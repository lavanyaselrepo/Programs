package connexus.coretest.testcases.cp1.airpracticecompliance;

import connexus.coretest.testscripts.RrAirPracticeComplianceTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.pageobjectmodels.connexus.DropOffPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.PatientMaintenancePage;
import hwqe.baseframework.models.pageobjectmodels.connexus.PatientSearchPage;
import hwqe.baseframework.utilities.PropertyReader;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class AirRrPracticeComplianceTestSet1 {

    RrAirPracticeComplianceTestSetScript rrAirPracticeComplianceTestSetScript = new RrAirPracticeComplianceTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    PropertyReader prop = PropertyReader.getInstance();
    String siteId =prop.getProperty("cnx.store");
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    boolean flagUpdated = false;

    @BeforeClass
    public void performlogin() {
        connexusAppUtils.startAppiumServer();
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Verify whether when a Pharmacy Associate, enters a new prescription for a C2 drug and it is past the Drop Off Expiration Date from fill date, Texas(TX) 21 days Expiry
     * PreCondition
     * 1. Update State to TX
     * Author: Tarun Upputuri(vn510o1)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify whether when a Pharmacy Associate, enters a new prescription for a C2 drug and it is past the Drop Off Expiration Date from fill date, Texas(TX) 21 days Expiry.",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/AirCp1Tests.json", sheetName = "AirCp1")
    public void HWPHME2E_423_C2_Past_Dropoff_Expiration_date(Map<String, String> inputData) {
        System.out.println(">>>tc_31_HWPHME2E_423_C2_Past_Dropoff_Expiration_date<<<");
        RrAirPracticeComplianceTestSetScript rrAirPracticeComplianceTestSetScript = new RrAirPracticeComplianceTestSetScript(LoginAs.userType.PHARMACIST_ADFlagOff);
        connexusAppUtils.getStoreId();
        //Pre-Conditions
        //1. Store state should be TX.
        //TC requires restart of services
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        rrAirPracticeComplianceTestSetScript.initializeTestCase(true);
        connexusAppUtils.getState(inputData);
        //1.Login to connexus with valid credentials.| Login should be successful
        //2.Drop an Original Rx.| Drop off should be completed and the Rx should be in Input work queue.
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff(Priority.Critical);

        //3.Input a C2 drug and all other mandatory details, give the Earliest Fill date(EFD) such that the Drop off has expired (> 21 days prior to the sys date) | User should be able to input all the mandatory details and the exp should be extended 21 days from EFD.
        //4.Click on Accept. Verify the work queue | Rx should be in 4 point check.
        rrAirPracticeComplianceTestSetScript.validatePastDropOffExpirationDate(inputData);
        System.out.println("<<<HWPHME2E_423_C2_Past_Dropoff_Expiration_date>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Verify whether warning message is displayed in application when standing Order for the prescriber got expired _TX State.
     * PreCondition
     * 1. Update State to TX
     * Author: Tarun Upputuri(vn510o1)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify whether warning message is displayed in application when standing Order for the prescriber got expired _TX State.",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/AirCp1Tests.json", sheetName = "AirCp1")
    public void HWPHME2E_424_Standing_Order_Warning_Message(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_424_Standing_Order_Warning_Message<<<");

        connexusAppUtils.getStoreId();

        //Pre-Conditions
        //1. Store state should be TX.

        //1.Login to Connexus with valid Credentials.| User should be able to Login to Connexus with valid Credentials.
        //2.User should be able to Login to Connexus with valid Credentials.| warning message should be displayed after opening the application.
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        rrAirPracticeComplianceTestSetScript.initializeTestCase(flagUpdated);
        rrAirPracticeComplianceTestSetScript.launchConnexusAndValidateStandingOrderProtocolPopup();

        System.out.println("<<<HWPHME2E_424_Standing_Order_Warning_Message>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description:Verify if the DX code field is available at input screen for CII drug_RI state.
      * PreCondition
      * 1. Update State to RI
      * Author: Tarun Upputuri(vn510o1)
  ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify if the DX code field is available at input screen for CII drug_RI state.",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/AirCp1Tests.json", sheetName = "AirCp1")
    public void HWPHME2E_425_DX_Code_Availability_For_C2_Drug_In_RI_State(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_425_DX_Code_Availability_For_C2_Drug_In_RI_State<<<");

        connexusAppUtils.getStoreId();
        //Pre-Conditions
        //1. Store state should be RI.
        //TC requires restart of Services
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        String issueAgencycode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE_UPDATE"));
        rrAirPracticeComplianceTestSetScript.updateDxCodeFlagCondition(issueAgencycode);
        connexusAPIManager.restartConnexusService(siteId);
        rrAirPracticeComplianceTestSetScript.initializeTestCase(true);
        connexusAppUtils.getState(inputData);

        //1.Login to Connexus with valid Credentials.| User should be able to Login to Connexus with valid Credentials
        //2.Drop a prescription for a patient with all mandatory fields filled in the Drop Off work queue.| User should be able to Drop a prescription for a patient with all mandatory fields filled in the Drop Off work queue.
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff(Priority.Critical);

        //3.Verify whether Rx is in Input work queue.| User should be able to see the Rx in Input queue.
        //4.Input all the mandatory details along with product/item as CII drug.| User should be able to give the respective details in input successfully.
        //5.Verify if the DX code field is visible above the "accept" option at input queue.| User should be able to see the DX code field at input queue.
        //6.Leave the DX code as empty and click on accept at input queue.| User should see a pop up "Input - Invalid Data" with a message saying Invalid Diagnosis code.
        //7.Give a valid code in the DX field and click on accept at input queue.| User should successfully complete the input queue.
        //8.Verify if the Rx is now at 4 point queue.| User should be able to see the Rx in 4 point queue.
        rrAirPracticeComplianceTestSetScript.inputPrescribedProduct(inputData);
        rrAirPracticeComplianceTestSetScript.validateIsDxCodeDisplayed();
        rrAirPracticeComplianceTestSetScript.enterPrescriberAndAccept(inputData);
        rrAirPracticeComplianceTestSetScript.verifyRxIn4PointQueue();

        System.out.println("<<<HWPHME2E_425_DX_Code_Availability_For_C2_Drug_In_RI_State>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
   * Test Description:Verify whether prescription is not allowed for more than 31 days supply for SC state _C2 drugs_Original Rx.
   * PreCondition
   * 1. Update State to SC
   * Author: Tarun Upputuri(vn510o1)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify whether prescription is not allowed for more than 31 days supply for SC state _C2 drugs_Original Rx.",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/AirCp1Tests.json", sheetName = "AirCp1")
    public void HWPHME2E_426_Days_Of_Supply_Not_More_than_30_Days_For_Sc_State_C2_Drug(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_426_Days_Of_Supply_Not_More_than_30_Days_For_Sc_State_C2_Drug<<<");

        connexusAppUtils.getStoreId();
        //Pre-Conditions
        //1. Store state should be SC
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        connexusAPIManager.restartConnexusService(siteId);
        rrAirPracticeComplianceTestSetScript.initializeTestCase(true);
        connexusAppUtils.getState(inputData);

        //1.Login to Connexus with valid Credentials.| User should be able to Login to Connexus with valid Credentials
        //2.Drop a prescription for a patient with all mandatory fields filled in the Drop Off work queue.| User should be able to Drop a prescription for a patient with all mandatory fields filled in the Drop Off work queue.
        //3.Verify whether Rx is in Input work queue | user should be able to verify that Rx is in Input work queue
        //4.Input all the mandatory details along with days supply more than 31 and verify error message is displayed | Prescription should not be allowed to move to next workqueue and error message should be displayed.
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff(Priority.Critical);
        rrAirPracticeComplianceTestSetScript.validateInvalidDaysOfSupplyErrorMessage(inputData);

        System.out.println("<<<HWPHME2E_426_Days_Of_Supply_Not_More_than_30_Days_For_Sc_State_C2_Drug>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Enter Non - Opioid drug in Input ,change it to Opioid drug after entering all other values and check TM code_OK State.
     * PreCondition
     * 1. Update State to OK
     * Author: Tarun Upputuri(vn510o1)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Enter Non - Opioid drug in Input ,change it to Opioid drug after entering all other values and check TM code_OK State.",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/AirCp1Tests.json", sheetName = "AirCp1")
    public void HWPHME2E_427_TM_Code_Field_For_Opioid_And_Non_Opioid_Drug_In_OK_State(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_427_TM_Code_Field_For_Opioid_And_Non_Opioid_Drug_In_OK_State<<<");

        connexusAppUtils.getStoreId();
        //Pre-Conditions
        //1. Store state should be OK
        //TC requires restart of services
        String issueAgencycode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE_UPDATE"));
        rrAirPracticeComplianceTestSetScript.updateTmFlagRestriction(issueAgencycode);
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        connexusAPIManager.restartConnexusService(siteId);
        connexusAppUtils.getState(inputData);
        rrAirPracticeComplianceTestSetScript.initializeTestCase(true);

        //1.Drop Rx in OK State.| Drop-off should be completed.
        //2.In Input , select an Opioid Drug (CODEINE PHOS POW) and enter all other details.| All details should be selected and TM Code should be blank.
        //3.Now select a Non-Opioid Drug(ZOLPIDEM 5MG TAB). | TM Code should be set to 99
        //4.Hower on to the TM code and verify the tool-tip. | Tool-tip should be appearing for the.
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff(Priority.Critical);
        rrAirPracticeComplianceTestSetScript.inputPrescribedProduct(inputData);
        rrAirPracticeComplianceTestSetScript.validateTmFieldForOpiodDrug();
        rrAirPracticeComplianceTestSetScript.validateTmFieldForNonOpiodDrug(inputData);

        System.out.println("<<<HWPHME2E_427_TM_Code_Field_For_Opioid_And_Non_Opioid_Drug_In_OK_State>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Enter Non - Opioid drug in Input ,change it to Opioid drug after entering all other values and check TM code_OK State.
    * PreCondition
    * 1. Update State to OK
    * Author: Tarun Upputuri(vn510o1)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Enter Non - Opioid drug in Input ,change it to Opioid drug after entering all other values and check TM code_OK State.",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/AirCp1Tests.json", sheetName = "AirCp1")
    public void HWPHME2E_428_TM_Code_Field_For_Non_Opioid_Drug_And_Opioid_In_OK_State(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_428_TM_Code_Field_For_Non_Opioid_Drug_And_Opioid_In_OK_State<<<");
        connexusAppUtils.getStoreId();
        connexusAppUtils.getState(inputData);

        //Pre-Conditions
        //1. Store state should be OK
        //1.Drop Rx in OK State.| Drop-off should be completed.
        //2.In Input , select an Non-Opioid Drug  (ZOLPIDEM 5MG TAB) and enter all other details| All details should be selected and TM Code should be 99.
        //3.Now select a Opioid Drug (CODEINE PHOS POW). | TM Code should be set to blank.
        //4.Expand the TM code drop down and verify codes 01,07,09,99 | The TM codes should have the Text attached as follows
        // 01 - Opioid: Not for Pain
        //07 - Opioid: Acute Pain
        //09 - Opioid: Chronic Pain
        //99 - Non-Opioid
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("OK");
        rrAirPracticeComplianceTestSetScript.initializeTestCase(true);
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff(Priority.Critical);
        rrAirPracticeComplianceTestSetScript.inputPrescribedProduct(inputData);
        rrAirPracticeComplianceTestSetScript.validateTmCodeDropDownValuesByChangingNonOpioidToOpioidDrug(inputData);

        System.out.println("<<<HWPHME2E_428_TM_Code_Field_For_Non_Opioid_Drug_And_Opioid_In_OK_State>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
   * Test Description:Verify whether Connexus is assigning a 30 day expiration date when a Pharmacy Associate enters a new prescription for a scheduled drug_NY state_original Rx_ CASH_C2drug.
   * PreCondition
   * 1. Update State to NY
   * Author: Tarun Upputuri(vn510o1)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify whether Connexus is assigning a 30 day expiration date when a Pharmacy Associate enters a new prescription for a scheduled drug_NY state_original Rx_ CASH_C2drug",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/AirCp1Tests.json", sheetName = "AirCp1")
    public void HWPHME2E_429_C2_Drug_Expiration_Date_NY_State(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_429_C2_Drug_Expiration_Date_NY_State<<<");
        RrAirPracticeComplianceTestSetScript rrAirPracticeComplianceTestSetScript = new RrAirPracticeComplianceTestSetScript(LoginAs.userType.PHARMACIST_ADFlagOff);
        connexusAppUtils.getStoreId();
        //PreCondition
        //1. Update State to NY
        // TC requires restart of services
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        connexusAppUtils.getState(inputData);
        rrAirPracticeComplianceTestSetScript.initializeTestCase(true);

        //1.Login to Connexus application with valid credentials | User should be able to Login to Connexus application with valid credentials.
        //2.Search for a patient with DOB,Phone number, First name and Last name in input work queue. | Search for a patient with DOB,Phone number, First name and Last name in input work queue.
        //3.Verify whether selected rx is opened when double clicked on the patient details. |Rx should be displayed on double clicking the patient details.
        //4.Verify all the patient details and C2 drug details | User should be able to Verify all the patient details and C2 drug details.
        //5.verify whether Connexus is assigning a 30 day expiration date for c2 drug. | 30 day expiration date should be assigned for c2 drug.
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff(Priority.Critical);
        rrAirPracticeComplianceTestSetScript.inputPrescribedProduct(inputData);
        rrAirPracticeComplianceTestSetScript.validateControlDrugExpirationDate(inputData);

        System.out.println("<<<HWPHME2E_429_C2_Drug_Expiration_Date_NY_State>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
       * Test Description:verify whether Connexus is assigning a 180 day expiration date when a Pharmacy Associate enters a new prescription for a scheduled drug_NY state_original Rx_ CASH_C3drug
       * PreCondition
       * 1. Update State to NY
       * Author: Tarun Upputuri(vn510o1)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "verify whether Connexus is assigning a 180 day expiration date when a Pharmacy Associate enters a new prescription for a scheduled drug_NY state_original Rx_ CASH_C3drug",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/AirCp1Tests.json", sheetName = "AirCp1")
    public void HWPHME2E_430_C3_Drug_Expiration_Date_NY_State(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_430_C3_Drug_Expiration_Date_NY_State<<<");
        RrAirPracticeComplianceTestSetScript rrAirPracticeComplianceTestSetScript = new RrAirPracticeComplianceTestSetScript(LoginAs.userType.PHARMACIST_ADFlagOff);
        connexusAppUtils.getStoreId();
        //PreCondition
        //1. Update State to NY
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        connexusAppUtils.getState(inputData);
        connexusAPIManager.restartConnexusService(siteId);
        rrAirPracticeComplianceTestSetScript.initializeTestCase(true);

        //1.Login to Connexus application with valid credentials | User should be able to Login to Connexus application with valid credentials.
        //2.Search for a patient with DOB,Phone number, First name and Last name in input work queue. | Search for a patient with DOB,Phone number, First name and Last name in input work queue.
        //3.Verify whether selected rx is opened when double clicked on the patient details. |Rx should be displayed on double clicking the patient details.
        //4.Verify all the patient details and C3 drug details | User should be able to Verify all the patient details and C3 drug details.
        //5.verify whether Connexus is assigning a 180 day expiration date for c3 drug. | 180 day expiration date should be assigned for c3 drug.
        rrAirPracticeComplianceTestSetScript.createNewPatient(inputData);
        rrAirPracticeComplianceTestSetScript.performDropOff(Priority.Critical);
        rrAirPracticeComplianceTestSetScript.validateC3ExpirationDate(inputData);

        System.out.println("<<<HWPHME2E_430_C3_Drug_Expiration_Date_NY_State>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
       * Test Description:Verify, a time stamp is updated in patient_demog table when a patient profile is updated for the Lbs field for a Patient with less than 12 Yrs of age
       * Author: Tarun Upputuri(vn510o1)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify, a time stamp is updated in patient_demog table when a patient profile is updated for the Lbs field for a Patient with less than 12 Yrs of age.",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/AirCp1Tests.json", sheetName = "AirCp1")
    public void HWPHME2E_245_Patient_Demog_Table_Time_Stamp_When_Lbs_Updated(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_245_Patient_Demog_Table_Time_Stamp_When_Lbs_Updated<<<");
        connexusAppUtils.getStoreId();
        rrAirPracticeComplianceTestSetScript.initializeTestCase(true);
        rrAirPracticeComplianceTestSetScript.selectingPatientTypeHumanDropOffQueue(inputData);
        rrAirPracticeComplianceTestSetScript.editingWeightField();
        rrAirPracticeComplianceTestSetScript.verifyWeightField();
        PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
        patientMaintenancePage.clickExit();
        patientMaintenancePage.clickYes();
        PatientSearchPage patientSearchPage = new PatientSearchPage();
        patientSearchPage.clickClose();
        DropOffPage dropOffPage = new DropOffPage();
        dropOffPage.clickBtnCancel();
    }
}
