package connexus.coretest.testcases;
import connexus.ConnexusTestScripts;
import connexus.coretest.testscripts.PaymentFlowZeroCopayTestScript;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.utilities.PropertyReader;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.utilities.Reporter;
import java.util.*;

    public class PaymentFlowZeroCopay {
    PaymentFlowZeroCopayTestScript paymentFlowZeroCopayTestScript = new PaymentFlowZeroCopayTestScript();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    PropertyReader prop = PropertyReader.getInstance();
    String siteId =prop.getProperty("cnx.store");
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    public static LoginAs.userType loginUser_Type=LoginAs.userType.HOMEOFFICE_ADFlagOn;
    ConnexusTestScripts connexusTestScripts = new ConnexusTestScripts();
    ServiceResponse resp;
    InputResponse inputResp;
    
    Map<String, List<String>> workQueueToRxList = new HashMap<>();
    List<String> rxFillIdList = new ArrayList<>();
    String workQueue = null;

    private void ensureLoggedInForStore(String storeName) {
        Reporter.log("Ensuring logged in for store: " + storeName);
        connexusAppUtils.readAndUpdateFlag("15192", "TRUE");
        connexusAppUtils.readAndUpdateFlag("5323", storeName);
        connexusAppUtils.readAndUpdateFlag("15068","QA");
        connexusAPIManager.flushCache(siteId);
    }
    @BeforeClass
    public void loginToConnexus() {
        connexusAppUtils.startAppiumServer();
    }
    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }
    @Test(enabled = true, description = "Verify that the receipt is not printed for 0 Co-pay and only the scan tag is printed at Pickup when bagging Flag is off and Zero Pay flag is On for sam's store.",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputDoubleRxTestData.json", sheetName = "InputDoubleRxTestSet1")
    public void HWPHME2E_1574_0_Copay_1rx_Walmart_Pharmacy(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-1574-0_Copay_1rx_Walmart_Pharmacy");
        try {
            ensureLoggedInForStore("Wal-Mart Pharmacy");
            int patientId = connexusTestScripts.addPatientWithTP(inputData);
            List<String>responseList = connexusTestScripts.createNewOrderTillPickup(inputData, inputData.get("DRUG_NAME"), patientId);
            String rxNbr = responseList.get(0);
            String workQueue = responseList.get(1);
            String fillId = responseList.get(2);
            paymentFlowZeroCopayTestScript.loginConnexus(loginUser_Type);
            connexusTestScripts.performPickupWithPatientId(inputData,patientId,rxNbr, workQueue);
            resp = connexusAPIManager.getOrderDetailsInfo(Integer.parseInt(siteId), Integer.parseInt(fillId));
            resp = connexusAPIManager.counselComplete(resp.getDataResponse());
            inputResp = resp.getDataResponse(InputResponse.class);
            String workqueue = inputResp.getWorkQueue();
            if (WorkQueueSettings.EOD.name().equals(workqueue)) {
                Reporter.log("Success: Order moved to correct WorkQueue:" + workqueue);
            } else {
                Reporter.log("Failure: Order failed to move to EOD, but found " + workqueue);
                Assert.fail("Failure: Order failed to move to EOD, verify EasyPay manually");
            }
        } catch (Exception e) {
            Reporter.log("Test failed in HWPHME2E_1574_0_Copay_1rx_Walmart_Pharmacy: " + e.getMessage());
            throw e;
        } finally {
            // Ensure Connexus is closed to keep environment clean for next tests
            AutomationManager.getInstance().getConnexus().closeConnexus();
        }
    }
    @Test(enabled = true, description = "Verify that the receipt is not printed for 0 Co-pay and only the scan tag is printed at Pickup when bagging Flag is off and Zero Pay flag is On for sam's store.",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputDoubleRxTestData.json", sheetName = "InputDoubleRxTestSet1")
    public void HWPHME2E_1574_0_Copay_1rx_Sams_Pharmacy(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-1574-0_Copay_1rx_Sams_Pharmacy");
        try {
        ensureLoggedInForStore("Sam's Pharmacy");
            int patientId = connexusTestScripts.addPatientWithTP(inputData);
            List<String>responseList = connexusTestScripts.createNewOrderTillPickup(inputData, inputData.get("DRUG_NAME"), patientId);
            String rxNbr = responseList.get(0);
            String workQueue = responseList.get(1);
            String fillId = responseList.get(2);
            paymentFlowZeroCopayTestScript.loginConnexus(loginUser_Type);
            connexusTestScripts.performPickupWithPatientId(inputData,patientId,rxNbr, workQueue);
            resp = connexusAPIManager.getOrderDetailsInfo(Integer.parseInt(siteId), Integer.parseInt(fillId));
            resp = connexusAPIManager.counselComplete(resp.getDataResponse());
            inputResp = resp.getDataResponse(InputResponse.class);
            String workqueue = inputResp.getWorkQueue();
            if (WorkQueueSettings.EOD.name().equals(workqueue)) {
                Reporter.log("Success: Order moved to correct WorkQueue:" + workqueue);
            } else {
                Reporter.log("Failure: Order failed to move to EOD, but found " + workqueue);
                Assert.fail("Failure: Order failed to move to EOD, verify EasyPay manually");
            }
    } catch (Exception e) {
        Reporter.log("Test failed in HWPHME2E_1574_0_Copay_1rx_Sams_Pharmacy: " + e.getMessage());
        throw e;
    } finally {
        // Ensure Connexus is closed to keep environment clean for next tests
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }
    }

    @Test(enabled = true, description = "Verify that the receipt is not printed for 0 Co-pay and only the scan tag is printed at Pickup when bagging Flag is Off and Zero Pay flag is On for a multi rx scenario for Wal-Mart Pharmacy store",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputDoubleRxTestData.json", sheetName = "InputDoubleRxTestSet1")
    public void HWPHME2E_1572_0_Copay_2rx_Walmart_Pharmacy(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-1572-0_Copay_2rx_Walmart_Pharmacy");
        try {
        ensureLoggedInForStore("Wal-Mart Pharmacy");
            List<String> ndcList = Arrays.asList(inputData.get("PRODUCT_NAME"), inputData.get("DRUG_NAME"));
        int patientId = connexusTestScripts.addPatientWithTP(inputData);
        List<String> multiRxResponseList = connexusTestScripts.dropMultiRxOrderTillPickup(inputData,ndcList, patientId);
        paymentFlowZeroCopayTestScript.loginConnexus(loginUser_Type);
            for (int i = 0; i < multiRxResponseList.size(); i += 5) {

                String rxNbr = multiRxResponseList.get(i);
                String workQueue = multiRxResponseList.get(i + 1);
                String fillId = multiRxResponseList.get(i + 2);

                // Group Rx numbers by work queue
                workQueueToRxList.computeIfAbsent(workQueue, k -> new ArrayList<>()).add(rxNbr);
                rxFillIdList.add(fillId);

            }

            // Loop over each WorkQueue and process pickup
            for (Map.Entry<String, List<String>> entry : workQueueToRxList.entrySet()) {
                String workQueue = entry.getKey();
                List<String> rxNbrList = entry.getValue();

                connexusTestScripts.performMultiRxPickupWithPatientId(
                        inputData,
                        patientId,
                        rxNbrList,
                        workQueue
                );
            }
            // Validate EOD transition for each fillId
            for (String fillId : rxFillIdList) {
                resp = connexusAPIManager.getOrderDetailsInfo(Integer.parseInt(siteId), Integer.parseInt(fillId));
                resp = connexusAPIManager.counselComplete(resp.getDataResponse());
                inputResp = resp.getDataResponse(InputResponse.class);
                String resultingQueue = inputResp.getWorkQueue();
                if (WorkQueueSettings.EOD.name().equals(resultingQueue)) {
                    Reporter.log("Success: Order for Fill ID " + fillId + " moved to correct WorkQueue: " + resultingQueue);
                } else {
                    Reporter.log(" Failure: Order for Fill ID " + fillId + " failed to move to EOD. Expected 'EOD' but found: " + resultingQueue);
                    Assert.fail("Failure: Order failed to move to EOD, verify EasyPay manually");
                }
            }
        } catch (Exception e) {
            Reporter.log(" Test failed in HWPHME2E_1572_0_Copay_2rx_Walmart_Pharmacy: " + e.getMessage());
            throw e;
        } finally {
            AutomationManager.getInstance().getConnexus().closeConnexus();
        }
    }

    @Test(enabled = true, description = "Verify that the receipt is not printed for 0 Co-pay and only the scan tag is printed at Pickup when bagging Flag is Off and Zero Pay flag is On for a multi rx scenario for Sam's store",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputDoubleRxTestData.json", sheetName = "InputDoubleRxTestSet1")
    public void HWPHME2E_1572_0_Copay_2rx_Sams_Pharmacy(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-1572-0_Copay_2rx_Sams_Pharmacy");
        try {
        ensureLoggedInForStore("Sam's Pharmacy");
        List<String> ndcList = Arrays.asList(inputData.get("PRODUCT_NAME"), inputData.get("DRUG_NAME"));
        int patientId = connexusTestScripts.addPatientWithTP(inputData);
            List<String> multiRxResponseList = connexusTestScripts.dropMultiRxOrderTillPickup(inputData,ndcList,patientId);
        paymentFlowZeroCopayTestScript.loginConnexus(loginUser_Type);
            for (int i = 0; i < multiRxResponseList.size(); i += 5) {

                String rxNbr = multiRxResponseList.get(i);
                String workQueue = multiRxResponseList.get(i + 1);
                String fillId = multiRxResponseList.get(i + 2);

                // Group Rx numbers by work queue
                workQueueToRxList.computeIfAbsent(workQueue, k -> new ArrayList<>()).add(rxNbr);
                rxFillIdList.add(fillId);

            }

            // Loop over each WorkQueue and process pickup
            for (Map.Entry<String, List<String>> entry : workQueueToRxList.entrySet()) {
                String workQueue = entry.getKey();
                List<String> rxNbrList = entry.getValue();

                connexusTestScripts.performMultiRxPickupWithPatientId(
                        inputData,
                        patientId,
                        rxNbrList,
                        workQueue
                );
            }
            // Validate EOD transition for each fillId
            for (String fillId : rxFillIdList) {
                resp = connexusAPIManager.getOrderDetailsInfo(Integer.parseInt(siteId), Integer.parseInt(fillId));
                resp = connexusAPIManager.counselComplete(resp.getDataResponse());
                inputResp = resp.getDataResponse(InputResponse.class);
                String resultingQueue = inputResp.getWorkQueue();
                if (WorkQueueSettings.EOD.name().equals(resultingQueue)) {
                    Reporter.log("Success: Order for Fill ID " + fillId + " moved to correct WorkQueue: " + resultingQueue);
                } else {
                    Reporter.log(" Failure: Order for Fill ID " + fillId + " failed to move to EOD. Expected 'EOD' but found: " + resultingQueue);
                    Assert.fail("Failure: Order failed to move to EOD, verify EasyPay manually");
                }
            }
        } catch (Exception e) {
            Reporter.log(" Test failed in HWPHME2E_1572_0_Copay_2rx_Walmart_Pharmacy: " + e.getMessage());
            throw e;
        } finally {
            AutomationManager.getInstance().getConnexus().closeConnexus();
        }
    }
}