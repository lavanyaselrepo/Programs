package connexus.coretest.testcases;


import connexus.coretest.testscripts.UserExperienceTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class UserExperienceTestSet1 {

    UserExperienceTestSetScript userExperienceTestSetScript = new UserExperienceTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    AutomationManager automationManager = AutomationManager.getInstance();
    public static LoginAs.userType loginUser_Type=LoginAs.userType.HOMEOFFICE_ADFlagOn;

    @BeforeClass
    public void performlogin() {
        automationManager.performSleep(10);
        connexusAppUtils.startAppiumServer();
        userExperienceTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

        //tc_01 is Obsolete because in new PMS screen Phone number provided in the search screen should not be prepopulated in the Phone 1 field, ignore it
    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Phone number is pre-populated in the Phone 1 field of Contact
     * information section on the general information tab of New PMS, when phone number is provided in the search
     * screen, while creating a new patient profile.
     *
     * JIRA: HWPHME2E-199
     *
     * Pre-Conditions:
     * 1. New PMS 27247 should be set to TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-199")
   /* @Test(description = "To verify whether the Phone number is pre-populated in the Phone 1 field of Contact " +
            "information section on the general information tab of New PMS, when phone number is provided in the " +
            "search screen, while creating a new patient profile.",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_199_tc_01_Phone_No_Pre_populating(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_199_tc_01_Phone_No_Pre_populating<<<");

        //Pre-Condition
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");

        //1.Login to Connexus and Press Ctrl+Shift+P | Patient search screen should be displayed.
        //2.Enter FN,LN,DOB & Phone field in the Search screen | User should be able to enter the data in the respective fields.
        //3.Click on Search Now button | Search result should not be displayed.
        userExperienceTestSetScript.searchPatientWithFields(inputData);

        //4.Click on Host Look up | Search result should not be displayed.
        userExperienceTestSetScript.hostLookUpInPatientSearch(inputData);

        //5.Click on New | General Information tab of New PMS should be displayed.
        userExperienceTestSetScript.clickNewInPatientSearch(inputData);

        //6.Select patient type as Human in the General Information tab of New PMS | All the fields in the general information tab of new PMS should get enabled.
        userExperienceTestSetScript.selectPatientTypeHuman(inputData);

        //7.Verify the Phone 1 field in the Contact Information section  in the general information tab of new PMS | Phone number provided in the search screen should be pre populated in the Phone 1 field
        userExperienceTestSetScript.validatePhoneNumberPMS(inputData);

        //To continue the flow of next test case
        userExperienceTestSetScript.clickExitPMSWithAbondonPopUp(inputData);
        userExperienceTestSetScript.clickCloseInPatientSearch(inputData);

        System.out.println("<<<HWPHME2E_199_tc_01_Phone_No_Pre_populating>>>");
    }*/

    //tc_02 is Obsolete because in new PMS screen Phone number provided in the search screen should not be prepopulated in the Phone 1 and Zip code field, ignore it
    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Zip code number is pre-populated in the Zip field in the Physical
     * Address Tab of Address section  in the general information tab of new PMS, when zip code number is provided
     * in the search screen, while creating a new patient profile.
     *
     * JIRA: HWPHME2E-184
     *
     * Pre-Conditions:
     * 1. New PMS 27247 should be set to TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-184")
  /*  @Test(description = "To verify whether the Zip code number is pre-populated in the Zip field in the Physical " +
            "Address Tab of Address section  in the general information tab of new PMS, when zip code number is provided" +
            " in the search screen, while creating a new patient profile.",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_184_tc_02_Phone_Zip_Code_Pre_populating(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_184_tc_02_Phone_Zip_Code_Pre_populating<<<");

        //Pre-Condition
        //connexusAppUtlis.readAndUpdateFlag("27247","TRUE");

        //1.Login to Connexus and Press Ctrl+Shift+P | Patient search screen should be displayed.
        //2.Enter FN,LN,DOB & Phone field in the Search screen | User should be able to enter the data in the respective fields.
        //3.Click on Search Now button | Search result should not be displayed.
        userExperienceTestSetScript.searchPatientWithFields(inputData);

        //4.Enter Zip Code in the Zip field of the Search screen | User should be able to enter the zip code in the zip field.
        userExperienceTestSetScript.searchPatientwithZipCode(inputData);

        //5.Click on Host Look up | Search result should not be displayed.
        userExperienceTestSetScript.hostLookUpInPatientSearch(inputData);

        //6.Click on New | General Information tab of New PMS should be displayed.
        userExperienceTestSetScript.clickNewInPatientSearch(inputData);

        //7.Select patient type as Human in the General Information tab of New PMS | All the fields in the general information tab of new PMS should get enabled.
        userExperienceTestSetScript.selectPatientTypeHuman(inputData);

        //8.Verify the Phone 1 field in the Contact Information section  in the general information tab of new PMS | Phone number provided in the search screen should be pre populated in the Phone 1 field
        userExperienceTestSetScript.validatePhoneNumberPMS(inputData);

        //9.Verify the Zip field in the Physical Address Tab of Address section  in the general information tab of new PMS | Zip code provided in the search screen should be pre populated in the Physical Address Tab of Address section  in the general information tab of new PMS
        userExperienceTestSetScript.validateZip(inputData);

        //To continue the flow of next test case
        userExperienceTestSetScript.clickExitPMSWithAbondonPopUp(inputData);
        userExperienceTestSetScript.clickCloseInPatientSearch(inputData);

        System.out.println("<<<HWPHME2E_184_tc_02_Phone_Zip_Code_Pre_populating>>>");
    }*/

    // tc_04 to tc_14 all test cases are combined into tc_03 and validating in same screen TASCO PMS
    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Last Name, First name,Middle Name, Birth date, Gender radio buttons, Weight, Birth Allergy information grid, Medical Condition Information grid,
     * Other Medications button, ClinicalServices Details button, Allergy Medical Conditions Tab fields are disabled for the patient in the General Information
     * Tab on New PMS when we opened from TASCO machine.
     *
     * JIRA: HWPHME2E-586
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-586")
    @Test(description = "To verify whether fields are disabled on New PMS when we opened Patient Profile from TASCO machine.",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_586_tc_03_TASCO_PMS_GeneralInformation_Patient_Profile(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_586_tc_03_TASCO_PMS_GeneralInformation_Patient_Profile<<<");

        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE
        if (connexusAppUtils.readAndUpdateFlag("26849", "TRUE")) {
            AutomationManager.getInstance().getConnexus().closeConnexus();
            automationManager.performSleep(2);
            userExperienceTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            connexusAppUtils.getStoreId();
        }
        userExperienceTestSetScript.createNewPatient(inputData);
        userExperienceTestSetScript.dropAnRxTillPickUp(inputData);

        //1.Hit f11 and open the TASCO | TASCO should display
        userExperienceTestSetScript.openTascoPage(inputData);

        //2.Enter Patient Last Name | Last Name should be able to enter in the field
        //3.Enter Patient First Name | First Name should be able to enter in the field
        //4.Enter Patient DOB | DOB should be able to enter in the field
        //5.Select Search | It should redirect to next page
        userExperienceTestSetScript.searchPatientInTasco(inputData);

        //6.Select Patient Profile from the menu | It shouldredirect to PMS
        //7.Verfy it is displaying the PMS General Information screen | Should display General Information Screen
        userExperienceTestSetScript.patientProfileInTascoPage(inputData);

        //8.Verify Patient Information is displaying in the mandatory fields of PMS General Information screen. | Should display all mandatory fields
        userExperienceTestSetScript.mandatoryFieldsGeneralInformation(inputData);

        //9.Verify Last Name, First Name, Middle Name, Birth date,Gender,Weight,Allergy Information grid,Medical Condition Information grid are disable in General Information Screen | Last Name, First Name, Middle Name, Birth date,Gender,Weight,Allergy Information grid,Medical Condition Information grid should be disable in General Information Screen
        userExperienceTestSetScript.lastNameDisabledPMS(inputData);
        userExperienceTestSetScript.firstNameDisabledPMS(inputData);
        userExperienceTestSetScript.middleNameDisabledPMS(inputData);
        userExperienceTestSetScript.dateOfBirthDisabledPMS(inputData);
        userExperienceTestSetScript.genderDisabledPMS(inputData);
        userExperienceTestSetScript.weightDisabledPMS(inputData);
        userExperienceTestSetScript.allergyRadioButtonsDisabled(inputData);
        userExperienceTestSetScript.medicalRadioButtonsDisabled(inputData);

        //10.Verify Other medications button is disabled in Profile/Other screen | Other medications button should be disabled in Profile/Other screen
        userExperienceTestSetScript.otherMedicationsDisabledInProfile(inputData);

        //11.Verify Service Details button is disabled in Clinical Services screen. | Service Details button should be disabled in Clinical Services screen.
        userExperienceTestSetScript.serviceDetailsDisabledInClinicalServices(inputData);

        //12.Open Allergy/Medical Condition tab | Should display Allergy/Medical Condition screen
        //13.Verify Allergy added to allergy grid should  be disabled (It should not allow to deactivate the allergy). | Allergy grid should be disabled in PMS Allergy Medical Conditions Tab
        userExperienceTestSetScript.allergyDisabledInAlleryMedicalConditions(inputData);

        //14.Verify Medical conditions added to medical condition grid should  be disabled (not able to deactivate). | Medical conditions grid should be disabled
        userExperienceTestSetScript.medicalDisabledInAlleryMedical(inputData);

        //To continue the flow of next test case in TASCO PMS Allergy Medical Conditions Tab
        userExperienceTestSetScript.clickExitPMSWithAbondonPopUp(inputData);

        System.out.println("<<<HWPHME2E_586_tc_03_TASCO_PMS_GeneralInformation_Patient_Profile>>>");
    }


    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the First name field is disabled for the patient in the General Information
     *  Tab on New PMS when we opened from TASCO machine.
     *
     * JIRA: HWPHME2E-586
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-586")
 /*  @Test(description = "To verify whether the First name field is disabled for the patient in the General Information" +
            " Tab on New PMS when we opened from TASCO machine.",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_03_389315_TASCO_PMS_GeneralInformation_Screen_LastName"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_586_tc_04_TASCO_PMS_GeneralInformation_Screen_FirstName(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_586_tc_04_TASCO_PMS_GeneralInformation_Screen_FirstName<<<");

        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE

        //1.Hit f11 and open the TASCO | TASCO should display
        //2.Enter Patient Last Name | Last Name should be able to enter in the field
        //3.Enter Patient First Name | First Name should be able to enter in the field
        //4.Enter Patient DOB | DOB should be able to enter in the field
        //5.Select Search | It should redirect to next page
        //6.Select Patient Profile from the menu | It should redirect to PMS
        //7.Verify it is displaying the PMS General Information screen | Should display General Information Screen
        //8.Verify Patient Information is displaying in the mandatory fields of PMS General Information screen. | Should display all mandatory fields
        //9.Verify Patient First Name field is disabed. | First Name field should be disabled
        userExperienceTestSetScript.firstNameDisabledPMS(inputData);

        System.out.println("<<<HWPHME2E_586_tc_04_TASCO_PMS_GeneralInformation_Screen_FirstName>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Middle Name field is disabled for the patient in the General Information
     *  Tab on New PMS when we opened from TASCO machine.
     *
     * JIRA: HWPHME2E-586
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-586")
  /*  @Test(description = "To verify whether the Middle Name field is disabled for the patient in the General Information" +
            " Tab on New PMS when we opened from TASCO machine.",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_03_389315_TASCO_PMS_GeneralInformation_Screen_LastName"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_586_tc_05_TASCO_PMS_GeneralInformation_Screen_MiddleName(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_586_tc_05_TASCO_PMS_GeneralInformation_Screen_MiddleName<<<");

        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE

        //1.Hit f11 and open the TASCO | TASCO should display
        //2.Enter Patient Last Name | Last Name should be able to enter in the field
        //3.Enter Patient First Name | First Name should be able to enter in the field
        //4.Enter Patient DOB | DOB should be able to enter in the field
        //5.Select Search | It should redirect to next page
        //6.Select Patient Profile from the menu | It should redirect to PMS
        //7.Verify it is displaying the PMS General Information screen | Should display General Information Screen
        //8.Verify Patient Information is displaying in the mandatory fields of PMS General Information screen. | Should display all mandatory fields
        //9.Verify Patient Middle Name field is disabed. | Middle Name field should be disabled
        userExperienceTestSetScript.middleNameDisabledPMS(inputData);

        System.out.println("<<<HWPHME2E_586_tc_05_TASCO_PMS_GeneralInformation_Screen_MiddleName>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Birth date field is disabled for the patient in the General
     * Information Tab on New PMS when we opened from TASCO machine.
     *
     * JIRA: HWPHME2E-586
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-586")
   /* @Test(description = "To verify whether the Birth date field is disabled for the patient in the General Information" +
            " Tab on New PMS when we opened from TASCO machine.",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_03_389315_TASCO_PMS_GeneralInformation_Screen_LastName"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_586_tc_06_TASCO_PMS_GeneralInformation_Screen_Birthdate(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_586_tc_06_TASCO_PMS_GeneralInformation_Screen_Birthdate<<<");

        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE

        //1.Hit f11 and open the TASCO | TASCO should display
        //2.Enter Patient Last Name | Last Name should be able to enter in the field
        //3.Enter Patient First Name | First Name should be able to enter in the field
        //4.Enter Patient DOB | DOB should be able to enter in the field
        //5.Select Search | It should redirect to next page
        //6.Select Patient Profile from the menu | It should redirect to PMS
        //7.Verify it is displaying the PMS General Information screen | Should display General Information Screen
        //8.Verify Patient Information is displaying in the mandatory fields of PMS General Information screen. | Should display all mandatory fields
        //9.Verify Patient Birth date field is disabed. | Birth date field should be disabled
        userExperienceTestSetScript.dateOfBirthDisabledPMS(inputData);

        System.out.println("<<<HWPHME2E_586_tc_06__PMS_GeneralInformation_Screen_Birthdate>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Gender radio buttons is disabled for the patient in the General
     * Information Tab on New PMS when we opened from TASCO machine.
     *
     * JIRA: HWPHME2E-586
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-586")
  /*  @Test(description = "To verify whether the Gender radio buttons is disabled for the patient in the General " +
            "sInformation Tab on New PMS when we opened from TASCO machine.",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_03_389315_TASCO_PMS_GeneralInformation_Screen_LastName"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_586_tc_07_TASCO_PMS_GeneralInformation_Screen_Gender(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_586_tc_07_TASCO_PMS_GeneralInformation_Screen_Gender<<<");

        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE

        //1.Hit f11 and open the TASCO | TASCO should display
        //2.Enter Patient Last Name | Last Name should be able to enter in the field
        //3.Enter Patient First Name | First Name should be able to enter in the field
        //4.Enter Patient DOB | DOB should be able to enter in the field
        //5.Select Search | It should redirect to next page
        //6.Select Patient Profile from the menu | It should redirect to PMS
        //7.Verify it is displaying the PMS General Information screen | Should display General Information Screen
        //8.Verify Patient Information is displaying in the mandatory fields of PMS General Information screen. | Should display all mandatory fields
        //9.Verify Patient Gender radio buttons are disabled. | Gender radio buttons should be disabled
        userExperienceTestSetScript.genderDisabledPMS(inputData);

        System.out.println("<<<HWPHME2E_586_tc_07_TASCO_PMS_GeneralInformation_Screen_Gender>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Weight field is disabled for the patient in the General Information
     *  Tab on New PMS when we opened from TASCO machine.
     *
     * JIRA: HWPHME2E-586
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-586")
   /* @Test(description = "To verify whether the Weight field is disabled for the patient in the General Information" +
            " Tab on New PMS when we opened from TASCO machine.",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_03_389315_TASCO_PMS_GeneralInformation_Screen_LastName"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_586_tc_08_TASCO_PMS_GeneralInformation_Screen_Weight(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_586_tc_08_TASCO_PMS_GeneralInformation_Screen_Weight<<<");

        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE

        //1.Hit f11 and open the TASCO | TASCO should display
        //2.Enter Patient Last Name | Last Name should be able to enter in the field
        //3.Enter Patient First Name | First Name should be able to enter in the field
        //4.Enter Patient DOB | DOB should be able to enter in the field
        //5.Select Search | It should redirect to next page
        //6.Select Patient Profile from the menu | It should redirect to PMS
        //7.Verify it is displaying the PMS General Information screen | Should display General Information Screen
        //8.Verify Patient Information is displaying in the mandatory fields of PMS General Information screen. | Should display all mandatory fields
        //9.Verify Patient weight field is disabled. | Weight field should be disabled
        userExperienceTestSetScript.weightDisabledPMS(inputData);

        System.out.println("<<<HWPHME2E_586_tc_08_TASCO_PMS_GeneralInformation_Screen_Weight>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Birth Allergy information grid is disabled for the patient in the General
     *  Information Tab on New PMS when we opened from TASCO machine.
     *
     * JIRA: HWPHME2E-586
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-586")
  /*  @Test(description = "To verify whether the Birth Allergy information grid is disabled for the patient in the General" +
            " Information Tab on New PMS when we opened from TASCO machine.",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_03_389315_TASCO_PMS_GeneralInformation_Screen_LastName"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_586_tc_09_TASCO_PMS_GeneralInformation_Screen_AllergyInformationGrid(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_586_tc_09_TASCO_PMS_GeneralInformation_Screen_AllergyInformationGrid<<<");

        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE

        //1.Hit f11 and open the TASCO | TASCO should display
        //2.Enter Patient Last Name | Last Name should be able to enter in the field
        //3.Enter Patient First Name | First Name should be able to enter in the field
        //4.Enter Patient DOB | DOB should be able to enter in the field
        //5.Select Search | It should redirect to next page
        //6.Select Patient Profile from the menu | It should redirect to PMS
        //7.Verify it is displaying the PMS General Information screen | Should display General Information Screen
        //8.Verify Patient Information is displaying in the mandatory fields of PMS General Information screen. | Should display all mandatory fields
        //9.Verify Allergy Information grid radio buttons are disabled | Allergy Information grid radio buttons should be disabled
        userExperienceTestSetScript.allergyRadioButtonsDisabled(inputData);

        System.out.println("<<<HWPHME2E_586_tc_09_TASCO_PMS_GeneralInformation_Screen_AllergyInformationGrid>>>");
    }*/


    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Medical Condition Information grid is disabled for the patient in the General
     *  Information Tab on New PMS when we opened from TASCO machine.
     *
     * JIRA: HWPHME2E-586
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-586")
  /*  @Test(description = "To verify whether the Medical Condition Information grid is disabled for the patient in the General" +
            " Information Tab on New PMS when we opened from TASCO machine.",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_03_389315_TASCO_PMS_GeneralInformation_Screen_LastName"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_586_tc_10_TASCO_PMS_GeneralInformation_Screen_MedicalConditionInformation(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_586_tc_10_TASCO_PMS_GeneralInformation_Screen_MedicalConditionInformation<<<");

        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE

        //1.Hit f11 and open the TASCO | TASCO should display
        //2.Enter Patient Last Name | Last Name should be able to enter in the field
        //3.Enter Patient First Name | First Name should be able to enter in the field
        //4.Enter Patient DOB | DOB should be able to enter in the field
        //5.Select Search | It should redirect to next page
        //6.Select Patient Profile from the menu | It should redirect to PMS
        //7.Verify it is displaying the PMS General Information screen | Should display General Information Screen
        //8.Verify Patient Information is displaying in the mandatory fields of PMS General Information screen. | Should display all mandatory fields
        //9.Verify Medical Condition Information grid Radio buttons are disabled | Medical Condition Information grid Radio buttons should be disabled
        userExperienceTestSetScript.medicalRadioButtonsDisabled(inputData);

        System.out.println("<<<HWPHME2E_586_tc_10_TASCO_PMS_GeneralInformation_Screen_MedicalConditionInformation>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Other Medications button is disabled for the patient in the Profile/OtherScreen
     * Tab on New PMS when we opened from TASCO machine.
     *
     * JIRA: HWPHME2E-586
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-586")
  /*  @Test(description = "To verify whether the Other Medications button is disabled for the patient in the " +
            "Profile/OtherScreen Tab on New PMS when we opened from TASCO machine.",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_03_389315_TASCO_PMS_GeneralInformation_Screen_LastName"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_586_tc_11_TASCO_PMS_Profile_Otherscreen_OtherMedications(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_586_tc_11_TASCO_PMS_Profile_Otherscreen_OtherMedications<<<");

        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE

        //1.Hit f11 and open the TASCO | TASCO should display
        //2.Enter Patient Last Name | Last Name should be able to enter in the field
        //3.Enter Patient First Name | First Name should be able to enter in the field
        //4.Enter Patient DOB | DOB should be able to enter in the field
        //5.Select Search | It should redirect to next page
        //6.Select Patient Profile from the menu | It should redirect to PMS
        //7.Verify it is displaying the PMS General Information screen | Should display General Information Screen
        //8.Verify Patient Information is displaying in the mandatory fields of PMS General Information screen. | Should display all mandatory fields
        //9.Verify Other medications button is disabled | Other medications button should be disabled
        userExperienceTestSetScript.otherMedicationsDisabledInProfile(inputData);

        System.out.println("<<<HWPHME2E_586_tc_11_TASCO_PMS_Profile_Otherscreen_OtherMedications>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Service Details button is disabled for the patient in the Clinical Services
     *  Tab on New PMS when we opened from TASCO machine.
     *
     * JIRA: HWPHME2E-586
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-586")
  /*  @Test(description = "To verify whether the Service Details button is disabled for the patient in the Clinical Services " +
            "Tab on New PMS when we opened from TASCO machine.",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_03_389315_TASCO_PMS_GeneralInformation_Screen_LastName"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_586_tc_12_TASCO_PMS_ClinicalServices_ServiceDetails(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_586_tc_12_TASCO_PMS_ClinicalServices_ServiceDetails<<<");

        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE

        //1.Hit f11 and open the TASCO | TASCO should display
        //2.Enter Patient Last Name | Last Name should be able to enter in the field
        //3.Enter Patient First Name | First Name should be able to enter in the field
        //4.Enter Patient DOB | DOB should be able to enter in the field
        //5.Select Search | It should redirect to next page
        //6.Select Patient Profile from the menu | It should redirect to PMS
        //7.Verify it is displaying the PMS General Information screen | Should display General Information Screen
        //8.Verify Patient Information is displaying in the mandatory fields of PMS General Information screen. | Should display all mandatory fields
        //9.Verify Service Details button is disabled | Service Details button should be disabled
        userExperienceTestSetScript.serviceDetailsDisabledInClinicalServices(inputData);

        System.out.println("<<<HWPHME2E_586_tc_12_TASCO_PMS_ClinicalServices_ServiceDetails>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the allergy added to allergy grid is disabled for the patient in the Allergy/Medical Conditions
     *  Tab on New PMS when we opened from TASCO machine.
     *
     * JIRA: HWPHME2E-586
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-586")
  /*  @Test(description = "To verify whether the allergy added to allergy grid is disabled for the patient in the Allergy/Medical Conditions" +
            " Tab on New PMS when we opened from TASCO machine.",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_03_389315_TASCO_PMS_GeneralInformation_Screen_LastName"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_586_tc_13_TASCO_PMS_Allergy_Medical_Conditions_Tab(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_586_tc_13_TASCO_PMS_Allergy_Medical_Conditions_Tab<<<");

        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE

        //1.Hit f11 and open the TASCO | TASCO should display
        //2.Enter Patient Last Name | Last Name should be able to enter in the field
        //3.Enter Patient First Name | First Name should be able to enter in the field
        //4.Enter Patient DOB | DOB should be able to enter in the field
        //5.Select Search | It should redirect to next page
        //6.Select Patient Profile from the menu | It should redirect to PMS
        //7.Verify it is displaying the PMS General Information screen | Should display General Information Screen
        //8.Verify Patient Information is displaying in the mandatory fields of PMS General Information screen. | Should display all mandatory fields
        //9.Open Allergy/Medical Condition tab | Should display Allergy/Medical Condition screen
        //10.Verify Allergy added to allergy grid should  be disabled (It should not allow to deactivate the allergy). | Allergy grid should be disabled
        userExperienceTestSetScript.allergyDisabledInAlleryMedicalConditions(inputData);

        System.out.println("<<<HWPHME2E_586_tc_13_TASCO_PMS_Allergy_Medical_Conditions_Tab>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the medical conditions added to medical condition grid is disabled for the patient in the
     * Allergy/Medical Conditions Tab on New PMS when we opened from TASCO machine.
     *
     * JIRA: HWPHME2E-586
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-586")
  /*  @Test(description = "To verify whether the medical conditions added to medical condition grid is disabled for the patient in the " +
            "Allergy/Medical Conditions Tab on New PMS when we opened from TASCO machine.",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_03_389315_TASCO_PMS_GeneralInformation_Screen_LastName"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_586_tc_14_TASCO_PMS_Allergy_Medical_Conditions_Tab(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_586_tc_14_TASCO_PMS_Allergy_Medical_Conditions_Tab<<<");

        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE

        //1.Hit f11 and open the TASCO | TASCO should display
        //2.Enter Patient Last Name | Last Name should be able to enter in the field
        //3.Enter Patient First Name | First Name should be able to enter in the field
        //4.Enter Patient DOB | DOB should be able to enter in the field
        //5.Select Search | It should redirect to next page
        //6.Select Patient Profile from the menu | It should redirect to PMS
        //7.Verify it is displaying the PMS General Information screen | Should display General Information Screen
        //8.Verify Patient Information is displaying in the mandatory fields of PMS General Information screen. | Should display all mandatory fields
        //9.Open Allergy/Medical Condition tab | Should display Allergy/Medical Condition screen
        //10.Verify Medical conditions added to medical condition grid should  be disabled (not able to deactivate). | Medical conditions grid should be disabled
        userExperienceTestSetScript.medicalDisabledInAlleryMedical(inputData);

        //To continue the flow of next test case
        userExperienceTestSetScript.clickExitPMSWithAbondonPopUp(inputData);

        System.out.println("<<<HWPHME2E_586_tc_14_TASCO_PMS_Allergy_Medical_Conditions_Tab>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether fields are disabled on New PMS when we opened HIPAA from TASCO machine.
     *
     * JIRA: HWPHME2E-587
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-587")
    @Test(description = "To verify whether fields are disabled on New PMS when we opened HIPAA from TASCO machine.",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_587_tc_15_TASCO_PMS_HIPAA(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_587_tc_15_TASCO_PMS_HIPAA<<<");
        connexusAppUtils.getStoreId();

        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE

        //1.Hit f11 and open the TASCO | TASCO should display
        //2.Click on HIPAA | It should redirect to Patient Privacy Information
        userExperienceTestSetScript.openHIPAAPage(inputData);

        //3.Enter Patient Last Name | Last Name should be able to enter in the field
        //4.Enter Patient First Name | First Name should be able to enter in the field
        //5.Enter Patient DOB | DOB should be able to enter in the field
        //6.Select Search and it will redirect to next page | Should redirect to Patient information screen
        userExperienceTestSetScript.searchPatientInTasco(inputData);

        //7.Select the patient  | should able to select the patient information
        //8.Click on Patient Profile icon | Should redirect to PMS screen
        userExperienceTestSetScript.patProfileInHIPAA(inputData);

        //9.Verify Last Name, First Name, Middle Name, Birth date,Gender,Weight,Allergy Information grid,Medical Condition Information grid are disable in General Information Screen | Last Name, First Name, Middle Name, Birth date,Gender,Weight,Allergy Information grid,Medical Condition Information grid should be disable in General Information Screen
        userExperienceTestSetScript.lastNameDisabledPMS(inputData);
        userExperienceTestSetScript.firstNameDisabledPMS(inputData);
        userExperienceTestSetScript.dateOfBirthDisabledPMS(inputData);
        userExperienceTestSetScript.genderDisabledPMS(inputData);
        userExperienceTestSetScript.weightDisabledPMS(inputData);
        userExperienceTestSetScript.allergyDisabledInAlleryMedicalConditions(inputData);
        userExperienceTestSetScript.medicalDisabledInAlleryMedical(inputData);

        //10.Verify Other medications button is disabled in Profile/Other screen | Other medications button should be disabled in Profile/Other screen
        userExperienceTestSetScript.otherMedicationsDisabledInProfile(inputData);

        //11.Verify Service Details button is disabled in Clinical Services screen. | Service Details button should be disabled in Clinical Services screen.
        userExperienceTestSetScript.serviceDetailsDisabledInClinicalServices(inputData);

        System.out.println("<<<HWPHME2E_587_tc_15_TASCO_PMS_HIPAA>>>");

        //To continue to next test case flow
        userExperienceTestSetScript.clickExitPMSWithAbondonPopUp(inputData);
        userExperienceTestSetScript.clickExitHIPAA(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether fields are disabled on New PMS when we opened Pseudoephedrine from TASCO machine.
     *
     * JIRA: HWPHME2E-2829
     *
     * Pre-Conditions:
     * 1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
     * 2. 27247 flag should be TRUE
     *
     * Author: Keerthana Jayaraman(vn82865)
     //@Jira(testID = "HWPHME2E-2829")
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether fields are disabled on New PMS when we opened Pseudoephedrine from TASCO machine.",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/userExperienceDataBook.json", sheetName = "userExperienceDataSheet")
    public void HWPHME2E_2829_tc_16_389315_TASCO_PMS_Pseudoephedrine_Restrictions(Map<String, String> inputData) {
        System.out.println(">>>>HWPHME2E_2829_tc_16_389315_TASCO_PMS_Pseudoephedrine_Restrictions<<<");
        connexusAppUtils.getStoreId();
        //Pre-Condition
        //1. Create a new patient, drop an Rx and process the Rx till Pickup Queue.
        //2. 27247 flag should be TRUE
        connexusAppUtils.readAndUpdateFlag("27247", "TRUE");

        //1.Hit f11 and open the TASCO | TASCO should display
        //2.Click on Pseudoephedrine Restrictions | It should redirect to Pseudoephedrine Restrictions screen
        userExperienceTestSetScript.openPseudoephedrine(inputData);

        //3.Enter Patient Last Name | Last Name should be able to enter in the field
        //4.Enter Patient First Name | First Name should be able to enter in the field
        //5.Enter Patient DOB | DOB should be able to enter in the field
        //6.Select Search | Patient profile icon should display
        userExperienceTestSetScript.searchPatientInTasco(inputData);

        //7.Click on Patient Profile | Should redirect to PMS screen
        userExperienceTestSetScript.patientProfileInPseudophedrine(inputData);
        userExperienceTestSetScript.handleControlIdSubstanceForControlledDrugPopup();

        //8.Verify Last Name, First Name, Middle Name, Birth date,Gender,Weight,Allergy Information grid,Medical Condition Information grid are disable in General Information Screen | Last Name, First Name, Middle Name, Birth date,Gender,Weight,Allergy Information grid,Medical Condition Information grid should be disable in General Information Screen
        userExperienceTestSetScript.lastNameDisabledPMS(inputData);
        userExperienceTestSetScript.firstNameDisabledPMS(inputData);
        userExperienceTestSetScript.dateOfBirthDisabledPMS(inputData);
        userExperienceTestSetScript.genderDisabledPMS(inputData);
        userExperienceTestSetScript.weightDisabledPMS(inputData);
        userExperienceTestSetScript.allergyDisabledInAlleryMedicalConditions(inputData);
        userExperienceTestSetScript.medicalDisabledInAlleryMedical(inputData);

        //9.Verify Other medications button is disabled in Profile/Other screen | Other medications button should be disabled in Profile/Other screen
        userExperienceTestSetScript.otherMedicationsDisabledInProfile(inputData);

        //10.Verify Service Details button is disabled in Clinical Services screen. | Service Details button should be disabled in Clinical Services screen.
        userExperienceTestSetScript.serviceDetailsDisabledInClinicalServices(inputData);

        //To continue the flow to next test case
        userExperienceTestSetScript.clickExitPMSWithAbondonPopUp(inputData);
        userExperienceTestSetScript.clickExitHIPAA(inputData);
        userExperienceTestSetScript.clickExitInTasco(inputData);

        System.out.println("<<<>HWPHME2E_2829_tc_16_389315_TASCO_PMS_Pseudoephedrine_Restrictions>>>");
    }
}
