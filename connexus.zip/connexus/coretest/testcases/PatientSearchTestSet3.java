package connexus.coretest.testcases;

import connexus.coretest.testscripts.PatientSearchTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import java.util.Map;

public class PatientSearchTestSet3 {

    PatientSearchTestSetScript patientSearchTestSetScript = new PatientSearchTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils;
    public boolean flagUpdated = false;

    @BeforeClass
    public void performlogin(){
        connexusAppUtils = new ConnexusAppUtils();
        AutomationManager.getInstance().performSleep(10);
        connexusAppUtils.startAppiumServer();
        AutomationManager.getInstance().performSleep(5);

    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Patient search result displayed without middle name when Patient doesn't having Middle name
     * JIRA: HWQEAUTO-6941
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the Patient search result displayed without middle name when Patient doesn't having Middle name",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_397_Patient_Search_Verify_Whether_Patient_Search_Results_Displayed_When_Patient_Does_Not_Have_Middle_Name(Map<String, String> inputData) {

        //Pre-Condition: Check Flag 26849 and set it to TRUE and restart Connexus.
        /*if (connexusAppUtils.readFlagValue("26849").get(0).get("phm_parm_value").toString().trim().equals("FALSE")) {
            patientSearchTestSetScript.closeConnexus();
            connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
        }*/
        flagUpdated = connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
        patientSearchTestSetScript.initializeTestCase(flagUpdated);
        //1. Create a new patient
        patientSearchTestSetScript.createPatientWithPrimaryPhoneNumber(inputData);

        //2. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //3. Search for a Patient which does not have middle name and verify the search results does not show the middle name on Patient Search window
        patientSearchTestSetScript.searchForPatientOnFileAndVerifySearchResults(inputData);

        //4. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Patient does not have middle name is verified on Patient Search window");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the ESC button closes search screen
     * JIRA: HWQEAUTO-6855
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the ESC button closes search screen",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_395_Patient_Search_Verify_Whether_Escape_Button_Closes_Patient_Search(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Verify whether the ESC button closes the Patient search screen
        patientSearchTestSetScript.closePatientSearchWindowsByPressingEscapeButton();

        Reporter.log("ESC button closes the Patient search screen is Verified");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the search history is displayed when user clicks on the search text box
     * JIRA: HWQEAUTO-6861
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //HWPHME2E-396 , Duplicate covered in TC 2452
  /*  @Test(description = "To verify whether the search history is displayed when user clicks on the search text box",
            priority = 33, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = "tc31_Patient_Search_Verify_Whether_Patient_Search_Results_Displayed_When_Patient_Does_Not_Have_Middle_Name")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc33_Patient_Search_Verify_Whether_Search_History_Displayed_In_All_Text_Fields(Map<String, String> inputData) {
        System.out.println(">>>tc33_Patient_Search_Verify_Whether_Search_History_Displayed_In_All_Text_Fields");

        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Verify whether the search history is displayed when user clicks on the search text box
        patientSearchTestSetScript.checkPatientSearchHistoryAndVerifyResults();

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc33_Patient_Search_Verify_Whether_Search_History_Displayed_In_All_Text_Fields");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether No Records Found pop up is displayed when patient not found on Searching with Name and DOB
     * JIRA: HWQEAUTO-13670
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether No Records Found pop up is displayed when patient not found on Searching with Name and DOB",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_398_Patient_Search_Verify_Whether_NoRecordFoundPopUp_Displayed_WhenNoResultsFound(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Verify whether No Records Found pop up is displayed when patient not found on Searching with Name and DOB
        patientSearchTestSetScript.verifyNoRecordsFoundPopUpWhenNoResultsFound(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether No Records Found popup is displayed when no record found on searching with Store and RX number
     * JIRA: HWQEAUTO-13671
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether No Records Found popup is displayed when no record found on searching with Store and RX number",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_399_Patient_Search_Verify_Whether_NoRecordFoundPopUp_Displayed_WhenNoResultsFound_Search_With_StoreNum_RXNum(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Verify whether No Records Found popup is displayed when no record found on searching with Store and RX number
        patientSearchTestSetScript.verifyNoRecordsFoundPopUpWhenNoResultsFoundWithStoreAndRX(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the Patient search result displayed from Search For field
     * JIRA: HWQEAUTO-15266
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the Patient search result displayed from Search For field",
            enabled=false,priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = "HWPHME2E_397_Patient_Search_Verify_Whether_Patient_Search_Results_Displayed_When_Patient_Does_Not_Have_Middle_Name")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_400_Patient_Search_Verify_Whether_Search_Results_Found_With_Name_And_DOB(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Verify whether the Patient search result displayed from Search For field
        patientSearchTestSetScript.searchForPatientOnFileAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Patient search result displayed from Search For field is verified");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the PET Patient details displayed from Search For Field
     * JIRA: HWQEAUTO-15267
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the PET Patient details displayed from Search For Field",enabled = false,
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_401_Patient_Search_Verify_Whether_PET_Patient_Displayed_On_PatientSearchWindow(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Verify whether the PET Patient details displayed from Search For Field
        patientSearchTestSetScript.searchForPatientAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("PET Patient details displayed from Search For Field is verified");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the LIVESTOCK Patient details displayed from Search For field
     * JIRA: HWQEAUTO-15268
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the LIVESTOCK Patient details displayed from Search For field",
            priority = 8, enabled=false, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_402_Patient_Search_Verify_Whether_LIVESTOCK_Patient_Displayed_On_PatientSearchWindow(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Verify whether the LIVESTOCK Patient details displayed from Search For field
        patientSearchTestSetScript.searchForPatientAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("LIVESTOCK Patient details displayed from Search For field is verified");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the pediatric Patient details should be displayed from Search For field
     * JIRA: HWQEAUTO-15269
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the pediatric Patient details should be displayed from Search For field",
            priority = 9, enabled = false, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_403_Patient_Search_Verify_Whether_Pediatric_Patient_Displayed_On_PatientSearchWindow(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Verify whether the pediatric Patient details should be displayed from Search For field
        patientSearchTestSetScript.searchForPatientAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Pediatric Patient details displayed from Search For field is verified");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the search history is displayed when user clicks on the Search For field drop down
     * JIRA: HWQEAUTO-15270
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the search history is displayed when user clicks on the Search For field drop down",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = "HWPHME2E_397_Patient_Search_Verify_Whether_Patient_Search_Results_Displayed_When_Patient_Does_Not_Have_Middle_Name")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_404_Patient_Search_Verify_Whether_Search_History_Displayed_In_Name_Field(Map<String, String> inputData) {

        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Verify whether the search history is displayed when user clicks on the search text box
        patientSearchTestSetScript.verifyPatientNameSearchHistory(inputData);

        //3. Press ESC button  to close the Patient search screen
        patientSearchTestSetScript.closePatientSearchWindowsByPressingEscapeButton();

        Reporter.log("Search history is displayed when user clicks on the search text box is verified");
    }

}
