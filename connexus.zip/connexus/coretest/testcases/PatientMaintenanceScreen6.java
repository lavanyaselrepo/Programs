package connexus.coretest.testcases;

import connexus.coretest.testscripts.PatientMaintenanceScreenScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.datamodels.connexus.PatientProfileModel;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreen6 {

    PatientMaintenanceScreenScript patientMaintenanceScreenScript = new PatientMaintenanceScreenScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils;
    boolean relaunchConnexus = false;

    @BeforeClass
    public void performlogin(){
        connexusAppUtils = new ConnexusAppUtils();
        AutomationManager.getInstance().performSleep(5);
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }
    /**----------------------------------------------------------------------------------------------------------
     * Test Description:Validate Creation of PET Patient Profile
     * JIRA: HWCNXCLD-10264
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Creation of PET Patient Profile",
            enabled = true, priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintenanceScreenDataBook.json", sheetName = "PatientMaintenance")
    public void HWPHME2E_1869_Validate_Creation_of_PET_Patient_Profile(Map<String, String> inputData) {

        patientMaintenanceScreenScript.initializeTestCase(relaunchConnexus);
        //1. Validate Creation of PET Patient Profile
        patientMaintenanceScreenScript.createNewPatient(inputData,0, PatientProfileModel.PatientType.PET);

        // Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientMaintenanceScreenScript.openPatientSearchWindow();

        //2. Search for a Patient and verify all the search results on the results grid view on Patient Search window
        patientMaintenanceScreenScript.verifyAllSearchResultsOnSearchResultsGrid();
        Reporter.log("Creation of Pet Patient Profile is Verified");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify the Patient search results from Search menu
     * JIRA: HWQEAUTO-8715
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Creation of LIVESTOCK Patient Profile",
            enabled = true,  priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintenanceScreenDataBook.json", sheetName = "PatientMaintenance")
    public void HWPHME2E_1870_Validate_Creation_of_LIVESTOCK_Patient_Profile(Map<String, String> inputData) {

        patientMaintenanceScreenScript.initializeTestCase(relaunchConnexus);
        //  Creation of LIVESTOCK Patient Profile
        patientMaintenanceScreenScript.createLiveStockPatientProfile(inputData);

        patientMaintenanceScreenScript.closePatientSearchWindowByClickingOnCloseButton();

        // Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientMaintenanceScreenScript.openPatientSearchWindow();

        // Search for a Patient and verify all the search results on the results grid view on Patient Search window
        patientMaintenanceScreenScript.verifyAllSearchResultsOnSearchResultsGrid();

        Reporter.log("Creation of LIVESTOCK Patient Profile is Verified");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the empty contact number displayed on result grid when phone1 and Phone 2 is not exist but messaging number is exist at patient profile
     * JIRA: HWQEAUTO-8617
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Making the Patient Profile Deceased and Activating again",
            enabled = true,  priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintenanceScreenDataBook.json", sheetName = "PatientMaintenance")
    public void HWPHME2E_1871_Validate_Making_Patient_Profile_Deceased_and_Activating_again(Map<String, String> inputData) {

        patientMaintenanceScreenScript.initializeTestCase(relaunchConnexus);
        //Create Patient
        patientMaintenanceScreenScript.createNewPatientforDeceased(inputData);

        //Complete DropOff
        patientMaintenanceScreenScript.performDropOff(Priority.Critical);

        //Complete Input
        patientMaintenanceScreenScript.performInput(inputData);

        // Checking Patient Status
        patientMaintenanceScreenScript.verifyPatientStatus(inputData);

        // Make Patient Status as Deceased
        patientMaintenanceScreenScript.makePatientStatusAsDeceased();

        // Make Patient Status as Active
        patientMaintenanceScreenScript.makeStatusActive();

        Reporter.log("Making the Patient Profile Deceased and Activating again is Validated");
    }
}
