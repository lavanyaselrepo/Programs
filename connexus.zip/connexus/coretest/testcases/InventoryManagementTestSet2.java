package connexus.coretest.testcases;

import connexus.coretest.testscripts.InventoryManagementTestSetScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class InventoryManagementTestSet2 {

    InventoryManagementTestSetScripts inventoryManagementTestSetScripts = new InventoryManagementTestSetScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();

    @BeforeClass
    public void performlogin() {
        inventoryManagementTestSetScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To Verify if the new on hand qty changed in Cycle Count Report for any CII drug when selecting Haz waste as the
     * Adjustment reason pop up is getting updated in the FE and BE.
     *
     * TFS ID: 277891
     *
     * Pre-Conditions:
     * 1. 27107 Flag set tp <past date> and 27153 set to TRUE
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To Verify if the new on hand qty changed in Cycle Count Report for any CII drug when selecting Haz waste as the Adjustment " +
            "reason pop up is getting updated in the FE and BE.",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_15_277891_Return_to_Genco_or_Haz_or_Key_in_222_form(Map<String, String> inputData) {
        System.out.println(">>>tc_15_277891_Return_to_Genco_or_Haz_or_Key_in_222_form<<<");

        //1.Pre-Condition
        if(connexusAppUtils.readAndUpdateFlag("27153","TRUE") || connexusAppUtils.readAndUpdateFlag("27107","2000-01-01")){
            tearDown();
            inventoryManagementTestSetScripts = new InventoryManagementTestSetScripts();
            inventoryManagementTestSetScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        }

        //2.Login to connexus | Pharmacist should be able to login
        //3.Go to Report -> Inventory Report -> Select Cycle count report | Cycle count report should get opened.
        inventoryManagementTestSetScripts.openCycleCountReport();

        //4.Select the NDC and Enter the onhand qty in enter quantity field | Pharmacist should be able to enter the onhand quantity.
        //5.Press tab and click on Yes button in Double check point | CII Adjustment Reason pop up should be displayed.
        inventoryManagementTestSetScripts.changeOnHandDrugQtyOnReports();

        //6.Select Haz Waste as a adjustment reason | Pharmacist should be able to select the reason.
        //7.Click on Continue button | Pharmacist should be able click on continue button.
        inventoryManagementTestSetScripts.selectHazardousWaste();

        //8.Now verify whether DEA 222 Form# pop up is displaying when Pharmacist is selecting the reason Haz Waste while updating the onhand quantity | DEA 222 Form# pop up should be displayed when pharmacist select Return to Genco as a reason while updating the onhand quantity for CII Drug.
        //9.Enter valid data in the first and second text box | Valid Entry of data should be accepted in both the text fields and Accept button should be enabled.
        //10.Click on Accept Button |  DEA Form Pop-up Should disappear.
        inventoryManagementTestSetScripts.verifyDEA222Form(inputData);
        inventoryManagementTestSetScripts.processCycleCount();

        //11.Verify at the BE if the on hand qty is updated as required using the below query:
        //select * from pharmacy_offering:pharmacy_item  where ndc_nbr=<<>>
        //select * from pharmacy_offering:phm_item_inv_adjmt_log where mds_fam_id=<<>>  order by 1 desc | The new on hand qty should be displayed in this table.
        inventoryManagementTestSetScripts.verifyProcessedDrugQty();

        System.out.println("<<<tc_15_277891_Return_to_Genco_or_Haz_or_Key_in_222_form>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Verify the state of Accept and cancel button in DEA 222 Form# pop up.
     *
     * TFS ID: 271649
     *
     * Pre-Conditions:
     * 1. 27107 Flag set to <past date> and 27153 set to TRUE.
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify the state of Accept and cancel button in DEA 222 Form# pop up.",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_16_271649_Return_to_Genco_or_Haz_or_Key_in_222_form(Map<String, String> inputData) {
        System.out.println(">>>tc_16_271649_Return_to_Genco_or_Haz_or_Key_in_222_form<<<");

        //1.Pre-Condition:
        if(connexusAppUtils.readAndUpdateFlag("27153","TRUE") || connexusAppUtils.readAndUpdateFlag("27107","2000-01-01")){
            tearDown();
            inventoryManagementTestSetScripts = new InventoryManagementTestSetScripts();
            inventoryManagementTestSetScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        }

        //2.Login to connexus | Pharmacist should be able to login.
        //3.Open IMS screen and enter CII Drug and click on search button | NDC should be displayed.
        inventoryManagementTestSetScripts.searchCIIDrugOnIMSScreen(inputData);

        //4.Change the onhand quantity of the NDC | Pharmacist should be able to enter the onhand quantity.
        //5.Click on Accept button | CII Adjustment Reason pop up should be displayed.
        inventoryManagementTestSetScripts.changeOnHandDrugQtyOnIMS();

        //6.Select Return to Genco/Haz Waste as a adjustment reason | Pharmacist should be able to select the reason.
        //7.Click on Continue button | DEA 222 Form# pop up should be displayed.
        inventoryManagementTestSetScripts.selectHazardousWaste();

        //8.Verify the option available in DEA 222 Form# pop up | In order to key in 222 form #, user should have the below options:
        //a.There should be text field named 'DEA 222 form#'
        //b.There should be 2nd text field named 'Retype DEA 222 form#' available to re-enter the 222 form #.
        //C.Accept and Cancel button should be displayed.
        //9.Verify whether 2nd text field to retype 222 form# is in deactivated state or not | The 2nd text field to retype 222 form# should be deactivated initially when the option (pop up) for 222 form# entry opens up.
        //10.Now verify the state of Accept and Cancel button | Accept button should be in deactivated state initially and Cancel button should be in Active state when the option (pop up) for 222 form# entry opens up.
        inventoryManagementTestSetScripts.validateDEA222FormNumberPopUp(inputData);

        System.out.println("<<<tc_16_271649_Return_to_Genco_or_Haz_or_Key_in_222_form>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify the state of second test box field when Pharmacist enters 8 digit alphanumeric value in first text box of DEA 222 Form.
     *
     * TFS ID: 271654
     *
     * Pre-Conditions:
     * 1. 27107 Flag set to <past date> and 27153 set to TRUE.
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify the state of second test box field when Pharmacist enters 8 digit alphanumeric value in first text box of DEA 222 Form.",
            priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_16_271649_Return_to_Genco_or_Haz_or_Key_in_222_form"})
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/inventoryManagementDataBook.json", sheetName = "inventoryManagementDataSheet")
    public void tc_17_271654_Return_to_Genco_or_Haz_or_222_form_validations_for_1st_text_box(Map<String, String> inputData) {
        System.out.println(">>>tc_17_271654_Return_to_Genco_or_Haz_or_222_form_validations_for_1st_text_box<<<");

        //1.Pre-Condition
        //'tc_17_271654_Return_to_Genco_or_Haz_or_222_form_validations_for_1st_text_box depends' on 'tc_16_271649_Return_to_Genco_or_Haz_or_Key_in_222_form'
        // preconditon is applied in previous test case

        //2.Login to connexus | Pharmacist should be able to login.
        //3.Open IMS screen and enter CII Drug and click on search button | NDC should be displayed.
        //4.Change the onhand quantity of the NDC | Pharmacist should be able to enter the onhand quantity.
        //5.Click on Accept button | CII Adjustment Reason pop up should be displayed.

        //6.Select Return to Genco as a adjustment reason | Pharmacist should be able to select the reason.
        //7.Click on Continue button | DEA 222 Form# pop up should be displayed.
        inventoryManagementTestSetScripts.selectHazardousWaste();

        //8.Enter 8 digit alphanumeric in the first text box field, press tab and verify the state of second text box | The second textbox should remain disabled until the first textbox reaches 9 characters in length
        inventoryManagementTestSetScripts.validateTextBox1For8CharLenInDEA222PopUp(inputData);

        //9.Enter 9 digit  alphanumeric in the first text box field, press tab and verify the state of second text box | When pharmacist clicked or tab to the second textbox from the first
        //a.The first textbox text should become starred out.
        //b.Second text box should get enabled.
        //c.The second textbox characters are visible as you type
        inventoryManagementTestSetScripts.validateTextBox1For9CharLenInDEA222PopUp(inputData);

        //10.Now again drop one digit from first text box and verify the state of second text box in 222 DEA form | Textbox2 should be in disabled state anytime when the textbox1's length drops below 9 characters in length.
        inventoryManagementTestSetScripts.validateTextBox1For8CharLenInDEA222PopUp(inputData);

        //To continue the flow
        inventoryManagementTestSetScripts.closeDEA222PopUpWithValidDeaNumber(inputData);

        System.out.println("<<<tc_17_271654_Return_to_Genco_or_Haz_or_222_form_validations_for_1st_text_box>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: To verify whether Accept button is getting enable or not when pharmacist select Liquid loss check box in DEA 222 from# pop for CII Drug.
     *
     * TFS ID : 275857
     *
     * Pre-Conditions:
     * 1. 27107 Flag set to <past date> and 27153 set to TRUE.
     * 2. Cycle count row should be there in Cycle count Report with CII Drug.
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether Accept button is getting enable or not when pharmacist select Liquid loss check box in DEA 222 from# pop for CII Drug",
            priority = 18, dependsOnMethods = {"tc_17_271654_Return_to_Genco_or_Haz_or_222_form_validations_for_1st_text_box"})
    public void tc_18_275857_Return_to_Genco_or_Haz_Liquid_Loss_checkbox_Accept_button_validation() {
        System.out.println(">>>tc_18_275857_Return_to_Genco_or_Haz_Liquid_Loss_checkbox_Accept_button_validation<<<");

        //1.Pre-Condition
        // 'tc_18_275857_Return_to_Genco_or_Haz_Liquid_Loss_checkbox_Accept_button_validation' depends on 'tc_17_271654_Return_to_Genco_or_Haz_or_222_form_validations_for_1st_text_box'
        // preconditon is applied in previous test case

        //2.Login to connexus | Pharmacist should be able to login.
        //3.Go to IMS and search for CII Drug type as liquid | CII Drug with liquid type should be there in the store.
        //4.Change the onhand quantity of the NDC | Pharmacist should be able to enter the onhand quantity.

        //5.Select reason as Hazardous Waste and click on Continue button | DEA 222 pop up should be displayed.
        inventoryManagementTestSetScripts.selectHazardousWaste();

        //6.Select liquid loss check box in DEA 222 form# pop up | Check box should get selected.And DEA from# text field should get disabled.
        inventoryManagementTestSetScripts.checkLiquidLoss();
        inventoryManagementTestSetScripts.validateLiquidLossCheckBox();
        inventoryManagementTestSetScripts.validateTextBox1OnDeaPopUp();

        //7.Now verify whether Accept button is getting enable or not | Accept button should get enabled and a message should be displayed as "** DEA 222# is not required for Liquid Loss CII's."
        inventoryManagementTestSetScripts.validateAcceptButtonOnDeaPopUp();
        inventoryManagementTestSetScripts.validateLiquidLossMessage();

        //8.Uncheck the Liquid Loss check box and verify the state of Accept button in DEA 222 form# pop up | Accept button should be in disabled state and DEA form# text field should be in enabled state.
        inventoryManagementTestSetScripts.checkLiquidLoss();
        inventoryManagementTestSetScripts.validateAcceptButtonOnDeaPopUp();

        System.out.println("<<<tc_18_275857_Return_to_Genco_or_Haz_Liquid_Loss_checkbox_Accept_button_validation>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify the verbiage displaying when Pharmacist select Liquid Loss check box in DEA 222 form# pop for CII Drug in IMS.
     *
     * TFS ID: 275858
     *
     * Pre-Conditions:
     * 1. 27107 Flag set to <past date> and 27153 set to TRUE.
     * 2. Cycle count row should be there in Cycle count Report with CII Drug.
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify the verbiage displaying when Pharmacist select Liquid Loss check box in DEA 222 form# pop for CII Drug in IMS",
            priority = 19,dependsOnMethods = {"tc_18_275857_Return_to_Genco_or_Haz_Liquid_Loss_checkbox_Accept_button_validation"})
    public void tc_19_275858_Return_to_Genco_or_Haz_Liquid_Loss_checkbox_Verbiage_validation() {
        System.out.println(">>>tc_19_275858_Return_to_Genco_or_Haz_Liquid_Loss_checkbox_Verbiage_validation<<<");

        //1.Pre-Condition
        // 'tc_19_275858_Return_to_Genco_or_Haz_Liquid_Loss_checkbox_Verbiage_validation' depends on 'tc_18_275857_Return_to_Genco_or_Haz_Liquid_Loss_checkbox_Accept_button_validation'
        // preconditon is applied in previous test case

        //2.Login to connexus | Pharmacist should be able to login.
        //3.Go to IMS and search for CII Drug type as liquid | CII Drug with liquid type should be there in the store.
        //4.Change the onhand quantity of the NDC | Pharmacist should be able to enter the onhand quantity.
        //5.Select reason as Hazardous Waste and click on Continue button | DEA 222 pop up should be displayed.
        //6.Select liquid loss check box in DEA 222 form# pop up | Check box should get selected.And DEA from# text field should get disabled.
        //7.Now verify whether Accept button is getting enable or not | Accept button should get enabled and a message should be displayed as "** DEA 222# is not required for Liquid Loss CII's."
        //8.Verify the verbiage displaying when Pharmacist select Liquid Loss check box | Below verbiage should be displayed:
        //"** DEA 222# is not required for Liquid Loss CII's
        // Acceptance Criteria is same as tc 17 and validated in tc_17_275857_Return_to_Genco_or_Haz_Liquid_Loss_checkbox_Accept_button_validation

        //to continue the flow
        inventoryManagementTestSetScripts.checkLiquidLoss();
        inventoryManagementTestSetScripts.clickAcceptButtonOnDeaPopUp();
        inventoryManagementTestSetScripts.acceptProductSearch();

        System.out.println("<<<tc_19_275858_Return_to_Genco_or_Haz_Liquid_Loss_checkbox_Verbiage_validation>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify whether For a liquid loss CII, there is no 222 form # in CII Digital Logbook report as there will be nothing to ship back to Haz waste. (Report Validation).
     *
     * TFS ID: 279895
     *
     * Pre-Conditions:
     * 1. 27107 Flag set to <past date> and 27153 set to TRUE.
     * 2. Row should be there in Cycle count Report with CII Drug.
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify whether For a liquid loss CII, there is no 222 form # in CII Digital Logbook report as there will be nothing to ship back to Haz waste. (Report Validation)",
            priority = 20)
    public void tc_20_279895_Return_to_Genco_or_Haz_or_Liquid_Loss_check_box_or_Verbiage_validation() {
        System.out.println(">>>tc_20_279895_Return_to_Genco_or_Haz_or_Liquid_Loss_check_box_or_Verbiage_validation<<<");

        //1.Pre-Condition
        if(connexusAppUtils.readAndUpdateFlag("27153","TRUE") || connexusAppUtils.readAndUpdateFlag("27107","2000-01-01")){
            tearDown();
            inventoryManagementTestSetScripts = new InventoryManagementTestSetScripts();
            inventoryManagementTestSetScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        }

        //2.Login to connexus | Pharmacist should be able to login.
        //3.Go to cycle count report-> select NDC | Pharmacist should be able to select the ndc.
        inventoryManagementTestSetScripts.openCycleCountReport();
        inventoryManagementTestSetScripts.selectNdcOnCycleCountReport();

        //4.Change the onhand qty of the NDC and click on Accept button | Double check point pop up should be displayed.
        inventoryManagementTestSetScripts.changeOnHandDrugQtyOnReports();

        //5.Select reason as Haz waste and click on Continue button | DEA 222 pop up should be displayed.
        inventoryManagementTestSetScripts.selectHazardousWaste();

        //6.Select liquid loss check box in DEA 222 form# pop up | Check box should get selected.And Both DEA from# text field should get disabled.
        inventoryManagementTestSetScripts.checkLiquidLoss();
        inventoryManagementTestSetScripts.validateLiquidLossCheckBox();
        inventoryManagementTestSetScripts.validateTextBox1OnDeaPopUp();
        inventoryManagementTestSetScripts.validateTextBox2OnDeaPopup();

        //7.Now click on Accept button | Data should get saved to DB when user clicked on Accept button in DEA 222 form# pop up for CII Drug and the pop up should get closed.
        inventoryManagementTestSetScripts.validateAcceptButtonOnDeaPopUp();
        inventoryManagementTestSetScripts.clickAcceptButtonOnDeaPopUp();
        String ndcNbr = inventoryManagementTestSetScripts.processCycleCountInReport();

        //8.Now Go to Report -> CII Inventory Report -> CII Report -> CII Digital Logbook report | CII Logbook report should get opened.
        //9.Enter the NDC number and click on search button | NDC detail should be displayed in the table
        //10.Verify whether DEA 222 form# is displaying or not in the report | DEA 222 form# number should not be displayed in the report as there will be nothing to ship back to Haz waste.
        inventoryManagementTestSetScripts.openCIIDigitalLogBookAndVerifyDrug(ndcNbr);
        inventoryManagementTestSetScripts.verifyDEA222FormInCIIDigitalLogBook(ndcNbr);

        //11.And verify whether inventory adjustment is logged for selected reason in the database or not | Inventory adjusted should be logged in "adjmt table"
        inventoryManagementTestSetScripts.validateAdjustmentReasonOnDB();

        System.out.println("<<<tc_20_279895_Return_to_Genco_or_Haz_or_Liquid_Loss_check_box_or_Verbiage_validation>>>");
    }
}
