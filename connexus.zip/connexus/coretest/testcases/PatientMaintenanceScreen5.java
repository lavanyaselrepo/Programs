package connexus.coretest.testcases;

import connexus.coretest.testscripts.PatientMaintenanceScreenScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreen5 {

    PatientMaintenanceScreenScript patientMaintenanceScreenScript = new PatientMaintenanceScreenScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils;
    boolean relaunchConnexus = false;

    @BeforeClass
    public void performlogin(){
        connexusAppUtils = new ConnexusAppUtils();
        AutomationManager.getInstance().performSleep(5);
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify the Patient Search results on clicking Search Now button in Patient search screen
     * JIRA: HWCNXCLD-10264
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate adding only Alternate Phone Number Types to the Patient Profile ",
            enabled = true, priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintenanceScreenDataBook.json", sheetName = "PatientMaintenance")
    public void HWPHME2E_2093_Adding_Alternate_Phone_Number_Types_to_Patient(Map<String, String> inputData) {

        patientMaintenanceScreenScript.initializeTestCase(relaunchConnexus);
        // Create a new patient with Messaging Number only (without Primary and Alternate numbers)
        patientMaintenanceScreenScript.createPatientWithAlternateNumberOnly(inputData);

        // Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientMaintenanceScreenScript.openPatientSearchWindow();

        // Search for the Patient and verify whether the Phone Number field is empty
        patientMaintenanceScreenScript.searchForPatientAndVerifyAlternateNumber(inputData);

        // Click on Close button to close the Patient Search window
        patientMaintenanceScreenScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Adding only Alternate Phone Number Types to the Patient Profile is Verified");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the empty contact number displayed on result grid when phone1 and Phone 2 is not exist but messaging number is exist at patient profile
     * JIRA: HWQEAUTO-8617
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate adding all Phone Number Types to the Patient Profile",
            enabled = true,  priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintenanceScreenDataBook.json", sheetName = "PatientMaintenance")
    public void HWPHME2E_2091_Validate_adding_all_Phone_Number_Types_to_Patient(Map<String, String> inputData) {

        patientMaintenanceScreenScript.initializeTestCase(relaunchConnexus);
        // Create Patient with All Numbers
        patientMaintenanceScreenScript.createPatientWithAllNumbers(inputData);

        // Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientMaintenanceScreenScript.openPatientSearchWindow();

        // Search for a Patient and verify all the search results on the results grid view on Patient Search window
        patientMaintenanceScreenScript.verifyAllSearchResultsOnSearchResultsGrid();

        // Click on Close button to close the Patient Search window
        patientMaintenanceScreenScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Validated adding all Phone Number Types to the Patient Profile.");
    }

    @Test(description = "Validate deleting all Phone Number Types to the Patient Profile",
            enabled = true,  priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintenanceScreenDataBook.json", sheetName = "PatientMaintenance")
    public void HWPHME2E_2092_Validate_deleting_Phone_Number_Types_to_Patient(Map<String, String> inputData) {

        patientMaintenanceScreenScript.initializeTestCase(relaunchConnexus);
        // Create Patient with All Number
        patientMaintenanceScreenScript.createPatientWithAllNumbers(inputData);

        // Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientMaintenanceScreenScript.openPatientSearchWindowfordelContacts(inputData);

        // Search for a Patient and verify all the search results on the results grid view on Patient Search window
        patientMaintenanceScreenScript.deleteAllNumbersFromContacts();
        Reporter.log("Deleting all Phone Number Types to the Patient Profile is Verified");
    }
}
