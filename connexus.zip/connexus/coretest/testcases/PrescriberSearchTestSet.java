package connexus.coretest.testcases;

import connexus.coretest.testscripts.PrescriberSearchTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataProvider;
import org.openjdk.tools.sjavac.Log;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PrescriberSearchTestSet {

    PrescriberSearchTestSetScript prescriberSearchTestSetScript = new PrescriberSearchTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils;
    boolean flagUpdated = false;

    @BeforeClass
    public void performlogin(){
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.startAppiumServer();
        prescriberSearchTestSetScript.loginConnexus();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    public void updateFlags() {
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32050", "TRUE");
        flagUpdated =connexusAppUtils.readAndUpdateFlag("7118", "TRUE");
    }
    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether "Invalid Phone Number Format" popup is displayed on entering alphabets in Phone field and Search
     * JIRA: HWPHME2E-416
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether 'Invalid Phone Number Format' popup is displayed on entering alphabets in Phone field and Search",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_416_Verify_Whether_Invalid_Phone_Number_Format_Popup_Displayed_On_Entering_Alphabets_In_Phone_Field(Map<String, String> inputData) {
        System.out.println(">>>tc02_Verify_Whether_Invalid_Phone_Number_Format_Popup_Displayed_On_Entering_Alphabets_In_Phone_Field<<<");
        connexusAppUtils.getStoreId();
        prescriberSearchTestSetScript.initializeTestCase(false);
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Enter an Invalid Number in Phone field on Prescriber Search window and verify whether 'Invalid Number Format' popup displayed
        prescriberSearchTestSetScript.invalidPhoneNumberVerification(inputData);

        //3. Click on Close button to close the Prescriber Search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc02_Verify_Whether_Invalid_Phone_Number_Format_Popup_Displayed_On_Entering_Alphabets_In_Phone_Field>>>");
    }


    /**----------------------------------------------------------------------------------------------------------
     * Test Description: To verify whether user able to select Prescriber who doesn't have DEA for normal drugs
     * JIRA: HWPHME2E-406
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     *----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether user able to select Prescriber who doesn't have DEA for normal drugs",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_406_Verify_Whether_User_Able_To_Select_A_Prescriber_Without_DEA(Map<String, String> inputData) {
        System.out.println(">>>tc14_Verify_Whether_User_Able_To_Select_A_Prescriber_Without_DEA<<<");

        connexusAppUtils.getStoreId();
        prescriberSearchTestSetScript.initializeTestCase(false);
        prescriberSearchTestSetScript.createNewPatient(inputData);
        //1. Perform Drop-Off for previously created Patient
        prescriberSearchTestSetScript.performDropOff(Priority.Critical);

        //2. Verify whether user able to select Prescriber who doesn't have DEA for normal drugs
        prescriberSearchTestSetScript.verifyPrescriberWithoutDEAForNonControlledDrugs(inputData);

        //3. Search for the Patient on Order Search Window and verify that Prescriber details are matched
        prescriberSearchTestSetScript.searchForOrderAndVerifyPrescriberDetails(inputData);

        System.out.println("<<<tc14_Verify_Whether_User_Able_To_Select_A_Prescriber_Without_DEA>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: To verify whether DEA expired pop up is displayed on selecting the Prescriber with Expired DEA for Controlled Drug
     * JIRA: HWPHME2E-405
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     *----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether DEA expired pop up is displayed on selecting the Prescriber with Expired DEA for Controlled Drug",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true, dependsOnMethods = "HWPHME2E_406_Verify_Whether_User_Able_To_Select_A_Prescriber_Without_DEA")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_405_Verify_Whether_DEA_Expired_PopUp_Displayed_For_Controlled_Drug(Map<String, String> inputData) {
        System.out.println(">>>tc15_Verify_Whether_DEA_Expired_PopUp_Displayed_For_Controlled_Drug<<<");
        connexusAppUtils.getStoreId();

        prescriberSearchTestSetScript.initializeTestCase(false);
        //1. Perform Drop-Off for previously created Patient
        prescriberSearchTestSetScript.performDropOff(Priority.Critical);

        //2. Verify whether DEA expired pop up is displayed on selecting the Prescriber with Expired DEA for Controlled Drug
        prescriberSearchTestSetScript.verifyPrescriberWithoutDEAForControlledDrugs(inputData);

        System.out.println("<<<tc15_Verify_Whether_DEA_Expired_PopUp_Displayed_For_Controlled_Drug>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: To Verify_Values_in_State_Dropdown
     * JIRA: HWPHME2E-1845
     *
     * Pre-Conditions:
     * 1. Flag 32050 should be set to TRUE
     * For middle name to be included in search ; degree drop down and state drop down to appear in search criteria
     * 2. flag 7118 should be set to TRUE
     * 3.User is logged into Connexus
     *
     * Author: Lavanya(vn575up)
     *----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1845")
    @Test(description = "To Verify_Values_in_State_Dropdown", priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1845_tc16_Verify_Values_in_State_Dropdown(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_1845_tc16_Verify_Values_in_State_Dropdown<<<");
        connexusAppUtils.getStoreId();
        updateFlags();
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.initializeTestCase(flagUpdated);
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2.Search for the prescriber with Partial name and verify that Prescriber Record Displayed
        prescriberSearchTestSetScript.enterPrescriberWithPartialName(inputData);

        //3. Click on State drop down and validate the values in state dropdown list
        prescriberSearchTestSetScript.verifySearchStateDropdown(inputData);

        System.out.println("<<<HWPHME2E_1845_tc16_Verify_Values_in_State_Dropdown>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: To Verify the values in degree dropdown
     * JIRA: HWPHME2E-1846
     *
     * Pre-Conditions:
     * 1. Flag 32050 should be set to TRUE
     * For middle name to be included in search ; degree drop down and state drop down to appear in search criteria
     * 2. flag 7118 should be set to TRUE
     * 3.User is logged into Connexus
     *
     * Author: Lavanya(vn575up)
     *----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1846")
    @Test(description = "To Verify the values in degree dropdown", priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1846_tc17_Verify_Values_in_Degree_Dropdown(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_1846_tc17_Verify_Values_in_Degree_Dropdown<<<");
        connexusAppUtils.getStoreId();
        updateFlags();
        prescriberSearchTestSetScript.initializeTestCase(flagUpdated);
        //Below step1 and step2 - validating in tc_16 and continuing the flow
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        //prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2.Search for the prescriber with Partial name and verify that Prescriber Record Displayed
        //prescriberSearchTestSetScript.enterPrescriberWithPartialName(inputData);

        //3. Click on Degree drop down and validate the values in degree dropdown list
        prescriberSearchTestSetScript.verifySearchDegreeDropdown(inputData);

        System.out.println("<<<HWPHME2E_1846_tc17_Verify_Values_in_Degree_Dropdown>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: To Validate the inclusion of temp users in the search result set
     * JIRA: HWPHME2E-1847
     *
     * Pre-Conditions:
     * 1. Flag 32050 should be set to TRUE
     * For middle name to be included in search ; degree drop down and state drop down to appear in search criteria
     * 2. flag 7118 should be set to TRUE
     * 3.User is logged into Connexus
     *
     * Author: Lavanya(vn575up)
     *----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1847")
    @Test(description = "To Verify the values in degree dropdown", priority = 18, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1847_tc18_Validate_the_inclusion_of_temp_users_in_search_result_set(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_1847_tc18_Validate_the_inclusion_of_temp_users_in_search_result_set<<<");
        connexusAppUtils.getStoreId();
        prescriberSearchTestSetScript.initializeTestCase(false);
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2.Enter the created prescriber LN, FN and MN name with Partially and check the count
        prescriberSearchTestSetScript.enterPrescriberWithPartialName(inputData);

        //3. Create New Prescriber from Prescriber Maintenance Screen
        prescriberSearchTestSetScript.createNewPrescriber(inputData);

        //4.Open Prescriber search from same box and enter the created prescriber name and include MN with Partially
        prescriberSearchTestSetScript.searchPrescriberWithPartialName(inputData);

        //5. Click on Close button to close the Prescriber Search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();

        //6.Open Prescriber search from different box and enter the created prescriber LN, FN Partially
        Log.info("Test step involves functionalities in store A and store B, so its complicate to automate");

        System.out.println("<<<HWPHME2E_1847_tc18_Validate_the_inclusion_of_temp_users_in_search_result_set>>>");
    }
    /**----------------------------------------------------------------------------------------------------------
     Test Description: Verify the search functionality when value is provided in any of the fields -
     Name, NPI, DEA#, Phone, Fax and Search Now button clicked when there are no results.
     * JIRA: HWPHME2E-1833
     * Pre-Conditions:
     * select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 32050;
     * For middle name to be included in search ; degree drop down and state drop down to appear in search criteria , flag 7118 should be set to TRUE
     * select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 7118;
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "tc19_No_Results_search_functionality_with_fields_Name_NPI_DEA_Phone_Fax",
            priority = 19, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1833_No_Results_search_functionality_with_fields_Name_NPI_DEA_Phone_Fax(Map<String, String> inputData) {
        Log.info(">>>HWPHME2E_1833_No_Results_search_functionality_with_fields_Name_NPI_DEA_Phone_Fax<<<");
        connexusAppUtils.getStoreId();
        prescriberSearchTestSetScript.initializeTestCase(false);

        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Search for a Prescriber and verify the search results on Prescriber Search window
        prescriberSearchTestSetScript.verifyNoSearchResultsWithSingleInput(inputData);

        Log.info("<<<HWPHME2E_1833_No_Results_search_functionality_with_fields_Name_NPI_DEA_Phone_Fax>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:Verify the search functionality when value is provided in 2 or more fields -
     * Name, NPI, DEA#, Phone, Fax, Degree, State and Search Now button clicked when there are no results.
     * JIRA: HWPHME2E-1834
     *
     * Pre-Conditions:
     * 1.Flag 32050 should be set to TRUE
     * 2.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 32050;
     * 3.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 7118;
     * Launch Connexus and login with valid credentials.
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "tc20_Verify_No_Results_provided_two_or_more_fields_Name_NPI_DEA_Phone_Fax_Degree_State",
            priority = 20, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1834_Verify_No_Results_provided_two_or_more_fields_Name_NPI_DEA_Phone_Fax_Degree_State(Map<String, String> inputData) {
        Log.info(">>>HWPHME2E_1834_Verify_No_Results_provided_two_or_more_fields_Name_NPI_DEA_Phone_Fax_Degree_State<<<");
        connexusAppUtils.getStoreId();
        prescriberSearchTestSetScript.initializeTestCase(false);
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Search for a Prescriber and verify the search results on Prescriber Search window
        prescriberSearchTestSetScript.verifyNoSearchResultsforMultipleInput(inputData);

        Log.info("<<<HWPHME2E_1834_Verify_No_Results_provided_two_or_more_fields_Name_NPI_DEA_Phone_Fax_Degree_State>>>");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:Verify the search functionality when value is provided in 2 or more fields- Name, NPI, DEA#,
     * Phone, Fax, Degree, State and Search Now button clicked when there are less than 100 results.
     * JIRA: HWPHME2E-1835
     *
     * Pre-Conditions:
     * 1.UFlag 32050 should be set to TRUE
     * 2.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 32050;
     * 3.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 7118;
     * Launch Connexus and login with valid credentials.
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "Verify the search Result  with less than 100 records",
            priority = 21, dataProviderClass = DataProvider.class, enabled = false, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1835_search_result_less_than_100_records_with_multiple_input(Map<String, String> inputData) {
        Log.info(">>>HWPHME2E_1835_search_result_less_than_100_records_with_multiple_input<<<");
        connexusAppUtils.getStoreId();
        updateFlags();
        prescriberSearchTestSetScript.initializeTestCase(flagUpdated);
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Verify search result with less than 100 records
        prescriberSearchTestSetScript.verifySearchResultGridRecordsTextwithMultipleInput(inputData);

        //3. Close search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();
        Log.info("HWPHME2E_1835_search_result_less_than_100_records_with_multiple_input");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:Verify the search functionality when value is provided in 2 or more fields -
     * Name, NPI, DEA#, Phone, Fax, Degree, State and Search Now button clicked when there are no results.
     * JIRA: HWPHME2E-1837
     *
     * Pre-Conditions:
     * 1.UFlag 32050 should be set to TRUE
     * 2.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 32050;
     * 3.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 7118;
     * Launch Connexus and login with valid credentials.
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "Verify the search Result  with less than 100 records",
            priority = 21, dataProviderClass = DataProvider.class, enabled = true, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1837_Search_With_Single_Value_for_less_than_100_records(Map<String, String> inputData) {
        Log.info(">>>HWPHME2E_1837_Search_With_Single_Value_for_less_than_100_records<<<");
        connexusAppUtils.getStoreId();
        updateFlags();
        prescriberSearchTestSetScript.initializeTestCase(flagUpdated);
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Verify search result with less than 100 records
        prescriberSearchTestSetScript.verifySearchResultGridRecordsTextwithSingleInput(inputData);

        //3. Close search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();
        Log.info("HWPHME2E_1837_Search_With_Single_Value_for_less_than_100_records");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Verify the search functionality when value is provided in 2 or more fields -
     *  Name, NPI, DEA#, Phone, Fax, Degree, State and Search Now button clicked when there are more than 100 results.
     * JIRA: HWPHME2E-1836
     *
     * Pre-Conditions:
     * 1.UFlag 32050 should be set to TRUE
     * 2.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 32050;
     * 3.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 7118;
     * Launch Connexus and login with valid credentials.
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "verify prescriber search result with more than 100 records",
            priority = 4, dataProviderClass = DataProvider.class, enabled = false, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1836_Search_result_with_multi_value_for_more_than_100_records(Map<String, String> inputData) {
        Log.info(">>>HWPHME2E_1836_Search_result_with_multi_value_for_more_than_100_records<<<");
        prescriberSearchTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.initializeTestCase(false);
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Click on Close button to close the Prescriber Search window
        prescriberSearchTestSetScript.searchWithMultiValueforMoreThan100Records(inputData);

        prescriberSearchTestSetScript.createNewPatient(inputData);
        //Perform Dropoff
        prescriberSearchTestSetScript.performDropOff(Priority.Critical);
        //open Input
        prescriberSearchTestSetScript.openRXinInputScreen(inputData);
        // verify search Result
        prescriberSearchTestSetScript.searchWithMultiValueforMoreThan100Records(inputData);
        //perform Input
        prescriberSearchTestSetScript.performInput(inputData);
        // Verify search results on modify screen
        prescriberSearchTestSetScript.searchResultGridwithMultiValueinModifyDeatils(inputData);

        Log.info("HWPHME2E_1836_Search_result_with_multi_value_for_more_than_100_records");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Verify the search functionality when value is provided in 2 or more fields -
     *  Name, NPI, DEA#, Phone, Fax, Degree, State and Search Now button clicked when there are more than 100 results.
     * JIRA: HWPHME2E-1838
     *
     * Pre-Conditions:
     * 1.UFlag 32050 should be set to TRUE
     * 2.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 32050;
     * 3.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 7118;
     * Launch Connexus and login with valid credentials.
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "verify prescriber search result with more than 100 records",
            priority = 22, dataProviderClass = DataProvider.class, enabled = true, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1838_Search_result_with_single_value_for_more_than_100_records(Map<String, String> inputData) {
        Log.info(">>>HWPHME2E_1838_Search_result_with_single_value_for_more_than_100_records<<<");
        connexusAppUtils.getStoreId();
        prescriberSearchTestSetScript.initializeTestCase(false);
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Click on Close button to close the Prescriber Search window
        prescriberSearchTestSetScript.searchWithSingleValueforMoreThan100Records(inputData);

        prescriberSearchTestSetScript.createNewPatient(inputData);
        //Perform Dropoff
        prescriberSearchTestSetScript.performDropOff(Priority.Critical);
        //open Input
        prescriberSearchTestSetScript.openRXinInputScreen(inputData);
        // verify search Result
        prescriberSearchTestSetScript.searchWithSingleValueforMoreThan100Records(inputData);
        //perform Input
        prescriberSearchTestSetScript.performInput(inputData);
        // Verify search results on modify screen
        prescriberSearchTestSetScript.searchResultGridwithSingleValueinModifyDeatils(inputData);

        Log.info("HWPHME2E_1838_Search_result_with_single_value_for_more_than_100_records");
    }

    /**----------------------------------------------------------------------------------------------------------
     *  Validate prescriber search using LN,FN ( will be testing with partial and full LN / FN provided and with /without MN associated with prescribers)
     .
     * JIRA: HWPHME2E-1839
     *
     * Pre-Conditions:
     * 1.UFlag 32050 should be set to TRUE
     * 2.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 32050;
     * 3.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 7118;
     * Launch Connexus and login with valid credentials.
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "Verify the search functionality with full and Partial name details",
            priority = 24, dataProviderClass = DataProvider.class, enabled = false, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1839_Verify_PrescriberNames_with_full_and_partial_names(Map<String, String> inputData) {
        Log.info(">>HWPHME2E_1839_Verify_PrescriberNames_with_full_and_partial_names<<<");
        connexusAppUtils.getStoreId();
        prescriberSearchTestSetScript.initializeTestCase(false);
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Verify the search functionality with full and Partial name details
        prescriberSearchTestSetScript.enterthreeLetterFNLNwithThreeLetterMN(inputData);

        prescriberSearchTestSetScript.clickClearSearch();

        prescriberSearchTestSetScript.enterFullDetailsFNLNwithFullMN(inputData);

        prescriberSearchTestSetScript.clickClearSearch();

        prescriberSearchTestSetScript.searchForPrescriberPartialNameWithoutMN(inputData);
        //3. Close search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();
        Log.info("HWPHME2E_1839_Verify_PrescriberNames_with_full_and_partial_names");

    }

    /**----------------------------------------------------------------------------------------------------------
     *  Validate prescriber search using LN,FN MN with only 1 letter in MN ( will be testing with partial and full LN / FN provided)
     .
     * JIRA: HWPHME2E-1840
     *
     * Pre-Conditions:
     * 1.UFlag 32050 should be set to TRUE
     * 2.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 32050;
     * 3.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 7118;
     * Launch Connexus and login with valid credentials.
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "Verify the search functionality with full and Partial name details",
            priority = 25, dataProviderClass = DataProvider.class, enabled = false, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1840_Verify_PrescriberNames_full_and_partial_names_with_oneLetterMN(Map<String, String> inputData) {
        Log.info(">>HWPHME2E_1840_Verify_PrescriberNames_full_and_partial_names_with_oneLetterMN<<<");
        connexusAppUtils.getStoreId();
        prescriberSearchTestSetScript.initializeTestCase(false);
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Verify the search functionality with full and Partial name details
        prescriberSearchTestSetScript.enterthreeLetterFNLNwithOneLetterMN(inputData);

        prescriberSearchTestSetScript.clickClearSearch();

        prescriberSearchTestSetScript.enterFullDetailsFNLNwithOneLetterMN(inputData);

        //3. Close search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowsByPressingEscapeButton();
        Log.info("HWPHME2E_1840_Verify_PrescriberNames_full_and_partial_names_with_oneLetterMN");

    }
    /**----------------------------------------------------------------------------------------------------------
     *  Validate prescriber search using LN,FN MN with only 2 letters in MN ( will be testing with partial and full LN / FN provided)
     .
     * JIRA: HWPHME2E-1841
     *
     * Pre-Conditions:
     * 1.UFlag 32050 should be set to TRUE
     * 2.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 32050;
     * 3.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 7118;
     * Launch Connexus and login with valid credentials.
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "Verify the search functionality with full and Partial name details",
            priority = 26, dataProviderClass = DataProvider.class, enabled = false, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1841_Verify_PrescriberNames_full_and_partial_names_with_twoLetterMN(Map<String, String> inputData) {
        Log.info(">>HWPHME2E_1841_Verify_PrescriberNames_full_and_partial_names_with_twoLetterMN<<<");
        connexusAppUtils.getStoreId();
        prescriberSearchTestSetScript.initializeTestCase(false);
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Verify the search functionality with full and Partial name details
        prescriberSearchTestSetScript.enterthreeLetterFNLNwithTwoLetterMN(inputData);

        prescriberSearchTestSetScript.clickClearSearch();

        prescriberSearchTestSetScript.enterFullDetailsFNLNwithTwoLetterMN(inputData);

        //3. Close search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowsByPressingEscapeButton();
        Log.info("HWPHME2E_1841_Verify_PrescriberNames_full_and_partial_names_with_twoLetterMN");

    }
    /**----------------------------------------------------------------------------------------------------------
     *  Validate prescriber search using LN,FN MN with only 3 letters in MN ( will be testing with partial and full LN / FN provided)
     .
     * JIRA: HWPHME2E-1842
     *
     * Pre-Conditions:
     * 1.UFlag 32050 should be set to TRUE
     * 2.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 32050;
     * 3.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 7118;
     * Launch Connexus and login with valid credentials.
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "Verify the search functionality with full and Partial name details",
            priority = 27, dataProviderClass = DataProvider.class, enabled = false, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1842_Verify_PrescriberNames_full_and_partial_names_with_ThreeLetterMN(Map<String, String> inputData) {
        Log.info(">>HWPHME2E_1842_Verify_PrescriberNames_full_and_partial_names_with_ThreeLetterMN<<<");
        connexusAppUtils.getStoreId();
        prescriberSearchTestSetScript.initializeTestCase(false);
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Verify the search functionality with full and Partial name details
        prescriberSearchTestSetScript.enterthreeLetterFNLNwithThreeLetterMN(inputData);

        prescriberSearchTestSetScript.clickClearSearch();

        prescriberSearchTestSetScript.enterFullDetailsFNLNwithThreeLetterMN(inputData);

        //3. Close search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowsByPressingEscapeButton();
        Log.info("HWPHME2E_1842_Verify_PrescriberNames_full_and_partial_names_with_ThreeLetterMN");

    }

    /**----------------------------------------------------------------------------------------------------------
     *  Validate prescriber search using LN,FN MN with full MN provided ( will be testing with partial and full LN / FN provided)
     .
     * JIRA: HWPHME2E-1843
     *
     * Pre-Conditions:
     * 1.UFlag 32050 should be set to TRUE
     * 2.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 32050;
     * 3.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 7118;
     * Launch Connexus and login with valid credentials.
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "Verify the search functionality with full and Partial name details",
            priority = 28, dataProviderClass = DataProvider.class, enabled = true, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1843_Verify_PrescriberNames_full_and_partial_names_with_fullMN(Map<String, String> inputData) {
        Log.info(">>HWPHME2E_1843_Verify_PrescriberNames_full_and_partial_names_with_fullMN<<<");
        connexusAppUtils.getStoreId();
        prescriberSearchTestSetScript.initializeTestCase(false);
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Verify the search functionality with full and Partial name details
        prescriberSearchTestSetScript.enterthreeLetterFNLNwithFullMN(inputData);

        prescriberSearchTestSetScript.clickClearSearch();

        prescriberSearchTestSetScript.enterthreeLetterFNLNwithFullMN(inputData);

        //3. Close search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowsByPressingEscapeButton();
        Log.info("HWPHME2E_1843_Verify_PrescriberNames_full_and_partial_names_with_fullMN");

    }

    /**----------------------------------------------------------------------------------------------------------
     *  Validate prescriber search using FN LN ( will be testing with partial and full FN / LN provided and with /without MN associated with prescribers)
     .
     * JIRA: HWPHME2E-1844
     *
     * Pre-Conditions:
     * 1.UFlag 32050 should be set to TRUE
     * 2.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 32050;
     * 3.select phm_parm_value from rx21c:bu_phm_parm where phm_parm_code = 7118;
     * Launch Connexus and login with valid credentials.
     *
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "Verify the search functionality with full and Partial name details",
            priority = 29, dataProviderClass = DataProvider.class, enabled = false, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void HWPHME2E_1844_Verify_PrescriberNames_full_and_partial_names(Map<String, String> inputData) {
        Log.info(">>HWPHME2E_1844_Verify_PrescriberNames_full_and_partial_names<<<");
        connexusAppUtils.getStoreId();
        prescriberSearchTestSetScript.initializeTestCase(false);
        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Verify the search functionality with full and Partial name details
        prescriberSearchTestSetScript.enterthreeLetterFNLNwithThreeLetterMN(inputData);

        prescriberSearchTestSetScript.clickClearSearch();

        prescriberSearchTestSetScript.enterFullDetailsFNLNwithFullMN(inputData);

        prescriberSearchTestSetScript.clickClearSearch();

        prescriberSearchTestSetScript.searchForPrescriberPartialNameWithoutMN(inputData);

        prescriberSearchTestSetScript.clickClearSearch();

        prescriberSearchTestSetScript.enterFullDetailsFNLNwithoutMN(inputData);
        //3. Close search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowsByPressingEscapeButton();
        Log.info("HWPHME2E_1844_Verify_PrescriberNames_full_and_partial_names");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether user is able to search the prescriber from search menu using Search Now button
     * JIRA: HWQEAUTO-8777
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *bb
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    /*@Test(description = "To verify whether user is able to search the prescriber from search menu using Search Now button",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void tc01_Verify_Whether_User_Able_To_Search_Prescriber_From_Search_Menu(Map<String, String> inputData) {
        System.out.println(">>>tc01_Verify_Whether_User_Able_To_Search_Prescriber_From_Search_Menu<<<");

        //1. Open Prescriber Search from Search Menu  - commented for search Menu and using keys to open search window
        //prescriberSearchTestSetScript.openPrescriberSearchWindowFromSearchMenu();

        //2. Search for a Prescriber and verify the search results on Prescriber Search window
        prescriberSearchTestSetScript.searchForPrescriberAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Prescriber Search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc01_Verify_Whether_User_Able_To_Search_Prescriber_From_Search_Menu>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the search history is displayed when user clicks on the search text box for Name,NPI,DEA fields
     * JIRA: HWQEAUTO-16027
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     *----------------------------------------------------------------------------------------------------------*/
    /*@Test(description = "To verify whether the search history is displayed when user clicks on the search text box for Name,NPI,DEA fields",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void tc03_Verify_Search_History(Map<String, String> inputData) {
        System.out.println(">>>tc03_Verify_Search_History<<<");

        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. a. Enter Prescriber Name, NPI, DEA, Phone, Fax, SPI and then click on Search Store button
        //   b. Verify the search results with the given inputs.
        prescriberSearchTestSetScript.searchForPrescriberWithAllFields(inputData);

        //3. Click on Close button to close the Prescriber Search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();

        //4. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        //prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //5. a. Go to each text field in Prescriber Search window and check if it has previous Search History displayed
        //   b. In each Text Field/Dropdown, press Down Arrow Key to select the value
        //   c. Click on Search Now button
        //   d. Verify the search results matched with the given inputs.
        //prescriberSearchTestSetScript.checkPrescriberSearchHistory(inputData);

        //6. Click on Close button to close the Prescriber Search window
        //prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc03_Verify_Search_History>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the ESC button closes search screen
     * JIRA: HWQEAUTO-16029
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     * ----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To verify whether the ESC button closes search screen",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void tc04_Verify_Whether_ESC_Button_Closes_Prescriber_Search_Window(Map<String, String> inputData) {
        System.out.println(">>>tc04_Verify_Whether_ESC_Button_Closes_Prescriber_Search_Window<<<");

        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Search for a Prescriber and verify the search results on Prescriber Search window
        prescriberSearchTestSetScript.searchForPrescriberAndVerifySearchResults(inputData);

        //3. Verify whether Prescriber Search Window is closed when the user pressed ESC button
        prescriberSearchTestSetScript.closePrescriberSearchWindowsByPressingEscapeButton();


        System.out.println("<<<tc04_Verify_Whether_ESC_Button_Closes_Prescriber_Search_Window>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Prescriber maintenance screen is displayed on double clicking record from search results
     * JIRA: HWQEAUTO-8729
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     *----------------------------------------------------------------------------------------------------------*/
    /*@Test(description = "To verify whether Prescriber maintenance screen is displayed on double clicking record from search results",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void tc05_Verify_Whether_Prescriber_Maintenance_Screen_Displayed_On_double_Clicking_Record_From_Search_Results(Map<String, String> inputData) {
        System.out.println(">>>tc05_Verify_Whether_Prescriber_Maintenance_Screen_Displayed_On_double_Clicking_Record_From_Search_Results<<<");

        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Search for a Prescriber and verify the search results on Prescriber Search window
        prescriberSearchTestSetScript.searchForPrescriberAndVerifySearchResults(inputData);

        //3. Double click and open the Prescriber Maintenance window from search grid
        prescriberSearchTestSetScript.openPrescriberMaintenanceByDoubleClickingOnSearchRecord();

        //4. Verify whether Prescriber maintenance screen is displayed
        prescriberSearchTestSetScript.verifyWhetherPrescriberMaintenanceDisplayed(inputData);

        //5. Close Prescriber Maintenance screen by clicking on Cancel button
        prescriberSearchTestSetScript.closePrescriberMaintenanceWindowByClickingOnCancel();

        System.out.println("<<<tc05_Verify_Whether_Prescriber_Maintenance_Screen_Displayed_On_double_Clicking_Record_From_Search_Results>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether empty result grid is displayed with column names when search results are not found
     * JIRA: HWQEAUTO-8706
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     *----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To verify whether empty result grid is displayed with column names when search results are not found",
            priority = 6, dataProviderClass = DataProvider.class, enabled = true, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void tc06_Verify_Whether_Empty_Results_Grid_Displayed_When_No_Results_Found(Map<String, String> inputData) {
        System.out.println(">>>tc06_Verify_Whether_Empty_Results_Grid_Displayed_When_No_Results_Found<<<");

        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Search for a prescriber in Prescriber Search window
        prescriberSearchTestSetScript.verifyEmptySearchResultsGridWhenNoResultsFound(inputData);

        //3. Click on Close button to close the Prescriber Search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc06_Verify_Whether_Empty_Results_Grid_Displayed_When_No_Results_Found>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether user able to search prescriber with Name, NPI, DEA fields
     * JIRA: HWQEAUTO-8698; HWQEAUTO-8670
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     *----------------------------------------------------------------------------------------------------------*/
    /*@Test(description = "To verify whether user able to search prescriber with Name, NPI, DEA fields",
            priority = 7, dataProviderClass = DataProvider.class, enabled = true, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void tc07_Verify_Whether_User_Able_To_Search_Prescriber_With_Name_NPI_DEA_Fields(Map<String, String> inputData) {
        System.out.println(">>>tc07_Verify_Whether_User_Able_To_Search_Prescriber_With_Name_NPI_DEA_Fields<<<");

        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Search for an invalid prescriber in Prescriber Search window and verify that search results grid is empty
        prescriberSearchTestSetScript.searchForPrescriberWith_Name_NPI_DEA_Fields(inputData);

        //3. Click on Close button to close the Prescriber Search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc07_Verify_Whether_User_Able_To_Search_Prescriber_With_Name_NPI_DEA_Fields>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify the prescriber search results on entering data from Input screen and clicking search
     * JIRA: HWQEAUTO-8666
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     *----------------------------------------------------------------------------------------------------------*/
   /* @Test(description = "To verify the prescriber search results on entering data from Input screen and clicking search",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void tc08_Verify_Prescriber_Search_Results_From_Input_Screen(Map<String, String> inputData) {
        System.out.println(">>>tc08_Verify_Prescriber_Search_Results_From_Input_Screen<<<");

        //1. Create a new patient
        prescriberSearchTestSetScript.createPatient(inputData);

        //2. DropOff an RX for the above created patient
        prescriberSearchTestSetScript.performDropOffForNewPatient();

        //3. Search for the Patient on the Order Search Window and open on Input screen
        prescriberSearchTestSetScript.openRXinInputScreen(inputData);

        //4. From Input screen, search for a prescriber and verify the search results.
        prescriberSearchTestSetScript.searchForPrescriberInInputScreenAndVerifyResults(inputData);

        //5. Clear Search on Prescriber Search window and search again for a prescriber and verify the search results.
        prescriberSearchTestSetScript.clearSearchAndSearchAgainForPrescriberInInputScreenAndVerifyResults(inputData);

        //6. Click on Close button to close the Prescriber Search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();

        //7. Close Input screen
        prescriberSearchTestSetScript.closeInputScreen();

        System.out.println("<<<tc08_Verify_Prescriber_Search_Results_From_Input_Screen>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Prescriber Maintenance screen is displayed on clicking New Button
     * JIRA: HWQEAUTO-8664
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     *----------------------------------------------------------------------------------------------------------*/
    /*@Test(description = "To verify whether Prescriber Maintenance screen is displayed on clicking New Button",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void tc09_Verify_Whether_Prescriber_Maintenance_Screen_Displayed_On_Clicking_New_Button(Map<String, String> inputData) {
        System.out.println(">>>tc09_Verify_Whether_Prescriber_Maintenance_Screen_Displayed_On_Clicking_New_Button<<<");

        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Search for a Prescriber and verify the search results on Prescriber Search window
        prescriberSearchTestSetScript.searchForPrescriberAndVerifySearchResults(inputData);

        //3. Click on New Button and verify whether Prescriber Maintenance screen is displayed
        prescriberSearchTestSetScript.clickOnNewButtonAndVerifyIfPrescriberMaintenanceScreenDisplayed();

        //4. Click on Close button to close the Prescriber Search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc09_Verify_Whether_Prescriber_Maintenance_Screen_Displayed_On_Clicking_New_Button>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether user able to search prescriber using searching in combinations
     * JIRA: HWQEAUTO-8656
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     *----------------------------------------------------------------------------------------------------------*/
    /*@Test(description = "To verify whether user able to search prescriber using searching in combinations",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void tc10_Verify_Whether_User_Able_To_Search_Prescriber_Using_Combinations(Map<String, String> inputData) {
        System.out.println(">>>tc10_Verify_Whether_User_Able_To_Search_Prescriber_Using_Combinations<<<");

        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Verify whether user able to search prescriber using different search combinations
        prescriberSearchTestSetScript.searchWithDifferentCombinationsAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Prescriber Search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc10_Verify_Whether_User_Able_To_Search_Prescriber_Using_Combinations>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether user able to search prescriber with Phone, Fax, SPI fields
     * JIRA: HWQEAUTO-8628
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     *----------------------------------------------------------------------------------------------------------*/
    /*@Test(description = "To verify whether user able to search prescriber with Phone, Fax, SPI fields",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = false)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void tc11_Verify_Whether_User_Able_To_Search_Prescriber_Using_Phone_Fax_SPI_Combinations(Map<String, String> inputData) {
        System.out.println(">>>tc11_Verify_Whether_User_Able_To_Search_Prescriber_Using_Phone_Fax_SPI_Combinations<<<");

        //1. Open Prescriber Search window by pressing the keyboard shortcut key CTRL+SHIFT+B
        prescriberSearchTestSetScript.openPrescriberSearchWindow();

        //2. Verify whether user able to search prescriber using Phone, Fax and SPI search combinations
        prescriberSearchTestSetScript.searchWithPhoneFaxSPICombinationAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Prescriber Search window
        prescriberSearchTestSetScript.closePrescriberSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc11_Verify_Whether_User_Able_To_Search_Prescriber_Using_Phone_Fax_SPI_Combinations>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: To verify the data in Prescriber Address and Prescriber DEA on changing the Prescriber in Results grid
     * JIRA: HWQEAUTO-8230
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     *----------------------------------------------------------------------------------------------------------*/
    /*@Test(description = "To verify the data in Prescriber Address and Prescriber DEA on changing the Prescriber in Results grid",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true)
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void tc12_Verify_Whether_Order_Search_Shows_Updated_Prescriber_Details(Map<String, String> inputData) {
        System.out.println(">>>tc12_Verify_Whether_Order_Search_Shows_Updated_Prescriber_Details<<<");

        //Pre-Condition: Check Flag 26849 and set it to TRUE and restart Connexus.
        *//*if (connexusAppUtils.readFlagValue("26849").get(0).get("phm_parm_value").toString().trim().equals("true")) {
            closeConnexus();
            connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
            prescriberSearchTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }*//*

        //1. Create a new patient
        prescriberSearchTestSetScript.createPatient(inputData);

        //2. Drop an RX for the newly created patient
        prescriberSearchTestSetScript.performDropOff(inputData);

        //3. Complete Input
        prescriberSearchTestSetScript.performInput(inputData);

        //4. Search for the Patient on Order Search Window and verify that Prescriber details are matched
        prescriberSearchTestSetScript.searchForOrderAndVerifyPrescriberDetails(inputData);

        //5. Open RX in Four Point >> Open Modify Details >> Change Prescriber
        prescriberSearchTestSetScript.openRXinFourPointAndModifyPrescriberDetails(inputData);

        //6. Search for the Patient on Order Search Window and verify that Prescriber details are matched
        prescriberSearchTestSetScript.searchForOrderAndVerifyModifiedPrescriberDetails(inputData);

        System.out.println("<<<tc12_Verify_Whether_Order_Search_Shows_Updated_Prescriber_Details>>>");
    }*/


    /**----------------------------------------------------------------------------------------------------------
     * Test Description: To verify the data in Prescriber Address and Prescriber DEA on changing the Prescriber in Results grid
     * JIRA: HWQEAUTO-8229; HWQEAUTO-8171
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     *
     /* *----------------------------------------------------------------------------------------------------------*//*
    @Test(description = "To verify the data in Prescriber Address and Prescriber DEA on changing the Prescriber in Results grid",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", enabled = true, dependsOnMethods = "tc12_Verify_Whether_Order_Search_Shows_Updated_Prescriber_Details")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PrescriberSearchDataBook.json", sheetName = "PrescriberSearch")
    public void tc13_Verify_Prescriber_Address_DEA_on_Changing_Prescriber_In_Results_Grid(Map<String, String> inputData) {
        System.out.println(">>>tc13_Verify_Prescriber_Address_DEA_on_Changing_Prescriber_In_Results_Grid<<<");

        //1. Complete 4Point for the previously created RX
        prescriberSearchTestSetScript.completeFourPoint();

        //2. Complete ChkDUR
        prescriberSearchTestSetScript.completeChkDUR();

        //3. Complete Resolution in case if RX goes to resolution queue.
        prescriberSearchTestSetScript.completeResolution();

        //4. Open the RX from Filling Queue, it lands on Modify details screen
        prescriberSearchTestSetScript.openRXinFillingQueue();

        //5. Verify the data in Prescriber Address and Prescriber DEA on changing the Prescriber in Results grid
        prescriberSearchTestSetScript.verifyPrescriberDetailsInModifyDetailsScreen(inputData);

        //6. Close Modify Details screen
        //
        prescriberSearchTestSetScript.closeModifyDetailsScreen();

        System.out.println("<<<tc13_Verify_Prescriber_Address_DEA_on_Changing_Prescriber_In_Results_Grid>>>");
    }*/
}
