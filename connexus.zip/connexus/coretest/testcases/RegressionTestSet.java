package connexus.coretest.testcases;


import connexus.coretest.testscripts.RegressionTestSetScript;
import connexus.coretest.testscripts.UserExperienceTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class RegressionTestSet {

    ConnexusAppUtils connexusAppUtils= new ConnexusAppUtils();
    RegressionTestSetScript regressionTestSetScript = new RegressionTestSetScript();

    @BeforeClass
    public void performlogin() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:To verify if Resolution setting for Pharmacist is working correctly.
    *
    * Pre condition:
    1. login to the store as pharmacist.
    * Author: Tarun Upputuri(vn510o1)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify if Resolution setting for Pharmacist is working correctly.",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RegressionDataBook.json", sheetName = "Regression")
    public void HWPHME2E_357_Resolution_settings_Pharmacist_13(Map<String, String> inputData) {

        //Pre condition:
        //1. login to the store as pharmacist.

        //1.User should be able to login to the store as pharmacist. | login to connexus application as pharmacist.
        regressionTestSetScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //2.Resolution option popup should be open. | click on resolution settings in tools
        //3.All check boxes should be enabled for pharmacist.| Verify the Resolution option
        regressionTestSetScript.navigateToResolutionSettingsAndValidateResolutionOptions(inputData);

        Reporter.log("Resolution option popup is opened and clicked on settings in tools");
    }

    /*----------------------------------------------------------------------------------------------------------
        * Test Description:To verify the Free form SIG is allowing the Technician to enter the data in Input screen.
        *
        Pre condition:
        1. login to the store as pharmacist.
        * Author: Tarun Upputuri(vn510o1)
        ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify the Free form SIG is allowing the Technician to enter the data in Input screen.",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RegressionDataBook.json", sheetName = "Regression")
    public void HWPHME2E_356_Verify_Free_form_SIG_is_allowing_Technician_to_enter_data_in_Input_screen(Map<String, String> inputData) {

        // Pre condition:
        // 1. login to the store as technician.

        //1.login to connexus and open the drop-off screen. | Drop-off screen should be opened.
        regressionTestSetScript.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);

        //2.Search for an existing patient and complete drop-off | User should be able to complete drop-off and RX should be moved to input work queue.
        //3.search for the patient using F6 and double click on the RX.| RX should be in Input work queue.
        //4.Enter all the mandatory fields on the input screen |user should be able to enter the details.
        //5.Give  SIG as FF | User should be able to enter SIG as free form.
        //6.enter description with numeric value and tab out | User should be able to enter numeric values on the description field.
        //7.Enter the description with special characters | user should be able to enter special characters on the description field.
        //8.Enter lengthier sentence as description | User should be able to enter the description.And the maximum charecters user can enter should be 255 .
        regressionTestSetScript.createNewPatient(inputData);
        regressionTestSetScript.performDropOff(Priority.InStore);
        regressionTestSetScript.validateExtendedSig(inputData);

        Reporter.log("Free form SIG is allowed in the Technician to enter the data in Input screen");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: To verify the Pickup time of the Rx based on the Priority selected at the Drop Off.
     *
     Pre condition:
     1. User should have valid credential to login connexus.
     2.Patient should be available.
     *
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify the Pickup time of the Rx based on the Priority selected at the Drop Off.",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/RegressionDataBook.json", sheetName = "Regression")
    public void HWPHME2E_213_Verify_Pickup_time_of_Rx_based_on_Priority_selected_at_DropOff(Map<String, String> inputData) {

        // Pre Condition: To verify the Free form SIG is allowing the Technician to enter the data in Input screen.

        // Pre condition:
        // 1. User should have valid credential to login connexus.
        // 2. Patient should be available.

        regressionTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        //1.Login to connexus| User should be able to login
        //2.Click on Drop off and search for the patient | Patient search results should be populated
        //3.Scan an Rx for the Patient| New Rx should be populated in the Order Information grid.
        //4.Select Order Priority as 'In-Store' from the Priority drop down and verify the Ready By time is 20 minutes from system time  | User should be able to select the priority and Ready By time should be auto populated as 20 minutes from the system time
        //5.Select Order Priority as 'Today' from the Priority drop down | User should be able to select the priority and Ready By field should be enabled
        //6.Select Ready By time from the drop down | User should be able to select the Ready By time.
        //7.Select Order Priority as 'Dr Call In' from the Priority drop down and verify the Ready By time is 45 minutes from system time | User should be able to select the priority and Ready By time should be auto populated as 45 minutes from the system time
        //8.Select Order Priority as 'Drive Thru' from the Priority drop down and verify the Ready By time is 20 minutes from system time | User should be able to select the priority and Ready By time should be auto populated as 20 minutes from the system time.
        //9.Select Order Priority as 'Future' from the Priority drop down | User should be able to select the priority and Ready By time & Date should be auto populated.
        //10.Select any Future Date and time from the drop down | User should be able to select the Ready By time
        //11.Select Order Priority as 'Critical' from the Priority drop down and verify the Ready By time is 5 minutes from the system time | User should be able to select the priority and Ready By time should be auto populated as 5 minutes from the system time.

        regressionTestSetScript.validatePriority(inputData);

        Reporter.log("verifed the Pickup time of the Rx based on the Priority selected at the Drop Off");
    }

}


