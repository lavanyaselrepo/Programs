package connexus.coretest.testcases;

import connexus.coretest.testscripts.OrderPickupTestSet1Script;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class OrderPickupTestSet1 {

    OrderPickupTestSet1Script orderPickupTestSet1Script = new OrderPickupTestSet1Script();
    ConnexusAppUtils connexusAppUtils= new ConnexusAppUtils();


    @BeforeClass
   public void performlogin() {
        connexusAppUtils.startAppiumServer();
        orderPickupTestSet1Script.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
         }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:verify  whether the patient Name,DOB, Address, City, State, Phone # are displayed
     *
     * Pre-Conditions: 1. 26846 should be ON
     *
     * Author: Preetha(vn50myr)
     ----------------------------------------------------------------------------------------------------------*/
  /*  @Test(description = "verify  whether the patient Name,DOB, Address, City, State, Phone # are displayed",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/OrderPickupDataBook.json", sheetName = "orderPickup")
    public void tc_1_303359_or_215028_PSEsearch(Map<String, String> inputData) {
        System.out.println(">>>tc_303359_or_215028_PSEsearch<<<");

        //Pre-conditions
        //1. 26846 should be ON and 26849 should be ON
        if( connexusAppUtils.readAndUpdateFlag("26846","TRUE")){
            tearDown();
            orderPickupTestSet1Script = new OrderPickupTestSet1Script();
            orderPickupTestSet1Script.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        if(connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            orderPickupTestSet1Script = new OrderPickupTestSet1Script();
            orderPickupTestSet1Script.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        orderPickupTestSet1Script.createPatient(inputData);
        orderPickupTestSet1Script.dropAnRxTillBagging(inputData);

        //1.Login to connexus and press F11, click on  PSE icon |PSE search screen should be displayed
        //2.Search for a patient profile that  exists in the current store |Search results should be displayed
        //3.Select the patient and verify whether the patient Name,DOB, Address, City, State, Phone # are displayed|All the fields should be displayed
        orderPickupTestSet1Script.pseSearch(inputData);

        System.out.println("<<<tc_303359_or_215028_PSEsearch>>>");
    }

     /*----------------------------------------------------------------------------------------------------------
    * Test Description:To verify whether TP to Cash pop up is displayed when there is TP to Cash change on a Rx with TP in state of WA.
    *
    * Pre-Conditions:
    * 1. User should have valid credential to login connexus.
    * 2.Patient should be available.
    * 3.State should be configured to WA
    *
    * Author: Preetha(vn50myr)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether TP to Cash pop up is displayed when there is TP to Cash change on a Rx with TP in state of WA.",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/OrderPickupDataBook.json", sheetName = "orderPickup")
    public void HWPHME2E_547(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_547<<<");

        //Pre-condition:
        //1. User should have valid credential to login connexus.
        if( connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            orderPickupTestSet1Script = new OrderPickupTestSet1Script();
            orderPickupTestSet1Script.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        //2.Patient should be available.
        orderPickupTestSet1Script.createPatientAllRequiredFields(inputData);
        //3.State should be configured to WA
        orderPickupTestSet1Script.updateStoreState(inputData);

        //1.Login to connexus | User should be able to login
        //2.Drop an rx with primary payment method as TP | Rx should  move to Input Work queue
        //3.Complete Input for the rx | Rx should  move to Four point Work queue
        //4.Complete Four point for the rx | Rx should move to Filling Work queue
        //5.Open modify details screen and do switch to cash and click on accept | Rx should move to Four point Work queue
        //6.Complete Four Point for the rx | Rx should move to Filling Work queue
        //7.Change Payment type from TP to cash and complete filling for the rx. | Rx should move to Visual Verify Work queue
        //8.Complete Visual Verify for the rx | Rx should move to Bagging Work queue
        //9.Complete Bagging for the rx | Rx should move to Pickup Work queue
        //10.Hit F11, search for the above patient and click on Check Out button | Switch To Cash pop up should be displayed
        //11.Click on Pay Cash Price and give Fill Id and complete Pickup | Rx should move to Counsel Work queue
        //12.Complete Counsel for the rx | Rx should move to POS Work queue
        //13.Complete POS for the rx | Rx should be taken till EOD successfully
        orderPickupTestSet1Script.dropAnRxTillEodSwitchToCash(inputData);
        System.out.println("<<<HWPHME2E_547>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
         * Test Description:To Verify that Order detail option doesnot appear in the Current RX option when the RX is in POS queue.
         *
         * Pre-Conditions:
         * 1. User is logged in to ConnexUs,and CDI Flag is turned OFF
         * 2. Patient profile should be present in the connexus.
         *
         * Author: Preetha(vn50myr)
         ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the Controlled Substance Checkout screen",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/OrderPickupDataBook.json", sheetName = "orderPickup")
    public void HWPHME2E_598(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_598<<<");
        //Pre-condition
        //1. User is logged in to ConnexUs,and CDI Flag is turned OFF
        if( connexusAppUtils.readAndUpdateFlag("8600","FALSE")){
            tearDown();
            orderPickupTestSet1Script = new OrderPickupTestSet1Script();
            orderPickupTestSet1Script.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        //2. Patient profile should be present in the connexus.
        orderPickupTestSet1Script.createPatient(inputData);

        //1.Click on the Drop off Icon. | Drop Off screen would be launched.
        //2.scan 1 Rx at Drop Off  for the existing patient. | The scan Rx will be successful
        //3.Select the priority of the RX and click on ACCEPT at Drop Off screen | The DropOff screen will be closed and the Connexus screen will be Blank.
        //4.Complete the Input for the RX | Input will be completed
        //5.Move the rx till POS. | Rx should be in POS workqueue.
        orderPickupTestSet1Script.dropAnRxTillPos(inputData);
        //6.Open the rx which is in POS work queue from the F6 search screeen by double clicking on it. | Modify details screen should be displayed.
        //7.Click on the Current Rx option on the modify details screen for the rx in POS  and verify that there is no Order detail option appearing . | Order detail option will not be present in theCurrent Rx option on the modify details screen ffor the rx in POS queue.
        orderPickupTestSet1Script.POS_ModifyCurrentRx_OrderDetails();

        System.out.println("<<<HWPHME2E_598>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Verify that Pharmacy Associate is able to select the "CANCEL" button on the Cash Payment Option screen of TASCO when Patient with valid Texas Medicaid plan requests to pay cash for the RX.
     *
     * Pre-Conditions:
     *  1. Store Settings in Connexus should be Wal-Mart Pharmacy.
     *  2. Patient Profile should be configured as English.
     *  3. Medicaid plan should be configured to Flag On.  The Restriction number column in covg_opt_restrict table should be ' Y' for carrier = SW and Plan =MTX. Use following query to check:-
     *      "SELECT * FROM covg_opt_restrict WHERE CARRIER_CO_ID = '124790' AND ins_carr_plan_id = '103' ".
     *  4. The patient should be conofigured for a valid Texas Medicaid Plan.
     *  5. Process the RX with Normal Drug Till Filling queue.
     *  6. When at FILLING, click F9 to open Modify Details screen and change the payment method to Cash and click on ACCEPT button.
     *  7. Select any reason from the list in the "Select Reason for Switch to Cash"  pop up box displayed and click on OK Button.
     *  8. Process the Rx from Filling till Pick Up queue.
     *  9. SigPad should be available and configured.
     *
     * Author: Preetha(vn50myr)
     * Jira Testcase id : HWPHME2E-548
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify that Pharmacy Associate is able to select the 'CANCEL' button on the Cash Payment Option screen of TASCO when Patient with valid Texas Medicaid plan requests to pay cash for the RX.",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/OrderPickupDataBook.json", sheetName = "orderPickup")
    public void HWPHME2E_548_tc_2_138167_Cash_Payment_CANCEL_Button_SELECT(Map<String, String> inputData) {
        System.out.println(">>>tc_138167_Cash_Payment_CANCEL_Button_SELECT<<<");
        //pre- conditions :
        if( connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            orderPickupTestSet1Script = new OrderPickupTestSet1Script();
            orderPickupTestSet1Script.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        //1. Store Settings in Connexus should be Wal-Mart Pharmacy.
        //2. Patient Profile should be configured as English.
        //3. Medicaid plan should be configured to Flag On.  The Restriction number column in covg_opt_restrict table should be ' Y' for carrier = SW and Plan =MTX. Use following query to check:-
        //"SELECT * FROM covg_opt_restrict WHERE CARRIER_CO_ID = '124790' AND ins_carr_plan_id = '103' ".
        //4. The patient should be conofigured for a valid Texas Medicaid Plan.
        orderPickupTestSet1Script.createPatientAllRequiredFields(inputData);
        //5. Process the RX with Normal Drug Till Filling queue.//

        //6. When at FILLING, click F9 to open Modify Details screen and change the payment method to Cash and click on ACCEPT button.
        // 7. Select any reason from the list in the "Select Reason for Switch to Cash"  pop up box displayed and click on OK Button.
        //8. Process the Rx from Filling till Pick Up queue.
        //9. SigPad should be available and configured.
        orderPickupTestSet1Script.dropAnRxTillBagginSwitchToCash(inputData);
        //1.Press F11 and open TASCO screen,Enter patient last name, first name, DOB in the respective fields and click search |Tasco Screen returns the correct Patient Information and the RX orders relating to the Patient.
        //2.Select the Rx and click on the CheckOut|Cash Pay Restriction Screen will be displayed with Details f the RX and reason for switching to cash.
        //3.Click on Pay Cash Price button at the bottom |Co[nnexus displays popup prompting pharmacist to Ask the customer if they would like to join the easy pay program
        //4.Click NO or Ask Later button | Connexus returns to Tasco and Scan STR page is displayed ro scan the RX.
        //5.Select the RX number in the To Continue Scan Prescription section and type &apos;xxxxFill Idx&apos; and click on the ACCEPT Button which will be enabled.(x=any number)(if Fill Id is less than 7 ..prefix with 000 |HIPAA Acknowledgement Information Screen wil be displayed.
        //6.Patient Refuses to sign the HIPAA Acknowledgement Information Form, and click on Patient Refuse to sign Button. | Cash Payment Option dialog box will open having the Following verbiage:- "Action Needed: Patient signature and relationship are required to authorize the pharmacy to submit their Texas Medicaid prescription(s) as cash and not bill insurance".
        //7.Click on Ok Button. |The CASH PAYMENT OPTION SCREEN will be displayed.
        //8.Verify whetehr Pharmacy Associate is able to Select the CANCEL button present on Cash Payment Option screen of TASCO.|User should be able to select the CANCEL button and the system should return to the tasco Screen form where the Pharmacy associate entered the patient name and date of birth.
        orderPickupTestSet1Script.pickupCancelpayCash(inputData);

        System.out.println("<<<tc_138167_Cash_Payment_CANCEL_Button_SELECT>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
 * Test Description:To verify whether patient's name is displayed once during checkout, when  two rxs processed in same order are split from pickup(split bag), processed till pickup again, and selected for checkout.
 *
 * Pre-Conditions: 1. User should be logged in to connexus
 *
 * Author: Preetha(vn50myr)
 ----------------------------------------------------------------------------------------------------------*/
  /* @Test(description = "To verify whether patient's name is displayed once during checkout, when  two rxs processed in same order are split from pickup(split bag), processed till pickup again, and selected for checkout.",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/OrderPickupDataBook.json", sheetName = "orderPickup")
    public void tc_8_172062_Split_tasco (Map<String, String> inputData) {
        System.out.println(">>>tc_172062_Split_tasco<<<");

        //Pre condition:
        //1. User should be logged in to connexus
        if( connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            orderPickupTestSet1Script = new OrderPickupTestSet1Script();
            orderPickupTestSet1Script.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        orderPickupTestSet1Script.createPatient(inputData);
        //1.Process two Rxs for a patient in one  order till pickup | Rxs should be in pickup
        //2.Split the rxs at pickup(split bagging) |  Rxs should move to bagging workqueue
        //3.Complete bagging for the RXs | RXs should move to pickup
        orderPickupTestSet1Script.drop2RXTillBagging(inputData);
        //4. Select the rxs at pickup and click checkout. Verify whether patient's name is displayed. |  Patient's name should be displayed only once
        orderPickupTestSet1Script.pickupWith2Drug(inputData);
        System.out.println("<<<tc_172062_Split_tasco>>>");
    }
    /*----------------------------------------------------------------------------------------------------------
       * Test Description: To verify whether the Controlled Substance Checkout screen.
       *
       * Pre-Conditions:
       * 1. User should have valid credential to login connexus.
       * 2.Patient should be available.
       * 3.State should be configured to SC.
       * 4.Flag should be set as 29891 as TRUE.
       *
       * Author: Preetha(vn50myr)
       * JIRA testcase id : HWPHME2E-186
       ----------------------------------------------------------------------------------------------------------*/
   @Test(description = "To verify whether the Controlled Substance Checkout screen",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/OrderPickupDataBook.json", sheetName = "orderPickup")
    public void HWPHME2E_186_tc_4_311567_CSID_Pickup(Map<String, String> inputData) {
        System.out.println(">>>tc_311567_CSID_Pickup<<<");
        //Pre-condition:
        //1. User should have valid credential to login connexus.
        //2.Patient should be available.
        if( connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            if(connexusAppUtils.readAndUpdateFlag("29891", "TRUE")){
            tearDown();
            orderPickupTestSet1Script = new OrderPickupTestSet1Script();
            orderPickupTestSet1Script.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        }

        orderPickupTestSet1Script.createPatient(inputData);
        //3.State should be configured to SC.
        orderPickupTestSet1Script.updateStoreState(inputData);

        // 1.Login to connexus | User should be able to login
        //2.Drop an rx with primary payment method as TP | Rx should  move to Input Work queue
        //3.Complete Input for the rx | Rx should  move to Four point Work queue
        //4.Complete Four point for the rx | Rx should move to Filling Work queue
        //5.Open modify details screen and do switch to cash and click on accept | Rx should move to Four point Work queue
        //6.Complete Four Point for the rx | Rx should move to Filling Work queue
        //7.Change Payment type from TP to cash and complete filling for the rx. | Rx should move to Visual Verify Work queue
        //8.Complete Visual Verify for the rx | Rx should move to Bagging Work queue
        orderPickupTestSet1Script.dropAnRxTillBagging(inputData);
        //9.Complete Bagging for the rx | Rx should move to Pickup Work queue
        //10.Hit F11, search for the above patient and click on Check Out button | Switch To Cash pop up should be displayed
        //11.Select relationship and click on Accept. | should be selected successfully.
        //12.DL Id type pop will appear . | select the required DL ID type and state
        //13.CSID dl Capture screen will be shown  | Screen should be displayed
        //14.Enter all the details on the ID capture and hit accept | ID detail shall be saved
        orderPickupTestSet1Script.csidPickup(inputData);
        //15.Click on Pay Cash Price and give Fill Id and complete Pickup | Rx should move to Counsel Work queue
        //16.Complete Counsel for the rx | Rx should move to POS Work queue
        //17.Complete POS for the rx | Rx should be taken till EOD successfully
        orderPickupTestSet1Script.completeCounselAndEod();
        System.out.println("<<<tc_311567_CSID_Pickup>>>");
    }

}
