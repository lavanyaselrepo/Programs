package connexus.coretest.testcases;

import connexus.coretest.testscripts.AddCardinPatientProfileScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class AddCardinPatientTestSet {

    AddCardinPatientProfileScript addCardinPatientProfileScript = new AddCardinPatientProfileScript();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();

    @BeforeClass
    public void performlogin(){
        connexusAppUtils.readAndUpdateFlag("27151", "FALSE");
        connexusAppUtils.readAndUpdateFlag("29903", "TRUE");
        connexusAppUtils.startAppiumServer();
        addCardinPatientProfileScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    @Test(enabled = true, description = "HWPHME2E-1578 If we are able to add Visa cards to patient profile",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/AddCardDataBook.json", sheetName = "AddCard")
    public void HWPHME2E_1578_Add_Visa_Cards_Patient_Profile(Map<String, String> inputData) {
        String cardType = inputData.getOrDefault("cardType", "Visa");
        Reporter.log("HWPHME2E-1580 Add Visa Card to patient profile" + cardType);

        //Add Visa cards to patient profile
        addCardinPatientProfileScript.addVisaCardToPatient(inputData);
        Reporter.log("HWPHME2E-1578 If we are able to add Visa cards to patient profile");

    }

    @Test(enabled = true, description = " HWPHME2E-1580 Add Master Card to patient profile",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/AddCardDataBook.json", sheetName = "AddCard")
    public void HWPHME2E_1580_Add_Master_in_Patient_Profile(Map<String, String> inputData) {
        String cardType = inputData.getOrDefault("cardType", "Mastercard");
        Reporter.log("HWPHME2E-1580 Add Master Card to patient profile" + cardType);

        //Add Master Card to patient profile
        addCardinPatientProfileScript.addMasterCardToPatient(inputData);
        Reporter.log("HWPHME2E-1580 Add Master Card to patient profile");

    }


    @Test(enabled = true, description = "HWPHME2E-1577 If we are able to Amex starting with 37 cards to patient profile",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/AddCardDataBook.json", sheetName = "AddCard")
    public void HWPHME2E_1577_Add_Amex_Card_Starting_with_37(Map<String, String> inputData) {
        String cardType = inputData.getOrDefault("cardType", "Amex");
        Reporter.log("HWPHME2E-1580 Add Amex Card to patient profile" + cardType);

        //Amex starting with 37 cards to patient profile
        addCardinPatientProfileScript.addAmexCardstartwith37ToPatient(inputData);
        Reporter.log("HWPHME2E-1577 If we are able to Amex starting with 37 cards to patient profile");

    }

    @Test(enabled = true, description = "HWPHME2E-1579 If we are able to add Discover cards to patient profile",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/AddCardDataBook.json", sheetName = "AddCard")
    public void HWPHME2E_1579_Add_Discover_Cards_Patient_Profile(Map<String, String> inputData) {
        String cardType = inputData.getOrDefault("cardType", "Discover");
        Reporter.log("HWPHME2E-1580 Add Discover Card to patient profile" + cardType);

        //add Discover cards to patient profile
        addCardinPatientProfileScript.addDiscoverCardToPatient(inputData);
        Reporter.log("HWPHME2E-1579 If we are able to add Discover cards to patient profile");
    }
}
