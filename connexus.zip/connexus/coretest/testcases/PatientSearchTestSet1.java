package connexus.coretest.testcases;

import connexus.coretest.testscripts.PatientSearchTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import hwqe.baseframework.utilities.Reporter;

import java.util.Map;

public class PatientSearchTestSet1 {


    PatientSearchTestSetScript patientSearchTestSetScript = new PatientSearchTestSetScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils;
    public boolean flagUpdated = false;

    @BeforeClass
    public void performlogin(){
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify the Patient Search results on clicking Search Now button in Patient search screen
     * JIRA: HWCNXCLD-10264
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //HWPHME2E-364, Duplicate will be covered in TC 2452
    /*@Test(description = "To verify the Patient Search results on clicking Search Now button in Patient search screen", enabled = true, priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc01_Patient_Search_Verify_Search_Results_On_Clicking_Search_Now(Map<String, String> inputData) {
        System.out.println(">>>tc01_Patient_Search_Verify_Search_Results_On_Clicking_Search_Now<<<");

        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a Patient and verify the search results on Patient Search window
        patientSearchTestSetScript.searchForPatientAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc01_Patient_Search_Verify_Search_Results_On_Clicking_Search_Now>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether empty search results grid is displayed when no records found
     * JIRA: HWCNXCLD-10265
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //HWPHME2E-363, Duplicate will be covered in TC 2452
  /*  @Test(description = "To verify whether empty search results grid is displayed when no records found",
            enabled = true, priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc02_Patient_Search_Verify_Empty_Search_Results_Grid_When_No_Records_Found(Map<String, String> inputData) {
        System.out.println(">>>tc02_Patient_Search_Verify_Empty_Search_Results_Grid_When_No_Records_Found<<<");

        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a Patient which does not exist in current store and verify if search results grid is empty on Patient Search window
        patientSearchTestSetScript.enterPatientNameAndVerifyEmptySearchResultsGrid(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc02_Patient_Search_Verify_Empty_Search_Results_Grid_When_No_Records_Found>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether all details are displayed on clicking Search Now
     * JIRA: HWCNXCLD-10266
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether all details are displayed on clicking Search Now ",
            enabled = false, priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_361_Patient_Search_Verify_Whether_All_Details_Are_Displayed_On_Clicking_Search_Now(Map<String, String> inputData) {

        flagUpdated = connexusAppUtils.readAndUpdateFlag("5710", "TRUE");
        patientSearchTestSetScript.initializeTestCase(flagUpdated);

        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a Patient and verify all the search results on the results grid view on Patient Search window
        patientSearchTestSetScript.verifyAllSearchResultsOnSearchResultsGrid(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Patient Details verified on grid view on Patient Search window");

    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether search results grid is cleared on clicking New Search with OK button
     * JIRA: HWCNXCLD-10267
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //HWPHME2E-359 , Duplicate will be covered in TC 2452
   /* @Test(description = "To verify whether search results grid is cleared on clicking New Search with OK button",
            enabled = true, priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc04_Patient_Search_Verify_Whether_Search_Results_Grid_Cleared_On_Clicking_New_Search(Map<String, String> inputData) {
        System.out.println(">>>tc04_Patient_Search_Verify_Whether_Search_Results_Grid_Cleared_On_Clicking_New_Search<<<");

        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a Patient and verify the search results on Patient Search window
        patientSearchTestSetScript.searchForPatientAndVerifySearchResults(inputData);

        //3. Click on New Search button and verify if the Search Results are cleared on Patient Search window
        patientSearchTestSetScript.verifySearchResultsClearedOnClickingNewSearch();

        //4. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc04_Patient_Search_Verify_Whether_Search_Results_Grid_Cleared_On_Clicking_New_Search>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Patient maintenance screen is displayed on clicking New button
     * JIRA: HWCNXCLD-10268
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //HWPHME2E-360, Duplicate will be covered in TC 2452
   /* @Test(description = "To verify whether Patient maintenance screen is displayed on clicking New button",
            enabled = true,   priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc05_Patient_Search_Verify_Whether_Patient_Maintenance_Screen_Displayed_On_Clicking_New_Button(Map<String, String> inputData) {
        System.out.println(">>>tc05_Patient_Search_Verify_Whether_Patient_Maintenance_Screen_Displayed_On_Clicking_New_Button<<<");

        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. a. Search for a Patient which does not exist in current store and click on New button
        //   b. Verify whether the Patient Maintenance screen is displayed
        patientSearchTestSetScript.verifyPMSDisplayedOnClickingNewButton(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc05_Patient_Search_Verify_Whether_Patient_Maintenance_Screen_Displayed_On_Clicking_New_Button>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether Patient maintenance screen is displayed on double click on patient details
     * JIRA: HWCNXCLD-10269
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //HWPHME2E-362, Duplicate will be covered in TC 2452
   /* @Test(description = "To verify whether Patient maintenance screen is displayed on double click on patient details",
            enabled = true, priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc06_Patient_Search_Verify_Whether_Patient_Maintenance_Screen_Displayed_On_Double_Click_Patient_Search_Result(Map<String, String> inputData) {
        System.out.println(">>>tc06_Patient_Search_Verify_Whether_Patient_Maintenance_Screen_Displayed_On_Double_Click_Patient_Search_Result<<<");

        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a Patient and verify the search results on Patient Search window
        patientSearchTestSetScript.searchForPatientAndVerifySearchResults(inputData);

        //3. Double click on a record on the Patient Search window and verify whether Patient Maintenance screen is displayed
        patientSearchTestSetScript.verifyPMSDisplayedOnDoubleClickingPatientDetails();

        System.out.println("<<<tc06_Patient_Search_Verify_Whether_Patient_Maintenance_Screen_Displayed_On_Double_Click_Patient_Search_Result>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify the Patient search results from Search menu
     * JIRA: HWQEAUTO-8715
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify the Patient search results from Search menu",
            enabled = true,  priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_380_Patient_Search_Verify_Patient_Search_Results_From_Search_Menu(Map<String, String> inputData) {
        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window from Search Menu
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a Patient and verify the search results on Patient Search window
        patientSearchTestSetScript.searchForPatientAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        Reporter.log("Patient Search Verified from Search Menu");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the screen is navigated to main screen on clicking close button
     * JIRA: HWQEAUTO-8626
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //HWPHME2E-375, Duplicate will be covered in TC 2452
   /* @Test(description = "To verify whether the screen is navigated to main screen on clicking close button",
            enabled = true,   priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc08_Patient_Search_Verify_Whether_Screen_Navigated_To_Main_Screen_On_Clicking_Close_Button(Map<String, String> inputData) {
        System.out.println(">>>tc08_Patient_Search_Verify_Whether_Screen_Navigated_To_Main_Screen_On_Clicking_Close_Button<<<");

        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a Patient and verify the search results on Patient Search window
        patientSearchTestSetScript.searchForPatientAndVerifySearchResults(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        //4. Verify whether the screen is navigated back to main screen
        patientSearchTestSetScript.verifyWhetherNavigatedBackToMainScreen();

        System.out.println("<<<tc08_Patient_Search_Verify_Whether_Screen_Navigated_To_Main_Screen_On_Clicking_Close_Button>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the phone number 1 is displayed on result grid
     * JIRA: HWQEAUTO-8688
     *
     * Pre-Conditions:
     * 1. Restart Connexus after updating the flag 26849
     * 2. Login to Connexus as a HomeOffice user
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //This is duplciate of TC 365, Code need to be checked and removed
   /* @Test(description = "To verify whether the phone number 1 is displayed on result grid",
       enabled = true,     priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc09_Patient_Search_Verify_Whether_Phone_Number1_Displayed_On_Result_Grid(Map<String, String> inputData) {
        System.out.println(">>>tc09_Patient_Search_Verify_Whether_Phone_Number1_Displayed_On_Result_Grid<<<");

        //Pre-Condition: Check Flag 26849 and set it to TRUE and restart Connexus.
        //Adding comment for Relogin scenario.
       if (connexusAppUtils.readFlagValue("26849").get(0).get("phm_parm_value").toString().trim().equals("TRUE")) {
            patientSearchTestSetScript.closeConnexus();
            connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
            patientSearchTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
       }

        //1. Create a new patient with Phone Number 1 as the preferred number
        patientSearchTestSetScript.createPatientWithPhoneNumber1AsPreferredNumber(inputData);

        //2. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //3. Search for the Patient and verify whether the Phone Number from the search results matches
        //   with the given Phone Number 1 which is selected as preferred number while creating the patient
        patientSearchTestSetScript.searchForPatientAndVerifyPhoneNumber1(inputData);

        //4. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc09_Patient_Search_Verify_Whether_Phone_Number1_Displayed_On_Result_Grid>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the phone number 2 is displayed on result grid
     * JIRA: HWQEAUTO-8761
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //This is duplciate of TC 367, Code need to be checked and removed
  /*  @Test(description = "To verify whether the phone number 2 is displayed on result grid",
        enabled = true,    priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", dependsOnMethods = "tc09_Patient_Search_Verify_Whether_Phone_Number1_Displayed_On_Result_Grid")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc10_Patient_Search_Verify_Whether_Phone_Number2_Displayed_On_Result_Grid(Map<String, String> inputData) {
        System.out.println(">>>tc10_Patient_Search_Verify_Whether_Phone_Number2_Displayed_On_Result_Grid<<<");

        //1. Create a new patient with Phone Number 2 as Preferred Number
        patientSearchTestSetScript.createPatientWithPhoneNumber2AsPreferredNumber(inputData);

        //2. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //3. Search for the Patient and verify whether the Phone Number from the search results matches
        //   with the given Phone Number 2 which is selected as preferred number while creating the patient
        patientSearchTestSetScript.searchForPatientAndVerifyPhoneNumber2(inputData);

        //4. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc10_Patient_Search_Verify_Whether_Phone_Number2_Displayed_On_Result_Grid>>>");
    }*/

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the empty contact number displayed on result grid when phone1 and Phone 2 is not exist but messaging number is exist at patient profile
     * JIRA: HWQEAUTO-8617
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the empty contact number displayed on result grid when phone1 and Phone 2 is not exist but messaging number is exist at patient profile",
            enabled = false,  priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_373_Patient_Search_Verify_Whether_Empty_Contact_Number_Displayed_On_Result_Grid_When_Only_Messaging_Number_Exist(Map<String, String> inputData) {

        flagUpdated = connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
        patientSearchTestSetScript.initializeTestCase(flagUpdated);
        //1. Create a new patient with Messaging Number only (without Primary and Alternate numbers)
        patientSearchTestSetScript.createPatientWithMessagingNumberOnly(inputData);

        //2. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //3. Search for the Patient and verify whether the Phone Number field is empty
        patientSearchTestSetScript.searchForPatientAndVerifyIfPhoneNumberIsEmpty(inputData);

        //4. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

       // Reporter.log("Patient Messaging Contact number is present without Primary and Alernate numbers Verified on Search Grid.");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the address selected as primary address is displayed on search screen
     * JIRA: HWQEAUTO-8630
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the address selected as primary address is displayed on search screen",
            enabled = true,  priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_376_Patient_Search_Verify_Whether_Primary_Address_Displayed_On_Result_Grid(Map<String, String> inputData) {
        patientSearchTestSetScript.initializeTestCase(false);
        patientSearchTestSetScript.createPatientWithPrimaryPhoneNumber(inputData);
        // Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();
        //verify if rx number field is available
        patientSearchTestSetScript.verifyWhetherRxNbrAndStoreNbrTextFieldIsNotDisplayedOnPatientSearch();

        // Search for the Patient and verify whether the address selected as primary address is displayed on search screen
        patientSearchTestSetScript.verifyWhetherPrimaryAddressDisplayedOnPatientSearch(inputData);
        //verify if rx number field is available
        patientSearchTestSetScript.verifyWhetherRxNbrAndStoreNbrTextFieldIsDisplayedOnPatientSearch();

        // Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether last modified details are display when user modified any details on Patient Maintenance
     * JIRA: HWQEAUTO-8618
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether last modified details are display when user modified any details on Patient Maintenance",
            enabled = true, priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_374_Patient_Search_Verify_Whether_Modified_Details_Displayed_On_Result_Grid(Map<String, String> inputData) {
        patientSearchTestSetScript.initializeTestCase(false);
        //1. Create a new patient (using primary number as the preferred number based on the flag setting of previous test cases)
        patientSearchTestSetScript.createPatientWithPrimaryPhoneNumber(inputData);

        //2. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //3. Search for the Patient and verify whether the address selected as primary address is displayed on search screen
        patientSearchTestSetScript.verifyWhetherModifiedDetailsDisplayedOnPatientSearch(inputData);

        //4. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether the user able to enter RX number field without entering Name
     * JIRA: HWQEAUTO-8657
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether the user able to enter RX number field without entering Name",
            enabled = false, priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = "HWPHME2E_373_Patient_Search_Verify_Whether_Empty_Contact_Number_Displayed_On_Result_Grid_When_Only_Messaging_Number_Exist")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void HWPHME2E_378_Patient_Search_Verify_Whether_RX_Nbr_Field_Displayed_Only_After_Searching_Patient(Map<String, String> inputData) {
        patientSearchTestSetScript.initializeTestCase(false);
        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Verify whether the user not able to see RX number and Store number fields without performing patient search at least once.
        patientSearchTestSetScript.verifyWhetherRxNbrAndStoreNbrTextFieldIsNotDisplayedOnPatientSearch();

        //3. Search for a patient and verify whether user able to see RX number and Store number fields
        patientSearchTestSetScript.verifyWhetherRxNbrAndStoreNbrTextFieldIsDisplayedOnPatientSearch();

        //4. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description:To verify whether "Please use the following format "MM/DD/YYYY"pop up box message should be displayed when enter DD/MM/YYYY format at DOB field
     * JIRA: HWQEAUTO-8743
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus[

     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //HWPHME2E-383 , Duplciated covered in 382
  /*  @Test(description = "To verify whether \"Please use the following format \"MM/DD/YYYY\"pop up box message should be displayed when enter DD/MM/YYYY format at DOB field",
            enabled = true,   priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap", dependsOnMethods = "tc11_Patient_Search_Verify_Whether_Empty_Contact_Number_Displayed_On_Result_Grid_When_Only_Messaging_Number_Exist")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientSearchDataBook.json", sheetName = "PatientSearch")
    public void tc15_Patient_Search_Verify_Whether_Invalid_DOB_Popup_Displayed_When_Invalid_Date_Entered(Map<String, String> inputData) {
        System.out.println(">>>tc15_Patient_Search_Verify_Whether_Invalid_DOB_Popup_Displayed_When_Invalid_Date_Entered");

        //1. Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientSearchTestSetScript.openPatientSearchWindow();

        //2. Search for a patient with an invalid date in DOB field and verify whether an error message displayed and this method also closes the Patient Search window
        patientSearchTestSetScript.verifyWhetherInvalidDOBPopUpDisplayedWhenSearchedWithInvalidDate(inputData);

        //3. Click on Close button to close the Patient Search window
        patientSearchTestSetScript.closePatientSearchWindowByClickingOnCloseButton();

        System.out.println("<<<tc15_Patient_Search_Verify_Whether_Invalid_DOB_Popup_Displayed_When_Invalid_Date_Entered");
    }*/
}
