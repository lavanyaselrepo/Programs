package connexus.coretest.testcases;

import connexus.coretest.testscripts.PatientMaintenanceScreenScript;
import connexus.coretest.testscripts.PatientSearchTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreen4 {

    PatientMaintenanceScreenScript patientMaintenanceScreenScript = new PatientMaintenanceScreenScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils;
    boolean relaunchConnexus = false;

    @BeforeClass
    public void performlogin(){
        connexusAppUtils = new ConnexusAppUtils();
        AutomationManager.getInstance().performSleep(5);
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    @Test(description = "Validate adding Allergy on the Patient Profile & deactivating the Allergy",
            enabled = true, priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath ="TestData/Connexus/CoreTest/PatientMaintenanceScreenDataBook.json", sheetName = "PatientMaintenance")
    public void HWPHME2E_2251_Validate_adding_Allergy_on_Patient_Profile_and_deactivating_Allergy(Map<String, String> inputData) {

        patientMaintenanceScreenScript.initializeTestCase(relaunchConnexus);
        // Create Patient
        patientMaintenanceScreenScript.createPatientWithAllNumbers(inputData);

        // Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientMaintenanceScreenScript.openPatientSearchWindow();

        // Search for a Patient and verify all the search results on the results grid view on Patient Search window
        patientMaintenanceScreenScript.searchForPatientAndVerifySearchResults(inputData);

        // Add Allergy to Patient
        patientMaintenanceScreenScript.addAllergyDetails(inputData);

        // Deactivate Allergy to Patient
        patientMaintenanceScreenScript.deactivateAllergyDetails(inputData);

        //4.Validate  Allergy from DB
        patientMaintenanceScreenScript.verifyAllergyDetailsInDb();
        Reporter.log("Patient Details verified on grid view on Patient Search window");
    }

    @Test(description = "Validate adding Primary Third Party Details on PTMS",
            enabled = true,  priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintenanceScreenDataBook.json", sheetName = "PatientMaintenance")
    public void HWPHME2E_2246_Validate_adding_Primary_Third_Party_Details_on_PTMS(Map<String, String> inputData) {

        patientMaintenanceScreenScript.initializeTestCase(relaunchConnexus);
        // Create patient
        patientMaintenanceScreenScript.createNewPatient(inputData,1);

        //open search window
        patientMaintenanceScreenScript.openPatientSearchWindow();

        // Search for a Patient and verify the search results on Patient Search window
        patientMaintenanceScreenScript.searchForPatientAndVerifySearchResults(inputData);

        Reporter.log("Validated Adding Primary Third Party Details on PTMS");
    }

    @Test(description = "Validating adding secondary Third Party Details on PTMS",
            enabled = true,  priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintenanceScreenDataBook.json", sheetName = "PatientMaintenance")
    public void HWPHME2E_2248_Validating_adding_secondary_Third_Party_Details_on_PTMS(Map<String, String> inputData) {

        patientMaintenanceScreenScript.initializeTestCase(relaunchConnexus);
        //Log Store Number
        connexusAppUtils.getStoreId();

        //Create Patient
        patientMaintenanceScreenScript.createNewPatient(inputData,2);

        // Open Patient Search window from Search Menu
        patientMaintenanceScreenScript.openPatientSearchWindow();

        // Search for a Patient and verify the search results on Patient Search window
        patientMaintenanceScreenScript.searchForPatientAndVerifySearchResults(inputData);
        Reporter.log("Validated Adding secondary Third Party Details on PTMS");
    }

    @Test(description = "Validate Reactivating the Deactivated Third Party on Patient Profile",
            enabled = true,  priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CoreTest/PatientMaintenanceScreenDataBook.json", sheetName = "PatientMaintenance")
    public void HWPHME2E_2247_Validate_Reactivating_the_Deactivated_Third_Party_on_Patient_Profile(Map<String, String> inputData) {

        patientMaintenanceScreenScript.initializeTestCase(relaunchConnexus);
        //Create Patient
        patientMaintenanceScreenScript.createNewPatient(inputData,1);

        // Open Patient Search window by pressing Keyboard shortcut CTRL + SHIFT + P
        patientMaintenanceScreenScript.openPatientSearchWindow();

        // Click on Close button to close the Patient Search window
        patientMaintenanceScreenScript.DiscontinueThirdPartyDetailsAnReactivatingPlan(inputData);

        //Complete Drop off
        patientMaintenanceScreenScript.performDropOff(Priority.Critical);

        //Complete Input
        patientMaintenanceScreenScript.performInput(inputData);

        //Complete 4Point
        patientMaintenanceScreenScript.perform4Point(false);

        //Complete Filling
        patientMaintenanceScreenScript.performFilling();

        //Complete Visual Verify
        patientMaintenanceScreenScript.performVisualVerify();

        //Check Payment Method
        patientMaintenanceScreenScript.checkPaymentMethodInPickup();
        Reporter.log("Validated Reactivating the Deactivated Third Party on Patient Profile.");
    }
}
