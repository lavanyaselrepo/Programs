package connexus.OrderCreation;


import bom.tests.WrapperTestScript;
import connexus.OrderCreation.testscripts.OrderCreationCommonFunctions;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import java.util.Map;

public class OrderCreationTestSet {
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    OrderCreationCommonFunctions orderCreationCommonFunctions=new OrderCreationCommonFunctions(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    public static LoginAs.userType loginUser_Type_PHARMACIST= LoginAs.userType.PHARMACIST_ADFlagOff;
    boolean flagUpdated = false;

    @BeforeClass
    public void performLogin() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
             * Test Description:TC005_Naloxone_SO_Order_Process_Till_EOD(E2E) for Protocol/SO order type
             *
             * Pre-Conditions: 1. Set the store state as : AL
                               2. To enable the 'Protocol / SO order type' radio button for State Specific standing order:
                                  StandingOrderNXSettingsFlag = 14118 - in agency_rqmt_parm table should be set as 'TRUE'
                                  select * from agency_rqmt_parm where restrict_type_code = '14118' and issue_agency_code = 200 (should be true )
             * Author: Narayanaswamy(N0s06rk)
             ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "TC005_Naloxone_SO_Order_Process_Till_EOD(E2E)_for_Protocol/SO_order_type",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_335(Map<String, String> inputData) {

        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AL");
        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        flagUpdated |= connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("14137", "TRUE");
        String statecode = connexusAppUtils.fetchIssueAgencyCodeOfState("AL");
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("FALSE", "14120", statecode);
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("TRUE", "14118", statecode);
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,false);
        orderCreationCommonFunctions.loginConnexus(loginUser_Type_PHARMACIST);
        orderCreationCommonFunctions.createNewPatient(inputData);
        orderCreationCommonFunctions.performNaloxoneDropOff();
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performChkDUR();
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.performVisualVerify();
        orderCreationCommonFunctions.performPickUp(inputData);
        orderCreationCommonFunctions.performCounselling();
        orderCreationCommonFunctions.performPOS();
    }


    /*----------------------------------------------------------------------------------------------------------
      * Test Description:TC005_Naloxone_SO_Order_Process_Till_EOD(E2E) for Protocol/SO order type
      *
      * Pre-Conditions: 1. Set the store state as : AL
                        2. To enable the 'Protocol / SO order type' radio button for State Specific standing order:
                           StandingOrderNXSettingsFlag = 14118 - in agency_rqmt_parm table should be set as 'TRUE'
                           select * from agency_rqmt_parm where restrict_type_code = '14118' and issue_agency_code = 200 (should be true )
      *
      * Author: Narayanaswamy(N0s06rk)
      ----------------------------------------------------------------------------------------------------------*/


    @Test(enabled = true, description = "TC011_Naloxone_SO_Order_Process till EOD(E2E flow) for RPH Issued Order Type",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_334(Map<String, String> inputData) {
        Reporter.log("<<<TC01_Naloxone_RPH Issued_Order_Process_Till_EO>>>");
        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        flagUpdated |= connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("WV");
        String statecode = connexusAppUtils.fetchIssueAgencyCodeOfState("WV");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("14137", "TRUE");
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("FALSE", "14118", statecode);
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("TRUE", "14120", statecode);
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,false);
        orderCreationCommonFunctions.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        orderCreationCommonFunctions.createNewPatient(inputData);
        orderCreationCommonFunctions.performNaloxoneDropOffForPatient();
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performChkDUR();
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.performVisualVerify();
        orderCreationCommonFunctions.performPickUp(inputData);
        orderCreationCommonFunctions.performCounselling();
        orderCreationCommonFunctions.performPOS();
        Reporter.log("<<<TC01_Naloxone_RPH Issued_Order_Process_Till_EO>>>");

    }

    /*----------------------------------------------------------------------------------------------------------
          * Test Description:Verify whether site id is displaying in Consolidated Notes Screen when we add the order comments in Double check 4 point queue
          *
          * Pre-Conditions: 1. Update the state to MN
                            2. Double 4-point check should be true (select * from agency_rqmt_parm where restrict_type_code=9102 and issue_agency_code=223)
          *JIRA Testcase id : HWPHME2E-308
          * Author: Narayanaswamy(N0s06rk)
          ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify whether site id is displaying in Consolidated Notes Screen when we add the order comments in Double check 4 point queue",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_308(Map<String, String> inputData) {
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("MN");
        String statecode = connexusAppUtils.fetchIssueAgencyCodeOfState("MN");
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y", "9102", statecode);
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        orderCreationCommonFunctions.createNewPatient(inputData);
        orderCreationCommonFunctions.performDropOff();
        orderCreationCommonFunctions.performInput(inputData);
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performChkDUR();
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.performVisualVerify();
        orderCreationCommonFunctions.performPickUp(inputData);
        orderCreationCommonFunctions.performCounselling();
        orderCreationCommonFunctions.performPOS();
        orderCreationCommonFunctions.initializeTestCase(false,false);
        orderCreationCommonFunctions.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        orderCreationCommonFunctions.performDouble4Point();
        orderCreationCommonFunctions.verifyRxInEOD();

        Reporter.log("Verified that site id is displaying in Consolidated notes when logged in by Pharmacist");
    }

    /*----------------------------------------------------------------------------------------------------------
            * Test Description:Verify that Rx will not go On-Hold after Double 4-point when when the store is configured to MN State
            *
            * Pre-Conditions: 1. Update the state to MN
                              2. Double 4-point check should be true (select * from agency_rqmt_parm where restrict_type_code=9102 and issue_agency_code=223)
            *JIRA Testcase id : HWPHME2E-309
            * Author: Narayanaswamy(N0s06rk)
            ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify that Rx will not go On-Hold after Double 4-point when when the store is configured to MN State",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_309(Map<String, String> inputData) {
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("MN");
        String statecode = connexusAppUtils.fetchIssueAgencyCodeOfState("MN");
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y", "9102", statecode);
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("14305", "TRUE");
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        orderCreationCommonFunctions.createNewPatient(inputData);
        orderCreationCommonFunctions.performDropOff();
        orderCreationCommonFunctions.performInput(inputData);
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performChkDUR();
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.performVisualVerify();
        orderCreationCommonFunctions.performPickUp(inputData);
        orderCreationCommonFunctions.performCounselling();
        orderCreationCommonFunctions.performPOS();
        orderCreationCommonFunctions.initializeTestCase(false,false);
        orderCreationCommonFunctions.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        orderCreationCommonFunctions.performDouble4Point();
        orderCreationCommonFunctions.verifyRxInEOD();
        orderCreationCommonFunctions.getNoOfRxNotes();
        Reporter.log("Verified that Rx is not going in on hold, reached till EOD when logged in by Pharmacist");
    }

    /*----------------------------------------------------------------------------------------------------------
            * Test Description:PI14_HWOC_Sprint1_OnHold1_Double 4-Pt_TC017
            *
            * Pre-Conditions: 1. Update the state to MN
            * Author: Narayanaswamy(N0s06rk)
            ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "PPI_IMZ_4Pt_SO_Modify_edit_29",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_314(Map<String, String> inputData) {

        flagUpdated = connexusAppUtils.readAndUpdateStoreState("GA");
        String statecode = connexusAppUtils.fetchIssueAgencyCodeOfState("GA");
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("TRUE", "15102", statecode);
        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
        //        flagUpdated |= connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
//        orderCreationCommonFunctions.initializeTestCase(flagUpdated,false);
        orderCreationCommonFunctions.initializeTestCase(false,false);
        orderCreationCommonFunctions.loginConnexus(loginUser_Type_PHARMACIST);
        orderCreationCommonFunctions.createNewPatient(inputData);
        orderCreationCommonFunctions.performIMZDropOff();
        orderCreationCommonFunctions.verifyIMZModufyDetails();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:PI14_HWOC_Sprint1_OnHold1_Double 4-Pt_TC017
     * Pre-Conditions: 1. Update the state to MN
     * Author: Narayanaswamy(N0s06rk)


     *     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Edit option for Third party Days Supply text box",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "BOMOrderCreation")
    public void HWPHME2E_326(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData, "HWPHME2E_322 - Disable TP Days Supply");
        Integer rxNbr = stagedClaimData.getRxNbr();
        String rxNbrStr = rxNbr != null ? rxNbr.toString() : null;
        orderCreationCommonFunctions.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        orderCreationCommonFunctions.verifyThirdPartyDaysSupplyField(rxNbrStr, WorkQueue.RESOLVE, true, "enabled");
        orderCreationCommonFunctions.clickCancelBtn();
        AutomationManager.getInstance().getConnexus().closeConnexus();
        Reporter.log("<<<Edit option for Third party Days Supply text box>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
        * Test Description:Disable option for Third party Days Supply text box
        *
        *         * Author: Narayanaswamy(N0s06rk)        * Pre-Conditions: 1. Update the state to MN

        ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Disable option for Third party Days Supply text box",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "BOMOrderCreation")
    public void HWPHME2E_322(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData, "HWPHME2E_322 - Disable TP Days Supply");
        Integer rxNbr = stagedClaimData.getRxNbr();
        String rxNbrStr = rxNbr != null ? rxNbr.toString() : null;
        orderCreationCommonFunctions.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        orderCreationCommonFunctions.verifyThirdPartyDaysSupplyField(rxNbrStr, WorkQueue.FOUR_POINT, false, "disabled");
        orderCreationCommonFunctions.clickCancelBtn();
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
        * Test Description:‘addition_val’ column when value is removed/entered 0 in ‘Third party days supply’ textbox
        * Pre-Conditions: 1. Update the state to MN
        *  Query:SELECT addition_val from clm_override_addtn WHERE rx_fill_id= ? AND addtn_class_code = 23232
        *         * Author: Narayanaswamy(N0s06rk)
        ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "‘addition_val’ column when value is removed/entered 0 in ‘Third party days supply’ textbox",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "BOMOrderCreation")
    public void HWPHME2E_325(Map<String, Object> inputData) {
        Reporter.log("<<<‘addition_val’ column when value is removed/entered 0 in ‘Third party days supply’ textbox>>>");
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData, "HWPHME2E_325 - addition_val’ column when value is removed");
        Integer rxNbr = stagedClaimData.getRxNbr();
        Integer patientId = stagedClaimData.getPatientId();
        String patientIdStr = patientId != null ? patientId.toString() : null;
        String rxNbrStr = rxNbr != null ? rxNbr.toString() : null;
        orderCreationCommonFunctions.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        orderCreationCommonFunctions.verifyTPdaysSupplyOnTPInfoPage(rxNbrStr, patientIdStr);
        Reporter.log("No record in database for this fill id.");
    }

    /*----------------------------------------------------------------------------------------------------------
        * Test Description:Third party days supply value from F10 in claim details screen
        * Pre-Conditions: 1. Update the state to AL
        *  Query:SELECT addition_val from clm_override_addtn WHERE rx_fill_id= ? AND addtn_class_code = 23232
        *         * Author: Narayanaswamy(N0s06rk)
        ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Third party days supply value from F10 in claim details screen",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "BOMOrderCreation")
    public void HWPHME2E_323(Map<String, Object> inputData) {
        Reporter.log("<<<Third party days supply value from F10 in claim details screen>>>");
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData, "HWPHME2E_323 - Third party days supply value from F10");
        Integer rxNbr = stagedClaimData.getRxNbr();
        String rxNbrStr = rxNbr != null ? rxNbr.toString() : null;
        orderCreationCommonFunctions.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        orderCreationCommonFunctions.verifyThirdPartyDaysSupplyField(rxNbrStr, WorkQueue.RESOLVE, true, "enabled");
        orderCreationCommonFunctions.verifyTPDaysSupplyValueWithValue(rxNbrStr,"10", true, "matched");
    }

    /*----------------------------------------------------------------------------------------------------------
        * Test Description:HWQEAUTO_4354
        * Pre-Conditions: 1. Update the state to MN
        *  1.Flag 31153 should be ON.
        *  2.Drugs having High Audit risk restriction should be selected.
        *         * Author: Narayanaswamy(N0s06rk)
        ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify the message in modify details screen when " +
            "opened from other screens(VV/4point) for SIG codes like TAD, UAD, UD, or TUD.",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "BOMOrderCreation")
    public void HWPHME2E_330(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData, "HWPHME2E_322 - Message in modify details screen");
        Integer rxNbr = stagedClaimData.getRxNbr();
        String rxNbrStr = rxNbr != null ? rxNbr.toString() : null;
        orderCreationCommonFunctions.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        orderCreationCommonFunctions.verifyDirectionOfUse(rxNbrStr);
        orderCreationCommonFunctions.clickCancelBtn();
    }

    /*----------------------------------------------------------------------------------------------------------
       * Test Description:HWQEAUTO_4354
       * Pre-Conditions: 1. Update the state to MN
       *  1.Flag 31153 should be ON.
       *  2.Drugs having High Audit risk restriction should be selected.
       *         * Author: Narayanaswamy(N0s06rk)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "TC003_Cash_To_TP_ Pickup",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_327(Map<String, String> inputData) {
        orderCreationCommonFunctions.initializeTestCase(false,true);
        orderCreationCommonFunctions.createNewPatient(inputData,1);
        orderCreationCommonFunctions.performDropOff();
        orderCreationCommonFunctions.performInput(inputData);
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performChkDUR();
        orderCreationCommonFunctions.switchToCASHFromTP();
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.performVisualVerify();
        orderCreationCommonFunctions.switchToTPFromCASH(inputData);
        orderCreationCommonFunctions.verifyWorkQueue(WorkQueue.PICKUP);


    }

    /*----------------------------------------------------------------------------------------------------------
       * Test Description:HWQEAUTO_1133
       * Pre-Conditions:
       * Author: Narayanaswamy(N0s06rk)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "TC005_TP_To_TP_ Filling_Refill",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_328(Map<String, String> inputData) {
        Reporter.log("<<<TC005_TP_To_TP_ Filling_Refill>>>");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        orderCreationCommonFunctions.createNewPatient(inputData,2);
        orderCreationCommonFunctions.performDropOff();
        orderCreationCommonFunctions.performInput(inputData);
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.performVisualVerify();
        orderCreationCommonFunctions.performPickUp(inputData);
        orderCreationCommonFunctions.performCounselling();
        orderCreationCommonFunctions.performPOS();
        orderCreationCommonFunctions.performDropOffForARXWithNoRefills();
        orderCreationCommonFunctions.verifyIfRxIsInResolutionQueue();
        orderCreationCommonFunctions.performRefillsAuthorized(inputData);
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performChkDUR();
        orderCreationCommonFunctions.changeTPtoTP(inputData, WorkQueue.FILLING);
        Reporter.log("Because of changes made to this fill, it's being sent to Third Party queue");

    }
}