package connexus.OrderCreation;

import connexus.OrderCreation.testscripts.OrderCreationCommonFunctions;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import hwqe.baseframework.utilities.Reporter;
import java.util.Map;

public class OrderCreationTestSet1 {
    OrderCreationCommonFunctions orderCreationCommonFunctions=new OrderCreationCommonFunctions(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    boolean flagUpdated = false;

    @BeforeClass
    public void performlogin() {
        connexusAppUtils.startAppiumServer();
        CheckAndSetPreConditions();

    }

    @AfterClass
    public void tearDown() {
        connexusAppUtils.stopAppiumServer();
    }

    private void CheckAndSetPreConditions() {
        //Set the state to AR for the current store
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("32550", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31053", "TRUE");

        //Verify and set the flag 28750 (AD Authentication) to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("28750", "TRUE");

        //Verify and set the flag 26849 (Redesign Contact Information) to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("26849", "TRUE");

        //Verify and set the flag 8670 (Enable/Disable Bagging queue) to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("8670", "FALSE");

        //Verify and set the flag 26218 (Bagging Queue Enabled) to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("26218", "FALSE");

        //Verify and set the flag 15166 (Flag to Enable ABN Changes) to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15166", "TRUE");

        //Verify and set the flag 24550 (Advanced Beneficiary Notice (ABN) Requirement) to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("24550", "FALSE");

        //Verify that Max Daily Dose Altered Flag is set to True
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31153", "TRUE");

        flagUpdated |= connexusAppUtils.isManualMTRItemFilled();

        //Set the central patient flag to FALSE, to avoid getting golden record after update
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("26846","FALSE");
    }



/*----------------------------------------------------------------------------------------------------------
         * Test Description:TC013_Drug_Change_ ChkDUR_TP
         *
         * Pre-Conditions:
         * Author: Narayanaswamy(N0s06rk)
         ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "TC013_Drug_Change_ChkDUR_TP",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_303(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        orderCreationCommonFunctions.createNewPatient(inputData,1);
        orderCreationCommonFunctions.performDropOff();
        orderCreationCommonFunctions.performInput(inputData);
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performModifyDrugAtAnyWorkqueue(WorkQueue.CHK_DUR.getWorkQueue(),inputData);
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performChkDUR();
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.performVisualVerify();
        orderCreationCommonFunctions.performPickUp(inputData);
        orderCreationCommonFunctions.performCounselling();
        orderCreationCommonFunctions.performPOS();
    }

/*----------------------------------------------------------------------------------------------------------
         * Test Description:TC013_Drug_Change_ ChkDUR_TP
         *
         * Pre-Conditions:
         * Author: Narayanaswamy(N0s06rk)
         ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "TC015_Drug_Change_VV_TP_Rej",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_304(Map<String, String> inputData)
    {

        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        orderCreationCommonFunctions.createNewPatient(inputData,1);
        orderCreationCommonFunctions.performDropOff();
        orderCreationCommonFunctions.performInput(inputData);
        orderCreationCommonFunctions.performResolution();
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performChkDUR();
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.performModifyDrugAtAnyWorkqueue(WorkQueue.VISUAL_VERIFY.getWorkQueue(),inputData);
        Reporter.log("RX moved to Third Party Rejection/Failure workqueue, when drug is changed from VV modify details screen for the RX with TP rejection as primary payment method");
        orderCreationCommonFunctions.performResolution();

    }

    /*----------------------------------------------------------------------------------------------------------
             * Test Description:TC068_partial_fill_unchecked_final_fill_resolution_void_remaining
             *
             * Pre-Conditions:
             * Author: Narayanaswamy(N0s06rk)
             ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "TC068_partial_fill_unchecked_final_fill_resolution_void_remaining",priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_152(Map<String, String> inputData) {
        Reporter.log("<<<TC068_partial_fill_unchecked_final_fill_resolution_void_remaining>>>");
        flagUpdated = connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        orderCreationCommonFunctions.createNewPatient(inputData);
        orderCreationCommonFunctions.performDropOff();
        orderCreationCommonFunctions.performInput(inputData);
        orderCreationCommonFunctions.perform4Point(true);
        orderCreationCommonFunctions.performChkDURRedFlag(inputData);
        orderCreationCommonFunctions.selectOrDeselectVoidRemaingCheckBox(0);
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.performPartialFill(WorkQueue.VISUAL_VERIFY.getWorkQueue());
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.uncheckVoidRemaingCheckBox(1);
        orderCreationCommonFunctions.verifyVoidRemaingCheckBoxDisabled(0);
        Reporter.log("Void remaining checkbox is unchecked and disabled");
        Reporter.log("<<<TC068_partial_fill_unchecked_final_fill_resolution_void_remaining>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
            * 417779_Add Order Comments_Double Check 4point_TC004
            *
            * Pre-Conditions: 1. Update the state to MN
                              2. Double 4-point check should be true (select * from agency_rqmt_parm where restrict_type_code=9102 and issue_agency_code=223)
            *[
            * Author: Narayanaswamy (N0s06rk)
            ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "417779_Add Order Comments_Double Check 4point_TC004",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWQEAUTO_1115(Map<String, String> inputData) {
        Reporter.log("<<<417779_Add Order Comments_Double Check 4point_TC004>>>");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("MN");
        String statecode = connexusAppUtils.fetchIssueAgencyCodeOfState("MN");
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y", "9102", statecode);
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("14305", "TRUE");
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        orderCreationCommonFunctions.createNewPatient(inputData);
        orderCreationCommonFunctions.performDropOff();
        orderCreationCommonFunctions.performInput(inputData);
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performChkDUR();
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.performVisualVerify();
        orderCreationCommonFunctions.performPickUp(inputData);
        orderCreationCommonFunctions.performCounselling();
        orderCreationCommonFunctions.performPOS();
        orderCreationCommonFunctions.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        orderCreationCommonFunctions.performDouble4Point();
        orderCreationCommonFunctions.verifyRxInEOD();
        orderCreationCommonFunctions.getNoOfRxNotes();
        Reporter.log("<<<417779_Add Order Comments_Double Check 4point_TC004>>>");

    }
    /*----------------------------------------------------------------------------------------------------------
           * To verify whether TP is getting reversed for an ERx pending in Future fill resolution
           *
           * Pre-Conditions:
           * Author: Narayanaswamy(N0s06rk)
           ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "To verify whether TP is getting reversed for an ERx pending in Future fill resolution",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_333(Map<String, String> inputData) {

        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        orderCreationCommonFunctions.createNewPatient(inputData,1);
        orderCreationCommonFunctions.sendErxMessage("surescriptFutureFill",inputData);
        Reporter.log("ERx is sent for the patient from surescript and move till 4 point with non controlled drug");
        orderCreationCommonFunctions.performInput(inputData);
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.verifyClaimSubmission("Reversed");
        Reporter.log("<<<To verify whether TP is getting reversed for an ERx pending in Future fill resolution>>>");

    }
    /*----------------------------------------------------------------------------------------------------------
           * Verify Status of RX -Cancel fill when original fill didn't cross pickup for patient with Third Party Profile
           *
           * Pre-Conditions:
           * Author: Narayanaswamy(N0s06rk)
           ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify Status of RX -Cancel fill when original fill didn't cross pickup for patient with Third Party Profile",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_311(Map<String, String> inputData) throws InterruptedException {
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.createNewPatientWithTPViaAPI(inputData);
        orderCreationCommonFunctions.moveOrderFromDropOffToVVViaAPI(inputData);
        orderCreationCommonFunctions.verifyWorkQueue(WorkQueue.VISUAL_VERIFY.getWorkQueue());
        orderCreationCommonFunctions.performDropOffForRXWithNoRefills();
        orderCreationCommonFunctions.verifyIfRxIsInResolutionQueue();
        orderCreationCommonFunctions.performRefillsAuthorized(inputData);
        orderCreationCommonFunctions.moveOrderFrom4PointToFillingViaAPI();
        orderCreationCommonFunctions.verifyWorkQueue(WorkQueue.FILLING.getWorkQueue());
        orderCreationCommonFunctions.performDropOffForRXWithNoRefills();
        orderCreationCommonFunctions.verifyIfRxIsInResolutionQueue();
        orderCreationCommonFunctions.performRefillsAuthorized(inputData);
        orderCreationCommonFunctions.moveOrderFrom4PointToFillingViaAPI();
        orderCreationCommonFunctions.verifyWorkQueue(WorkQueue.FILLING.getWorkQueue());
        orderCreationCommonFunctions.sendErxMessage("cancelsurescriptrequest", inputData);
        orderCreationCommonFunctions.performCancelPrescriptions();
        orderCreationCommonFunctions.verifyRxStatusFromDropOff("Canceled");
        orderCreationCommonFunctions.dropoffActions();
    }


    /*----------------------------------------------------------------------------------------------------------
           *  Verify status of Rx-Cancel fill when original fill crossed pickup for Patient with Third Party Profile
           *
           * Pre-Conditions:
           * Author: Narayanaswamy(N0s06rk)
           ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true
            , description = "Verify status of Rx-Cancel fill when original fill " +
            "crossed pickup for Patient with Third Party Profile",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_312(Map<String, String> inputData) {
        Reporter.log("<<<Verify status of Rx-Cancel fill when original fill" +
                " crossed pickup for Patient with Third Party Profile>>>");
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.createNewPatientWithTPViaAPI(inputData);
        // Use API to move order from DropOff through Pickup to Counsel queue
        orderCreationCommonFunctions.moveOrderToCounselViaAPI(inputData);
        orderCreationCommonFunctions.verifyWorkQueue(WorkQueue.COUNSEL.getWorkQueue());
        orderCreationCommonFunctions.performDropOffForRXWithNoRefills();
        orderCreationCommonFunctions.verifyIfRxIsInResolutionQueue();
        orderCreationCommonFunctions.performRefillsAuthorized(inputData);
        orderCreationCommonFunctions.moveOrderFrom4PointToVVViaAPI();
        orderCreationCommonFunctions.verifyWorkQueue(WorkQueue.VISUAL_VERIFY.getWorkQueue());
        orderCreationCommonFunctions.performDropOffForRXWithNoRefills();
        orderCreationCommonFunctions.verifyIfRxIsInResolutionQueue();
        orderCreationCommonFunctions.performRefillsAuthorized(inputData);
        orderCreationCommonFunctions.moveOrderFrom4PointToFillingViaAPI();
        orderCreationCommonFunctions.verifyWorkQueue(WorkQueue.FILLING.getWorkQueue());
        orderCreationCommonFunctions.sendErxMessage("cancelsurescriptrequest",inputData);
        orderCreationCommonFunctions.performCancelPrescriptions();
        orderCreationCommonFunctions.verifyRxStatusFromDropOff("Canceled");
        orderCreationCommonFunctions.dropoffActions();
    }
     /*----------------------------------------------------------------------------------------------------------
           *  Verify status of Rx-Cancel fill when original fill crossed pickup for Patient with Third Party Profile
           *
           * Pre-Conditions:
           * Author: Narayanaswamy(N0s06rk)
           ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "To Verify the status of Rx when a " +
            "cancel request is sent for which the original fill is in EOD.",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_305(Map<String, String> inputData) {

        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        orderCreationCommonFunctions.createNewPatient(inputData);
        // Use API to move order from DropOff through POS to EOD queue
        orderCreationCommonFunctions.moveOrderToEODViaAPI(inputData);
        orderCreationCommonFunctions.verifyWorkQueue(WorkQueue.EOD.getWorkQueue());
        orderCreationCommonFunctions.sendErxMessage("cancelsurescriptrequest",inputData);
        orderCreationCommonFunctions.performCancelPrescription();
        orderCreationCommonFunctions.verifyRxStatusFromDropOff("Canceled");
        orderCreationCommonFunctions.dropoffActions();

    }
}