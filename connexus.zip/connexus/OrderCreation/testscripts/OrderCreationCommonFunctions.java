package connexus.OrderCreation.testscripts;

import bom.resources.BomUtils;
import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import connexus.OrderCreation.testcases.OrderCreationRegressionTestSet1;
import connexus.OrderCreation.testcases.OrderCreationRegressionTestSet2;
import connexus.OrderCreation.testcases.OrderCreationRegressionTestSet4;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.joda.time.DateTime;
import org.openqa.selenium.Keys;
import org.testng.Assert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class OrderCreationCommonFunctions extends ConnexusTestScripts {

    BomUtils bomUtils = new BomUtils();

    public OrderCreationCommonFunctions(LoginAs.userType loginUserType){
        super(loginUserType);
    }

    public Boolean isTaskOrderCreated = false;

    public void discontinueAndAddSameTPPlan(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            patientSearchPage.launchPatientSearchScreen();
            if(patientSearchPage.isPatientSearchWindowDisplayed()) {
                patientSearchPage.inputPatientName(name[0] + "," + name[1]);
                patientSearchPage.clickSearchNow();
                softAssert.assertTrue(patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(name[0] + "," + name[1]));
                patientSearchPage.openFirstPatientRecord();
                Reporter.logScreenShot(Status.INFO, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                String newCardId ="12345";
                patientMaintenancePage.discontinueNAddTpPlan(patient.getPatientTp().getCarrierBin(),newCardId,patient.getPatientTp().getPlan());
                automationManager.performSleep(10);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.clickSaveAndClose();
            }else
            {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Patient search screen not launched");
            }
        } catch (Throwable e) {
            isExceptionCaptured=true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    // discontinueAndAddSameTPPlan with patient details
    public void discontinueAndAddSameTPPlan(Map<String, Object> patientName, String carrierBin, String plan) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            patientSearchPage.launchPatientSearchScreen();
            if (patientSearchPage.isPatientSearchWindowDisplayed()) {
                patientSearchPage.inputPatientName(patientName.get("last_name").toString().trim() + "," + " " + patientName.get("first_name").toString().trim());
                patientSearchPage.clickSearchNow();
                automationManager.performSleep(5);
                softAssert.assertTrue(patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(patientName.get("first_name").toString().trim() + "," + patientName.get("last_name").toString().trim()));
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.INFO, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                String newCardId = bomUtils.getRandId(5);
                patientMaintenancePage.setPatientAllergy(PatientMedicalConditionModel.Allergies.NO);
                patientMaintenancePage.discontinueNAddTpPlan(carrierBin, newCardId, plan);
                automationManager.performSleep(10);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.clickSaveAndClose();
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Patient search screen not launched");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void createNewPatientWith2TPPlans(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Initialize model objects before use (only if not already set)
            if (patient == null) patient = new PatientProfileModel();
            if (addressModel == null) addressModel = new AddressModel();
            if (thirdPartyModel == null) thirdPartyModel = new ThirdPartyModel();
            if (contactModel == null) contactModel = new ContactModel();
            if (patientMedicalConditionModel == null) patientMedicalConditionModel = new PatientMedicalConditionModel();

            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            thirdPartyModel.setCarrierBin(inputData.get("TP_CARRIER_BIN"));
            thirdPartyModel.setPlan(inputData.get("TP_PLAN"));
            thirdPartyModel.setCardId(inputData.get("TP_CARD_ID"));
            thirdPartyModel.setCarrierBin2(inputData.get("TP_CARRIER_BIN_2"));
            thirdPartyModel.setPlan2(inputData.get("TP_PLAN_2"));
            thirdPartyModel.setCardId2(inputData.get("TP_CARD_ID_2"));
            patient.setPatientTp(thirdPartyModel);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);

            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);
            if (connexusStartPage.isConnexusLaunched()) {
                automationManager.getConnexusWorkFlow().createNewPatient(true, patient);

                Reporter.log("Patient has been created.");
            }else {
                softAssert.fail("Connexus not launched");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertAll();
            }

        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(OrderCreationRegressionTestSet1.loginUser_Type);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    @Override
    public void performDropOffForRXWithNoRefills() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            dropOffPage.clickOkInActivePopUp();
            softAssert.assertTrue(dropOffPage.getTextFromRefillRequestPopup().contains("The Prescription is Out Of Refills"));
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickOKonRefillRequestPopUp();
            softAssert.assertTrue(dropOffPage.isFaxSendPopUpDisplayed());
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickSendToResolutionOnFaxSendPopUp();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickYesOnFaxNumberPopUp();
            dropOffPage.selectPriority("Critical");
            dropOffPage.clickBtnAccept();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed");
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    @Override
    public void verifyIfRxIsInResolutionQueue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.performSearch(rxNbr, SearchType.PatientRx);
            softAssert.assertEquals(orderSearch.getWorkQueue(0).toLowerCase(), WorkQueue.RESOLVE.getWorkQueue());
            softAssert.assertEquals(orderSearch.getProblemMessage(0), "Need to Call Doctor for Refills");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            orderSearch.closeSearch();
            Reporter.log("RX is in Resolution Queue");
        }catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void switchToTPFromCASH(Map<String, String> inputData, WorkQueue workQueue) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(workQueue.getWorkQueue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.launchModifyDetailsPage();
                modifyDetails.selectClaimsDropDown();
                String planName = inputData.get("TP_CARRIER_BIN") + " / " + inputData.get("TP_PLAN") + " / " + inputData.get("TP_CARD_ID");
                modifyDetails.switchToInsurance(planName);
                modifyDetails.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being sent to the \n" + "Third Party queue.");
                modifyDetails.clickOnConnexusPopUp();
                modifyDetails.checkAndClickWarning();
                if(modifyDetails.checkConnexusPopDisplayed())
                {
                    modifyDetails.clickOnConnexusPopUp();
                    modifyDetails.checkAndClickWarning();
                }
            } else {
                Reporter.log( String.format("RX is not in %s queue",workQueue.getWorkQueue()));
                Assert.fail(String.format("RX is not in %s queue",workQueue.getWorkQueue()));
            }
        }
        catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            loginConnexus(OrderCreationRegressionTestSet2.loginUser_Type);
            softAssert.assertAll();
        }
    }

    public void switchToTP(Map<String, Object> inputData, WorkQueue workQueue, String rxNbr, Map<String, Object> patientData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        ModifyDetails modifyDetails = new ModifyDetails();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(workQueue.getWorkQueue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.launchModifyDetailsPage();
                modifyDetails.selectClaimsDropDown();
                String planName = inputData.get("TP_CARRIER_BIN") + " / " + inputData.get("TP_PLAN") + " / "
                        + patientData.get("first_name").toString().trim() + patientData.get("last_name").toString().trim();
                modifyDetails.switchToInsurance(planName);
                modifyDetails.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being sent to the \n" + "Third Party queue.");
                modifyDetails.clickOnConnexusPopUp();
                modifyDetails.checkAndClickWarning();
                if (modifyDetails.checkConnexusPopDisplayed()) {
                    modifyDetails.clickOnConnexusPopUp();
                    modifyDetails.checkAndClickWarning();
                }
            } else {
                Reporter.log(String.format("RX is not in %s queue", workQueue.getWorkQueue()));
                Assert.fail(String.format("RX is not in %s queue", workQueue.getWorkQueue()));
            }
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            loginConnexus(OrderCreationRegressionTestSet2.loginUser_Type);
            softAssert.assertAll();
        }
    }

    @Override
    public void changePaymentFromTPtoCASHForAPatient() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            patientSearchPage.launchPatientSearchScreen();
            if(patientSearchPage.isPatientSearchWindowDisplayed()) {
                patientSearchPage.inputPatientName(name[0] + "," + name[1]);
                patientSearchPage.clickSearchNow();
                softAssert.assertTrue(patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(name[0] + "," + name[1]));
                patientSearchPage.openFirstPatientRecord();
                Reporter.logScreenShot(Status.INFO, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.switchPaymentMethodFromTPtoCASH();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.clickSaveAndClose();
            }else
            {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Patient search screen not launched");
            }
        } catch (Throwable e) {
            isExceptionCaptured=true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    @Override
    public void changeTPPlanIn4Point(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatus(name[0] + "," + name[1]);
            if(rxStatus.equalsIgnoreCase(WorkQueue.DUR.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            rxStatus = orderSearch.getRXStatus(name[0] + "," + name[1]);
            if(rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            rxStatus = orderSearch.getRXStatus(name[0] + "," + name[1]);
            if(rxStatus.replace(" ", "").toLowerCase().equalsIgnoreCase(WorkQueue.FOUR_POINT.getWorkQueue())) {
                orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
                orderSearch.selectRowFromSearch(0);
                automationManager.performSleep(5);
                connexusStartPage.inputShortcutKeys(AppShortcuts.MODIFY_DETAILS.getAppShortcuts());
                modifyDetails.selectClaimsDropDown();
                String planName = inputData.get("TP_CARRIER_BIN") + " / " + inputData.get("TP_PLAN") + " / " + inputData.get("TP_CARD_ID");
                modifyDetails.switchToInsurance(planName);
                modifyDetails.clickAccept();
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.selectReasonForSwitchToCash();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                automationManager.performSleep(5);
                softAssert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being sent to the \n" + "Third Party queue.");
                modifyDetails.checkAndClickWarning();
            }
            else{
                Reporter.log("RX is not in 4 Point queue");
                Assert.fail("RX is not in 4 Point queue");
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void performResolution()
    {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
            Reporter.log("RX is in CASH queue");
            automationManager.performSleep(10);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
        }
        while (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
        }
    }

    public void performResolutionForSubmit()
    {
        while (automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr, WorkQueue.RESOLVE)) {
            String currentStepMethodName = StackUtils.getCurrentMethodName();
            ResolutionPage resolutionPage = new ResolutionPage();
            F6Search search = new F6Search();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            resolutionPage.clickSubmit();
            Reporter.log("Resolution " + resolutionPage.takeScreenShot("Resolution").getKey());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Resolution completed");
        }

    }

    public void performResolutionWithDownTime(String rxNbr) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        ResolutionPage resolutionPage = new ResolutionPage();
        automationManager.performSleep(5);
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(rxNbr);
        patientSearchPage.openFirstPatientRecord();
        automationManager.performSleep(2);
        resolutionPage.clickDownTime();
        Reporter.log("Clicked on DownTime Button");
        automationManager.performSleep(5);
        resolutionPage.enterCoPayAmt("0.0");
        Reporter.log("Entered copay Amount");
        resolutionPage.clickAccept();
        Reporter.log("Resolution " + resolutionPage.takeScreenShot("Resolution").getKey());
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
        automationManager.performSleep(5);
        Reporter.log("Resolution completed");
        automationManager.performSleep(5);
    }

    public void isTPDaysSupplyFieldEnabled(WorkQueue workQueue, Boolean verifyCase, String enable) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        F6Search rxSearch = new F6Search();
        ResolutionPage resolutionPage = new ResolutionPage();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        orderSearch.launchOrderSearchScreen();
        orderSearch.performSearch(name[0] + "," + name[1]);

        if (!orderSearch.getWorkQueue(0).equalsIgnoreCase(workQueue.getWorkQueue())) {
            for (int i = 0; i <= 2; i++) {
                rxSearch.clickSearch();
                automationManager.performSleep(5);
            }
        }
        orderSearch.openFirstPatientRecord();
        automationManager.performSleep(3);
        resolutionPage.thirdPartyExtraPage();
        automationManager.performSleep(10);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        System.out.println(modifyDetails.isThirdPartyDaysSupply());
        if (modifyDetails.isThirdPartyDaysSupply() == verifyCase) {
            Assert.assertTrue(true, "ThirdPartyDaysSupply" + enable);
        } else {
            Assert.fail("ThirdPartyDaysSupply " + enable);
        }
    }

    public void enterTPDaysSupplyValueAndSubmit(String TPDaysSupply){

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        modifyDetails.enterTPDaysSupply(TPDaysSupply);
        modifyDetails.clickAccept();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        automationManager.performSleep(3);
        resolutionPage.clickSubmit();
    }

    public void verifyTpDaysSupplyCount(String TPDaysSupply, Boolean value)
    {
        String count = connexusAppUtils.fetchTPFillDetails(rxNbr, "rx_fill_id", true);
        if (TPDaysSupply.equalsIgnoreCase(count)) {
            Assert.assertTrue(value, "TPDaysSupply matched");
        } else {
            Assert.fail("TPDaysSupply not matched");
        }
    }

    public void verifyTPDaySupplyValueWithValue(String TPDaysSupply, Boolean value) {
        String additional_val = connexusAppUtils.fetchTPFillDetailsWithValue(rxNbr, "addition_val", true);
        if (TPDaysSupply.equalsIgnoreCase(additional_val)) {
            Assert.assertTrue(value, "TPDaysSupply matched");
        } else {
            Assert.fail("TPDaysSupply not matched");
        }
    }

    public void CloseConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        loginPage.closeAppKeyCombo();
    }

    public void performDouble4Point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(5);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            automationManager.getConnexusWorkFlow().performDoubleFourPoint(name[0] + "," + name[1]);
        } catch (Exception e) {
            Reporter.log("Test failed at 4 Point queue");

            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

        }
    }

    public boolean verifyOrderComments() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        PropertyReader propertyReader = PropertyReader.getInstance();
        int panes = 0;
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try {
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRow(0);
            patientMaintenancePage.clickNotesButton();
            patientMaintenancePage.clickchkOrderComment();
            boolean result = patientMaintenancePage.checkOrderCommentExists();
            patientMaintenancePage.closeNotes();
            patientMaintenancePage.clickExit();
            Reporter.log("Order comment check completed");
            return result;
        }
        catch (Exception e) {
            System.out.println(e.getLocalizedMessage());
        }
        return false;
    }

    @Override
    public void sendErxMessage(String payloadType, Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        MenuBar menuBar = new MenuBar();
        F6Search search = new F6Search();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchAboutScreen();
            String dob = inputData.get("DOB");
            switch(payloadType)
            {
                case "surescriptFutureFill":
                case "surescriptNewRequst":
                    System.out.print("payload"+payloadResource.getPayload(payloadType,name,dob));
                    search.sendErxMsg(payloadResource.getPayload(payloadType,name,dob));
                    search.selectSurescriptsRadioButton();
                    break;
                case "cancelsurescriptrequest":
                    search.sendErxMsg(payloadResource.getPayload(payloadType,name,dob));
                    search.selectSurescriptsRadioButton();
                    break;
            }
            search.sendErxMessage();
            if("Failure".equalsIgnoreCase(search.getErxResponseMessage())){
                search.clickOk();
                search.closeAboutWindow();
                Assert.fail("Failed to send Erx Message");
            }else{
                automationManager.performSleep(5);
                search.clickOk();
                automationManager.performSleep(5);
                search.closeAboutWindow();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at sending ERX");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    /*Method to perform Partial fill on RX
     * Author - k0k07q3
     * */
    public void performPartialFilling(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if(rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())){
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if(rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())){
                automationManager.getConnexusWorkFlow().completePartialFilling(rxNbr);
            }
            else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                automationManager.getConnexusWorkFlow().completePartialFilling(rxNbr);
                Reporter.log("RX is in Resolve queue");
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                Reporter.log("RX is in CASH queue");
                automationManager.performSleep(10);
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr,1);
                if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
                {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                automationManager.getConnexusWorkFlow().completePartialFilling(rxNbr);
            }
        }catch (Throwable e) {
            Reporter.log("Test failed at Filling queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Method to perform inital filling post partial fill
     * Author - k0k07q3
     * */
    public void performInitialFill() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 1);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(20);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 1);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                Reporter.log("RX is in CASH queue");
                automationManager.performSleep(15);
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
                {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            }else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
                Reporter.log("RX is in Resolve queue");
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Filling queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Method to perform visual verify on index based searched record
     * @param - index of search records
     * @Author -k0k07q3
     * */

    public void performVisualVerify(int index){
        String currentStepMethodName = StackUtils.getCurrentMethodName();

        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openSecondPatientRecord();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(5);
            visVerPage.handleIHaveOrderPopUp();
            visVerPage.clickCancelButtonOnPopUp();
            visVerPage.clickAccept();
            visVerPage.clickOk();
            Reporter.log("Visual Verify completed");
        } catch (Throwable e) {
            Reporter.log("Test failed at Filling queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    /*Method to perform pickup for initial fill
     * Author - k0k07q3
     * */
    public void performPickupForInialFill(Map<String, String> inputData){

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try {
            automationManager.getConnexusWorkFlow().completePickup(name[1],name[0],inputData.get("DOB"),rxNbr);
        } catch (Throwable e) {
            Reporter.log("Test failed at Filling queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /* Method Perform resolution on indexed search records
   @Prams -index
   @Author - K0k07q3
   */
    public void perormResolution(int index){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            ResolutionPage resolutionPage = new ResolutionPage();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openSecondPatientRecord();
            resolutionPage.clickReleaseToFill();
            resolutionPage.clikOKOnPopup();
        }
        catch (Throwable e) {
            Reporter.log("Test failed at POS queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /* Method to verify full co pay after final partial fill
    @Author -k0k07q3
    */
    public void verifyFullCopayPaid() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        rxLookUp.launchRxLookUpPage();
        rxLookUp.inputSearch(rxNbr);
        rxLookUp.clickSearch();
        try {
            rxLookUp.isFullCopayDone();
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            Reporter.log("Test failed at POS queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();

        }
    }

    /**
     Method to verify TP days supply on Patient info page
     @pram {Map<String>} input feed
     @Author - K0k07q3
     */
    public void verifyTPdaysSupplyOnTPInfoPage(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(5);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            rxNbr = getRxNbr(name[0] , name[1], siteId);
            if (rxNbr == null || rxNbr.isEmpty()) {
                rxNbr = getRxNbr(name[0] , name[1], siteId);
                if (rxNbr == null || rxNbr.isEmpty()) {
                    Reporter.log("Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                    Assert.fail("Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                }
                Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
            }

            if(checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point "+rxNbr,"In progress",fileName,40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                        Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                        performResolveQueue(rxNbr);
                    }
                }
            automationManager.performSleep(10);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                orderSearch.openFirstPatientRecord();
                tpExtraInfoPage.openTPExtraInfo();
                automationManager.performSleep(3);
                tpExtraInfoPage.enterTPDaySupply(inputData.get("TPdaysSupply"));
                tpExtraInfoPage.clickAcceptBtn();
                automationManager.performSleep(3);
                claimPage.launchClaimPage();
                claimPage.performClaimSearch(name[0] + "," + name[1]);
                Reporter.logScreenShot(Status.PASS, "Claim Search", claimPage.takeScreenShot(currentStepMethodName).getValue());
                orderSearch.openFirstPatientRecord();
                Assert.assertTrue(loginPage.validateClaimDetailsPageIsLaunched());
                resolutionTPRejPage.clickClaimDetailsTab();
                String supplyDaysOnUI = resolutionTPRejPage.TPSupplyDaysVal();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                resolutionTPRejPage.clickClose();
                Assert.assertEquals(inputData.get("TPdaysSupply"), supplyDaysOnUI);
            }
        }catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    /**
     Method to get RxNbr on index based
     @pram {Array,Int} input
     @Author - K0k07q3
     */
    public void getRxNbr(String name [], int index){
        orderSearch.performSearch(name[0]+","+name[1],SearchType.PatientRx);
        rxNbr= orderSearch.getRxNbr(index);

    }


    public void performPatientMisMatchResolution(){
        String[] name = connexusAppUtils.readPatientNameFromFile();
        orderSearch.launchOrderSearchScreen();
        orderSearch.performSearch(name[0] + "," + name[1]);
        if(orderSearch.getWorkQueue(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            orderSearch.openFirstPatientRecord();
            automationManager.performSleep(3);
            if(resolutionPage.isPatientMismatchScreen()){
                resolutionPage.searchPatientMisMatch(name);
            } else{

                Reporter.log("Patient Mismatch not found!");
            }
            automationManager.performSleep(3);
            resolutionPage.clickUseSelectedPatient();
        }

    }

    public void performCancelPrescription() {
        cancelPrescription = new CancelPrescription();
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        automationManager.performSleep(5);
        String[] name = connexusAppUtils.readPatientNameFromFile();
        orderSearch.launchOrderSearchScreen();
        orderSearch.performSearch(name[0] + "," + name[1]);
        try {
            String workQueue = orderSearch.getWorkQueue(0);
            if(workQueue.equalsIgnoreCase(WorkQueue.CANCELRX.getWorkQueue())) {
                orderSearch.openFirstPatientRecord();
                cancelPrescription.selectCancelCheckBox(0);
                cancelPrescription.clickAcceptCancelBtn();
                cancelPrescription.confirmCancelPrescription();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                cancelPrescription.clickReturn2Stock();
                cancelPrescription.clickCancelbuttonk();
                cancelPrescription.clickOK();
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                orderSearch.closeSearch();
            } else {
                Reporter.log("RX is not in CancelRx queue, It is in" + workQueue);
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());

            }
        }  catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    /**
     Method to perform verification of should hold option in cancel fill
     @pram { }
     @Author - K0k07q3
     */
    public void verifyShouldOnHoldIsDisabled(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        orderSearch.launchOrderSearchScreen();
        orderSearch.performSearch(name[0] + "," + name[1]);
        orderSearch.openFirstPatientRecord();
        modifyDetails.clickCurrentRX();
        modifyDetails.clickOnCancelRx();
        boolean flag = modifyDetails.isShouldBeOnHoldEnabled();
        System.out.print(flag);
        if(flag) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickOnNoBtn();
        }
        else if (!flag) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());

        }
        modifyDetails. exitFromScreen();
        modifyDetails.clickAccept();
        Assert.assertFalse(flag);
    }


    public void updatePrimaryContactAsMessaging(Map<String, String> inputData) {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        System.out.print("patient name"+name[0].toUpperCase() +name[1].toUpperCase());
        String patientId = connexusAppUtils.getPatientId(name[0].toUpperCase(), name[1].toUpperCase());
        String getTimeStamp = connexusAppUtils.getTimeStampQuery(patientId);
        Map<String,Object> resultMap = automationManager.getConnexusDB().executeQuery(getTimeStamp);
        String timestamp = resultMap.get("CurrentTimeStamp").toString().trim().substring(0, 19);
        String updatePrimaryContactAsMessaging = connexusAppUtils.getUpdatePrimaryContactMessagingQuery(timestamp, patientId);
        int result = automationManager.getConnexusDB().executeUpdateQuery(updatePrimaryContactAsMessaging);
        if(result==0){
            Reporter.log("Operation updatePrimaryContactAsMessaging failed");
        } else {
            Reporter.log("Operation updatePrimaryContactAsMessaging is complete");
        }
    }

    public void checkMsgExistsAndEnterPrimary(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try{
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.inputPatientDob(patient.getPatientDob());
            patientSearchPage.clickSearchNow();
            softAssert.assertTrue(patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(name[0] + "," + name[1]));
            patientSearchPage.openFirstPatientRecord();
            String patientMessagingNum= patientMaintenancePage.getPatientMessagingPhoneNumber().replaceAll("[^0-9]", "");
            if(!patientMessagingNum.equals(inputData.get("PRIMARY_NUMBER"))){
                Reporter.log("phone number in messaging does not match primary number in file");
                Assert.fail("phone number in messaging does not match primary number in file");
            }
            patientMaintenancePage.inputPrimaryPhoneNumber(inputData.get("PRIMARY_NUMBER"));
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            if (patientMaintenancePage.isSaveAsEnteredDisplayed()) {
                patientMaintenancePage.clickSaveAsEntered();
            }
        }
        catch (Throwable e) {
            Reporter.log("Test failed at checkMessagingContactExists");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }

    public void checkPrimaryContact(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try{
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.inputPatientDob(patient.getPatientDob());
            System.out.println(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            softAssert.assertTrue(patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(name[0] + "," + name[1]));
            patientSearchPage.openFirstPatientRecord();
            String patientPrimaryContact= patientMaintenancePage.getPrimaryPhone().replaceAll("[^0-9]", "");
            if(!patientPrimaryContact.equals(inputData.get("PRIMARY_NUMBER"))){
                Reporter.log("phone number in primary contact does not match primary number in file");
                Assert.fail("phone number in primary contact does not match primary number in file");
            } else {
                Reporter.log("phone number in primary contact matches primary number in file");
            }
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            if (patientMaintenancePage.isSaveAsEnteredDisplayed()) {
                patientMaintenancePage.clickSaveAsEntered();
            }
        }
        catch (Throwable e) {
            Reporter.log("Test failed at checkPrimaryContact");
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void VerifySequenceNumber(String patientId){
        String getContactInfoQuery = connexusAppUtils.getContactInfoQuery(patientId);
        Map<String,Object> resultMap = automationManager.getConnexusDB().executeQuery(getContactInfoQuery);
        if(Integer.parseInt(resultMap.get("RecordCount").toString())!=1){
            Reporter.log("Cannot find a phone number in primary contact");
            Assert.fail("Cannot find a phone number in primary contact");
        } else {
            Reporter.log("Sequence number verified for " + resultMap.get("RecordCount").toString());
        }
    }

    public void VerifyPrimaryNumAndCheckSeqNbr(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try{
            String patientId = connexusAppUtils.getPatientId(name[0].toUpperCase(), name[1].toUpperCase());
            VerifySequenceNumber(patientId);
            String updateSeqNbr = connexusAppUtils.getUpdateSeqNbrQuery(patientId);
            int result = automationManager.getConnexusDB().executeUpdateQuery(updateSeqNbr);
            if(result==0){
                Reporter.log("Operation updateSeqNbr in VerifyPrimaryNumAndCheckSeqNbr failed");
            }
            checkPrimaryContact(inputData);
            VerifySequenceNumber(patientId);
        }
        catch (Throwable e) {
            Reporter.log("Test failed at VerifyPrimaryNumAndCheckSeqNbr");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void createNewPatientWithAllergy(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);
            patient.setPatientAllergy(inputData.get("ALLERGY"));


            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            patient.setPatientTp(thirdPartyModel);

            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.YES);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);
            if (connexusStartPage.isConnexusLaunched()) {
                automationManager.performSleep(3);
                automationManager.getConnexusWorkFlow().createNewPatient(false, patient);

                Reporter.log("Patient has been created.");
            }else {
                softAssert.fail("Connexus not launched");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertAll();
            }

        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }



    public void verifyMaxDailyDoseIsEntered(Map<String, String> inputData)
    {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.selectDAW(1);
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            if (inputPage.isMaxDoseBoxEnabled()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertTrue(true, "Max Dose Text Box Enabled");
            } else {
                Assert.fail("Max Dose Disabled");
            }
            inputPage.clickAccept();
            if (inputPage.isCnxPopUpMessageDisplayed()) {
                inputPage.clickOkOnCnxPopUpMessage();
            }
            if ("Max daily dose is required.".equals(inputPage.getTextFromPopUp())) {
                Assert.assertTrue(true);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Assert.fail("Max daily dose is required");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            inputPage.clickOKButtonDEAPopup();
            inputPage.clickCancel();
            connexusStartPage.clickYes();
        }
        catch (Throwable e) {
            Reporter.log("Test failed at Input queue");
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyMaxDailyDoseValueDb(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            F6Search rxSearch = new F6Search();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();

            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.inputExpandedSig(inputData.get("EXPANDED_SIG"));
            if (inputPage.isMaxDoseBoxEnabled()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertTrue(true, "Max Dose Text Box Enabled");
            } else {
                Assert.fail("Max Dose Disabled");
            }
            inputPage.enterMaxDose(inputData.get("MAX_DOSE"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.selectDAW(1);
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            inputPage.clickAccept();
            if (inputPage.isCnxPopUpMessageDisplayed()) {
                inputPage.clickOkOnCnxPopUpMessage();
            }
            inputPage.clickMaxDoseButtonOk();
            inputPage.clickOKButtonDEAPopup();
            inputPage.enterMaxDose(inputData.get("MAX_DOSE"));
            inputPage.clickAccept();
            inputPage.clickOkOnCnxPopUpMessage();
            inputPage.clickMaxDoseButtonOk();
            inputPage.enterProductSupplyDays("10");
            inputPage.clickOKButtonDEAPopup();
            inputPage.clickAccept();
            inputPage.clickOnOutofStockPopupOk();
            inputPage.clickOkOnCnxPopUpMessage();
            //inputPage.clickOnOutofStockPopupOk();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(5);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);

            if (rxSearch.getWorkQueue(0).toLowerCase().equals(WorkQueue.FOUR_POINT.getWorkQueue()) || rxSearch.getWorkQueue(0).toLowerCase().equals(WorkQueue.CHK_DUR.getWorkQueue())) {
                patientSearchPage.clickClose();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                String dbMaxDose = connexusAppUtils.fetchMaxDose(rxNbr, "comment_text");
                orderSearch.closeSearch();
                if (inputData.get("MAX_DOSE").equalsIgnoreCase(dbMaxDose)) {
                    Assert.assertTrue(true, "Max Dose value matched");
                } else {
                    Assert.fail("Max dose value not matched");
                }
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
        }
    }

    public void performEmergencyRxDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        automationManager.performSleep(5);
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try {
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            dropOffPage.clickScanNewRx();
            dropOffPage.switchWindow();
            String barCode = dropOffPage.generateRxBarCode();
            dropOffPage.enterBarCode(barCode);
            Reporter.log("New barcode entered " + barCode);
            automationManager.performSleep(5);
            dropOffPage.clickBtnAccept();
            dropOffPage.switchWindow();
            dropOffPage.clickVerifyBarCode();
            dropOffPage.selectRxOrigin();
            dropOffPage.clickEmergencyRxCheckBox();
            dropOffPage.clickBtnAccept();
            dropOffPage.addNoOfRx(barCode, 1);
            dropOffPage.selectPriority(Priority.Critical.getPriority());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickBtnAccept();
            automationManager.performSleep(6);
            dropOffPage.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed");
        } catch (Throwable e) {
            Reporter.log("Test failed at DropOff queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyInitialFillCreatedAfterFourPoint(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        automationManager.performSleep(5);
        try {
            F6Search rxSearch = new F6Search();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String daysofSupply = "";
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            if (fourPoint.isNameChkBoxDisplayed()) {
                fourPoint.chkName();
                fourPoint.chkPrescribed();
                fourPoint.chkStrength();
                fourPoint.chkSIG();
                if (fourPoint.isDeaChkBoxDisplayed()) {
                    fourPoint.chkDEA();
                }
                if (fourPoint.isNonAcuteRdbDisplayed()) {
                    fourPoint.clickNonAcute();
                }
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
                fourPoint.clickAccept();
                fourPoint.islblDaysofSupplyDisplayed();
                {
                    daysofSupply = fourPoint.getDaysofSupply();
                }
                if ("3".equals(daysofSupply)) {
                    Assert.assertTrue(true, "DaysSupply matched");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
                }
                if(fourPoint.isbtnSendToFillingDisplayed()) {
                    fourPoint.clickbtnSendToFilling();
                }
                if("An Emergency fill has been created.  If a refill request is needed, generate it from drop-off.".equalsIgnoreCase(fourPoint.getTextFromPopup()))
                {
                    Assert.assertTrue(true);
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
                    fourPoint.clickOkInPopUp();
                }
                else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
                    Assert.fail("Test failed at 4 Point");
                }

            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("4 Point screen not launched");
            }
        }
        catch (Throwable e) {
            Reporter.log("Test failed at Four Point queue");
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyFillTypeCodeFromDb() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            F6Search rxSearch = new F6Search();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            if (rxSearch.getWorkQueue(0).toLowerCase().equals(WorkQueue.CHK_DUR.getWorkQueue()) || rxSearch.getWorkQueue(0).toLowerCase().equals(WorkQueue.FILLING.getWorkQueue()) ) {
                String fillTypeCode = connexusAppUtils.getFillTypeCodeFromDB(rxNbr, "fill_type_code");
                if ("7002".equals(fillTypeCode)) {
                    Assert.assertTrue(true, "Only Initial Fill Created");
                } else {
                    Assert.fail("Initial Fill is not created");
                }
            }
        }
        catch (Throwable e) {
            Reporter.log("Test failed at verifyFillTypeCodeFromDb");
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void verifyFutureFillDateInput_ERX(Map<String, String> inputData)
    {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        F6Search orderSearch = new F6Search();
        PatientSearchPage patientSearchPage = new PatientSearchPage();
        try{
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);

            if(rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue())){
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                orderSearch.openFirstPatientRecord();

                //Future Date given from surescript is Next Day
                Date date = new Date(System.currentTimeMillis());
                Calendar c = Calendar.getInstance();
                c.setTime(date);
                c.add(Calendar.DATE,1);
                String futureDate = new SimpleDateFormat("MM/dd/yyyy").format(c.getTime());

                if(inputPage.getEarliestFillDate().equals(futureDate))
                {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                    Assert.assertTrue(true,"Earliest Fill date matched");
                }else{
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                    Assert.fail("Earliest Fill Date not matched");
                    inputPage.exitInputScreen();
                }

                inputPage.enterNdc(inputData.get("DRUG_NAME"));
                inputPage.clickProductSearch3Dots();
                inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
                inputPage.enterSigCode(inputData.get("SIG"));
                inputPage.enterRefillQty(inputData.get("REFILLS"));
                inputPage.selectDAW(1);
                inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
                inputPage.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                inputPage.clickAccept();

                inputPage.sendHotKeys(Keys.ENTER);
                if (inputPage.isValidateRXPopUpDisplayed()) {
                    inputPage.clickYesOnValidateRxPopUp();
                }
                Reporter.log("Input completed");
            }
            else{
                Reporter.log("RX is not in Input queue");
                Assert.fail();
            }


        }
        catch (Throwable e) {
            Reporter.log("Test failed at sending ERX");
            loginConnexus(OrderCreationRegressionTestSet4.loginUser_Type);
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }


    }


    public void performNaloxoneDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().performNaloxoneDropRx(dropRxModel);
        } catch (Exception e) {
            Reporter.log("Test failed at DropOff queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    public void performIMZDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().performIMZDropOff(dropRxModel);
        } catch (Exception e) {
            Reporter.log("Test failed at DropOff queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performDropOffForARXWithNoRefills() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(10);
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickOKonRefillRequestPopUp();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickSendToResolutionOnFaxSendPopUp();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickYesOnFaxNumberPopUp();
            dropOffPage.selectPriority("Critical");
            dropOffPage.clickBtnAccept();
            dropOffPage.handleStorePickupTimePopup();
            Reporter.log("Drop-Off completed");
        } catch (Throwable e) {
            e.printStackTrace();
            isExceptionCaptured = true;
        }
    }


    @Override
    public void switchToCASHFromTP() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.selectClaimsDropDown();
                Robot robot = new Robot();
                robot.keyPress(KeyEvent.VK_UP);
                robot.keyRelease(KeyEvent.VK_UP);
                robot.keyPress(KeyEvent.VK_ENTER);
                robot.keyRelease(KeyEvent.VK_ENTER);
                modifyDetails.clickAccept();
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_ENTER);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.OkWarningClick();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being reprocessed");
                modifyDetails.checkAndClickWarning();
            } else {
                Reporter.log("RX is not in Visual verify queue");
                Assert.fail("RX is not in Visual verify queue");
            }
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


    public void switchToTPFromTP(Map<String, String> inputData, WorkQueue workQueue) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue(),ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.selectClaimsDropDown();
                String planName = inputData.get("TP_CARRIER_BIN") + " / " + inputData.get("TP_PLAN") + " / " + inputData.get("TP_CARD_ID");
                Reporter.log("Plan name " + planName);
                modifyDetails.switchToInsurance(planName);
                modifyDetails.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.selectReasonForSwitchToCash();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                automationManager.performSleep(5);
                softAssert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being sent to the \n" + "Third Party queue.");
                modifyDetails.checkAndClickWarning();
            } else {
                Reporter.log("RX is not in Filling queue");
                Assert.fail("RX is not in Filling queue");
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


    public void getNoOfRxNotes() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        int panes = 0;
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try {
            patientSearchPage.patientSearchShotCutKeys();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRow(0);
            patientMaintenancePage.clickNotesButton();
            panes = patientMaintenancePage.getSiteIdsCount().size();
            for (int i = 0; i <= panes - 1; i++) {

                String siteId = patientMaintenancePage.getSiteIdsCount().get(i).getAttribute("Value.Value");

                if (siteId.equalsIgnoreCase(PropertyReader.getInstance().getProperty("cnx.store"))) {
                    Reporter.log("ok");
                } else {
                    Assert.assertFalse(false, "SiteId not matched");
                }
            }
            String conNotes = "";
            for (int j = 0; j <= patientMaintenancePage.getNotesCount().size() - 1; j++) {
                String notes = patientMaintenancePage.getNotesCount().get(j).getAttribute("Value.Value");
                conNotes = conNotes + notes;
            }
            String consolidatedNotes = conNotes.toLowerCase().trim();
            if (consolidatedNotes.contains("rxnotes".toLowerCase()) && consolidatedNotes.contains("pharmacynotes".toLowerCase())
                    && consolidatedNotes.contains("counselingnotes".toLowerCase())) {

            } else {
                Assert.assertFalse(false, "Notes not matched");
            }
            patientMaintenancePage.closeNotes();
            patientMaintenancePage.clickExit();
        } catch (Exception e) {
            Reporter.log(e.getLocalizedMessage());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }

    }

    public void verifyIMZModufyDetails() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        orderSearch.launchOrderSearchScreen();
        orderSearch.performSearch(name[0] + "," + name[1]);
        orderSearch.openFirstPatientRecord();
        if (fourPoint.overDose()) {
            fourPoint.clickOverDoseButton();
        }
        modifyDetails.launchModifyDetailScreen();
        automationManager.performSleep(2);
        if (modifyDetails.isPrescribedPdtEnabled()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Prescribed Product field enabled");

        }
        if (modifyDetails.isDispensedQntyEnabled()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Dispensed Quantity field enabled");
        }
        if (modifyDetails.isRefillAuthEnabled()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Refill Auth field enabled");
        }
        modifyDetails.clickCancel();
        modifyDetails.clickYes();
        modifyDetails.clickCancel();

    }

    public void verifyThirdPartyDaysSupplyField(String stagedRxNbr, WorkQueue workQueue, Boolean verifyCase, String enable) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        orderSearch.launchOrderSearchScreen();
        orderSearch.performSearch(stagedRxNbr);
        orderSearch.selectRowFromSearchRX();
        automationManager.performSleep(3);
        modifyDetails.launchtpExtraInfo();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
        if (modifyDetails.isThirdPartyDaysSupply() == verifyCase) {
            Assert.assertTrue(true, "ThirdPartyDaysSupply" + enable);
            Reporter.log("ThirdPartyDaysSupply is enabled");
            modifyDetails.clickCancel();
        } else {
            Assert.fail("ThirdPartyDaysSupply " + enable);
        }

    }



    public void verifyTPDaysSupplyValueWithValue(String stagedRxNbr,String TPDaysSuppy, Boolean value, String matchValue) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        orderSearch.launchOrderSearchScreen();
        orderSearch.performSearch(stagedRxNbr);
        orderSearch.openFirstPatientRecord();
        TPExtraInfoPage tpExtraInfoPage = new TPExtraInfoPage();
        ResolutionTPRejPage resolutionTPRejPage = new ResolutionTPRejPage();
        tpExtraInfoPage.openTPExtraInfo();
        tpExtraInfoPage.enterTPDaySupply(TPDaysSuppy);
        Reporter.log("Entered TPDaysSuppy as " + TPDaysSuppy);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
        tpExtraInfoPage.clickAcceptBtn();
        modifyDetails.clickAccept();
        automationManager.performSleep(3);
        String rx_ID = automationManager.getConnexusDB().getScalar("select rx_id from rx where rx_nbr =" +stagedRxNbr, String.class);
        String rx_fill_id =automationManager.getConnexusDB().getScalar("select rx_fill_id from rx_fill where rx_id =" +rx_ID, String.class);
        String addition_val =automationManager.getConnexusDB().getScalar("SELECT addition_val from clm_override_addtn WHERE rx_fill_id=" + rx_fill_id + "AND addtn_class_code = 23232", String.class);
        Assert.assertEquals(addition_val,TPDaysSuppy);
        Reporter.log("TPDaysSuppy values matches");
        resolutionTPRejPage.clickClose();
    }

    public String verifyTPDaySupplyValue(String rxnbr) {
        ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
        String value = "";
        value = connexusAppUtils.fetchTPFillDetails(rxnbr, "rx_fill_id", false);
        return value;
    }


    public void verifyDirectionOfUse(String rxNbrStr) {

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbrStr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbrStr);
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbrStr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.launchModifyDetailScreen();
                modifyDetails.clearSigField();
                modifyDetails.enterSig1("TAD");
                modifyDetails.enterDaysSupply("15");
                Reporter.log("entered sig and days");
                modifyDetails.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                automationManager.performSleep(5);
                if (modifyDetails.getDirectionUseText().equalsIgnoreCase("This prescription requires  specific directions for use. Please contact the prescriber to obtain detailed instructions, then annotate the prescription image.\n" +
                        "DirectionThis")) {

                    softAssert.assertTrue(true, "expected condition matched");
                }

            }

            else if(rxStatus.equalsIgnoreCase(WorkQueue.FOUR_POINT.getWorkQueue())){
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbrStr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.launchModifyDetailScreen();
                modifyDetails.clearSigField();
                modifyDetails.enterSig1("TAD");
                modifyDetails.enterDaysSupply("15");
                modifyDetails.clickAccept();
                automationManager.performSleep(2);
                if (modifyDetails.getDirectionUseText().equalsIgnoreCase("This prescription requires  specific directions for use. Please contact the prescriber to obtain detailed instructions, then annotate the prescription image.\n" +
                        "DirectionThis")) {
                    softAssert.assertTrue(true, "expected condition matched");
                }
            }
        } catch(Throwable e){
            isExceptionCaptured = true;
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyWorkQueue(WorkQueue workQueue) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatus(rxNbr);
            orderSearch.performSearch(rxNbr, SearchType.PatientRx);
            if (rxStatus.equalsIgnoreCase(workQueue.getWorkQueue())) {
                Reporter.log("RX is in Pick up queue");
                orderSearch.closeSearch();
            } else {
                Reporter.log("RX is not in Pick up queue");
                Assert.fail("RX is not in Pick up queue");
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void changeTPtoTP(Map<String, String> inputData, WorkQueue workQueue) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())){
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
                connexusAppUtils.writeTextToFile("Completed ChkDUR "+rxNbr,"In progress",fileName,50, DateTime.now());
            }
            rxStatus = orderSearch.getRXStatus(rxNbr);
            if (rxStatus.equalsIgnoreCase(workQueue.getWorkQueue())) {
                switchToTPFromTP(inputData, workQueue);

            } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                Reporter.log("RX is in Resolve queue");
                Assert.fail("RX is in Resolve queue");
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                Reporter.log("RX is in CASH queue");
                Assert.fail("RX is in CASH queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Filling queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyWorkQueue(String workQueue) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            F6Search search = new F6Search();
            automationManager.performSleep(2);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = search.getRXStatus(name[0] + "," + name[1]);
            if (rxStatus.equalsIgnoreCase(workQueue)) {
                Assert.assertTrue(true, "Workqueue Matched");
            } else {

                Assert.fail("Workqueue not Matched, current work queue is " + rxStatus);
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(workQueue + " " + "not matched");
            Reporter.log(workQueue + " " + "not matched");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }


    public void uncheckVoidRemaingCheckBox( int index) {

        F6Search search = new F6Search();
        VisVerPage visVerPage = new VisVerPage();
        ChkDur dur = new ChkDur();
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        automationManager.performSleep(5);
        String rxStatus = orderSearch.getRXStatusBasedOnRxIndex(rxNbr, index);
        if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {  // perform checkDUR
            try {
                search.performSearch(rxNbr, SearchType.PatientRx);
                search.selectRowFromSearch(index);
                automationManager.performSleep(4);
                modifyDetails.openModifyDetailsScreen();
                modifyDetails.clickVoidRemaining();
                modifyDetails.uncheckVoidRemaining();
                modifyDetails.clickAccept();
                modifyDetails.OkWarningClick();
                modifyDetails.clickFloatingOkButton();
                modifyDetails.clickok();
                automationManager.performSleep(4);
                visVerPage.handleIHaveOrderPopUp();
                visVerPage.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } catch (Exception e) {
                isExceptionCaptured = true;
                Assert.fail("CheckDUR failed" + e.getStackTrace());
                Reporter.log("Test failed at ChkDUR queue" + e.getStackTrace());
            }
        }
    }
    public void selectOrDeselectVoidRemaingCheckBox( int index) {

        F6Search search = new F6Search();
        VisVerPage visVerPage = new VisVerPage();
        ChkDur dur = new ChkDur();
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {

            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusBasedOnRxIndex(rxNbr, index);

            if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) { //select void remaining in filling modify
                try {
                    Reporter.log(" 1" + rxStatus);
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    automationManager.performSleep(4);
                    modifyDetails.openModifyDetailsScreen();
                    modifyDetails.clickVoidRemaining();
                    modifyDetails.OkWarningClick();
                    modifyDetails.clickAccept();
                    modifyDetails.clickFloatingOkButton();
                    modifyDetails.acceptAndClose();
                    modifyDetails.clickFloatingOkButton();
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                } catch (Exception a) {
                    Assert.fail("Filliing failed" + a.getStackTrace());
                    Reporter.log("Test failed at filling queue" + a.getStackTrace());
                }
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {  // perform checkDUR
                try {
                    Reporter.log(" 2 " + rxStatus);
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    if (dur.checkIfAcceptIsEnabled()) {
                        dur.clickAccept();
                    }
                    modifyDetails.clickFloatingOkButton();
                    modifyDetails.saveConsolidatedNotes();
                } catch (Exception e) {
                    Assert.fail("CheckDUR failed" + e.getStackTrace());
                    Reporter.log("Test failed at ChkDUR queue" + e.getStackTrace());
                }
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) { //Uncheck void remaning if VV
                try {
                    ResolutionPage resolutionPage = new ResolutionPage();
                    Reporter.log(" 3" + rxStatus);
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    automationManager.performSleep(4);
                    //resolutionPage.clickDownTime();
                    automationManager.performSleep(4);
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    automationManager.performSleep(4);
                    modifyDetails.openModifyDetailsScreen();
                    modifyDetails.clickVoidRemaining();
                    modifyDetails.OkWarningClick();
                    modifyDetails.clickAccept();
                    modifyDetails.clickFloatingOkButton();
                    modifyDetails.saveConsolidatedNotes();
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    automationManager.performSleep(4);
                    resolutionPage.clickDownTime();
                    automationManager.performSleep(4);
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    automationManager.performSleep(4);
                    visVerPage.handleIHaveOrderPopUp();
                    visVerPage.clickAccept();
                } catch (Exception e) {
                    Assert.fail("VV failed" + e.getStackTrace());
                    Reporter.log("Test failed at VV queue" + e.getStackTrace());
                }
            }else if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {  // perform checkDUR
                try {
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    automationManager.performSleep(4);
                    modifyDetails.openModifyDetailsScreen();
                    modifyDetails.clickVoidRemaining();
                    modifyDetails.uncheckVoidRemaining();
                    modifyDetails.clickAccept();
                    modifyDetails.OkWarningClick();
                    modifyDetails.clickFloatingOkButton();
                    automationManager.performSleep(4);
                    visVerPage.handleIHaveOrderPopUp();
                    visVerPage.clickAccept();
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                } catch (Exception e) {
                    Assert.fail("CheckDUR failed" + e.getStackTrace());
                    Reporter.log("Test failed at ChkDUR queue" + e.getStackTrace());
                }
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyRxStatusFromDropOff(String status) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickDropOffQueue();
            automationManager.performSleep(3);
            dropOffPage.enterPatientName(rxNbr);
            automationManager.performSleep(3);
            dropOffPage.clickPatientSearch();
            automationManager.performSleep(5);
            dropOffPage.clickOkButton();
            if(dropOffPage.isRxStatusAvailable(0)){
                Reporter.log(dropOffPage.getRxStatusAvailable(0));
                if(dropOffPage.getRxStatusAvailable(0).equalsIgnoreCase(status)) {
                    Reporter.logScreenShot(currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                }else{
                    Assert.fail("rx status not matched, Expected " + status);
                    Reporter.logScreenShot(Status.FAIL,currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                }
            }
            else{
                Assert.fail("rx status available");
                Reporter.logScreenShot(Status.FAIL,currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            }

        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }
    public void performPartialFill(String workqueue) {
        F6Search search = new F6Search();
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            MenuBar menuBar = new MenuBar();
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatus(rxNbr);
            if (rxStatus.equalsIgnoreCase(workqueue)) {
                search.performSearch(rxNbr, SearchType.PatientRx);
                search.selectRowFromSearch(0);
                modifyDetails.clickCurrentRX();
                //menuBar.navigateToMenu(AppMenu.PARTIAL_FILL);
                modifyDetails.clickOnCancelRx();
                //menuBar.navigateToMenu(AppMenu.PARTIAL_FILL);
                modifyDetails.clickOnPartialFill();
                modifyDetails.enterPartialFillQuantity();
                modifyDetails.enterOnHandQuantity();
                modifyDetails.clickAccept();
                modifyDetails.switchWindow();
                modifyDetails.selectQtyDiscrepency();
                modifyDetails.clickContinue();
                dropOffPage.checkAndClickDropOffStation();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    public void verifyClaimSubmission(String claimStatus) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

            }
            automationManager.performSleep(5);
            orderSearch.clickClaim();
            connexusStartPage.performSearch(rxNbr);
            automationManager.performSleep(4);
            connexusStartPage.clickSearchButton();
            if(connexusStartPage.getCailnSatus(0).equalsIgnoreCase(claimStatus)||connexusStartPage.getCailnSatus(1).equalsIgnoreCase(claimStatus)){
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

            }
            connexusStartPage.clickClose();
        }
        catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();

        }
    }


    public void clickCancelBtn(){
        ResolutionPage resolutionPage= new ResolutionPage();
        resolutionPage.clickCancel();
    }

    public void verifyTPdaysSupplyOnTPInfoPage(String rxNbr,String patientId){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                for (int index = 0; index <= 4; index++) {
                    automationManager.performSleep(10);
                    int isOrderIn4point = checkOrderIn4pointAndNotDUR(rxNbr);
                    Reporter.log("check order in 4 point"+isOrderIn4point);
                    if (isOrderIn4point > 0) {
                        break;
                    }
                }
                Reporter.log("RX in TP flow");
            }
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            TPExtraInfoPage tpExtraInfoPage = new TPExtraInfoPage();
            ResolutionTPRejPage resolutionTPRejPage = new ResolutionTPRejPage();
            tpExtraInfoPage.openTPExtraInfo();
            tpExtraInfoPage.enterTPDaySupply("0");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            tpExtraInfoPage.clickAcceptBtn();
            String rx_ID = automationManager.getConnexusDB().getScalar("select rx_id from rx where patient_id =" +patientId, String.class);
            String rx_fill_id =automationManager.getConnexusDB().getScalar("select rx_fill_id from rx_fill where rx_id =" +rx_ID, String.class);

            String addition_val =automationManager.getConnexusDB().getScalar("SELECT addition_val from clm_override_addtn WHERE rx_fill_id=" + rx_fill_id + "AND addtn_class_code = 23232", String.class);
            Assert.assertEquals(addition_val,null);
            Reporter.log("addition_val column in null when value is removed/entered 0 in ‘Third party days supply");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            resolutionTPRejPage.clickClose();
        }catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }


    public void performRefillsAuthorized(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolutionForRefills(rxNbr, inputData.get("REFILLS"), connexusAppUtils.randomName());
            } else {
                Reporter.log("RX is not in Resolve queue");
                Assert.fail("RX is not in Resolve queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


    public void performNaloxoneDropOffForPatient() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().performNaloxoneDropRxForPatient(dropRxModel);
        } catch (Throwable e) {
            Reporter.log("Test failed at DropOff queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void performCancelPrescriptions() {
        CancelPrescription cancelPrescription = new CancelPrescription();
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        orderSearch.launchOrderSearchScreen();
        orderSearch.performSearch(name[0]+","+name[1]);
        try {
            String workQueue = orderSearch.getWorkQueue(0);
            if(workQueue.equalsIgnoreCase(WorkQueue.CANCELRX.getWorkQueue())) {
                orderSearch.openFirstPatientRecord();
                cancelPrescription.selectCancelCheckBox(2);
                cancelPrescription.clickAcceptCancelBtn();
                cancelPrescription.clickOK();
                automationManager.performSleep(5);
                /*cancelPrescription.confirmCancelPrescription();
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                cancelPrescription.clickReturn2Stock();
                automationManager.performSleep(10);
                cancelPrescription.clickCancelbuttonk();
                automationManager.performSleep(15);*/
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0]+","+name[1]);
                orderSearch.closeSearch();
            } else {
                Reporter.log("RX is not in CancelRx queue, It is in" + workQueue);
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());

            }
        }  catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void performChkDURRedFlag(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            ChkDur dur = new ChkDur();
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();

                if (dur.clickRedFlagsBtn()) {
                    Reporter.logScreenShot(Status.PASS, "Resolving Red flags", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    dur.selectResolvedCheckBoxes();
                    dur.clickDurBtn();
                }

                if (dur.isElementDisplayed(dur.lblRequired, 30)) {
                    Assert.assertTrue(true);
                }

                if (!dur.clickClearConflictsBtn()) {
                    dur.selectAllCheckBoxes();
                }
                dur.clickNarxCareCheckBox();
                dur.clickAccept();
                ResolutionPage resolutionPage = new ResolutionPage();
                resolutionPage.clickProblemResolved();
            }


        }
        catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void performModifyDrugAtAnyWorkqueue(String workqueue, Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {

                orderSearch.launchOrderSearchScreen();

                orderSearch.performSearch(rxNbr);

                orderSearch.openFirstPatientRecord();

                modifyDetails.launchModifyDetailScreen();

                automationManager.performSleep(6);
                modifyDetails.enterProductNameInPrescribedProduct(inputData.get("UPDATED_DRUG"));
                inputPage.clickAccept();
                try {
                    inputPage.clickYes();
                } catch (Exception e) {
                    Reporter.log("RTS lable not available");
                }
                inputPage.clickButtonOk();
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.launchModifyDetailScreen();

                modifyDetails.enterProductNameInPrescribedProduct(inputData.get("UPDATED_DRUG"));
                inputPage.clickAccept();
                try {
                    inputPage.clickYes();
                } catch (Exception e) {
                    Reporter.log("RTS lable not available");
                }
                inputPage.clickButtonOk();
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void verifyVoidRemaingCheckBoxDisabled( int index) {

        F6Search search = new F6Search();
        VisVerPage visVerPage = new VisVerPage();
        ChkDur dur = new ChkDur();
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        automationManager.performSleep(5);
        String rxStatus = orderSearch.getRXStatusBasedOnRxIndex(rxNbr, index);
        if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {  // perform checkDUR
            try {
                search.performSearch(rxNbr, SearchType.PatientRx);
                search.selectRowFromSearch(index);
                automationManager.performSleep(4);
                modifyDetails.openModifyDetailsScreen();
                modifyDetails.clickButtonClose();
                modifyDetails.clickCancel();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }   catch (Exception e) {
                isExceptionCaptured = true;
                Assert.fail("CheckDUR failed" + e.getStackTrace());
                Reporter.log("Test failed at ChkDUR queue" + e.getStackTrace());
            }
        }
    }

    public int checkOrderIn4pointAndNotDUR(String rxNbr) {
        int workQueueCode = 0;
        int siteId = Integer.parseInt(propertyReader.getProperty("cnx.store"));
        try {
            workQueueCode = checkOrderWorkqueueCode(siteId,rxNbr);
            Reporter.log("next work queue code is"+workQueueCode);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        if (workQueueCode == WorkQueueSettings.wm4PointCheck.getValue()) {
            return 1;
        } else {
            return 0;
        }
    }

    public int checkOrderWorkqueueCode(int siteId,String rxNbr) {
        int rxFillId=getFillId(rxNbr);
        Map<String, Object> rxInfo = automationManager.getConnexusDB(siteId).executeQuery("select next_work_que_code from rx21c: rx_order_detail where rx_fill_id =" + rxFillId);
        int nextWorkQueueCode = Integer.parseInt(rxInfo.get("next_work_que_code").toString());
        return nextWorkQueueCode;
    }

    public int getFillId(String rxNbr){
        String query = "select max(rx_fill_id) as rx_fill_id  from  rx_order_detail where rx_id =(select rx_id from rx where rx_nbr=\"" + rxNbr + "\")";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        int fillId = Integer.parseInt(rxInfo.get("rx_fill_id").toString());
        Reporter.log("Filld is "+fillId);
        return fillId;
    }
    public void dropoffActions() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickOkButton();
            dropOffPage.clickBtnCancel();
            dropOffPage.clickYes();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at dropoffActions");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performDropRx_TP_Discontinue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try {
            DropOffPage dropOff = new DropOffPage();
            dropOff.clickDropOffQueue();
            dropOff.enterPatientName(name[0] + "," + name[1]);
            dropOff.clickPatientSearch();
            dropOff.handleAnnualValidatePatInfoPopUp();
            dropOff.discontinueTpPlan();
            dropOff.clickScanNewRx();
            String barCode = dropOff.generateRxBarCode();
            dropOff.enterBarCode(barCode);
            Reporter.log("New barcode entered " + barCode);
            dropOff.clickBtnAccept();
            dropOff.clickVerifyBarCode();
            dropOff.selectRxOrigin();
            dropOff.clickBtnAccept();
            dropOff.addNoOfRx(barCode, 1);
            dropOff.selectPriority(Priority.Critical.getPriority());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            dropOff.clickBtnAccept();
            dropOff.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed");
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    private String completeCheckDURIfRequiredViaAPI(String fourPointResponsePayload) {
        automationManager.performSleep(5);
        String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
            Reporter.log("Order is in CheckDUR queue. Completing CheckDUR via API");
            hwqe.baseframework.apicontext.ServiceResponse chkDurResp = connexusAPIManager.chkDURComplete(fourPointResponsePayload);
            Assert.assertEquals(chkDurResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
            Assert.assertFalse(chkDurResp.getDataResponse().contains("error"), "CheckDUR could not be completed");
            Reporter.log("CheckDUR completed via API");
            return chkDurResp.getDataResponse();
        }

        Reporter.log("Order is not in CheckDUR queue. Proceeding to Filling");
        return fourPointResponsePayload;
    }

    private String completeDropOffViaAPI(Map<String, String> inputData) {
        String ndc = inputData.get("DRUG_NAME");
        if (ndc == null || ndc.isEmpty()) {
            ndc = inputData.get("NDC");
        }
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        hwqe.baseframework.datacontext.DataRow drugInfo = connexusAPIManager.getDrugInfo(cnx, ndc);
        String[] name = connexusAppUtils.readPatientNameFromFile();
        int patientId = Integer.parseInt(connexusAppUtils.getPatientId(name[0].toUpperCase(), name[1].toUpperCase()));
        int numRefills = Integer.parseInt(inputData.getOrDefault("REFILLS", "3"));
        hwqe.baseframework.apicontext.ServiceResponse dropOffResp = connexusAPIManager.createOrderAndDropOff(
                1600, 21104, 1, patientId, siteId,
                new hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils().getPickUpDate(),
                new hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils().getExpiryDate(),
                numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");
        Reporter.log("DropOff completed via API");
        return dropOffResp.getDataResponse();
    }

    private String completeInputViaAPI(String dropOffResponsePayload) {
        hwqe.baseframework.apicontext.ServiceResponse inputAcceptResp = connexusAPIManager.inputAccept(dropOffResponsePayload);
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains("error"), "Input Accept could not be completed");
        hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse inputResp = inputAcceptResp.getDataResponse(hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse.class);
        rxNbr = String.valueOf(inputResp.getRxNbr());
        Reporter.log("Input completed via API. RxNbr: " + rxNbr);
        return inputAcceptResp.getDataResponse();
    }

    private String completeFourPointViaAPI(String inputResponsePayload) {
        hwqe.baseframework.apicontext.ServiceResponse fourPointResp = connexusAPIManager.fourPointCheck(inputResponsePayload);
        Assert.assertEquals(fourPointResp.getStatusCode(), 302, "FourPointCheck API response status code did not match");
        Assert.assertFalse(fourPointResp.getDataResponse().contains("error"), "4-Point Check could not be completed");
        Reporter.log("4-Point Check completed via API");
        automationManager.performSleep(30);
        return fourPointResp.getDataResponse();
    }

    private String completeFillingViaAPI(String payload) {
        hwqe.baseframework.apicontext.ServiceResponse fillResp = connexusAPIManager.fillComplete(payload);
        Assert.assertEquals(fillResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillResp.getDataResponse().contains("error"), "Filling could not be completed");
        Reporter.log("Filling completed via API");
        return fillResp.getDataResponse();
    }

    private String completeVVViaAPI(String fillResponsePayload) {
        automationManager.performSleep(5);
        hwqe.baseframework.apicontext.ServiceResponse vvResp = connexusAPIManager.vvComplete(fillResponsePayload);
        Assert.assertEquals(vvResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvResp.getDataResponse().contains("error"), "Visual Verify could not be completed");
        Reporter.log("Visual Verify completed via API");
        return vvResp.getDataResponse();
    }

    private String completePickupViaAPI(String vvResponsePayload) {
        automationManager.performSleep(5);
        hwqe.baseframework.apicontext.ServiceResponse pickupResp = connexusAPIManager.pickupComplete(vvResponsePayload);
        Assert.assertEquals(pickupResp.getStatusCode(), 302, "PickupComplete API response status code did not match");
        Assert.assertFalse(pickupResp.getDataResponse().contains("error"), "Pickup could not be completed");
        Reporter.log("Pickup completed via API");
        return pickupResp.getDataResponse();
    }

    private String completeCounselViaAPI(String pickupResponsePayload) {
        automationManager.performSleep(5);
        hwqe.baseframework.apicontext.ServiceResponse counselResp = connexusAPIManager.counselComplete(pickupResponsePayload);
        Assert.assertEquals(counselResp.getStatusCode(), 302, "CounselComplete API response status code did not match");
        Assert.assertFalse(counselResp.getDataResponse().contains("error"), "Counsel could not be completed");
        Reporter.log("Counsel completed via API");
        return counselResp.getDataResponse();
    }

    private String completePOSViaAPI(String counselResponsePayload) {
        automationManager.performSleep(5);
        hwqe.baseframework.apicontext.ServiceResponse posResp = connexusAPIManager.posComplete(counselResponsePayload);
        Assert.assertEquals(posResp.getStatusCode(), 302, "POSComplete API response status code did not match");
        Assert.assertFalse(posResp.getDataResponse().contains("error"), "POS could not be completed");
        Reporter.log("POS completed via API - Order moved to EOD queue");
        return posResp.getDataResponse();
    }

    private String buildOrderPayloadFromDB() {
        String query = "SELECT rod.rx_fill_id, rod.rx_id, rod.order_id, rod.ord_seq_nbr " +
                "FROM rx_order_detail rod JOIN rx r ON r.rx_id = rod.rx_id " +
                "WHERE r.rx_nbr = " + rxNbr + " AND rod.rx_fill_id = (SELECT MAX(rx_fill_id) FROM rx_order_detail WHERE rx_id = r.rx_id)";
        Map<String, Object> orderInfo = automationManager.getConnexusDB(siteId).executeQuery(query);
        int rxFillId = Integer.parseInt(orderInfo.get("rx_fill_id").toString());
        int rxId = Integer.parseInt(orderInfo.get("rx_id").toString());
        int orderId = Integer.parseInt(orderInfo.get("order_id").toString());
        int ordSeqNbr = Integer.parseInt(orderInfo.get("ord_seq_nbr").toString());
        return String.format("{\"rxNbr\":%s,\"rxFillId\":%d,\"rxId\":%d,\"orderId\":%d,\"orderSeqNbr\":%d,\"siteId\":%d}",
                rxNbr, rxFillId, rxId, orderId, ordSeqNbr, siteId);
    }

  
/**
 * Moves order from DropOff through POS to EOD queue using APIs instead of UI.
 * This method replaces: performDropOff, performInput, perform4Point, performFilling,
 * performVisualVerify, performPickUp, performCounselling, and performPOS with API calls.
 * @param inputData - Test data map containing drug and patient information
 */
public void moveOrderToEODViaAPI(Map<String, String> inputData) {
    String currentStepMethodName = StackUtils.getCurrentMethodName();
    try {
        Reporter.log("Starting API-based order flow to EOD queue");
        String dropOffPayload = completeDropOffViaAPI(inputData);
        String inputPayload = completeInputViaAPI(dropOffPayload);
        String fourPointPayload = completeFourPointViaAPI(inputPayload);
        String fillingPayload = completeCheckDURIfRequiredViaAPI(fourPointPayload);
        String fillPayload = completeFillingViaAPI(fillingPayload);
        String vvPayload = completeVVViaAPI(fillPayload);
        String pickupPayload = completePickupViaAPI(vvPayload);
        String counselPayload = completeCounselViaAPI(pickupPayload);
        completePOSViaAPI(counselPayload);
        Reporter.log("API-based order flow to EOD queue completed successfully");
    } catch (Exception e) {
        isExceptionCaptured = true;
        Reporter.log("API-based order flow failed: " + e.getMessage());
        Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        softAssert.fail(e.toString());
        softAssert.assertAll();
    }
}

public void moveOrderToCounselViaAPI(Map<String, String> inputData) {
    String currentStepMethodName = StackUtils.getCurrentMethodName();
    try {
        Reporter.log("Starting API-based order flow to Counsel queue");
        String dropOffPayload = completeDropOffViaAPI(inputData);
        String inputPayload = completeInputViaAPI(dropOffPayload);
        String fourPointPayload = completeFourPointViaAPI(inputPayload);
        String fillingPayload = completeCheckDURIfRequiredViaAPI(fourPointPayload);
        String fillPayload = completeFillingViaAPI(fillingPayload);
        String vvPayload = completeVVViaAPI(fillPayload);
        completePickupViaAPI(vvPayload);
        Reporter.log("API-based order flow to Counsel queue completed successfully");

    } catch (Exception e) {
        isExceptionCaptured = true;
        Reporter.log("API-based order flow failed: " + e.getMessage());
        Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        softAssert.fail(e.toString());
        softAssert.assertAll();
    }
}

/**
 * Moves order from 4-Point through Filling to Visual Verify queue using APIs instead of UI.
 * This method replaces: perform4Point, performChkDUR, and performFilling with API calls.
 * Assumes order is already in 4-Point queue and rxNbr is set.
 */
public void moveOrderFrom4PointToVVViaAPI() {
    String currentStepMethodName = StackUtils.getCurrentMethodName();
    try {
        Reporter.log("Starting API-based order flow from 4-Point to Visual Verify queue");
        String orderPayload = buildOrderPayloadFromDB();
        String fourPointPayload = completeFourPointViaAPI(orderPayload);
        String fillingPayload = completeCheckDURIfRequiredViaAPI(fourPointPayload);
        completeFillingViaAPI(fillingPayload);
        Reporter.log("API-based order flow from 4-Point to Visual Verify completed successfully");

    } catch (Exception e) {
        isExceptionCaptured = true;
        Reporter.log("API-based order flow failed: " + e.getMessage());
        Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        softAssert.fail(e.toString());
        softAssert.assertAll();
    }
}

/**
 * Moves order from DropOff through Filling to Visual Verify queue using APIs instead of UI.
 * This method replaces: performDropOff, performInput, perform4Point, performChkDUR, and performFilling with API calls.
 * @param inputData - Test data map containing drug and patient information
 */
public void moveOrderFromDropOffToVVViaAPI(Map<String, String> inputData) {
    String currentStepMethodName = StackUtils.getCurrentMethodName();
    try {
        Reporter.log("Starting API-based order flow from DropOff to Visual Verify queue");
        String dropOffPayload = completeDropOffViaAPI(inputData);
        String inputPayload = completeInputViaAPI(dropOffPayload);
        String fourPointPayload = completeFourPointViaAPI(inputPayload);
        String fillingPayload = completeCheckDURIfRequiredViaAPI(fourPointPayload);
        completeFillingViaAPI(fillingPayload);
        Reporter.log("API-based order flow from DropOff to Visual Verify completed successfully");

    } catch (Exception e) {
        isExceptionCaptured = true;
        Reporter.log("API-based order flow failed: " + e.getMessage());
        Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        softAssert.fail(e.toString());
        softAssert.assertAll();
    }
}

/**
 * Moves order from 4-Point through ChkDUR to Filling queue using APIs instead of UI.
 * This method replaces: perform4Point and performChkDUR with API calls.
 * Assumes order is already in 4-Point queue and rxNbr is set.
 */
public void moveOrderFrom4PointToFillingViaAPI() {
    String currentStepMethodName = StackUtils.getCurrentMethodName();
    try {
        Reporter.log("Starting API-based order flow from 4-Point to Filling queue");
        String orderPayload = buildOrderPayloadFromDB();
        String fourPointPayload = completeFourPointViaAPI(orderPayload);
        completeCheckDURIfRequiredViaAPI(fourPointPayload);
        Reporter.log("API-based order flow from 4-Point to Filling completed successfully");

    } catch (Exception e) {
        isExceptionCaptured = true;
        Reporter.log("API-based order flow failed: " + e.getMessage());
        Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        softAssert.fail(e.toString());
        softAssert.assertAll();
    }
}

    public boolean isManualMTRItemFilled()
    {
        try {
            String selectQuery = "SELECT min(Date(piia.adjmt_ts)) mtr_date\n" +
                    " FROM pharmacy_offering:phm_item_inv_adjmt piia, pharmacy_offering:pharmacy_item pi\n" +
                    " WHERE piia.adjmt_type_code IN (6603, 6606)\n" +
                    " AND piia.adjmt_status_code IN (6701, 6705)\n" +
                    " AND (piia.adjmt_qty / (pi.inner_pack_qty * pi.outer_pack_qty)) >= 1.0\n" +
                    " AND pi.mds_fam_id = piia.mds_fam_id\n" +
                    " AND pi.dept_nbr != 38\n" +
                    " AND Date(piia.adjmt_ts) = Date(CURRENT) - 1 UNITS DAY\n" +
                    " AND piia.adjmt_ref_nbr IS NULL" ;
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB().executeQueryForList(selectQuery);
            if (resultSet != null && (resultSet.get(0).get("mtr_date") != null)) {
                isTaskOrderCreated=false;
                System.out.println("Manual MTR items is filled");
            }
            else
            {
                String userid=propertyReader.getProperty("cnx.ho.userName");
                String eventTaskDesc="Print Need to MTR report and complete manual MTR";
                String createMTRQuery ="call CreateTaskOrder(214,201,0, \"" + userid + "\" , \"" + eventTaskDesc + "\")";
                automationManager.getConnexusDB().executeUpdateQuery(createMTRQuery);
                isTaskOrderCreated=true;
            }
            return true;
        } catch (NumberFormatException e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at checking Manual MTR items filled");
            e.printStackTrace();
        }
        return false;
    }

    public void createNewPatientWithTPViaAPI(Map<String, String> inputData) {
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String firstName = name[1];
            String lastName = name[0];

            hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.CreatePatientRequest createPatientRequest =
                    new hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.CreatePatientRequest();
            hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.InsuranceDetails insuranceDetails =
                    new hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.InsuranceDetails();

            createPatientRequest.setFirstName(firstName);
            createPatientRequest.setLastName(lastName);
            createPatientRequest.setSiteId(connexusAppUtils.getStoreId());
            createPatientRequest.setDob(inputData.get("DOB"));
            createPatientRequest.setHomePhone(inputData.get("PRIMARY_NUMBER"));
            createPatientRequest.setWorkPhone(inputData.get("PRIMARY_NUMBER"));
            createPatientRequest.setCellPhone(inputData.get("PRIMARY_NUMBER"));

            createPatientRequest.setPatientHasInsurance(true);
            insuranceDetails.setInsuranceCarrierPlanId(Integer.parseInt(inputData.get("carrierPlanId")));
            insuranceDetails.setInsuranceCarrierCompanyId(Integer.parseInt(inputData.get("carrierCompanyCode")));
            insuranceDetails.setBillingSeqNbr(inputData.get("billSeqNbr") != null && !inputData.get("billSeqNbr").isEmpty() ? Integer.parseInt(inputData.get("billSeqNbr")) : 1);
            insuranceDetails.setCardholderId(inputData.get("cardHolderId") != null && !inputData.get("cardHolderId").isEmpty() ? inputData.get("cardHolderId") : inputData.get("TP_CARD_ID"));
            insuranceDetails.setCardholderFirstName(inputData.get("cardHolderFirstName") != null && !inputData.get("cardHolderFirstName").isEmpty() ? inputData.get("cardHolderFirstName") : firstName);
            insuranceDetails.setCardholderLastName(inputData.get("cardHolderLastName") != null && !inputData.get("cardHolderLastName").isEmpty() ? inputData.get("cardHolderLastName") : lastName);
            insuranceDetails.setRelationshipCode(inputData.get("relationshipCode") != null && !inputData.get("relationshipCode").isEmpty() ? Integer.parseInt(inputData.get("relationshipCode")) : 3201);
            insuranceDetails.setCoverageInd(inputData.get("coverageIndicator") != null && !inputData.get("coverageIndicator").isEmpty() ? inputData.get("coverageIndicator") : "Y");
            insuranceDetails.setCoverageExpDate(inputData.get("covExpDate") != null && !inputData.get("covExpDate").isEmpty() ? inputData.get("covExpDate") : null);
            insuranceDetails.setInsPlanTypeCode(inputData.get("planTypeCode") != null && !inputData.get("planTypeCode").isEmpty() ? Integer.parseInt(inputData.get("planTypeCode")) : 1000);
            insuranceDetails.setSplitBillInd("");

            createPatientRequest.setInsurance(insuranceDetails);
            patientId = connexusAPIManager.createPaientWithOrWithoutTP(createPatientRequest);
            Reporter.log("Created patient with TP plan via API. Patient ID: " + patientId);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
}