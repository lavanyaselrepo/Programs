package connexus.OrderCreation;

import hwqe.baseframework.models.pageobjectmodels.connexus.DropOffPage;
import hwqe.baseframework.utilities.PropertyReader;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class PayloadResource {

    public String getPayload(String payloadType,String[]name,String dob) throws ParseException {
        DropOffPage dropOff = new DropOffPage();
        String random = dropOff.generateRxBarCode();
        String messageID = "messageId" + random;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date(System.currentTimeMillis());
        Date dateOfBirth = new SimpleDateFormat("MM/dd/yyyy").parse(dob);
        PropertyReader propertyReader = PropertyReader.getInstance();
        String storeNo="990"+propertyReader.getProperty("cnx.store").toString();

        //Setting Future Fill Date as Next Day
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE,1);
        Date futureDate = c.getTime();

        String payload="";
        switch (payloadType){
            case "surescriptNewRequst":
                payload="<?xml version=\"1.0\"?><Message xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
                        "DatatypesVersion=\"20170715\" TransportVersion=\"20170715\" TransactionDomain=\"SCRIPT\" TransactionVersion=\"20170715\" StructuresVersion=\"20170715\" ECLVersion=\"20170715\">" +
                        "<Header><To Qualifier=\"P\">"+storeNo+"</To><From Qualifier=\"D\">5262234330002</From><MessageID>" + messageID + "</MessageID>" +
                        "<SentTime>2020-09-08T11:57:00.0364904Z</SentTime><SenderSoftware><SenderSoftwareDeveloper>Surescripts</SenderSoftwareDeveloper><SenderSoftwareProduct>ErxMessageManager</SenderSoftwareProduct>" +
                        "<SenderSoftwareVersionRelease>1.15.0</SenderSoftwareVersionRelease></SenderSoftware><PrescriberOrderNumber>61dfe7a3531a4c8eb10788bb3e3bc8d3</PrescriberOrderNumber></Header>" +
                        "<Body><NewRx><BenefitsCoordination><PayerIdentification><PayerID>T00000000021633</PayerID><ProcessorIdentificationNumber>CAR-123</ProcessorIdentificationNumber><NAICCode>BIN123</NAICCode></PayerIdentification>" +
                        "<CardholderID>MID4444444444444</CardholderID><GroupID>CG1111111111/CGID333333X</GroupID><PBMMemberID>ZZQ%PBM-UID-888877222-%VVVVAAAA10011XX-XX261L</PBMMemberID></BenefitsCoordination><Patient><HumanPatient><Name><LastName>" + name[0] + "</LastName>" +
                        "<FirstName>" + name[1] + "</FirstName></Name><Gender>M</Gender><DateOfBirth><Date>"+formatter.format(dateOfBirth) +"</Date></DateOfBirth><Address><AddressLine1>64 Violet Lane</AddressLine1><City>Howey In The Hills</City><StateProvince>FL</StateProvince><PostalCode>34737</PostalCode>" +
                        "<CountryCode>US</CountryCode></Address><CommunicationNumbers><PrimaryTelephone><Number>9508450398</Number></PrimaryTelephone></CommunicationNumbers></HumanPatient></Patient><Pharmacy><Identification><NCPDPID>9905561</NCPDPID></Identification><BusinessName>Walmart Pharmacy 5561</BusinessName>" +
                        "<Address><AddressLine1>1102 SE 5th Street</AddressLine1><City>Bentonville</City><StateProvince>TX</StateProvince><PostalCode>72712</PostalCode><CountryCode>US</CountryCode></Address><CommunicationNumbers><PrimaryTelephone><Number>4798667575</Number></PrimaryTelephone><Fax><Number>4798667576</Number></Fax>" +
                        "</CommunicationNumbers></Pharmacy><Prescriber><NonVeterinarian><Identification><DEANumber>MN3192301</DEANumber><NPI>1811908056</NPI></Identification><Name><LastName>BINGHAM</LastName><FirstName>PETER</FirstName><MiddleName>H</MiddleName></Name><Address><AddressLine1>3305 ROOSEVELT ST</AddressLine1>" +
                        "<City>CARLSBAD</City><StateProvince>CA</StateProvince><PostalCode>920081619</PostalCode><CountryCode>US</CountryCode></Address><CommunicationNumbers><PrimaryTelephone><Number>7617412814</Number></PrimaryTelephone><Fax><Number>7607207700</Number></Fax></CommunicationNumbers></NonVeterinarian></Prescriber>" +
                        "<Observation><Measurement><VitalSign>8302-2</VitalSign><LOINCVersion>2.42</LOINCVersion><Value>62</Value><UnitOfMeasure>[in_i]</UnitOfMeasure><UCUMVersion>!</UCUMVersion><ObservationDate><Date>2018-01-20</Date></ObservationDate></Measurement><Measurement><VitalSign>29463-7</VitalSign><LOINCVersion>2.42</LOINCVersion>" +
                        "<Value>140</Value><UnitOfMeasure>[lb_av]</UnitOfMeasure><UCUMVersion>!</UCUMVersion><ObservationDate><Date>2018-01-23</Date></ObservationDate></Measurement></Observation><MedicationPrescribed><DrugDescription>Magic Mouthwash Diphenhydramine 12.5 mg/5 mL, Viscous lidocaine 2%, Maalox 1 part</DrugDescription><Quantity><Value>900</Value>" +
                        "<CodeListQualifier>CF</CodeListQualifier><QuantityUnitOfMeasure><Code>C28254</Code></QuantityUnitOfMeasure></Quantity><DaysSupply>30</DaysSupply><WrittenDate><DateTime>"+ formatter.format(date)+"</DateTime></WrittenDate><Substitutions>0</Substitutions><NumberOfRefills>1</NumberOfRefills><Diagnosis><ClinicalInformationQualifier>2</ClinicalInformationQualifier>" +
                        "<Primary><Code>K1233</Code><Qualifier>ABF</Qualifier><Description>Oral mucositis (ulcerative) due to radiation</Description></Primary></Diagnosis>" +
                        "<Note>Patient requested peppermint flavoring if possible. Please provide appropriate documentation to patient for how to use this product, including not swallowing solution. A child-resistant package also requested.</Note><DrugCoverageStatusCode>UN</DrugCoverageStatusCode><Sig><SigText>Swish and spit 15 mL orally for 1 minute every 12 hours</SigText>" +
                        "<CodeSystem><SNOMEDVersion>20170131</SNOMEDVersion><FMTVersion>16.03d</FMTVersion></CodeSystem><Instruction><DoseAdministration><DoseDeliveryMethod><Text>Swish</Text><Qualifier>SNOMED</Qualifier><Code>421805007</Code></DoseDeliveryMethod><Dosage><DoseQuantity>15</DoseQuantity><DoseUnitOfMeasure><Text>mL</Text><Qualifier>DoseUnitOfMeasure</Qualifier><Code>C28254</Code>" +
                        "</DoseUnitOfMeasure></Dosage><RouteOfAdministration><Text>oral route</Text><Qualifier>SNOMED</Qualifier><Code>26643006</Code></RouteOfAdministration></DoseAdministration><TimingAndDuration><Interval><IntervalNumericValue>12</IntervalNumericValue><IntervalUnits><Text>hours</Text><Qualifier>SNOMED</Qualifier><Code>307467005</Code></IntervalUnits></Interval>" +
                        "<TimingClarifyingFreeText>for 1 minute every 12 hours</TimingClarifyingFreeText></TimingAndDuration></Instruction></Sig><RxFillIndicator>All Fill Statuses</RxFillIndicator><DeliveryRequest>FIRST FILL DELIVERY</DeliveryRequest><DeliveryLocation>CONTACT PATIENT FOR DELIVERY</DeliveryLocation><FlavoringRequested>Y</FlavoringRequested><CompoundInformation>" +
                        "<FinalCompoundPharmaceuticalDosageForm>C28254</FinalCompoundPharmaceuticalDosageForm><CompoundIngredientsLotNotUsed><CompoundIngredient><CompoundIngredientItemDescription>Diphenhydramine 12.5 mg/5 mL</CompoundIngredientItemDescription><Strength><StrengthValue>12.5</StrengthValue><StrengthForm><Code>C42986</Code></StrengthForm><StrengthUnitOfMeasure><Code>C91131</Code>" +
                        "</StrengthUnitOfMeasure></Strength></CompoundIngredient><Quantity><Value>300</Value><CodeListQualifier>38</CodeListQualifier><QuantityUnitOfMeasure><Code>C28254</Code></QuantityUnitOfMeasure></Quantity></CompoundIngredientsLotNotUsed><CompoundIngredientsLotNotUsed><CompoundIngredient><CompoundIngredientItemDescription>Viscous lidocaine 2%</CompoundIngredientItemDescription>" +
                        "<Strength><StrengthValue>2</StrengthValue><StrengthForm><Code>C42986</Code></StrengthForm><StrengthUnitOfMeasure><Code>C25613</Code></StrengthUnitOfMeasure></Strength></CompoundIngredient><Quantity><Value>300</Value><CodeListQualifier>38</CodeListQualifier><QuantityUnitOfMeasure><Code>C28254</Code></QuantityUnitOfMeasure></Quantity></CompoundIngredientsLotNotUsed><CompoundIngredientsLotNotUsed><CompoundIngredient>" +
                        "<CompoundIngredientItemDescription>Maalox oral suspension</CompoundIngredientItemDescription><Strength><StrengthValue>200/200/20</StrengthValue><StrengthForm><Code>C68992</Code></StrengthForm><StrengthUnitOfMeasure><Code>C91131</Code></StrengthUnitOfMeasure></Strength></CompoundIngredient><Quantity><Value>300</Value><CodeListQualifier>38</CodeListQualifier><QuantityUnitOfMeasure><Code>C28254</Code></QuantityUnitOfMeasure>" +
                        "</Quantity></CompoundIngredientsLotNotUsed></CompoundInformation></MedicationPrescribed></NewRx></Body></Message>";
                break;
            case"surescriptFutureFill":
                payload="<?xml version=\"1.0\"?><Message xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
                        "DatatypesVersion=\"20170715\" TransportVersion=\"20170715\" TransactionDomain=\"SCRIPT\" TransactionVersion=\"20170715\" StructuresVersion=\"20170715\" ECLVersion=\"20170715\">" +
                        "<Header><To Qualifier=\"P\">"+storeNo+"</To><From Qualifier=\"D\">5262234330002</From><MessageID>" + messageID + "</MessageID>" +
                        "<SentTime>2020-09-08T11:57:00.0364904Z</SentTime><SenderSoftware><SenderSoftwareDeveloper>Surescripts</SenderSoftwareDeveloper><SenderSoftwareProduct>ErxMessageManager</SenderSoftwareProduct>" +
                        "<SenderSoftwareVersionRelease>1.15.0</SenderSoftwareVersionRelease></SenderSoftware><PrescriberOrderNumber>61dfe7a3531a4c8eb10788bb3e3bc8d3</PrescriberOrderNumber></Header>" +
                        "<Body><NewRx><BenefitsCoordination><PayerIdentification><PayerID>T00000000021633</PayerID><ProcessorIdentificationNumber>CAR-123</ProcessorIdentificationNumber><NAICCode>BIN123</NAICCode></PayerIdentification>" +
                        "<CardholderID>MID4444444444444</CardholderID><GroupID>CG1111111111/CGID333333X</GroupID><PBMMemberID>ZZQ%PBM-UID-888877222-%VVVVAAAA10011XX-XX261L</PBMMemberID></BenefitsCoordination><Patient><HumanPatient><Name><LastName>" + name[0] + "</LastName>" +
                        "<FirstName>" + name[1] + "</FirstName></Name><Gender>M</Gender><DateOfBirth><Date>"+formatter.format(dateOfBirth) +"</Date></DateOfBirth><Address><AddressLine1>64 Violet Lane</AddressLine1><City>Howey In The Hills</City><StateProvince>FL</StateProvince><PostalCode>34737</PostalCode>" +
                        "<CountryCode>US</CountryCode></Address><CommunicationNumbers><PrimaryTelephone><Number>9508450398</Number></PrimaryTelephone></CommunicationNumbers></HumanPatient></Patient><Pharmacy><Identification><NCPDPID>9905561</NCPDPID></Identification><BusinessName>Walmart Pharmacy 5561</BusinessName>" +
                        "<Address><AddressLine1>1102 SE 5th Street</AddressLine1><City>Bentonville</City><StateProvince>TX</StateProvince><PostalCode>72712</PostalCode><CountryCode>US</CountryCode></Address><CommunicationNumbers><PrimaryTelephone><Number>4798667575</Number></PrimaryTelephone><Fax><Number>4798667576</Number></Fax>" +
                        "</CommunicationNumbers></Pharmacy><Prescriber><NonVeterinarian><Identification><DEANumber>MN3192301</DEANumber><NPI>1811908056</NPI></Identification><Name><LastName>BINGHAM</LastName><FirstName>PETER</FirstName><MiddleName>H</MiddleName></Name><Address><AddressLine1>3305 ROOSEVELT ST</AddressLine1>" +
                        "<City>CARLSBAD</City><StateProvince>CA</StateProvince><PostalCode>920081619</PostalCode><CountryCode>US</CountryCode></Address><CommunicationNumbers><PrimaryTelephone><Number>7617412814</Number></PrimaryTelephone><Fax><Number>7607207700</Number></Fax></CommunicationNumbers></NonVeterinarian></Prescriber>" +
                        "<Observation><Measurement><VitalSign>8302-2</VitalSign><LOINCVersion>2.42</LOINCVersion><Value>62</Value><UnitOfMeasure>[in_i]</UnitOfMeasure><UCUMVersion>!</UCUMVersion><ObservationDate><Date>2018-01-20</Date></ObservationDate></Measurement><Measurement><VitalSign>29463-7</VitalSign><LOINCVersion>2.42</LOINCVersion>" +
                        "<Value>140</Value><UnitOfMeasure>[lb_av]</UnitOfMeasure><UCUMVersion>!</UCUMVersion><ObservationDate><Date>2018-01-23</Date></ObservationDate></Measurement></Observation><MedicationPrescribed><DrugDescription>Magic Mouthwash Diphenhydramine 12.5 mg/5 mL, Viscous lidocaine 2%, Maalox 1 part</DrugDescription><Quantity><Value>900</Value>" +
                        "<CodeListQualifier>CF</CodeListQualifier><QuantityUnitOfMeasure><Code>C28254</Code></QuantityUnitOfMeasure></Quantity><DaysSupply>30</DaysSupply><WrittenDate><DateTime>"+ formatter.format(date)+"</DateTime></WrittenDate><Substitutions>0</Substitutions><NumberOfRefills>1</NumberOfRefills><Diagnosis><ClinicalInformationQualifier>2</ClinicalInformationQualifier>" +
                        "<Primary><Code>K1233</Code><Qualifier>ABF</Qualifier><Description>Oral mucositis (ulcerative) due to radiation</Description></Primary></Diagnosis>" +
                        "<Note>Patient requested peppermint flavoring if possible. Please provide appropriate documentation to patient for how to use this product, including not swallowing solution. A child-resistant package also requested.</Note><DrugCoverageStatusCode>UN</DrugCoverageStatusCode><Sig><SigText>Swish and spit 15 mL orally for 1 minute every 12 hours</SigText>" +
                        "<CodeSystem><SNOMEDVersion>20170131</SNOMEDVersion><FMTVersion>16.03d</FMTVersion></CodeSystem><Instruction><DoseAdministration><DoseDeliveryMethod><Text>Swish</Text><Qualifier>SNOMED</Qualifier><Code>421805007</Code></DoseDeliveryMethod><Dosage><DoseQuantity>15</DoseQuantity><DoseUnitOfMeasure><Text>mL</Text><Qualifier>DoseUnitOfMeasure</Qualifier><Code>C28254</Code>" +
                        "</DoseUnitOfMeasure></Dosage><RouteOfAdministration><Text>oral route</Text><Qualifier>SNOMED</Qualifier><Code>26643006</Code></RouteOfAdministration></DoseAdministration><TimingAndDuration><Interval><IntervalNumericValue>12</IntervalNumericValue><IntervalUnits><Text>hours</Text><Qualifier>SNOMED</Qualifier><Code>307467005</Code></IntervalUnits></Interval>" +
                        "<TimingClarifyingFreeText>for 1 minute every 12 hours</TimingClarifyingFreeText></TimingAndDuration></Instruction></Sig><RxFillIndicator>All Fill Statuses</RxFillIndicator><DeliveryRequest>FIRST FILL DELIVERY</DeliveryRequest><DeliveryLocation>CONTACT PATIENT FOR DELIVERY</DeliveryLocation><FlavoringRequested>Y</FlavoringRequested><CompoundInformation>" +
                        "<FinalCompoundPharmaceuticalDosageForm>C28254</FinalCompoundPharmaceuticalDosageForm><CompoundIngredientsLotNotUsed><CompoundIngredient><CompoundIngredientItemDescription>Diphenhydramine 12.5 mg/5 mL</CompoundIngredientItemDescription><Strength><StrengthValue>12.5</StrengthValue><StrengthForm><Code>C42986</Code></StrengthForm><StrengthUnitOfMeasure><Code>C91131</Code>" +
                        "</StrengthUnitOfMeasure></Strength></CompoundIngredient><Quantity><Value>300</Value><CodeListQualifier>38</CodeListQualifier><QuantityUnitOfMeasure><Code>C28254</Code></QuantityUnitOfMeasure></Quantity></CompoundIngredientsLotNotUsed><CompoundIngredientsLotNotUsed><CompoundIngredient><CompoundIngredientItemDescription>Viscous lidocaine 2%</CompoundIngredientItemDescription>" +
                        "<Strength><StrengthValue>2</StrengthValue><StrengthForm><Code>C42986</Code></StrengthForm><StrengthUnitOfMeasure><Code>C25613</Code></StrengthUnitOfMeasure></Strength></CompoundIngredient><Quantity><Value>300</Value><CodeListQualifier>38</CodeListQualifier><QuantityUnitOfMeasure><Code>C28254</Code></QuantityUnitOfMeasure></Quantity></CompoundIngredientsLotNotUsed><CompoundIngredientsLotNotUsed><CompoundIngredient>" +
                        "<CompoundIngredientItemDescription>Maalox oral suspension</CompoundIngredientItemDescription><Strength><StrengthValue>200/200/20</StrengthValue><StrengthForm><Code>C68992</Code></StrengthForm><StrengthUnitOfMeasure><Code>C91131</Code></StrengthUnitOfMeasure></Strength></CompoundIngredient><Quantity><Value>300</Value><CodeListQualifier>38</CodeListQualifier><QuantityUnitOfMeasure><Code>C28254</Code></QuantityUnitOfMeasure>" +
                        "</Quantity></CompoundIngredientsLotNotUsed></CompoundInformation><OtherMedicationDate><OtherMedicationDate>" +
                        "<Date>"+ formatter.format(futureDate)+"</Date></OtherMedicationDate><OtherMedicationDateQualifier>EffectiveDate</OtherMedicationDateQualifier></OtherMedicationDate></MedicationPrescribed></NewRx></Body></Message>";
                break;
            case "cancelsurescriptrequest":
                    payload="<?xml version=\"1.0\"?>\n" +
                            "<Message xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" DatatypesVersion=\"20170715\" TransportVersion=\"20170715\" TransactionDomain=\"SCRIPT\" TransactionVersion=\"20170715\" StructuresVersion=\"20170715\" ECLVersion=\"20170715\">\n" +
                            "  <Header>\n" +
                            "    <To Qualifier=\"P\">"+storeNo+"</To>\n" +
                            "    <From Qualifier=\"D\">2449809346001</From>\n" +
                            "    <MessageID>"+messageID+"</MessageID>\n" +
                            "    <RelatesToMessageID>ECHO FROM REFRES</RelatesToMessageID>\n" +
                            "    <SentTime>2022-05-18T01:59:57.5620906Z</SentTime>\n" +
                            "    <SenderSoftware>\n" +
                            "      <SenderSoftwareDeveloper>Surescripts</SenderSoftwareDeveloper>\n" +
                            "      <SenderSoftwareProduct>ErxMessageManager</SenderSoftwareProduct>\n" +
                            "      <SenderSoftwareVersionRelease>1.9.0</SenderSoftwareVersionRelease>\n" +
                            "    </SenderSoftware>\n" +
                            "    <PrescriberOrderNumber>a461281967db4ee3b6a181d3c13f4afa</PrescriberOrderNumber>\n" +
                            "  </Header>\n" +
                            "  <Body>\n" +
                            "    <CancelRx>\n" +
                            "      <Patient>\n" +
                            "        <HumanPatient>\n" +
                            "          <Name>\n" +
                            "            <LastName>"+name[0]+"</LastName>\n" +
                            "            <FirstName>"+name[1]+"</FirstName>\n" +
                            "          </Name>\n" +
                            "          <Gender>M</Gender>\n" +
                            "          <DateOfBirth>\n" +
                            "            <Date>"+formatter.format(dateOfBirth)+"</Date>\n" +
                            "          </DateOfBirth>\n" +
                            "          <Address>\n" +
                            "            <AddressLine1>27732 West Alameda Potholeladen Street</AddressLine1>\n" +
                            "            <AddressLine2>Apt 425-B</AddressLine2>\n" +
                            "            <City>Rancho Cucamonga</City>\n" +
                            "            <StateProvince>CA</StateProvince>\n" +
                            "            <PostalCode>917011515</PostalCode>\n" +
                            "            <CountryCode>US</CountryCode>\n" +
                            "          </Address>\n" +
                            "          <CommunicationNumbers>\n" +
                            "            <PrimaryTelephone>\n" +
                            "              <Number>7075214577</Number>\n" +
                            "              <SupportsSMS>Y</SupportsSMS>\n" +
                            "            </PrimaryTelephone>\n" +
                            "            <ElectronicMail>Juancarlos.Usacruz@hotmail.com</ElectronicMail>\n" +
                            "            <HomeTelephone>\n" +
                            "              <Number>7075576314</Number>\n" +
                            "            </HomeTelephone>\n" +
                            "            <WorkTelephone>\n" +
                            "              <Number>8903456098</Number>\n" +
                            "              <Extension>45422142</Extension>\n" +
                            "              <SupportsSMS>N</SupportsSMS>\n" +
                            "            </WorkTelephone>\n" +
                            "            <OtherTelephone>\n" +
                            "              <Number>1709863483</Number>\n" +
                            "            </OtherTelephone>\n" +
                            "          </CommunicationNumbers>\n" +
                            "        </HumanPatient>\n" +
                            "      </Patient>\n" +
                            "      <Pharmacy>\n" +
                            "        <Identification>\n" +
                            "          <NCPDPID>9905510</NCPDPID>\n" +
                            "          <NPI>5689648728</NPI>\n" +
                            "        </Identification>\n" +
                            "        <BusinessName>Wal-Mart Pharmacy 5510</BusinessName>\n" +
                            "        <Address>\n" +
                            "          <AddressLine1>805 SE Moberly Lane</AddressLine1>\n" +
                            "          <City>Bentonville</City>\n" +
                            "          <StateProvince>TX</StateProvince>\n" +
                            "          <PostalCode>72712</PostalCode>\n" +
                            "          <CountryCode>US</CountryCode>\n" +
                            "        </Address>\n" +
                            "        <CommunicationNumbers>\n" +
                            "          <PrimaryTelephone>\n" +
                            "            <Number>4798675309</Number>\n" +
                            "          </PrimaryTelephone>\n" +
                            "          <Fax>\n" +
                            "            <Number>4798675310</Number>\n" +
                            "          </Fax>\n" +
                            "        </CommunicationNumbers>\n" +
                            "      </Pharmacy>\n" +
                            "      <Prescriber>\n" +
                            "        <NonVeterinarian>\n" +
                            "          <Identification>\n" +
                            "            <DEANumber>AN1234561</DEANumber>\n" +
                            "            <NPI>2677842447</NPI>\n" +
                            "          </Identification>\n" +
                            "          <Name>\n" +
                            "            <LastName>Napoletani</LastName>\n" +
                            "            <FirstName>Levi</FirstName>\n" +
                            "          </Name>\n" +
                            "          <Address>\n" +
                            "            <AddressLine1>342 Miles Street</AddressLine1>\n" +
                            "            <City>Sylvania</City>\n" +
                            "            <StateProvince>OH</StateProvince>\n" +
                            "            <PostalCode>43560</PostalCode>\n" +
                            "            <CountryCode>US</CountryCode>\n" +
                            "          </Address>\n" +
                            "          <CommunicationNumbers>\n" +
                            "            <PrimaryTelephone>\n" +
                            "              <Number>4792543838</Number>\n" +
                            "            </PrimaryTelephone>\n" +
                            "            <Fax>\n" +
                            "              <Number>4792543838</Number>\n" +
                            "            </Fax>\n" +
                            "          </CommunicationNumbers>\n" +
                            "        </NonVeterinarian>\n" +
                            "      </Prescriber>\n" +
                            "      <MedicationPrescribed>\n" +
                            "        <DrugDescription>Magic Mouthwash Diphenhydramine 12.5 mg/5 mL, Viscous lidocaine 2%, Maalox 1 part</DrugDescription>\n" +
                            "        <Quantity>\n" +
                            "          <Value>900</Value>\n" +
                            "          <CodeListQualifier>CF</CodeListQualifier>\n" +
                            "          <QuantityUnitOfMeasure>\n" +
                            "            <Code>C28254</Code>\n" +
                            "          </QuantityUnitOfMeasure>\n" +
                            "        </Quantity>\n" +
                            "        <DaysSupply>30</DaysSupply>\n" +
                            "        <WrittenDate>\n" +
                            "          <DateTime>"+ formatter.format(date)+"</DateTime>\n" +
                            "        </WrittenDate>\n" +
                            "        <Substitutions>0</Substitutions>\n" +
                            "        <NumberOfRefills>1</NumberOfRefills>\n" +
                            "        <Diagnosis>\n" +
                            "          <ClinicalInformationQualifier>2</ClinicalInformationQualifier>\n" +
                            "          <Primary>\n" +
                            "            <Code>K1233</Code>\n" +
                            "            <Qualifier>ABF</Qualifier>\n" +
                            "            <Description>Oral mucositis (ulcerative) due to radiation</Description>\n" +
                            "          </Primary>\n" +
                            "          <Secondary>\n" +
                            "            <Code>Z510</Code>\n" +
                            "            <Qualifier>ABF</Qualifier>\n" +
                            "            <Description>Encounter for antineoplastic radiation therapy</Description>\n" +
                            "          </Secondary>\n" +
                            "        </Diagnosis>\n" +
                            "        <Note>Patient requested peppermint flavoring if possible. Please provide appropriate documentation to patient for how to use this product, including not swallowing solution. A child-resistant package also requested.</Note>\n" +
                            "        <Sig>\n" +
                            "          <SigText>Swish and spit 15 mL orally for 1 minute every 12 hours</SigText>\n" +
                            "          <CodeSystem>\n" +
                            "            <SNOMEDVersion>20170131</SNOMEDVersion>\n" +
                            "            <FMTVersion>16.03d</FMTVersion>\n" +
                            "          </CodeSystem>\n" +
                            "          <Instruction>\n" +
                            "            <DoseAdministration>\n" +
                            "              <DoseDeliveryMethod>\n" +
                            "                <Text>Swish</Text>\n" +
                            "                <Qualifier>SNOMED</Qualifier>\n" +
                            "                <Code>421805007</Code>\n" +
                            "              </DoseDeliveryMethod>\n" +
                            "              <Dosage>\n" +
                            "                <DoseQuantity>15</DoseQuantity>\n" +
                            "                <DoseUnitOfMeasure>\n" +
                            "                  <Text>mL</Text>\n" +
                            "                  <Qualifier>DoseUnitOfMeasure</Qualifier>\n" +
                            "                  <Code>C28254</Code>\n" +
                            "                </DoseUnitOfMeasure>\n" +
                            "              </Dosage>\n" +
                            "              <RouteOfAdministration>\n" +
                            "                <Text>oral route</Text>\n" +
                            "                <Qualifier>SNOMED</Qualifier>\n" +
                            "                <Code>26643006</Code>\n" +
                            "              </RouteOfAdministration>\n" +
                            "            </DoseAdministration>\n" +
                            "            <TimingAndDuration>\n" +
                            "              <Interval>\n" +
                            "                <IntervalNumericValue>12</IntervalNumericValue>\n" +
                            "                <IntervalUnits>\n" +
                            "                  <Text>hours</Text>\n" +
                            "                  <Qualifier>SNOMED</Qualifier>\n" +
                            "                  <Code>307467005</Code>\n" +
                            "                </IntervalUnits>\n" +
                            "              </Interval>\n" +
                            "              <TimingClarifyingFreeText>for 1 minute every 12 hours</TimingClarifyingFreeText>\n" +
                            "            </TimingAndDuration>\n" +
                            "          </Instruction>\n" +
                            "        </Sig>\n" +
                            "        <CompoundInformation>\n" +
                            "          <FinalCompoundPharmaceuticalDosageForm>C28254</FinalCompoundPharmaceuticalDosageForm>\n" +
                            "          <CompoundIngredientsLotNotUsed>\n" +
                            "            <CompoundIngredient>\n" +
                            "              <CompoundIngredientItemDescription>Diphenhydramine 12.5 mg/5 mL</CompoundIngredientItemDescription>\n" +
                            "              <Strength>\n" +
                            "                <StrengthValue>12.5</StrengthValue>\n" +
                            "                <StrengthForm>\n" +
                            "                  <Code>C42986</Code>\n" +
                            "                </StrengthForm>\n" +
                            "                <StrengthUnitOfMeasure>\n" +
                            "                  <Code>C91131</Code>\n" +
                            "                </StrengthUnitOfMeasure>\n" +
                            "              </Strength>\n" +
                            "            </CompoundIngredient>\n" +
                            "            <Quantity>\n" +
                            "              <Value>300</Value>\n" +
                            "              <CodeListQualifier>38</CodeListQualifier>\n" +
                            "              <QuantityUnitOfMeasure>\n" +
                            "                <Code>C28254</Code>\n" +
                            "              </QuantityUnitOfMeasure>\n" +
                            "            </Quantity>\n" +
                            "          </CompoundIngredientsLotNotUsed>\n" +
                            "          <CompoundIngredientsLotNotUsed>\n" +
                            "            <CompoundIngredient>\n" +
                            "              <CompoundIngredientItemDescription>Viscous lidocaine 2%</CompoundIngredientItemDescription>\n" +
                            "              <Strength>\n" +
                            "                <StrengthValue>2</StrengthValue>\n" +
                            "                <StrengthForm>\n" +
                            "                  <Code>C42986</Code>\n" +
                            "                </StrengthForm>\n" +
                            "                <StrengthUnitOfMeasure>\n" +
                            "                  <Code>C25613</Code>\n" +
                            "                </StrengthUnitOfMeasure>\n" +
                            "              </Strength>\n" +
                            "            </CompoundIngredient>\n" +
                            "            <Quantity>\n" +
                            "              <Value>300</Value>\n" +
                            "              <CodeListQualifier>38</CodeListQualifier>\n" +
                            "              <QuantityUnitOfMeasure>\n" +
                            "                <Code>C28254</Code>\n" +
                            "              </QuantityUnitOfMeasure>\n" +
                            "            </Quantity>\n" +
                            "          </CompoundIngredientsLotNotUsed>\n" +
                            "          <CompoundIngredientsLotNotUsed>\n" +
                            "            <CompoundIngredient>\n" +
                            "              <CompoundIngredientItemDescription>Maalox oral suspension</CompoundIngredientItemDescription>\n" +
                            "              <Strength>\n" +
                            "                <StrengthValue>200/200/20</StrengthValue>\n" +
                            "                <StrengthForm>\n" +
                            "                  <Code>C68992</Code>\n" +
                            "                </StrengthForm>\n" +
                            "                <StrengthUnitOfMeasure>\n" +
                            "                  <Code>C91131</Code>\n" +
                            "                </StrengthUnitOfMeasure>\n" +
                            "              </Strength>\n" +
                            "            </CompoundIngredient>\n" +
                            "            <Quantity>\n" +
                            "              <Value>300</Value>\n" +
                            "              <CodeListQualifier>38</CodeListQualifier>\n" +
                            "              <QuantityUnitOfMeasure>\n" +
                            "                <Code>C28254</Code>\n" +
                            "              </QuantityUnitOfMeasure>\n" +
                            "            </Quantity>\n" +
                            "          </CompoundIngredientsLotNotUsed>\n" +
                            "        </CompoundInformation>\n" +
                            "      </MedicationPrescribed>\n" +
                            "    </CancelRx>\n" +
                            "  </Body>\n" +
                            "</Message>";
                    break;

        }
       return payload;

    }
}
