package connexus.OrderCreation;

import com.aventstack.extentreports.Status;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.Map;

public class TestScripts {
    LoginPage loginPage;
    ConnexusStartPage connexusStartPage;
    PatientSearchPage patientSearchPage;
    TascoPage tascoPage;
    PatientMaintenancePage patientMaintenancePage;
    DropOffPage dropOffPage;
    F6Search orderSearch;
    FourPoint fourPoint;
    InputPage inputPage;
    ModifyDetails modifyDetails;
    ConnexusAppUtils connexusAppUtils;
    AutomationManager automationManager;
    DropRxModel dropRxModel;
    RxModel rxModel;
    SoftAssert softAssert = new SoftAssert();
    String rxNbr = null;
    PatientProfileModel patient = new PatientProfileModel();
    AddressModel addressModel = new AddressModel();
    ContactModel contactModel = new ContactModel();
    PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
    ThirdPartyModel thirdPartyModel = new ThirdPartyModel();

    PrescriberSearchPage prescriberSearchPage;
    MenuBar menuBar;
    F6Search rxSearch;


    public void loginConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        connexusStartPage =new ConnexusStartPage();
        connexusAppUtils = new ConnexusAppUtils();
        prescriberSearchPage = new PrescriberSearchPage();
        menuBar = new MenuBar();
        rxSearch = new F6Search();
        inputPage = new InputPage();
        fourPoint = new FourPoint();
        modifyDetails = new ModifyDetails();
        automationManager = AutomationManager.getInstance();
        loginPage.loginConnexus(userType);
    }

    /**
     * Method to open Prescriber Search window by pressing the Keyboard shortcut CTRL+SHIFT+B
     * Author: Srinivas(vn50jui)
     * */
    public void openPrescriberSearchWindow() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusStartPage.inputShortcutKeys(AppShortcuts.PRESCRIBER.getAppShortcuts());
            automationManager.performSleep(2);
            Assert.assertTrue(prescriberSearchPage.isPrescriberSearchWindowDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for a prescriber and verify search results
     * Author: Srinivas(vn50jui)
     * */
    public void searchForPrescriberAndVerifySearchResults(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            prescriberSearchPage.inputPrescriberName(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.isPrescriberRecordDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInCtColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInNameColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInNPIColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInPhoneColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInAddressColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInCityColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInStateColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInFaxColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNameFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NAME")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to close the Prescriber Search window by clicking on close button
     * Author: Srinivas(vn50jui)
     * */
    public void closePrescriberSearchWindowByClickingOnCloseButton() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            prescriberSearchPage.clickClose();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to open Prescriber Search window from Search Menu
     * Author: Srinivas(vn50jui)
     * */
    public void openPrescriberSearchWindowFromSearchMenu() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            menuBar.navigateToMenu(AppMenu.PRESCRIBER);
            automationManager.performSleep(2);
            Assert.assertTrue(prescriberSearchPage.isPrescriberSearchWindowDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to enter invalid phone number in Phone field in Prescriber Search window and verify whether 'Invalid Phone Number Format' popup is displayed
     * Author: Srinivas(vn50jui)
     * */
    public void invalidPhoneNumberVerification(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            prescriberSearchPage.inputPrescriberPhone(inputData.get("PRESCRIBER_PHONE"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.isInvalidPhoneNumberFormatPopDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickOKOnInvalidPhoneNumberPopup();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify search history in all text fields on Prescriber Search and validate search results
     * It selects the previous search values in text fields and then perform Search
     * Author: Srinivas(vn50jui)
     * */
    public void checkPrescriberSearchHistory(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            do {
                prescriberSearchPage.pressDownArrowKeyInNameSearchField();
            } while (!inputData.get("PRESCRIBER_NAME").equalsIgnoreCase(prescriberSearchPage.getValueFromNameTextField()));

            do {
                prescriberSearchPage.pressDownArrowKeyInNPISearchField();
            } while (!inputData.get("PRESCRIBER_NPI").equalsIgnoreCase(prescriberSearchPage.getValueFromNPITextField()));

            do {
                prescriberSearchPage.pressDownArrowKeyInDEASearchField();
            } while (!inputData.get("PRESCRIBER_DEA").equalsIgnoreCase(prescriberSearchPage.getValueFromDEATextField()));

            do {
                prescriberSearchPage.pressDownArrowKeyInFaxSearchField();
            } while (!inputData.get("PRESCRIBER_FAX").equalsIgnoreCase(prescriberSearchPage.getValueFromFaxTextField()));

            do {
                prescriberSearchPage.pressDownArrowKeyInSPISearchField();
            } while (!inputData.get("PRESCRIBER_SPI").equalsIgnoreCase(prescriberSearchPage.getValueFromSPITextField()));

            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.isPrescriberRecordDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNameFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NAME")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNPIFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NPI")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberPhoneFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_PHONE")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberFaxFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_FAX")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for a prescriber with all search fields and verify search results
     * Author: Srinivas(vn50jui)
     * */
    public void searchForPrescriberWithAllFields(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            prescriberSearchPage.inputPrescriberName(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.inputPrescriberNPI(inputData.get("PRESCRIBER_NPI"));
            prescriberSearchPage.inputPrescriberDEA(inputData.get("PRESCRIBER_DEA"));
            prescriberSearchPage.inputPrescriberPhone(inputData.get("PRESCRIBER_PHONE"));
            prescriberSearchPage.inputPrescriberFAX(inputData.get("PRESCRIBER_FAX"));
            prescriberSearchPage.inputPrescriberSPI(inputData.get("PRESCRIBER_SPI"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.isPrescriberRecordDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInCtColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInNameColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInNPIColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInPhoneColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInAddressColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInCityColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInStateColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInFaxColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNameFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NAME")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNPIFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NPI")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberPhoneFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_PHONE")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberFaxFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_FAX")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify if the Prescriber Search Window is closed when the user pressed ESC button
     * Author: Srinivas(vn50jui)
     * */
    public void closePrescriberSearchWindowsByPressingEscapeButton() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            prescriberSearchPage.closeProductSearchWindowsByPressingEscButton();
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to open Prescriber Maintenance screen by double clicking on the search result from Prescriber Search grid
     * Author: Srinivas(vn50jui)
     * */
    public void openPrescriberMaintenanceByDoubleClickingOnSearchRecord() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.doubleClickOnSearchGridRow(0);
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to open Prescriber Maintenance screen by double clicking on the search result from Prescriber Search grid
     * Author: Srinivas(vn50jui)
     * */
    public void verifyWhetherPrescriberMaintenanceDisplayed(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertTrue(prescriberSearchPage.isPrescriberMaintenanceWindowDisplayed());
            Assert.assertTrue(inputData.get("PRESCRIBER_NAME").contains(prescriberSearchPage.getPrescriberLastNameFromMaintenanceScreen()));
            Assert.assertTrue(inputData.get("PRESCRIBER_NAME").contains(prescriberSearchPage.getPrescriberFirstNameFromMaintenanceScreen()));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to close Prescriber Maintenance screen by clicking on Cancel button
     * Author: Srinivas(vn50jui)
     * */
    public void closePrescriberMaintenanceWindowByClickingOnCancel() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickCancelButtonOnPrescriberMaintenanceWindow();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for a prescriber that does not exist and verify if the results grid is empty
     * Author: Srinivas(vn50jui)
     * */
    public void verifyEmptySearchResultsGridWhenNoResultsFound(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            prescriberSearchPage.inputPrescriberName(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertFalse(prescriberSearchPage.isPrescriberRecordDisplayed(0));
            Assert.assertFalse(prescriberSearchPage.isDataInCtColumnDisplayed(0));
            Assert.assertFalse(prescriberSearchPage.isDataInNameColumnDisplayed(0));
            Assert.assertFalse(prescriberSearchPage.isDataInNPIColumnDisplayed(0));
            Assert.assertFalse(prescriberSearchPage.isDataInPhoneColumnDisplayed(0));
            Assert.assertFalse(prescriberSearchPage.isDataInAddressColumnDisplayed(0));
            Assert.assertFalse(prescriberSearchPage.isDataInCityColumnDisplayed(0));
            Assert.assertFalse(prescriberSearchPage.isDataInStateColumnDisplayed(0));
            Assert.assertFalse(prescriberSearchPage.isDataInFaxColumnDisplayed(0));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for a prescriber with Name, NPI and DEA search fields and verify search results
     * Author: Srinivas(vn50jui)
     * */
    public void searchForPrescriberWith_Name_NPI_DEA_Fields(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            prescriberSearchPage.inputPrescriberName(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.inputPrescriberNPI(inputData.get("PRESCRIBER_NPI"));
            prescriberSearchPage.inputPrescriberDEA(inputData.get("PRESCRIBER_DEA"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.isPrescriberRecordDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInCtColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInNameColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInNPIColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInPhoneColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInAddressColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInCityColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInStateColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.isDataInFaxColumnDisplayed(0));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNameFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NAME")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNPIFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NPI")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberPhoneFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_PHONE")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberFaxFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_FAX")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to Search for a Patient on Patient Search Window and then create a new patient
     * Author: Srinivas(vn50jui)
     */
    public void createPatient(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            PatientProfileModel patient = new PatientProfileModel();
            AddressModel addressModel = new AddressModel();
            ContactModel contactModel = new ContactModel();
            PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
            PatientIdentityModel patientIdentityModel = new PatientIdentityModel();

            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS_LINE_1"));
            addressModel.setPatientAddressLine2(inputData.get("ADDRESS_LINE_2"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            //addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            contactModel.setPatientPhoneNumber1(inputData.get("PHONE_NUMBER1"));
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            contactModel.setPreferredPhoneNumber(ContactModel.PreferredPhoneNumber.PHONE_NUMBER1);
            patient.setPatientContact(contactModel);
            patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
            patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
            patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));
            patient.setPatientIdentityModel(patientIdentityModel);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            //Search and Create a New Patient
            automationManager.getConnexusWorkFlow().searchAndCreatePatient(false, patient);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to Drop and RX for the newly created patient
     * Author: Srinivas(vn50jui)
     */
    public void performDropOffForNewPatient() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            DropRxModel dropRxModel = new DropRxModel();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            dropRxModel.setOrderComment("TESTING");

            //Complete Drop-Off
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for an Order or Patient on Order Search Window and open the order from search results
     * Author: Srinivas(vn50jui)
     */
    public void openRXinInputScreen(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            automationManager.performSleep(2);
            rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            rxSearch.selectRowFromSearch(0);
            automationManager.performSleep(4);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, rxSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to close the Input screen
     * Author: Srinivas(vn50jui)
     */
    public void closeInputScreen() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickCancel();
            connexusStartPage.clickYes();
            automationManager.performSleep(4);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to Drop and RX for the newly created patient
     * Author: Srinivas(vn50jui)
     */
    public void searchForPrescriberInInputScreenAndVerifyResults(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.searchForPrescriber(inputData.get("PRESCRIBER_NAME"));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNameFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NAME")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNPIFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NPI")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberPhoneFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_PHONE")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberFaxFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_FAX")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberDEAFromSearchGrid(0).contains(inputData.get("PRESCRIBER_DEA")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            prescriberSearchPage.clickClose();
        }
    }

    /**
     * Method to perform new search on Prescriber Search window which is opened from Input screen
     * Author: Srinivas(vn50jui)
     */
    public void clearSearchAndSearchAgainForPrescriberInInputScreenAndVerifyResults(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            prescriberSearchPage.clickClearSearch();
            prescriberSearchPage.inputPrescriberName(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.getPrescriberNameFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NAME")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNPIFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NPI")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberPhoneFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_PHONE")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberFaxFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_FAX")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberDEAFromSearchGrid(0).contains(inputData.get("PRESCRIBER_DEA")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether Prescriber Maintenance screen is displayed on clicking New Button
     * Author: Srinivas(vn50jui)
     */
    public void clickOnNewButtonAndVerifyIfPrescriberMaintenanceScreenDisplayed() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            prescriberSearchPage.clickSearchHost();
            prescriberSearchPage.clickNew();
            Assert.assertTrue(prescriberSearchPage.isPrescriberMaintenanceWindowDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickCancelButtonOnPrescriberMaintenanceWindow();
            prescriberSearchPage.clickYesButtonOnPrescriberMaintenanceAbandonChangesPopUp();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether user able to search prescriber using different search combinations
     * Author: Srinivas(vn50jui)
     * */
    public void searchWithDifferentCombinationsAndVerifySearchResults(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            prescriberSearchPage.inputPrescriberName(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.inputPrescriberNPI(inputData.get("PRESCRIBER_NPI"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.getPrescriberNameFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NAME")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNPIFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NPI")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberPhoneFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_PHONE")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberFaxFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_FAX")));
            Reporter.logScreenShot(Status.PASS, "NAME and NPI Search Combination", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            prescriberSearchPage.inputPrescriberNPI(inputData.get("PRESCRIBER_NPI"));
            prescriberSearchPage.inputPrescriberDEA(inputData.get("PRESCRIBER_DEA"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.getPrescriberNameFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NAME")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNPIFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NPI")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberPhoneFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_PHONE")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberFaxFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_FAX")));
            Reporter.logScreenShot(Status.PASS, "NPI and DEA Search Combination", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            prescriberSearchPage.inputPrescriberDEA(inputData.get("PRESCRIBER_DEA"));
            prescriberSearchPage.inputPrescriberPhone(inputData.get("PRESCRIBER_PHONE"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.getPrescriberNameFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NAME")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNPIFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NPI")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberPhoneFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_PHONE")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberFaxFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_FAX")));
            Reporter.logScreenShot(Status.PASS, "DEA and PHONE Search Combination", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            prescriberSearchPage.inputPrescriberPhone(inputData.get("PRESCRIBER_PHONE"));
            prescriberSearchPage.inputPrescriberFAX(inputData.get("PRESCRIBER_FAX"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.getPrescriberNameFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NAME")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNPIFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NPI")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberPhoneFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_PHONE")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberFaxFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_FAX")));
            Reporter.logScreenShot(Status.PASS, "PHONE and FAX Search Combination", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClearSearch();
            prescriberSearchPage.inputPrescriberNPI(inputData.get("PRESCRIBER_NPI"));
            prescriberSearchPage.inputPrescriberSPI(inputData.get("PRESCRIBER_SPI"));
            prescriberSearchPage.clickSearchStore();
            Assert.assertTrue(prescriberSearchPage.getPrescriberNameFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NAME")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberNPIFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NPI")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberPhoneFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_PHONE")));
            Assert.assertTrue(prescriberSearchPage.getPrescriberFaxFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_FAX")));
            Reporter.logScreenShot(Status.PASS, "NPI and SPI Search Combination", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether user able to search prescriber using Phone, Fax and SPI combinations
     * Author: Srinivas(vn50jui)
     * */
    public void searchWithPhoneFaxSPICombinationAndVerifySearchResults(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            prescriberSearchPage.inputPrescriberPhone(inputData.get("PRESCRIBER_PHONE"));
            prescriberSearchPage.inputPrescriberFAX(inputData.get("PRESCRIBER_FAX"));
            prescriberSearchPage.inputPrescriberSPI(inputData.get("PRESCRIBER_SPI"));
            prescriberSearchPage.clickSearchStore();
            softAssert.assertTrue(prescriberSearchPage.getPrescriberNameFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NAME")));
            softAssert.assertTrue(prescriberSearchPage.getPrescriberNPIFromSearchGrid(0).contains(inputData.get("PRESCRIBER_NPI")));
            softAssert.assertTrue(prescriberSearchPage.getPrescriberPhoneFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_PHONE")));
            softAssert.assertTrue(prescriberSearchPage.getPrescriberFaxFromSearchGrid(0).replaceAll("[()\\s-]+", "").contains(inputData.get("PRESCRIBER_FAX")));
            Reporter.logScreenShot(Status.PASS, "Phone, Fax and SPI Search Combination", prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to Search for a Patient on Patient Search Window and then create a new patient with Primary Number
     * Author: Srinivas(vn50jui)
     */
    public void createPatientWithPrimaryPhoneNumber(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            PatientProfileModel patient = new PatientProfileModel();
            AddressModel addressModel = new AddressModel();
            ContactModel contactModel = new ContactModel();
            PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
            PatientIdentityModel patientIdentityModel = new PatientIdentityModel();

            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("PATIENT_DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("PATIENT_ADDRESS"));
            addressModel.setPatientCity(inputData.get("PATIENT_CITY"));
            addressModel.setPatientState(inputData.get("PATIENT_STATE"));
            addressModel.setPatientZipCode(inputData.get("PATIENT_ZIP"));
            addressModel.setPatientCountry(inputData.get("PATIENT_COUNTRY"));
            patient.setPatientAddress(addressModel);
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);
            patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
            patientIdentityModel.setPatientDrivingLicenseState(inputData.get("PATIENT_STATE"));
            patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));
            patient.setPatientIdentityModel(patientIdentityModel);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            //Search and Create a New Patient
            automationManager.getConnexusWorkFlow().searchAndCreatePatient(false, patient);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to perform DropOff and Input for a Patient
     * Author: Srinivas(vn50jui)
     * */
    public void performDropOff(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            DropRxModel dropRxModel =new DropRxModel();

            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    /**
     * Method to perform DropOff and Input for a Patient
     * Author: Srinivas(vn50jui)
     * */
    public void performNaloxoneDropOff(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            DropRxModel dropRxModel =new DropRxModel();

            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to perform Input for a Patient
     * Author: Srinivas(vn50jui)
     * */
    public void performInput(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            RxModel rxModel = new RxModel();

            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxModel.setNdc(inputData.get("DRUG_NAME"));
            rxModel.setPrescribedQty(inputData.get("QUANTITY"));
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            automationManager.getConnexusWorkFlow().performInput(rxModel);
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether user able to select Prescriber who doesn't have DEA for normal drugs
     * Author: Srinivas(vn50jui)
     * */
    public void verifyPrescriberWithoutDEAForNonControlledDrugs(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] patientName = connexusAppUtils.readPatientNameFromFile();
            String name = patientName[0] + "," + patientName[1];
            automationManager.performSleep(2);
            rxSearch.performSearch(name, SearchType.PatientRx);
            rxSearch.selectRowFromSearch(0);
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterPrescriberNameInPrescriber(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.clickSelectButtonOnPrescriberSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for the Patient on Order Search Window and verify that Prescriber details are matched
     * Author: Srinivas(vn50jui)
     * */
    public void searchForOrderAndVerifyPrescriberDetails(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] patientName = connexusAppUtils.readPatientNameFromFile();
            String name = patientName[0] + "," + patientName[1];
            automationManager.performSleep(2);
            rxSearch.performSearch(name, SearchType.PatientRx);
            automationManager.performSleep(5);
            rxSearch.sendHotKeys(Keys.END);
            softAssert.assertTrue(rxSearch.getPrescriberName(0).equalsIgnoreCase(inputData.get("PRESCRIBER_NAME")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            rxSearch.closeSearch();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to perform Four Point >> Modify Details >> Modify Prescriber details >> save and close
     * Author: Srinivas(vn50jui)
     * */
    public void openRXinFourPointAndModifyPrescriberDetails(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] patientName = connexusAppUtils.readPatientNameFromFile();
            String name = patientName[0] + "," + patientName[1];
            if(automationManager.getConnexusWorkFlow().checkRxWorkQue(name, WorkQueue.FOUR_POINT)){
                automationManager.performSleep(2);
                rxSearch.performSearch(name, SearchType.PatientRx);
                rxSearch.selectRowFromSearch(0);
                automationManager.performSleep(15);
                modifyDetails.openModifyDetailsScreen();
                automationManager.performSleep(15);
                modifyDetails.clearPrescriberName();
                modifyDetails.enterPrescriberName(inputData.get("NEW_PRESCRIBER_NAME"));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickAccept();
                automationManager.performSleep(15);
                fourPoint.clickButtonCancel();
            }
            else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for the Patient on Order Search Window and verify that modified Prescriber details are matched
     * Author: Srinivas(vn50jui)
     * */
    public void searchForOrderAndVerifyModifiedPrescriberDetails(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] patientName = connexusAppUtils.readPatientNameFromFile();
            String name = patientName[0] + "," + patientName[1];
            automationManager.performSleep(2);
            rxSearch.performSearch(name, SearchType.PatientRx);
            automationManager.performSleep(3);
            rxSearch.sendHotKeys(Keys.END);
            softAssert.assertTrue(rxSearch.getPrescriberName(0).equalsIgnoreCase(inputData.get("NEW_PRESCRIBER_NAME")));
            softAssert.assertAll();
            rxSearch.closeSearch();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to complete 4 Point
     * Author: Srinivas(vn50jui)
     */
    public void completeFourPoint(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to complete ChkDUR
     * Author: Srinivas(vn50jui)
     */
    public void completeChkDUR(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to perform Modify Drug In CheckDur
     * Author: Narayanaswamy(n0s06rk)
     */
    public void performModifyDrugInCheckDur() {
        F6Search search = new F6Search();
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        System.out.print("w1");
        try {
            System.out.print("w2");
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatus("8808273");
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                search.selectRowFromSearch(0);
                automationManager.performSleep(2);
                modifyDetails.openModifyDetailsScreen();
                inputPage.clearPrescribedProduct();
                inputPage.enterNdc("74312001130");
                inputPage.clickAccept();
                inputPage.clickButtonOk();
            }
        } catch (Exception e) {
            Reporter.log("Test failed at ChkDUR queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to complete Resolution
     * Author: Srinivas(vn50jui)
     */
    public void completeResolution(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            if(automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr, WorkQueue.RESOLVE)){
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void createNewPatient(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);

            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));

            patientMaintenancePage.sendHotKeys(Keys.TAB);
            patientMaintenancePage.switchWindow();

            if (patientMaintenancePage.isOkDisplayed()) {
                patientMaintenancePage.clickOk();
            }
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            patient.setPatientTp(thirdPartyModel);

            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            automationManager.getConnexusWorkFlow().createNewPatient(false, patient);

            Reporter.log("Patient has been created.");
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to search for an Order or Patient on Order Search Window and open the order from search results
     * This method explicitly works if the RX is in Filling Queue.
     * Author: Srinivas(vn50jui)
     */
    public void openRXinFillingQueue(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            if(automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr, WorkQueue.FILLING)){
                automationManager.performSleep(2);
                rxSearch.performSearch(rxNbr, SearchType.PatientRx);
                rxSearch.selectRowFromSearch(0);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            }
            else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify the data in Prescriber Address and Prescriber DEA on changing the Prescriber in Results grid
     * Author: Srinivas(vn50jui)
     * */
    public void verifyPrescriberDetailsInModifyDetailsScreen(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(10);
            modifyDetails.openPrescriberSearchWindow();
            modifyDetails.clearText(modifyDetails.cmbPrescriberName);
            modifyDetails.sendText(modifyDetails.cmbPrescriberName, inputData.get("PRESCRIBER_NAME").split(",")[0]);
            prescriberSearchPage.clickSearchStore();
            softAssert.assertTrue(prescriberSearchPage.isPrescriberRecordDisplayed(0));
            softAssert.assertTrue(prescriberSearchPage.isDataInCtColumnDisplayed(0));
            softAssert.assertTrue(prescriberSearchPage.isDataInNameColumnDisplayed(0));
            softAssert.assertTrue(prescriberSearchPage.isDataInPhoneColumnDisplayed(0));
            softAssert.assertTrue(prescriberSearchPage.isDataInAddressColumnDisplayed(0));
            softAssert.assertTrue(prescriberSearchPage.isDataInCityColumnDisplayed(0));
            softAssert.assertTrue(prescriberSearchPage.isDataInStateColumnDisplayed(0));

            String prescriber1Address = prescriberSearchPage.getPrescriberAddressFromSearchGrid(0);
            String prescriber1DEA = prescriberSearchPage.getPrescriberDEAFromSearchGrid(0);

            prescriberSearchPage.selectPrescriberRow(1);

            String prescriber2Address = prescriberSearchPage.getPrescriberAddressFromSearchGrid(0);
            String prescriber2DEA = prescriberSearchPage.getPrescriberDEAFromSearchGrid(0);

            softAssert.assertNotEquals(prescriber1Address, prescriber2Address);
            softAssert.assertNotEquals(prescriber1DEA, prescriber2DEA);

            Reporter.logScreenShot(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickClose();
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to close the Modify Details screen
     * Author: Srinivas(vn50jui)
     */
    public void closeModifyDetailsScreen() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            modifyDetails.clickCancel();
            connexusStartPage.clickYes();
            automationManager.performSleep(4);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether user able to select Prescriber who doesn't have DEA for normal drugs
     * Author: Srinivas(vn50jui)
     * */
    public void verifyPrescriberWithoutDEAForControlledDrugs(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] patientName = connexusAppUtils.readPatientNameFromFile();
            String name = patientName[0] + "," + patientName[1];
            automationManager.performSleep(2);
            rxSearch.performSearch(name, SearchType.PatientRx);
            rxSearch.selectRowFromSearch(0);
            automationManager.performSleep(4);
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterPrescriberNameInPrescriber(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.clickSelectButtonOnPrescriberSearch();
            softAssert.assertTrue(prescriberSearchPage.isDEAExpiredPopUpDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            prescriberSearchPage.clickOKButtonOnDEAExpiredPopUp();
            prescriberSearchPage.clickClose();
            prescriberSearchPage.clickOKButtonOnDEAExpiredPopUp();
            inputPage.clickCancel();
            inputPage.clickYes();
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


}
