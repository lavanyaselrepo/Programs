package connexus.OrderCreation.testcases;

import connexus.OrderCreation.testscripts.OrderCreationCommonFunctions;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class OrderCreationRegressionTestSet3 {

    OrderCreationCommonFunctions orderCreationCommonFunctions=new OrderCreationCommonFunctions(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils=new ConnexusAppUtils();
    PropertyReader prop = PropertyReader.getInstance();
    String siteId =prop.getProperty("cnx.store");
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    public static LoginAs.userType loginUser_Type=LoginAs.userType.HOMEOFFICE_ADFlagOn;
    boolean flagUpdated = false;


    @BeforeClass
    public void performLogin(){
        connexusAppUtils.startAppiumServer();
        CheckAndSetPreConditions();
    }

    private void CheckAndSetPreConditions() {
        //Set the state to AR for the current store
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("32550","TRUE");
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("31053","TRUE");

        //Verify and set the flag 28750 (AD Authentication) to TRUE
        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        flagUpdated |=connexusAppUtils.readAndUpdateFlag("28750", "TRUE");

        //Verify and set the flag 26849 (Redesign Contact Information) to TRUE
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("26849", "TRUE");

        //Verify and set the flag 8670 (Enable/Disable Bagging queue) to FALSE
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("8670", "FALSE");

        //Verify and set the flag 26218 (Bagging Queue Enabled) to FALSE
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("26218", "FALSE");

        //Verify and set the flag 15166 (Flag to Enable ABN Changes) to TRUE
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("15166", "TRUE");

        //Verify and set the flag 24550 (Advanced Beneficiary Notice (ABN) Requirement) to FALSE
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("24550", "FALSE");

        //Verify that Max Daily Dose Altered Flag is set to True
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("31153", "TRUE");

        flagUpdated |=connexusAppUtils.isManualMTRItemFilled();
    }


    @AfterClass
    public void tearDown(){
        orderCreationCommonFunctions.CloseConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description:verify the Third party days supply value for subsequent fill in addition_val column of clm_override_addtn table when Third party days supply value of original fill is empty/zero|
* Pre-Conditions: 1. 32550 =TRUE,24550=FALSE
* Author: Priyanka(p0j01ks)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-329")
    @Test(enabled = true, description = "TP_Days_Supply_Refill Counseling_TP_Rej",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_329_tc_12_TP_Days_Supply_Blank_Refill(Map<String, String> inputData) {
        Reporter.log(">>>tc_12_TP_Days_Supply_Refill<<<");

        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);

        // Create a new patient
        orderCreationCommonFunctions.createNewPatient(inputData,1);

        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();

        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);

        //Verify thirdParty Days supply value
        orderCreationCommonFunctions.isTPDaysSupplyFieldEnabled(WorkQueue.RESOLVE, true, "enabled");

        //Enter Blank/0 Days of Supply
        orderCreationCommonFunctions.enterTPDaysSupplyValueAndSubmit("0");

        //Perform Resolution
        orderCreationCommonFunctions.performResolution();

        //Complete 4Point
        orderCreationCommonFunctions.perform4Point();

        //Complete Filling
        orderCreationCommonFunctions.performFilling();

        //Complete Visual Verify
        orderCreationCommonFunctions.performVisualVerify();

        //Perform DropOff for an RX which has Refills
        orderCreationCommonFunctions.performDropOffForRXWithRefills();

        //Perform Resolution
        orderCreationCommonFunctions.performResolution();

        //verify TPDaysSupplyValue
        orderCreationCommonFunctions.verifyTpDaysSupplyCount("0",true);

        Reporter.log("<<<tc_12_TP_Days_Supply_Refill>>>");
    }


    /*----------------------------------------------------------------------------------------------------------
* Test Description:verify the Third party days supply value for subsequent fill in addition_val column of clm_override_addtn table when flag is ON.|
* Pre-Conditions: 1. 32550 =TRUE,24550=FALSE
* Author: Priyanka(p0j01ks)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-324")
    @Test(enabled = true, description = "TP_Days_Supply_Refill Counseling_TP_Rej",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_324_tc_13_TP_Days_Supply_Value_Refill(Map<String, String> inputData) {
        Reporter.log(">>>tc_13_TP_Days_Supply_Value_Refill<<<");

        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        //Create a new patient
        orderCreationCommonFunctions.createNewPatient(inputData,1);

        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();

        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);

        //Verify thirdParty Days supply value
        orderCreationCommonFunctions.isTPDaysSupplyFieldEnabled(WorkQueue.RESOLVE, true, "enabled");

        //Enter valid Days of Supply > 0
        orderCreationCommonFunctions.enterTPDaysSupplyValueAndSubmit("10");

        //Perform Resolution
        orderCreationCommonFunctions.performResolution();

        //Complete 4Point
        orderCreationCommonFunctions.perform4Point();

        //Complete Filling
        orderCreationCommonFunctions.performFilling();

        //Complete Visual Verify
        orderCreationCommonFunctions.performVisualVerify();

        //Perform DropOff for an RX which has Refills
        orderCreationCommonFunctions.performDropOffForRXWithRefills();

        //Perform Resolution
        orderCreationCommonFunctions.performResolution();

        //verify TPDaysSupplyValue
        orderCreationCommonFunctions.verifyTPDaySupplyValueWithValue("10",true);

        Reporter.log("<<<tc_13_TP_Days_Supply_Value_Refill>>>");
    }


    /*----------------------------------------------------------------------------------------------------------
          * Test Description:Verify whether Order Comments are displaying in Consolidated Notes Screen when we add it from Double check 4 point queue.
          *
          * Pre-Conditions: 1. Update the state to MN
                            2. Double 4-point check should be true (select * from agency_rqmt_parm where restrict_type_code=9102 and issue_agency_code=223)
          * JIRA Testcase id : HWPHME2E-310 
          * Author: Ilangeeran(i0k00hp)
          ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify whether Order Comments are displaying in Consolidated Notes Screen when we add it from Double check 4 point queue.",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "OrderCreation")
    public void HWPHME2E_310_Order_Comments_Double_Check_4point(Map<String, String> inputData) {
        connexusAppUtils.updateStoreState("MN");
        String statecode = connexusAppUtils.fetchIssueAgencyCodeOfState("MN");
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "9102", statecode);
        connexusAppUtils.readAndUpdateFlag("14305", "TRUE");
        connexusAPIManager.restartConnexusService(siteId);
        orderCreationCommonFunctions.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        orderCreationCommonFunctions.createNewPatient(inputData);
        orderCreationCommonFunctions.performDropOff();
        orderCreationCommonFunctions.performInput(inputData);
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performChkDUR();
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.performVisualVerify();
        orderCreationCommonFunctions.performPickUp(inputData);
        orderCreationCommonFunctions.performCounselling();
        orderCreationCommonFunctions.performPOS();
        AutomationManager.getInstance().getConnexus().closeConnexus();
        orderCreationCommonFunctions.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        orderCreationCommonFunctions.performDouble4Point();
        if(!orderCreationCommonFunctions.verifyOrderComments()){
            Assert.fail("No order comments found");
        }
        Reporter.log("Verified order comments in double four point queue with pharmacist login");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description:HWSYSTMS-4956|Tech Mod | TC010_CASH_To_TP_ VV_TP_Rej_Refill_rx
* Author: Priyanka (p0j01ks)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-298")
    @Test(enabled = true, description = "tc_15_Cash_To_TPRej_Refill",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_298_tc_15_Cash_To_TPRej_Refill(Map<String, String> inputData) {
        Reporter.log(">>>tc_15_Cash_To_TPRej_Refill<<<");

        connexusAppUtils.getStoreId();

        //Create a new patient
        orderCreationCommonFunctions.createNewPatient(inputData,1);

        //Change Payment to Cash as Primary
        orderCreationCommonFunctions.changePaymentFromTPtoCASHForAPatient();

        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();

        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);

        //Complete 4Point
        orderCreationCommonFunctions.perform4Point();

        //Complete Filling
        orderCreationCommonFunctions.performFilling();

        //Complete Visual Verify
        orderCreationCommonFunctions.performVisualVerify();

        //Complete PickUp
        orderCreationCommonFunctions.performPickUp(inputData);

        //Complete Counselling
        orderCreationCommonFunctions.performCounselling();

        //Perform POS - Offline Sale
        orderCreationCommonFunctions.performPOS();

        //Perform DropOff for an RX which has Refills
        orderCreationCommonFunctions.performDropOffForRXWithRefills();

        //Perform Resolution
        orderCreationCommonFunctions.performResolution();

        //Complete Filling
        orderCreationCommonFunctions.performFilling();

        //Switch to CASH from TP plan in Filling queue
        orderCreationCommonFunctions.switchToTPFromCASH(inputData, WorkQueue.VISUAL_VERIFY);

        //Perform Resolution
        orderCreationCommonFunctions.performResolution();

        Reporter.log("<<<tc_15_Cash_To_TPRej_Refill>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description:Tech Mod |HWQEAUTO-4313| Checking Max Daily Dose Left Empty
* Author: Aayushi (a0s0fqj)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-315")
    @Test(enabled = true, description = "Validate_Max Daily_Dose_Left_Empty", priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_315_tc_16_Validate_Max_Daily_Dose_Left_Empty(Map<String, String> inputData)
    {
        Reporter.log(">>>tc_16_Validate_Max_Daily_Dose_Left_Empty<<<");

        connexusAppUtils.getStoreId();

        //Create a new patient
        orderCreationCommonFunctions.createNewPatient(inputData);

        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();


        orderCreationCommonFunctions.verifyMaxDailyDoseIsEntered(inputData);

        Reporter.log(">>>tc_16_Validate_Max_Daily_Dose_Left_Empty<<<");


    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description:Tech Mod |HWQEAUTO-4413| Checking Max Daily Dose value saved in database
* Author: Priyanka (p0j01ks)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-316")
    @Test(enabled = true, description = "Validate_Max Daily_Dose_Left_Empty", priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_316_tc_17_Validate_Max_Daily_Dose_Value_DB(Map<String, String> inputData)
    {
        Reporter.log(">>>tc_17_Validate_Max_Daily_Dose_Value_DB<<<");

        connexusAppUtils.getStoreId();

        //Create a new patient
        orderCreationCommonFunctions.createNewPatient(inputData);

        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();

        //Complete Input
        orderCreationCommonFunctions.verifyMaxDailyDoseValueDb(inputData);

        Reporter.log(">>>tc_17_Validate_Max_Daily_Dose_Value_DB<<<");


    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description:|Tech Mod |HWQEAUTO-1127| Verify the Third party days supply value for subsequent fill
* Author: Aayushi (a0s0fqj)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-300")
    @Test(enabled = true, description = "Verify that final fill is not getting created for the normal drug prescription after the emergency RX creation.", priority = 18, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_300_tc_18_Verify_Final_Fill_Not_Created_For_Emergency_Rx(Map<String, String> inputData)
    {
        Reporter.log(">>>tc_18_Verify_Final_Fill_Not_Created_For_Emergency_Rx<<<");

        connexusAppUtils.getStoreId();

        //Create a new patient
        orderCreationCommonFunctions.createNewPatient(inputData);

        //Complete DropOff
        orderCreationCommonFunctions.performEmergencyRxDropOff();

        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);

        //Complete Input
        orderCreationCommonFunctions.verifyInitialFillCreatedAfterFourPoint(inputData);

        //Verify Database
        orderCreationCommonFunctions.verifyFillTypeCodeFromDb();

        Reporter.log(">>>tc_18_Verify_Final_Fill_Not_Created_For_Emergency_Rx<<<");

    }
}