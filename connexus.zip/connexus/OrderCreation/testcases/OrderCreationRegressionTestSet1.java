package connexus.OrderCreation.testcases;

import connexus.OrderCreation.testscripts.OrderCreationCommonFunctions;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.utilities.PropertyReader;

import java.util.Map;

public class OrderCreationRegressionTestSet1 {

    OrderCreationCommonFunctions orderCreationCommonFunctions=new OrderCreationCommonFunctions(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils=new ConnexusAppUtils();
    ConnexusAPIManager connexusAPIManager=new ConnexusAPIManager();
    PropertyReader prop = PropertyReader.getInstance();
    public static LoginAs.userType loginUser_Type=LoginAs.userType.HOMEOFFICE_ADFlagOn;

    @BeforeClass
    public void performLogin(){
        System.out.println("Welcome: Before class");
        CheckAndSetPreConditions();
        String siteId =prop.getProperty("cnx.store");
        connexusAPIManager.restartConnexusService(siteId);
        AutomationManager.getInstance().performSleep(10);
        connexusAppUtils.startAppiumServer();
        orderCreationCommonFunctions.loginConnexus(loginUser_Type);
    }

    private void CheckAndSetPreConditions() {
        //Set the state to AR for the current store
        connexusAppUtils.updateStoreState("AR");
        connexusAppUtils.readAndUpdateFlag("32550","TRUE");
        connexusAppUtils.readAndUpdateFlag("31053","TRUE");

        //Verify and set the flag 28750 (AD Authentication) to TRUE
        connexusAppUtils.readAndUpdateFlag("28750", "TRUE");

        //Verify and set the flag 26849 (Redesign Contact Information) to TRUE
        connexusAppUtils.readAndUpdateFlag("26849", "TRUE");

        //Verify and set the flag 8670 (Enable/Disable Bagging queue) to FALSE
        connexusAppUtils.readAndUpdateFlag("8670", "FALSE");

        //Verify and set the flag 26218 (Bagging Queue Enabled) to FALSE
        connexusAppUtils.readAndUpdateFlag("26218", "FALSE");

        //Verify and set the flag 15166 (Flag to Enable ABN Changes) to TRUE
        connexusAppUtils.readAndUpdateFlag("15166", "TRUE");

        //Verify and set the flag 24550 (Advanced Beneficiary Notice (ABN) Requirement) to FALSE
        connexusAppUtils.readAndUpdateFlag("24550", "FALSE");
        orderCreationCommonFunctions.isManualMTRItemFilled();
    }


    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Drop a refill for an RX which has zero refills|HWQEAUTO-3120|
     *
     * Pre-Conditions: 1. 8670 - FLASE,26218 - FALSE,28750 - TRUE,15166=TRUE,24550=FALSE
     *
     * Author: Priyanka(p0j01ks)*/
      //Duplicate Test Case
    /*@Test(enabled = true, description = "Drop a refill for an RX which has zero refills",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void tc_01_Drop_A_Refill_For_RX_With_Zero_Number_Refills(Map<String, String> inputData) {
        System.out.println(">>>tc01_Drop_A_Refill_For_RX_With_Zero_Number_Refills<<<");

        //Create a new patient
        orderCreationCommonFunctions.createNewPatient(inputData);

        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();

        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);

        //Complete 4Point
        orderCreationCommonFunctions.perform4Point();

        //Complete Filling
        orderCreationCommonFunctions.performFilling();

        //Complete Visual Verify
        orderCreationCommonFunctions.performVisualVerify();

        //Complete PickUp
        orderCreationCommonFunctions.performPickUp(inputData);

        //Complete Counselling
        orderCreationCommonFunctions.performCounselling();

        //Perform POS - Offline Sale
        orderCreationCommonFunctions.performPOS();

        //Perform DropOff for an RX which has no Refills
        orderCreationCommonFunctions.performDropOffForRXWithNoRefills();

        //Verify whether RX moved toResolution queue due to zero refills
        orderCreationCommonFunctions.verifyIfRxIsInResolutionQueue();

        System.out.println("<<<tc01_Drop_A_Refill_For_RX_With_Zero_Number_Refills>>>");
    }*/


    /*----------------------------------------------------------------------------------------------------------
 * Test Description:verify  whether Need to MTR task for items filled on previous day is displayed after
 * clicking on Tasks on Action items menus
 *
 * Pre-Conditions: 1. 31053 Falg should be on
 *
 * Author: Dibyendu(d0s0bfq)
 ----------------------------------------------------------------------------------------------------------*/
    //to check with developer
    /*@Test(enabled = true,description = "verify  whether Need to MTR task for items filled on previous day is displayed after\n" +
            "  clicking on Tasks on Action items menus",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void tc_02_30153_Need_To_MTR_Daily_Task_Creation(Map<String, String> inputData) {
        System.out.println(">>>tc_2_30153_DisplayMTRTask<<<");
        orderCreationTestScript.manualMTRTaskCreationCheck();
        if(orderCreationTestScript.isTaskOrderCreated) orderCreationTestScript.deleteMTRDataIfInserted();
        System.out.println("<<<tc_2_30153_Need_To_MTR_Daily_Task_Creation>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
* Test Description:Verify refill at Drop off for cash/tp|HWQEAUTO-2980
* Pre-Conditions: 1. 15166=TRUE,24550=FALSE
* Author: Priyanka(p0j01ks)
----------------------------------------------------------------------------------------------------------*/
    //Duplicate Test Case
 /*   @Test(enabled = false, description = "Drop a refill for an RX which has atleast one refill",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void tc_03_Verify_refill_at_Drop_off_for_cash(Map<String, String> inputData) {
        System.out.println(">>>tc_03_Verify_refill_at_Drop_off_for_cash<<<");

        //Create a new patient
        orderCreationCommonFunctions.createNewPatient(inputData);

        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();

        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);

        //Complete 4Point
        orderCreationCommonFunctions.perform4Point();

        //Complete Filling
        orderCreationCommonFunctions.performFilling();

        //Complete Visual Verify
        orderCreationCommonFunctions.performVisualVerify();

        //Complete PickUp
        orderCreationCommonFunctions.performPickUp(inputData);

        //Complete Counselling
        orderCreationCommonFunctions.performCounselling();

        //Perform POS - Offline Sale
        orderCreationCommonFunctions.performPOS();

        //Perform DropOff for an RX which has Refills
        orderCreationCommonFunctions.performDropOffForRXWithRefills();

        //Complete Filling
        orderCreationCommonFunctions.performFilling();

        //Complete Visual Verify
        orderCreationCommonFunctions.performVisualVerify();

        //Complete PickUp
        orderCreationCommonFunctions.performPickUp(inputData);

        //Perform POS - Offline Sale
        orderCreationCommonFunctions.performPOS();

        System.out.println("<<<tc_03_Verify_refill_at_Drop_off_for_cash>>>");
    }*/


    /*----------------------------------------------------------------------------------------------------------
* Test Description:Verify being able to drop a rx and take to eod with multiple tp on file|HWQEAUTO-2977
* Author: Ilangeeran (i0k00hp)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "tc_04_Drop_Rx_Multiple_TP_EOD",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_295_tc_04_Drop_Rx_Multiple_TP_EOD(Map<String, String> inputData) {

        Reporter.log("HWPHME2E-295");
        connexusAppUtils.getStoreId();
        //Create a new patient
        orderCreationCommonFunctions.createNewPatientWith2TPPlans(inputData);

        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();

        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);

        //Complete 4Point
        orderCreationCommonFunctions.perform4Point();

        //Complete Filling
        orderCreationCommonFunctions.performFilling();

        //Complete Visual Verify
        orderCreationCommonFunctions.performVisualVerify();

        //Complete PickUp
        orderCreationCommonFunctions.performPickUp(inputData);

        //Complete Counselling
        orderCreationCommonFunctions.performCounselling();

        //Perform POS - Offline Sale
        orderCreationCommonFunctions.performPOS();

        System.out.println("<<<tc_04_Drop_Rx_Multiple_TP_EOD>>>");
    }

       /*----------------------------------------------------------------------------------------------------------
* Test Description:Switching Cash_To_TP_ Filling|HWQEAUTO-1120
* Pre-Conditions: 1. 15166=TRUE,24550=FALSE
* Author: Priyanka(p0j01ks)
----------------------------------------------------------------------------------------------------------*/
//Duplicate Test Case
 /*   @Test(enabled = true, description = "Cash_To_TP_ Filling",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void tc_05_SwitchCashToTp(Map<String, String> inputData) {
        System.out.println(">>>tc_05_SwitchCashToTp<<<");
        //Create a new patient
        orderCreationCommonFunctions.createNewPatientWithTP(inputData);

        //Change payment method on Patient profile from CASH to TP
        orderCreationCommonFunctions.changePaymentFromTPtoCASHForAPatient();

        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();

        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);

        //Complete 4Point
        orderCreationCommonFunctions.perform4Point();

        //Complete chkDUR
        orderCreationCommonFunctions.performChkDUR();

        //Switch to CASH from TP plan in Filling queue
        orderCreationCommonFunctions.switchToTPFromCASH(inputData, WorkQueue.FILLING);

        System.out.println("<<<tc_05_SwitchCashToTp>>>");
    }*/

     /*----------------------------------------------------------------------------------------------------------
* Test Description:verify whether RX moves to Third Part Rejection/Failure resolution when prescribed Qty is changed from ChkDUR modify details screen for the RX with TP Rejection as primary payment method
*  Author: Aayushi(a0s0fqj)
----------------------------------------------------------------------------------------------------------*/
//HWPHME2E-303, Duplciate TC number and code should not be removed
  /*  @Test(enabled = true,description = "verify whether RX moves to Third Part Rejection/Failure resolution \n" +
            "when prescribed Qty is changed from ChkDUR modify details screen for the RX with TP \n" +
            "Rejection as primary payment method",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void tc_06_drug_qty_change_chkdur_tp_rej(Map<String, String> inputData) {
        System.out.println(">>>TC020_Drug_Qty_Change_ ChkDUR_TP_Rej<<<");
        orderCreationCommonFunctions.createNewPatientWithTP(inputData);

        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();

        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);

        //Complete 4Point
        orderCreationCommonFunctions.perform4Point();

        orderCreationCommonFunctions.performChkDurModifyQty();

        System.out.println("<<<TC_06_Drug_Qty_Change_ ChkDUR_TP_Rej>>>");
    }*/


}




