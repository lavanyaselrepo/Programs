package connexus.OrderCreation.testcases;

import bom.tests.WrapperTestScript;
import com.jayway.jsonpath.JsonPath;
import connexus.OrderCreation.testscripts.OrderCreationCommonFunctions;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import org.json.simple.parser.ParseException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

public class OrderCreationRegressionTestSet2 {

    OrderCreationCommonFunctions orderCreationCommonFunctions=new OrderCreationCommonFunctions(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils=new ConnexusAppUtils();
    public static LoginAs.userType loginUser_Type=LoginAs.userType.HOMEOFFICE_ADFlagOn;
    boolean flagUpdated = false;


    @BeforeClass
    public void performLogin() {
        System.out.println("Welcome: Before class");
        CheckAndSetPreConditions();
        connexusAppUtils.startAppiumServer();
    }

    private void CheckAndSetPreConditions() {
        //Set the state to AR for the current store
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("32550","TRUE");
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("31053","TRUE");

        //Verify and set the flag 28750 (AD Authentication) to TRUE
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("28750", "TRUE");

        //Verify and set the flag 26849 (Redesign Contact Information) to TRUE
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("26849", "TRUE");

        //Verify and set the flag 8670 (Enable/Disable Bagging queue) to FALSE
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("8670", "FALSE");

        //Verify and set the flag 26218 (Bagging Queue Enabled) to FALSE
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("26218", "FALSE");

        //Verify and set the flag 15166 (Flag to Enable ABN Changes) to TRUE
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("15166", "TRUE");

        //Verify and set the flag 24550 (Advanced Beneficiary Notice (ABN) Requirement) to FALSE
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("24550", "FALSE");
        flagUpdated |= orderCreationCommonFunctions.isManualMTRItemFilled();
    }


    @AfterClass
    public void tearDown() {
        orderCreationCommonFunctions.CloseConnexus();
        connexusAppUtils.stopAppiumServer();
    }


           /*----------------------------------------------------------------------------------------------------------
* Test Description:Verify when using a tp plan, should be able to switch to another tp at 4 point and take to eod|
* Pre-Conditions: 1. 15166=TRUE,24550=FALSE
* Author: Ilangeeran (i0k00hp)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-303")
    // duplicate test
   /* @Test(enabled = true, description = "Verify when using a tp plan, should be able to switch to another tp at 4 point and take to eod",
            priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void tc_07_SwitchPlan_EOD(Map<String, String> inputData) {
        System.out.println(">>>tc_07_SwitchPlan_EOD<<<");
        //Create a new patient
        orderCreationCommonFunctions.createNewPatientWith2TPPlans(inputData);

        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();

        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);

        //Switch TP plan
        orderCreationCommonFunctions.changeTPPlanIn4Point(inputData);

        //Complete 4Point
        orderCreationCommonFunctions.perform4Point();

        //Complete chkDUR
        orderCreationCommonFunctions.performChkDUR();

        //Complete Filling
        orderCreationCommonFunctions.performFilling();

        //Complete Visual Verify
        orderCreationCommonFunctions.performVisualVerify();

        //Complete PickUp
        orderCreationCommonFunctions.performPickUp(inputData);

        //Complete Counselling
        orderCreationCommonFunctions.performCounselling();

        //Perform POS - Offline Sale
        orderCreationCommonFunctions.performPOS();
        System.out.println("<<<tc_07_SwitchPlan_EOD>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
* Test Description:Verify refill at Drop off for cash/tp|
* Pre-Conditions: 1. 15166=TRUE,24550=FALSE
* Author: Aayushi(a0s0fqj)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-297")
    @Test(enabled = true, description = "Drop a refill for an RX which has zero refills",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_297_tc_08_Verify_refill_at_Drop_off_for_tp(Map<String, String> inputData) {
        System.out.println(">>>tc_08_Verify_refill_at_Drop_off_for_tp<<<");

        connexusAppUtils.getStoreId();
        CheckAndSetPreConditions();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated);

        //Create a new patient
        orderCreationCommonFunctions.createNewPatient(inputData, 1);

        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();

        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);

        //Complete 4Point
        orderCreationCommonFunctions.perform4Point();

        //Complete Filling
        orderCreationCommonFunctions.performFilling();

        //Complete Visual Verify
        orderCreationCommonFunctions.performVisualVerify();

        //Complete PickUp
        orderCreationCommonFunctions.performPickUp(inputData);

        //Complete Counselling
        orderCreationCommonFunctions.performCounselling();

        //Perform POS - Offline Sale
        orderCreationCommonFunctions.performPOS();

        //Perform DropOff for an RX which has Refills
        orderCreationCommonFunctions.performDropOffForRXWithRefills();

        orderCreationCommonFunctions.performResolutionForSubmit();

        //Complete Filling
        orderCreationCommonFunctions.performFilling();

        //Complete Visual Verify
        orderCreationCommonFunctions.performVisualVerify();

        //Complete PickUp
        orderCreationCommonFunctions.performPickUp(inputData);


        orderCreationCommonFunctions.performResolutionForSubmit();


        //Perform POS - Offline Sale
        orderCreationCommonFunctions.performPOS();

        System.out.println("<<<tc_08_Verify_refill_at_Drop_off_for_tp>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description:Verify being able to discontinue one of the tps for a patient with multiple tp plans and take to eod|
* Author: Priyanka (p0j01ks)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-110")
    @Test(enabled = false, description = "tc_04_Drop_Rx_Multiple_TP_EOD",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_110_tc_09_Drop_Rx_DiscontinueTP_EOD(Map<String, String> inputData) {
        System.out.println(">>>tc_09_Drop_Rx_DiscontinueTP_EOD<<<");

        connexusAppUtils.getStoreId();

        //Create a new patient
        orderCreationCommonFunctions.createNewPatient(inputData, 1);

        //Complete DropOff
        orderCreationCommonFunctions.performDropRx_TP_Discontinue();

        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);

        //Complete 4Point
        orderCreationCommonFunctions.perform4Point();

        //Complete Filling
        orderCreationCommonFunctions.performFilling();

        //Complete Visual Verify
        orderCreationCommonFunctions.performVisualVerify();

        //Complete PickUp
        orderCreationCommonFunctions.performPickUp(inputData);

        //Complete Counselling
        orderCreationCommonFunctions.performCounselling();

        //Perform POS - Offline Sale
        orderCreationCommonFunctions.performPOS();

        System.out.println("<<<tc_09_Drop_Rx_DiscontinueTP_EOD>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description:Verify being able to drop a rx fo a patient having multiple records for the same tp plan|
* Author: Priyanka (p0j01ks)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-301")
    @Test(enabled = true, description = "Verify patient’s rx after a TP plan is disabled and then re‑added with the same details",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_301_tc_10_Drop_Rx_DiscontinueAddTP_EOD(Map<String, Object> inputData) {
        System.out.println(">>>tc_10_Drop_Rx_DiscontinueAddTP_EOD<<<");
        String testType = "HWPHME2E_301 - Verify patient’s rx after a TP plan is disabled and then re‑added with the same details";
        CheckAndSetPreConditions();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated);
        // Create patient
        Integer patientId = WrapperTestScript.createPatient(inputData, testType);

        // Get patient name
        Map<String, Object> patientName = connexusAppUtils.getPatientFirstNameAndLastName(connexusAppUtils.getStoreId(), patientId);

        // Pre-Conditions: logged into Connexus
        orderCreationCommonFunctions.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);

        // Discontinue and Add same TP plan
        orderCreationCommonFunctions.discontinueAndAddSameTPPlan(patientName, inputData.get("TP_CARRIER_BIN").toString(), inputData.get("TP_PLAN").toString());

        // Submit prescription drop-off request using the created patient ID
        ServiceResponse dropOffResponse = WrapperTestScript.completePrescriptionDropOff(patientId, inputData, testType);

        // Complete prescription input with updated pickup/expiry dates (adds 3 days)
        ServiceResponse inputResponse = WrapperTestScript.completePrescriptionInput(dropOffResponse, testType);

        Integer rxFillId = JsonPath.read(inputResponse.getDataResponse(), "$.rxFillId");

        // Move to EOD
        WrapperTestScript.moveRXToEOD(rxFillId, connexusAppUtils.getStoreId(), "MoveTOEOD");

        System.out.println("<<<tc_10_Drop_Rx_DiscontinueAddTP_EOD>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description:TC012_CASH_To_TP_ Counseling_TP_Rej|
* Pre-Conditions: 1. 15166=TRUE,24550=FALSE
* Author: Priyanka(p0j01ks)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-299")
    @Test(enabled = true, description = "CASH_To_TP_ Counseling_TP_Rej",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_299_tc_11_CashToTP_Rej(Map<String, Object> inputData) throws IOException, ParseException {
        System.out.println(">>>tc_11_CashToTP_Rej<<<");

        ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
        CheckAndSetPreConditions();

        //Create a new patient
        Integer patientId = WrapperTestScript.createPatient(inputData, "HWPHME2E_299 - Verify the functionality when the payment method is changed from Cash to TP");

        //Create order with cash payment method, advance to pickup
        ArrayList<String> rxOrderResponse = connexusAPIManager.createOrderAndMoveToPickUp_SwitchToCash_Consent(patientId,
                connexusAppUtils.getStoreId(), Integer.parseInt(inputData.get("REFILLS").toString()), inputData.get("ndc").toString());

        String rxNbr = rxOrderResponse.getFirst();
        Map<String, Object> patientData = connexusAppUtils.getPatientFirstNameAndLastName(connexusAppUtils.getStoreId(), patientId);

        //Pre-Conditions: logged into Connexus
        orderCreationCommonFunctions.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);

        //Complete PickUp
        orderCreationCommonFunctions.performPickUp(rxNbr, patientData);

        //Switch to CASH from TP plan
        orderCreationCommonFunctions.switchToTP(inputData, WorkQueue.PICKUP, rxNbr, patientData);

        //Perform Resolution
        orderCreationCommonFunctions.performResolutionWithDownTime(rxNbr);

        System.out.println("<<<tc_11_CashToTP_Rej>>>");
    }


}

    


