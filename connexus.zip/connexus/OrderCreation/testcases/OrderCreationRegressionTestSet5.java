package connexus.OrderCreation.testcases;

import connexus.OrderCreation.testscripts.OrderCreationCommonFunctions;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class OrderCreationRegressionTestSet5 {
    OrderCreationCommonFunctions orderCreationCommonFunctions=new OrderCreationCommonFunctions(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    boolean flagUpdated = false;

    @BeforeClass
    public void performLogin() {
        connexusAppUtils.startAppiumServer();
        CheckAndSetPreConditions();
    }

    private void CheckAndSetPreConditions() {
        //Set the state to AR for the current store
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("32550", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31053", "TRUE");

        //Verify and set the flag 28750 (AD Authentication) to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("28750", "TRUE");

        //Verify and set the flag 26849 (Redesign Contact Information) to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("26849", "TRUE");

        //Verify and set the flag 8670 (Enable/Disable Bagging queue) to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("8670", "FALSE");

        //Verify and set the flag 26218 (Bagging Queue Enabled) to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("26218", "FALSE");

        //Verify and set the flag 15166 (Flag to Enable ABN Changes) to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15166", "TRUE");

        //Verify and set the flag 24550 (Advanced Beneficiary Notice (ABN) Requirement) to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("24550", "FALSE");

        //Verify that Max Daily Dose Altered Flag is set to True
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31153", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("26846","FALSE");

        flagUpdated |= connexusAppUtils.isManualMTRItemFilled();

        //Set the central patient flag to FALSE, to avoid getting golden record after update

    }


    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: TC032_R1501 UAT_Create Rx_ Insurance patient_ Final fill
* Author: Kundan (k0k07q3)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-2827")
    @Test(enabled = true, description = "Verify whether initial and " +
            "final partial fill can be performed for the insurance patient and Rx will be in full co pay amount after proceeding final fill to EOD.", priority = 19, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_2827_Tc_20_UAT_Create_Rx_Insurance_patient_Final_fill(Map<String, String> inputData) {
        Reporter.log(">>>HWPHME2E_2827_Tc_20_UAT_Create_Rx_Insurance_patient_Final_fill<<<");

        CheckAndSetPreConditions();

        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        //Create a new patient
        orderCreationCommonFunctions.createNewPatient(inputData,1);
        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();
        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);
        //Complete 4Point
        orderCreationCommonFunctions.perform4Point();
        //Perform ChkDUR
        orderCreationCommonFunctions.performChkDUR();
        //Perform PartialFill
        orderCreationCommonFunctions.performPartialFilling();
        // Perform initial fill of final fill
        orderCreationCommonFunctions.performInitialFill();
        // Perform visual verify of inital fill
        orderCreationCommonFunctions.performVisualVerify(1);
        // Perform pickup of initial fill
        orderCreationCommonFunctions.performPickupForInialFill(inputData);
        // Perform counselling
        orderCreationCommonFunctions.performCounselling();
        // Perform resolution on initial fill
        orderCreationCommonFunctions.perormResolution(1);
        // Perform full copay paid verification
        orderCreationCommonFunctions.verifyFullCopayPaid();
        Reporter.log(">>>HWPHME2E_2827_Tc_20_UAT_Create_Rx_Insurance_patient_Final_fill<<<");
    }


    /*------------------------------------------------------------------------------------------------------------------
    *Test Description : Verify the value in ‘addition_val’ column with ‘Third party days supply’ field.
    * Preconditions: Flag 32550 ON
    --------------------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-2828")
    @Test(enabled = true, description = "Verify the value in ‘addition_val’ column with ‘Third party days supply’ field in claims screen.", priority = 21, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_2828_Tc_21_Verify_the_value_in_addition_val_column_with_Third_party_days_supply_field_in_claims_screen(Map<String, String> inputData) {

        CheckAndSetPreConditions();

        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        //Create a new patient
        orderCreationCommonFunctions.createNewPatient(inputData,1);
        //Complete DropOff
        orderCreationCommonFunctions.performDropOff();
        //Complete Input
        orderCreationCommonFunctions.performInput(inputData);
        //Complete TP Supply days on patient info page
        orderCreationCommonFunctions.verifyTPdaysSupplyOnTPInfoPage(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
       * Profile saved with primary number_contact redesign flag on_update comm_seq_nbr with zero in DB
       *
       * Pre-Conditions: 1. Flag 26849 should be True
       *                 2. Flag 26846 should be False

       * Author: Ilangeeran(i0k00hp)
       ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-286")
    @Test(enabled = true, description = "Profile saved with primary number_contact redesign flag on_update comm_seq_nbr with zero in DB",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "OrderCreation")
    public void HWPHME2E_286_Tc_22_VerifyMessagingNumber(Map<String, String> inputData) {
        Reporter.log("<<<Profile saved with primary number_contact redesign flag on_update comm_seq_nbr with zero in DB>>>");

        CheckAndSetPreConditions();

        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);

        orderCreationCommonFunctions.createNewPatient(inputData);
        // updating the primary contact number as Messaging number by modifying DB data
        orderCreationCommonFunctions.updatePrimaryContactAsMessaging(inputData);
        // checking whether the messaging number exists and then copying the number to primary
        orderCreationCommonFunctions.checkMsgExistsAndEnterPrimary(inputData);
        // check if the primary contact is there for that patient
        orderCreationCommonFunctions.checkPrimaryContact(inputData);
        // update the seq nbr as 0 in db, then check open PTMS and check primary is present and query to db to check if seq nbr got reverted to 1
        orderCreationCommonFunctions.VerifyPrimaryNumAndCheckSeqNbr(inputData);
        Reporter.log("<<<Profile saved with primary number_contact redesign flag on_update comm_seq_nbr with zero in DB>>>");
    }

   /*------------------------------------------------------------------------------------------------------------------
    *Test Description : Verify the rx is cancelling successfully after placing cancel request from surescripts
    *
    --------------------------------------------------------------------------------------------------------------------
     */
   //@Jira(testID = "HWPHME2E-306")
    @Test(enabled =true, description = "Verify the rx is cancelling successfully after placing cancel request from surescripts", priority = 23, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_306_Tc_23_rx_cancelling_successfully_after_placing_cancel_request_from_surescripts(Map<String, String> inputData) {
        CheckAndSetPreConditions();
        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        orderCreationCommonFunctions.createNewPatient(inputData,1);
        orderCreationCommonFunctions.sendErxMessage("surescriptNewRequst", inputData);
        orderCreationCommonFunctions.performPatientMisMatchResolution();
        orderCreationCommonFunctions.performInput(inputData);
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performChkDUR();
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.sendErxMessage("cancelsurescriptrequest",inputData);
        orderCreationCommonFunctions.performCancelPrescription();
    }

    //This is DUPLICATE scenario

    /*------------------------------------------------------------------------------------------------------------------
    *Test Description : HWQEAUTO-14454 | On-Hold_ Cancel Rx
    *
    --------------------------------------------------------------------------------------------------------------------
     *//*
    //@Jira(testID = "HWPHME2E-306")
    @Test(enabled = true, description = "On-Hold_ Cancel Rx", priority = 24, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "orderCreation")
    public void HWPHME2E_306_Tc_24_On_Hold_Cancel_Rx(Map<String, String> inputData) {
        orderCreationCommonFunctions.createNewPatientWithTP(inputData);
        orderCreationCommonFunctions.performDropOff();
        orderCreationCommonFunctions.performInput(inputData);
        orderCreationCommonFunctions.perform4Point();
        orderCreationCommonFunctions.performChkDUR();
        orderCreationCommonFunctions.performFilling();
        orderCreationCommonFunctions.performVisualVerify();
        orderCreationCommonFunctions.performPickUp(inputData);
        orderCreationCommonFunctions.performCounselling();
        orderCreationCommonFunctions.performRefillDropOff();
        orderCreationCommonFunctions.performResolution();
        orderCreationCommonFunctions.sendErxMessage("cancelsurescriptrequest", inputData);
        orderCreationCommonFunctions.performCancelPrescription();
        orderCreationCommonFunctions.verifyShouldOnHoldIsDisabled();
    }*/
}
