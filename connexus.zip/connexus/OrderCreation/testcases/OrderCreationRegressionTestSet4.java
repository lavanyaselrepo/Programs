package connexus.OrderCreation.testcases;

import connexus.OrderCreation.testscripts.OrderCreationCommonFunctions;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class OrderCreationRegressionTestSet4 {


    OrderCreationCommonFunctions orderCreationCommonFunctions=new OrderCreationCommonFunctions(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils=new ConnexusAppUtils();
    public static LoginAs.userType loginUser_Type=LoginAs.userType.HOMEOFFICE_ADFlagOn;
    boolean flagUpdated = false;

    @BeforeClass
    public void performLogin(){
        connexusAppUtils.startAppiumServer();
        CheckAndSetPreConditions();
    }

    private void CheckAndSetPreConditions() {
        //Set the state to AR for the current store
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("32550","TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31053","TRUE");

        //Verify and set the flag 28750 (AD Authentication) to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("28750", "TRUE");

        //Verify and set the flag 26849 (Redesign Contact Information) to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("26849", "TRUE");

        flagUpdated |= connexusAppUtils.readAndUpdateFlag("9061", "TRUE");
    }


    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
           * HWCNXCORTH-309_Verify the earliest fill date checkbox is checked and correct date is being populated in input
           *
           * Pre-Conditions: 1. Flag 9061 should be True

           * Author: Priyanka(p0j01ks)
           ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify the earliest fill date checkbox is checked and correct date is being populated in input",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderCreation/OrderCreationTestBook.json", sheetName = "OrderCreation")
    public void HWPHME2E_331_tc_19_VerifyEarliestFillDate_ERX(Map<String, String> inputData) {

        Reporter.log("HWPHME2E-331");
        connexusAppUtils.getStoreId();
        orderCreationCommonFunctions.initializeTestCase(flagUpdated,true);
        orderCreationCommonFunctions.createNewPatient(inputData);
        orderCreationCommonFunctions.sendErxMessage("surescriptFutureFill",inputData);
        orderCreationCommonFunctions.verifyFutureFillDateInput_ERX(inputData);

        System.out.println("<<<Verify the earliest fill date checkbox is checked and correct date is being populated in input>>>");

    }
    
}

    


