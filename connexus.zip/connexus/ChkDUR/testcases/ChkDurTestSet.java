package connexus.ChkDUR.testcases;

import clinicalservices.Immunization.testScripts.ClinicalIntelligenceTestScripts;
import clinicalservices.Immunization.testScripts.WalkinTestScript;
import connexus.ChkDUR.testscripts.ChkDurTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.pageobjectmodels.connexus.InputPage;
import hwqe.baseframework.utilities.PropertyReader;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.Map;
import hwqe.baseframework.utilities.Reporter;

public class ChkDurTestSet {

    ChkDurTestScript durTestScript;
    ConnexusAppUtils connexusAppUtils;
    PropertyReader propertyReader = PropertyReader.getInstance();
    WalkinTestScript walkinTestScript = new WalkinTestScript();
    ClinicalIntelligenceTestScripts clinicalIntelligenceTestScript;
    String stateCode = "";
    String conflictMsg;
    String conflictReason;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        durTestScript = new ChkDurTestScript(LoginAs.userType.PHARMACIST_ADFlagOff);
        clinicalIntelligenceTestScript= new ClinicalIntelligenceTestScripts(LoginAs.userType.PHARMACIST_ADFlagOff);
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3287 Test Description: Send to Resolution from DUR - Contact Prescriber
   *
   * Pre-Conditions:
   * 1.User is logged into Connexus
   * Author: Aparna Ramalingam(vn50izt)
   ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Send to Resolution from DUR - Contact Prescriber",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3287_sendToResolution_ContactPrescriber(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.validateResolutionOnDUR();
        durTestScript.selectRph(inputData.get("MESSAGE"), InputPage.ManualResolutionType.CONTACT_PRESCRIBER);
        durTestScript.verifyResolutionStatus(inputData);
    }
    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3288 Test Description: Send to Resolution from DUR - Contact Customer
   *
   * Pre-Conditions:
   * 1.User is logged into Connexus
   * Author: Aparna Ramalingam(vn50izt)
   ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Send to Resolution from DUR - Contact Customer",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3288_sendToResolution_ContactCustomer(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.validateResolutionOnDUR();
        durTestScript.selectRph(inputData.get("MESSAGE"), InputPage.ManualResolutionType.CONTACT_CUSTOMER);
        durTestScript.verifyResolutionStatus(inputData);
    }
    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3289 Test Description: Send to Resolution from DUR - Manual Resolution
   *
   * Pre-Conditions:
   * 1.User is logged into Connexus
   * Author: Nanthini(vn576ph)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Send to Manual Resolution from DUR",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3289_sendTo_Manual_Resolution(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.validateResolutionOnDUR();
        durTestScript.selectRph(inputData.get("MESSAGE"), InputPage.ManualResolutionType.MANUAL_RESOLUTION);
        durTestScript.verifyResolutionStatus(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3291 Test Description: Therapy Discontinue Rx from DUR
   *
   * Pre-Conditions:
   * 1.User is logged into Connexus
   * Author: Nanthini(vn576ph)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Therapy_Discontinue_Rx_from_DUR",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3291_Therapy_Discontinue_Rx_from_DUR(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.therapyDiscontinuedOpenStock(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3290 Test Description: Put Rx on hold from DUR
   *
   * Pre-Conditions:
   * 1.User is logged into Connexus
   * Author: Nanthini(vn576ph)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Put_Rx_on_hold_from_DUR",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3290_Put_Rx_on_hold_from_DUR(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.validatePutRxOnHold(inputData);
    }


    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3292 Test Description : Validate Duplicate Fill Creation via DUR Check in chkDUR Component
   *
   * Pre-Conditions:
   * 1.User is logged into Connexions
   * Author: Mallikarjuna(vn58n9x)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate Duplicate Fill Creation via DUR Check in chkDUR Component",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR_DATA")
    public void HWPHME2E_3292_Duplicate_Fill_From_DUR(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.performDURCheck_Duplicate_Fill(inputData);
        Reporter.log("Executed successfully ,validating the duplicate fill creation process through the DUR check in the chkDUR component ");
    }

    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3293 Test Description : Validate Patient wants Written Rx Back via DUR Check in chkDUR Component
   *
   * Pre-Conditions:
   * 1.User is logged into Connexions
   * Author: Mallikarjuna(vn58n9x)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate Patient wants Written Rx Back via DUR Check in chkDUR Component",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR_DATA")
    public void HWPHME2E_3293_Patient_Wants_WrittenRx_Back_From_DUR(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.performDURCheckAndPatientWrittenRxBack(inputData);
        Reporter.log("Executed successfully ,validating the Patient wants Written Rx Back creation process through the DUR check in the chkDUR component ");
    }

/*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_2745 Test Description : Validate system alert triggers when a patient with a Disease Check Alert: Neuromuscular Disease | C-19395
   *
   * Pre-Conditions:
   * 1.User is logged into Connexions
   * input a patient profile with a documented Neuromuscular Disease.
   * attempt to prescribe a Neuromuscular Disease based medication.
   * verify the system triggers an Disease Check alert
   * Author: Mallikarjuna(vn58n9x)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate system alert triggers when a patient with a Disease Check Alert: Neuromuscular Disease - C-19395",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR_DATA")
    public void HWPHME2E_2745_Neuromuscular_DiseaseAlert_C19395(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
//      ********** Add Medical Condition to Patient ********************
        durTestScript.addMedicalConditionDetails(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.ValidateChkDURScreenForNeuromuscularPatient(inputData);
        durTestScript.checkRxIsInFillingQueue();
        Reporter.log("Executed successfully ,Validate system alert triggers when a patient with a Disease Check Alert: Neuromuscular Disease - C-19395");
    }

    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_2740 Test Description : Validate system alert triggers when a patient with a Penicillin allergy is flagged during prescription
   *
   * Pre-Conditions:
   * 1.User is logged into Connexions
   * input a patient profile with a documented Penicillin allergy.
   * attempt to prescribe a Penicillin based medication.
   * verify the system triggers an allergy alert
   * Author: Mallikarjuna(vn58n9x)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate system alert triggers when a patient with a Penicillin allergy is flagged during prescription",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR_DATA")
    public void HWPHME2E_2740_PenicillinAllergyCheck_AlertTriggered_E2E(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.addAllergyToPatientProfile(inputData);
        durTestScript.performDropOff(Priority.Critical);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.ValidateDURConflictsChkDURScreen(inputData);
        durTestScript.checkRxIsInFillingQueue();
        Reporter.log("Executed successfully ,Validate system alert triggers when a patient with a Penicillin allergy is flagged during prescription ");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: HWPHME2E_2748_Gender check alert conflict resolution in ChkDur
     *
     * Pre-Conditions:  1.User is logged into Connexus
     *                  2.Pateint Gender: Male
     *
     * Author: Diya(vn58o0i)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Gender check alerts: Male conflict resolution in Chkdur ", enabled = true, priority = 10,
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_2748_gender_check_alert_conflict_resolution_in_Dur(Map<String, String> inputData){
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false, inputData, false);
        durTestScript.verifyingAndResolvingConflicts(inputData);
        durTestScript.checkRxIsInFillingQueue();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: HWPHME2E_2749_Dose check alert in chkdur
     *
     * Pre-Conditions:  User is logged into Connexus
     *
     * Author: Diya(vn58o0i)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Dose check alert in Chkdur ", enabled = true, priority = 11,
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_2749_dose_check_alert_in_chkdur(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false, inputData,false);
        durTestScript.verifyingAndResolvingConflicts(inputData);
        durTestScript.checkRxIsInFillingQueue();
    }


    /*----------------------------------------------------------------------------------------------------------
* HWPHME2E-3286 Test Description: Add counseling note at DUR
*
* Pre-Conditions:
* 1.User is logged into Connexus
* Author: Nanthini(vn576ph)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Add_Counseling_Note_At_DUR",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3286_Add_Counseling_Note_At_DUR(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.validateCounsellingNotes(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
* HWPHME2E_280 Test Description: Verify Check DUR is triggered for an Rx that conflicts with an allergy with allergy class code > 32767
*
* Pre-Conditions:
* 1.User is logged into Connexus
* Author: Aparna Ramalingam(vn50izt)
----------------------------------------------------------------------------------------------------------*/
   @Test(enabled = true, description = "Verify Check DUR is triggered for an Rx that conflicts with an allergy with allergy class code > 32767",
           priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
   @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
   public void HWPHME2E_280_verifyChkDUR(Map<String, String> inputData) {
       connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
       durTestScript.initializeObjects(false);
       durTestScript.createNewPatient(inputData,0);
       durTestScript.addAllergyToPatientProfile(inputData);
       durTestScript.performDropOff(Priority.InStore);
       durTestScript.performInput(inputData);
       durTestScript.perform4Point(false, false);
       durTestScript.ValidateDURConflictsChkDURScreen(inputData);
   }
    /*----------------------------------------------------------------------------------------------------------
* HWPHME2E_3277 Test Description: Red DUR
*
* Pre-Conditions:
* 1.User is logged into Connexus
* Author: Aparna Ramalingam(vn50izt)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Red DUR",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3277_RedDUR(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData,0);
        durTestScript.addAllergyToPatientProfile(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.verifyChkDurQueueAndConflictMessage(inputData.get("MESSAGE"));
        durTestScript.resolveConflictWithReason(inputData.get("REASON"),3);
        durTestScript.checkRxIsInFillingQueue();
    }

    /*----------------------------------------------------------------------------------------------------------
* HWPHME2E_3279 Test Description: Red DUR - Dr.Approved
*
* Pre-Conditions:
* 1.User is logged into Connexus
* Author: Aparna Ramalingam(vn50izt)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Red DUR - Dr.Approved",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3279_RedDUR_override_dr_approved(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData,0);
        durTestScript.addAllergyToPatientProfile(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.verifyChkDurQueueAndConflictMessage(inputData.get("MESSAGE"));
        durTestScript.resolveConflictWithReason(inputData.get("REASON"),3);
        durTestScript.checkRxIsInFillingQueue();
    }
    /*----------------------------------------------------------------------------------------------------------
* HWPHME2E_3282 Test Description: Red DUR - Side effect confirmed
*
* Pre-Conditions:
* 1.User is logged into Connexus
* Author: Aparna Ramalingam(vn50izt)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Red DUR - Side effect confirmed",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3282_RedDUR_override_sideeffect_confirmed(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData,0);
        durTestScript.addAllergyToPatientProfile(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.verifyChkDurQueueAndConflictMessage(inputData.get("MESSAGE"));
        durTestScript.resolveConflictWithReason(inputData.get("REASON"),3);
        durTestScript.checkRxIsInFillingQueue();
    }
    /*----------------------------------------------------------------------------------------------------------
* HWPHME2E_3283 Test Description: Red DUR override -  Prior Use with Success
*
* Pre-Conditions:
*
* 1.User is logged into Connexus
* Author: Aparna Ramalingam(vn50izt)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Red DUR override -  Prior Use with Success",
            priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3283_RedDUR_override_Prior_Use_with_Success(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData,0);
        durTestScript.addAllergyToPatientProfile(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.verifyChkDurQueueAndConflictMessage(inputData.get("MESSAGE"));
        durTestScript.resolveConflictWithReason(inputData.get("REASON"),3);
        durTestScript.checkRxIsInFillingQueue();
    }
    /*----------------------------------------------------------------------------------------------------------
* HWPHME2E_3280 Test Description: Red DUR override - Not Relevant Old Therapy
*
* Pre-Conditions:
*
* 1.User is logged into Connexus
* Author: Aparna Ramalingam(vn50izt)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Red DUR override - Not Relevant Old Therapy",
            priority = 18, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3280_RedDUR_override_not_relevant_old_threapy(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData,0);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.performDropOff(Priority.InStore);
        inputData.put("DRUG_NAME",inputData.get("SECOND_DRUG_NAME"));
        inputData.put("QUANTITY",inputData.get("SECOND_NDC_QTY"));
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.verifyChkDurQueueAndConflictMessage(inputData.get("MESSAGE"));
        durTestScript.resolveConflictWithReason(inputData.get("REASON"),4);
        durTestScript.checkRxIsInFillingQueue();
    }

   /*----------------------------------------------------------------------------------------------------------
    * HWPHME2E_2746 Test Description : Validate system alert triggers when patient with a Gender Check Alerts: Female
    * Pre-Conditions:
    * 1.User is logged into Connexions
    * input a patient profile with a documented NDC: 55111062930.
    * attempt to prescribe a NDC: 55111062930 based medication.
    * verify the system triggers an Gender Check Alerts: Female
    * Author: Mallikarjuna(vn58n9x)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate system alert triggers when a patient with a gender Check Alerts: Female ",
            priority = 19, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR_DATA")
    public void HWPHME2E_2746_Check_Alerts_Female(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.Critical);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.verifyingAndResolvingConflicts(inputData);
        durTestScript.checkRxIsInFillingQueue();
        Reporter.log("Executed successfully, validated the patient's request for gender-specific check alerts: Female");
    }

    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_2752 Test Description : Validate system alert triggers when patient with a Pregnancy Alerts Check: Female
   * Pre-Conditions:
   * 1.User is logged into Connexions
   * input a patient profile with a documented NDC: 16729028615.
   * attempt to prescribe a NDC: 16729028615 based medication to the Patient.
   * verify the system triggers a Pregnancy Alerts Check for Female Patient..
   * Author: Mallikarjuna(vn58n9x)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate system alert triggers for female patient with Pregnancy Alerts Check",
            priority = 20, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR_DATA")
    public void HWPHME2E_2752_Pregnancy_Alerts_Check(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("DRUG_NAME"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.addMedicalConditionDetails(inputData);
        durTestScript.performDropOff(Priority.Critical);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.verifyingAndResolvingConflicts(inputData);
        durTestScript.checkRxIsInFillingQueue();
        Reporter.log("Executed successfully ,Validate system alert triggers for female patient with Pregnancy Alerts Check");
    }

    @Test(enabled = true, description = "Verify monograph for alert Check Dur",
            priority = 21, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_4664_Verify_Monograph_For_Alert_Check_Dur(Map<String, String> inputData){
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.addAllergyToPatientProfile(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.verifyMonographForAlertChkDur(inputData);
    }
    /*----------------------------------------------------------------------------------------------------------
 * HWPHME2E_2755 Test Description : Validate system alert is triggers when prescribing to a patient with drug Interaction Alert Check
 * Pre-Conditions:
 * 1.User is logged into Connexions
 * input a patient profile with the following documented NDC:  68180021509,68645055254.
 * verify the system triggers a drug_Interaction_Alert_Check
 * Author: Mallikarjuna(vn58n9x)
 ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate system alert is triggers when prescribing to a patient with drug Interaction Alert Check",
            priority = 22, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR_DATA")
    public void HWPHME2E_2755_drug_Interaction_Alert_Check(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        // New RX validation
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.Critical);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.checkRxIsInFillingQueue();
        // 2nd-New RX (second drug)
        durTestScript.performDropOff(Priority.Critical);
        inputData.put("DRUG_NAME",inputData.get("DRUG_NAME_2"));
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.verifyChkDurQueueAndConflictMessage(inputData.get("MESSAGE"));
        durTestScript.checkRxIsInFillingQueue();

        Reporter.log("Executed successfully ,Validate that a system alert is triggered when prescribing to a patient with a drug Interaction Alert ");
    }

    /*----------------------------------------------------------------------------------------------------------
* HWPHME2E-3285 Test Description: Counsel from DUR
*
* Pre-Conditions:
* 1.User is logged into Connexus
* Author: Nanthini(vn576ph)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "HWPHME2E_3285_Counsel_from_DUR",
            priority = 23, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3285_Counsel_from_DUR(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.acceptCounselReasonOnDUR();
        durTestScript.performFilling();
        durTestScript.performVisualVerify();
        durTestScript.performPickUp(inputData);
        durTestScript.validateRxIsSkipCounseling();
        durTestScript.performPOS();
        durTestScript.verifyRxInEOD();
    }



    /*----------------------------------------------------------------------------------------------------------
     * HWPHME2E_3294 Test Description: Excess 50MME or 7 Days
     *
     * Author: Naveen(vn58o0j)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-3294")
    @Test(enabled = true, description = "HWPHME2E_3294_Excess_50MME_or_7_Days",
            priority = 24, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3294_Excess_50MME_or_7_Days(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.Critical);
        durTestScript.performInput(inputData);
        durTestScript.performFourPointAndHandleAcuteCondition(inputData);
        durTestScript.openDurAndValidateRedFlag(inputData);
        durTestScript.performFilling();
        durTestScript.performVisualVerify();
        durTestScript.performPickUp(inputData);
        durTestScript.performCounselling();
        durTestScript.performPOS();
        durTestScript.verifyRxInEOD();
    }


    /*----------------------------------------------------------------------------------------------------------
     * HWPHME2E_3281 Test Description: Red DUR override(Condition no longer exists)
     *
     * Author: Naveen(vn58o0j)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-3281")
    @Test(enabled = true, description = "condition_no_longer_exist",
            priority = 25, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3281_Condition_No_Longer_Exist(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.addMedicalConditionDetails(inputData);
        durTestScript.performDropOff(Priority.Critical);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.verifyChkDurQueueAndConflictMessage(inputData.get("MESSAGE"));
        durTestScript.resolveConflictWithReason(inputData.get("REASON"),3);
        durTestScript.checkRxIsInFillingQueue();
    }
    /*----------------------------------------------------------------------------------------------------------
* HWPHME2E_3284 Test Description: DUR counsel opt-in
*
* Pre-Conditions:
* 1.User is logged into Connexus
* Author: Aparna Ramalingam(vn50izt)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = " DUR counsel opt-in",
            priority = 26, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3284_DUR_counsel_opt_in(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData,0);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false);
        durTestScript.performFilling();
        durTestScript.performVisualVerify();
        durTestScript.performPickUp(inputData);
        durTestScript.performCounselling();
        durTestScript.performPOS();
        durTestScript.verifyRxInEOD();
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.resolveCounselOptIn(inputData);
        durTestScript.checkRxIsInFillingQueue();
        durTestScript.performFilling();
        durTestScript.performVisualVerify();
        durTestScript.performPickUp(inputData);
        durTestScript.checkRxIsInCounsellingQueue();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: HWPHME2E_3295_opening Refusal to fill browser from ChkDur
    *
    * Pre-Conditions:  User is logged into Connexus
    *
    * Author: Diya(vn58o0i)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Opening Refusal to fill browser from ChkDur", priority = 27,
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3295_Clicking_Rtf_Brtf_button_From_ChkDur(Map<String, String>inputData){
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(true, false);
        durTestScript.openRefusalToFillBrowser();
    }
    /*----------------------------------------------------------------------------------------------------------
* HWPHME2E_2760 Test Description: Duplicate Therapy Alert Check
*
* Pre-Conditions:
*
* 1.User is logged into Connexus
* 2.Patient is created with the first drug
* Author: Aparna Ramalingam(vn50izt)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = " Duplicate Therapy Alert Check",
            priority = 28, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_2760_Duplicate_Therapy_Alert_Check(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.createPatientAndMoveToEodUsingApi(inputData,Integer.parseInt(propertyReader.getProperty("cnx.store")),1, 21100, 1);
        durTestScript.initializeObjects(true);
        durTestScript.performDropOff(Priority.InStore);
        inputData.put("DRUG_NAME",inputData.get("SECOND_DRUG_NAME"));
        inputData.put("QUANTITY",inputData.get("SECOND_NDC_QTY"));
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.verifyChkDurQueueAndConflictMessage(inputData.get("MESSAGE"));
        durTestScript.checkRxIsInFillingQueue();

    }
    /*----------------------------------------------------------------------------------------------------------
* HWPHME2E_2757 Test Description: Drug Interaction Alert Check
*
* Pre-Conditions:
*
* 1.User is logged into Connexus
* 2.Patient is created with the first drug
* Author: Aparna Ramalingam(vn50izt)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = " Drug Interaction Alert Check",
            priority = 29, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_2757_Drug_Interaction_Alert_Check(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.createPatientAndMoveToEodUsingApi(inputData,Integer.parseInt(propertyReader.getProperty("cnx.store")),1, 21100, 1);
        durTestScript.initializeObjects(true);
        durTestScript.performDropOff(Priority.InStore);
        inputData.put("DRUG_NAME",inputData.get("SECOND_DRUG_NAME"));
        inputData.put("QUANTITY",inputData.get("SECOND_NDC_QTY"));
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.verifyChkDurQueueAndConflictMessage(inputData.get("MESSAGE"));
        durTestScript.resolveConflictWithReason(inputData.get("REASON"),3);
        durTestScript.checkRxIsInFillingQueue();
    }

    /*----------------------------------------------------------------------------------------------------------
   * Test Description: HWPHME2E_2754_Check Dur alert for pregnancy medical condition
   *
   * Pre-Conditions:  1.User is logged into Connexus
   *                  2.Medical Condition: Pregnancy
   *
   * Author: Diya(vn58o0i)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "pregnancy check alert",
            priority = 30, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath =  "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_2754_Chkdur_Alert_For_Pregnancy_Medical_Condition(Map<String , String>inputData){
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.addMedicalConditionDetails(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.verifyingAndResolvingConflicts(inputData);
        durTestScript.checkRxIsInFillingQueue();
    }
    /*----------------------------------------------------------------------------------------------------------
       * HWPHME2E_3276 Test Description : Validate system alert triggers when patient with Yellow DUR
       *
       * Pre-Conditions:
       * 1.User is logged into Connexions
       * patient medical condition : Serotonin Syndrome
       * input a patient profile with a documented 1st RX NDC:   00378073501.
       * input a patient profile with a documented 2nd RX NDC:   70010023305.
       * verify the system triggers a yellow dur alert
       * Author: Mallikarjuna(vn58n9x)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate system alert triggers when prescribing to a patient with Yellow DUR",
            priority = 31, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR_DATA")
    public void HWPHME2E_3276_Yellow_dur(Map<String, String> inputData) {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        // New RX validation
        durTestScript.createNewPatient(inputData);
        durTestScript.addMedicalConditionDetails(inputData);
        durTestScript.performDropOff(Priority.Critical);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.checkRxIsInFillingQueue();
        // 2nd-New RX (second drug)
        durTestScript.performDropOff(Priority.Critical);
        inputData.put("DRUG_NAME",inputData.get("DRUG_NAME_2"));
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false,inputData,false);
        durTestScript.verifyChkDurQueueAndConflictMessage(inputData.get("MESSAGE"));
        durTestScript.checkRxIsInFillingQueue();
        durTestScript.validateSeverityAndGetFillId();

        Reporter.log("Executed successfully ,Validate system alert triggers when prescribing to a patient with Yellow DUR ");
    }


    /*----------------------------------------------------------------------------------------------------------
    * Test Description: HWPHME2E_2742_Check Dur alert for allergy ACE Inhibitors
    *
    * Pre-Conditions:  1.User is logged into Connexus
    *                  2.Allergy: ACE Inhibitors
    *
    * Author: Diya(vn58o0i)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Check alert for allergy ACE Inhibitors",
            priority = 32, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_2742_Allergy_Check_Alert_For_ACE_Inhibitors(Map<String, String>inputData){
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.addAllergyToPatientProfile(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false, false);
        durTestScript.verifyChkDurQueueAndConflictMessage(inputData.get("MESSAGE"));
        durTestScript.resolveConflictWithReason(inputData.get("REASON"),4, inputData.get("OVERRIDE_REASON"));
        durTestScript.checkRxIsInFillingQueue();
    }
    /*----------------------------------------------------------------------------------------------------------
 * HWPHME2E_4663 Test Description : Verify Monograph For a Dosing Check Dur
 *
 * Pre-Conditions:
 * 1.User is logged into Connexions
 * input a patient profile with a documented 1st RX NDC:   00006411903.
 * Verify Monograph For a Dosing Check Dur
 * Author: Mallikarjuna(vn58n9x)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify that the monograph is displayed for dosing alert Check",
            priority = 33, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR_DATA")
    public void HWPHME2E_4663_Verify_Monograph_for_dosing_check_DUR(Map<String, String> inputData){
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.addAllergyToPatientProfile(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(false,false);
        durTestScript.verifyMonographForAlertChkDur(inputData);

        Reporter.log("Executed successfully ,Validate that system triggers an alert and display the monograph for dosing alert Check");
    }
    /*----------------------------------------------------------------------------------------------------------
  * Test Description: HWPHME2E_3278 Orange Dur
  *
  * Pre-Conditions:  1.User is logged into Connexus
  *                  2.Patient should be less than 1 year old
  *
  * Author: Diya(vn58o0i)
  ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Orange Dur",
            priority = 34, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_3278_Orange_Dur_Conflict(Map<String, String>inputData){
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        durTestScript.initializeObjects(false);
        durTestScript.createNewPatient(inputData);
        durTestScript.performDropOff(Priority.InStore);
        durTestScript.performInput(inputData);
        durTestScript.perform4Point(true, false);
        durTestScript.verifyChkDurQueueAndConflictMessage(inputData.get("MESSAGE"));
        durTestScript.checkRxIsInFillingQueue();
    }
    /*----------------------------------------------------------------------------------------------------------
* Test Description: HWPHME2E_5307  DUR conflict triggers,when pharmacist and patient name matches
*
* Pre-Conditions:  1.User is logged into Connexus
*                  2.pharmacist and patient name should match
*
*
* Author: Jyotirmayee Priyadarshini(vn58g1s)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "DUR conflict triggers,when pharmacist and patient name matches",
            priority = 35, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/ChkDUR/DurTest.json", sheetName = "DUR")
    public void HWPHME2E_5307_Dur_Conflict_When_Pharmacist_And_Patient_Name_Matches(Map<String, String> inputData) {
        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login as Pharmacist
        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ Rph
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER"));
        conflictMsg = inputData.get("MESSAGE");
        conflictReason = inputData.get("REASON");
        durTestScript.initializeObjects(false);
        //Search for an existing patient and if not found create a new one
        durTestScript.searchAndHandleExistingPatient(inputData);
        //Drop an order on the Connexus by selecting Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,true);
        //Complete checkdur WQ by selecting one of the conflict reason from the dropdown
        durTestScript.verifyChkDURWQConflictMessageForIMZRx(inputData, conflictMsg,conflictReason,2);
        //Verify the next WQ as Clin Intel
        clinicalIntelligenceTestScript.validateClinicalIntelligenceBtnEnabled(inputData,true);
    }
}