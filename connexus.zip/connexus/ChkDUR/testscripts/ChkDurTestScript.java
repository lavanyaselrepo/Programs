package connexus.ChkDUR.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.awt.event.KeyEvent;
import java.lang.reflect.Array;
import java.util.List;
import java.util.Map;

import static hwqe.baseframework.models.datamodels.connexus.PatientMedicalConditionModel.MedicalCondition.YES;

public class ChkDurTestScript extends ConnexusTestScripts {

    SoftAssert softAssert = new SoftAssert();
    F6Search rxSearch;
    ChkDur chkdurPage;
    MenuBar menuBar ;
    InputPage inputPage;
    FourPoint fourPoint;
    int rxFillId;

    ConsolidatedNotesPage consolidatedNotesPage;

    public ChkDurTestScript(LoginAs.userType loginUserType) {
        super(loginUserType);
    }

    /*
     * Method to initialize necessary objects
     *
     * Author: Aparna Ramalingam (vn50izt)
     * */
    public  void initializeObjects(boolean relaunchConnexus) {
        initializeTestCase(relaunchConnexus);
        inputPage = new InputPage();
        chkdurPage = new ChkDur();
        rxSearch = new F6Search();
        automationManager = AutomationManager.getInstance();
        connexusAppUtils = new ConnexusAppUtils();
        modifyDetails = new ModifyDetails();
        menuBar = new MenuBar();
        consolidatedNotesPage = new ConsolidatedNotesPage();
        fourPoint = new FourPoint();
    }
    /*
     * Method to perform ChkDUR
     *
     * Author: Aparna Ramalingam (vn50izt)
     * */
    public void validateResolutionOnDUR() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
                rxSearch.selectRowFromSearch(0);
                Reporter.logScreenShot("ChkDUR screen", chkdurPage.takeScreenShot());
                chkDur.pressKeys(KeyEvent.VK_ALT, KeyEvent.VK_U, KeyEvent.VK_S);
                if (chkdurPage.checkRxResolutionPopUp()) {
                    Reporter.log("Rx Resolution screen has been opened");
                } else {
                    Assert.fail("Unable to send it to resolution");
                }
            }
            else {
                Reporter.logScreenShot("Rx status",chkdurPage.takeScreenShot());
                Assert.fail("RX is not in CHkDUR queue");
            }
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: "+ e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
        catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*
     * Method to send Rx to Resolution queue
     *
     * Author: Aparna Ramalingam (vn50izt)
     * */
    public void selectRph(String inputResolutionType, InputPage.ManualResolutionType manualResolutionType) {
        try {
            inputPage.sendRxToManualResolution(inputResolutionType, manualResolutionType);
        } catch (Exception e) {
            Reporter.log("Test failed at RX Resolution page");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
        }
    }

    /*
     * Method to verify if Rx is in Resolution queue with expected problem message
     *
     * Author: Aparna Ramalingam (vn50izt)
     * */
    public void verifyResolutionStatus(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            List<String> statusAndProblem = rxSearch.getRxStatusAndProblem(rxNbr, 0);
            String message = inputData.get("MESSAGE");
            if (statusAndProblem.get(0) != null && statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                Reporter.log("Patient is in Resolve Queue with " + message);
                Reporter.logScreenShot("Rx search", chkdurPage.takeScreenShot());
                rxSearch.closeSearch();
                Assert.assertTrue(
                        statusAndProblem.get(1) != null && statusAndProblem.get(1).contains(message),
                        "Problem message should contain expected text"
                );
            } else {
                Assert.fail("Patient not landed in Resolve Queue with " + message);
            }
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Failed in verifyResolutionStatus");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, chkdurPage.takeScreenShot("verifyResolutionStatus").getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*
     * Method to check if "Therapy Discontinued will cancel the fill and deactivate the prescription. Continue?" Popup message is visible
     *
     * Author: Nanthini
     * */
    public void therapyDiscontinuedOpenStock(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (!openDUR()) {
                Assert.fail("ChkDUR screen is not opened");
            }
            chkDur.pressKeys(KeyEvent.VK_ALT, KeyEvent.VK_U, KeyEvent.VK_C, KeyEvent.VK_T);
            String DiscontinuePopup = chkdurPage.getTextOfcancelFillPopup();
            Reporter.log("Popup Message" + DiscontinuePopup);
            Reporter.logScreenShot("Therapy DiscontinuePopup",chkdurPage.takeScreenShot());
            Assert.assertEquals(DiscontinuePopup,inputData.get("POPUP MESSAGE"));
            modifyDetails.clickOnNoBtn();
            chkdurPage.exitFromDur();
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, chkdurPage.takeScreenShot("verifyResolutionStatus").getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate if "Should be On-hold will cancel the fill and place prescription on-hold. Continue?" Popup is visible
     *
     * Author: Nanthini
     * */
    public void validatePutRxOnHold(Map<String, String> inputData) {
        try {
            openDUR();
            chkDur.pressKeys(KeyEvent.VK_ALT, KeyEvent.VK_U, KeyEvent.VK_C, KeyEvent.VK_S);
            String cancelFillPopup = chkdurPage.getTextOfcancelFillPopup();
            Reporter.log("Popup Message" + cancelFillPopup);
            Assert.assertEquals(cancelFillPopup, inputData.get("POPUP MESSAGE"));
            Reporter.logScreenShot(" Validate On Hold Popup Message", chkdurPage.takeScreenShot());
            modifyDetails.clickOnNoBtn();
            chkdurPage.exitFromDur();
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            Reporter.logScreenShot("validatePutRxOnHold", chkdurPage.takeScreenShot());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*
     * Method to open ChkDUR
     *
     * Author: Nanthini
     * */
    public boolean openDUR() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                orderSearch.performSearch(rxNbr, SearchType.PatientRx);
                orderSearch.selectRowFromSearch(0);
                if (orderSearch.isCheckDURPageDisplayed()) {
                    Reporter.logScreenShot("CHKDUR screen", chkdurPage.takeScreenShot());
                    return true;
                } else {
                    Reporter.log("ChkDur screen is not opened");
                }
            }
        } catch (Exception e) {
            Reporter.log("Test failed at ChkDUR queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return false;
    }


    /*
    * Method to validate if Duplicate Fill is visible after getting the Popup
    * */
    public void performDURCheck_Duplicate_Fill(Map<String,String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (!openDUR()){
                Assert.fail("Not in ChkDUR queue or screen is not opened");
            }
            chkDur.pressKeys(KeyEvent.VK_ALT, KeyEvent.VK_U, KeyEvent.VK_C, KeyEvent.VK_D);
            Assert.assertEquals(chkDur.Duplicate_Fill_TextPopup(),inputData.get("POPUP MESSAGE"));
            modifyDetails.clickOnNoBtn();
            chkDur.exitFromDur();
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            Reporter.log("Test failed at ChkDUR queue");
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate if WrittenRx Back is visible after getting the Popup
     * */
    public void performDURCheckAndPatientWrittenRxBack(Map<String,String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (!openDUR()){
                Assert.fail("Not in ChkDUR queue or screen is not opened");
            }
            chkDur.pressKeys(KeyEvent.VK_ALT, KeyEvent.VK_U, KeyEvent.VK_C, KeyEvent.VK_P);
            Assert.assertEquals(chkDur.PatientWants_WrittenRX_TextPopup(),inputData.get("POPUP MESSAGE"));
            modifyDetails.clickOnNoBtn();
            chkDur.exitFromDur();
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            Reporter.log("Test failed at ChkDUR queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to add patient medical condition details
     * */
    public void addMedicalConditionDetails(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            String patientDOB = inputData.get("DOB");
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            patientMaintenancePage.setMedicalCondition(YES);
            Reporter.logScreenShot("click Medical Condition Tab", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.addMedicalcondition_Disease(inputData);
            Reporter.logScreenShot("Added Medical Condition details ", connexusStartPage.takeScreenShot());
            Reporter.log("Patient Medical Condition is added");
            patientMaintenancePage.clickSaveAndClose();
            if (patientMaintenancePage.isSaveAsEnteredDisplayed()) {
                patientMaintenancePage.clickSaveAsEntered();
            }
        }
        catch(Exception e){
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate ChkDUR Screen For Neuromuscular Patient
     * */
    public void ValidateChkDURScreenForNeuromuscularPatient(Map<String,String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openDUR();
            Reporter.logScreenShot("ChkDUR screen",chkDur.takeScreenShot());
            Assert.assertEquals(chkDur.Neuromuscular_patient_Dur_screen_text(),inputData.get("Conflicts_Dut_Text"));
            chkDur.click_resolve_All_Conflicts();
            chkDur.clickAccept();
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue :" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate system alert triggers when a patient with a Penicillin allergy is flagged during prescription
     * */
    public void ValidateDURConflictsChkDURScreen(Map<String,String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openDUR();
            Reporter.logScreenShot("ChkDUR screen",chkDur.takeScreenShot());
            Assert.assertEquals(chkDur.PatientPenicillinsDurscreenText(),inputData.get("Conflicts_Dut_Text"));
            chkDur.click_resolve_All_Conflicts();
            chkDur.clickAccept();
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue :" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate and resolve conflicts in chkdur
     * */
    public void verifyingAndResolvingConflicts(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openDUR();
            Assert.assertTrue(chkdurPage.checkDURAlerts().contains(inputData.get("MESSAGE")));
            Reporter.log("Expected message appear :" + inputData.get("MESSAGE"));
            chkdurPage.selectDurCheckBoxes();
            chkdurPage.clickAccept();
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue :"+e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate Rx is in next work queue
     * */
    public void checkRxIsInFillingQueue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue())) {
                orderSearch.performSearch(rxNbr, SearchType.PatientRx);
                takeScreenShotRXStatus(rxNbr,WorkQueue.FILLING.getWorkQueue(),currentStepMethodName,Status.PASS);
                chkdurPage.CloseOrderSearch();
            }
            else {
                Reporter.log("RX is not in filling queue");
                Assert.fail("RX is not in filling queue");
            }
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at filling queue :"+e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*
     * Method to Open counseling Notes
     *
     * Author: Nanthini
     * */
    public void validateCounsellingNotes(Map<String, String> inputData) {
        try {
            openDUR();
            Assert.assertTrue(chkdurPage.isChkDurOpen());
            Reporter.log("Rx has reached chkDUR queue");
            Reporter.logScreenShot("CHKDUR screen", connexusStartPage.takeScreenShot());
            chkdurPage.clickCounsellingNotes();
            Assert.assertTrue(chkdurPage.getrdbCounselState());
            Reporter.log("Counseling radio button is selected");
            chkdurPage.enterCounselingNotes(inputData.get("COUNSELING_NOTES"));
            Reporter.logScreenShot("entering Counseling Notes", chkdurPage.takeScreenShot());
            Reporter.log("saved counseling notes");
            chkdurPage.clickCounsellingNotes();
            String notes = consolidatedNotesPage.getTxtNotes().trim();
            Assert.assertTrue(notes.contains(inputData.get("COUNSELING_NOTES")),"Counsel reason is " + notes);
            Reporter.log("Counsel Note is " + notes);
            Reporter.logScreenShot("validating entered Counseling Notes", chkdurPage.takeScreenShot());
            consolidatedNotesPage.clickButtonExit();
            chkdurPage.exitFromDur();
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            Reporter.log("Exception messgae for Counsel Note is not saved:" + e.getMessage());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyChkDURWQConflictMessageForIMZRx(Map<String, String> inputData,String conflictMessage,String reason,int counter) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        orderSearch = new F6Search();
        try {
            rxNbr = orderSearch.getRxNbrForPatient(inputData.get("LAST_NAME") + "," + inputData.get("FIRST_NAME"), 0);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_20)) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                verifyChkDurQueueAndConflictMessage(conflictMessage);
                if (!chkdurPage.clickClearConflictsBtn()) {
                    chkdurPage.selectAllCheckBoxes();
                    chkdurPage.resolveConflictWithReason(reason,counter,null);
                    chkdurPage.click_resolve_All_Conflicts();
                    chkdurPage.clickAccept();
                }

            }
        }
        catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }

        }
    /*
     * Method to verify if Rx is in ChkDUR queue and verify if it contains expected conflict message
     *
     * Author: Aparna Ramalingam (vn50izt)
     * */
    public void verifyChkDurQueueAndConflictMessage(String conflictMessage) {
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(),10)) {
                Reporter.log("RX is in ChkDUR Queue");
                openDUR();
                if (chkDur.clickRedFlagsBtn()) {
                    chkdurPage = new ChkDur();
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }
                Reporter.logScreenShot("ChkDUR screen with Conflict Message", chkdurPage.takeScreenShot());
                List<String> durMessage = chkdurPage.checkDURAlerts();
                boolean redDurFlag = chkdurPage.redDurValidation();
                boolean isConflictFound = false;
                boolean isAcceptbuttonFound = false;
                for(String message: durMessage){
                    if(message.contains(conflictMessage) && redDurFlag){
                        isConflictFound = true;
                        break;
                    }else if(chkdurPage.orangeDurValidation()) {
                        Reporter.log("Orange DUR counsel activity has been validated");
                        chkdurPage.selectDurCheckBoxes();
                        isConflictFound = true;
                        isAcceptbuttonFound = true;
                        break;
                    }else if (message.contains(conflictMessage)) {
                        chkdurPage.selectDurCheckBoxes();
                        isConflictFound = true;
                        isAcceptbuttonFound = true;
                    }
                }
                Assert.assertTrue(isConflictFound,"Conflict message should display for patient with allergy  ");
                if (!conflictMessage.isEmpty()) {
                    Reporter.log("Expected message appear :" + conflictMessage);
                }
                if (isAcceptbuttonFound){
                    chkdurPage.clickAccept();
                }
            } else {
                rxSearch.closeSearch();
                Assert.fail("RX not landed in ChkDUR Queue" );
            }
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            Reporter.log("RX is not ChkDUR queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    /*
     * Method to select reason in chkDUR screen and resolve conflict
     *
     * Author: Aparna Ramalingam (vn50izt)
     * */
    public void resolveConflictWithReason(String reason, int counter) {
        resolveConflictWithReason(reason,counter, null);
    }
    public void resolveConflictWithReason(String reason, int counter,String overrideReason) {
        chkdurPage.resolveConflictWithReason(reason,counter, overrideReason);
    }


    /*
     * Method to verify monograph for alert check DUR
     *
     * Author: Diya Steephen (vn58o0i)
     * */
    public void verifyMonographForAlertChkDur(Map<String, String> inputData) {
        try{
            openDUR();
            String chkDurMessage = chkdurPage.monographForAlertChkDur();
            Assert.assertTrue(chkDurMessage.contains(inputData.get("MESSAGE")));
            chkdurPage.openDurAlertDetail();
            Assert.assertTrue(chkdurPage.verifychkDurAlertMonographIsOpened().contains(inputData.get("POPUP MESSAGE")));
            Reporter.logScreenShot("Dur Alert Details", chkdurPage.takeScreenShot());
            chkdurPage.closeDurAlertMonograph();
            chkdurPage.exitFromDur();
            Reporter.log("Monograph for Alert chkDur is successfully opened while double clicking on the ChkDur conflict description");
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }catch (Exception e){
            Reporter.log("Monograph for Alert chkDur is not opened: " + e.getMessage());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateRxIsSkipCounseling() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (checkOrderNextWorkQueueDB(rxNbr).equals(WorkQueueSettings.Counseling.getValue())){
                Assert.fail("RX is in Counseling Queue");
            } else {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                Reporter.logScreenShot("validating RX is skipped Counseling Queue", chkdurPage.takeScreenShot());
                orderSearch.closeSearch();
                Reporter.log("RX is Skipped Counseling Queue");
            }
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            Reporter.log("RX is not skipped Counseling Queue as Expected:" + e.getMessage());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void acceptCounselReasonOnDUR() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openDUR();
            Assert.assertTrue(chkdurPage.isChkDurOpen());
            chkdurPage.clickCounselButton();
            if(counselPage.isElementDisplayed(counselPage.counselReason,10)){
                counselPage.acceptAll();
                Reporter.logScreenShot(Status.PASS,"Accept Counsel Reason" , counselPage.takeScreenShot());
                counselPage.clickAccept();
                Reporter.log("Counsel is accepted from DUR screen");
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }else {
                Assert.fail("Failed to complete counselling");
            }
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            Reporter.log("Check DUR is not completed:" + e.getMessage());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


    /**
     * Method to perform four point with acute condition,Then validating the expected POM 1322 popup.
     * @param inputData
     * Author: Naveen (vn58o0j)
     */
    public void  performFourPointAndHandleAcuteCondition(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try{
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1],0);
            Reporter.log("Rx number is " + rxNbr);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();

            if(fourPoint.onHoldButtonSelected()){
                fourPoint.unCheckOnHold();
            }
            if (fourPoint.isNameChkBoxDisplayed()) {
                Reporter.logScreenShot("Fourpoint Screen", connexusStartPage.takeScreenShot());
                fourPoint.chkName();
                fourPoint.chkPrescribed();
                if (fourPoint.ischkStrength()) {
                    fourPoint.chkStrength();
                }
                fourPoint.chkSIG();
                if (fourPoint.isElementDisplayed(fourPoint.chkDEA, 1)) {
                    fourPoint.click(fourPoint.chkDEA);
                }
                clickAcuteConditionAndHandlePopup(inputData);
                fourPoint.clickAccept();
                Reporter.log("4 point completed");
            }
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }


    /**
     * Method for clicking the acute condition and Validating the POM 1322 popup after giving the initial fill as yes.
     * @param inputData
     * Author: Naveen (vn58o0j)
     */
    public void clickAcuteConditionAndHandlePopup(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (fourPoint.isElementDisplayed(fourPoint.rdbAcute, 5)) {
                fourPoint.click(fourPoint.rdbAcute);
                fourPoint.click(fourPoint.clickInitialFill);
            }
            if (fourPoint.isElementDisplayed(fourPoint.rdbAcuteInitialFillYes, 10)) {
                fourPoint.moveToElementAndClick(fourPoint.rdbAcuteInitialFillYes);
            }
            Assert.assertEquals(fourPoint.getTextFromPom1322Popup(), inputData.get("POPUP MESSAGE"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            if (fourPoint.isElementDisplayed(fourPoint.btnAcceptFill, 5) && fourPoint.isElementDisplayed(fourPoint.btnModifyFill, 5) && fourPoint.isElementDisplayed(fourPoint.btnCancel, 5)) {
                fourPoint.click(fourPoint.btnAcceptFill);
            } else {
                Assert.fail("Accept fill or Modify fill or cancel buttons are not displayed");
            }
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
        }
    }


    /**
     * Method to validate the red flag description and resolving conflicts in DUR.
     * @param inputData
     * Author: Naveen (vn58o0j)
     */
    public void openDurAndValidateRedFlag(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openDUR();
            List<String> redFlagDescription = chkDur.readRedFlags();
            boolean messageFlag = false;
            if (redFlagDescription.isEmpty()) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("No redflags displayed in the DUR screen");
                Assert.fail("No redflags displayed in the DUR screen");
            }
            for (int i = 0; i < redFlagDescription.size(); i++) {
                if (redFlagDescription.get(i).equalsIgnoreCase(inputData.get("MESSAGE"))) {
                    Assert.assertTrue(true, "Excess of 50MMEs or 7 days flag is  displayed");
                    Reporter.log("Red flag is verified with " + redFlagDescription.get(i));
                    messageFlag = true;
                    break;
                }
                Reporter.logScreenShot("Red flag verified", chkDur.takeScreenShot());
                if (chkDur.clickRedFlagsBtn()) {
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                    chkDur.selectDurCheckBoxes();
                    Reporter.logScreenShot(Status.INFO, "ChkDur completed", chkDur.takeScreenShot("ChkDUR").getValue());
                }
                chkDur.clickAccept();
            }
            if (!messageFlag) {
                Assert.fail("Excess of 50MMEs or 7 days flag is not displayed");
                Reporter.logScreenShot("Red flag not verified", chkDur.takeScreenShot());
            }
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Excess of 50MMEs or 7 days flag is not displayed");
        }
    }

    /*
     * Method to select reason for Counsel Opt-in in chkDUR screen and resolve conflict
     *
     * Author: Aparna Ramalingam (vn50izt)
     * */
    public void resolveCounselOptIn(Map<String,String> inputData) {
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(),10)) {
                Reporter.log("RX is in ChkDUR Queue");
                openDUR();
                chkdurPage.selectCounselChkBox();
                chkdurPage.selectReasonForCounsel(inputData.get("REASON"));
                chkdurPage.selectAllCheckBoxes();
                Reporter.logScreenShot("ChkDUR After selecting reason",chkdurPage.takeScreenShot());
                chkdurPage.clickAccept();
            } else {
                rxSearch.closeSearch();
                Assert.fail("RX has not landed in ChkDUR Queue" );
            }
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            Reporter.log("RX is not ChkDUR queue"+e.getMessage());
            isExceptionCaptured = true;
            Assert.fail(e.toString());
        }
    }
    /*
     * Method to validate Rx is in Counsel work queue
     * */
    public void checkRxIsInCounsellingQueue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Counseling.getValue())) {
                orderSearch.performSearch(rxNbr, SearchType.PatientRx);
                takeScreenShotRXStatus(rxNbr,WorkQueue.COUNSEL.getWorkQueue(),currentStepMethodName,Status.PASS);
                Reporter.log("RX has landed in Counsel queue");
                chkdurPage.CloseOrderSearch();
            }
            else {
                Reporter.log("RX is not in Counsel queue");
                Assert.fail("RX is not in Counsel queue");
            }
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Counsel queue :"+e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*
     * Method to click Rtf/Brtf button and open RTF browser
     *
     * Author: Diya
     * */
    public void openRefusalToFillBrowser(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openDUR();
            Assert.assertTrue(chkdurPage.isChkDurOpen());
            chkdurPage.clickRTFBRTFButton();
            Assert.assertTrue(chkdurPage.isRTFBrowserOpened());
            Reporter.logScreenShot("Refusal to fill browser", chkdurPage.takeScreenShot());
            Reporter.log("Refusal to fill browser is opened when clicking on Rtf/Brtf button from ChkDur");
            Runtime.getRuntime().exec("TASKKILL /F /IM chrome.exe");
            Reporter.log("Browser Closed");
            chkdurPage.exitFromDur();
        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }catch (Exception e){
            isExceptionCaptured = true;
            Reporter.log("Browser not opened: "+e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,chkdurPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void validateSeverityAndGetFillId() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            rxFillId = connexusAppUtils.getFillId(rxNbr);
            connexusAppUtils.validateSeverity(rxFillId,2);
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed during Severity validation and Fill ID retrieval: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
}
