package connexus.Filling.testscripts;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import connexus.ConnexusTestScripts;
import fom.datamodels.ssoresponse.*;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.CreatePatientRequest;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class Rts_testscripts extends ConnexusTestScripts {

    ServiceResponse resp;
    DataRow drugInfo;
    String sapsGetRTSListURL, sapsGetRTSInfoURL;
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse sapsGetRTSInforesp;
    FOMGetRTSInfoResponse sapsGetInfoResponse;
    int bagNbr;
    ArrayList<Integer> fillIdInList = new ArrayList<>();
    boolean isOrderIdInGetRTSList;
    ArrayList<Integer> orderSeqNbrInList = new ArrayList<>();
    int patientId, numRefills, priorityId, requestTypeCode, dispenseType, clinicId, prescriber;
    WrapperUtils wrapperUtils = new WrapperUtils();
    ServiceResponse sapsGetRTSListresp;
    FOMSapsGetRTSListResponse sapsGetRTSListResponse;
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();


    public ServiceResponse performGetRTSInfo(String bagNbr) {
        String serviceEndpoint = StoreIDManager.createEndPointURL(propertyReader.getProperty("cnx.store"), propertyReader.getProperty("connexustestharness.common.portNo"), propertyReader.getProperty("connexustestharness.sapsUrl.https"), propertyReader.getProperty("connexusharness.GetRTSlistInfoEndPoint"));
        req.setUrl(serviceEndpoint + "?bagNbr=" + bagNbr);
        headers.put("content-type", "application/json");
        headers.put("DeviceName", propertyReader.getProperty("fom.setDeviceName"));
        headers.put("source", propertyReader.getProperty("fom.rtssource"));
        headers.put("RequestUser", propertyReader.getProperty("fom.newuserId"));
        headers.put("storeId", propertyReader.getProperty("cnx.store"));
        headers.put(propertyReader.getProperty("app.authprop"), propertyReader.getProperty("cw.saps"));
        req.setHeaders(headers);
        Reporter.log("GetRTSInfo Request endpoint: " + req.getUrl());
        resp = automationManager.getRestContext().performGet(req);
        Reporter.logJSON("GetRTSInfo Response", resp.getDataResponse());
        return resp;
    }

    public void RTSresponse(Map<String, String> inputData) {
        resp = performGetRTSInfo(inputData.get("bagnbr"));
        Assert.assertTrue(resp.getStatusCode() ==406,"Expected status code 406 but found " + resp.getStatusCode());
        Reporter.log("API Response Status Code: " + resp.getStatusCode());
    }

    public int genericCreatePatient() {
        CreatePatientRequest createPatientRequest = new CreatePatientRequest();
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        siteId = Integer.parseInt(propertyReader.getProperty("cnx.store"));
        //Build input patient
        createPatientRequest.setFirstName(name[0]);
        createPatientRequest.setLastName(name[1]);
        createPatientRequest.setSiteId(siteId);
        createPatientRequest.setHomePhone("1234567890");
        createPatientRequest.setWorkPhone("8888888999");
        createPatientRequest.setCellPhone("9876543210");
        //without TP Details
        patientId= connexusAPIManager.createPaientWithOrWithoutTP(createPatientRequest);
        return patientId;
    }

    public String createOrderTillPickup(String ndc) {
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        priorityId = 21100;
        requestTypeCode = 1600;
        dispenseType = 1;
        numRefills = 0;
        Prescriber prescriber;
        prescriber = wrapperUtils.PrescriberDetails();
        DataRow prescriberData = connexusAPIManager.getPrescriberInfo(cnx, prescriber.getPrescriberId());
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();
        drugInfo = connexusAPIManager.getDrugInfo(cnx, ndc);
        resp = connexusAPIManager.orderToPickup(siteId, patientId, priorityId, requestTypeCode, dispenseType, numRefills, inputPickupDate, clinicId, inputRxExpDate, drugInfo, prescriberData);
        Assert.assertEquals(resp.getStatusCode(), 201, "The order cannot be created and drop till pickup" + resp.getDataResponse());
        Gson gson = new Gson();
        JsonObject json = gson.fromJson(resp.getDataResponse(), JsonObject.class);
        rxNbr = json.get("rxNbr").getAsString();
        Log.info("rxNbr:" + rxNbr);
        Reporter.log("rxNbr:" + rxNbr);
        return rxNbr;
    }

    public ServiceResponse rtsList() {

        sapsGetRTSListURL = StoreIDManager.createEndPointURL(propertyReader.getProperty("cnx.store"), propertyReader.getProperty("connexustestharness.common.portNo"), propertyReader.getProperty("connexustestharness.sapsUrl.https"), propertyReader.getProperty("connexusharness.GetRTSList"));
        req.setUrl(sapsGetRTSListURL);
        headers.put("content-type", "application/json");
        headers.put("DeviceName", propertyReader.getProperty("fom.setDeviceName"));
        headers.put("source", propertyReader.getProperty("fom.rtssource"));
        headers.put("RequestUser", propertyReader.getProperty("fom.newuserId"));
        headers.put("storeId", propertyReader.getProperty("cnx.store"));
        headers.put(propertyReader.getProperty("app.authprop"), propertyReader.getProperty("cw.saps"));
        req.setHeaders(headers);
        Reporter.log("GetRTSList Request endpoint: " + req.getUrl());
        resp = automationManager.getRestContext().performGet(req);
        Reporter.logJSON("GetRTSList Response", resp.getDataResponse());
        return resp;
    }

    public ServiceResponse RTSInfo(int bagNbr) {

        sapsGetRTSInfoURL = StoreIDManager.createEndPointURL(propertyReader.getProperty("cnx.store"), propertyReader.getProperty("connexustestharness.common.portNo"), propertyReader.getProperty("connexustestharness.sapsUrl.https"), propertyReader.getProperty("connexusharness.GetRTSInfo"));
        sapsGetRTSInfoURL = sapsGetRTSInfoURL + "?bagNbr=" + bagNbr;
        req.setUrl(sapsGetRTSInfoURL);
        headers.put("content-type", "application/json");
        headers.put("DeviceName", propertyReader.getProperty("fom.setDeviceName"));
        headers.put("source", propertyReader.getProperty("fom.rtssource"));
        headers.put("RequestUser", propertyReader.getProperty("fom.newuserId"));
        headers.put("storeId", propertyReader.getProperty("cnx.store"));
        headers.put(propertyReader.getProperty("app.authprop"), propertyReader.getProperty("cw.saps"));
        req.setHeaders(headers);
        Reporter.log("GetRTSInfo Request endpoint: " + req.getUrl());
        resp = automationManager.getRestContext().performGet(req);
        Reporter.logJSON("GetRTSInfo Response", resp.getDataResponse());
        return resp;
    }

    public FOMGetRTSInfoResponse validateSapsGetRTSInfoAPI(int bagNbr, int getRTSInfoResponseCode) {

        // Query to get Order ID
        String orderIdQuery = "SELECT rod.order_id FROM rx_order_detail rod " + "INNER JOIN rx r ON rod.rx_id=r.rx_id WHERE rod.next_work_que_code=6 " + "AND r.patient_id=" + patientId + " ORDER BY rod.rx_fill_id DESC LIMIT 1";
        int order_Id = automationManager.getConnexusDB(siteId).getScalar(orderIdQuery, Integer.class);
        int siteID = Integer.parseInt(propertyReader.getProperty("cnx.store"));
        sapsGetRTSInforesp = RTSInfo(bagNbr);
        Assert.assertEquals(sapsGetRTSInforesp.getStatusCode(), getRTSInfoResponseCode, "GetRTSInfo Saps service response did not match");
        if (getRTSInfoResponseCode == 200) {
            sapsGetInfoResponse = sapsGetRTSInforesp.getDataResponse(FOMGetRTSInfoResponse.class);
            System.out.println("Expected Order ID: " + order_Id);
            for (fom.datamodels.ssoresponse.SapsRTSListContents order : sapsGetInfoResponse.getRtsList()) {
                System.out.println("Checking Order ID: " + order.getOrderId());
                if (order.getOrderId().equals(String.valueOf(order_Id))) {
                    System.out.println("Matched Order ID: " + order_Id);
                    Reporter.log("Found Order ID: " + order_Id);
                    // Extract details
                    Reporter.log("Bag Number: " + order.getOrderInfo().get(0).getBagNbr());
                    Reporter.log(" Color Abbreviation: " + order.getOrderInfo().get(0).getColorAbbr());
                    Reporter.log(" Color Code: " + order.getOrderInfo().get(0).getColorCode());
                    for (fom.datamodels.ssoresponse.SapsRTSFillInfoContents fillInfo : order.getOrderInfo().get(0).getFillInfo()) {
                        Reporter.log(" - Fill ID: " + fillInfo.getFillId());
                        Reporter.log("   - Fill Date: " + fillInfo.getFillDate());
                        Reporter.log(" - Fill Type: " + fillInfo.getFillType());
                        Reporter.log(" - Is Compound: " + (fillInfo.isCompound() ? "true" : "false"));
                        Reporter.log(" - Rx Number: " + fillInfo.getRxNbr());
                        Reporter.log(" - VV Date: " + fillInfo.getVvDate());

                        for (fom.datamodels.ssoresponse.SapsRTSFillItemContents item : fillInfo.getFillItems()) {
                            Reporter.log("   - Drug Code: " + item.getDrugControlCode());
                            Reporter.log("   - Short Name: " + item.getShortName());
                            Reporter.log("   - MdsFamId: " + item.getMdsfamid());
                            Reporter.log(" - Department Number: " + item.getDeptNumber());
                            Reporter.log(" - Inner Pack Quantity: " + item.getInnerPackQty());
                            Reporter.log(" - Item Quantity: " + item.getItemQty());
                            Reporter.log(" - Single Dispense Indicator: " + item.getSingleDispInd());
                        }
                    }
                    break;
                }
            }
        }
        return sapsGetInfoResponse;
    }


    public void validateRTSServices(int fillCountInOrder, int NumberOfDaysInPickUp, boolean isOrderIdInGetRTSListValidation, int getRTSInfoResponseCode) {

        siteId = Integer.parseInt(propertyReader.getProperty("cnx.store"));
        isOrderIdInGetRTSList = false;
        fillIdInList.clear();
        orderSeqNbrInList.clear();
        genericCreatePatient();
        createOrderTillPickup("00781528364");
        // Query to get Order ID
        String orderIdQuery = "SELECT rod.order_id FROM rx_order_detail rod " +
                "INNER JOIN rx r ON rod.rx_id=r.rx_id WHERE rod.next_work_que_code=6 " +
                "AND r.patient_id=" + patientId + " ORDER BY rod.rx_fill_id DESC LIMIT 1";
        Integer order_Id = automationManager.getConnexusDB(siteId).getScalar(orderIdQuery, Integer.class);
        System.out.println("Executed Order ID Query: " + orderIdQuery);
        System.out.println("Retrieved order_Id: " + order_Id);
        Reporter.log("Executed Order ID Query: " + orderIdQuery);
        Reporter.log("Retrieved order_Id: " + order_Id);

        // Query to get Fill Details
        String fillDetailsQuery = "SELECT rx_fill_id, tote_nbr, order_seq_nbr FROM rx_order_detail " +
                "WHERE order_id=" + order_Id + " AND next_work_que_Code=6 ORDER BY rx_fill_id DESC";
        List<Map<String, Object>> fillDetailsFromDB = automationManager.getConnexusDB(siteId).executeQueryForList(fillDetailsQuery);
        System.out.println("Executed Fill Details Query: " + fillDetailsQuery);
        System.out.println("Retrieved fillDetailsFromDB: " + fillDetailsFromDB);
        Reporter.log("Executed Fill Details Query: " + fillDetailsQuery);
        Reporter.log("Retrieved fillDetailsFromDB: " + fillDetailsFromDB);

        // Validate fillDetailsFromDB size
        Assert.assertEquals(fillDetailsFromDB.size(), fillCountInOrder, "Mismatch in expected and actual fill count");

        // Generate a random 4-digit tote number
        Random random = new Random();
        int randomToteNumber = random.nextInt(900) + 100;
        if (fillDetailsFromDB.isEmpty() || fillDetailsFromDB.get(0).get("tote_nbr") == null) {
            Integer rxFillId = Integer.parseInt(fillDetailsFromDB.get(0).get("rx_fill_id").toString());
            String updateToteNbrQuery = "UPDATE rx_order_detail SET tote_nbr = " + randomToteNumber + " WHERE rx_fill_id = " + rxFillId;
            automationManager.getConnexusDB(siteId).executeUpdateQuery(updateToteNbrQuery);
            System.out.println("Executed Tote Number Update Query: " + updateToteNbrQuery);
            Reporter.log("Executed Tote Number Update Query: " + updateToteNbrQuery);
            // Re-run the query to fetch updated values
            fillDetailsFromDB = automationManager.getConnexusDB(siteId).executeQueryForList(fillDetailsQuery);
        }
        bagNbr = Integer.parseInt(fillDetailsFromDB.get(0).get("tote_nbr").toString());
        Reporter.log("Randomly Generated Bag Number: " + bagNbr);
        System.out.println("Randomly Generated Bag Number: " + bagNbr);
        for (int i = 0; i < fillDetailsFromDB.size(); i++) {
            fillIdInList.add(Integer.parseInt(fillDetailsFromDB.get(i).get("rx_fill_id").toString()));
            orderSeqNbrInList.add(Integer.parseInt(fillDetailsFromDB.get(i).get("order_seq_nbr").toString()));
        }
        LocalDate newDate = LocalDate.now().minusDays(NumberOfDaysInPickUp);
        for (int j = 0; j < fillIdInList.size(); j++) {
            String updateQuery = "UPDATE rx_fill SET fill_date='" + newDate + "' WHERE rx_fill_id=" + fillIdInList.get(j);
            automationManager.getConnexusDB(siteId).executeUpdateQuery(updateQuery);
            System.out.println("Executed Update Query: " + updateQuery);
            Reporter.log("Executed Update Query: " + updateQuery);
        }
        String fetchUpdatedFillDateQuery = "SELECT rx_fill_id, fill_date FROM rx_fill WHERE rx_fill_id IN (" +
                fillIdInList.stream().map(String::valueOf).collect(Collectors.joining(",")) + ")";
        List<Map<String, Object>> updatedFillDates = automationManager.getConnexusDB(siteId).executeQueryForList(fetchUpdatedFillDateQuery);
        System.out.println("Executed Fetch Updated Fill Date Query: " + fetchUpdatedFillDateQuery);
        System.out.println("Updated Fill Dates: " + updatedFillDates);
        Reporter.log("Executed Fetch Updated Fill Date Query: " + fetchUpdatedFillDateQuery);
        Reporter.log("Updated Fill Dates: " + updatedFillDates);
        sapsGetRTSListresp = rtsList();
        Assert.assertEquals(sapsGetRTSListresp.getStatusCode(), 200, "GetRTSList Saps service response did not match");
        sapsGetRTSListResponse = sapsGetRTSListresp.getDataResponse(FOMSapsGetRTSListResponse.class);
        for (int k = 0; k < sapsGetRTSListResponse.getRtsList().size(); k++) {
            if (order_Id == Integer.parseInt(sapsGetRTSListResponse.getRtsList().get(k).getOrderId())) {
                isOrderIdInGetRTSList = true;
                break;
            }
        }
        Assert.assertEquals(isOrderIdInGetRTSList, isOrderIdInGetRTSListValidation,"Validation of orderId:"+order_Id+" presence in getRTSList response did not match");
        sapsGetInfoResponse=validateSapsGetRTSInfoAPI(bagNbr,getRTSInfoResponseCode);
    }

    public void validateFillDatesInRTSResponse() {

        int siteID = Integer.parseInt(propertyReader.getProperty("cnx.store"));
        String minusdaysquery = "SELECT phm_parm_value from bu_phm_parm WHERE phm_parm_code = 5384;";
        Reporter.log("minusdays Query: " + minusdaysquery);
        int minusdays = automationManager.getConnexusDB(siteID).getScalar(minusdaysquery, Integer.class);
        Reporter.log("minusdays: " + minusdays);
        sapsGetRTSListresp = rtsList();
        Assert.assertEquals(sapsGetRTSListresp.getStatusCode(), 200, "GetRTSList Saps service response did not match");
        FOMSapsGetRTSListResponse response = sapsGetRTSListresp.getDataResponse(FOMSapsGetRTSListResponse.class);
        // Define cutoff date (minus X days from today)
        LocalDate cutoffDate = LocalDate.now().minusDays(minusdays);
        for (SapsRTSListContents order : response.getRtsList()) {
            for (SapsRTSorderInfoContents orderInfo : order.getOrderInfo()) {
                for (SapsRTSFillInfoContents fillInfo : orderInfo.getFillInfo()) {
                    if (fillInfo.getFillDate() != null) {
                        LocalDate fillDate = LocalDate.parse(fillInfo.getFillDate());
                        // **Skip validation if minusdays == 0**
                        if (minusdays > 0) {
                            Assert.assertTrue(fillDate.isEqual(cutoffDate) || fillDate.isBefore(cutoffDate),
                                    "Invalid fill date: " + fillDate + " is within the last " + minusdays + " days");
                        } else {
                            Reporter.log("Skipping validation as minusdays is 0. Accepting fill date: " + fillDate);
                        }
                        Reporter.log("Validated fill date: " + fillDate + " (minusdays = " + minusdays + ")");
                    }
                }
            }
            Reporter.log("Validation successful: All fill dates are at least " + minusdays + " days old.");
            System.out.println("Validation successful: All fill dates are at least " + minusdays + " days old.");
        }

    }

    public void validationinRTSlist() {

        int siteId = Integer.parseInt(propertyReader.getProperty("cnx.store"));

        sapsGetRTSListresp = rtsList();
        Assert.assertEquals(sapsGetRTSListresp.getStatusCode(), 200, "GetRTSList Saps service response did not match");
        sapsGetRTSListResponse = sapsGetRTSListresp.getDataResponse(FOMSapsGetRTSListResponse.class);
        FOMSapsGetRTSListResponse sapsGetRTSListResponse = sapsGetRTSListresp.getDataResponse(FOMSapsGetRTSListResponse.class);
        Reporter.log("Parsed API Response Successfully");

        List<String> fillIdsToUpdate = sapsGetRTSListResponse.getRtsList().stream()
                .flatMap(order -> order.getOrderInfo().stream())
                .filter(orderInfo -> orderInfo.getBagNbr() == 0)
                .flatMap(orderInfo -> orderInfo.getFillInfo().stream())
                .map(SapsRTSFillInfoContents::getFillId)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        Reporter.log("Found " + fillIdsToUpdate.size() + " entries with bagNbr = 0");

        // Update bagNbr in the database with different random numbers
        Random random = new Random();
        for (String fillId : fillIdsToUpdate) {
            int randomToteNumber = random.nextInt(900) + 100;
            String updateQuery = "UPDATE rx_order_detail SET tote_nbr = " + randomToteNumber + " WHERE rx_fill_id = " + fillId;
            Reporter.log("Executing Update Query: " + updateQuery);
            automationManager.getConnexusDB(siteId).executeUpdateQuery(updateQuery);
            Reporter.log("Executed Update Query for fillId " + fillId + " -> Assigned Tote: " + randomToteNumber);
        }
        Reporter.log("Updated bagNbr for all applicable records with unique values.");
        sapsGetRTSListresp = rtsList();
        Assert.assertEquals(sapsGetRTSListresp.getStatusCode(), 200, "GetRTSList Saps service response did not match after update");
        Reporter.log("Re-hit RTS List API Call after Update");
        sapsGetRTSListResponse = sapsGetRTSListresp.getDataResponse(FOMSapsGetRTSListResponse.class);
        Reporter.log("Parsed Updated API Response Successfully");
        //Validate that no bagNbr is 0
        boolean hasZeroBagNbr = sapsGetRTSListResponse.getRtsList().stream()
                .flatMap(order -> order.getOrderInfo().stream())
                .anyMatch(orderInfo -> orderInfo.getBagNbr() == 0);
        Assert.assertFalse(hasZeroBagNbr, "There are still records with bagNbr = 0 after update");
        Reporter.log("Final validation: No bagNbr = 0 found.");
    }

    public void validate206response(int fillCountInOrder) {


        siteId = Integer.parseInt(propertyReader.getProperty("cnx.store"));
        genericCreatePatient();
        createOrderTillPickup("00536467801");

        // Query to get Order ID
        String orderIdQuery = "SELECT rod.order_id FROM rx_order_detail rod " + "INNER JOIN rx r ON rod.rx_id=r.rx_id WHERE rod.next_work_que_code=6 " + "AND r.patient_id=" + patientId + " ORDER BY rod.rx_fill_id DESC LIMIT 1";
        Integer order_Id = automationManager.getConnexusDB(siteId).getScalar(orderIdQuery, Integer.class);
        System.out.println("Executed Order ID Query: " + orderIdQuery);
        System.out.println("Retrieved order_Id: " + order_Id);
        Reporter.log("Executed Order ID Query: " + orderIdQuery);
        Reporter.log("Retrieved order_Id: " + order_Id);

        // Query to get Fill Details
        String fillDetailsQuery = "SELECT rx_fill_id, tote_nbr, order_seq_nbr FROM rx_order_detail " + "WHERE order_id=" + order_Id + " AND next_work_que_Code=6 ORDER BY rx_fill_id DESC";

        List<Map<String, Object>> fillDetailsFromDB = automationManager.getConnexusDB(siteId).executeQueryForList(fillDetailsQuery);
        System.out.println("Executed Fill Details Query: " + fillDetailsQuery);
        System.out.println("Retrieved fillDetailsFromDB: " + fillDetailsFromDB);
        Reporter.log("Executed Fill Details Query: " + fillDetailsQuery);
        Reporter.log("Retrieved fillDetailsFromDB: " + fillDetailsFromDB);
        // Validate fillDetailsFromDB size
        Assert.assertEquals(fillDetailsFromDB.size(), fillCountInOrder,
                "Mismatch in expected and actual fill count");
        // Generate a random 4-digit tote number
        Random random = new Random();
        int randomToteNumber = random.nextInt(900) + 100;

        if (fillDetailsFromDB.isEmpty() || fillDetailsFromDB.get(0).get("tote_nbr") == null) {
            Integer rxFillId = Integer.parseInt(fillDetailsFromDB.get(0).get("rx_fill_id").toString());
            String updateToteNbrQuery = "UPDATE rx_order_detail SET tote_nbr = " + randomToteNumber + " WHERE rx_fill_id = " + rxFillId;
            automationManager.getConnexusDB(siteId).executeUpdateQuery(updateToteNbrQuery);
            System.out.println("Executed Tote Number Update Query: " + updateToteNbrQuery);
            Reporter.log("Executed Tote Number Update Query: " + updateToteNbrQuery);
            // Re-run the query to fetch updated values
            fillDetailsFromDB = automationManager.getConnexusDB(siteId).executeQueryForList(fillDetailsQuery);
        }
        bagNbr = Integer.parseInt(fillDetailsFromDB.get(0).get("tote_nbr").toString());
        Reporter.log("Randomly Generated Bag Number: " + bagNbr);
        System.out.println("Randomly Generated Bag Number: " + bagNbr);
        for (int i = 0; i < fillDetailsFromDB.size(); i++) {
            fillIdInList.add(Integer.parseInt(fillDetailsFromDB.get(i).get("rx_fill_id").toString()));
            orderSeqNbrInList.add(Integer.parseInt(fillDetailsFromDB.get(i).get("order_seq_nbr").toString()));
        }
        String minusdaysquery = "SELECT phm_parm_value from bu_phm_parm WHERE phm_parm_code = 5384;";
        Reporter.log("Query to find the number of days for valid fill: " + minusdaysquery);
        int phm_parm_valueDays = automationManager.getConnexusDB(siteId).getScalar(minusdaysquery, Integer.class);
        Reporter.log("Query returns days as: " + phm_parm_valueDays);
        RTSInfo(bagNbr);
        Reporter.log("API Response Status Code: " + resp.getStatusCode());
        Reporter.log("created a new Rx till pickup with todays fill date and the reponse return:" +resp.getStatusCode());
    }
}

