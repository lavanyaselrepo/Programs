package connexus.Filling.testscripts;

import centralfilltests.CheckInAppDBWrapper;
import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import connexus.e2e.testcases.E2E_TestCases;
import fom.datamodels.ssorequests.*;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexusharnessapicontext.apimanager.BeaconServiceManager;
import hwqe.baseframework.connexusharnessapicontext.datamodels.beaconservice.GetStationCounts.GetStationCounts;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Response.FillingGetFillInfoResponse;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.joda.time.DateTime;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.awt.event.KeyEvent;
import java.util.*;
import static connexus.e2e.testcases.E2E_TestCases.loginUser_Type;
import static hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager.scanPickUpCodeForCF;

public class Filling_testscripts extends ConnexusTestScripts {
    public Filling_testscripts(LoginAs.userType loginUserType){
        super(loginUserType);
    }

    ServiceResponse resp;
    PropertyReader prop = PropertyReader.getInstance();
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    AutomationManager am = AutomationManager.getInstance();
    int  patientID,siteId,bagNbr,rxFillId;
    CheckInAppDBWrapper dbwrapper = new CheckInAppDBWrapper();
    ServiceResponse sapsGetFillInforesp;
    FillingGetFillInfoResponse getFillInfoResponse;
    String sapsGetFillInfoURL;
    int secondFillId;
    BeaconServiceManager beaconServiceManager = new BeaconServiceManager();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();

    public void Reportvalidating() {

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            MenuBar menuBar = new MenuBar();
            menuBar.pressKeys(KeyEvent.VK_ALT, KeyEvent.VK_R);
            menuBar.pressKeys(KeyEvent.VK_R);
            menuBar.pressKeys(KeyEvent.VK_B);
            if (patientSearchPage.isBioSimilarRXsearcDisplayed()) {
                patientSearchPage.inputrxnum(rxNbr);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            patientSearchPage.clicksearchbtn();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.showreport();
            if (inputPage.isCancelBtnDisplayed()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                inputPage.clickCancel();
            } else {
                Assert.fail("Report not loaded");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Reportcheck", "Failed", fileName, 10, DateTime.now());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateCyclecount(Map<String, String> inputData) {

        resp = beaconServiceManager.GetStationCounts(prop.getProperty("cnx.store"), inputData.get("station"));
        Reporter.log("API Response Status Code: " + resp.getStatusCode());

        GetStationCounts getStationCountsResponse = resp.getDataResponse(GetStationCounts.class);
        Assert.assertNotNull(getStationCountsResponse.CycleCounts);
        Assert.assertNull(getStationCountsResponse.Filling);
        Assert.assertNull(getStationCountsResponse.RTS);
        Assert.assertNull(getStationCountsResponse.LogCopy);

        String completedCountQuery = "SELECT DISTINCT Count(*) count " + "FROM pharmacy_offering:phm_item_problem pip " + "LEFT JOIN pharmacy_offering:item_count_cycle icc " +
                "ON icc.count_cycle_id = pip.count_cycle_id " + "AND icc.count_complete_date IS NULL " + "WHERE problem_stat_code = 6321 " + "AND count_role_code IN (3000,3010);";
        String pendingCountQuery = "SELECT DISTINCT Count(*) count " + "FROM pharmacy_offering:phm_item_problem pip " + "LEFT JOIN pharmacy_offering:item_count_cycle icc " +
                "ON icc.count_cycle_id = pip.count_cycle_id " + "AND icc.count_complete_date IS NULL " + "WHERE problem_stat_code = 6320 " + "AND count_role_code IN (3000,3010);";
        int siteID = Integer.parseInt(prop.getProperty("cnx.store"));
        int completedCount = am.getConnexusDB(siteID).getScalar(completedCountQuery, Integer.class);
        int pendingCount = am.getConnexusDB(siteID).getScalar(pendingCountQuery, Integer.class);
        // Log the API and DB response values
        Reporter.log("API response for Cycle Completed Count: " + getStationCountsResponse.CycleCounts.getCompletedCount());
        Reporter.log("Completed Count Query: " + completedCountQuery);
        Reporter.log("Completed Count from DB: " + completedCount);
        Reporter.log("API response for Pending Cycle Count: " + getStationCountsResponse.CycleCounts.getPendingCount());
        Reporter.log("Pending Count Query: " + pendingCountQuery);
        Reporter.log("Pending Count from DB: " + pendingCount);
        // Assertions to validate counts
        Assert.assertEquals(getStationCountsResponse.CycleCounts.getCompletedCount(), completedCount, "Completed count mismatch between API and DB");
        Assert.assertEquals(getStationCountsResponse.CycleCounts.getPendingCount(), pendingCount, "Pending count mismatch between API and DB");
    }

    public void validateRTSCount(Map<String, String> inputData) {
        // API call and response handling
        resp = beaconServiceManager.GetStationCounts(prop.getProperty("cnx.store"), inputData.get("station"));
        Reporter.log("API Response Status Code: " + resp.getStatusCode());

        GetStationCounts getStationCountsResponse = resp.getDataResponse(GetStationCounts.class);
        Assert.assertNull(getStationCountsResponse.CycleCounts);
        Assert.assertNull(getStationCountsResponse.Filling);
        Assert.assertNull(getStationCountsResponse.LogCopy);
        Assert.assertNotNull(getStationCountsResponse.RTS);
        // Queries for DB validation
        String completedCountQuery = "SELECT COUNT(*) FROM pharmacy_offering:rts_vial WHERE DATE(create_ts) = DATE(current);";
        String pendingCountQuery = "SELECT COUNT(*) FROM ((SELECT UNIQUE rod.order_id, rod.order_seq_nbr, rf.rx_fill_id, rx1.rx_nbr " + "FROM customer_order co, rx_order_detail rod, rx rx1, rx_fill rf, rx_fill_activity rfa " + "WHERE co.order_id = rod.order_id AND rod.next_work_que_code = 6 AND rod.work_que_stat_code = 20200 " + "AND rod.rx_fill_id = rf.rx_fill_id AND rf.fill_date <= (TODAY - 9 UNITS DAY) " +
                "AND rx1.rx_id = rod.rx_id AND rf.status_code <> 20403 AND rod.status_code in (20501, 20502) " + "AND rod.rx_fill_id = rfa.rx_fill_id AND rfa.activity_seq_nbr = (SELECT MAX(activity_seq_nbr) " + "FROM rx_fill_activity rfa1 WHERE rfa1.activity_code = 1104 AND rfa1.rx_fill_id = rf.rx_fill_id) " +
                "AND co.status_code in (20301, 20302) AND co.order_id NOT IN (SELECT order_id FROM rx_order_detail rod2 " + "WHERE rod.order_id = rod2.order_id AND (rod2.next_work_que_code <> 6 AND rod2.next_work_que_code <> 15) " +
                "AND rod2.work_que_stat_code <> 20202 AND rod2.next_work_que_code IS NOT NULL AND rod2.package_nbr = rod.package_nbr)) " + "UNION " + "(SELECT UNIQUE rod.order_id, rod.order_seq_nbr as orderLineItemId, rf.rx_fill_id, rx1.rx_nbr " +
                "FROM customer_order co, rx_order_detail rod, rx rx1, rx_fill rf, rx_fill_activity rfa, rx_fill_item rfi, " + "pharmacy_offering:pharmacy_product pp, pharmacy_offering:pharmacy_item pi, " +
                "pharmacy_offering:product_gpi_xref pgx, pharmacy_offering:genc_prod_restrict pr " + "WHERE co.order_id = rod.order_id AND rod.next_work_que_code = 6 AND rod.work_que_stat_code = 20200 " +
                "AND rx1.rx_id = rod.rx_id AND rod.rx_fill_id = rf.rx_fill_id AND rf.status_code <> 20403 " + "AND rod.status_code in (20501,20502) AND rfa.rx_fill_id = rf.rx_fill_id " +
                "AND rfa.activity_seq_nbr = (SELECT MAX(activity_seq_nbr) FROM rx_fill_activity rfa1 " + "WHERE rfa1.activity_code = 1104 AND rfa1.rx_fill_id = rf.rx_fill_id) AND co.status_code in (20301, 20302) " +
                "AND rf.rx_fill_id = rfi.rx_fill_id AND rfi.item_seq_nbr = 1 AND rfi.item_mds_fam_id = pi.mds_fam_id " + "AND pgx.product_mds_fam_id = pp.product_mds_fam_id AND pi.product_mds_fam_Id = pp.product_mds_fam_id " + "AND pr.gpi_code = pgx.gpi_code AND rx1.rx_exp_date < TODAY AND pr.restrict_type_code = 980 " +
                "AND pr.restriction_value = 'Y' AND co.order_id NOT IN (SELECT order_id FROM rx_order_detail rod2 " + "WHERE rod.order_id = rod2.order_id AND (rod2.next_work_que_code <> 6 AND rod2.next_work_que_code <> 15) " + "AND rod2.work_que_stat_code <> 20202 AND rod2.next_work_que_code IS NOT NULL AND rod2.package_nbr = rod.package_nbr)));";
        String autoCancelledQuery = "SELECT COUNT(*) FROM (SELECT UNIQUE rod.order_id, rod.order_seq_nbr, rod.rx_fill_id, rx.rx_nbr " +
                "FROM rx_order_detail rod, rx, rx_fill rxf WHERE rod.status_code = 20501 " + "AND rod.next_work_que_code = 26 AND rod.work_que_stat_code = 20200 AND rod.rx_id = rx.rx_id " + "AND rod.rx_fill_id = rxf.rx_fill_id AND rxf.rx_id = rx.rx_id AND rxf.status_code = 20403);";

        int siteID = Integer.parseInt(prop.getProperty("cnx.store"));
        int completedCount = am.getConnexusDB(siteID).getScalar(completedCountQuery, Integer.class);
        int pendingCount = am.getConnexusDB(siteID).getScalar(pendingCountQuery, Integer.class);
        int autoCancelledCount = am.getConnexusDB(siteID).getScalar(autoCancelledQuery, Integer.class);
        int totalPendingCount = pendingCount + autoCancelledCount;
        // Log the API response values
        Reporter.log("API respose for RTS Completed Count: " + getStationCountsResponse.RTS.getCompletedCount());
        Reporter.log("Completed Count Query: " + completedCountQuery);
        Reporter.log("RTS Completed Count from DB: " + completedCount);
        Reporter.log("API response for RTS Pending Count: " + getStationCountsResponse.RTS.getPendingCount());
        Reporter.log("Pending Count Query : " + pendingCountQuery);
        Reporter.log("Auto Cancelled Query: " + autoCancelledQuery);
        Reporter.log("Completed Count from DB: " + completedCount);
        Reporter.log("Count to fetch Rxs eligible for RTS : " + pendingCount);
        Reporter.log("Auto Cancelled Count from DB: " + autoCancelledCount);
        Reporter.log("Total Pending Count from DB: " + totalPendingCount);
        // Assertions for validation
        Assert.assertEquals(completedCount, getStationCountsResponse.RTS.getCompletedCount(), "Mismatch in Completed Count between API and DB");
        Assert.assertEquals(totalPendingCount, getStationCountsResponse.RTS.getPendingCount(), "Mismatch in Pending Count between API and DB");
    }

    public void validateFillingCounts(Map<String, String> inputData) {

        resp = beaconServiceManager.GetStationCounts(prop.getProperty("cnx.store"), inputData.get("station"));
        Reporter.log("API Response Status Code: " + resp.getStatusCode());

        GetStationCounts getStationCountsResponse = resp.getDataResponse(GetStationCounts.class);
        Assert.assertNull(getStationCountsResponse.CycleCounts);
        Assert.assertNull(getStationCountsResponse.RTS);
        Assert.assertNull(getStationCountsResponse.LogCopy);
        Assert.assertNotNull(getStationCountsResponse.Filling);
        // Queries for DB counts
        String completedCountQuery = "SELECT COUNT(*) count " + "FROM rx_fill rf, rx_order_detail rod " + "WHERE rod.rx_fill_id = rf.rx_fill_id " +
                "AND rf.fill_date = DATE(CURRENT) " + "AND rf.tech_of_rec_userid IS NOT NULL " + "AND rf.status_code = 20401 " + "AND rod.sub_que_type_code = 1";

        String pendingCountQuery = "SELECT count(order_id) " + "FROM rx_order_detail " + "WHERE next_work_que_code = 4 " +
                "AND work_que_stat_code = 20200 " + "AND status_code = 20501 " + "AND sub_que_type_code = 1";

        String due30minQuery = "SELECT COUNT(*) " + "FROM rx_order_detail " + "WHERE (work_que_stat_code = 20200 " +
                "OR (work_que_stat_code = 20204 AND retry_ts < CURRENT)) " + "AND assigned_userid IS NULL " +
                "AND status_code = 20501 " + "AND next_work_que_code = 4 " + "AND est_pickup_ts <= (CURRENT + 30 units minute) " + "AND sub_que_type_code = 1";

        String due48hrsQuery = "SELECT COUNT(*) " + "FROM rx_order_detail " + "WHERE (work_que_stat_code = 20200 " + "OR (work_que_stat_code = 20204 AND retry_ts < CURRENT)) " +
                "AND assigned_userid IS NULL " + "AND status_code = 20501 " + "AND next_work_que_code = 4 " + "AND est_pickup_ts <= (CURRENT + 2880 units minute) " + "AND sub_que_type_code = 1";

        String dueFutureQuery = "SELECT COUNT(*) " + "FROM rx_order_detail " + "WHERE (work_que_stat_code = 20200 " + "OR (work_que_stat_code = 20204 AND retry_ts < CURRENT)) " +
                "AND assigned_userid IS NULL " + "AND status_code = 20501 " + "AND next_work_que_code = 4 " + "AND est_pickup_ts > (CURRENT + 120 units minute) " + "AND sub_que_type_code = 1";

        String due2hoursQuery = "SELECT COUNT(*) " + "FROM rx_order_detail " + "WHERE (work_que_stat_code = 20200 " + "OR (work_que_stat_code = 20204 AND retry_ts < CURRENT)) " +
                "AND assigned_userid IS NULL " + "AND status_code = 20501 " + "AND next_work_que_code = 4 " + "AND est_pickup_ts <= (CURRENT + 120 units minute) " + "AND sub_que_type_code = 1";

        // Fetch counts from DB
        int siteID = Integer.parseInt(prop.getProperty("cnx.store"));
        int due30minCount = am.getConnexusDB(siteID).getScalar(due30minQuery, Integer.class);
        int due48hrsCount = am.getConnexusDB(siteID).getScalar(due48hrsQuery, Integer.class);
        int due2hoursCount = am.getConnexusDB(siteID).getScalar(due2hoursQuery, Integer.class);
        int pendingCount = am.getConnexusDB(siteID).getScalar(pendingCountQuery, Integer.class);
        int completedCount = am.getConnexusDB(siteID).getScalar(completedCountQuery, Integer.class);
        int dueFutureCount = am.getConnexusDB(siteID).getScalar(dueFutureQuery, Integer.class);

        // Log the API response values
        Reporter.log("API response for Filling Completed Count: " + getStationCountsResponse.Filling.getCompletedCount());
        Reporter.log("Completed Count Query for filling : " + completedCountQuery);
        Reporter.log("DB Completed Count: " + completedCount);
        Reporter.log("API response for Filling Pending Count: " + getStationCountsResponse.Filling.getPendingCount());
        Reporter.log("Pending Count Query for filling: " + pendingCountQuery);
        Reporter.log("DB Pending Count: " + pendingCount);
        Reporter.log("API response for Filling Due 2 hours Count: " + getStationCountsResponse.Filling.getDue2hours());
        Reporter.log("Due 2 hours Count Query for filling: " + due2hoursQuery);
        Reporter.log("DB Due 2 hours Count: " + due2hoursCount);
        Reporter.log("API response for Filling Due 30min Count: " + getStationCountsResponse.Filling.getDue30mins());
        Reporter.log("Due 30min Count Query for filling: " + due30minQuery);
        Reporter.log("DB Due 30min Count: " + due30minCount);
        Reporter.log(" API response for Filling Due 48hrs Count: " + getStationCountsResponse.Filling.getDue48hours());
        Reporter.log("Due 48hrs Count Query for filling: " + due48hrsQuery);
        Reporter.log("DB Due 48hrs Count: " + due48hrsCount);
        Reporter.log("API response for Filling Due future Count: " + getStationCountsResponse.Filling.getDueFuture());
        Reporter.log("Due Future Count Query for filling: " + dueFutureQuery);
        Reporter.log("DB Due Future Count: " + dueFutureCount);
        // Assert that API and DB counts match for each
        Assert.assertEquals(getStationCountsResponse.Filling.getCompletedCount(), completedCount);
        Assert.assertEquals(getStationCountsResponse.Filling.getPendingCount(), pendingCount);
        Assert.assertEquals(getStationCountsResponse.Filling.getDue2hours(), due2hoursCount);
        Assert.assertEquals(getStationCountsResponse.Filling.getDue30mins(), due30minCount);
        Assert.assertEquals(getStationCountsResponse.Filling.getDue48hours(), due48hrsCount);
        Assert.assertEquals(getStationCountsResponse.Filling.getDueFuture(), dueFutureCount);
    }

    public ServiceResponse performSapsgetFillInfo(String source, String deviceName, int storeId, String orderId,int toteNbr, String userId, String assignedOrd) {

        FillingGetFillInfoSapsRequest sapsGetFillInfo = new FillingGetFillInfoSapsRequest();

        sapsGetFillInfo.setSource(source);
        sapsGetFillInfo.setDeviceName(deviceName);
        sapsGetFillInfo.setStoreId(storeId);
        sapsGetFillInfo.setOrderId(orderId);
        sapsGetFillInfo.setToteNbr(toteNbr);
        sapsGetFillInfo.setUserId(userId);
        sapsGetFillInfo.setAssignedOrd(assignedOrd);

        req.setRequestPayloadWithNulls(sapsGetFillInfo);
        sapsGetFillInfoURL =  StoreIDManager.createEndPointURL(prop.getProperty("cnx.store"), prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.GetWorkForFill"));
        req.setUrl(sapsGetFillInfoURL);
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        Reporter.log("getFillInfo endpoint: " + req.getUrl());
        Reporter.logJSON("getFillInfo Request", sapsGetFillInfo);
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("getFillInfo Response", resp.getDataResponse());
        return resp;
    }

    public ServiceResponse setFillInfo(String orderId, int storeNbr, String deviceId, String techUserId, int bagNbr, String labelMac, String reprintInd,
                                       ArrayList<FillingOrderLineInfoContents> orderLineInfo) {

        FillingSetFillInfoRequest sapsSetFillInfo = new FillingSetFillInfoRequest();
        sapsSetFillInfo.setOrderId(orderId);
        sapsSetFillInfo.setGroupingId(null);
        sapsSetFillInfo.setStoreNbr(storeNbr);
        sapsSetFillInfo.setDeviceId(deviceId);
        sapsSetFillInfo.setTechUserId(techUserId);
        sapsSetFillInfo.setBagNbr(bagNbr);
        sapsSetFillInfo.setLabelMac(labelMac);
        sapsSetFillInfo.setReprintInd(reprintInd);
        sapsSetFillInfo.setOrderLineInfo(orderLineInfo);
        req.setRequestPayloadWithNulls(sapsSetFillInfo);
        String serviceEndPointUrl = StoreIDManager.createEndPointURL(String.valueOf(storeNbr), prop.getProperty("fom.connexusWrapper.portNo"), prop.getProperty("fom.connexusWrapper.sapsUrl"), prop.getProperty("fom.connexusWrapper.setfill"));
        req.setUrl(serviceEndPointUrl);
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        Reporter.log("setFillInfo endpoint: " + req.getUrl());
        Reporter.logJSON("setFillInfo Request", sapsSetFillInfo);
        Log.info("setFillInfo RequestPayload:\n" + req.getRequestPayload());
        resp = am.getRestContext().performPost(req, 3);
        Reporter.logJSON("setFillInfo Response", resp.getDataResponse());
        return resp;
    }

    public Map<String, Object> getRxOrderDetailsFromPatientId(int siteId, String patientId,int nextWorkQueCode){
        return am.getConnexusDB(siteId).executeQuery("select * from informix.rx_order_detail where next_work_que_code=" +nextWorkQueCode+ " and rx_id in (select rx_id from rx where patient_id=" + patientId +");");
    }

    public ServiceResponse getFillInfo(String source, String deviceName, int storeId, String orderId, int toteNbr, String userId, String assignedOrd) {

        FillingGetFillInfoRequest getFillInfoRequest = new FillingGetFillInfoRequest();
        getFillInfoRequest.setSource(source);
        getFillInfoRequest.setDeviceName(deviceName);
        getFillInfoRequest.setStoreId(storeId);
        getFillInfoRequest.setOrderId(orderId);
        getFillInfoRequest.setToteNbr(toteNbr);
        getFillInfoRequest.setUserId(userId);
        getFillInfoRequest.setAssignedOrd(assignedOrd);
        req.setRequestPayloadWithNulls(getFillInfoRequest);
        String serviceEndPointUrl = StoreIDManager.createEndPointURL(String.valueOf(storeId), prop.getProperty("fom.connexusWrapper.portNo"), prop.getProperty("fom.connexusWrapper.sapsUrl"), prop.getProperty("fom.connexusWrapper.getfill"));
        req.setUrl(serviceEndPointUrl);
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        Reporter.log("getFillInfo endpoint: " + req.getUrl());
        Reporter.logJSON("getFillInfo Request", getFillInfoRequest);
        Log.info("getFillInfo RequestPayload:\n" + req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("getFillInfo Response", resp.getDataResponse());
        Log.info("getFillInfo ResponsePayload:\n" + resp.getDataResponse());
        return resp;
    }

    public void getWorkForFill(int StoreNbr, int bagNbr, int orderId){
        am.getConnexusDB(StoreNbr).executeUpdateQuery("update rx_order_detail set tote_Nbr="+bagNbr+" where order_id="+orderId);
        am.getConnexusDB(StoreNbr).executeUpdateQuery("update rx_order_detail set assigned_userid='WALMART20' where order_id="+orderId);
        am.getConnexusDB(StoreNbr).executeUpdateQuery("update rx_order_detail set wrkstatn_host_name='MACADDRESS' where order_id="+orderId);
    }

    //Method for doing Cancel fill using set fill Api

    public void verifyGetSetFillInfocancelled(int StoreNbr, int problemCodeForCancelFill, boolean isRTSVialUsed) {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        bagNbr = dbwrapper.getToteNumber(StoreNbr);
        System.out.println(bagNbr);
        patientID = Integer.parseInt(connexusAppUtils.getPatientId(name[0],name[1]));
        Map<String, Object> getRxOrderDetailsFromPatient;
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        getRxOrderDetailsFromPatient = getRxOrderDetailsFromPatientId(siteId, String.valueOf(patientID),WorkQueueCode.FILLING.getWorkQueueCode());
        rxFillId = (Integer) getRxOrderDetailsFromPatient.get("rx_fill_id");
        System.out.println(rxFillId);
        int orderId = (Integer) getRxOrderDetailsFromPatient.get("order_id");
        System.out.println(orderId);
        getWorkForFill(StoreNbr, bagNbr, orderId);
        sapsGetFillInforesp =  performSapsgetFillInfo(prop.getProperty("fom.setSource"), prop.getProperty("fom.setDeviceName"),
                siteId, String.valueOf(orderId), bagNbr, prop.getProperty("fom.newuserId"),prop.getProperty("fom.assignedOrd"));
        Assert.assertEquals(sapsGetFillInforesp.getStatusCode(), 200, "GetFillInfo Saps service response did not match");
        Reporter.log("getFillInfo API is logged with status code:200 ");
        getFillInfoResponse = sapsGetFillInforesp.getDataResponse(FillingGetFillInfoResponse.class);
        connexusAPIManager.validateSetFillInfoAPIForCancelled(StoreNbr,getFillInfoResponse,problemCodeForCancelFill,isRTSVialUsed);
    }


    //Method to create partial fill after using cancel Api when the resolution shows Drug out of stock

    public void Doosresolution(Map<String, String> inputData) {

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(name[0] + "," + name[1]);
        String problem = orderSearch.getdoosresolve(name[0] + "," + name[1],0);
        Assert.assertEquals(problem,"Drug - Out of Stock");
        Reporter.log("rx is in Doos Resolution");
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(name[0] + "," + name[1]);
        patientSearchPage.openFirstPatientRecord();
        resolutionPage.clickPartialFill();
        Assert.assertTrue(resolutionPage.isInputPartialDisplayed());
        resolutionPage.inputpartialdays(Integer.parseInt(inputData.get("partialdays")));
        resolutionPage.onHandQuantity(Integer.parseInt(inputData.get("handqty")));
        resolutionPage.clickAccept();
        resolutionPage.clickAdjreason();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        resolutionPage.clickContinue();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("partial fill not created", "Failed", "E2E_execution_status.txt", 40, DateTime.now());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed while creating partial fill");
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyGetSetFillInfoSubmitted(List<Integer> problemCodeStatus){
        String[] name = connexusAppUtils.readPatientNameFromFile();
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        bagNbr = dbwrapper.getToteNumber(siteId);
        System.out.println(bagNbr);
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        patientID = Integer.parseInt(connexusAppUtils.getPatientId(name[0],name[1]));
        Map<String, Object> getRxOrderDetailsFromPatient = getRxOrderDetailsFromPatientId(siteId, String.valueOf(patientID), WorkQueueCode.FILLING.getWorkQueueCode());
        if (getRxOrderDetailsFromPatient == null) {
            throw new AssertionError("No RX order details found for patientId: " + patientID + " in FILLING queue.");
        }
        secondFillId = (Integer) getRxOrderDetailsFromPatient.get("rx_fill_id");
        System.out.println(secondFillId);
        int orderId = (Integer) getRxOrderDetailsFromPatient.get("order_id");
        System.out.println(orderId);
        am.getConnexusDB(siteId).executeUpdateQuery("update rx_order_detail set tote_nbr = " + bagNbr + "," +
                " wrkstatn_host_name = 'MACADDRESS', assigned_userid = 'WALMART20' where rx_fill_id in (" + secondFillId + ")");

        sapsGetFillInforesp = performSapsgetFillInfo(prop.getProperty("fom.setSource"), prop.getProperty("fom.setDeviceName"),
                siteId, String.valueOf(orderId), bagNbr, prop.getProperty("fom.newuserId"),prop.getProperty("fom.assignedOrd"));
        Assert.assertEquals(sapsGetFillInforesp.getStatusCode(), 200, "GetFillInfo Saps service response did not match");
        getFillInfoResponse = sapsGetFillInforesp.getDataResponse(FillingGetFillInfoResponse.class);
        Reporter.log("getFillInfo API is logged with status code:200");
        connexusAPIManager.validateSetFillInfoForDelayReasons(siteId,getFillInfoResponse,problemCodeStatus);
    }

    public void submitted (){
        this.verifyGetSetFillInfoSubmitted(Collections.singletonList(200));
    }

    public void performCounsel() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();

        String rxStatus0 = orderSearch.getRXStatusForPatient(rxNbr, 0);
        String rxStatus1 = orderSearch.getRXStatusForPatient(rxNbr, 1);

        if (rxStatus0.equalsIgnoreCase(WorkQueue.COUNSEL.getWorkQueue())
                || rxStatus1.equalsIgnoreCase(WorkQueue.COUNSEL.getWorkQueue())) {

            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);

            if (rxStatus0.equalsIgnoreCase(WorkQueue.COUNSEL.getWorkQueue())) {
                patientSearchPage.openFirstPatientRecord();
            } else {
                orderSearch.openSecondPatientRecord();
            }

            counselPage.acceptAll();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    counselPage.takeScreenShot(currentStepMethodName).getValue());
            counselPage.clickAccept();
            Reporter.log("Counsel Completed");
        } else {
            Assert.fail("Failed to complete counselling");
        }
    }

    public void performPos() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus0 = orderSearch.getRXStatusForPatient(rxNbr, 0);
            String rxStatus1 = orderSearch.getRXStatusForPatient(rxNbr, 1);

            if (rxStatus0.equalsIgnoreCase(WorkQueue.POS.getWorkQueue())
                    || rxStatus1.equalsIgnoreCase(WorkQueue.POS.getWorkQueue())) {

                automationManager.getConnexusWorkFlow().completeOfflineSale(rxNbr);
                connexusAppUtils.writeTextToFile("POS Completed " + rxNbr, "Passed",
                        "E2E_execution_status.txt", 100, DateTime.now());
            } else {
                Reporter.log("RX is not in POS queue");
                Assert.fail("RX is not in POS queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("POS Not Completed " + rxNbr, "Failed", "E2E_execution_status.txt", 100, DateTime.now());
            Reporter.log("Test failed at POS queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void performVv() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus0 = orderSearch.getRXStatusForPatient(rxNbr, 0);
            String rxStatus1 = orderSearch.getRXStatusForPatient(rxNbr, 1);

            if (rxStatus0.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())
                   || rxStatus1.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                if (rxStatus0.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
                    patientSearchPage.openFirstPatientRecord();
                } else {
                    orderSearch.openSecondPatientRecord();
                }
                visVerPage.handleIHaveOrderPopUp();
                visVerPage.clickCancelButtonOnPopUp();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
                visVerPage.clickAccept();
                visVerPage.clickOk();
                visVerPage.clickOkButton();
                connexusAppUtils.writeTextToFile("Visual Verification Completed " + rxNbr, "In progress", "E2E_execution_status.txt", 70, DateTime.now());
            } else {
                Reporter.log("RX is not in Visual Verify queue");
                Assert.fail("RX is not in Visual Verify queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Visual Verification Not Completed " + rxNbr, "Failed", "E2E_execution_status.txt", 70, DateTime.now());
            Reporter.log("Test failed at Visual Verify queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public String getFillId(String rxNbr) {
        String fillId = null;
        try {
            String query = "select max(rx_fill_id) as rx_fill_id  from  rx_order_detail where rx_id =(select rx_id from rx where rx_nbr=\"" + rxNbr + "\") and next_work_que_code ='6'";
            Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
            fillId = rxInfo.get("rx_fill_id").toString();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return fillId;
    }

    public void performPickup(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String rxStatus0 = orderSearch.getRXStatusForPatient(rxNbr, 0);
        String rxStatus1 = orderSearch.getRXStatusForPatient(rxNbr, 1);

        if (rxStatus0.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())
                || rxStatus1.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())) {
            tascoPage.launchTascoScreen();
            tascoPage.inputPatientLastName(name[0]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(name[1]);
            tascoPage.pressTabKey();
            tascoPage.inputPatientDob(inputData.get("DOB"));
            tascoPage.pressTabKey();
            tascoPage.pressTabKey();
            tascoPage.clickSearchOnTascoPage();
            tascoPage.clickRow(0);
            tascoPage.medicarevalidationpopup();
            tascoPage.continueCheckout();
            tascoPage.handleOtherOrdersAvailablePopUp();

            tascoPage.clickCheckout();
            tascoPage.handleConnexusCheckoutCashPayPopup();

            tascoPage.handleConnexusCheckoutEasyPayPopup();
            tascoPage.handlePatientCentralDataUpdatePayPopup();
            tascoPage.clickBtnOK();
            String fillId = getFillId(rxNbr);
            String siteId = prop.getProperty("cnx.store");
            Log.info(fillId);
            if (tascoPage.isToteNbrDisplayed()) {
                if (siteId.length() == 4) {
                    tascoPage.scanRx("0" + siteId + "00" + rxNbr + "0000");
                } else {
                    tascoPage.scanRx(siteId + "00" + rxNbr + "0000");
                }
            } else if (tascoPage.isTxtCounselCommentsDisplayed()) {
                tascoPage.scanRx("4793" + fillId + "0");
            }
            tascoPage.clickBtnNo();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.handleDoYouHaveAnyQuestionsToTheDoctorPopup();
            tascoPage.clickAcceptCheckout();
            tascoPage.clickOk();
            if (tascoPage.clickPatientRefused()) {
                tascoPage.clickOk();
            } else {
                tascoPage.clickCancel();
            }
            tascoPage.handleCheckoutPopUpForTp();
            tascoPage.clickSignOff();
            Reporter.log("pickup Completed");
        }else{
            isExceptionCaptured = true;
            Reporter.log("Rx is not in pickup");
        }
    }

    public void classicFilling(List<Integer> problemCodeStatus,int patID){

        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        bagNbr = dbwrapper.getToteNumber(siteId);

        Map<String, Object> getRxOrderDetailsFromPatient = getRxOrderDetailsFromPatientId(siteId, String.valueOf(patID), WorkQueueCode.FILLING.getWorkQueueCode());
        if (getRxOrderDetailsFromPatient == null) {
            throw new AssertionError("No RX order details found for patientId: " + patID + " in FILLING queue.");
        }
        secondFillId = (Integer) getRxOrderDetailsFromPatient.get("rx_fill_id");
        System.out.println(secondFillId);
        int orderId = (Integer) getRxOrderDetailsFromPatient.get("order_id");
        System.out.println(orderId);
        am.getConnexusDB(siteId).executeUpdateQuery("update rx_order_detail set tote_nbr = " + bagNbr + "," +
                " wrkstatn_host_name = 'MACADDRESS', assigned_userid = 'WALMART20' where rx_fill_id in (" + secondFillId + ")");
        sapsGetFillInforesp = performSapsgetFillInfo(prop.getProperty("fom.setSource"), prop.getProperty("fom.setDeviceName"),
                siteId, String.valueOf(orderId), bagNbr, prop.getProperty("fom.newuserId"),prop.getProperty("fom.assignedOrd"));
        Assert.assertEquals(sapsGetFillInforesp.getStatusCode(), 200, "GetFillInfo Saps service response did not match");
        getFillInfoResponse = sapsGetFillInforesp.getDataResponse(FillingGetFillInfoResponse.class);
        Reporter.log("getFillInfo API is logged with status code:200");
        connexusAPIManager.validateSetFillInfoForDelayReasons(siteId,getFillInfoResponse,problemCodeStatus);
    }
}
