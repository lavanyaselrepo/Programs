package connexus.Filling.testcases;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.informix.jdbc.IfxBSONObject;
import fom.FomAPIWrapper;
import fom.datamodels.ssoresponse.FOMSapsGetRTSListResponse;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.List;
import java.util.Map;

import static java.lang.Integer.parseInt;

public class RTSFlowsTestSet {
    AutomationManager am = AutomationManager.getInstance();
    ConnexusAppUtils connexusAppUtils;
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    PropertyReader prop = PropertyReader.getInstance();
    FomAPIWrapper api = new FomAPIWrapper();
    boolean isFlagUpdated = false;

    @BeforeClass
    public void performlogin() {
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        Reporter.log("Tearing down the test environment");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * Test Description:RTS | Verify inventory is adjusted in pharmacy_item table when setRTSInfo API is hit with eligible RTS order and isReprint: N
     * JIRA: HWPHME2E-618

     * Author: Sweety Saxena
     * ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "Test Description:RTS | Verify inventory is adjusted in pharmacy_item table when setRTSInfo API is hit with eligible RTS order and isReprint: N",priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/FomData/RTSdata.json", sheetName = "RTSFlows")
    public void HWPHME2E_618(Map<String, String> inputData) {

        connexusAppUtils.getStoreId();
        int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        // Set the flag to True
        isFlagUpdated = connexusAppUtils.readAndUpdateFlag("17315", "TRUE");
        if (isFlagUpdated){
            connexusAPIManager.restartConnexusService(prop.getProperty("cnx.store"));
        }

        // Call the getRTSList API
        ServiceResponse sapsGetRTSListResp = api.performSapsGetRTSList(siteId, "MACADDRESS", "RTSApp", "WALMART20");

        Assert.assertEquals(sapsGetRTSListResp.getStatusCode(), 200, "GetRTSList Saps service response did not match");
        FOMSapsGetRTSListResponse sapsGetRTSListResponse = sapsGetRTSListResp.getDataResponse(FOMSapsGetRTSListResponse.class);

        int orderId = Integer.parseInt(sapsGetRTSListResponse.getRtsList().get(0).getOrderId());
        int itemQty = sapsGetRTSListResponse.getRtsList().get(0).getOrderInfo().get(0).getFillInfo().get(0).getFillItems().get(0).getItemQty();
        int fillId = Integer.parseInt(sapsGetRTSListResponse.getRtsList().get(0).getOrderInfo().get(0).getFillInfo().get(0).getFillId());
        int mdsfamId = sapsGetRTSListResponse.getRtsList().get(0).getOrderInfo().get(0).getFillInfo().get(0).getFillItems().get(0).getMdsfamid();
        int orderLineItemId = Integer.parseInt(sapsGetRTSListResponse.getRtsList().get(0).getOrderInfo().get(0).getFillInfo().get(0).getOrderLineItemId());
        Reporter.log("OrderId selected from rtslist is" +orderId);
        Reporter.log("Mdsfamid for selected order is" +mdsfamId);
        Reporter.log("Item quantity for selected order is" +itemQty);

        int onHandQty = am.getConnexusDB(siteId).getScalar("Select on_hand_qty from pharmacy_offering:pharmacy_item where mds_fam_id = " + mdsfamId,Integer.class);

        // Extract the value from the result
        Reporter.log("OnHand Quantity after Get query is " + onHandQty);

        ServiceResponse postApiResponse = api.performSapsSetRTSInfo(siteId, orderId, orderLineItemId, fillId, "RTNSTOCK", "WINDOWS", "N", "Y",
                "N", "RTSApp", "WALMART20");

        Assert.assertEquals(postApiResponse.getStatusCode(), 206, "Post API response status code is incorrect");

        // Adding the fill qty of the fill that is returned to stock
        int expOnHandQty = onHandQty + itemQty;
        Reporter.log("Expected onHand quantity post SET request should be" + expOnHandQty);

        int onHandQtyAfter = am.getConnexusDB(siteId).getScalar("Select on_hand_qty from pharmacy_offering:pharmacy_item where mds_fam_id = " + mdsfamId,Integer.class);
        Reporter.log("OnHand Quantity After POST is " + onHandQtyAfter);

        // Extract the value from the result after executing setRTS

        Assert.assertEquals(expOnHandQty, onHandQtyAfter, "on_hand_qty updated with fill qty as expected");
        Reporter.log("onHandQty after SET got updated as expected");

        List<Map<String, Object>> finalValidation = am.getConnexusDB(siteId).executeQueryForList("select * from  rxone_trans where trans_type = 105 and order_id = " +orderId);

        IfxBSONObject req_json = (IfxBSONObject) finalValidation.get(0).get("req_json");
        IfxBSONObject resp_json = (IfxBSONObject) finalValidation.get(0).get("resp_json");
        short trans_type = (short) finalValidation.get(0).get("trans_type");

        Assert.assertNotNull(req_json,"Req json is null");
        Reporter.log("req_json is not null for order id "+orderId);
        Assert.assertNotNull(resp_json,"Response json is null");
        Reporter.log("resp_json is not null for order id "+orderId);
        Assert.assertEquals(trans_type, 105,"Trans type is not 105 as expected");
        Reporter.log("Trans_type is 105 as expected for order id "+orderId);
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * RTS | Verify inventory is not adjusted in pharmacy_item table when setRTSInfo API is hit with eligible RTS order and isReprint: Y
     * JIRA: HWPHME2E-619

     * Author: Sweety Saxena
     * ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "Verify inventory is not adjusted in pharmacy_item table when setRTSInfo API is hit with eligible RTS order and isReprint: Y",priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/FomData/RTSdata.json", sheetName = "RTSFlows")
    public void HWPHME2E_619(Map<String, String> inputData) {

        connexusAppUtils.getStoreId();
        int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        // Set the flag to True
        isFlagUpdated = connexusAppUtils.readAndUpdateFlag("17315", "TRUE");
        if (isFlagUpdated){
            connexusAPIManager.restartConnexusService(prop.getProperty("cnx.store"));
        }

        // Call the getRTSList API
        ServiceResponse sapsGetRTSListResp = api.performSapsGetRTSList(siteId, "MACADDRESS", "RTSApp", "WALMART20");

        Assert.assertEquals(sapsGetRTSListResp.getStatusCode(), 200, "GetRTSList Saps service response did not match");
        FOMSapsGetRTSListResponse sapsGetRTSListResponse = sapsGetRTSListResp.getDataResponse(FOMSapsGetRTSListResponse.class);

        int orderId = Integer.parseInt(sapsGetRTSListResponse.getRtsList().get(0).getOrderId());
        int itemQty = sapsGetRTSListResponse.getRtsList().get(0).getOrderInfo().get(0).getFillInfo().get(0).getFillItems().get(0).getItemQty();
        int fillId = Integer.parseInt(sapsGetRTSListResponse.getRtsList().get(0).getOrderInfo().get(0).getFillInfo().get(0).getFillId());
        int mdsfamId = sapsGetRTSListResponse.getRtsList().get(0).getOrderInfo().get(0).getFillInfo().get(0).getFillItems().get(0).getMdsfamid();
        int orderLineItemId = Integer.parseInt(sapsGetRTSListResponse.getRtsList().get(0).getOrderInfo().get(0).getFillInfo().get(0).getOrderLineItemId());

        Reporter.log("OrderId selected from rtslist is" +orderId);
        Reporter.log("Mdsfamid for selected order is" +mdsfamId);
        Reporter.log("Item quantity for selected order is" +itemQty);
        int onHandQty = am.getConnexusDB(siteId).getScalar("Select on_hand_qty from pharmacy_offering:pharmacy_item where mds_fam_id = " + mdsfamId,Integer.class);

        // Extract the value from the result
        Reporter.log("OnHand Quantity after Get query is " + onHandQty);

        ServiceResponse postApiResponse = api.performSapsSetRTSInfo(siteId, orderId, orderLineItemId, fillId, "RTNSTOCK", "WINDOWS", "N", "Y",
                "Y", "RTSApp", "WALMART20");

        Assert.assertEquals(postApiResponse.getStatusCode(), 206, "Post API response status code is incorrect");

        int onHandQtyAfter = am.getConnexusDB(siteId).getScalar("Select on_hand_qty from pharmacy_offering:pharmacy_item where mds_fam_id = " + mdsfamId,Integer.class);
        Reporter.log("OnHand Quantity After POST is " + onHandQtyAfter);

        // Extract the value from the result after executing setRTS

        Assert.assertEquals(onHandQty, onHandQtyAfter, "on_hand_qty without fill qty as expected");
        Reporter.log("onHandQty before and after SET request are same as expected");

        List<Map<String, Object>> finalValidation = am.getConnexusDB(siteId).executeQueryForList("select * from  rxone_trans where trans_type = 105 and order_id = " +orderId);

        IfxBSONObject req_json = (IfxBSONObject) finalValidation.get(0).get("req_json");
        IfxBSONObject resp_json = (IfxBSONObject) finalValidation.get(0).get("resp_json");
        short trans_type = (short) finalValidation.get(0).get("trans_type");

        Assert.assertNotNull(req_json,"Req json is null");
        Reporter.log("req_json is not null for order id "+orderId);
        Assert.assertNotNull(resp_json,"Response json is null");
        Reporter.log("resp_json is not null for order id "+orderId);
        Assert.assertEquals(trans_type, 105,"Trans type is not 105 as expected");
        Reporter.log("Trans_type is 105 as expected for order id "+orderId);
    }
/**
     * ----------------------------------------------------------------------------------------------------------
     * Test Description:RTS | Verify inventory is adjusted in pharmacy_item table when setRTSInfo API is hit with eligible RTS order and isReprint: N
     * JIRA: HWPHME2E-620

     * Author: Sweety Saxena
     * ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify inventory is adjusted in pharmacy_item table",priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/FomData/RTSdata.json", sheetName = "RTSFlows")
    public void HWPHME2E_620(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        int siteId = parseInt(prop.getProperty("cnx.store"));
        // Set the flag to True
        isFlagUpdated = connexusAppUtils.readAndUpdateFlag("17315", "TRUE");
        if (isFlagUpdated){
            connexusAPIManager.restartConnexusService(prop.getProperty("cnx.store"));
        }
        // Call the getRTSList API
        ServiceResponse sapsGetRTSListResp = api.performSapsGetRTSList(siteId, "MACADDRESS", "RTSApp", "WALMART20");
        Assert.assertEquals(sapsGetRTSListResp.getStatusCode(), 200, "GetRTSList Saps service response did not match");
        Gson gson = new Gson();
        JsonObject sapsGetRTSListResponse = gson.fromJson(sapsGetRTSListResp.getDataResponse(), JsonObject.class);

        JsonArray wcbList = sapsGetRTSListResponse.get("wcbreconList").getAsJsonArray();
        if(wcbList.size() == 0) {
            Assert.fail("there are no orders eligible for autocancel");
        }
        JsonObject wcbFirstOrder = wcbList.get(0).getAsJsonObject();
        int OrderId = wcbFirstOrder.get("orderId").getAsInt();

        JsonArray OrderInfo = wcbFirstOrder.get("orderInfo").getAsJsonArray();
        JsonArray fillInfo = OrderInfo.get(0).getAsJsonObject().get("fillInfo").getAsJsonArray();
        JsonArray fillItems = fillInfo.get(0).getAsJsonObject().get("fillItems").getAsJsonArray();
        int itemQty = fillItems.get(0).getAsJsonObject().get("itemQty").getAsInt();
        int fillId = fillInfo.get(0).getAsJsonObject().get("fillId").getAsInt();
        int mdsfamId = fillItems.get(0).getAsJsonObject().get("mdsfamid").getAsInt();
        int orderLineItemId = fillInfo.get(0).getAsJsonObject().get("orderLineItemId").getAsInt();
        Reporter.log("OrderId selected from WcbreconList is" +OrderId);
        Reporter.log("Mdsfamid for selected order is" +mdsfamId);
        Reporter.log("Item quantity for selected order is" +itemQty);
        int onHandQty = am.getConnexusDB(siteId).getScalar("Select on_hand_qty from pharmacy_offering:pharmacy_item where mds_fam_id = " + mdsfamId,Integer.class);
        // Extract the value from the result
        Reporter.log("OnHand Quantity after Get query is " + onHandQty);
        ServiceResponse postApiResponse = api.performSapsSetRTSInfo(siteId, OrderId, orderLineItemId, fillId, "AUTOCANCEL", "WINDOWS", "N", "Y",
                "N", "RTSApp", "WALMART20");
        Assert.assertEquals(postApiResponse.getStatusCode(), 206, "Post API response status code is incorrect");
        // Adding the fill qty of the fill that is returned to stock
        int expOnHandQty = onHandQty + itemQty;
        Reporter.log("Expected onHand quantity post SET request should be" + expOnHandQty);
        int onHandQtyAfter = am.getConnexusDB(siteId).getScalar("Select on_hand_qty from pharmacy_offering:pharmacy_item where mds_fam_id = " + mdsfamId,Integer.class);
        Reporter.log("OnHand Quantity After POST is " + onHandQtyAfter);
        // Extract the value from the result after executing setRTS
        Assert.assertEquals(expOnHandQty, onHandQtyAfter, "on_hand_qty updated with fill qty as expected");
        List<Map<String, Object>> finalValidation = am.getConnexusDB(siteId).executeQueryForList("select * from  rxone_trans where trans_type = 105 and order_id = " +OrderId);
        IfxBSONObject req_json = (IfxBSONObject) finalValidation.get(0).get("req_json");
        IfxBSONObject resp_json = (IfxBSONObject) finalValidation.get(0).get("resp_json");
        short trans_type = (short) finalValidation.get(0).get("trans_type");
        Assert.assertNotNull(req_json,"Req json is null");
        Reporter.log("req_json is not null for order id "+OrderId);
        Assert.assertNotNull(resp_json,"Response json is null");
        Reporter.log("resp_json is not null for order id "+OrderId);
        Assert.assertEquals(trans_type, 105,"Trans type is not 105 as expected");
        Reporter.log("Trans_type is 105 as expected for order id "+OrderId);
    }
    /*
     * ----------------------------------------------------------------------------------------------------------
     * Test Description:RTS | Verify inventory is adjusted in pharmacy_item table when setRTSInfo API is hit with eligible RTS order and isReprint: N
     * JIRA: HWPHME2E-621

     * Author: Sweety Saxena
     * ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify inventory is adjusted in pharmacy_item table",priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/FomData/RTSdata.json", sheetName = "RTSFlows")
    public void HWPHME2E_621(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        // Set the flag to True
        isFlagUpdated = connexusAppUtils.readAndUpdateFlag("17315", "TRUE");
        if (isFlagUpdated){
            connexusAPIManager.restartConnexusService(prop.getProperty("cnx.store"));
        }
        // Call the getRTSList API
        ServiceResponse sapsGetRTSListResp = api.performSapsGetRTSList(siteId, "MACADDRESS", "RTSApp", "WALMART20");
        Assert.assertEquals(sapsGetRTSListResp.getStatusCode(), 200, "GetRTSList Saps service response did not match");

        Gson gson = new Gson();
        JsonObject sapsGetRTSListResponse = gson.fromJson(sapsGetRTSListResp.getDataResponse(), JsonObject.class);

        JsonArray wcbList = sapsGetRTSListResponse.get("wcbreconList").getAsJsonArray();
        if(wcbList.size() == 0) {
            Assert.fail("there are no orders eligible for autocancel");
        }
        JsonObject wcbFirstOrder = wcbList.get(0).getAsJsonObject();
        int OrderId = wcbFirstOrder.get("orderId").getAsInt();

        JsonArray OrderInfo = wcbFirstOrder.get("orderInfo").getAsJsonArray();
        JsonArray fillInfo = OrderInfo.get(0).getAsJsonObject().get("fillInfo").getAsJsonArray();
        JsonArray fillItems = fillInfo.get(0).getAsJsonObject().get("fillItems").getAsJsonArray();
        int itemQty = fillItems.get(0).getAsJsonObject().get("itemQty").getAsInt();
        int fillId = fillInfo.get(0).getAsJsonObject().get("fillId").getAsInt();
        int mdsfamId = fillItems.get(0).getAsJsonObject().get("mdsfamid").getAsInt();
        int orderLineItemId = fillInfo.get(0).getAsJsonObject().get("orderLineItemId").getAsInt();
        Reporter.log("OrderId selected from WcbreconList is" +OrderId);
        Reporter.log("Mdsfamid for selected order is" +mdsfamId);
        Reporter.log("Item quantity for selected order is" +itemQty);
        int onHandQty = am.getConnexusDB(siteId).getScalar("Select on_hand_qty from pharmacy_offering:pharmacy_item where mds_fam_id = " + mdsfamId,Integer.class);
        // Extract the value from the result
        Reporter.log("OnHand Quantity after Get query is " + onHandQty);
        ServiceResponse postApiResponse = api.performSapsSetRTSInfo(siteId, OrderId, orderLineItemId, fillId, "AUTOCANCEL", "WINDOWS", "N", "Y",
                "Y", "RTSApp", "WALMART20");
        Assert.assertEquals(postApiResponse.getStatusCode(), 206, "Post API response status code is incorrect");
        // The fill qty of the fill that is returned to stock

        int onHandQtyAfter = am.getConnexusDB(siteId).getScalar("Select on_hand_qty from pharmacy_offering:pharmacy_item where mds_fam_id = " + mdsfamId,Integer.class);
        Reporter.log("OnHand Quantity After POST is " + onHandQtyAfter);
        // Extract the value from the result after executing setRTS
        Assert.assertEquals(onHandQty, onHandQtyAfter, "on_hand_qty as expected");
        List<Map<String, Object>> finalValidation = am.getConnexusDB(siteId).executeQueryForList("select * from  rxone_trans where trans_type = 105 and order_id = " +OrderId);
        IfxBSONObject req_json = (IfxBSONObject) finalValidation.get(0).get("req_json");
        IfxBSONObject resp_json = (IfxBSONObject) finalValidation.get(0).get("resp_json");
        short trans_type = (short) finalValidation.get(0).get("trans_type");
        Assert.assertNotNull(req_json,"Req json is null");
        Reporter.log("req_json is not null for order id "+OrderId);
        Assert.assertNotNull(resp_json,"Response json is null");
        Reporter.log("resp_json is not null for order id "+OrderId);
        Assert.assertEquals(trans_type, 105,"Trans type is not 105 as expected");
        Reporter.log("Trans_type is 105 as expected for order id "+OrderId);
    }

}