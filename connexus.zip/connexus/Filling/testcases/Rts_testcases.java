package connexus.Filling.testcases;

import connexus.Filling.testscripts.Rts_testscripts;
import connexus.easyPay.testscripts.easyPayViaCPC.EasyPayPaymentProcessingTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class Rts_testcases {

    Rts_testscripts rtsTestscripts = new Rts_testscripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();

    /*----------------------------------------------------------------------------------------------------------
           * Test Description:RTS | Verify getRTSInfo API returns 406 if bagNbr provided is not in range
           *
           * Author: snehaa(vn57hhm)
           ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "RTS | Verify getRTSInfo API returns 406 if bagNbr provided is not in range",
            priority =4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOM/RTS.json", sheetName = "rts")
    public void HWPHME2E_614(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        rtsTestscripts.RTSresponse(inputData);
    }

     /*----------------------------------------------------------------------------------------------------------
           * Test Description: Verify getRTSInfo API returns valid details of RTS associated bag provided in url
           *
           * Author: snehaa(vn57hhm)
           ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = " Verify getRTSInfo API returns valid details of RTS associated bag provided in url",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOM/RTS.json", sheetName = "rts")
    public void HWPHME2E_612(Map<String, String> inputData)  {
        connexusAppUtils.updateFlagValue("17315","TRUE");
        connexusAppUtils.getStoreId();
        rtsTestscripts.validateRTSServices(Integer.parseInt(inputData.get("fillcount")), Integer.parseInt(inputData.get("daysinpickup")), Boolean.parseBoolean(inputData.get("rtsvalisation")), Integer.parseInt(inputData.get("response")));
    }

     /*----------------------------------------------------------------------------------------------------------
           * Test Description: Verify getRTSList response only shows RTS if fill is past the days count mentioned in Parm code 5384
           *
           * Author: snehaa(vn57hhm)
           ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = " Verify getRTSList response only shows RTS if fill is past the days count mentioned in Parm code 5384",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOM/RTS.json", sheetName = "rts")
    public void HWPHME2E_609(Map<String, String> inputData)  {
        connexusAppUtils.getStoreId();
        rtsTestscripts.validateFillDatesInRTSResponse();
    }

     /*----------------------------------------------------------------------------------------------------------
           * Test Description: RTS | Verify getRTSInfo API returns 206 if bagNbr provided has fill with fill date below or equal to value mentioned in Parm code 5384
           *
           * Author: snehaa(vn57hhm)
           ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = " RTS | Verify getRTSInfo API returns 206 " +
            "if bagNbr provided has fill with fill date below or equal to value mentioned in Parm code 5384",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOM/RTS.json", sheetName = "rts")
    public void HWPHME2E_615(Map<String, String> inputData)  {
        connexusAppUtils.updateFlagValue("17315","TRUE");
        connexusAppUtils.getStoreId();
        rtsTestscripts.validationinRTSlist();
        rtsTestscripts.validate206response(Integer.parseInt(inputData.get("fillcount")));
    }
}