package connexus.Filling.testcases;

import connexus.Filling.testscripts.Filling_testscripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Map;

public class Filling_testcases {

    Filling_testscripts fillingTestscripts = new Filling_testscripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    PropertyReader prop = PropertyReader.getInstance();
    String siteId =prop.getProperty("cnx.store");
    boolean relaunchConnexus = false;

    @BeforeClass
    public void performlogin(){
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
             * Test Description:FOM | Reports | Biosimilar Substitution report
             *
             * Pre-Conditions:  1.agency_rqmt_parm 31559 is set to 'Y' for the issue_agency_code of the Store's state
             *
             * Author: snehaa(vn57hhm)
             ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled =true, description = "FOM | Reports | Biosimilar Substitution report",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOM/Filling.json", sheetName = "Fill")
    public void HWPHME2E_1947(Map<String, String> inputData)  {

        connexusAppUtils.getStoreId();
        fillingTestscripts.initializeTestCase(relaunchConnexus);
        fillingTestscripts.createNewPatient(inputData);
        fillingTestscripts.performDropOff(Priority.Critical);
        fillingTestscripts.performInput(inputData);
        fillingTestscripts.perform4Point(false);
        fillingTestscripts.performFilling();
        fillingTestscripts.performVisualVerify();
        fillingTestscripts.performPickUp(inputData);
        fillingTestscripts.performCounselling();
        fillingTestscripts.performPOS();
        fillingTestscripts.Reportvalidating();
    }

 /*----------------------------------------------------------------------------------------------------------
             * Test Description:Filling | Verify creation of partial fill from DOOS resolution
             *
             * Pre-Conditions:  1.agency_rqmt_parm 31559 is set to 'Y' for the issue_agency_code of the Store's state
             *
             * Author: snehaa(vn57hhm)
             ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Filling | Verify creation of partial fill from DOOS resolution",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOM/Filling.json", sheetName = "Fill")
    public void HWPHME2E_603(Map<String, String> inputData)throws SQLException, ParserConfigurationException, IOException, SAXException, ParseException {

        int problemCodeForCancelFill  = Integer.parseInt(prop.getProperty("fom.problemCodeForCancelFill"));
        connexusAppUtils.readAndUpdateFlag("17310","TRUE");
        connexusAppUtils.readAndUpdateFlag("29387","FALSE");
        connexusAppUtils.getStoreId();
        //Login to connexus
        fillingTestscripts.initializeTestCase(relaunchConnexus);
        //Create New patient and move till filling
        fillingTestscripts.createNewPatient(inputData);
        fillingTestscripts.performDropOff(Priority.Critical);
        fillingTestscripts.performInput(inputData);
        fillingTestscripts.perform4Point(false);
        fillingTestscripts.performChkDUR();
        fillingTestscripts.verifyRxInFillingQueue();
        //Cancel the fill using Setfill API
        fillingTestscripts.verifyGetSetFillInfocancelled(Integer.parseInt(siteId),problemCodeForCancelFill,false);
        fillingTestscripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        //Created partial fill updating On-hand quantity
        fillingTestscripts.Doosresolution(inputData);
        //Submitting the fill
        fillingTestscripts.submitted();
        //performing vv to EOD
        fillingTestscripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        fillingTestscripts.performVv();
        fillingTestscripts.performPickup(inputData);
        fillingTestscripts.performCounsel();
        fillingTestscripts.performPos();
    }

    /*----------------------------------------------------------------------------------------------------------
             * Test Description:FOM | GetStationCounts | CycleCounts
             *
             * Author: snehaa(vn57hhm)
             ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "FOM | GetStationCounts | CycleCounts",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOM/Filling.json", sheetName = "Fill")
    public void HWPHME2E_1950(Map<String, String> inputData)  {

        connexusAppUtils.getStoreId();
        fillingTestscripts.validateCyclecount(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
            * Test Description:FOM | GetStationCounts | RTS
            *
            * Author: snehaa(vn57hhm)
            ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "FOM | GetStationCounts | RTS",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOM/Filling.json", sheetName = "Fill")
    public void HWPHME2E_1949(Map<String, String> inputData) {

        connexusAppUtils.getStoreId();
        fillingTestscripts.validateRTSCount(inputData);
    }

     /*----------------------------------------------------------------------------------------------------------
             * Test Description:FOM | GetStationCounts | Filling
             *
             * Author: snehaa(vn57hhm)
             ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "FOM | GetStationCounts | Filling",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/FOM/Filling.json", sheetName = "Fill")
    public void HWPHME2E_1948(Map<String, String> inputData) {

        connexusAppUtils.getStoreId();
        fillingTestscripts.validateFillingCounts(inputData);
    }
}


