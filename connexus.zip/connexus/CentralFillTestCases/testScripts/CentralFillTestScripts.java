package connexus.CentralFillTestCases.testScripts;

import centralfilltests.CFDataModels.Fill;
import com.aventstack.extentreports.Status;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.gson.*;
import com.informix.jdbc.IfxBSONObject;
import connexus.ConnexusTestScripts;
import connexus.Filling.testscripts.Filling_testscripts;
import connexus.PMP.testScripts.PMPRealTimeReportingTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.joda.time.DateTime;
import org.openjdk.tools.sjavac.Log;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import rxpd.RXPDE2E.Utils.Poller;

import centralfilltests.CFDBModels.barcodeGeneretion.BarcodeDBModelRxToken;
import centralfilltests.tests.StatuaUpdateE2E.statusupdatewrapper;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.*;
import java.util.List;

import static connexus.e2e.testcases.E2E_TestCases.loginUser_Type;
import static hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager.asnNumber;
import static hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager.shipmentId;

public class CentralFillTestScripts extends ConnexusTestScripts {
    int patientId, numRefills, patientIdFromName;
    List<String> ndcList;

    PropertyReader prop = PropertyReader.getInstance();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    List<InputResponse> multiRx4PointCompleteResp = new ArrayList<>();
    List<InputResponse> multiRxPaymentCompleteResp = new ArrayList<>();
    List<String> multiRxNbr = new ArrayList<>();
    List<String> multiRxNbrList = new ArrayList<>();
    Map<String, Object> values = new HashMap<>();
    String workStationName ="";
    public List<Map<String, Integer>> fillIdAndTranIdRx = new ArrayList<>();
    public connexus.Filling.testscripts.Filling_testscripts fillingTestscripts = new connexus.Filling.testscripts.Filling_testscripts(loginUserType);

    public void postStatusUpdateToStore() {
        int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        int fillId = connexusAppUtils.getFillId(rxNbr);
        String storeTranId = connexusAppUtils.getStoreTranIdForFillId(siteId, fillId);
        if (storeTranId == null) {
            return;
        }

        List<BarcodeDBModelRxToken> tokens = automationManager
                .getConnexusDB(siteId)
                .executeQueryForList("select token,enc_val,last_change_ts,last_change_userid from rx_token where enc_val = '" + fillId + "'", BarcodeDBModelRxToken.class);
        if (tokens == null || tokens.isEmpty() || tokens.get(0) == null) {
            Assert.fail("No token found in rx_token table for fillId: " + fillId);
            return;
        }
        String token = String.valueOf(tokens.get(0).getToken());

        Map<String, String> apiData = new HashMap<>();
        apiData.put("store_nbr", "0" + siteId);
        apiData.put("store_tran_id", storeTranId);
        apiData.put("token", token);
        apiData.put("rx_fill_id", String.valueOf(fillId));

        statusupdatewrapper wrapper = new statusupdatewrapper();
        ServiceResponse resp = wrapper.statusUpdateApi(apiData);
        Assert.assertTrue(resp.getStatusCode() == 200 || resp.getStatusCode() == 202,
                "Status Update API call failed. HTTP status: " + resp.getStatusCode());
    }

    public void postStatusUpdateToStore(Map<String, String> inputData) {
        postStatusUpdateToStore();
    }

    /**
     * Validate TP card details PTMS screen.
     */
    public void checkDigitalRxInfoCheckboxInPMScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRow(0);
            if (!patientMaintenancePage.isElementSelected(patientMaintenancePage.chkDigitalRx)) {
                patientMaintenancePage.click(patientMaintenancePage.chkDigitalRx);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            e.printStackTrace();
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Card details are missing");
        }
    }

    public void updatePriorityByClickingOnPUButton() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            orderSearch.clickUpdatePUButton();
            dropOffPage.dropOffFutureDateSelection(-3);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            orderSearch.selectReadyByTimeupdate();
            orderSearch.clickAccept();
            orderSearch.clickSoldYes();
            orderSearch.closeSearch();
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail("Priority update failed");
        }
    }

    public void updatePriorityToFutureByClickingOnPUButton() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            orderSearch.clickUpdatePUButton();
            orderSearch.updatePriority("Future");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            orderSearch.selectReadyByTimeupdate();
            orderSearch.clickAccept();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            orderSearch.clickSoldYes();
            orderSearch.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Priority update failed");
        }
    }

    public void verifySubqueTypeCodeUsingPoller(String expectedSubQueueTypeCode){
        try{
            Poller poller = new Poller(20, 500);
            if(poller.pollForSuccess(() -> verifySubQueTypeCodeInRxOrderDetailTable(expectedSubQueueTypeCode))){
                int fillId = connexusAppUtils.getFillId(rxNbr);
                Reporter.log("Fill id : " + fillId + " || Sub Que Type code: " + expectedSubQueueTypeCode);
                Assert.assertTrue(true);
            }else{
                Assert.fail("Incorrect sub queue type code for associated fill");
            }
        } catch (Throwable e) {
            Assert.fail(e.toString());
        }
    }

    /**
     * Verify Sub Que Type code from Order detail table.
     */
    public boolean verifySubQueTypeCodeInRxOrderDetailTable(String expectedSubQueTypeCode) {
        automationManager.performSleep(10);
        List<Map<String, Object>> resultSet = connexusAppUtils.verifySubQueTypeCode(rxNbr);
        String subQueTypeCode="";
        for (int i = 0; i < resultSet.size(); i++) {
            Map<String, Object> result = resultSet.get(i);
            Object isworkQueueTypeCodeNull=result.get("next_work_que_code");
            if(isworkQueueTypeCodeNull!=null) {
                if ("4".equalsIgnoreCase(result.get("next_work_que_code").toString()) || "10".equalsIgnoreCase(result.get("next_work_que_code").toString())) {
                    Reporter.log("Fill id : " + result.get("rx_fill_id").toString() + " || Sub Que Type code: " + result.get("sub_que_type_code").toString());
                    subQueTypeCode = result.get("sub_que_type_code").toString();
                }
            }
        }
        return subQueTypeCode.equals(expectedSubQueTypeCode);
    }

    public String verifySubQueTypeCodeInRxOrderDetailTable(String subQueueTypeCode, Priority priority) {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
        List<Map<String, Object>> resultSet = connexusAppUtils.verifySubQueTypeCode(rxNbr);
        String subQueTypeCode = "";
        for (int i = 0; i < resultSet.size(); i++) {
            Map<String, Object> result = resultSet.get(i);
            dropRxModel.setPriority(priority);
            if (priority == Priority.Future) {
                Object issubQueueTypeCodeNull=result.get("sub_que_type_code");
                if(issubQueueTypeCodeNull!=null) {
                    Reporter.log("Fill id : " + result.get("rx_fill_id").toString() + " || Sub Que Type code: " + result.get("sub_que_type_code").toString());
                    subQueTypeCode = result.get("sub_que_type_code").toString();
                    Assert.assertEquals(result.get("sub_que_type_code").toString(), subQueueTypeCode);
                    break;
                }else{
                    Assert.assertNull(result.get("sub_que_type_code"), "Sub queue type code value is null in DB");
                    Reporter.log("Fill id : " + result.get("rx_fill_id").toString() + " || Sub Que Type code: " + result.get("sub_que_type_code"));
                }
            }
            if (priority != Priority.Future) {
                if ("4".equalsIgnoreCase(result.get("next_work_que_code").toString())) {
                    Reporter.log("Fill id : " + result.get("rx_fill_id").toString() + " || Sub Que Type code: " + result.get("sub_que_type_code").toString());
                    subQueTypeCode = result.get("sub_que_type_code").toString();
                    Assert.assertEquals(result.get("sub_que_type_code").toString(), subQueueTypeCode);
                } else {
                    Assert.assertNull(result.get("sub_que_type_code"), "Sub queue type code value is null in DB");
                    Reporter.log("Fill id : " + result.get("rx_fill_id").toString() + " || Sub Que Type code: " + result.get("sub_que_type_code"));
                }
            }
        }
        return subQueTypeCode;
    }

    /**
     * Validate trans type and warning label.
     */
    public void validateTransTypeAndWarningLabel(Map<String, String> inputData) {
        try {
            String rxFillId = String.valueOf(connexusAppUtils.getFillId(rxNbr));
            Object sendFillReq = "";
            Object fillResoponce23 = "";
            List<String> transTypes = new ArrayList<>();
            List<Map<String, Object>> results = connexusAppUtils.getTransTypeAndStatusCOdeByFillId(rxFillId);
            for (Map<String, Object> result : results) {
                Assert.assertEquals(result.get("req_status_code").toString(), inputData.get("REQUEST_STATUS_CODE"));
                String transTypeCode = result.get("trans_type_code").toString();
                transTypes.add(transTypeCode);
                Reporter.log("Trans Type Code: " + transTypeCode + " || Status Code: " + result.get("req_status_code").toString());

                if (result.get("trans_type_code").toString().equals(inputData.get("TRANS_TYPE_CODE_ONE"))) {
                    sendFillReq = result.get("req_json");
                } else if ("23".equals(result.get("trans_type_code").toString())) {
                    fillResoponce23 = result.get("resp_json");
                }

                Object responseCode=result.get("http_resp_code");
                if(responseCode!=null) {
                    Assert.assertEquals(result.get("http_resp_code").toString(), "200", "http_resp_code code is not 200 for Trans Type code " + result.get("trans_type_code").toString());
                }
            }

            //Validation of trans type 1 & 23 presence
            if (transTypes.contains(inputData.get("TRANS_TYPE_CODE_ONE")) && transTypes.contains(inputData.get("TRANS_TYPE_CODE_TWO"))) {
                Assert.assertTrue(true);
            } else {
                Assert.fail("Trans Type 1 & 23 is not present in the DB result");
            }
            //Validation of send Fill Request for 1 trans type
            IfxBSONObject bson = (IfxBSONObject) sendFillReq;
            Map<String, Object> map = bson.toMap();
            Gson gson = new GsonBuilder().serializeNulls().create();
            String formattedjson = gson.toJson(map);
            JsonObject json = JsonParser.parseString(formattedjson).getAsJsonObject();
            if (json.has("data") && json.getAsJsonObject("data").has("fill_data")) {
                JsonObject fillData = json.getAsJsonObject("data").getAsJsonObject("fill_data").getAsJsonObject("warnings");
                Assert.assertTrue(fillData.keySet().contains("warning_label5"));
                String warningLabel = fillData.get("warning_label5").toString();
                Reporter.log("warning_label5: " + warningLabel);
                Assert.assertTrue(warningLabel.contains(inputData.get("WARNING_LABEL_TEXT")), "Warning label should contain " + inputData.get("WARNING_LABEL_TEXT") + " but found " + warningLabel);
            } else {
                Assert.fail("warning_label5 is not present in the send fill Request");
            }

            //Validation of Response for Trans Type 23
            IfxBSONObject resbson = (IfxBSONObject) fillResoponce23;
            Map<String, Object> resmap = resbson.toMap();
            Gson resgson = new GsonBuilder().serializeNulls().create();
            String resformattedjson = resgson.toJson(resmap);
            JsonObject responseJson = JsonParser.parseString(resformattedjson.toString()).getAsJsonObject();
            if (responseJson.has("digitalMedGuideUrl")) {
                String digitalUrl = responseJson.get("digitalMedGuideUrl").toString();
                Assert.assertTrue(digitalUrl.contains(inputData.get("WARNING_LABEL_TEXT")), "Warning label should contain " + inputData.get("WARNING_LABEL_TEXT") + " but found " + digitalUrl);
            } else {
                Assert.fail("digitalMedGuideUrl is not present in the send fill Response");
            }
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail("Trans Tpe and Warning label validation failed");
        }
    }

    public List<String> CreatePatientAndMultiRxOrderMoveTocheckDUR(Map<String, String> inputData) {
        return CreatePatientAndMultiRxOrderMoveTocheckDUR(inputData,1);
    }
    public void validateCentralfillActivitiesinRXreport(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.CENTRAL_FILL_ACTIVITY_REPORT, AppMenuItemsIndex.RX_REPORTS, AppMenuSubItemsIndex.CENTRAL_FILL_ACTIVITY_REPORT, null);
            rxLookUp.openCentralFillActivitiesReportIneligiblePatientRestrictions();
            Assert.assertTrue(rxLookUp.checkRxExistsInReport(rxNbr));
            Reporter.log("CF Activities with correct Activity Description is present in the RX report");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            menuBar.click(menuBar.closeButton);
        } catch (Throwable e) {
            e.printStackTrace();
            menuBar.click(menuBar.closeButton);
            Reporter.log("Test failed while validating RX in Central Fill Activities report");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }
    /**
     * This Method will create a patient and complete till Check DUR for Multi RX
     *
     * @param inputData
     * @return
     */
    public List<String> CreatePatientAndMultiRxOrderMoveTocheckDUR(Map<String, String> inputData,int numOfRxs) {
        PMPRealTimeReportingTestScript pmpRealTimeReportingTestScript = new PMPRealTimeReportingTestScript();
        patientId = pmpRealTimeReportingTestScript.getPatientId(inputData);
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        ndcList = new ArrayList<>();
        for (int i =0; i <= numOfRxs; i++) {
            int temp = i + 1;
            ndcList.add(inputData.get("DRUG_NAME" + temp));
        }
        String priorityId = inputData.get("PRIORITY_ID");
        multiRx4PointCompleteResp = connexusAPIManager.createMultiRxDropOffAndMoveTocheckDUR(patientId, siteId, numRefills, ndcList, priorityId, connexusAPIManager.PrescriberDetails());
        loginConnexus(loginUser_Type);
        for (int i = 0; i <= numOfRxs; i++) {
            rxNbr = String.valueOf(multiRx4PointCompleteResp.get(i).getRxNbr());
            multiRxNbr.add(rxNbr);
            Log.info("rxNbrValue:" + rxNbr);
            performChkDUR();
        }
        return multiRxNbr;
    }

    /**
     * It will get the central fill id and order id and return it
     * @return
     */
    public List<Map<String,Integer>> getCentralFillRxNumber(Map<String, String> inputData) {
        int fillId =0;
        int orderId=0;
        int rxNumber=0;
        String tranId="";
        List<String> subQueType = new ArrayList<>();
        List<Map<String,Integer>> CFlist=new ArrayList<>();
        for (String rx : multiRxNbr) {
            Map<String, Integer> fillIdAndOrderId = new HashMap<>();
            List<Map<String, Object>> resultSet = connexusAppUtils.verifySubQueTypeCode(rx);
            for (int i = 0; i < resultSet.size(); i++) {
                Map<String, Object> result = resultSet.get(i);
                String subQType = result.get("sub_que_type_code") != null ? result.get("sub_que_type_code").toString() : "";
                subQueType.add(subQType);
                workStationName = result.get("wrkstatn_host_name") != null ? result.get("wrkstatn_host_name").toString() : "";

                if(workStationName.contains(prop.getProperty("cf.workstation"))){
                    Assert.assertTrue(true);
                    Reporter.log("workstation Name is in " + workStationName);
                    fillId = connexusAppUtils.getFillId(rx);
                    tranId = getStoreTranId(String.valueOf(fillId), inputData);
                    orderId = Integer.parseInt(result.get("order_id").toString());
                    rxNumber = Integer.parseInt(rx);
                    fillIdAndOrderId.put("fillId", fillId);
                    fillIdAndOrderId.put("orderId", orderId);
                    fillIdAndOrderId.put("rxNumber", rxNumber);
                    fillIdAndOrderId.put("tranId", Integer.parseInt(tranId));
                    if (subQType.equals(prop.getProperty("cf.subq.code"))) {
                        Assert.assertTrue(true, "Sub Que Type Code 5 Validated Successfully");
                        Reporter.log("Fill id : " + result.get("rx_fill_id").toString() + " || Sub Que Type code: " + subQType);
                    } else {
                        Assert.fail("SubQue Type Validation Failed");
                    }
                }else{
                    Assert.fail("Central Fill Work station name coming as "+workStationName);
                }
            }
            if (!fillIdAndOrderId.isEmpty()) {
                CFlist.add(fillIdAndOrderId);
            }

            fillIdAndTranIdRx.add(fillIdAndOrderId);
        }
        return CFlist;
    }


    /**
     * It will get the central fill id and order id and return it
     * @return
     */
    public List<Map<String,Integer>> getCentralFillRxNumber(Map<String, String> inputData,String rx) {
        int fillId =0;
        int orderId=0;
        int rxNumber=0;
        String tranId="";
        List<String> subQueType = new ArrayList<>();
        List<Map<String,Integer>> CFlist=new ArrayList<>();
        Map<String,Integer> fillIdAndOrderId = new HashMap<>();
        List<Map<String, Object>> resultSet = connexusAppUtils.verifySubQueTypeCode(rx);
        for (int i = 0; i < resultSet.size(); i++) {
            Map<String, Object> result = resultSet.get(i);
            String subQType = result.get("sub_que_type_code")!=null?result.get("sub_que_type_code").toString():"";
            subQueType.add(subQType);
            workStationName = result.get("wrkstatn_host_name")!=null?result.get("wrkstatn_host_name").toString():"";
            if(workStationName.contains(prop.getProperty("cf.workstation"))){
                Assert.assertTrue(true);
                Reporter.log("workstation Name is in "+workStationName);
                fillId= connexusAppUtils.getFillId(rx);
                tranId=getStoreTranId(String.valueOf(fillId),inputData);
                orderId = Integer.parseInt(result.get("order_id").toString());
                rxNumber = Integer.parseInt(rx);
                fillIdAndOrderId.put("fillId",fillId);
                fillIdAndOrderId.put("orderId",orderId);
                fillIdAndOrderId.put("rxNumber",rxNumber);
                fillIdAndOrderId.put("tranId",Integer.parseInt(tranId));
                if(subQType.equals(prop.getProperty("cf.subq.code"))){
                    Assert.assertTrue(true,"Sub Que Type Code 5 Validated Successfully");
                    Reporter.log("Fill id : " + result.get("rx_fill_id").toString() + " || Sub Que Type code: " + subQType);
                }else{
                    Assert.fail("SubQue Type Validation Failed");
                }
            }else{
                Assert.fail("Central Fill Work station name coming as "+workStationName);
            }

            if(!fillIdAndOrderId.isEmpty()) {
                CFlist.add(fillIdAndOrderId);
            }
        }
        fillIdAndTranIdRx.add(fillIdAndOrderId);
        return CFlist;
    }

    /**
     * This method will get the store tran id and return
     * @param rxFillId
     * @param inputData
     * @return
     */
    public String getStoreTranId(String rxFillId,Map<String, String> inputData) {
        List<Map<String, Object>> results = connexusAppUtils.getTransTypeAndStatusCOdeByFillId(rxFillId);
        String storeTranId = "";
        List<String> transTypes = new ArrayList<>();
        for (Map<String, Object> result : results) {
            String transTypeCode = result.get("trans_type_code").toString();
            Reporter.log("Trans Type Code: " + transTypeCode + " || Status Code: " + result.get("req_status_code").toString());
            transTypes.add(transTypeCode);
            if (result.get("trans_type_code").toString().equals(prop.getProperty("cf.tran.one"))) {
                Assert.assertEquals(result.get("req_status_code").toString(), inputData.get("REQUEST_STATUS_CODE"));
                storeTranId = result.get("store_tran_id").toString();
            }
        }
        if(transTypes.contains(prop.getProperty("cf.trans.type.three"))){
            Assert.assertTrue(true);
        }else{
            Assert.fail("There is no Trans Type 3 is present for the fill id "+rxFillId);
        }
        return storeTranId;
    }

    /**
     * This Method will validate the activity type code
     * @param orderId
     */
    public void validateActivityTypeCodeForCentralFill(int orderId){
        if(connexusAppUtils.validateActivityCode(orderId)){
            Assert.assertTrue(true);
            Reporter.log("Activity Type Code Validated Successfully, Activity Type Code is in 10000, 16136");
        }else{
            Assert.fail("Activity code is not in 10000, 16136");
        }
    }

    /**
     * This Method will validate the espn update
     * @param rxFillId
     */
    public void validateTransTypeFourForEspnUpdate(String rxFillId){
        List<Map<String, Object>> results = connexusAppUtils.getTransTypeAndStatusCOdeByFillId(rxFillId);
        List<String> transTypes = new ArrayList<>();
        for (Map<String, Object> result : results) {
            transTypes.add(result.get("trans_type_code").toString());
        }
        if(transTypes.contains(prop.getProperty("cf.trans.type.four"))){
            Reporter.log("Trans type "+prop.getProperty("cf.trans.type.four")+" Added in DB");
            Assert.assertTrue(true);
        }else{
            Assert.fail("There is no Trans Type 4 is present for the fill id "+rxFillId);
        }
    }

    /**
     * This Method will validate Fill id's in ASN list
     * @param rxFillId
     */
    public void validateFillIdUnderAsnList(String rxFillId){
        Object json="";
        List<Map<String, Object>> results = connexusAppUtils.getTransTypeAndStatusCOdeByFillId(rxFillId);
        for (Map<String, Object> result : results) {
            if(result.get("trans_type_code").toString().equalsIgnoreCase(prop.getProperty("cf.trans.type.four"))){
                json=result.get("req_json");
            }
        }
        IfxBSONObject bson = (IfxBSONObject)json;
        Map<String, Object> map = bson.toMap();
        Gson gson = new GsonBuilder().serializeNulls().create();
        String formattedjson = gson.toJson(map);
        JsonObject jsonObject = JsonParser.parseString(formattedjson).getAsJsonObject();
        JsonArray FillId=jsonObject.get("ASNFillList").getAsJsonArray();
        Assert.assertEquals(FillId.size(),2,"Fill id count not matching");
        Reporter.log("Fill ids under ASN list are " + FillId);
    }

    public void validateShipmentIdAndASNNumberPoller(int rxFillId) {
        try{
            Poller poller = new Poller(15, 500);
            if(poller.pollForSuccess(() -> validateShipmentIdAndASNNumber(rxFillId))){
                Reporter.log("Shipment id "+shipmentId+" is present");
                //validation of ASN Number
                String asnNum = connexusAppUtils.getAsnNumber(shipmentId);
                Assert.assertEquals(asnNum.trim(),String.valueOf(asnNumber).trim(),"ASN Number is not matching");
                Reporter.log("Validated ASN number "+asnNumber+" is present in DB");
            }else{
                Reporter.log("Shipment id "+shipmentId+" is not present");
                Assert.fail("Shipment id is not there");
            }
        } catch (Throwable e) {
            Assert.fail(e.toString());
        }
    }

    /**
     * This Method will validate Shipment id and ASN number.
     * @param
     */
    public boolean validateShipmentIdAndASNNumber(int fillId){
        List<Map<String, Object>>  shipMents = connexusAppUtils.getShipMentId(String.valueOf(fillId));
        List<String> shipmentIds= new ArrayList<>();
        //Shipment id validation
        for (Map<String, Object> shipMent : shipMents){
            String shipmentNum= shipMent.get("cf_shipment_id").toString();
            shipmentIds.add(shipmentNum);
        }
        return shipmentIds.contains(String.valueOf(shipmentId));

    }

    /**
     * This Method will validate the trans type
     * @param
     */
    public void validateTransType() {
        try {
            List<Map<String, Object>> resultSet = connexusAppUtils.verifySubQueTypeCode(rxNbr);
            for (int i = 0; i < resultSet.size(); i++) {
                Map<String, Object> result = resultSet.get(i);
                String rxFillId = result.get("rx_fill_id").toString();
                List<String> expectedTransTypes = Arrays.asList(prop.getProperty("cf.expexted.trans.types").split(","));
                List<Map<String, Object>> results = connexusAppUtils.getTransTypeAndStatusCOdeByFillId(rxFillId);
                Reporter.log("RX Fill Id "+rxFillId);
                for (Map<String, Object> result1 : results) {
                    String transTypeCode = result1.get("trans_type_code").toString();
                    if (expectedTransTypes.contains(transTypeCode)) {
                        Assert.assertTrue(true);
                        Reporter.log("Trans Type " + transTypeCode + " is present in db result");
                    }
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail("Trans Tpe and Warning label validation failed");
        }
    }

    /**
     * This Method will validate updated NDC and Workstation name.
     * @param
     */
    public void validateUpdatedNdcAndWorkStationHostName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            String ndcNumber=modifyDetails.getNdcNumber();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickCancel();
            orderSearch.clickSoldYes();
            if(ndcNumber.contains(inputData.get("DRUG_NAME"))){
                Assert.fail("CF Eligible NDC number not updated");
            }else{
                Reporter.log("CF Eligible NDC number updated.");
            }
            workStationName=connexusAppUtils.getWorkStationName(rxNbr);
            if(workStationName.contains(prop.getProperty("cf.workstation")))
            {
                Assert.assertTrue(true,"RX moved to Facility");
                Reporter.log("Work Station name"+workStationName);
            }else {
                Assert.fail("Rx not moved to facility");
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    /**
     * Validate ndc number in Pull back report.
     * @param rxNum
     */
    public void validateNdcNumberInCentralFIllPullBackReport(String rxNum){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        menuBar.selectNavigation(AppMenu.RX_PULLBACKED_FROM_CENTRAL_FILL, AppMenuItemsIndex.RX_REPORTS, AppMenuSubItemsIndex.RX_PULLBACKED_FROM_CENTRAL_FILL, null);
        rxLookUp.setDateAndClickShowReport(connexusAppUtils.getCurrentDate("MM/dd/YYYY"));
        if(rxLookUp.getNdcNumber(rxNum)){
            Reporter.log("NDC number is present in the RX report");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(true);
        }else{
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("NDC Number is not present in the Central Fill Pull Back Report");
        }
    }

    /**
     * Performs pick up for multiple rx.
     * @param inputData
     */
    public void performMultiRxPickUp(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String rxStatus, currentRxNbr, firstName, lastName;
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        values = connexusAppUtils.getPatientFirstNameAndLastName(siteId,patientId);
        firstName = (String) values.get("first_name");
        lastName = (String) values.get("last_name");
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = multiRxNbr.get(i);
                multiRxNbrList.add(currentRxNbr);
                rxStatus = orderSearch.getRXStatusForPatientSelfHelp(currentRxNbr, 0, inputData);
                Assert.assertTrue(rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue()));
            }
            automationManager.getConnexusWorkFlow().completeMultiRxPickup(firstName.trim(), lastName.trim(), inputData.get("DOB"), multiRxNbrList,String.valueOf(siteId));
        }   catch(Throwable e){
            Reporter.log("Test failed at PickUp queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * THis method will validate bg numbers in TASCO screen
     * @param inputData
     */
    public void validateBagNumbersInTascoPage(Map<String,String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        Set<String> bagNumbersText = new HashSet<>();
        WorkFlow workFlow= new WorkFlow();
        String firstName, lastName;
        values = connexusAppUtils.getPatientFirstNameAndLastName(siteId,patientId);
        firstName = ((String) values.get("first_name")).trim();
        lastName = ((String) values.get("last_name")).trim();
        workFlow.checkRxWorkQue( lastName+","+ firstName, WorkQueue.PICKUP);
        tascoPage.launchTascoScreen();
        if(tascoPage.isElementDisplayed(tascoPage.txtFirstName,10)) {
            tascoPage.inputPatientLastName(lastName);
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(firstName);
            tascoPage.pressTabKey();
            tascoPage.inputPatientDob(inputData.get("DOB"));
            tascoPage.pressTabKey();
            tascoPage.pressTabKey();
        }else {
            tascoPage.inputPatientRxnumber(rxNbr);
        }
        tascoPage.clickSearchOnTascoPage();
        tascoPage.clickRow(0);
        tascoPage.medicarevalidationpopup();
        tascoPage.continueCheckout();
        tascoPage.handleOtherOrdersAvailablePopUp();
        if (!tascoPage.validateCheckoutBkt()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            org.junit.Assert.fail("Checkout button not enabled on tasco screen");
            return;
        }
        tascoPage.clickCheckout();
        tascoPage.handleConnexusCheckoutCashPayPopup();
        tascoPage.handleControlIdSubstanceForControlledDrugPopup();
        tascoPage.handleIdAndRelationshipForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsscreen();
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        tascoPage.handlePatientCentralDataUpdatePayPopup();
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        //validation of two bag
        List<WebElement> bagNumbers = tascoPage.getbagNumbersList();
        for (WebElement bagNumber:bagNumbers){
            bagNumbersText.add(bagNumber.getText().trim());
            Reporter.log("Bag Number: "+bagNumber.getText());
        }
        if(bagNumbersText.size()==bagNumbers.size()){
            Reporter.log("Total "+bagNumbers.size()+ " Bag Number present in the Tasco Page" );
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(true);
        }else{
            Assert.fail("Test Cases Failed at TASCO Page|| unique bag number is not present");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        }
        tascoPage.clickSignOff();
    }

    /**
     * Method to validate rx in counsel queue.
     **/
    public void verifyRxInCounselQueueForMultiRx() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            for(String rxNbr:multiRxNbr) {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Counseling.getValue())) {
                    takeScreenShotRXStatus(rxNbr, WorkQueue.COUNSEL.getWorkQueue(), currentStepMethodName, Status.PASS);
                    Assert.assertTrue(true);
                    Reporter.log("RX is in Counsel queue");
                } else {
                    Reporter.log("RX is not in Counsel queue");
                    takeScreenShotRXStatus(rxNbr, null, currentStepMethodName + ", review the Work Queue status", Status.FAIL);
                    Assert.fail("RX is not in Counsel queue");
                }
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Test failed at Counsel queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            AutomationManager.getInstance().getConnexus().closeConnexus();
        }
    }

    /**
     * Handle Modify Detail screen
     */
    public void handleModifyDetailsWorkQueue(){
        for (String rxNumber:multiRxNbr) {
            orderSearch.openSearch();
            orderSearch.performSearch(rxNumber);
            orderSearch.openFirstPatientRecord();
            patientSearchPage.clickCancel();
            orderSearch.clickYes();
        }
    }

    /**
     * Perform POS for multi rx.
     */
    public void performPOSForMultiRx(){
        for (String rxNumber:multiRxNbr) {
            rxNbr = rxNumber;
            performPOS();
        }
    }

    /**
     * Method to perform Drop Off for RX which created and picked up earlier with > 0 refill
     **/
    public void performRefill(Priority priority) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            dropOffPage.clickOkInActivePopUp();
            dropOffPage.clickOkButton();
            dropOffPage.selectPriority(priority.getPriority());
            if (priority == Priority.Future) {
                dropOffPage.dropOffFutureDateSelection(5);
                dropOffPage.selectReadyByTimeNew();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickBtnAccept();
            dropOffPage.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            connexusAppUtils.writeTextToFile("DropOff For RX With Refills not completed "+rxNbr,"Failed",fileName,0, DateTime.now());
            Reporter.log("DropOff For RX With Refills failed");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * Validate ASN Number in Central Fill Audit and Usage report.
     */
    public void validateASNNumberInCentralFIllAuditUsageReport(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        menuBar.selectNavigation(AppMenu.RX_AUDIT_AND_USAGE_CENTRAL_FILL, AppMenuItemsIndex.RX_REPORTS, AppMenuSubItemsIndex.RX_AUDIT_AND_USAGE_CENTRAL_FILL, null);
        rxLookUp.inputRxNumber(rxNbr);
        if(rxLookUp.getNdcNumber(String.valueOf(asnNumber))){
            Reporter.log("ASN number is present in the RX report");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(true);
            menuBar.click(menuBar.closeButton);
        }else{
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            menuBar.click(menuBar.closeButton);
            Assert.fail("ASN Number is not present in the Central Fill Audit and Usage Report");
        }
    }

    /**
     * This Method will get Store tran id and Fill id.
     * @param
     */
    public List<Map<String, Integer>> getStoreTranIdAndFillId() {
        int fillId = 0;
        int storeTranId = 0;
        Map<String, Integer> tranAndFillID = new HashMap<>();
        List<Map<String, Integer>> storeTranAndFillId = new ArrayList<>();
        List<Map<String, Object>> resultSet = connexusAppUtils.verifySubQueTypeCode(rxNbr);
        for (int i = 0; i < resultSet.size(); i++) {
            Map<String, Object> result = resultSet.get(i);
            Object isworkQueueTypeCodeNull = result.get("next_work_que_code");
            if (isworkQueueTypeCodeNull != null) {
                if (result.get("next_work_que_code").toString().equalsIgnoreCase(prop.getProperty("cf.trans.type.four"))) {
                    {
                        fillId = connexusAppUtils.getFillId(rxNbr);
                        List<Map<String, Object>> results = connexusAppUtils.getTransTypeAndStatusCOdeByFillId(String.valueOf(fillId));
                        for (Map<String, Object> resultValue : results) {
                            int request_Type_Code = Integer.parseInt(resultValue.get("trans_type_code").toString());
                            if (request_Type_Code == Integer.parseInt(prop.getProperty("cf.tran.one"))) {
                                storeTranId = Integer.parseInt(resultValue.get("store_tran_id").toString());
                            }
                        }
                    }
                }
            }
        }
        tranAndFillID.put("tranId", storeTranId);
        tranAndFillID.put("fillId", fillId);
        storeTranAndFillId.add(tranAndFillID);
        return storeTranAndFillId;
    }

    /**
     * This Method will validate Workstation name.
     */
    public void validateWorkStationHostName(Map<String, String> inputData) {
        try {
            workStationName=connexusAppUtils.getWorkStationName(rxNbr);
            if(workStationName.contains(inputData.get("WORKSTATION_NAME")))
            {
                Assert.assertTrue(true);
                Reporter.log("Work Station name "+workStationName);
            }else {
                Assert.fail("Rx not moved to facility");
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    /**
     * This Method will update priority to critical
     * @param rxNumber
     */
    public void updatePriorityToCritical(String rxNumber){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try{
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNumber);
            orderSearch.clickUpdatePUButton();
            orderSearch.updatePriority(prop.getProperty("cf.priority"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            orderSearch.clickAccept();
            if("Store is closed at this Pickup Time. Would you like to Change it ?".equalsIgnoreCase(orderSearch.getErxResponseMessage())){
                orderSearch.clickNo();
            }
            if (orderSearch.isElementDisplayed(orderSearch.cfRxPullbackPrompt,5)) {
                Reporter.logScreenShot(Status.PASS, "CentralFill Rx pullback confirmation prompt", orderSearch.takeScreenShot(currentStepMethodName).getValue());
            }
            orderSearch.clickSoldYes();
            orderSearch.clickSoldYes();
            orderSearch.closeSearch();
        }catch (Throwable e){
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Update priority to Critical failed");
        }

    }


    public void validateTransTypeCodePoller(String rxFillId,String transTypeCode) {
        try{
            Poller poller = new Poller(10, 500);
            if(poller.pollForSuccess(() -> validateTransTypeCode(rxFillId, transTypeCode))){
                Reporter.log("Trans type " + transTypeCode + " Added in DB");
                Assert.assertTrue(true);
            }else{
                Assert.fail("There is no Trans Type " + transTypeCode +" is present for the fill id "+rxFillId);
            }
        } catch (Throwable e) {
            Assert.fail(e.toString());
        }
    }

    /* This Method will validate transtype code existance for fillID
     * @param rxFillId,transTypeCode
     */
    public boolean validateTransTypeCode(String rxFillId,String transTypeCode){
        List<Map<String, Object>> results = connexusAppUtils.getTransTypeAndStatusCOdeByFillId(rxFillId);
        for (int i = 0; i < results.size(); i++) {
            Map<String, Object> result = results.get(i);
            if(result.get("trans_type_code").toString().equalsIgnoreCase(prop.getProperty("cf.trans.type."+transTypeCode))){
                Assert.assertTrue(true);
                Reporter.log("Trans type "+ result.get("trans_type_code")+" present in DB");
                break;
            }
        }
        return true;
    }

    /**
     * Validate ndc number in Pull back report.
     */
    public void validateRxNumberInCentralFIllPullBackReport(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.RX_PULLBACKED_FROM_CENTRAL_FILL, AppMenuItemsIndex.RX_REPORTS, AppMenuSubItemsIndex.RX_PULLBACKED_FROM_CENTRAL_FILL, null);
            rxLookUp.setDateAndClickShowReport(connexusAppUtils.getCurrentDate("MM/dd/YYYY"));
            Assert.assertTrue(rxLookUp.checkRxExistsInReport(rxNbr));
            Reporter.log("Rx number is present in the RX report");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            menuBar.click(menuBar.closeButton);
        } catch (Throwable e) {
            e.printStackTrace();
            menuBar.click(menuBar.closeButton);
            Reporter.log("Test failed while validating RX pull back from Central Fill report");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }
    public List<String> CreatePatientAndMultiRxOrderMoveToFilling(Map<String, String> inputData) throws JsonProcessingException {
        PMPRealTimeReportingTestScript pmpRealTimeReportingTestScript = new PMPRealTimeReportingTestScript();
        patientId = pmpRealTimeReportingTestScript.getPatientId(inputData);
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        ndcList = Arrays.asList(inputData.get("DRUG_NAME1"), inputData.get("DRUG_NAME2"));
        multiRxPaymentCompleteResp = connexusAPIManager.createMultiRxAndMoveToFilling(patientId, siteId, numRefills, ndcList, connexusAPIManager.PrescriberDetails());

        loginConnexus(loginUser_Type);
        for (int i = 0; i <= 1; i++) {
            rxNbr = String.valueOf(multiRxPaymentCompleteResp.get(i).getRxNbr());
            multiRxNbr.add(rxNbr);
            Log.info("rxNbrValue:" + rxNbr);
        }
        return multiRxNbr;
    }
    public void validateWarningLabelTextRows(List<Map<String,Integer>> rxList,Map<String, String> inputData,List<Integer> expectedRowCount) {
        Assert.assertFalse(rxList.isEmpty(), "No rx entries present for validation. rxList is empty" );
        Object sendFillReq = "";
        List<String> transTypes = new ArrayList<>();
        for (Map<String, Integer> rxInfo : rxList) {
            String fillId = String.valueOf(rxInfo.get("fillId"));
            String rxNumber = "";
            if(rxInfo.containsKey("rxNumber")) {
                rxNumber = String.valueOf(rxInfo.get("rxNumber"));
            } else {
                rxNumber = rxNbr;
            }
            List<Map<String, Object>> results = connexusAppUtils.getTransTypeAndStatusCOdeByFillId(fillId);
            Reporter.log("Validating rxNumber :- " + rxNumber);
            for (Map<String, Object> result : results) {
                Assert.assertEquals(result.get("req_status_code").toString(), inputData.get("REQUEST_STATUS_CODE"));
                String transTypeCode = result.get("trans_type_code").toString();
                transTypes.add(transTypeCode);
                Reporter.log("Trans Type Code: " + transTypeCode + " || Status Code: " + result.get("req_status_code").toString());
                if (result.get("trans_type_code").toString().equals(prop.getProperty("cf.tran.one"))) {
                    sendFillReq = result.get("req_json");
                }
                Assert.assertEquals(result.get("http_resp_code").toString(), "200", "http_resp_code code is not 200 for Trans Type code " + result.get("trans_type_code").toString());
            }
            if (transTypes.contains(inputData.get("TRANS_TYPE_CODE_ONE"))) {
                Assert.assertTrue(true);
            } else {
                Assert.fail("Trans Type 1 is not present in the DB result");
            }
            IfxBSONObject bson = (IfxBSONObject) sendFillReq;
            Map<String, Object> map = bson.toMap();
            Gson gson = new GsonBuilder().serializeNulls().create();
            String formattedjson = gson.toJson(map);
            JsonObject json = JsonParser.parseString(formattedjson).getAsJsonObject();
            boolean matched = false;
            if (json.has("data") && json.getAsJsonObject("data").has("fill_data")) {
                JsonObject fillData = json.getAsJsonObject("data").getAsJsonObject("fill_data");
                JsonObject warningsObj = fillData.has("warnings") && fillData.get("warnings").isJsonObject() ? fillData.getAsJsonObject("warnings") : null;
                for (int i = 1; i <= 5; i++) {
                    int rowCount = 0;
                    String key = "warning_label" + i;
                    try {
                        if (warningsObj != null && warningsObj.has(key)) {
                            String warning = warningsObj.get(key).getAsString().trim();
                            for (String part : warning.split("\\.")) {
                                if (!part.trim().isEmpty()) {
                                    rowCount++;
                                }
                            }
                            Reporter.log("Rx: " + rxNumber + "|FillId: " + fillId + " | " + key + " | RowCount: " + rowCount);
                            if (expectedRowCount.contains(rowCount)) {
                                Reporter.log("Warning label text for " +key+ ":" +warning);
                                matched = true;
                                break;
                            }
                        }
                    } catch (Throwable e) {
                        Reporter.log("Skipped as : " + key + "is null");
                    }
                }
            }
            Assert.assertTrue(matched, "No rx found with warning label which has" +expectedRowCount+ "complete rows");
        }
    }

    /**
     * Update Pick up date to future/past date based on no of days.
     * @param noOfDays
     */
    public void updatePickUpDateTimeStamp(int noOfDays){
        int orderId = connexusAppUtils.getOrderId(rxNbr);
        connexusAppUtils.updateTimeStampToFutureDate(orderId,noOfDays);
        Reporter.log("Updated pick up date time stamp to"+ noOfDays+" Days in DB");
    }

    /**
     * Validate whether ASN has been finalized
     */
    public void validateASNFinalized(Map<String, String> inputData) {
        String statusCode = connexusAppUtils.getASNStatusCode(asnNumber);
        Assert.assertEquals(statusCode,inputData.get("ASN_STATUS_CODE"));
        Reporter.log("Validated ASN status code is " + statusCode);
    }

    public void validateNewFillCreatedPoller(int oldFillId){
        validateNewFillCreatedPoller(oldFillId,"");
    }

    public void validateNewFillCreatedPoller(int oldFillId, String rxNum) {
        try{
            Poller poller = new Poller(20, 500);
            if (rxNum.isEmpty()){
                rxNum = rxNbr;
            }
            if(poller.pollForSuccess(() -> validateNewFillCreated(oldFillId))){
                int newFillId = connexusAppUtils.getFillId(rxNum);
                Reporter.log("Validated new Fill: " + newFillId + " created for Rx: " + rxNum);
                Assert.assertTrue(true);
            }else{
                Assert.fail("New fill Id not generated");
            }
        } catch (Throwable e) {
            Assert.fail(e.toString());
        }
    }

    /**
     * Validate whether new file was created
     * @param oldFillId
     */
    public boolean validateNewFillCreated(int oldFillId){
        int newFillId = connexusAppUtils.getFillId(rxNbr);
        return oldFillId != newFillId;
    }

    public void validateNDCAndAdjReasonInInventoryAdjustmentReport(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.INVENTORY_ADJUSTMENT, AppMenuItemsIndex.INVENTORY_REPORTS, AppMenuSubItemsIndex.INVENTORY_ADJUSTMENTS, null);
            rxLookUp.setFromAndToDate(ConnexusAppUtils.getCurrentTimestamp("M/d/yyyy"));
            rxLookUp.clickSearchButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.clickShowReport();
            Assert.assertTrue(rxLookUp.isNDCWithExpectedAdjReasonExistsInReport(inputData.get("DRUG_NAME"), inputData.get("Adj_Reason")));
            Reporter.log("NDC number with expected Adjustment Reason is present in the Inventory Adjustment report");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed while validating Inventory Adjustment report");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }
    public void validateTransTypeByUsingTimeStamp() {
        try {
            List<String> expectedTransTypes = Arrays.asList(prop.getProperty("cf.expexted.trans.types").split(","));
            List<Map<String, Object>> results = connexusAppUtils.getLatestTransTypeByUsingTimeStamp();
            for (Map<String, Object> result : results) {
                String transTypeCode = result.get("trans_type_code").toString();
                if (expectedTransTypes.contains(transTypeCode)) {
                    Assert.assertTrue(true);
                    Reporter.log("Trans Type " + transTypeCode + " is present in db result");
                    break;
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail("Trans Tpe and Warning label validation failed");
        }
    }

    /**
     * Validate call drug sub result.
     */
    public void validateDrugSubResult(Map<String, String> inputData) {
        try {
            List<Map<String, Object>> resultSet = connexusAppUtils.verifySubQueTypeCode(rxNbr);
            for (int i = 0; i < resultSet.size(); i++) {
                Map<String, Object> result = resultSet.get(i);
                String rxFillId = result.get("rx_fill_id").toString();
                Object fillResoponce = "";
                List<String> transTypes = new ArrayList<>();
                List<Map<String, Object>> results = connexusAppUtils.getTransTypeAndStatusCOdeByFillId(rxFillId);
                for (Map<String, Object> result1 : results) {
                    String transTypeCode = result1.get("trans_type_code").toString();
                    transTypes.add(transTypeCode);
                    Reporter.log("Fill ID: " + rxFillId + " || Trans Type Code: " + transTypeCode + " || Status Code: " + result1.get("req_status_code").toString());
                    if ("20".equals(result1.get("trans_type_code").toString())) {
                        fillResoponce = result1.get("resp_json");
                        break;
                    }
                }
                //Validation of Response for Trans Type 20
                IfxBSONObject resbson = (IfxBSONObject) fillResoponce;
                Map<String, Object> resmap = resbson.toMap();
                Gson resgson = new GsonBuilder().serializeNulls().create();
                String resformattedjson = resgson.toJson(resmap);
                JsonObject responseJson = JsonParser.parseString(resformattedjson.toString()).getAsJsonObject();
                String drugSubResult = String.valueOf(responseJson.get("CallDrugSubResult"));
                Reporter.log("Drug Sub Result Response " + drugSubResult);
                if ("null".equalsIgnoreCase(drugSubResult)) {
                    Assert.fail("Call Drug sub result giving null response");
                } else {
                    Reporter.log("Call Drug Sub result having response value");
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail("Trans Tpe and Warning label validation failed");
        }
    }

    public void validateFinalizedASNInInCentralFIllAuditUsageReport() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        menuBar.selectNavigation(AppMenu.RX_AUDIT_AND_USAGE_CENTRAL_FILL, AppMenuItemsIndex.RX_REPORTS, AppMenuSubItemsIndex.RX_AUDIT_AND_USAGE_CENTRAL_FILL, null);
        rxLookUp.setFromAndToDate(ConnexusAppUtils.getCurrentTimestamp("M/d/yyyy"));
        rxLookUp.clickShowReport();
        Assert.assertTrue(rxLookUp.checkRxExistsInReport(rxNbr));
        Reporter.log("ASN :" + asnNumber + "is present in Finalized ASN List");
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
    }

    /**
     * Validate ASN Number available in Central Fill Audit and Usage report.
     */
    public void validateASNStatusInCFAuditReport(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        menuBar.selectNavigation(AppMenu.RX_AUDIT_AND_USAGE_CENTRAL_FILL, AppMenuItemsIndex.RX_REPORTS, AppMenuSubItemsIndex.RX_AUDIT_AND_USAGE_CENTRAL_FILL, null);
        rxLookUp.inputASNInCFAuditReport(asnNumber);
        if(rxLookUp.validateASNAvailableInReport(String.valueOf(asnNumber))){
            Reporter.log("Validated ASN number available in the Central Fill Audit and Usage Report");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(true);
            menuBar.click(menuBar.closeButton);
        }else{
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            menuBar.click(menuBar.closeButton);
            Assert.fail("ASN Number is not present in the Central Fill Audit and Usage Report");
        }
    }
    /**
     This method will update Workstation hostname in DB and validate the changed Workstation in UI
     */
        public void updateAndValidateWorkstationHostName(String rxFillId,Map<String, String> inputData){
            String currentStepMethodName = StackUtils.getCurrentMethodName();
            connexusAppUtils.updateWorkstationToShipped(rxFillId);
            List<Map<String, Object>> resultSet = connexusAppUtils.verifySubQueTypeCode(rxNbr);
            for (int i = 0; i < resultSet.size(); i++) {
                Map<String, Object> result = resultSet.get(i);
                if (result.get("next_work_que_code").toString().equalsIgnoreCase(prop.getProperty("cf.trans.type.four"))) {
                    validateWorkStationHostName(inputData);
                }
            }
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            orderSearch.closeSearch();
        }

    public void validateStatusUpdate() {
        validateStatusUpdate(Collections.emptyMap());
    }

    public void validateStatusUpdate(Map<String, String> inputData) {
        prop.loadCustomProperties("config/ccf/");

        int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        int fillId = connexusAppUtils.getFillId(rxNbr);
        String storeTranId = connexusAppUtils.getStoreTranIdForFillId(siteId, fillId);
        if (storeTranId == null) {
            return;
        }

        Map<String, String> statusUpdateData = new HashMap<>();
        statusUpdateData.put("store_nbr", String.valueOf(siteId));
        statusUpdateData.put("store_tran_id", storeTranId);
        statusUpdateData.put("msg_type", prop.getProperty("cfPayload.msg_type"));
        statusUpdateData.put("request_type_code", prop.getProperty("cfPayload.request_type_code"));
        statusUpdateData.put("request_type_desc", prop.getProperty("cfPayload.request_type_desc"));
        statusUpdateData.put("version", prop.getProperty("cfPayload.version"));

        statusUpdateData.put("token", "9999");
        statusUpdateData.put("cf_facility_nbr", prop.getProperty("cfPayload.cf_facility_nbr"));
        statusUpdateData.put("rx_fill_id", String.valueOf(fillId));

        statusUpdateData.put("status_code", inputData.get("status_code"));
        statusUpdateData.put("status_desc", inputData.get("status_desc"));
        statusUpdateData.put("wrk_station_name", inputData.get("workstation_name"));
        statusUpdateData.put("activity_user_id", prop.getProperty("cfPayload.activity_user_id"));

        statusupdatewrapper api = new statusupdatewrapper();
        ServiceResponse resp = api.statusUpdateApi(statusUpdateData);
        Reporter.log("Status Update API HTTP status: " + resp.getStatusCode());
        Assert.assertEquals(resp.getStatusCode(), 200,"Unexpected HTTP status: " + resp.getStatusCode() + " - " + resp.getStatusDesc());
    }

    public void validateCFActivitiesinreportReceivecancel(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.CENTRAL_FILL_ACTIVITY_REPORT, AppMenuItemsIndex.RX_REPORTS, AppMenuSubItemsIndex.CENTRAL_FILL_ACTIVITY_REPORT, null);
            rxLookUp.selectCancelsFromFacility(connexusAppUtils.getCurrentDate("MM/dd/YYYY"));
            Assert.assertTrue(rxLookUp.checkRxExistsInReport(rxNbr));
            Reporter.log("CF Activities with correct Activity Description is present ,RX number is equal to the RX number from the CF Activities Report");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            menuBar.click(menuBar.closeButton);
        } catch (Throwable e) {
            e.printStackTrace();
            menuBar.click(menuBar.closeButton);
            Reporter.log("Test failed while validating RX in Central Fill Activities report");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }
    public void cancelRxFromModifyDetails(String workqueue) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatus(rxNbr);
            if (rxStatus.equalsIgnoreCase(workqueue)) {
                orderSearch.performSearch(rxNbr, SearchType.PatientRx);
                orderSearch.selectRowFromSearch(0);
                modifyDetails.clickCurrentRX();
                modifyDetails.clickOnCancelRx();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickOnDuplicateFill();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickButtonYes();
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                orderSearch.closeSearch();
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("RX is not not cancelled "+e.getMessage());
        }
    }
    public void validateEspnStatusCode(String rxFillId,Map<String, String> inputData) {
        try {
            List<Map<String, Object>> result = connexusAppUtils.getShipMentId(rxFillId);
            Map<String,Object> row = result.get(0);
            String statusCode = row.get("espn_status_code").toString();
                Reporter.log("Espn status code found in rx_espn_fill table: " + statusCode);
                Assert.assertEquals(statusCode,inputData.get("ESPN_STATUS_CODE"),"Espn status code not matched");
        } catch (Throwable e) {
            Assert.fail("Espn status code is not matched" + e.getMessage());
        }
    }
    public void verifyRxIsInVV(String workqueue) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatus(rxNbr);
            if (rxStatus.equalsIgnoreCase(workqueue)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Rx is in Visual Verify Workqueue");
                orderSearch.closeSearch();
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Espn status code is not matched" + e.getMessage());
        }
    }
}
