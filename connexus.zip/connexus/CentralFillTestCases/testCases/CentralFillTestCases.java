package connexus.CentralFillTestCases.testCases;

import com.fasterxml.jackson.core.JsonProcessingException;
import connexus.CentralFillTestCases.testScripts.CentralFillTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class CentralFillTestCases {
    public static LoginAs.userType loginUser_Type = LoginAs.userType.PHARMACIST_ADFlagOff;
    CentralFillTestScripts centralFillTestScripts = new CentralFillTestScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    PropertyReader prop = PropertyReader.getInstance();
    String siteId = prop.getProperty("cnx.store");
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    boolean flagUpdated = false;

    @BeforeClass
    public void loginToConnexus() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    public void flagsCheckUp() {
        flagUpdated = connexusAppUtils.readAndUpdateFlag("12000", "FALSE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("12008", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("17500", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("17501", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("12674", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("12040", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("12041", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("12676", "10");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15068", "QA");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("17300", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("12003", "TRUE");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * Verify CF state after changing future date from 5 days to 2 days.
     * Author: Nagarjuna(vn575ve)
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-3143")
    @Test(enabled = true, description = "To verify drop a CF fill with future(5 days from today) priority and change future days to 2 days when CF fill accepted state",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_3143_Verify_CF_State_After_Changing_Future_Date_From_Five_Days_To_Two_Days(Map<String, String> inputData) {
        Reporter.log("To verify drop a CF fill with future(5 days from today) priority and change future days to 2 days when CF fill accepted state");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(1, Priority.Future, 5);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.verifySubqueTypeCodeUsingPoller(inputData.get("SUB_TYPE_CODE"));
        centralFillTestScripts.updatePriorityByClickingOnPUButton();
        centralFillTestScripts.verifySubqueTypeCodeUsingPoller(inputData.get("SUB_TYPE_CODE"));
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * verify that QR code url should be displayed in send fill request warning label 5
     * Author: Nagarjuna(vn575ve)
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-3140")
    @Test(enabled = true, description = "To verify that QR code url should be displayed in send fill request warning label 5",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_3140_Verify_QR_Code_URL_For_Warning_Label_In_SendFill_Request(Map<String, String> inputData) {
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.checkDigitalRxInfoCheckboxInPMScreen();
        centralFillTestScripts.performDropOff(Priority.Future);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.validateTransTypeAndWarningLabel(inputData);
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that Subqueue changes to 5 from 1 and update item occurred(NDC changed) when PU is updated from Today to future for Rx
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-3141")
    @Test(enabled = true, description = "To verify that Subqueue changes to 5 from 1 and update item occurred(NDC changed) when PU is updated from Today to future for Rx",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_3141_Verify_Subqueue_Changes_From_5_to_1_when_PU_is_updated_from_Today_to_future_for_Rx(Map<String, String> inputData) {
        Reporter.log("To verify that Subqueue changes to 5 from 1 and update item occurred(NDC changed) when PU is updated from Today to future for Rx");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(Priority.Today);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.updatePriorityToFutureByClickingOnPUButton();
        centralFillTestScripts.verifySubqueTypeCodeUsingPoller(inputData.get("SUB_TYPE_CODE"));
        centralFillTestScripts.validateTransType();
        centralFillTestScripts.validateUpdatedNdcAndWorkStationHostName(inputData);
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify drug sub update item ran when fill is in 4pt and updated PU time to future from InStore
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-3142")
    @Test(enabled = true, description = "To verify drug sub update item ran when fill is in 4pt and updated PU time to future from InStore",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_3142_Verify_drug_sub_update_item_ran_when_PU_time_to_future_from_Instore(Map<String, String> inputData) {
        Reporter.log("To verify drug sub update item ran when fill is in 4pt and updated PU time to future from InStore");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(Priority.InStore);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.updatePriorityToFutureByClickingOnPUButton();
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        centralFillTestScripts.validateTransType();
        centralFillTestScripts.validateUpdatedNdcAndWorkStationHostName(inputData);
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * Verify that TASCO checkout successfully completed using CF Label barcode
     * Author: Nagarjuna(vn575ve)
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-3135")
    @Test(enabled = true, description = "verify that TASCO checkout successfully completed using CF Label barcode",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_3135_VeryfyTascoCheckOutUsingCFLabelBarcode(Map<String, String> inputData) {
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(1, Priority.Future, 1);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.verifySubqueTypeCodeUsingPoller(inputData.get("SUB_TYPE_CODE"));
        List<Map<String, Integer>> tranAndFillId = centralFillTestScripts.getStoreTranIdAndFillId();
        connexusAPIManager.centralFillEspnUpdate(inputData, tranAndFillId);
        centralFillTestScripts.validateTransTypeFourForEspnUpdate(String.valueOf(tranAndFillId.get(0).get("fillId")));
        centralFillTestScripts.validateShipmentIdAndASNNumberPoller(tranAndFillId.get(0).get("fillId"));
        List<Integer> rxToken = connexusAPIManager.centralFillASNInfo();
        connexusAPIManager.centralFIllCfBagInfo(rxToken);
        centralFillTestScripts.performPickUp(inputData);
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify only one RX pull up on Pull back to store report in Connexus , In case of one CF Fill and One Store Fill in an multi rx order.
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-3138")
    @Test(enabled = true, description = "To verify only one RX pull up on Pull back to store report in Connexus , In case of one CF Fill and One Store Fill in an multi rx order",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_3138_VeryfyPullBackReport(Map<String, String> inputData) {
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        centralFillTestScripts.CreatePatientAndMultiRxOrderMoveTocheckDUR(inputData);
        List<Map<String, Integer>> fillIdAndOrderId = centralFillTestScripts.getCentralFillRxNumber(inputData);
        connexusAPIManager.centralFillEspnUpdate(inputData, fillIdAndOrderId);
        centralFillTestScripts.validateActivityTypeCodeForCentralFill(fillIdAndOrderId.get(0).get("orderId"));
        centralFillTestScripts.validateTransTypeFourForEspnUpdate(String.valueOf(fillIdAndOrderId.get(0).get("fillId")));
        centralFillTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        centralFillTestScripts.updatePriorityToCritical(String.valueOf(fillIdAndOrderId.get(0).get("rxNumber")));
        centralFillTestScripts.validateNdcNumberInCentralFIllPullBackReport(String.valueOf(fillIdAndOrderId.get(0).get("rxNumber")));
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify only one RX pull up on Pull back to store report in Connexus , In case of one CF Fill and One Store Fill in an multi rx order.
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-646")
    @Test(enabled = true, description = "To verify that check-in can be complete for a multi Rx and WCB assigned to it",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_646_VeryfyTascoCheckOutUsingCFLabelBarcode_MultiRX(Map<String, String> inputData) {
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        centralFillTestScripts.CreatePatientAndMultiRxOrderMoveTocheckDUR(inputData);
        List<Map<String, Integer>> fillIdAndTranId = centralFillTestScripts.getCentralFillRxNumber(inputData);
        connexusAPIManager.centralFillEspnUpdate(inputData, fillIdAndTranId);
        centralFillTestScripts.validateTransTypeFourForEspnUpdate(String.valueOf(fillIdAndTranId.get(0).get("fillId")));
        centralFillTestScripts.validateFillIdUnderAsnList(String.valueOf(fillIdAndTranId.get(0).get("fillId")));
        centralFillTestScripts.validateShipmentIdAndASNNumberPoller(fillIdAndTranId.get(0).get("fillId"));
        List<Integer> rxToken = connexusAPIManager.centralFillASNInfo();
        connexusAPIManager.centralFIllCfBagInfo(rxToken);
        centralFillTestScripts.performMultiRxPickUp(inputData);
        centralFillTestScripts.verifyRxInCounselQueueForMultiRx();
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that check-in can be completed for a multi Rx and WCB assigned to it (1 CF and 1 Non CF fill ) - Assign WCB bag for the Store fill and then
     * assign different bag for CF fill and Both bags show up at Tasco screen then Complete TASCO
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-3136")
    @Test(enabled = true, description = "To verify that check-in can be completed for a multi Rx and WCB assigned to it (1 CF and 1 Non CF fill ) - Assign WCB bag for the Store fill and then assign different bag for CF fill and Both bags show up at Tasco screen then Complete TASCO",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_3136_VeryfyBothBagInTascoScreen(Map<String, String> inputData) {
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        centralFillTestScripts.CreatePatientAndMultiRxOrderMoveTocheckDUR(inputData);
        List<Map<String, Integer>> fillIdAndTranId = centralFillTestScripts.getCentralFillRxNumber(inputData);
        centralFillTestScripts.performFilling();
        centralFillTestScripts.performVisualVerify();
        connexusAPIManager.centralFillEspnUpdate(inputData, fillIdAndTranId);
        centralFillTestScripts.validateTransTypeFourForEspnUpdate(String.valueOf(fillIdAndTranId.get(0).get("fillId")));
        centralFillTestScripts.validateShipmentIdAndASNNumberPoller(fillIdAndTranId.get(0).get("fillId"));
        List<Integer> rxToken = connexusAPIManager.centralFillASNInfo();
        connexusAPIManager.centralFIllCfBagInfo(rxToken);
        centralFillTestScripts.validateBagNumbersInTascoPage(inputData);
        centralFillTestScripts.handleModifyDetailsWorkQueue();
        centralFillTestScripts.performMultiRxPickUp(inputData);
        centralFillTestScripts.performCounselling();
        centralFillTestScripts.performPOSForMultiRx();
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * Verify that Multiple ASNs should be displayed in CF Audit usage report when SingleRrx mapped to different ASNs and search with Rx Nbr(refill)
     * Author: Nagarjuna(vn575ve)
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-3009")
    @Test(enabled = true, description = "To verify that Multiple ASNs should be displayed in CF Audit usage report when SingleRrx mapped to different ASNs and search with Rx Nbr(refill)",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_3009_VerifyMultipleASNsShouldBeDisplayedInCfAuditUsageReportWhenSingleRrxMappedToDifferentASN(Map<String, String> inputData) {
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(1, Priority.Future, 1);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        List<Map<String, Integer>> tranAndFillId = centralFillTestScripts.getStoreTranIdAndFillId();
        connexusAPIManager.centralFillEspnUpdate(inputData, tranAndFillId);
        centralFillTestScripts.validateTransTypeFourForEspnUpdate(String.valueOf(tranAndFillId.get(0).get("fillId")));
        centralFillTestScripts.validateShipmentIdAndASNNumberPoller(tranAndFillId.get(0).get("fillId"));
        List<Integer> rxToken = connexusAPIManager.centralFillASNInfo();
        connexusAPIManager.centralFIllCfBagInfo(rxToken);
        centralFillTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        centralFillTestScripts.performPickUp(inputData);
        centralFillTestScripts.performRefill(Priority.Future);
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        //centralFillTestScripts.verifySubqueTypeCodeUsingPoller(inputData.get("SUB_TYPE_CODE"));
        List<Map<String, Integer>> newTranAndFillId = centralFillTestScripts.getStoreTranIdAndFillId();
        connexusAPIManager.centralFillEspnUpdate(inputData, newTranAndFillId);
        centralFillTestScripts.validateASNNumberInCentralFIllAuditUsageReport();
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that the Rx shows in the pull back to store from CF report when Rx is pulled back after it is sent CF
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-1960")
    @Test(enabled = true, description = "To verify that the Rx shows in the pull back to store from CF report when Rx is pulled back after it is sent CF",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_643_1960_VeryfyPullBackReport_For_Rx_Sent_To_CF(Map<String, String> inputData) {
        Reporter.log("Verify that the Rx shows in the pull back to store from CF report when Rx is pulled back after it is sent CF");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(1, Priority.Future, 1);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        String rxFillId = String.valueOf(connexusAppUtils.getFillId(centralFillTestScripts.rxNbr));
        int orderId = connexusAppUtils.getOrderId(centralFillTestScripts.rxNbr);
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        centralFillTestScripts.validateTransTypeAndWarningLabel(inputData);
        centralFillTestScripts.validateWorkStationHostName(inputData);
        centralFillTestScripts.validateActivityTypeCodeForCentralFill(orderId);
        centralFillTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        centralFillTestScripts.updatePriorityToCritical(centralFillTestScripts.rxNbr);
        centralFillTestScripts.validateTransTypeCodePoller(rxFillId, "two");
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE_ONE"));
        centralFillTestScripts.validateRxNumberInCentralFIllPullBackReport();
        Reporter.log("Verified that the Rx shows in the pull back to store from CF report when Rx is pulled back after it is sent CF");
    }


    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that warning label text data in send fill request for a MultiRx- One of drug has got warning label text count =3 and second drug has got warning label text count =2
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-2430")
    @Test(enabled = true, description = "To verify that warning label text data in send fill request for a MultiRx- One of drug has got warning label text count =3 and second drug has got warning label text count =2",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_2430_VerifyWarningLabelTextDataInSendFillRequestForMultiRX(Map<String, String> inputData) throws JsonProcessingException {
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        centralFillTestScripts.CreatePatientAndMultiRxOrderMoveToFilling(inputData);
        List<Map<String, Integer>> rxList = centralFillTestScripts.getCentralFillRxNumber(inputData);
        centralFillTestScripts.validateWarningLabelTextRows(rxList, inputData, Arrays.asList(2, 3));
        Reporter.log("Validated one of the Rx complete 3 rows of warning label sent to facility and another Rx complete 2 rows of warning label text sent to facility");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that warning label text data in send fill request for Single Rx when drug has got warning label text count = 1
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-2429")
    @Test(enabled = true, description = "To verify that warning label text data in send fill request for Single Rx when drug has got warning label text count = 1",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_2429_VerifyWarningLabelTextDataInSendFillRequestForSingleRX(Map<String, String> inputData) throws JsonProcessingException {
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(1, Priority.Future, 1);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        centralFillTestScripts.validateWorkStationHostName(inputData);
        List<Map<String, Integer>> tranAndFillId = centralFillTestScripts.getStoreTranIdAndFillId();
        centralFillTestScripts.validateWarningLabelTextRows(tranAndFillId, inputData, Collections.singletonList(1));
        Reporter.log("Validated warning label text data in send fill request for Single Rx when drug has got warning label text count = 1");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify fill is sent to facility when changing phm_param_value for code 12676 in DB and drop fill within the param value days range.
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-2626")
    @Test(enabled = true, description = "To verify fill is sent to facility when changing phm_param_value for code 12676 in DB and drop fill within the param value days range",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_2626_Veryfy_Fill_Sent_To_Facility_When_Drop_Fill_With_In_The_Param_Value_Days_Range(Map<String, String> inputData) {
        Reporter.log("Veryfy fill sent to facility when drop fill with in the param value days range");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        connexusAppUtils.readAndUpdateFlag("12676", "10");
        centralFillTestScripts.createNewPatient(inputData);
        Reporter.log("Current Time Stamp " + connexusAppUtils.getCurrentTimestamp("YYYY-MM-dd HH:mm:ss"));
        centralFillTestScripts.performDropOff(1, Priority.Future, 10);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.verifyRxInFillingQueue();
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        Reporter.log("Verified fill sent to facility when drop fill with in the param value days range");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify fill is not sent to facility with pick-up date (days based on the phm_param_value 12676) next day from last day(last day +1) 12AM(10 days configured - 11th day after 12AM).
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-2626")
    @Test(enabled = true, description = "To verify fill is not sent to facility with pick-up date (days based on the phm_param_value 12676) next day from last day(last day +1) 12AM(10 days configured - 11th day after 12AM)",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_2625_Veryfy_Fill_Not_Sent_To_Facility_When_Drop_Fill_With_Next_Day_To_The_Param_Value_Days_Range(Map<String, String> inputData) {
        Reporter.log("Veryfy fill not sent to facility when drop fill with next day to the param value days range");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        connexusAppUtils.readAndUpdateFlag("12676", "10");
        centralFillTestScripts.createNewPatient(inputData);
        Reporter.log("Current Time Stamp " + connexusAppUtils.getCurrentTimestamp("YYYY-MM-dd HH:mm:ss"));
        centralFillTestScripts.performDropOff(1, Priority.Future, 11);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.updatePickUpDateTimeStamp(11);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.verifyRxInFillingQueue();
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        Reporter.log("Verified fill not sent to facility when drop fill with next day to the param value days range");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that a Rx can be cannot located and marked missing from check-in app
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-651")
    @Test(enabled = true, description = "To verify that a Rx can be cannot located and marked missing from check-in app",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_651_Rx_can_be_marked_missing_from_checkinApp(Map<String, String> inputData) {
        Reporter.log("Verify that a Rx can be cannot located and marked missing from check-in app");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(Priority.Future);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        List<Map<String, Integer>> tranAndFillId = centralFillTestScripts.getStoreTranIdAndFillId();
        connexusAPIManager.centralFillEspnUpdate(inputData, tranAndFillId);
        centralFillTestScripts.validateTransTypeFourForEspnUpdate(String.valueOf(tranAndFillId.get(0).get("fillId")));
        centralFillTestScripts.validateShipmentIdAndASNNumberPoller(tranAndFillId.get(0).get("fillId"));
        List<Integer> rxToken = connexusAPIManager.centralFillASNInfo();
        Reporter.log("setCFMissingFills API call");
        connexusAPIManager.centralFIllCfSetFillMissing(rxToken.get(0),false);
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE_ONE"));
        centralFillTestScripts.performFilling();
        centralFillTestScripts.validateNewFillCreatedPoller(tranAndFillId.get(0).get("fillId"));
        centralFillTestScripts.performVisualVerify();
        centralFillTestScripts.validateASNNumberInCentralFIllAuditUsageReport();
        Reporter.log("Verified that a Rx can be cannot located and marked missing from check-in app");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that TASCO checkout successfully completed with CF token
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-652")
    @Test(enabled = true, description = "To verify that TASCO checkout successfully completed with CF token",
            priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_652_Tasco_checkout_successfully_completed_with_CFToken(Map<String, String> inputData) {
        Reporter.log("Verify that TASCO checkout successfully completed with CF token");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(Priority.Future);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        List<Map<String, Integer>> tranAndFillId = centralFillTestScripts.getStoreTranIdAndFillId();
        connexusAPIManager.centralFillEspnUpdate(inputData, tranAndFillId);
        centralFillTestScripts.validateTransTypeFourForEspnUpdate(String.valueOf(tranAndFillId.get(0).get("fillId")));
        centralFillTestScripts.validateShipmentIdAndASNNumberPoller(tranAndFillId.get(0).get("fillId"));
        List<Integer> rxToken = connexusAPIManager.centralFillASNInfo();
        connexusAPIManager.centralFIllCfBagInfo(rxToken, centralFillTestScripts.rxNbr);
        connexusAPIManager.centralFillFinalizeASN();
        centralFillTestScripts.validateASNFinalized(inputData);
        centralFillTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        centralFillTestScripts.performPickUp(inputData);
        Reporter.log("Verified that TASCO checkout successfully completed with CF token");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * verify that the NDC with adjustment reason as CF RTS is inserted in Inventory Adjustment report when a CF Rx is cancelled
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-1962")
    @Test(enabled = true, description = "To verify that the NDC with adjustment reason as CF RTS is inserted in Inventory Adjustment report when a CF Rx is cancelled\"",
            priority = 18, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_1962_Verify_Inventory_Adjustment_Report_When_CF_Rx_Is_Cancelled(Map<String, String> inputData) {
        Reporter.log("Verify that the NDC with adjustment reason as CF RTS is inserted in Inventory Adjustment report when a CF Rx is cancelled");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(1, Priority.Future, 1);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        String rxFillId = String.valueOf(connexusAppUtils.getFillId(centralFillTestScripts.rxNbr));
        int orderId = connexusAppUtils.getOrderId(centralFillTestScripts.rxNbr);
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        centralFillTestScripts.getStoreTranId(rxFillId, inputData);
        centralFillTestScripts.validateWorkStationHostName(inputData);
        centralFillTestScripts.validateActivityTypeCodeForCentralFill(orderId);
        List<Map<String, Integer>> tranAndFillId = centralFillTestScripts.getStoreTranIdAndFillId();
        connexusAPIManager.centralFillEspnUpdate(inputData, tranAndFillId);
        List<Integer> rxToken = connexusAPIManager.centralFillASNInfo();
        centralFillTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        centralFillTestScripts.updatePriorityToCritical(centralFillTestScripts.rxNbr);
        centralFillTestScripts.validateTransTypeCodePoller(rxFillId, "two");
        centralFillTestScripts.validateNewFillCreatedPoller(tranAndFillId.get(0).get("fillId"));
        connexusAPIManager.setCFRTSInfo(rxToken.get(0),false);
        centralFillTestScripts.validateNDCAndAdjReasonInInventoryAdjustmentReport(inputData);

        Reporter.log("Verified the NDC with adjustment reason as CF RTS is inserted in Inventory Adjustment report when a CF Rx is cancelled");
    }


    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that subqueue changes to 5 when PU is updated from critical to future for Rx having CF NDC.
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-633")
    @Test(enabled = true, description = "To verify that subqueue changes to 5 when PU is updated from critical to future for Rx having CF NDC",
            priority = 19, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_633_Veryfy_Subqueue_Type_Changes_To_5_When_PU_Is_Updated_From_Critical_ToFuture(Map<String, String> inputData) {
        Reporter.log("To verify that subqueue changes to 5 when PU is updated from critical to future for Rx having CF NDC");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(Priority.Critical);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"), Priority.Critical);
        centralFillTestScripts.updatePriorityToFutureByClickingOnPUButton();
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"), Priority.Future);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.verifyRxInFillingQueue();
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"), Priority.Future);
        centralFillTestScripts.validateDrugSubResult(inputData);
        centralFillTestScripts.validateTransType();
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that cf drug sub runs and subqueue goes to 5 for a CF NDC when PU time is future after 1pm
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-630")
    @Test(enabled = true, description = "To verify that cf drug sub runs and subqueue goes to 5 for a CF NDC when PU time is future after 1pm",
            priority = 20, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_630_Veryfy_Subqueue_Type_5_When_PU_Time_Is_Future_After_1PM(Map<String, String> inputData) {
        Reporter.log("To verify that cf drug sub runs and subqueue goes to 5 for a CF NDC when PU time is future after 1pm");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(1, Priority.Future, 1);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.verifyRxIn4PointQueue();
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"), Priority.Future);
        centralFillTestScripts.validateTransTypeByUsingTimeStamp();
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that the Rx along with ASN details are present in the Central fill audit and usage report
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-1961")
    @Test(enabled = true, description = "To verify that the Rx along with ASN details are present in the Central fill audit and usage report",
            priority = 21, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_1961_Verify_Rx_Along_With_ASN_Are_Present_In_CF_Audit_And_Usage_Report(Map<String, String> inputData) {
        Reporter.log("Verify that the Rx along with ASN details are present in the Central fill audit and usage report");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(Priority.Future);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        String rxFillId = String.valueOf(connexusAppUtils.getFillId(centralFillTestScripts.rxNbr));
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        centralFillTestScripts.getStoreTranId(rxFillId, inputData);
        List<Map<String, Integer>> tranAndFillId = centralFillTestScripts.getStoreTranIdAndFillId();
        connexusAPIManager.centralFillEspnUpdate(inputData, tranAndFillId);
        centralFillTestScripts.validateTransTypeFourForEspnUpdate(String.valueOf(tranAndFillId.get(0).get("fillId")));
        centralFillTestScripts.validateWorkStationHostName(inputData);
        connexusAppUtils.getShipMentId(String.valueOf(tranAndFillId.get(0).get("fillId")));
        centralFillTestScripts.validateShipmentIdAndASNNumberPoller(tranAndFillId.get(0).get("fillId"));
        centralFillTestScripts.validateASNNumberInCentralFIllAuditUsageReport();
        List<Integer> rxToken = connexusAPIManager.centralFillASNInfo();
        connexusAPIManager.centralFIllCfBagInfo(rxToken, centralFillTestScripts.rxNbr);
        connexusAPIManager.centralFillFinalizeASN();
        centralFillTestScripts.validateASNFinalized(inputData);
        centralFillTestScripts.validateFinalizedASNInInCentralFIllAuditUsageReport();
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that Multiple fills should be displayed in CF Audit usage report when ASN mapped to multiple Rxs and search with ASN Nbr
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-3010")
    @Test(enabled = true, description = "To verify that Multiple fills should be displayed in CF Audit usage report when ASN mapped to multiple Rxs and search with ASN Nbr",
            priority = 21, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_3010_verify_MultipleFills_should_be_displayed_in_CFAuditUsageReport_when_ASN_mapped_to_multiple_Rxs_search_with_ASNNbr(Map<String, String> inputData) {
        Reporter.log("Verify that Multiple fills should be displayed in CF Audit usage report when ASN mapped to multiple Rxs and search with ASN Nbr");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        List<String> rxs = centralFillTestScripts.CreatePatientAndMultiRxOrderMoveTocheckDUR(inputData, 2);
        centralFillTestScripts.getCentralFillRxNumber(inputData, rxs.get(0));
        centralFillTestScripts.getCentralFillRxNumber(inputData, rxs.get(1));
        centralFillTestScripts.getCentralFillRxNumber(inputData, rxs.get(2));
        Reporter.logJSON("Fill and tranID", centralFillTestScripts.fillIdAndTranIdRx);
        Reporter.log("ESPN update API call");
        connexusAPIManager.centralFillEspnUpdate(inputData, centralFillTestScripts.fillIdAndTranIdRx);
        centralFillTestScripts.cancelFillFromModifyDetailsScreen(rxs.get(0));
        Reporter.log("getASNInfo API call");
        List<Integer> rxToken = connexusAPIManager.centralFillASNInfo();
        int fillId = connexusAppUtils.getFillId(rxs.get(1));
        Reporter.log("setCFMissingFills API call");
        connexusAPIManager.centralFIllCfSetFillMissing(rxToken.get(1),false);
        Reporter.log("setCFBagInfo API call");
        connexusAPIManager.centralFIllCfBagInfo(rxToken.get(2), rxs.get(2));
        centralFillTestScripts.validateNewFillCreatedPoller(fillId, rxs.get(1));
        centralFillTestScripts.verifyRxInPickup(rxs.get(2));
        Reporter.log("setCFRTSInfo API call");
        connexusAPIManager.setCFRTSInfo(rxToken.get(0),false);
        centralFillTestScripts.validateASNStatusInCFAuditReport();
        Reporter.log("Verified that Multiple fills should be displayed in CF Audit usage report when ASN mapped to multiple Rxs and search with ASN Nbr");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that Rx can be cancelled when Rx has workstation names as Cf-filled/Shipped
     * Author: Purnima Arora(vn58gdi)
     * //@Jira(testID = "HWPHME2E-642")
     * ----------------------------------------------------------------------------------------------------------
     */

    @Test(enabled = true, description = "To verify that Rx can be cancelled when Rx has workstation names as Cf-filled/Shipped",
            priority = 23, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_642_Verify_Rx_Can_Be_Cancelled_When_Workstation_Name_As_Filled(Map<String, String> inputData) {
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(1, Priority.Future, 1);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        List<Map<String, Integer>> tranAndFillId = centralFillTestScripts.getStoreTranIdAndFillId();
        centralFillTestScripts.updateAndValidateWorkstationHostName(String.valueOf(tranAndFillId.get(0).get("fillId")), inputData);
        String rxFillId = String.valueOf(connexusAppUtils.getFillId(centralFillTestScripts.rxNbr));
        centralFillTestScripts.updatePriorityToCritical(centralFillTestScripts.rxNbr);
        centralFillTestScripts.validateTransTypeCodePoller(rxFillId, "two");
        centralFillTestScripts.getStoreTranId(rxFillId, inputData);

        Reporter.log("that Rx can be cancelled when Rx has workstation names as Cf-filled/Shipped");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To Verify that CF Activities Report shows Rxs that are not sent to CF due to Patient Restrictions
     * //@Jira(testID = "HWPHME2E-5515")
     * Author:kruthika(vn59ehu);
     * ----------------------------------------------------------------------------------------------------------
     */

    @Test(enabled = true, description = "To Verify that CF Activities Report shows Rxs that are not sent to CF due to Patient Restrictions",
            priority = 24, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_5515_To_Verify_that_CF_Activities_Report_shows_Rxs_that_are_not_sent_to_CF_due_to_Patient_Restrictions(Map<String, String> inputData) {
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        centralFillTestScripts.createNewPatient(inputData);
        centralFillTestScripts.performDropOff(1, Priority.Future, 1);
        centralFillTestScripts.performInput(inputData);
        centralFillTestScripts.perform4Point(false);
        centralFillTestScripts.performChkDUR();
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        centralFillTestScripts.validateCentralfillActivitiesinRXreport();
        Reporter.log("Validated CF Activities with correct Activity Description is present in the RX report");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To Verify that CF Activities Report shows Rxs that received Cancellation From Facility
     * //@Jira(testID = "HWPHME2E-5514");
     * Author:kruthika(vn59ehu);
     * ----------------------------------------------------------------------------------------------------------
     */
    @Test(enabled = true, description = "To Verify that CF Activities Report shows Rxs that received Cancellation From Facility",
            priority = 25, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_5514_To_Verify_that_CF_Activities_Report_shows_Rxs_that_received_Cancellation_From_Facility(Map<String, String> inputData) {
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated,false);
        int patientId = centralFillTestScripts.createPatientAPI(inputData);
        centralFillTestScripts.moveToFilling(inputData, Integer.parseInt(siteId),patientId);
        String rxFillId = String.valueOf(connexusAppUtils.getFillId(centralFillTestScripts.rxNbr));
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        centralFillTestScripts.getStoreTranId(rxFillId,inputData);
        centralFillTestScripts.validateWorkStationHostName(inputData);
        centralFillTestScripts.validateStatusUpdate();
        centralFillTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        centralFillTestScripts.validateCFActivitiesinreportReceivecancel();
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE_ONE"));
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that set CF RTS is successful when the RX is cancelled with new token with hyphen
     * Author: Purnima Arora(vn58gdi)
     * //@Jira(testID = "HWPHME2E-5536")
     * ----------------------------------------------------------------------------------------------------------
     */
    @Test(enabled = true, description = "To verify that set CF RTS is successful when the RX is cancelled with new token with hyphen\"",
            priority = 24, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_5536_Verify_set_cf_rts_is_successful_when_rx_is_cancelled_with_new_token_with_hyphen(Map<String, String> inputData) {
        Reporter.log("To verify that set CF RTS is successful when the RX is cancelled with new token with hyphen");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        int patientId = centralFillTestScripts.createPatientAPI(inputData);
        centralFillTestScripts.moveToFilling(inputData, Integer.parseInt(siteId),patientId);
        String rxFillId = String.valueOf(connexusAppUtils.getFillId(centralFillTestScripts.rxNbr));
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        centralFillTestScripts.getStoreTranId(rxFillId,inputData);
        centralFillTestScripts.validateWorkStationHostName(inputData);
        List<Map<String,Integer>> tranAndFillId = centralFillTestScripts.getStoreTranIdAndFillId();
        connexusAPIManager.centralFillEspnUpdate(inputData,tranAndFillId);
        List<Integer> rxToken =  connexusAPIManager.centralFillASNInfo();
        centralFillTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        centralFillTestScripts.cancelRxFromModifyDetails(WorkQueue.FILLING.getWorkQueue());
        centralFillTestScripts.validateTransTypeCodePoller(rxFillId,"two");
        Reporter.log("setCFRTSInfo API call with new token with hyphen");
        connexusAPIManager.setCFRTSInfo(rxToken.get(0),true);
        centralFillTestScripts.validateEspnStatusCode(rxFillId,inputData);
        Reporter.log("Verified that set CF RTS is successful when the RX is cancelled with new token with hyphen");
    }

    @Test(enabled = true, description = "To verify that a Rx can be cannot located and marked missing from check-in app with new token format with hypen\"",
            priority = 25, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_5535_Verify_rx_can_not_be_located_and_marked_missing_from_checkin_app_with_new_token_with_hyphen(Map<String, String> inputData) {
        Reporter.log("To verify that a Rx can be cannot located and marked missing from check-in app with new token format with hypen");
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated);
        int patientId = centralFillTestScripts.createPatientAPI(inputData);
        centralFillTestScripts.moveToFilling(inputData, Integer.parseInt(siteId), patientId);
        String rxFillId = String.valueOf(connexusAppUtils.getFillId(centralFillTestScripts.rxNbr));
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE"));
        centralFillTestScripts.validateWorkStationHostName(inputData);
        centralFillTestScripts.getStoreTranId(rxFillId, inputData);
        List<Map<String, Integer>> tranAndFillId = centralFillTestScripts.getStoreTranIdAndFillId();
        connexusAPIManager.centralFillEspnUpdate(inputData, tranAndFillId);
        centralFillTestScripts.validateTransTypeFourForEspnUpdate(String.valueOf(tranAndFillId.get(0).get("fillId")));
        connexusAppUtils.getShipMentId(String.valueOf(tranAndFillId.get(0).get("fillId")));
        centralFillTestScripts.validateShipmentIdAndASNNumberPoller(tranAndFillId.get(0).get("fillId"));
        List<Integer> rxToken = connexusAPIManager.centralFillASNInfo();
        Reporter.log("setCFMissingFills API call with new token with hyphen");
        connexusAPIManager.centralFIllCfSetFillMissing(rxToken.get(0),true);
        centralFillTestScripts.verifySubQueTypeCodeInRxOrderDetailTable(inputData.get("SUB_TYPE_CODE_ONE"));
        centralFillTestScripts.validateNewFillCreatedPoller(tranAndFillId.get(0).get("fillId"));
        centralFillTestScripts.fillingTestscripts.submitted();
        centralFillTestScripts.verifyRxIsInVV(WorkQueue.VISUAL_VERIFY.getWorkQueue());

        Reporter.log("Verified that a Rx can be cannot located and marked missing from check-in app with new token format with hypen");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * To verify that check-in can be complete for a multi Rx and WCB assigned to it for new token format with hyphen;
     * //@Jira(testID = "HWPHME2E-5534");
     * ----------------------------------------------------------------------------------------------------------
     */
    @Test(enabled = true, description = "To verify that check-in can be complete for a multi Rx and WCB assigned to it for new token format with hyphen",
            priority = 26, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CentralFill/CentralFill.json", sheetName = "CF")
    public void HWPHME2E_5534_To_verify_that_check_in_can_be_complete_for_a_multi_Rx_and_WCB_assigned_to_it_for_new_token_format_with_hyphen(Map<String, String> inputData) {
        flagsCheckUp();
        centralFillTestScripts.initializeTestCase(flagUpdated,false);
        centralFillTestScripts.CreatePatientAndMultiRxOrderMoveTocheckDUR(inputData);
        List<Map<String, Integer>> tranAndFillId = centralFillTestScripts.getStoreTranIdAndFillId();
        connexusAPIManager.centralFillEspnUpdate(inputData, tranAndFillId);
        centralFillTestScripts.validateTransTypeFourForEspnUpdate(String.valueOf(tranAndFillId.get(0).get("fillId")));
        centralFillTestScripts.validateShipmentIdAndASNNumberPoller(tranAndFillId.get(0).get("fillId"));
        List<Integer> rxToken = connexusAPIManager.centralFillASNInfo();
        connexusAPIManager.centralFIllCfBagInfo(rxToken,"",true);
    }
 }



