package connexus;

import com.aventstack.extentreports.Status;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import connexus.OrderCreation.PayloadResource;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.AddPatient;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.Address;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.CreatePatientRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.InsuranceDetails;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.TillPickupRequest;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.UpdatePatient.Wrapper.UpdatePatientWrapper;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.forklift.org.apache.commons.io.FileUtils;
import io.strati.libs.joda.time.DateTime;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import org.xml.sax.SAXException;
import rxpd.RXPDE2E.Utils.Poller;
import hwqe.baseframework.models.pageobjectmodels.connexus.ClinicalIntelligencePage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;

import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.Locale;
import java.util.Map;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.pharmaIMZApp.wrappers.PharmaIMZSchedulingWrapper.am;

/**
 * This class consist of common methods to be used in the Test Scripts for all the Connexus Domains.
 * Cloned from E2E_TestScripts, modified and added common methods
 * Author: John vinothkumar(vn58my9)
 **/
public class ConnexusTestScripts {
    public LoginAs.userType loginUserType;
    public LoginPage loginPage;
    public ConnexusStartPage connexusStartPage;
    public PatientSearchPage patientSearchPage;
    public PatientMaintenancePage patientMaintenancePage;
    public ProductSearchPage productSearchPage;
    public ProductMaintenancePage productMaintenancePage;
    public DropOffPage dropOffPage;
    public F6Search orderSearch;
    public RxLookUp rxLookUp;
    public ModifyDetails modifyDetails;
    public ConnexusAppUtils connexusAppUtils;
    public AutomationManager automationManager;
    public DropRxModel dropRxModel;
    public RxModel rxModel;
    public SoftAssert softAssert;
    public String rxNbr = null;
    public PatientProfileModel patient;
    public AddressModel addressModel;
    public ContactModel contactModel;
    public PatientMedicalConditionModel patientMedicalConditionModel;
    public ThirdPartyModel thirdPartyModel;
    public PatientIdentityModel patientIdentityModel;
    public VisVerPage visVerPage;
    public TascoPage tascoPage;
    public MenuBar menuBar;
    public PropertyReader propertyReader;
    public int siteId;
    public CounselPage counselPage;
    public ChkDur chkDur;
    public String fileName;
    public ImzEventPage imzEventPage;
    public ImmunizationSettingsPage imzSettingsPage;
    public ClaimPage claimPage;
    public FourPoint fourPoint;
    public ResolutionPage resolutionPage;
    public ChkDur chkdurPage;
    public InputPage inputPage;
    public ConsolidatedNotesPage consolidatedNotesPage;
    public ServiceResponse resp, orderDetailsResponse;
    public CycleCountReportPage cycleCountReportPage;
    public OnHandInventoryDetailPage onHandInventoryDetailPage;
    public CIIAdjustmentPage c2AdjustmentPage;
    public ReturnToInmarMckesPage returnToInmarMckesPage;
    public ItemMaintenancePage itemMaintenancePage;
    public CIILogBookAdjustmentReasonPage c2LogBookAdjustmentReasonPage;
    public PrescriberSearchPage prescriberSearchPage;
    public ClinicalIntelligencePage clinicalIntelligencePage;
    public PayloadResource payloadResource;
    public TPExtraInfoPage tpExtraInfoPage;
    public CancelPrescription cancelPrescription;
    public ResolutionTPRejPage resolutionTPRejPage;
    public OrderDetailsPage orderDetailsPage;
    public ETransferRequestPage eTransferRequestPage;
    public FaxInboxPage faxInboxPage;
    public DCTResolutionPage DCTResolutionPage;
    String currentRxNbr;
    List<Integer> multiRxNbrValues= new ArrayList<>();
    public int orderId,rxFillId;

    public String siteIDString;
    int startTime;
    int currentTime;
    public boolean isExceptionCaptured = false;
    public boolean isFirstTestCase = true;
    public int patientId,numRefills,priorityId,requestTypeCode,dispenseType,clinicId;
    WrapperUtils wrapperUtils = new WrapperUtils();
    public PatientProfileModel patientProfileModel;
    InputResponse inputResp = new InputResponse();
    DataRow drugInfo;
    String patientName;
    public OTCBillingSettingPage otcBillingSettingPage;
    public EODPage eod;
    public ActionItemsPage actionItemsPage;
    public boolean relaunchConnexus = false;
    public ConnexusAPIManager connexusAPIManager;
    public PickupPage pickupPage;
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    List<String> ndcList;
    public List<String> multiRxNbr = new ArrayList<>();
    List<InputResponse> multiRx4PointCompleteResp = new ArrayList<>();
    boolean loginRequired = true;
    public String rxStatus,inputRxExpDate,inputPickupDate;
    int patientID;
    IDatabaseContext cnx;
    public Map<String, Integer> value = new HashMap<>();
    public DBUtils dbUtils;
    List<String> statusAndProblem = new ArrayList<>();
    public F6Search rxSearch;


    /**
     * When No argument constructor called, initialize default login user type and execution status file name.
     * Updated: John vinothkumar(vn58my9)
     **/
    public ConnexusTestScripts(){
        this(LoginAs.userType.PHARMACIST_ADFlagOff, "Execution_Status.txt");
    }

    public ConnexusTestScripts(LoginAs.userType loginUserType){
        this(loginUserType, "Execution_Status.txt");
    }

    public ConnexusTestScripts(LoginAs.userType loginUserType,String fileName){
        // Assignment
        this.loginUserType = loginUserType;
        this.fileName = fileName.trim();
        this.rxNbr = null;
        // Common initialization
        softAssert = new SoftAssert();
        automationManager = AutomationManager.getInstance();
        connexusAppUtils = new ConnexusAppUtils();
        connexusAPIManager = new ConnexusAPIManager();
        propertyReader = PropertyReader.getInstance();
        siteId = Integer.parseInt(propertyReader.getProperty("cnx.store"));
        cnx = automationManager.getConnexusDB(siteId);
        siteIDString = String.valueOf(siteId);
        dbUtils = new DBUtils();
    }

    public void loginConnexus(){
        loginConnexus(loginUserType);
    }

    public void loginConnexus(LoginAs.userType userType) {
        // Keep current session user type in sync for downstream role-based actions
        // (e.g., RPH verify popup password/store handling).
        this.loginUserType = userType;
        automationManager = AutomationManager.getInstance();

        loginPage = new LoginPage(userType);
        //loginPage.loginConnexus(userType);
        if (loginRequired) {
            loginPage.loginConnexus(userType);
        }
        loginRequired = true;

        connexusStartPage = new ConnexusStartPage();
        patientSearchPage = new PatientSearchPage();
        patientMaintenancePage = new PatientMaintenancePage();
        productSearchPage = new ProductSearchPage();
        patientProfileModel= new PatientProfileModel();
        prescriberSearchPage = new PrescriberSearchPage();
        productMaintenancePage = new ProductMaintenancePage();
        productSearchPage = new ProductSearchPage();
        dropOffPage = new DropOffPage();
        patient = new PatientProfileModel();
        addressModel = new AddressModel();
        contactModel=new ContactModel();
        patientIdentityModel = new PatientIdentityModel();
        patientMedicalConditionModel = new PatientMedicalConditionModel();
        payloadResource = new PayloadResource();
        orderSearch = new F6Search();
        rxSearch    = new F6Search(); // was declared but never initialised — NPE in TPFlowTestscripts
        tascoPage=new TascoPage();
        inputPage = new InputPage();
        fourPoint= new FourPoint();
        chkDur = new ChkDur();
        orderDetailsPage = new OrderDetailsPage();
        modifyDetails = new ModifyDetails();
        claimPage = new ClaimPage();
        dropRxModel = new DropRxModel();
        rxModel = new RxModel();
        rxLookUp = new RxLookUp();
        visVerPage = new VisVerPage();
        counselPage = new CounselPage();
        chkdurPage = new ChkDur();
        menuBar=new MenuBar();
        imzEventPage = new ImzEventPage();
        imzSettingsPage = new ImmunizationSettingsPage();
        resolutionPage = new ResolutionPage();
        consolidatedNotesPage = new ConsolidatedNotesPage();
        itemMaintenancePage = new ItemMaintenancePage();
        c2LogBookAdjustmentReasonPage = new CIILogBookAdjustmentReasonPage();
        eod = new EODPage();
        softAssert = new SoftAssert();
        otcBillingSettingPage= new OTCBillingSettingPage();
        cycleCountReportPage = new CycleCountReportPage();
        returnToInmarMckesPage=new ReturnToInmarMckesPage();
        itemMaintenancePage=new ItemMaintenancePage();
        c2LogBookAdjustmentReasonPage=new CIILogBookAdjustmentReasonPage();
        onHandInventoryDetailPage=new OnHandInventoryDetailPage();
        c2AdjustmentPage=new CIIAdjustmentPage();
        prescriberSearchPage = new PrescriberSearchPage();
        actionItemsPage = new ActionItemsPage();
        clinicalIntelligencePage= new ClinicalIntelligencePage();
        pickupPage = new PickupPage();
        payloadResource = new PayloadResource();
        tpExtraInfoPage = new TPExtraInfoPage();
        resolutionTPRejPage = new ResolutionTPRejPage();
        eTransferRequestPage = new ETransferRequestPage();
        faxInboxPage= new FaxInboxPage();
        DCTResolutionPage = new DCTResolutionPage();
    }

    public void initializeTestCase(boolean flushCache) {
        softAssert = new SoftAssert();
        rxNbr = null;
        orderId = 0;
        rxFillId = 0;

        if (flushCache) {
            Reporter.log("Restarting Connexus service to apply updated flags");
            relaunchConnexus = true;
            if (!connexusAPIManager.flushCache(siteIDString)) {
                Assert.fail("Flush Cache failed");
            }
        }

        if(isFirstTestCase || isExceptionCaptured || relaunchConnexus) {
            if (!loginRequired) {
                Log.info("skipping Connexus login in initialize test case");
            } else if (isFirstTestCase) {
                Reporter.log("Launching Connexus application for the first test case");
                Log.info("Launching Connexus application for the first test case");
            } else if (isExceptionCaptured) {
                Reporter.log("Exception captured in previous test case, so re-launching the Connexus application");
                Log.info("Exception captured in previous test case, so re-launching the Connexus application");
            } else {
                Reporter.log("Relaunching Connexus application as per test case requirement");
                Log.info("Relaunching Connexus application as per test case requirement");
            }
            loginConnexus(loginUserType);
            isExceptionCaptured = false;
            isFirstTestCase = false;
            relaunchConnexus = false;
        }
    }

    /**
     * Blocks until work-queue panel is visible (200s timeout for cold launch).
     * Call from @BeforeMethod after initializeTestCase(). Fails fast with screenshot on timeout.
     * Escapes back to home screen on test failure (max 5 iterations).
     * Each iteration: Escape → 3s wait → dismissPostEscapePopup(). Breaks early if no popup found.
     */
    public void escapeToHome() {
        for (int i = 0; i < 5; i++) {
            automationManager.performSleep(3);
            connexusStartPage.pressEscapeKey();
            automationManager.performSleep(3);
            boolean popupDismissed = connexusStartPage.dismissPostEscapePopup();
            Reporter.log("escapeToHome iteration " + (i + 1) + ": popup dismissed = " + popupDismissed);
            if (!popupDismissed) {
                Reporter.log("escapeToHome: no popup after Escape — home screen reached, stopping.");
                break;
            }
        }
    }

    public void waitForConnexusReady() {
        if (connexusStartPage.isConnexusLaunched()) {
            Reporter.log("Connexus ready.");
            return;
        }
        String stepName = "waitForConnexusReady";
        String screenshotPath = connexusStartPage.takeScreenShot(stepName).getValue();
        if (screenshotPath != null && !screenshotPath.isBlank()) {
            Reporter.logScreenShot(Status.FAIL, stepName, screenshotPath);
        } else {
            Reporter.log("waitForConnexusReady: screenshot unavailable (empty path).");
        }
        isExceptionCaptured = true;
        Assert.fail("Connexus did not become ready within 200 s. See logs/screenshot for evidence.");
    }

    public void initializeTestCase(boolean flushCache, boolean isConnexusLoginRequired) {
        loginRequired = isConnexusLoginRequired;
        initializeTestCase(flushCache);
    }

    /**
     * Method to Create New patient
     * arguments:
     *      inputData - patient information from input xls
     *      thirdPartyCount (optional) - 0 or not passed - Cash; 1 to 3 - patient created with number of TP plan passed
     * Updated: John vinothkumar(vn58my9)
     **/
    public void createNewPatient(Map<String, String> inputData) {
        createNewPatient(inputData,0,PatientProfileModel.PatientType.HUMAN);
    }
    public void createNewPatient(Map<String, String> inputData, int thirdPartyCount){
        createNewPatient(inputData,thirdPartyCount,PatientProfileModel.PatientType.HUMAN);
    }
    public void createNewPatient(Map<String, String> inputData, int thirdPartyCount, PatientProfileModel.PatientType patientType) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patient = new PatientProfileModel();
            addressModel = new AddressModel();
            thirdPartyModel = new ThirdPartyModel();
            contactModel = new ContactModel();
            patientIdentityModel = new PatientIdentityModel();
            patientMedicalConditionModel = new PatientMedicalConditionModel();

            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            //Patient Type selection
            if (patientType.equals(PatientProfileModel.PatientType.PET)) {
                patient.setPatientType(PatientProfileModel.PatientType.PET);
                //this code to be written generic when other pet types are added
                patient.setPetLiveStockInfo(PatientProfileModel.PetLiveStockInfo.CANINE);
                connexusAppUtils.addRandomNamesInFile(name[0], name[1] + "(CANINE)");
            } else {
                patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            }

            //Personal Information
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));

            if ("FEMALE".equals(inputData.get("GENDER"))) {
                patient.setPatientGender(PatientProfileModel.PatientGender.FEMALE);
            } else {
                patient.setPatientGender(PatientProfileModel.PatientGender.MALE);
            }
            connexusAppUtils.writeTextToFile("Creating new patient with " + thirdPartyCount + " thirdParty Carrier",
                    "Started", fileName, 0, null);

            //Address
            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE").trim());
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientInsulinInd(inputData.get("IS_INSULIN_SET"));
            patient.setPatientAddress(addressModel);

            //Contact Information

            if (StringUtils.isNotBlank(inputData.get("PRIMARY_NUMBER"))) {
                contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER").trim());
            }
            if (StringUtils.isNotBlank(inputData.get("ALTERNATE_NUMBER"))) {
                contactModel.setPatientAlternateNumber(inputData.get("ALTERNATE_NUMBER").trim());
            }
            if (StringUtils.isNotBlank(inputData.get("MESSAGING_NUMBER"))) {
                contactModel.setPatientMessagingNumber(inputData.get("MESSAGING_NUMBER").trim());
            }
            if (StringUtils.isNotBlank(inputData.get("CLINICAL_SERVICE_NUMBER"))) {
                contactModel.setClinicalServicesNumber(inputData.get("CLINICAL_SERVICE_NUMBER").trim());
            }
            patient.setPatientContact(contactModel);

            //Third Party Information
            switch (thirdPartyCount) {
                case 3: //fall through
                    thirdPartyModel.setCarrierBin3(inputData.get("TP_CARRIER_BIN_3"));
                    thirdPartyModel.setPlan3(inputData.get("TP_PLAN_3"));
                    thirdPartyModel.setCardId3(inputData.get("TP_CARD_ID_3"));
                    break;
                case 2: //fall through
                    thirdPartyModel.setCarrierBin2(inputData.get("TP_CARRIER_BIN_2"));
                    thirdPartyModel.setPlan2(inputData.get("TP_PLAN_2"));
                    thirdPartyModel.setCardId2(inputData.get("TP_CARD_ID_2"));
                    break;
                case 1:
                    thirdPartyModel.setCarrierBin(inputData.get("TP_CARRIER_BIN"));
                    thirdPartyModel.setPlan(inputData.get("TP_PLAN"));
                    thirdPartyModel.setCardId(inputData.get("TP_CARD_ID"));
                    Reporter.log("Creating Patient with " + thirdPartyCount + " Third Party Carrier.");
                    break;
                default:
                    Reporter.log("Creating patient with Carrier as Cash.");
                    break;
            }
            patient.setPatientTp(thirdPartyModel);

            //Patient Identity
            if ((inputData.get("LICENSE_NUMBER")) != null && !inputData.get("LICENSE_NUMBER").isEmpty()
                    && (inputData.get("LICENSE_EXPIRATION_DATE")) != null && !inputData.get("LICENSE_EXPIRATION_DATE").isEmpty()) {
                patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
                patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
                patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));
            }
            if (inputData.get("SSN") != null && !inputData.get("SSN").isEmpty()) {
                patientIdentityModel.setPatientSSNNumber(Long.parseLong(inputData.get("SSN")));
            }
            patient.setPatientIdentityModel(patientIdentityModel);

            //Patient Allergies
            if (inputData.get("ALLERGY_BUTTON") != null && inputData.get("ALLERGY_BUTTON").contains("YES")){
                patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.YES);
                patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            }
            if (inputData.get("PATIENT_NOT_PRESENT") != null && inputData.get("PATIENT_NOT_PRESENT").contains("NOTPRESENT")){
                patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.PATIENT_NOT_PRESENT);
                patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.PATIENT_NOT_PRESENT);
            }
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            if (connexusStartPage.isConnexusLaunched()) {
                automationManager.getConnexusWorkFlow().createNewPatient(thirdPartyCount > 0, patient);
                Reporter.log("Patient has been created.");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.fail("Connexus not launched");
            }
            connexusAppUtils.writeTextToFile("Created Patient  With " + name[1] + " " + name[0], "In progress",
                    fileName, 10, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Create Patient", "Failed", fileName, 10, DateTime.now());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            softAssert.fail(e.toString());
        }
    }

    /**
     * Method Name: addAllergyToPatientProfile
     *              to add any allergy in patients profile
     * arguments: inputData - "DOB" , "ALLERGY" and "ALLERGY_INDEX"
     *            must be there in associated sheet
     * Author: Niraj Kumar (vn50sfl)
     **/
    public void addAllergyToPatientProfile(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            String patientName = name[0] + "," + name[1];
            String patientDOB = inputData.get("DOB");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickAllergyMedicalTab();
            String reaction = inputData.get("REACTION");
            String allergy = inputData.get("ALLERGY");
            patientMaintenancePage.addAllergy(reaction,allergy);
            patientMaintenancePage.clickSaveAndClose();
            if (patientMaintenancePage.isSaveAsEnteredDisplayed()) {
                patientMaintenancePage.clickSaveAsEntered();
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to add allergy");
            Assert.fail(e.toString());
        }
    }

    /**
     * Method Name: performDropOff
     * to perform Drop Off RX
     * arguments: noOfRx (optional) - not passed - 1 RX;
     * Updated: John vinothkumar(vn58my9)
     **/
    public void performDropOff() {
        //Default to Critical
        performDropOff(Priority.Critical);
    }
    public void performDropOff(Priority priority) {
        //Default to one RX
        performDropOff(1,priority);
    }
    public void performDropOff( boolean isTamperResistant) {
        //Default to Critical
        performDropOff(Priority.Critical,isTamperResistant);
    }
    public void performDropOff(Priority priority, boolean isTamperResistant) {
        //Default to one RX
        performDropOff(1,priority,isTamperResistant);
    }

    public void performDropOff(int noOfRx,Priority priority,int noOfFutureDays) {
        performDropOff(noOfRx,priority,noOfFutureDays, RxOriginType.OriginalRx);
    }

    public void performDropOffWithRxOriginType(int noOfRx, Priority priority, RxOriginType rxOriginType) {
        int defaultNoOfFutureDays = 1;
        performDropOff(noOfRx, priority, defaultNoOfFutureDays, rxOriginType);
    }

    public void performDropOff(int noOfRx,Priority priority,int noOfFutureDays, RxOriginType rxOriginType) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(noOfRx);
            dropRxModel.setPriority(priority);
            dropRxModel.setRxOriginType(rxOriginType);
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel,noOfFutureDays);
            connexusAppUtils.writeTextToFile("DropOff Completed","In progress",fileName,20, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("DropOff Not completed","Failed",fileName,20, DateTime.now());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void performDropOff(int noOfRx,Priority priority,int noOfFutureDays,boolean isTamperResistant) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(noOfRx);
            dropRxModel.setPriority(priority);
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel,noOfFutureDays,isTamperResistant);
            connexusAppUtils.writeTextToFile("DropOff Completed","In progress",fileName,20, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("DropOff Not completed","Failed",fileName,20, DateTime.now());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void performDropOffForExistingPatient(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile(inputData.get("LAST_NAME"),inputData.get("FIRST_NAME"));
            dropRxModel.setPatientLastName(inputData.get("LAST_NAME"));
            dropRxModel.setPatientFirstName(inputData.get("FIRST_NAME"));
            dropRxModel.setDob(inputData.get("DOB"));
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().existingPatientDropOff(dropRxModel);
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performDropOff(int noOfRx,Priority priority) {
        int defaultNoOfFutureDays=1;
        performDropOff(noOfRx,priority,defaultNoOfFutureDays);
    }

    public void performDropOff(int noOfRx,Priority priority, boolean isTamperResistant) {
        int defaultNoOfFutureDays=1;
        performDropOff(noOfRx,priority,defaultNoOfFutureDays,isTamperResistant);
    }

    /**
     * Method Name: performInput (to perform Input)
     * arguments: inputType (optional) - DAW1 or BlankTMCode or LessThanSixMonth ;
     * Updated: John vinothkumar(vn58my9)
     **/
    public void performInput(Map<String, String> inputData) {
        performInput(inputData, "Regular", false);
    }

    public void performInput(Map<String, String> inputData, String inputType) {
        performInput(inputData, inputType, false);
    }

    public void performInput(Map<String, String> inputData, String inputType, boolean compoundDrug) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            if(compoundDrug){
                // Set compound drug flag and name in model
                rxModel.setCompoundDrug(true);
                String compoundName = inputData.get("COMPOUND_DRUG_NAME");
                rxModel.setCompoundDrugName(compoundName);
            }else{
                rxModel.setCompoundDrug(false);
                rxModel.setNdc(inputData.get("DRUG_NAME"));
            }
            rxModel.setPrescribedQty(inputData.get("QUANTITY"));
            automationManager.performSleep(10);
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setExpandedSig(inputData.get("EXPANDED_SIG"));
            rxModel.setDays(inputData.get("DAYS"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            automationManager.performSleep(10);
            String rxCommentValue= inputData.get("RX_COMMENT");
            if (rxCommentValue != null && !rxCommentValue.isEmpty()) {
                rxModel.setRxComment(rxCommentValue);
            }
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }

            if (isOrderInInputQueueDB(name[0], name[1], 1)) {
                automationManager.getConnexusWorkFlow().performInput(rxModel, inputType);
            } else {
                Reporter.log("RX is not in Input queue");
                Assert.fail("RX is not in Input queue");
            }

            rxNbr = getRxNbr(name[0] , name[1], siteId);
            if (rxNbr == null || rxNbr.isEmpty()) {
                Reporter.log("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                Assert.fail("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
            }
            Reporter.log("In "+ currentStepMethodName + " Method, Rx number is " + rxNbr);

            connexusAppUtils.writeTextToFile("Input Completed","In progress",fileName,30, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Input not Completed","Failed",fileName,30, DateTime.now());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether the RX in 4 point Queue
     **/
    public void verifyRxIn4PointQueue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0] , name[1], siteId);
            if (rxNbr == null || rxNbr.isEmpty()) {
                Reporter.log("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                Assert.fail("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
            }
            Reporter.log("In "+ currentStepMethodName + " Method, Rx number is " + rxNbr);
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.wm4PointCheck.getValue())){
                takeScreenShotRXStatus(rxNbr,WorkQueue.FOUR_POINT.getWorkQueue(),currentStepMethodName,Status.PASS);
                Assert.assertTrue(true);
                Reporter.log("RX is in 4 point queue");
            }else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in 4 Point Queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at verify 4 Point queue");
            connexusAppUtils.writeTextToFile("verify 4 Point queue failed","Failed",fileName,0, DateTime.now());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void perform4Point() {
        perform4Point(false,false);
    }
    public void perform4Point(boolean contDrug) {
        perform4Point(contDrug,false);
    }
    public void perform4Point(boolean ContDrug,boolean flagDUR){
        perform4Point( ContDrug, flagDUR, null, false);
    }
    /**
     * Method to perform 4 point for Cash and TP patients
     * arguments - contDrug (controlled) - True/False
     *         flagDUR - True/False (to perform DUR check or not)
     *         inputData - patient information from input xls
     *         tpPatient - True/False (if patient created with TP details or not)
     **/
    public void perform4Point(boolean contDrug,boolean flagDUR, Map<String, String> inputData, boolean tpPatient) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            Reporter.log("Name: " + name[0] + " " + name[1]);
            if (rxNbr == null || rxNbr.isEmpty()) {
                rxNbr = getRxNbr(name[0] , name[1], siteId);
                if (rxNbr == null || rxNbr.isEmpty()) {
                    Reporter.log("Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                    Assert.fail("Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                }
                Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
            }

            if(checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point "+rxNbr,"In progress",fileName,40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    if (tpPatient) {
                        captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "Patient created with TP details, " +
                                "so it should not move to Resolve queue");
                    } else {
                        Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                        performResolveQueue(rxNbr);
                    }
                }
            }

            if(checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(),ConnexusConstants.WAIT_TIMEOUT_30)) {
                if (contDrug) {
                    Reporter.log("Controlled Drug");
                    orderSearch.launchOrderSearchScreen();
                    orderSearch.performSearch(rxNbr);
                    String productName = orderSearch.getProductName(0);
                    orderSearch.closeSearch();
                    rxNbr = automationManager.getConnexusWorkFlow().performFourPointForControlledDrug(rxNbr, productName, flagDUR);
                    dropOffPage.handleEarlyRefillReason();
                } else {
                    Reporter.log("Non Controlled Drug");
                    rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(rxNbr,inputData,false, flagDUR);
                }
                connexusAppUtils.writeTextToFile("4 point Completed "+rxNbr,"In progress",fileName,40, DateTime.now());
            }else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in 4 Point Queue to proceed");
            }

            if (fourPoint.isElementDisplayed(fourPoint.cmbReason, ConnexusConstants.WAIT_TIMEOUT_5)) {
                fourPoint.selectEarlyRefillReson();
                fourPoint.clickOkInEarlyRefillPopUp();
            }

        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            connexusAppUtils.writeTextToFile("4 point not Completed "+rxNbr,"Failed",fileName,40, DateTime.now());
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void perform4PointWithRxNbr(String rxNbr) {
        F6Search orderSearch = new F6Search();
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(20);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            automationManager.getConnexusWorkFlow().performFourPoint(rxNbr);
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }
    }

    /**
     * Method to perform 4 point for TP patients,
     * arguments - contDrug (controlled) - True/False
     **/
    public void perform4PointForTPPatient(boolean contDrug) {
        perform4Point(contDrug, false, null, true); //flagDUR false, inputData null and tpPatient true
    }

    /**
     * Method to perform Check DUR
     **/
    public void performChkDUR() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())){
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
                connexusAppUtils.writeTextToFile("Completed ChkDUR "+rxNbr,"In progress",fileName,50, DateTime.now());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to perform Filling
     **/
    public void performFilling() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            performChkDUR();

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue())) {
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            } else {
                performResolveQueue(rxNbr);
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue())) {
                    if(!automationManager.getConnexusWorkFlow().completeFilling(rxNbr)){
                        captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "Filling not completed for RX: " + rxNbr);
                    } else {
                        Reporter.log("Filling completed for RX: " + rxNbr);
                    }
                } else {
                    captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in Filling queue");
                }
            }
            Reporter.log("Filling Completed, RxNbr: "+rxNbr);
            connexusAppUtils.writeTextToFile("Filling Completed, RxNbr: "+rxNbr,"In progress",fileName,60, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Filling queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Filling notCompleted "+rxNbr,"Failed",fileName,60, DateTime.now());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to perform Filling with RX number as argument
     **/
    public void performFillingWithRxNbr(String rxNbr) {
        this.rxNbr = rxNbr;
        performFilling();
    }

    /**
     * Method to verify whether the RX in Filling Queue
     **/
    public void verifyRxInFillingQueue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0] , name[1], siteId);
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.WorkQueueFill.getValue())){
                takeScreenShotRXStatus(rxNbr,WorkQueue.FILLING.getWorkQueue(),currentStepMethodName,Status.PASS);
                Assert.assertTrue(true);
                Reporter.log("RX is in Filling queue");
            }else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in Filling Queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at verify Filling queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to perform Visual Verify
     **/
    public void performVisualVerify() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.VisualVerify.getValue())) {
                automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
            } else {
                performResolveQueue(rxNbr);
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.VisualVerify.getValue())) {
                    automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
                } else {
                    captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in Visual Verify queue");
                }
            }

            connexusAppUtils.writeTextToFile("Visual Verification Completed "+rxNbr,"In progress",fileName,70, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Visual Verification Not Completed "+rxNbr,"Failed",fileName,70, DateTime.now());
            Reporter.log("Test failed at Visual Verify queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to perform Visual Verify with RX number as argument
     **/
    public void performVisualVerifyWithRxNbr(String rxNbr) {
        this.rxNbr = rxNbr;
        performVisualVerify();
    }

    /**
     * Method to perform Pickup
     **/
    public void performPickUp(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Pickup.getValue())) {
                automationManager.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("DOB"), rxNbr);
            } else {
                performResolveQueue(rxNbr);
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Pickup.getValue())) {
                    automationManager.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("DOB"), rxNbr);
                }else {
                    captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in PickUp queue");
                }
            }
            connexusAppUtils.writeTextToFile("Pickup Completed "+rxNbr,"In progress",fileName,80, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Pickup not Completed "+rxNbr,"Failed",fileName,80, DateTime.now());
            Reporter.log("Test failed at PickUp queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void performPickUp(String rxNbr, Map<String, Object> patientData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String patientFirstName = patientData.get("first_name").toString().trim();
            String patientLastName = patientData.get("last_name").toString().trim();
            String patientDobTxt = patientData.get("birth_date").toString().trim().split("-")[1] + "/" +
                    patientData.get("birth_date").toString().trim().split("-")[2] + "/" +
                    patientData.get("birth_date").toString().trim().split("-")[0];
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Pickup.getValue())) {
                automationManager.getConnexusWorkFlow().completePickup(patientFirstName, patientLastName, patientDobTxt, rxNbr);
            } else {
                performResolveQueue(rxNbr);
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Pickup.getValue())) {
                    automationManager.getConnexusWorkFlow().completePickup(patientFirstName, patientLastName, patientDobTxt, rxNbr);
                }else {
                    captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in PickUp queue");
                }
            }
            connexusAppUtils.writeTextToFile("Pickup Completed "+rxNbr,"In progress",fileName,80, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Pickup not Completed "+rxNbr,"Failed",fileName,80, DateTime.now());
            Reporter.log("Test failed at PickUp queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to perform Counselling
     **/
    public void performCounselling() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String message;
        try {
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.Counseling.getValue())) {
                automationManager.getConnexusWorkFlow().completeCounsel(rxNbr);
            } else {
                if(performResolveQueue(rxNbr)) {
                    if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Counseling.getValue())) {
                        automationManager.getConnexusWorkFlow().completeCounsel(rxNbr);
                    } else {
                        Reporter.log("Moving RX from Resolve to Counsel queue failed");
                        takeScreenShotRXStatus(rxNbr,null,currentStepMethodName,Status.FAIL);
                        Assert.fail("Moving RX from Resolve to Counsel queue failed");
                    }
                }else{
                    if (checkOrderNextWorkQueueDB(rxNbr).equals(WorkQueueSettings.Pickup.getValue())){
                        message = "RX is still in Pickup queue";
                    } else {
                        message = "RX is not in Counselling or Resolve queue";
                    }
                    captureUnExpectedQueueResults(rxNbr, currentStepMethodName, message);
                }
            }
            connexusAppUtils.writeTextToFile("Counselling Completed "+rxNbr,"In progress",fileName,90, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Counselling Not Completed "+rxNbr,"Failed",fileName,90, DateTime.now());
            Reporter.log("Test failed at Counselling queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to perform Resolve Queue
     **/
    public boolean performResolveQueue(String rxNbr){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try{
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.TroubleShooting.getValue(),ConnexusConstants.WAIT_TIMEOUT_10)) {
                Reporter.log("RX is in Resolve queue");
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                return true;
            }
        }
        catch(Throwable e){
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Failed in Resolve Queue Method, RX "+rxNbr,"Failed",fileName,0, DateTime.now());
            Reporter.log("Test failed at Resolve queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
        return false;
    }

    /**
     * Method to perform POS
     **/
    public void performPOS() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.POS.getValue())) {
                automationManager.getConnexusWorkFlow().completeOfflineSale(rxNbr);
            } else {
                performResolveQueue(rxNbr);
                if (checkOrderQueueDB(rxNbr,WorkQueueSettings.POS.getValue())) {
                    automationManager.getConnexusWorkFlow().completeOfflineSale(rxNbr);
                }else {
                    captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in POS queue");
                }
            }
            connexusAppUtils.writeTextToFile("POS Completed "+rxNbr,"Passed",fileName,100, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("POS Not Completed " + rxNbr, "Failed", fileName, 0, DateTime.now());
            Reporter.log("Test failed at POS queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to perform EOD
     **/
    public void verifyRxInEOD() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.EOD.getValue())){
                takeScreenShotRXStatus(rxNbr,WorkQueue.EOD.getWorkQueue(),currentStepMethodName,Status.PASS);
                Assert.assertTrue(true);
                Reporter.log("RX is in EOD queue");
            } else {
                performResolveQueue(rxNbr);
                if (checkOrderQueueDB(rxNbr,WorkQueueSettings.EOD.getValue())){
                    takeScreenShotRXStatus(rxNbr,WorkQueue.EOD.getWorkQueue(),currentStepMethodName,Status.PASS);
                    Assert.assertTrue(true);
                    Reporter.log("RX is in EOD queue");
                } else {
                    captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in EOD queue");
                }
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at EOD queue");
            connexusAppUtils.writeTextToFile("EOD Not Completed " + rxNbr, "Failed", fileName, 0, DateTime.now());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to take Screenshots, compares the work queue
     **/
    public void takeScreenShotRXStatus(String rxNbr,String queue,String currentStepMethodName,Status status) {
        String currentStepMethodNames = StackUtils.getCurrentMethodName();
        if (orderSearch == null) {
            orderSearch = new F6Search();
        }
        try{
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            if (queue != null) {
                if (queue.equalsIgnoreCase(orderSearch.getWorkQueue(0))) {
                    Reporter.logScreenShot(status, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                } else {
                    Reporter.logScreenShot(Status.WARNING, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                }
            }else {
                Reporter.logScreenShot(status, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            }
            orderSearch.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodNames, orderSearch.takeScreenShot(currentStepMethodNames).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to perform Drop Off for RX which created and picked up earlier with zero refill
     **/
    public void performDropOffForRXWithNoRefills() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickOKonRefillRequestPopUp();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickSendToResolutionOnFaxSendPopUp();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickYesOnFaxNumberPopUp();
            dropOffPage.selectPriority("Critical");
            dropOffPage.clickBtnAccept();
            dropOffPage.handleStorePickupTimePopup();
            Reporter.log("Drop-Off completed");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("DropOff For RX With NoRefills not completed "+rxNbr,"Failed",fileName,0, DateTime.now());
            Reporter.log("DropOff For RX With NoRefills failed");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to perform Drop Off for RX which created and picked up earlier with > 0 refill
     **/
    public void performDropOffForRXWithRefills() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            dropOffPage.checkAndClickDropOffStation();
            dropOffPage.handleEarlyRefillReason();
            dropOffPage.clickOutOFFStock();
            dropOffPage.selectPriority("Critical");
            dropOffPage.clickBtnAccept();
            dropOffPage.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("DropOff For RX With Refills not completed "+rxNbr,"Failed",fileName,0, DateTime.now());
            Reporter.log("DropOff For RX With Refills failed");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to verify whether the RX is in RESOLVE Queue
     **/
    public void verifyIfRxIsInResolutionQueue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            Assert.assertEquals(orderSearch.getWorkQueue(0).toLowerCase(), WorkQueue.RESOLVE.getWorkQueue());
            Assert.assertEquals(orderSearch.getProblemMessage(0), "Need to Call Doctor for Refills");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            orderSearch.closeSearch();
            Reporter.log("RX is in Resolution Queue");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("verify Rx is in Resolution Queue not completed "+rxNbr,"Failed",fileName,0, DateTime.now());
            Reporter.log("verify Rx is in Resolution Queue failed");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to switch the payment from TP to CASH
     **/
    public void switchToCASHFromTP() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            performResolveQueue(rxNbr);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.switchPaymentPlan("CASH");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickAccept();
                modifyDetails.selectReasonForPaymentSwitch(); //found it's an optional popup
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being sent to the \n" + "Filling queue.");
                modifyDetails.checkAndClickWarning();
                connexusAppUtils.writeTextToFile("TP to CASH Completed "+rxNbr,"Passed",fileName,0, DateTime.now());
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in Filling queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("switch To CASH From TP not completed "+rxNbr,"Failed",fileName,0, DateTime.now());
            Reporter.log("switch To CASH From TP failed");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * This captureUnExpectedQueueResults method is used to capture the unexpected results
     * Author: John vinothkumar(vn58my9)
     **/
    public void captureUnExpectedQueueResults(String rxNbr, String currentStepMethodName, String message) {
        Reporter.log("Test failed at " + currentStepMethodName + ", " + message);
        takeScreenShotRXStatus(rxNbr, null, currentStepMethodName, Status.FAIL);
        connexusAppUtils.writeTextToFile(message, "Failed", fileName, 0, DateTime.now());
        Assert.fail(message);
    }

    /**
     * Method to switch the patient payment from CASH to TP when the next work queue is Filling
     **/
    public void switchToTPFromCASH(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            performResolveQueue(rxNbr);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CashOnNetwork.getValue(),ConnexusConstants.WAIT_TIMEOUT_30)) {
                Reporter.log("RX is in CASH queue");
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue(),ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.selectClaimsDropDown();
                String planName = inputData.get("TP_CARRIER_BIN") + " / " + inputData.get("TP_PLAN") + " / " + inputData.get("TP_CARD_ID");
                modifyDetails.switchToInsurance(planName);
                modifyDetails.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being sent to the \n" + "Third Party queue.");
                modifyDetails.clickOnConnexusPopUp();
                modifyDetails.checkAndClickWarning();
                connexusAppUtils.writeTextToFile("CASH to TP Completed "+rxNbr,"Passed",fileName,0, DateTime.now());
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in Filling queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("switch To TP From CASH not completed "+rxNbr,"Failed",fileName,0, DateTime.now());
            Reporter.log("switch To TP From CASH failed");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to change the TP plan when order in FOUR POINT
     **/
    public void changeTPPlanIn4Point(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0] , name[1], siteId);
            Reporter.log("In "+ currentStepMethodName + " Method, Rx number is " + rxNbr);

            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.wm4PointCheck.getValue(),ConnexusConstants.WAIT_TIMEOUT_40)){
                Reporter.log("RX in 4 Point");
            }else {
                performResolveQueue(rxNbr);
            }

            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.wm4PointCheck.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                orderSearch.openFirstPatientRecord();
                modifyDetails.launchModifyDetailScreen();
                modifyDetails.selectClaimsDropDown();
                String planName = inputData.get("TP_CARRIER_BIN") + " / " + inputData.get("TP_PLAN") + " / " + inputData.get("TP_CARD_ID");
                modifyDetails.switchToInsurance(planName);
                modifyDetails.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being sent to the \n" + "Third Party queue.");
                modifyDetails.clickOnConnexusPopUp();
                modifyDetails.checkAndClickWarning();
                connexusAppUtils.writeTextToFile("TP to TP Completed "+rxNbr,"Passed",fileName,0, DateTime.now());
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in 4 Point queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("change TP Plan in 4Point not completed "+rxNbr,"Failed",fileName,0, DateTime.now());
            Reporter.log("change TP Plan in 4Point failed");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Method to change the payment from TP to CASH in patient profile screen
     **/
    public void changePaymentFromTPtoCASHForAPatient() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage = new PatientSearchPage();
            patientMaintenancePage = new PatientMaintenancePage();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.inputPatientDob(patient.getPatientDob());
            patientSearchPage.clickSearchNow();
            softAssert.assertTrue(patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(name[0] + "," + name[1]));
            patientSearchPage.openFirstPatientRecord();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.switchPaymentMethodFromTPtoCASH();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            connexusAppUtils.writeTextToFile("TP to CASH Completed "+rxNbr,"Passed",fileName,0, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Change Payment From TP to CASH not completed "+rxNbr,"Failed",fileName,0, DateTime.now());
            Reporter.log("Change Payment From TP to CASH failed");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void switchToCashWithRxNbr(String rxNbr){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(20);
            }
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            patientSearchPage.openFirstPatientRecord();
            if (resolutionPage.isElementDisplayed(resolutionPage.btnSwithtoCash)) {
                resolutionPage.clickSwitchToCashButton();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.selectReasonForSwitchToCash();
                automationManager.performSleep(5);
                modifyDetails.checkAndClickWarning();
            }else {
                Assert.fail("Switch to cash failed, button not displayed");
                Reporter.log("Switch to cash failed, button not displayed");
            }
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Method to get the order work queue and compare against the queue passed and returns true/false
     * Defaults the timeLimit for polling as 30 seconds
     * Author: John vinothkumar(vn58my9)
     **/
    public boolean checkOrderQueueDB(String rxNbr,int queue) {
        //default 60 seconds
        return checkOrderQueueDB(rxNbr,queue, ConnexusConstants.WAIT_TIMEOUT_60);
    }

    /**
     * Method to get the order work queue and compare against the queue passed and returns true/false
     * arguments - rxNbr, queue to be compared and timeLimit for polling
     * calls the checkOrderNextWorkQueue method using Poller class with timeLimit and poll interval (default 500 milliseconds)
     * Author: John vinothkumar(vn58my9)
     **/
    public boolean checkOrderQueueDB(String rxNbr,int queue,int timeLimit) {
        int defaultPollInterval = 500;
        try{
            startTime = (int) (System.currentTimeMillis() / 1000);
            Poller poller = new Poller(timeLimit, defaultPollInterval);
            return poller.pollForSuccess(() -> checkOrderNextWorkQueueDB(rxNbr, queue));
        } catch (Throwable e) {
            Assert.fail(e.toString());
        }
        return false;
    }

    /**
     * Method to get the order work queue status from DB and returns true if matches with the queue passed
     * arguments - siteID, rxNbr, and queue to be compared
     * Author: John vinothkumar(vn58my9)
     **/
    public boolean checkOrderNextWorkQueueDB(String rxNbr,int queue) {
        int workQueueCode = 0;
        automationManager=AutomationManager.getInstance();
        try {
            String query = "select next_work_que_code from rx_order_detail rod join rx rx1 on rx1.rx_id = rod.rx_id where rx1.rx_nbr = "
                    + rxNbr +" and rod.rx_fill_id = (select MAX(rx_fill_id) from rx_order_detail rod1 where rod1.rx_id = rx1.rx_id );";
            Map<String, Object> rxInfo = automationManager.getConnexusDB(siteId).executeQuery(query);
            if (rxInfo != null && !rxInfo.isEmpty() && rxInfo.get("next_work_que_code") != null) {
                workQueueCode = Integer.parseInt(rxInfo.get("next_work_que_code").toString());
            }
            keepTheWinDriverSessionActive();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return workQueueCode == queue;
    }

    // Method to get the IMZ order work queue
    public boolean ischeckIMZOrderQueueDB(String rxNbr,int queue) {
        //default 60 seconds
        return ischeckIMZOrderQueueDB(rxNbr,queue, ConnexusConstants.WAIT_TIMEOUT_60);
    }

    /**
     * Method to get the order work queue status and returns true if matches with the queue passed
     * arguments - rxNbr, queue to be compared, timeLimit for polling
     * calls the ischeckIMZOrderNextWorkQueueDB method using Poller class with timeLimit and poll interval
     **/
    public boolean ischeckIMZOrderQueueDB(String rxNbr, int queue, int timeLimit) {
        int defaultPollInterval = 500;
        try {
            startTime = (int) (System.currentTimeMillis() / 1000);
            Poller poller = new Poller(timeLimit, defaultPollInterval);
            return poller.pollForSuccess(() -> ischeckIMZOrderNextWorkQueueDB(rxNbr, queue));
        } catch (Throwable e) {
            Assert.fail(e.toString());
        }
        return false;
    }

    /**
     * Method to get the work queue status for IMZ from DB.
     * arguments - rxNbr, queue to be compared
     * @return true if matches with the queue passed
     */
    public boolean ischeckIMZOrderNextWorkQueueDB(String rxNbr, int queue) {
        Map<String, Integer> value = new HashMap<>();
        int workQueueCode = 0;
        automationManager = AutomationManager.getInstance();
        try {
            value = connexusAppUtils.getRxIdAndRxFillIdAndOrderSeqNbr(siteId, rxNbr);
            int orderId = value.get("orderId");
            int orderSeqNbr = value.get("orderSeqNbr");
            String query = "select next_work_que_code from svc_order_detail where order_id = " + orderId + " and ord_seq_nbr = "  + orderSeqNbr + ";" ;
            Map<String, Object> rxInfo = automationManager.getConnexusDB(siteId).executeQuery(query);
            if (rxInfo != null && !rxInfo.isEmpty() && rxInfo.get("next_work_que_code") != null) {
                workQueueCode = Integer.parseInt(rxInfo.get("next_work_que_code").toString());
            }
            keepTheWinDriverSessionActive();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return workQueueCode == queue;
    }

    /**
     *  Open Patient Maintenance page Patient
     */
    public void launchPatientMaintenancePage() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRow(0);
        }catch(Exception e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("PTMS screen not launched");
        }
    }

    public void searchPatient() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.doubleClickOnSearchGridRow(0);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*------------------------------------

   This Method will click on Third Party button and then click on check splitBill and then will close the window

   * Author: Priyam Raj(vn8p0t)

   * -----------------------------------*/
    public void clickonSplitBoxCheck() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try
        {
            launchPatientMaintenancePage();
            patientMaintenancePage.clickOnchkSplitBill();
            Reporter.log("Clicked on Check Split Bill");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickbtnAcceptOnThirdPartyEdit();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("\" Primary Method\" pop up is displayed");
            patientMaintenancePage.clickYes();
            Reporter.log("Payment Method is updated");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            connexusStartPage.pressEscapeKey();
        }catch(Exception e){
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Unable to click on Split bill checkbox on TP Edit Screen");
        }
    }

    /**
     * Method to get the order work queue status from DB
     * arguments - rxNbr, and returns the work queue code
     * Author: John vinothkumar(vn58my9)
     **/
    public Integer checkOrderNextWorkQueueDB(String rxNbr) {
        int workQueueCode = 0;
        try {
            String query = "select next_work_que_code from rx_order_detail rod join rx rx1 on rx1.rx_id = rod.rx_id where rx1.rx_nbr = " + rxNbr +" and rod.rx_fill_id = (select MAX(rx_fill_id) from rx_order_detail rod1 where rod1.rx_id = rx1.rx_id );";
            Map<String, Object> rxInfo = automationManager.getConnexusDB(siteId).executeQuery(query);
            if (rxInfo != null && !rxInfo.isEmpty() && rxInfo.get("next_work_que_code") != null) {
                workQueueCode = Integer.parseInt(rxInfo.get("next_work_que_code").toString());
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return workQueueCode;
    }

    /**
     * Cancelled the filled prescription.
     *
     */
    public void cancelFilledPrescription() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            visVerPage.clickCancelButtonOnPopUp();
            menuBar.selectNavigation(AppMenu.RETURN_TO_STOCK, AppMenuItemsIndex.CURRENTRX_CANCEL_FILL, AppMenuSubItemsIndex.RETURN_TO_STOCK, null);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            visVerPage.clickYes();
            visVerPage.clickNo();
            connexusStartPage.pressEscapeKey();
        }
        catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Cancel Fill prescription not working");
        }
    }

    /**
     * Method to check whether Order is in Input Queue using DB data with Polling
     * arguments - lastName, firstName and seqNbr, and returns true/false
     * Author: John vinothkumar(vn58my9)
     */
    public boolean isOrderInInputQueueDB(String lastName, String firstName, int seqNbr) {
        int defaultPollInterval = 500; // 500 milliseconds
        try {
            startTime = (int) (System.currentTimeMillis() / 1000);
            Poller poller = new Poller(ConnexusConstants.WAIT_TIMEOUT_120, defaultPollInterval);
            return poller.pollForSuccess(() -> isOrderInWorkQueueDB(lastName, firstName, seqNbr, WorkQueueSettings.Input.getValue()));
        } catch (Throwable e) {
            Assert.fail(e.toString());
        }
        return false;
    }

    /**
     * Method to get the order work queue status from DB
     * arguments - lastName, firstName and seqNbr, and returns the work queue code
     * Author: John vinothkumar(vn58my9)
     */
    public boolean isOrderInWorkQueueDB(String lastName, String firstName, int seqNbr, int queue) {
        int workQueueCode = 0;
        try {
            String query = "select next_work_que_code from rx_order_detail where order_id = (" +
                    "select max(od.order_id) from rx_order_detail od " +
                    "join rx r1 on r1.rx_id = od.rx_id " +
                    "join patient p1 on p1.patient_id = r1.patient_id " +
                    "where p1.last_name = \"" + lastName.toUpperCase() + "\" " +
                    "and p1.first_name = \"" + firstName.toUpperCase() + "\") " +
                    "and order_seq_nbr = " + seqNbr;
            Map<String, Object> rxInfo = automationManager.getConnexusDB(siteId).executeQuery(query);
            if (rxInfo != null && !rxInfo.isEmpty() && rxInfo.get("next_work_que_code") != null) {
                workQueueCode = Integer.parseInt(rxInfo.get("next_work_que_code").toString());
            }
            keepTheWinDriverSessionActive();
        } catch (Exception e) {
            Reporter.log("Exception checking next work Queue in DB: " + e.getMessage());
        }
        return workQueueCode == queue;
    }

    /**
     * Method to get RX number for a patient with retry logic
     * This method executes a SQL query with retry mechanism (10 attempts with 500 milliseconds interval)
     *
     * @param firstName - Patient's first name
     * @param lastName - Patient's last name
     * @param siteId - Store/site ID
     * @return RX number as String, or null if not found after all retries
     * Author: John vinothkumar(vn58my9)
     */
    public String getRxNbr(String lastName, String firstName, int siteId) {
        return getRxNbrWithRetry(firstName, lastName, siteId, 10, 500);
    }

    /**
     * Enhanced method to get RX number for a patient with retry logic and custom parameters
     * This overloaded method allows customization of retry attempts and interval
     *
     * @param firstName - Patient's first name
     * @param lastName - Patient's last name
     * @param siteId - Store/site ID
     * @param maxRetries - Maximum number of retry attempts
     * @param retryIntervalMs - Retry interval in milliseconds
     * @return RX number as String, or null if not found after all retries
     * Author: John vinothkumar(vn58my9)
     */
    public String getRxNbrWithRetry(String firstName, String lastName, int siteId, int maxRetries, int retryIntervalMs) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();

        String newRxNbr = null;

        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                Log.info("[DB_QUERY] Attempt " + attempt + "/" + maxRetries + " - Querying RX number for patient: " + firstName + " " + lastName);

                // Step 1: patient table lives in the shared DB (no siteId)
                // Escape single quotes to prevent SQL injection / quote-breaking on names like O'Brien
                String safeLastName = lastName == null ? "" : lastName.toUpperCase().replace("'", "''");
                String safeFirstName = firstName == null ? "" : firstName.toUpperCase().replace("'", "''");

                String patientQuery = "select first 1 patient_id from patient " +
                        "where last_name='" + safeLastName + "' " +
                        "and first_name='" + safeFirstName + "' " +
                        "order by patient_id desc";
                Map<String, Object> patientInfo = automationManager.getConnexusDB().executeQuery(patientQuery);

                if (patientInfo != null && !patientInfo.isEmpty() && patientInfo.get("patient_id") != null) {
                    String patientId = patientInfo.get("patient_id").toString();
                    Log.info("[DB_QUERY] Found patient_id: " + patientId + " for patient: " + firstName + " " + lastName);

                    // Step 2: rx table lives in the site-specific DB (with siteId)
                    String rxQuery = "select first 1 rx_nbr from rx " +
                            "where patient_id = " + patientId + " " +
                            "order by rx_id desc";
                    Map<String, Object> rxInfo = automationManager.getConnexusDB(siteId).executeQuery(rxQuery);

                    if (rxInfo != null && !rxInfo.isEmpty() && rxInfo.get("rx_nbr") != null) {
                        newRxNbr = rxInfo.get("rx_nbr").toString();
                        Reporter.log("[DB_QUERY] SUCCESS - Found RX number: " + newRxNbr + " on attempt " + attempt);
                        break;
                    } else {
                        Log.info("[DB_RETRY] Attempt " + attempt + " - patient_id found but no RX yet. Retrying in " + retryIntervalMs + "ms...");
                    }
                } else {
                    Log.info("[DB_RETRY] Attempt " + attempt + " - No patient found for: " + firstName + " " + lastName + ". Retrying in " + retryIntervalMs + "ms...");
                }

            } catch (Exception e) {
                Log.info("[DB_ERROR] Attempt " + attempt + " failed with error: " + e.getMessage());

                if (attempt >= maxRetries) {
                    Log.info("[DB_ERROR] All " + maxRetries + " attempts exhausted. Unable to retrieve RX number for patient: " + firstName + " " + lastName);
                    throw new RuntimeException("Failed to retrieve RX number after " + maxRetries + " attempts", e);
                }
            }

            // Wait before next retry (except for the last attempt)
            if (attempt < maxRetries && newRxNbr == null) {
                try {
                    Thread.sleep(retryIntervalMs);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    Log.info("[DB_ERROR] Retry interrupted for patient: " + firstName + " " + lastName);
                    throw new RuntimeException("Database query retry interrupted", ie);
                }
            }
        }

        if (newRxNbr == null) {
            Reporter.log("[DB_ERROR] Failed to retrieve RX number for patient: " + firstName + " " + lastName + " after " + maxRetries + " attempts");
        }

        return newRxNbr;
    }

    public void keepTheWinDriverSessionActive(){
        currentTime = (int) (System.currentTimeMillis() / 1000);
        if ((currentTime - startTime) > 10) {
            connexusStartPage = new ConnexusStartPage();
            connexusStartPage.getTextFromMainScreenTitleBar();
            startTime = (int) (System.currentTimeMillis() / 1000);
        }
    }

    public void validateResolutionOnDUR(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                ChkDur dur = new ChkDur();
                String message = inputData.get("MESSAGE");
                if (dur.isCheckDUREligible(rxNbr)) {
                    orderSearch.launchOrderSearchScreen();
                    orderSearch.performSearch(rxNbr);
                    orderSearch.selectRowFromSearch(0);
                    if (!modifyDetails.sendToResolution(message)) {
                        Assert.fail("Send to Resolution failed from CHkDUR");
                    }
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    modifyDetails.clickAccept();
                    performResolveQueue(rxNbr);
                    resolutionPage = new ResolutionPage();
                    resolutionPage.clickProblemResolved();
                    resolutionPage.clickreturnToInput();
                    Reporter.log("Rx is dropped into Input Queue since Return To Input is selected");
                }
                else {
                    Reporter.logScreenShot("Rx status",chkdurPage.takeScreenShot());
                    Assert.fail("RX is not in CHkDUR queue");
                }
            }
        }
        catch(Throwable e){
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR (Resolution) queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyRXInInputQueue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try {
            if (isOrderInInputQueueDB(name[0],name[1],1)) {
                Reporter.log("RX is in Input queue");
            } else {
                Reporter.log("RX is not in Input queue");
                Assert.fail("RX is not in Input queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Verify Rx in Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*
     * Method to create new patient, drop RX and move till EOD using API
     */
    public void createPatientAndMoveToEodUsingApi(Map<String,String> inputData, int strNbr , int requestTypeCode, int priorityId , int dispenseType) {
        try {
            ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
            InputResponse inputResp = new InputResponse();
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            ServiceResponse resp;
            String lastName = name[0];
            String firstName = name[1];

            Long homePhone = Long.parseLong(inputData.get("PRIMARY_NUMBER"));
            Long workPhone = Long.parseLong(inputData.get("PRIMARY_NUMBER"));
            Long cellPhone = Long.parseLong(inputData.get("PRIMARY_NUMBER"));
            resp = connexusAPIManager.createPatient(firstName, lastName, inputData.get("inputDob"), strNbr, homePhone, workPhone, cellPhone);
            Assert.assertEquals(resp.getStatusCode(), 201, "Create Patient details" + resp.getDataResponse());

            inputResp = resp.getDataResponse(InputResponse.class);
            int patientId = inputResp.getPatientId();
            Reporter.log("New patient created with patientId = " + patientId);
            IDatabaseContext cnx = automationManager.getConnexusDB(siteId);

            //get drug details
            DataRow drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("NDC_NUMBER"));

            // Get current time in UTC and set the pickup and expiration dates
            ZonedDateTime utcNow = ZonedDateTime.now(ZoneId.of("UTC"));
            //Expiration Date is set to 6 months later from the current date
            ZonedDateTime ExpirationDayCount = utcNow.plusMonths(6);
            ZonedDateTime PickUpDayCount = utcNow.plusDays(1);

            // Format: "MMM dd yyyy HH:mm:ss.SSS z"
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd yyyy HH:mm:ss.SSS z", Locale.ENGLISH);

            String PickUpDate = PickUpDayCount.format(formatter);
            String ExpirationDate = ExpirationDayCount.format(formatter);
            ServiceResponse resp1 = connexusAPIManager.newOrderToEOD(requestTypeCode, priorityId, dispenseType, patientId, strNbr, PickUpDate, ExpirationDate, Integer.parseInt(inputData.get("REFILLS")), drugInfo);
            Assert.assertEquals(resp1.getStatusCode(), 201, "Order creation details" + resp.getDataResponse());

        }
        catch (Throwable e) {
            Reporter.log("Test failed while creating Order via API "+e.getMessage());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }
    }

    /*
     * Method to create new patient using API
     */
    public int createPatientUsingApi(Map<String,String> inputData, int strNbr, String patientName ) {
        try {
            connexusAPIManager = new ConnexusAPIManager();
            this.patientName = patientName;
            String[] name = patientName.split(",");
            String lastName = name[0];
            String firstName = name[1];
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date date = sdf.parse(inputData.get("DOB"));
            long dateInMilliSeconds = date.getTime();
            String dob = "/Date(" + dateInMilliSeconds + ")/";
            AddPatient addPatientValues =  addPatientDetails(inputData, strNbr, firstName, lastName, dob, false, inputData.get("GENDER"), false);
            patientId = connexusAPIManager.addPatientWithGenericAllParam(addPatientValues);
            Reporter.log("Created patient with patient id :\n" + patientId + "\n and patient name: " + patientName);
            return patientId;
        }
        catch(Exception e) {
            Reporter.log("Error while creating patient using API: " + e.getMessage());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            Assert.fail();
            return -1;
        }

    }

    public void CreatePatientAndMoveOrderToChkDURThroughUI(Map<String, String> inputData, boolean controlDrug) {
        //Create new patient
        this.createNewPatient(inputData);
        //Complete DropOff
        this.performDropOff(Priority.Critical);
        dropOffPage.clickBtnAccept();
        //Complete Input
        this.performInput(inputData);
        //Complete 4Point
        this.perform4Point(controlDrug);
    }

    public void CreatePatientAndMoveOrderToChkDUR(Map<String, String> inputData) {
        patientId = genericCreatePatient(inputData, true);
        createNewOrderAndMoveToChkDUR(inputData);
    }

    public void createNewOrderAndMoveToChkDUR(Map<String, String> inputData) {
        int refillCount = Integer.parseInt(inputData.get("REFILLS"));
        String ndc = inputData.get("DRUG_NAME");
        inputResp = connexusAPIManager.createOrderAndMoveTocheckDUR(patientId, siteId, refillCount, ndc, setPrescriber(inputData));
        rxNbr = String.valueOf(inputResp.getRxNbr());
        Reporter.log("RxNbr: " + rxNbr);
    }

    public Prescriber setPrescriber(Map<String, String> inputData)
    {
        Prescriber prescriberRequest = new Prescriber();
        prescriberRequest.setFullname(inputData.get("PRESCRIBER_FULLNAME"));
        prescriberRequest.setFirstname(inputData.get("PRESCRIBER_FNAME"));
        prescriberRequest.setLastname(inputData.get("PRESCRIBER_LNAME"));
        prescriberRequest.setPhone(inputData.get("PRESCRIBER_PHONE"));
        prescriberRequest.setState(inputData.get("PRESCRIBER_STATE"));
        prescriberRequest.setPrescriberId(Integer.parseInt(inputData.get("PRESCRIBER_ID")));
        prescriberRequest.setRxClinicId(Integer.parseInt(inputData.get("ClinicId")));
        prescriberRequest.setDea(inputData.get("DEA"));
        prescriberRequest.setNpi(inputData.get("PRESCRIBER_NAME"));
        return prescriberRequest;
    }

    public List<String> CreatePatientAndMultiRxOrderMoveToChkDUR(Map<String, String> inputData,int numOfRxs, boolean withAddress) {
        patientId = genericCreatePatient(inputData, withAddress);
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        ndcList = new ArrayList<>();
        for (int i = 1; i <= numOfRxs; i++) {
            ndcList.add(inputData.get("DRUG_NAME" + i));
        }
        String priorityIdValue = inputData.get("PRIORITY_ID");
        multiRx4PointCompleteResp = connexusAPIManager.createMultiRxDropOffAndMoveTocheckDUR(patientId, siteId, numRefills, ndcList, priorityIdValue, connexusAPIManager.PrescriberDetails());
        for (int i = 0; i < numOfRxs; i++) {
            rxNbr = String.valueOf(multiRx4PointCompleteResp.get(i).getRxNbr());
            multiRxNbr.add(rxNbr);
            Log.info("rxNbrValue:" + rxNbr);
        }
        return multiRxNbr;
    }

    /*
     * Method to generate patient object with required details for API call
     */

    public AddPatient addPatientDetails(Map<String,String> inputData, int storeId, String firstName, String lastName, String dob, boolean isPet, String Gender, boolean isMinor) {
        AddPatient addPatient = new AddPatient();
        addPatient.setSiteID(storeId);
        addPatient.setCommunicationID(inputData.get("PRIMARY_NUMBER"));
        addPatient.setFirstName(firstName);
        addPatient.setLastName(lastName);
        addPatient.setMiddleName("");
        addPatient.setPatientName(lastName + "," + firstName);
        addPatient.setDob(dob);
        addPatient.setGender(Gender);
        if (StringUtils.isNotBlank(inputData.get("LANGUAGE"))) {
            addPatient.setLanguage(inputData.get("LANGUAGE"));
        } else {
            addPatient.setLanguage("101");
        }
        addPatient.setStatus(Integer.parseInt(inputData.get("PATIENT_STATUS")));
        addPatient.setIsPatientMinor(isMinor);
        addPatient.setAddressTypeCode(Integer.parseInt(inputData.get("ADDRESS_TYPE")));
        addPatient.setVerifyFreCode(Integer.parseInt(inputData.get("VERIFY_CODE")));
        if (isPet) {
            addPatient.setPatientTypeCode(10202);   // Pet
        } else {
            addPatient.setPatientTypeCode(10200);   // Human
        }
        addPatient.setUserId(inputData.get("USER"));
        addPatient.setAddressLine1(inputData.get("ADDRESS"));
        addPatient.setAddressLine2("");
        addPatient.setCellPhone(inputData.get("PRIMARY_NUMBER"));
        addPatient.setCity(inputData.get("CITY"));
        addPatient.setCountry(inputData.get("COUNTRY"));
        addPatient.setHomePhone(inputData.get("PRIMARY_NUMBER"));
        addPatient.setState(inputData.get("STATE"));
        addPatient.setWorkPhone(inputData.get("PRIMARY_NUMBER"));
        addPatient.setZipCode(inputData.get("ZIP_CODE"));
        addPatient.setHipaaStatusCode(Integer.parseInt(inputData.get("HIPAA_CONSENT")));
        return addPatient;
    }
    /*
     * Method to Update patient data using API
     */
    public void updatePatientData(Map<String,String> inputData, String firstName,String lastName, int siteId, boolean isPet , int patientId) {
        try {
            UpdatePatientWrapper updatePatientWrapper = new UpdatePatientWrapper();
            DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            ZonedDateTime utcNow = Instant.now().atZone(ZoneOffset.UTC);
            String UpdatedTs = utcNow.format(DateTimeFormatter.ISO_INSTANT);

            LocalDate date = LocalDate.parse(inputData.get("DOB"), inputFormatter);
            String Dob = date.format(outputFormatter);
            inputData.put("gender", inputData.get("GENDER"));
            inputData.put("addressSeqNbr", inputData.get("ADDRESS_SEQ_NBR"));
            inputData.put("patientStatusCode", inputData.get("PATIENT_STATUS"));
            inputData.put("languageCode", inputData.get("LANGUAGE"));
            if (isPet) {
                inputData.put("patientTypeCode", "10202");
            } else {
                inputData.put("patientTypeCode", "10200");
            }
            inputData.put("patientTypeCode", "10200");
            inputData.put("storeChangeTs", UpdatedTs);
            inputData.put("lastChangeUserId", inputData.get("USER"));
            inputData.put("createTs", UpdatedTs);
            inputData.put("restrictTypeCode", inputData.get("RESTRICT_TYPE_CODE"));
            inputData.put("restrictValue", inputData.get("RESTRICT_VALUE"));
            inputData.put("effectiveTs", UpdatedTs);
            inputData.put("lastChangeTs", UpdatedTs);
            ServiceResponse response = updatePatientWrapper.updatePatient(inputData, firstName, lastName, Dob, patientId, siteId);

            Reporter.logJSON("Update Patient Response", response.getDataResponse());
            Assert.assertEquals(response.getStatusCode(), 202, "Updated patient response" + response.getDataResponse());
        }
        catch (Exception e) {
            Reporter.log("Failed while updating patient data using API "+e.getMessage());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            Assert.fail();
        }
    }

    public void cancelFillFromModifyDetailsScreen(String rxNum){
        try {
            orderSearch.performSearch(rxNum, SearchType.PatientRx);
            orderSearch.selectRowFromSearch(0);
            menuBar.selectNavigation(AppMenu.THERAPY_DISCONINUE, AppMenuItemsIndex.CURRENTRX_CANCEL_FILL, AppMenuSubItemsIndex.THERAPY_DISCONTINUED, null);
            modifyDetails.clickButtonYes();
            modifyDetails.clickButtonYes();
        }
        catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Failed to canceld fill from modify details screen");
            Assert.fail(e.toString());
        }
    }

    /**
     * Method to validate whether rx is in pickup
     **/
    public void verifyRxInPickup(String rxNum) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNum,WorkQueueSettings.Pickup.getValue())) {
                takeScreenShotRXStatus(rxNum, WorkQueue.PICKUP.getWorkQueue(), currentStepMethodName, Status.PASS);
                Assert.assertTrue(true);
                Reporter.log("RX " + rxNum + " is in Pickup queue");
            } else {
                takeScreenShotRXStatus(rxNum, WorkQueue.PICKUP.getWorkQueue(), currentStepMethodName, Status.FAIL);
                Assert.fail("RX " + rxNum + "failed to reach Pickup queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Pickup queue");
            softAssert.fail(e.toString());
        }
    }

    public void makePatientStatusAsDeceased() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (name == null || name.length < 2 || name[0] == null || name[1] == null ||
                    name[0].trim().isEmpty() || name[1].trim().isEmpty()) {
                Reporter.log("Patient name is missing or invalid");
                Assert.fail("Patient name is missing or invalid");
            }
            patientSearchPage.launchPatientSearchScreen();
            Reporter.log("Entering patient name: " + name[0] + ", " + name[1]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.selectDeceasedFromStatus();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.isValidationPopupDisplayedforPatientStatus();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyModifyDetailsScreenNotAccessible(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            Reporter.log("RX is in Resolve queue with Problem as Patient Deceased");
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.launchModifyDetailScreen();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.validatePatientDeceasedPopUp();
            Reporter.log("User isn't able to access Modify Screen when there is an Rx in Patient Deceased Resolution Queue");
            resolutionPage.clickCancel();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Failed in Resolve Queue Method, RX " + rxNbr, "Failed", fileName, 0, DateTime.now());
            Reporter.log("Test failed at Resolve queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyPatientDeceasedPopUpAppearsForDropOffRefill() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try {
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.validatePatientDeceasedPopUp();
            Reporter.log("User isn't able to access Modify Screen from either by F9 or through Menu Options when there is an Rx in Patient Deceased Resolution Queue");
            dropOffPage.clickBtnCancel();
            dropOffPage.clickYes();

        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Patient deceased pop up is not coming up " + rxNbr, "Failed", fileName, 0, DateTime.now());
            Reporter.log("Patient deceased pop up is not coming up");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyRxInPOSQueue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.POS.getValue())) {
                Assert.assertTrue(true);
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                orderSearch.closeSearch();
                Reporter.log("RX is in POS queue");
            } else {
                Assert.fail("RX not in POS queue");
                Reporter.log("RX not in POS queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("RX not in POS queue");
        }
    }
    public void addCardToPatientAccountAPI(int patientID, Map<String, String> inputData) {
        String strNbr = String.valueOf(siteId);
        String cardRefNbr,cardHolderName,expirYearNbr,expirMoNbr,p2peToken, startDate, phmPymtMethod;
        cardRefNbr   = inputData.get("CRD_REF_NUMBER");
        cardHolderName   = inputData.get("CARD_HOLDER_NAME");
        expirYearNbr   = inputData.get("EXPIRY_YEAR");
        expirMoNbr   = inputData.get("EXPIRY_MONTH");
        p2peToken   = inputData.get("P2P_TOKEN");
        startDate   = inputData.get("START_DATE");
        phmPymtMethod   = inputData.get("PAYMENT_METHOD");
        ServiceResponse resp;
        resp= connexusAPIManager.addCardToPatientAccount(String.valueOf(patientID),strNbr,cardRefNbr,cardHolderName,expirYearNbr,expirMoNbr,p2peToken, startDate, phmPymtMethod);
        Assert.assertEquals(resp.getStatusCode(), 202, "Add Card details" + resp.getDataResponse());
    }

    public void updateP2pTokenValue(){
        connexusAppUtils.updateP2PeTokenValueHasNull(patientId);
        Reporter.log("Removed P2PeToken value in visa card to Patient for getting unsuccessful transaction");
    }

    /**
     * Method to create new order till pickup using API
     * return rxNbr
     **/
    public List<String>  createNewOrderTillPickup(Map<String, String> inputData, String ndc, int patientId) {
        Reporter.log("Creating new order till pickup thorough API");
        List<String> responseList = new ArrayList<>();
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        priorityId = Integer.parseInt(inputData.get("PriorityId"));
        requestTypeCode = Integer.parseInt(inputData.get("RequestTypeCode"));
        dispenseType = Integer.parseInt(inputData.get("DispenseType"));
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        clinicId = Integer.parseInt(inputData.get("ClinicId"));
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();
        drugInfo = connexusAPIManager.getDrugInfo(cnx, ndc);
        DataRow prescriberId = connexusAPIManager.getPrescriberInfo(cnx, Integer.parseInt(inputData.get("PRESCRIBER_ID")));
        resp = connexusAPIManager.orderToPickup(siteId, patientId, priorityId, requestTypeCode, dispenseType, numRefills, inputPickupDate, clinicId, inputRxExpDate, drugInfo, prescriberId);
        Assert.assertEquals(resp.getStatusCode(), 201, "The order cannot be created and drop till pickup" + resp.getDataResponse());
        inputResp = resp.getDataResponse(InputResponse.class);
        rxNbr = String.valueOf(inputResp.getRxNbr());
        String workQueueCode = inputResp.getWorkQueue();
        int fillID = inputResp.getRxFillId();
        responseList.add(rxNbr);
        responseList.add(workQueueCode);
        responseList.add(String.valueOf(fillID));
        Reporter.log("rxNbr:" + rxNbr);
        Reporter.log("New order has been created and moved to pickup");
        return responseList;
    }

    /**
     * Method to create new patient using API
     * return patientId
     **/
    public int createPatientAPI(Map<String, String> inputData){
        long homePhone, workPhone, cellPhone;
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        homePhone = Long.parseLong(inputData.get("HOME_PHONE"));
        workPhone = Long.parseLong(inputData.get("WORK_PHONE"));
        cellPhone = Long.parseLong(inputData.get("CELL_PHONE"));
        resp = connexusAPIManager.createPatient(name[1], name[0], inputData.get("DOB"), siteId, homePhone, workPhone, cellPhone);
        Assert.assertEquals(resp.getStatusCode(), 201, "Create Patient details" + resp.getDataResponse());
        inputResp = resp.getDataResponse(InputResponse.class);
        patientId = inputResp.getPatientId();
        Reporter.log("Patient has been created.");
        return patientId;
    }

    /**
     * Method to perform Pickup using patientId
     **/
    public void performPickupWithPatientId(Map<String, String> inputData, int patientId, String rxNbr, String workQueue) {
        String firstName, lastName;
        try {
            Reporter.log("patientId: " + patientId);
            resp = connexusAPIManager.getPatientInformation(siteId,patientId,"");
            Gson gson = new Gson();
            JsonObject root = gson.fromJson(resp.getDataResponse(), JsonObject.class);
            JsonObject patient = root.getAsJsonObject("Patient");
            JsonObject generalInfo = patient.getAsJsonObject("PatGeneralInfo");
            JsonObject personalInfo = generalInfo.getAsJsonObject("PersonalInfo");
            firstName = personalInfo.get("FirstName").getAsString();
            lastName = personalInfo.get("LastName").getAsString();
            WorkQueueSettings queue = WorkQueueSettings.valueOf(workQueue);
            if (queue == WorkQueueSettings.Pickup) {
                automationManager.getConnexusWorkFlow().completePickup(firstName.trim(), lastName.trim(), inputData.get("DOB"), rxNbr);
            }else if (queue == WorkQueueSettings.TroubleShooting){
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                automationManager.getConnexusWorkFlow().completePickup(firstName.trim(), lastName.trim(), inputData.get("DOB"), rxNbr);
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at PickUp queue" + e.getMessage());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /**
     * Method to perform Single Rx order Filling and move to EOD using API
     **/
    public void performSingleRxFillingAndMoveToEOD() {
        Map<String, Integer> value = new HashMap<>();
        rxNbr = this.getRxNbrByPatientName();
        Reporter.log("rxNbr is :" + rxNbr);
        value = connexusAppUtils.getRxOrderDetailsBasedOnNextWorkQueCode(siteId, rxNbr);
        try {
            int rxFillId = value.get("rxFillId");
            connexusAPIManager.singleRxFillingToEOD(siteId, rxFillId);
            Reporter.log("POS has completed and work queue move to EOD");
        } catch (Throwable e) {
            Reporter.log("Test failed at Filling and move to EOD");
            Reporter.log("Error message in performSingleRxFillingAndMoveToEOD API" + e.getMessage());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /**
     * Method to get the rxNbr using patient name from file
     * return rxNbr
     **/
    public String getRxNbrByPatientName() {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String query = "SELECT rx.rx_nbr " + "FROM rx " + "JOIN patient ON rx.patient_id = patient.patient_id " +
                "WHERE patient.first_name = '" + name[1].toUpperCase() + "' " +
                "AND patient.last_name = '" + name[0].toUpperCase() + "';";
        List<Map<String, Object>> resultSet = automationManager.getConnexusDB().executeQueryForList(query);
        if (resultSet != null && !resultSet.isEmpty() && resultSet.getFirst().get("rx_nbr") != null) {
            Map<String, Object> firstRow = resultSet.getFirst();
            return firstRow.get("rx_nbr").toString();
        }
        return null;
    }

    public void setLoginUserType(LoginAs.userType loginUserType) {
        this.loginUserType = loginUserType;
        relaunchConnexus = true;
    }
    public String onlineAccountStatusInPMS() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String patientOnlineAccountStatus = null;
        try {
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(patient.getPatientLastName() + "," + patient.getPatientFirstName());
            patientSearchPage.clickSearchNow();
            patientSearchPage.hostSearchPatient();
            patientSearchPage.doubleClickOnSearchGridRow(0);
            Reporter.logScreenShot("Patient Maintenance", patientMaintenancePage.takeScreenShot("Patient Maintenance Screen").getValue());
            patientOnlineAccountStatus = patientMaintenancePage.getAccountStatus();

        } catch (Exception e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
        finally{
            patientMaintenancePage.closePTMScreen();
        }
        return patientOnlineAccountStatus;
    }

    /*
     * This method will unChk AllImgScanDownOption in tools menu
     * */
    public void unChkAllImgScanDownOption() {
        try {
            //open Tools menu store Settings page
            imzEventPage.openStoreSettings();
            //uncheck All Image Scanner Down option
            imzEventPage.chkAllImgScanDownOption();
            imzEventPage.clickAcceptBtn();
            Reporter.log("Able to uncheck All Image Scanner Down in store Settings page");
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Fail to uncheck All Image Scanner Down in store Settings page" + e.getMessage());
            Assert.fail(e.toString());
        }
    }

    public int getPatientId() {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        return patientId = Integer.parseInt(connexusAppUtils.getPatientId(name[0],name[1]));
    }

    public void moveRxToEod(String siteId) {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        rxNbr = getRxNbr(name[0] , name[1],Integer.parseInt(siteId));
        Reporter.log("Rx number is " +rxNbr);
        ServiceResponse eodApiStatus = connexusAPIManager.moveToEOD(connexusAppUtils.getFillId(rxNbr), Integer.parseInt(siteId));

        if (!"OK".equals(eodApiStatus.getStatusDesc())) {
            Assert.fail("Failed to move Rx " + rxNbr + " to EOD , eod API status is " + eodApiStatus.getStatusDesc());
        }
        Reporter.log("Rx " + rxNbr + " moved to EOD ");
    }

    public void moveMultiRxToEod(String siteId) {
        patientId = getPatientId();
        multiRxNbrValues = connexusAppUtils.getMultiRxNbrFromPatientId(Integer.parseInt(siteId), patientId);
        Reporter.log("Rx number are " + multiRxNbrValues);
        for (int i = 0; i < multiRxNbrValues.size(); i++) {
            currentRxNbr = String.valueOf(multiRxNbrValues.get(i));
            Reporter.log("Moving Rx " + currentRxNbr + " to EOD");
            ServiceResponse eodApiStatus = connexusAPIManager.moveToEOD(
                    connexusAppUtils.getFillId(String.valueOf(currentRxNbr)),
                    Integer.parseInt(siteId)
            );
            Assert.assertTrue(
                    "OK".equals(eodApiStatus.getStatusDesc()),
                    "Failed to move Rx " + currentRxNbr + " to EOD, eod API status is " + eodApiStatus.getStatusDesc()
            );
            Reporter.log("Rx " + currentRxNbr + " moved to EOD");

        }
    }

    public void verifyMultiRxInEOD() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        multiRxNbrValues = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        Log.info("multiRxNbrValues:" + multiRxNbrValues);
        try {
            for (int i = 0; i < multiRxNbrValues.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbrValues.get(i));
                if (checkOrderQueueDB(currentRxNbr.toString(), WorkQueueSettings.EOD.getValue())) {
                    takeScreenShotRXStatus(currentRxNbr.toString(), WorkQueue.EOD.getWorkQueue(), currentStepMethodName, Status.PASS);
                    Assert.assertTrue(true);
                    Reporter.log("Rx " + currentRxNbr + "Moved to EOD");
                } else {
                    performResolveQueue(currentRxNbr.toString());
                    if (checkOrderQueueDB(currentRxNbr.toString(), WorkQueueSettings.EOD.getValue())) {
                        takeScreenShotRXStatus(currentRxNbr.toString(), WorkQueue.EOD.getWorkQueue(), currentStepMethodName, Status.PASS);
                        Assert.assertTrue(true);
                        Reporter.log("Rx " + currentRxNbr + "Moved to EOD");
                    } else {
                        captureUnExpectedQueueResults(currentRxNbr.toString(), currentStepMethodName, "RX is not in EOD queue");
                    }
                }
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at EOD queue");
            connexusAppUtils.writeTextToFile("EOD Not Completed " + multiRxNbrValues, "Failed", fileName, 0, DateTime.now());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void dropAnRxTillEOD(Map<String, String> inputData) {
        this.performDropOff();
        this.performInput(inputData);
        this.perform4Point();
        this.performFilling();
        this.performVisualVerify();
        this.performPickUp(inputData);
        this.performCounselling();
        this.performPOS();
    }

    public void moveFromChkDurTillEODThroughUI(Map<String, String> inputData) {
        this.performFilling();
        this.performVisualVerify();
        this.performPickUp(inputData);
        this.performCounselling();
        this.performPOS();
    }

    /**
     * Generic method to change billing method in Service Admin - Modify Details
     * @param fromBilling - Source billing type (TP/CASH)
     * @param toBilling - Target billing type (TP/CASH or specific TP name)
     * @param drugName - Drug name to filter orders
     * Author: Lavanya(vn575up)
     */
    public void changeBillingFromModifyDetails(Map<String, String> inputData, String fromBilling, String toBilling, String drugName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        modifyDetails = new ModifyDetails();
        pickupPage = new PickupPage();
        String currentRxNbr;
        patientId = getPatientId();
        List<Integer> multiRxNbrValues = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        Log.info("multiRxNbrValues:" + multiRxNbrValues);
        try {
            for (int i = 0; i < multiRxNbrValues.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbrValues.get(i));

                if (checkOrderQueueDB(currentRxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    automationManager.getConnexusWorkFlow().completeResolution(currentRxNbr);
                }
                if (ischeckIMZOrderQueueDB(currentRxNbr, WorkQueueSettings.ServiceAdministration.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    patientSearchPage.launchOrderSearchScreen();
                    patientSearchPage.performSearch(currentRxNbr);
                    Reporter.log("Order is in service admin");
                    String productName = orderSearch.getProductName(0);
                    Log.info("productName:" + productName);

                    if (productName.contains(drugName)) {
                        patientSearchPage.openFirstPatientRecord();
                        // Index 0 = CASH or blank
                        if ("CASH".equalsIgnoreCase(toBilling) || toBilling.isBlank()) {
                            if (!modifyDetails.selectInsurance(0)) {
                                Assert.fail("Failed to change billing from " + fromBilling + " to CASH");
                            }
                            Reporter.log("Changed " + fromBilling + " to CASH");
                        } else if (inputData.containsKey("TP_CARRIER_BIN_2") && inputData.get("TP_CARRIER_BIN_2") != null) {
                            // If TP plan details are provided, update patient TP first (for TPtoTP or CashtoTP scenarios)
                            Reporter.log("Updating patient TP information and insurance");
                            updatePatientTP(inputData);
                            modifyDetails.clickOKBtn();
                            Reporter.log("Changed " + fromBilling + " to " + toBilling + " (TP) after updating patient TP");
                        } else {
                            // For any TP value (TP, COUPON, COMM, Medicaid, etc.), select index 1
                            if (!modifyDetails.selectInsurance(1)) {
                                Assert.fail("Failed to change billing from " + fromBilling + " to " + toBilling);
                            }
                            Reporter.log("Changed " + fromBilling + " to " + toBilling + " (TP)");
                        }
                        Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                        modifyDetails.clickAccept();
                        pickupPage.rxExpAndDrugDateSelection();
                        modifyDetails.clickAccept();
                        modifyDetails.selectReasonForPaymentSwitch();
                        Reporter.log("Test passed while changing billing from " + fromBilling + " to " + toBilling);
                        modifyDetails.clickAccept();
                        modifyDetails.checkAndClickWarning();
                        pickupPage.handleBottleLabelPopup();
                    }
                } else {
                    Assert.fail("Order is not in svcAdmin queue for payment modify details");
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed while changing billing from " + fromBilling + " to " + toBilling + ": " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Changes the billing method from TP to Cash.
     * @param drugName to filter orders.
     */
    public void changeBillingFromTPToCashInModifyDetails(Map<String, String> inputData, String drugName) {
        changeBillingFromModifyDetails(inputData, "TP", "", drugName);
    }

    /**
     * Changes the billing method from TP to TP.
     * @param drugName to filter orders.
     */
    public void changeBillingFromTPToTPInModifyDetails(Map<String, String> inputData, String drugName) {
        changeBillingFromModifyDetails(inputData, "TP", "TP", drugName);
    }

    /**
     * Changes the billing method from Cash to TP.
     * @param drugName to filter orders.
     */
    public void changeBillingFromCashToTPInModifyDetails(Map<String, String> inputData, String drugName) {
        changeBillingFromModifyDetails(inputData,"CASH", "TP", drugName);
    }

    /**
     * Updates the patient's third-party (TP) information in PMS
     * @param inputData for new TP information.
     */
    public void updatePatientTP(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        modifyDetails = new ModifyDetails();
        patientMaintenancePage = new PatientMaintenancePage();
        modifyDetails.clickPatientMaintenanceIcon();
        patientMaintenancePage.inputCarrierBin(inputData.get("TP_CARRIER_BIN_2"));
        patientMaintenancePage.selectPlan(inputData.get("TP_PLAN_2"), inputData.get("TP_CARRIER_BIN_2"));
        patientMaintenancePage.inputCardId(inputData.get("TP_CARD_ID_2"));
        patientMaintenancePage.checkSameAsPatientIfUnchecked();
        //update host pull patient missing fields
        if (patientMaintenancePage.checkIsValidationDisplayed()) {
            patientMaintenancePage.isValidationPopupDisplayedforPatientStatus();
            patientMaintenancePage.inputPhoneNum(inputData.get("PRIMARY_NUMBER"));
            patientMaintenancePage.isAllergiesNoEnabledRadioButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            patientMaintenancePage.clickPopUpOkBtn();
            patientMaintenancePage.clickYes();
            Reporter.log("Successfully updated patient TP information");
        } else {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        }
    }

    public int performCreatePatientThroughAPI(Map<String, String> inputData, int strNbr) {
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientId = createPatientUsingApi(inputData, strNbr, name[0] + "," + name[1]);
        } catch (Exception e) {
            Reporter.log("Test failed while creating Order via API " + e.getMessage());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }
        return patientId;
    }

    public void createPatientWithTpAndMoveToPickup(Map<String, String> inputData, int storeId) {
        patientId = genericCreatePatient(inputData);
        IDatabaseContext cnx = automationManager.getConnexusDB(storeId);
        DataRow drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("NDC_NUMBER"));
        rxNbr = connexusAPIManager.createNewOrderAndMoveToPickup(patientId, storeId, new SimpleDateFormat("MMM dd yyyy").format(Date.from(Instant.now().plus(720, ChronoUnit.DAYS))), new SimpleDateFormat("MMM dd yyyy").format(Date.from(Instant.now().plus(15, ChronoUnit.DAYS))) + " 08:00:00.000 UTC", 25, drugInfo, inputData.get("NDC_NUMBER")).get(0);
    }

    public void validateRxWorkQueue(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            Reporter.log("rxNumber : " + rxNbr);
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())) {
                Assert.assertTrue(true);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Assert.fail("WorkQueue is not in PICKUP");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("WorkQueue is not in PICKUP");
        }
    }

    public int genericCreatePatient(Map<String, String>inputData) {
        return genericCreatePatient(inputData, false);
    }

    public int genericCreatePatient(Map<String, String>inputData, boolean withAddress) {
        CreatePatientRequest createPatientRequest = new CreatePatientRequest();
        InsuranceDetails insuranceDetails = new InsuranceDetails();
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        siteId = Integer.parseInt(propertyReader.getProperty("cnx.store"));
        //Build input patient
        createPatientRequest.setFirstName(name[1]);
        createPatientRequest.setLastName(name[0]);
        createPatientRequest.setInputDob(inputData.get("INPUTDOB"));
        if (StringUtils.isNotBlank(inputData.get("GENDER"))) {
            createPatientRequest.setGender(inputData.get("GENDER"));
        } else {
            createPatientRequest.setGender("M");
        }
        createPatientRequest.setSiteId(siteId);
        createPatientRequest.setHomePhone(inputData.get("PRIMARY_NUMBER"));
        createPatientRequest.setWorkPhone(inputData.get("PRIMARY_NUMBER"));
        createPatientRequest.setCellPhone(inputData.get("PRIMARY_NUMBER"));
        //add address only if the flag passed with TRUE
        if (withAddress) {
            Address add = new Address();
            add.setAddressLine1(inputData.get("ADDRESS"));
            add.setZipCode(inputData.get("ZIP_CODE"));
            add.setState(inputData.get("STATE"));
            add.setCity(inputData.get("CITY"));
            add.setCountry(inputData.get("COUNTRY"));
            createPatientRequest.setAddress(add);
        }
        //TP Details if Patient Has Insurance
        if (Boolean.parseBoolean(inputData.get("patientHasInsurance"))) {
            //With TP Details
            createPatientRequest.setPatientHasInsurance(Boolean.parseBoolean(inputData.get("patientHasInsurance")));
            insuranceDetails.setInsuranceCarrierPlanId(Integer.parseInt(inputData.get("carrierPlanId")));
            insuranceDetails.setInsuranceCarrierCompanyId(Integer.parseInt(inputData.get("carrierCompanyCode")));
            insuranceDetails.setBillingSeqNbr(Integer.parseInt(inputData.get("billSeqNbr")));
            insuranceDetails.setCardholderId(inputData.get("cardHolderId"));
            insuranceDetails.setCardholderFirstName(inputData.get("cardHolderFirstName"));
            insuranceDetails.setCardholderLastName(inputData.get("cardHolderLastName"));
            insuranceDetails.setRelationshipCode(Integer.parseInt(inputData.get("relationshipCode")));
            insuranceDetails.setCoverageInd(inputData.get("coverageIndicator"));
            insuranceDetails.setCoverageExpDate(inputData.get("covExpDate"));
            insuranceDetails.setInsPlanTypeCode(Integer.parseInt(inputData.get("planTypeCode")));
            insuranceDetails.setSplitBillInd("");
            createPatientRequest.setInsurance(insuranceDetails);
        }
        patientId= connexusAPIManager.createPaientWithOrWithoutTP(createPatientRequest);
        return patientId;
    }

    public List<String> createRxAndMoveToPickupForTp(Map<String, String> inputData, int patientId) {
        List<String> multiRxNbr = new ArrayList<>();
        try {
            int numRefills = 0;
            List<String> ndcList = Arrays.asList(inputData.get("DRUG_NAME1"));
            List<String> multiRxTpCompleteResp = connexusAPIManager.createNewMultiDrugOrderToReadyForPickUp(patientId, siteId,numRefills, ndcList, connexusAPIManager.PrescriberDetails());
            for (String inputResponse : multiRxTpCompleteResp) {
                rxNbr = inputResponse;
                multiRxNbr.add(rxNbr);
            }
        } catch (Exception e) {
            Reporter.log("MultiRx Tp patient creation failed"+e.getMessage());
        }return multiRxNbr;
    }

    /**
     * Method to perform Pickup using patientId for single or multiple Rx
     */
    public void performMultiRxPickupWithPatientId(Map<String, String> inputData, int patientId, List<String> rxNbrList, String workQueue) {
        try {
            Reporter.log("patientId: " + patientId);
            // Fetch patient details from API
            resp = connexusAPIManager.getPatientInformation(siteId, patientId, "");
            JsonObject root = JsonParser.parseString(resp.getDataResponse()).getAsJsonObject();
            JsonObject personalInfo = root
                    .getAsJsonObject("Patient")
                    .getAsJsonObject("PatGeneralInfo")
                    .getAsJsonObject("PersonalInfo");
            String firstName = personalInfo.get("FirstName").getAsString().trim();
            String lastName = personalInfo.get("LastName").getAsString().trim();
            String dob = inputData.get("DOB");
            WorkQueueSettings queue = WorkQueueSettings.valueOf(workQueue);
            // If trouble shooting queue, resolve all rx before pickup
            if (queue == WorkQueueSettings.TroubleShooting) {
                for (String rxNbr : rxNbrList) {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
            }
            // Proceed to pickup
            if (queue == WorkQueueSettings.Pickup) {
                automationManager.getConnexusWorkFlow().completeMultiRxPickup(
                        firstName,
                        lastName,
                        dob,
                        rxNbrList,
                        String.valueOf(siteId)
                );
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at PickUp queue: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("Exception during pickup flow: " + e.getMessage());
        }
    }


    public int addPatientWithTP(Map<String, String> inputData) {
        CreatePatientRequest createPatientRequest = new CreatePatientRequest();
        InsuranceDetails insuranceDetails = new InsuranceDetails();
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        createPatientRequest.setFirstName(name[0]);
        createPatientRequest.setLastName(name[1]);
        createPatientRequest.setDob(inputData.get("DOB"));
        createPatientRequest.setSiteId(Integer.parseInt(propertyReader.getProperty("cnx.store")));
        createPatientRequest.setHomePhone(inputData.get("PRIMARY_NUMBER"));
        createPatientRequest.setWorkPhone(inputData.get("PHONE_NUMBER1"));
        createPatientRequest.setCellPhone(inputData.get("PHONE_NUMBER2\n"));

        createPatientRequest.setPatientHasInsurance(true);
        insuranceDetails.setInsuranceCarrierPlanId(102);
        insuranceDetails.setInsuranceCarrierCompanyId(121342);
        insuranceDetails.setBillingSeqNbr(1);
        insuranceDetails.setCardholderId(inputData.get("TP_CARD_ID"));
        insuranceDetails.setCardholderFirstName("LIAM");
        insuranceDetails.setCardholderLastName("TEST");
        insuranceDetails.setRelationshipCode(3201);
        insuranceDetails.setCoverageInd("Y");
        insuranceDetails.setInsPlanTypeCode(1000);
        createPatientRequest.setInsurance(insuranceDetails);
        req.setRequestPayloadWithNulls(createPatientRequest);
        req.setUrl(propertyReader.getProperty("connexusWrapper.CreatePatientUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("CreatePatient Request endpoint: " + req.getUrl());
        Log.info("CreatePatient Request endpoint\n " + req.getUrl());
        Reporter.logJSON("CreatePatient Request\n", createPatientRequest);
        Log.info("CreatePatient Request\n " + req.getRequestPayload());
        resp = automationManager.getRestContext().performPost(req);
        Reporter.logJSON("CreatePatient Response\n", resp.getDataResponse());
        Log.info("CreatePatient Response\n" + resp.getDataResponse());
        Assert.assertEquals(resp.getStatusCode(), 201, "Expected status code 201 but found " + resp.getStatusCode());
        inputResp = resp.getDataResponse(InputResponse.class);
        return inputResp.getPatientId();
    }


    public ServiceResponse getOrderDetailsAndMoveToEOD(int rxFillId){
        resp = connexusAPIManager.getOrderInfo(siteId,rxFillId,1);
        resp = connexusAPIManager.moveOrderToEOD(resp.getDataResponse());
        return resp;
    }

    public List<String> createMultiRxOrderTillPickup(Map<String, String> inputData, int patientId) {
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        ndcList = Arrays.asList(inputData.get("PRODUCT_NAME"), inputData.get("PRODUCT_NAME"));
        multiRxNbr = connexusAPIManager.createNewMultiDrugOrderToReadyForPickUp(patientId, siteId, numRefills, ndcList, connexusAPIManager.PrescriberDetails());
        System.out.println("Multi Rx Numbers: " + multiRxNbr);

        // Or use Reporter log if in a test framework
        Reporter.log("Multi Rx Numbers: " + multiRxNbr);
        return multiRxNbr;
    }

    public List<String> dropMultiRxOrderTillPickup(Map<String, String> inputData, List<String> ndcList, int patientId) {

        List<String> allMultiRxList = new ArrayList<>();

        Integer sharedOrderId = null;
        Integer sharedToteNumber = null;

        for (String ndc : ndcList) {
            List<String> multiRxNbr = dropNewOrderTillPickup(
                    inputData,
                    ndc,
                    patientId,
                    sharedOrderId,      // <-- pass same orderId here
                    sharedToteNumber    // <-- pass same tote #
            );
        /*
            multiRxNbr expected output order from createNewOrderTillPickup:
            index 0 = rxNbr
            index 1 = workQueue
            index 2 = rxFillId
            index 3 = orderId
            index 4 = toteNumber
        */
            // Capture orderId & tote number from first iteration
            if (sharedOrderId == null) {
                sharedOrderId = Integer.parseInt(multiRxNbr.get(3));
                sharedToteNumber = Integer.valueOf(multiRxNbr.get(4));
            }
            allMultiRxList.addAll(multiRxNbr);
        }

        System.out.println("All Multi Rx Details: " + allMultiRxList);
        Reporter.log("All Multi Rx Details: " + allMultiRxList);

        return allMultiRxList;
    }


    public ServiceResponse getOrderDetailsAndMoveToPickup(int rxFillId){
        resp = connexusAPIManager.getOrderInfo(siteId, rxFillId, 1);
        resp = connexusAPIManager.moveOrderToPickUp(resp.getDataResponse());
        return resp;
    }


    public int getNextWorkQueue(String rxNbr) {
        String query = "select next_work_que_code from rx_order_detail where status_code != 20503 and rx_id in (select rx_id from rx where rx_nbr  = " + rxNbr +")";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        return Integer.parseInt(rxInfo.get("next_work_que_code").toString());
    }

    public void restartConnexusService() {
        Reporter.log("Restarting Connexus service to apply updated flags");
        connexusAPIManager.restartConnexusService(siteIDString);
        relaunchConnexus = true;
    }

    public int checkOrderIn4pointAndNotCash(String rxNbr) {
        int workQueueCode = 0;

        try {
            workQueueCode = getNextWorkQueue(rxNbr);
        } catch (Exception e) {
            Log.error("Unhandled exception in DBService");
        }

        final int finalWorkQueuecode = workQueueCode;

        WorkQueueSettings matchedQueue = Arrays.stream(WorkQueueSettings.values())
                .filter(enumValue -> enumValue.getValue() == finalWorkQueuecode)
                .findFirst()
                .orElse(null);

        if (workQueueCode == WorkQueueSettings.wm4PointCheck.getValue()) {
            return 1;
        } else {
            return 0;
        }
    }

    public ServiceResponse  orderToPickup(int SiteId,int patientId,Integer orderId, Integer tote, int priorityId,int requestTypeCode,int dispenseType,int numRefills
            ,String inputPickupDate,int clinicId,String inputRxExpDate,DataRow drugInfo, DataRow prescriber){
        TillPickupRequest orderPickupRequest=new TillPickupRequest();
        String phoneNbr= hwqe.baseframework.utilities.StringUtils.phoneNumberGenerator();
        hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Drug drug = new hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Drug();
        orderPickupRequest.setRequestTypeCode(requestTypeCode);
        orderPickupRequest.setPriorityId(priorityId);
        orderPickupRequest.setDispenseType(dispenseType);
        orderPickupRequest.setPatientId(patientId);
        orderPickupRequest.setSiteID(SiteId);
        orderPickupRequest.setInputPickUpDate(inputPickupDate);
        orderPickupRequest.setInputRxExpDate(inputRxExpDate);
        orderPickupRequest.setNumRefills(numRefills);
        orderPickupRequest.setOrderId(orderId == null ? 0 : orderId);
        orderPickupRequest.setToteNumber(tote == null ? 0 : tote);
        drug.setGpiCode(drugInfo.getValue("gpi_code"));
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr"));
        drug.setItemId(drugInfo.getValue("mds_fam_id"));
        drug.setRxProdId(Integer.parseInt(drugInfo.getValue("product_mds_fam_id").toString().trim()));
        drug.setControlCode(Integer.parseInt(drugInfo.getValue("drug_control_code").toString()));
        // drug.setPresMultiSrcCode(Integer.parseInt(drugInfo.getValue("multi_source_code").toString()));
        //drug.setOnHandQty(Integer.parseInt(drugInfo.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
        drug.setOnHandQty(Integer.parseInt(propertyReader.getProperty("fom.OnHandQty")));
        drug.setUsualCost(propertyReader.getProperty("fom.usualCost"));
        drug.setActCost(propertyReader.getProperty("fom.actCost"));
        drug.setOrgUsualCost(propertyReader.getProperty("fom.orgUsualCost"));
        hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Prescriber pres=new hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Prescriber();
        pres.setPrescriberId(prescriber.getValue("prescriber_id"));
        pres.setNpi(propertyReader.getProperty("fom.npi"));
        pres.setDea(propertyReader.getProperty("fom.dea"));
        pres.setPhone(phoneNbr);
        String middle_name=prescriber.getValue("middle_name");
        String first_name=prescriber.getValue("first_name");
        String last_name=prescriber.getValue("last_name");
        pres.setFullname(first_name.trim()+" "+middle_name.trim()+" "+last_name.trim());
        pres.setState(propertyReader.getProperty("fom.state"));
        pres.setRxClinicId(clinicId);
        pres.setLastname(last_name.trim());
        pres.setFirstname(first_name.trim());
        orderPickupRequest.setDrug(drug);
        // orderPickupRequest.setPrescriber(pres);
        req.setRequestPayloadWithNulls(orderPickupRequest);
        req.setUrl(propertyReader.getProperty("fom.connexusWrapper.createOrderTillPickupUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("OrderTillPickup Request endpoint: " + req.getUrl());
        Reporter.logJSON("OrderTillPickup Request", orderPickupRequest);
        Log.info("OrderTillPickup RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = automationManager.getRestContext().performPost(req, 3);
        Reporter.logJSON("OrderTillPickup Response", resp.getDataResponse());
        Log.info("OrderTillPickup ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }

    /**
     * Method to create new order till pickup using API, you can same orderId and tote Number to create multi order
     * return rxNbr
     **/
    public List<String>  dropNewOrderTillPickup(Map<String, String> inputData, String ndc, int patientId, Integer orderId, Integer tote) {
        Reporter.log("Creating new order till pickup thorough API");
        List<String> responseList = new ArrayList<>();
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        priorityId = Integer.parseInt(inputData.get("PriorityId"));
        requestTypeCode = Integer.parseInt(inputData.get("RequestTypeCode"));
        dispenseType = Integer.parseInt(inputData.get("DispenseType"));
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        clinicId = Integer.parseInt(inputData.get("ClinicId"));
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();
        drugInfo = connexusAPIManager.getDrugInfo(cnx, ndc);
        DataRow prescriberId = connexusAPIManager.getPrescriberInfo(cnx, Integer.parseInt(inputData.get("PRESCRIBER_ID")));
        resp = orderToPickup(siteId, patientId, orderId, tote, priorityId, requestTypeCode, dispenseType, numRefills, inputPickupDate, clinicId, inputRxExpDate, drugInfo, prescriberId);
        Assert.assertEquals(resp.getStatusCode(), 201, "The order cannot be created and drop till pickup" + resp.getDataResponse());
        inputResp = resp.getDataResponse(InputResponse.class);
        rxNbr = String.valueOf(inputResp.getRxNbr());
        String workQueueCode = inputResp.getWorkQueue();
        int fillID = inputResp.getRxFillId();
        String newOrderId = String.valueOf(inputResp.getOrderId());
        String newTote = String.valueOf(inputResp.getToteNumber());

        responseList.add(rxNbr);
        responseList.add(workQueueCode);
        responseList.add(String.valueOf(fillID));
        responseList.add(newOrderId);
        responseList.add(newTote);
        Reporter.log("rxNbr:" + rxNbr);
        Reporter.log("New order has been created and moved to pickup");
        return responseList;
    }

    public String performERX(Map<String, String> inputData, String xmlPath, boolean verifyOrder) throws SQLException, ParserConfigurationException, IOException, SAXException {
        File xmlData;
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String messageId, inputPayload, ndc, drugName;
        String storeId=propertyReader.getProperty("cnx.store");
        if (storeId.length() == 4) {
            storeId = "0" + storeId;
        }

        // Connect to store DB
        IDatabaseContext cnx = automationManager.getConnexusDB(Integer.parseInt(storeId));
        // Get patient ID
        patientID = Integer.parseInt(connexusAppUtils.getPatientId(name[0], name[1]));
        // Get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientID);
        // Get XML file to generate input payload
        xmlData = new File(xmlPath);
        ndc = inputData.get("DRUG_NAME");
        drugName = inputData.get("DRUG_NAME");
        Reporter.log("Drug name: " + drugName);
        // Update the XML with required storeNbr, Date-time, and a unique messageId
        String generatedString = RandomStringUtils.randomAlphanumeric(10);
        String updateMsgId = storeId + generatedString;
        inputPayload = updateXML(xmlData, storeId, updateMsgId, patientInfo, ndc, drugName);
        Log.info("inputPayload: " + inputPayload);
        // Drop ERX order
        dropERX(inputPayload, storeId, patientID, updateMsgId);
        //verification order creation
        if (verifyOrder) {
            verifyOrderCreation(updateMsgId);
        }
        return updateMsgId;
    }

    public String PerformTransferRequest(Map<String, String> inputData, String xmlPath) throws ParserConfigurationException, IOException, SAXException {
        File xmlData;
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String  inputPayload, ndc, drugName;
        String storeId=propertyReader.getProperty("cnx.store");
        if (storeId.length() == 4) {
            storeId = "0" + storeId;
        }

        // Connect to store DB
        IDatabaseContext cnx = automationManager.getConnexusDB(Integer.parseInt(storeId));
        // Get patient ID
        patientID = Integer.parseInt(connexusAppUtils.getPatientId(name[0], name[1]));
        // Get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientID);
        // Get XML file to generate input payload
        xmlData = new File(xmlPath);
        ndc = inputData.get("DRUG_NAME");
        drugName = inputData.get("DRUG_NAME");
        Reporter.log("Drug name: " + drugName);
        // Update the XML with required storeNbr, Date-time, and a unique messageId
        String generatedString = RandomStringUtils.randomAlphanumeric(10);
        String updateMsgId = storeId + generatedString;
        inputPayload = updateTransferXML(xmlData, storeId, updateMsgId, patientInfo, drugName);
        Log.info("inputPayload: " + inputPayload);
        // Drop e transfer order
        dropETransferRequest(inputPayload, updateMsgId);
        //taking time to reflect in UI.
        automationManager.performSleep(15);
        return updateMsgId;
    }

    public DataRow getPatientInfo(IDatabaseContext cnx, int patientId) {
        String getPatientInfo = "select last_name, first_name, gender_code, birth_date from rx21c:informix.patient \n" +
                "where patient_id = " + patientId + ";";
        DataTable dt = cnx.getDataTable(getPatientInfo);
        Assert.assertEquals(dt.getRowCount(), 1);
        DataRow row = dt.getDataRows().get(0);
        return row;
    }

    public String updateXML(File xmlData, String storeNbr, String messageId, DataRow patientInfo, String ndc, String drugName)
            throws ParserConfigurationException, SAXException, IOException {
        String fileContext = FileUtils.readFileToString(xmlData, StandardCharsets.UTF_8);
        fileContext = fileContext.replaceAll("storeNbr", storeNbr);
        fileContext = fileContext.replaceAll("messageId", messageId);
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedDate = today.format(formatter);
        String currentTime = getCurrentTime();
        fileContext = fileContext.replaceAll("sentTime", currentTime);
        fileContext = fileContext.replaceAll("effectiveDate", formattedDate);
        fileContext = fileContext.replaceAll("writtenDate", currentTime);
        fileContext = fileContext.replaceAll("patientLastName", patientInfo.getValue("last_name").toString().trim());
        fileContext = fileContext.replaceAll("patientFirstName", patientInfo.getValue("first_name").toString().trim());
        fileContext = fileContext.replaceAll("patientGender", patientInfo.getValue("gender_code"));
        fileContext = fileContext.replaceAll("patientDOB", patientInfo.getValue("birth_date").toString());
        fileContext = fileContext.replaceAll("drugName", drugName);
        fileContext = fileContext.replaceAll("ndc", ndc);
        return fileContext;
    }

    public String updateTransferXML(File xmlData, String storeNbr, String messageId, DataRow patientInfo, String drugName)
            throws ParserConfigurationException, SAXException, IOException {
        String fileContext = FileUtils.readFileToString(xmlData, StandardCharsets.UTF_8);
        fileContext = fileContext.replaceAll("storeNbr", storeNbr);
        fileContext = fileContext.replaceAll("messageId", messageId);
        fileContext = fileContext.replaceAll("trackingId", java.util.UUID.randomUUID().toString());
        fileContext = fileContext.replaceAll("sentTime", Instant.now().toString());
        fileContext = fileContext.replaceAll("patientLastName", patientInfo.getValue("last_name").toString().trim());
        fileContext = fileContext.replaceAll("patientFirstName", patientInfo.getValue("first_name").toString().trim());
        fileContext = fileContext.replaceAll("patientGender", patientInfo.getValue("gender_code"));
        fileContext = fileContext.replaceAll("patientDOB", patientInfo.getValue("birth_date").toString());
        fileContext = fileContext.replaceAll("drugName", drugName.trim());
        return fileContext;
    }

    public String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String Ts = sdf.format(timestamp);
        return Ts;
    }

    public void dropERX(String inputPayload, String storeNbr, int patientId, String messageId) {
        //drop ERX via POST
        headers.put("content-type", "application/xml");
        headers.put("User-Agent", "PostmanRuntime/7.28.4");
        headers.put("Accept", "*/*");
        headers.put("Accept-Encoding", "gzip, deflate, br");
        headers.put("Connection", "keep-alive");
        req.setHeaders(headers);
        req.setUrl(PropertyReader.getInstance().getProperty("prm.RxTransferout.URL"));
        req.setRequestPayload(inputPayload);
        Reporter.log("Request Payload:\n" + req.getRequestPayload() + "\n");
        resp = automationManager.getRestContext().performPost(req);
        Reporter.log("Response status code is"+resp.getStatusCode());
        Reporter.log("Response Payload:\n" + resp.getDataResponse() + "\n");
        //verify POST request is successful
        Assert.assertEquals(resp.getStatusCode(), 200, "POST request returned error");
        Reporter.log("ERX order posting successful for patientId = " + patientId + " in store # " + storeNbr +
                ". The resp message_id is " + messageId);
    }

    public void dropETransferRequest(String inputPayload, String messageId) {
        //drop ETransfer from POST
        headers.put("content-type", "application/xml");
        headers.put("User-Agent", "PostmanRuntime/7.28.4");
        headers.put("Accept", "*/*");
        headers.put("Accept-Encoding", "gzip, deflate, br");
        headers.put("Connection", "keep-alive");
        headers.put("WM_CONSUMER.ID", propertyReader.getProperty("prm.RxTransferInboundProcessor.ConsumerId"));
        req.setHeaders(headers);
        req.setUrl(PropertyReader.getInstance().getProperty("prm.RxTransferInboundProcessor.URL"));
        req.setRequestPayload(inputPayload);
        Reporter.log("Request Payload:\n" + req.getRequestPayload() + "\n");
        resp = automationManager.getRestContext().performPost(req);
        Reporter.log("Response status code is"+resp.getStatusCode());
        Reporter.log("Response Payload:\n" + resp.getDataResponse() + "\n");
        //verify POST request is successful
        Assert.assertEquals(resp.getStatusCode(), 200, "POST request returned error");

    }

    public void verifyOrderCreation(String messageId) {
        try {
            hwqe.baseframework.utilities.Poller poller = new hwqe.baseframework.utilities.Poller(30, 500);
            boolean isOrderCreated = poller.pollForSuccess(() -> {
                String queryMsg = "select * from raw_eltnc_rx_resp where resp_message_id = '" + messageId + "'";
                Map<String, Object> resultSet = automationManager.getConnexusDB().executeQuery(queryMsg);
                return resultSet != null && !resultSet.isEmpty() && (short) resultSet.get("response_stat_code") == 26005;
            });
            if (isOrderCreated) {
                Reporter.log("ERX order successfully created for messageId: " + messageId);
            } else {
                Assert.fail("ERX order creation failed for messageId: " + messageId);
            }
        } catch (Throwable e) {
            Assert.fail("Exception during order creation verification: " + e.toString());
        }
    }

    public void performFourPointWithOnHoldStatus() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0] , name[1], siteId);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0]+ "," + name[1]);
            orderSearch.openFirstPatientRecord();
            if (fourPoint.isElementDisplayed(fourPoint.rdbNonAcute, 1)) {
                fourPoint.click(fourPoint.rdbNonAcute);
            }
            if(!fourPoint.onHoldButtonSelected()){
                fourPoint.unCheckOnHold();
            }
            fourPoint.chkName();
            fourPoint.chkPrescribed();
            if(fourPoint.ischkStrength()){
                fourPoint.chkStrength();
            }
            fourPoint.chkSIG();
            if (fourPoint.isElementDisplayed(fourPoint.chkDEA, 1)) {
                fourPoint.click(fourPoint.chkDEA);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            fourPoint.clickAccept();
            Reporter.log("4 point completed");
            automationManager.performSleep(10);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at 4 Point queue");
        }
    }

    public void sendErxMessage(String payloadType, Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchAboutScreen();
            String dob = inputData.get("DOB");
            switch(payloadType)
            {
                case "surescriptFutureFill":
                case "surescriptNewRequst":
                    System.out.print("payload"+payloadResource.getPayload(payloadType,name,dob));
                    orderSearch.sendErxMsg(payloadResource.getPayload(payloadType,name,dob));
                    orderSearch.selectSurescriptsRadioButton();
                    break;
                case "cancelsurescriptrequest":
                    orderSearch.sendErxMsg(payloadResource.getPayload(payloadType,name,dob));
                    orderSearch.selectSurescriptsRadioButton();
                    break;
            }
            orderSearch.sendErxMessage();
            if("Failure".equalsIgnoreCase(orderSearch.getErxResponseMessage())){
                orderSearch.clickOk();
                orderSearch.closeAboutWindow();
                Assert.fail("Failed to send Erx Message");
            }else{
                automationManager.performSleep(5);
                orderSearch.clickOk();
                automationManager.performSleep(5);
                orderSearch.closeAboutWindow();
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at sending ERX");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Creates a patient and moves order to Filling status (convenience method)
     * @param inputData - Test data containing patient and drug information
     * @param storeId - Store number
     * @return rxNbr - The prescription number
     */
    public String createPatientAndMoveToFilling(Map<String, String> inputData, int storeId,int numrefills) {
        int patientId=createPatient(inputData, storeId);
        return moveToFilling(inputData, storeId,patientId);
    }

    /**
     * Moves an existing patient's order to Filling status
     * @param inputData - Test data containing drug information
     * @param storeId - Store number
     * @return rxNbr - The prescription number
     */
    public String moveToFilling(Map<String, String> inputData, int storeId,int patientId) {
        try {
            IDatabaseContext cnx = automationManager.getConnexusDB(storeId);
            DataRow drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("NDC_NUMBER"));
            int numRefills=Integer.parseInt(inputData.get("REFILLS"));
            int fillQuantity = 0; // Default value
            try {
                String fillQtyStr = inputData.get("FILLQUANTITY");
                if (fillQtyStr != null && !fillQtyStr.trim().isEmpty()) {
                    fillQuantity = Integer.parseInt(fillQtyStr.trim());
                }
            } catch (NumberFormatException e) {
                Reporter.log("Invalid fill quantity value, using default: 0");
                fillQuantity = 0;
            }
            InputResponse fillingResponse = connexusAPIManager.createNewOrderAndMoveToFilling(fillQuantity,
                    patientId,
                    storeId,
                    numRefills,
                    drugInfo,
                    inputData.get("NDC_NUMBER")
            );

            rxNbr = String.valueOf(fillingResponse.getRxNbr());
            rxFillId = fillingResponse.getRxFillId();
            orderId = fillingResponse.getOrderId();
            Reporter.log("Order moved to Filling - rxNbr: " + rxNbr + ", rxFillId: " + rxFillId + ", orderId: " + orderId);
            return rxNbr;

        } catch (Exception e) {
            Reporter.log("Failed while moving to Filling: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    /**
     * Creates a patient through API and stores the patientId
     * @param inputData - Test data containing patient information
     * @param storeId - Store number
     * @return patientId - The created patient ID
     */
    public int createPatient(Map<String, String> inputData, int storeId) {
        patientId = performCreatePatientThroughAPI(inputData, storeId);
        return patientId;
    }

    public void performCompleteDropOffAPI(Map<String, String> inputData) {
        try {
            // get patientId
            patientId = getPatientId();
            //setting properties
            requestTypeCode = Integer.parseInt(propertyReader.getProperty("fom.OrderRequestTypeCode"));
            priorityId = Integer.parseInt(propertyReader.getProperty("fom.OrderPriorityId"));
            dispenseType = Integer.parseInt(propertyReader.getProperty("fom.OrderDispenseType"));
            inputRxExpDate = wrapperUtils.getExpiryDate();
            inputPickupDate = wrapperUtils.getPickUpDate();
            drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("DRUG_NAME"));
            //drop off
            resp = connexusAPIManager.createOrderAndDropOff(requestTypeCode, priorityId, dispenseType, patientId, siteId, inputPickupDate, inputRxExpDate, Integer.parseInt(inputData.get("REFILLS")), drugInfo);
            Assert.assertEquals(resp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");
            inputResp = resp.getDataResponse(InputResponse.class);
            Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());
        } catch (Throwable e) {
            Reporter.log("Test failed at DropOff via API");
            Reporter.log("Error message in DropOff " + e.getMessage());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performChkDurAPI() {
        try {
            value = connexusAppUtils.getRxOrderDetailsBasedOnNextWorkQueCode(siteId, rxNbr);
            rxFillId = value.get("rxFillId");
            automationManager.performSleep(20);
            int nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId);
            if (nxtWrkQueCode != WorkQueueCode.CHKDUR.getWorkQueueCode()) {
                Reporter.log("Skipping ChkDUR API. RxNbr: " + rxNbr + " is not in ChkDUR queue or moved to Filling. nextWorkQueCode: " + nxtWrkQueCode);
                return;
            }
            orderDetailsResponse = connexusAPIManager.getOrderDetailsInfo(siteId, rxFillId);
            resp = connexusAPIManager.chkDURComplete(orderDetailsResponse.getDataResponse());
            Assert.assertEquals(resp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
            Assert.assertFalse(resp.getDataResponse().contains("error"), "Check DUR could not be completed");
            Reporter.log("Check DUR completed via API for RxNbr: " + rxNbr);
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR via API");
            Reporter.log("Error message in chkDurAPI " + e.getMessage());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void  performFourPointForAcuteConditionYes() {
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0] , name[1], siteId);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0]+ "," + name[1]);
            orderSearch.openFirstPatientRecord();
            if (fourPoint.onHoldButtonSelected()) {
                fourPoint.unCheckOnHold();
            }
            if (fourPoint.isNameChkBoxDisplayed()) {
                fourPoint.chkName();
                fourPoint.chkPrescribed();
                if (fourPoint.ischkStrength()) {
                    fourPoint.chkStrength();
                }
                fourPoint.chkSIG();
                if (fourPoint.isElementDisplayed(fourPoint.chkDEA, 5)) {
                    fourPoint.click(fourPoint.chkDEA);
                }
                if (fourPoint.isElementDisplayed(fourPoint.rdbAcute, 5)) {
                    fourPoint.click(fourPoint.rdbAcute);
                    fourPoint.click(fourPoint.clickInitialFill);
                }
                if (fourPoint.isElementDisplayed(fourPoint.rdbAcuteInitialFillYes, 5)) {
                    fourPoint.moveToElementAndClick(fourPoint.rdbAcuteInitialFillYes);
                }
                Reporter.logScreenShot("Fourpoint Screen", connexusStartPage.takeScreenShot());
                if (fourPoint.isElementDisplayed(fourPoint.pom1322PopUp)) {
                    fourPoint.click(fourPoint.btnAcceptFill);
                }
                fourPoint.clickAccept();
                Reporter.log("4 point completed");
            }

        } catch (AssertionError e) {
            isExceptionCaptured = true;
            Reporter.log("Assertion failed: " + e.getMessage());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


    /**
     * Reads the saved patient name and opens their record in the input queue.
     * Shared by every input-screen flow so navigation is never copy-pasted.
     */
    protected void navigateToPatientInputRecord() {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        orderSearch.launchOrderSearchScreen();
        orderSearch.performSearch(name[0] + "," + name[1]);
        orderSearch.openFirstPatientRecord();
    }

    /**
     * Fills the five mandatory Rx fields on an already-open input screen using
     * {@code QUANTITY} as the prescribed quantity.
     *
     * <p>{@code QUANTITY} is the standard/final quantity for the prescription.
     * Use this for normal input flows and validation tests.
     * For date-selection flows that intentionally use a larger quantity to trigger
     * a quantity-change popup, the private overload with an explicit key is used.
     *
     * <p>This is the lowest-level shared step. Callers that also need optional
     * sections (attending physician, TM/DX/triplicate) should call
     * {@link #fillCoreRxFields(Map)} instead.
     */
    protected void fillBasicRxFields(Map<String, String> inputData) {
        fillBasicRxFields(inputData, "QUANTITY");
    }

    /**
     * Internal overload that lets callers specify which quantity data key to use.
     *
     * <ul>
     *   <li>{@code "QUANTITY"} – standard/final quantity (normal flows)</li>
     *   <li>{@code "EXTEND_QUANTITY"} – deliberately larger quantity used by
     *       date-selection tests to trigger a quantity-validation popup; after
     *       the popup is handled the test may reset back to the original quantity</li>
     * </ul>
     */
    protected void fillBasicRxFields(Map<String, String> inputData, String quantityKey) {
        inputPage.enterNdc(inputData.get("DRUG_NAME"));
        inputPage.clickProductSearch3Dots();
        inputPage.enterPrescribedQty(inputData.get(quantityKey));
        inputPage.enterSigCode(inputData.get("SIG"));
        inputPage.enterRefillQty(inputData.get("REFILLS"));

        // PRESCRIBER_STATE drives the prescriber state selection in the lookup grid.
        // STATE_UPDATE is separate — it is only for store/site state change.
        // NOTE: Use V2 — enterPrescriberBasedOnState (V1) targets the dgvLocFind grid
        // which no longer exists in the UI. V2 correctly uses dgvLocation for both
        // state and phone lookups, and includes dynamic row count + failure guards.
        String prescriberState = inputData.get("PRESCRIBER_STATE");

        if (prescriberState != null && !prescriberState.trim().isEmpty()) {
            inputPage.enterPrescriberBasedOnStateV2(inputData.get("PRESCRIBER_NAME"), prescriberState);
        } else {
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
        }
    }

    /**
     * Extends {@link #fillBasicRxFields(Map)} with optional attending-physician
     * entry and the TM-code / DX-code / triplicate conditional sections.
     * Does <em>not</em> navigate to the record and does <em>not</em> click Accept.
     *
     * <p>Use this when the test should auto-fill every available field.
     * Use {@link #fillBasicRxFields(Map)} when the test deliberately leaves
     * DX-code or TM-code empty to trigger a validation popup.
     */
    protected void fillCoreRxFields(Map<String, String> inputData) {
        fillCoreRxFields(inputData, "QUANTITY");
    }

    /**
     * Internal overload that threads an explicit quantity key through to
     * {@link #fillBasicRxFields(Map, String)}.
     * Used by date-selection flows that must enter {@code EXTEND_QUANTITY}.
     */
    protected void fillCoreRxFields(Map<String, String> inputData, String quantityKey) {
        fillBasicRxFields(inputData, quantityKey);

        // Attending physician is optional — skip when the key is absent or blank
        String attendingPrescriber = inputData.get("ATTENDING_PRESCRIBER");
        if (attendingPrescriber != null && !attendingPrescriber.trim().isEmpty()) {
            inputPage.enterAttendingPhysicianName(attendingPrescriber);
        }

        if (inputPage.isTMCodeDisplayed()) {
            inputPage.selectTmCodeField(2);
        }
        if (inputPage.isDxCodeDisplayed()) {
            inputPage.inputRandomDXCode();
        }
        if (inputPage.isTriplicateDisplayed()) {
            inputPage.inputTriplicateNumber();
        }
    }

    /**
     * Convenience composition for date-selection flows: navigate → fill fields
     * using {@code EXTEND_QUANTITY} (the intentionally larger quantity that
     * triggers a quantity-change validation popup before date selection).
     * Does NOT include address-popup handling.
     */
    private void fillRxInputFields(Map<String, String> inputData) {
        navigateToPatientInputRecord();
        fillCoreRxFields(inputData, "EXTEND_QUANTITY");
    }

    /**
     * Completes the V2 prescriber section on an already-open input screen.
     *
     * <p>Call this <em>after</em> {@code enterPrescriberBasedOnStateV2} (and any
     * authority checks the caller needs to perform). This helper handles:
     * <ol>
     *   <li>{@code clickPrescriberTab} – confirms prescriber selection</li>
     *   <li>Screenshot at the prescriber tab</li>
     *   <li>{@code clickAttendingPhysicianTab} – switches to attending section</li>
     *   <li>{@code enterAttendingPhysicianName} – from {@code ATTENDING_PRESCRIBER}</li>
     *   <li>TM-code, DX-code and triplicate conditional sections</li>
     * </ol>
     *
     * <p>Used by any flow that goes through the V2 prescriber path so the
     * tab-navigation and optional-field logic is never copy-pasted.
     */
    protected void fillV2PrescriberTabsAndOptionalFields(Map<String, String> inputData, String currentStepMethodName) {
        inputPage.clickPrescriberTab();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        inputPage.clickAttendingPhysicianTab();
        inputPage.enterAttendingPhysicianName(inputData.get("ATTENDING_PRESCRIBER"));
        if (inputPage.isTMCodeDisplayed()) {
            inputPage.selectTmCodeField(2);
        }
        if (inputPage.isDxCodeDisplayed()) {
            inputPage.inputRandomDXCode();
        }
        if (inputPage.isTriplicateDisplayed()) {
            inputPage.inputTriplicateNumber();
        }
    }

    /**
     * Navigates to the patient's input record, dismisses any address-validation
     * popup, fills all Rx fields (including TM/DX/triplicate conditionals), then
     * clicks Accept — stopping there so the caller can assert on whatever
     * validation popup the application raises.
     *
     * <p>Use this as the setup step for any test that validates a popup on the
     * input screen (e.g. invalid days-supply, state law limits).
     * <strong>Do not</strong> use it when the test must complete the full
     * accept / popup-chain.
     *
     * @param inputData test data map; supports both {@code QUANTITY} and
     *                  {@code EXTEND_QUANTITY} for prescribed quantity
     */
    public void performInputAndClickAccept(Map<String, String> inputData, boolean shouldClickAccept) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            navigateToPatientInputRecord();
            inputPage.isAddressValidationViewPopupDisplayed();
            fillCoreRxFields(inputData);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (shouldClickAccept) {
                inputPage.clickAccept();
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    /**
     * Clicks the Accept button on the Input page.
     * Use this after performing validations when accept was skipped
     * via {@link #performInputAndClickAccept(Map, boolean)}.
     */

    public void clickAcceptOnInputPage() {
        try {
            inputPage.clickAccept();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Shared input flow: searches patient, fills Rx fields, applies a date selection,
     * then clicks through accept/validation popups.
     *
     * @param dateSelectionAction the date-specific step to run after product fields are filled
     *                           (e.g. expiry-date or written-date selection)
     */
    private void performInputWithDateSelection(Map<String, String> inputData, Runnable dateSelectionAction) {
        fillRxInputFields(inputData);
        dateSelectionAction.run();
        inputPage.clickAccept();
        inputPage.clickYesOnValidateRxPopUp();
        inputPage.clickOnOutofStockPopupOk();
        inputPage.clickYesOnValidateRxPopUp();
        inputPage.partialpopup();
        inputPage.clickAccept();
        inputPage.clickOnOutofStockPopupOk();
    }

    public void performInputWithExpiryDateGreaterThan90Days(Map<String, String> inputData, int noOfDays) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            performInputWithDateSelection(inputData, () -> inputPage.rxExpiryDateSelection(noOfDays));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performInputWithWrittenDateLessThan90Days(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            performInputWithDateSelection(inputData, () -> inputPage.rxWrittenDateSelection(-90));
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Input not Completed", "Failed", "E2E_execution_status.txt", 30, DateTime.now());
        }
    }

    /**
     * Lightweight: only updates written date on an already-filled input screen.
     * Use this after performInputWithExpiryDateGreaterThan90Days when
     * all Rx fields are already populated.
     */
    public void updateWrittenDateAndAccept(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            inputPage.rxWrittenDateSelection(-90);
            inputPage.clickAccept();
            inputPage.clickYesOnValidateRxPopUp();
            inputPage.clickOnOutofStockPopupOk();
            inputPage.clickYesOnValidateRxPopUp();
            inputPage.partialpopup();
            inputPage.clickAccept();
            inputPage.clickOnOutofStockPopupOk();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Input not Completed", "Failed", "E2E_execution_status.txt", 30, DateTime.now());
        }
    }

    /**
     * Verifies popup text against expected value, takes screenshot, then dismisses.
     *
     * @param inputData       test data map
     * @param expectedTextKey the key in inputData holding the expected popup text
     * @param exitInputScreen if true, clicks Cancel + Yes to leave the input screen after popup
     */
    private void verifyPopUpTextAndDismiss(Map<String, String> inputData, String expectedTextKey, boolean exitInputScreen) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String actualText   = inputPage.getValidationPopText();
            String expectedText = inputData.get(expectedTextKey);
            Assert.assertEquals(actualText, expectedText);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.dismissValidationPopupAndWait();
            if (exitInputScreen) {
                // After dismissing any validation popup the written date field and quantity
                // may still hold the invalid values that triggered it. Reset both to their
                // original values before re-accepting so the same popup does NOT re-fire.
                inputPage.resetWrittenDateToToday();
                inputPage.clearDispensedProductQty();
                inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
                if (inputPage.isTriplicateDisplayed()) {
                    inputPage.inputTriplicateNumber();
                }
                inputPage.clickAccept();
                inputPage.clickYesOnValidateRxPopUp();
                inputPage.clickOnOutofStockPopupOk();
                inputPage.clickYesOnValidateRxPopUp();
                inputPage.partialpopup();
                inputPage.clickAccept();
                inputPage.clickOnOutofStockPopupOk();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyInvalidRxDatePopUpAndClickYes(Map<String, String> inputData) {
        verifyPopUpTextAndDismiss(inputData, "PRESCRIPTION_TEXT", true);
    }

    /**
     * Modify-screen context: verifies the PRESCRIPTION_TEXT popup that fires when a
     * written date older than 90 days is accepted on the Modify Details screen, then
     * clicks the Yes button to confirm proceeding. The Modify screen closes after Yes.
     *
     * <p>Call {@link #launchModifyScreenForValidation()} before this method.
     */
    public void verifyInvalidRxDatePopUpAndClickOKOnModifyScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String actualText = inputPage.getValidationPopText();
            // TODO: TEMP WORKAROUND - Remove once Modify screen double-space bug is fixed.
            Assert.assertEquals(actualText.replaceAll("\\s+", " ").trim(),
                    inputData.get("PRESCRIPTION_TEXT").replaceAll("\\s+", " ").trim());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickOKBtn();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Clicks the Cancel button on the Modify Details screen and confirms the
     * "Abandon Changes?" dialog by clicking Yes, cleanly closing the screen
     * without saving any in-progress changes.
     *
     * <p>Call this after verifying a popup on the Modify screen when you need
     * to reopen a fresh Modify Details screen for the next validation step.
     */
    public void clickCancelOnModifyScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            modifyDetails.clickCancel();
            modifyDetails.clickYes();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Navigates from the Fill work-queue to the Modify Details screen for the current
     * {@code rxNbr}. This is the shared navigation entry-point to call before
     *
     * <p>Asserts that the Rx is in the Fill queue before attempting navigation.
     */
    public void launchModifyScreenForValidation() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertTrue(
                    checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue()),
                    "Rx [" + rxNbr + "] is not in the Fill queue – cannot launch Modify screen."
            );
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            modifyDetails.launchModifyDetailScreen();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /** Verifies popup, clicks OK, then clicks Accept to resubmit. Input screen stays open. */
    public void verifyInvalidRxDatePopUpOnly(Map<String, String> inputData) {
        verifyPopUpTextAndDismiss(inputData, "PRESCRIPTION_TEXT", false);
    }

    public void verifyInputPopUpAndInputAccept(Map<String, String> inputData) {
        verifyPopUpTextAndDismiss(inputData, "VALIDATION_TEXT", true);
    }

    /** Verifies popup and keeps the input screen open for further updates. */
    public void verifyInputPopUpOnly(Map<String, String> inputData) {
        verifyPopUpTextAndDismiss(inputData, "VALIDATION_TEXT", false);
    }


    /** Verifies popup and keeps the Modify screen open for further updates. */
    public void verifyModifyPopUpOnly(Map<String, String> inputData) {
        verifyPopUpTextAndDismiss(inputData, "VALIDATION_TEXT", false);
    }
    /**
     * Navigates to the patient's input record, enters the prescribed fields using
     * {@code EXTEND_QUANTITY} (a deliberately larger quantity to breach the days-supply
     * limit), asserts the expected validation popup text, then corrects the dispensed
     * quantity to {@code QUANTITY} and completes the full accept chain.
     *
     * <p>Uses the V2 prescriber flow with an authority check before proceeding to
     * the prescriber tabs.
     */
    public void performInputWithGreaterThanDaysSupplyLimitAndUpdateDispenseQty(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            navigateToPatientInputRecord();
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(inputData.get("EXTEND_QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterPrescriberBasedOnStateV2(inputData.get("PRESCRIBER_NAME"), inputData.get("STATE_UPDATE"));
            if (inputPage.getInputScreenPopupMessage().contains("Prescriber does not have authority")) {
                Assert.fail("Entered Prescriber does not have authority. select a valid prescriber");
            }
            fillV2PrescriberTabsAndOptionalFields(inputData, currentStepMethodName);
            inputPage.clickAccept();
            Assert.assertEquals(inputData.get("VALIDATION_TEXT").trim(), inputPage.getValidationPopText().trim());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickOKButtonDEAPopup();
            inputPage.clickDispensedProductQty();
            inputPage.clearDispensedProductQty();
            inputPage.enterDispensedProductQty(inputData.get("QUANTITY"));
            inputPage.clickAccept();
            inputPage.clickYesOnValidateRxPopUp();
            inputPage.clickOnOutofStockPopupOk();
            inputPage.clickYesOnValidateRxPopUp();
            Reporter.log("Input completed");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Input not Completed", "Failed", "E2E_execution_status.txt", 30, DateTime.now());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * On the already-open Modify Details screen, sets the written date to 90 days in
     * the past and clicks Accept, which fires the invalid-Rx-date warning popup.
     *
     * <p>Prerequisite: call {@link #launchModifyScreenForValidation()} first to navigate
     * to the Modify screen. After clicking Accept the popup will be visible – dismiss it
     *
     */
    public void ClickOnAcceptButtonByProvidingWrittenDateLessThan90Days(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            modifyDetails.rxWrittenDateSelection(-90);
            modifyDetails.enterPresQty(inputData.get("EXTEND_QUANTITY"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());

            modifyDetails.clearDespQty();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());

            modifyDetails.enterDespQty(inputData.get("EXTEND_QUANTITY"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickAccept();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


    /**
     * Updates Prescribed and Dispensed quantities on the Modify Details screen
     * and clicks Accept.
     *
     * <p>Use this when the test needs to change quantities to trigger or clear
     * a validation popup (e.g., Days Supply limit).
     *
     * @param inputData  test data map
     * @param quantityKey data key to use (e.g., "QUANTITY", "EXTEND_QUANTITY")
     */
    public void updateQuantitiesAndAcceptInModifyDetails(Map<String, String> inputData, String quantityKey) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            modifyDetails.enterPresQty(inputData.get(quantityKey));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());

            modifyDetails.clearDespQty();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());

            modifyDetails.enterDespQty(inputData.get(quantityKey));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickAccept();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * On the already-open Modify Details screen, updates the prescriber, sets the
     * Rx expiry date 91 days beyond its current value (exceeding the 90-day limit),
     * enters {@code EXTEND_QUANTITY} as the dispensed quantity, then clicks Accept.
     * This triggers the PRESCRIPTION_TEXT expiry-date warning popup — the same popup
     * fired on the Input screen — so dismiss it with
     * {@link #verifyInvalidRxDatePopUpOnly(Map)} which keeps the Modify screen open.
     *
     * <p>Prerequisite: call {@link #launchModifyScreenForValidation()} first.
     */
    public void ClickOnAcceptButtonByProvidingrxExpiryDateSelectionThan90Days(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // modifyDetails.enterPrescriberName(inputData.get("PRESCRIBER_NAME"));
            modifyDetails.rxExpiryDateSelection(1);
            /*modifyDetails.enterPresQty(inputData.get("EXTEND_QUANTITY"));
            modifyDetails.clearDespQty();
            modifyDetails.enterDespQty(inputData.get("EXTEND_QUANTITY"));*/
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickAccept();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateRemainingQuantityAndRxNotesInModifyDetailsScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            performChkDUR();
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                orderSearch.openFirstPatientRecord();
                modifyDetails.launchModifyDetailScreen();
                Assert.assertEquals(Integer.parseInt(modifyDetails.getRemainingQuantity()),0);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                menuBar.launchRxNotesScreen();
                consolidatedNotesPage.clickViewMoreLink();
                String date = consolidatedNotesPage.getTxtDate().trim();
                String time = consolidatedNotesPage.getTxtTime().trim();
                String username = consolidatedNotesPage.getTxtUser().trim();
                String siteId = consolidatedNotesPage.getTxtSiteId().trim();
                String rxNumber = consolidatedNotesPage.getRxNbr().trim();
                String notes = consolidatedNotesPage.getTxtNotes().trim();
                String drugName = consolidatedNotesPage.getDrugName().trim();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                consolidatedNotesPage.clickCancel();
                consolidatedNotesPage.clickCancel();
                orderSearch.clickYes();
                Reporter.log("Rx notes card displayed with " + date + time + username + siteId + rxNumber + drugName + notes);
                Assert.assertEquals(notes, inputData.get("OVERRIDDEN_MESSAGE"));
                Assert.assertEquals(drugName.trim(), productName);
                Assert.assertEquals(siteId, propertyReader.getProperty("cnx.store"));
                Assert.assertEquals(rxNumber, rxNbr);
                modifyDetails.clickAccept();
            }
        } catch (Throwable e) {
            e.printStackTrace();
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail();
        }
    }

    public boolean verifyActivityCodeInRxActivityTable() {
        List<Map<String, Object>> resultSet = connexusAppUtils.verifyActivityCode(rxNbr);
        assert resultSet != null;
        if (resultSet.size() == 1) {
            Reporter.log("Activity code 15237 is inserted in the RX_activity table for Rx number "+ rxNbr);
            Assert.assertTrue(true, "Activity code inserted in DB");
        } else {
            Assert.fail("Activity code not inserted");
        }
        return true;
    }

    public void moveMultiRxToEod() {
        String rxNbr;
        int patientId = getPatientId();
        List<Integer> multiRxNum = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        try {
            for (int i = 0; i < multiRxNum.size(); i++) {
                rxNbr = String.valueOf(multiRxNum.get(i));
                ServiceResponse eodApiStatus = connexusAPIManager.moveToEOD(connexusAppUtils.getFillId(rxNbr), siteId);
                Assert.assertTrue("OK".equals(eodApiStatus.getStatusDesc()), "Failed to move Rx " + rxNbr + " to EOD , eod API status is " + eodApiStatus.getStatusDesc());
                Reporter.log("Rx " + rxNbr + " moved to EOD ");
            }
        } catch (Exception e) {
            Reporter.log("Test failed at Input queue: " + e.getMessage());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }


    /**
     * Validate rx problemdescription in connexus.
     *
     * @param inputData the input data
     */
    public void validateRxProblemdescriptionInConnexus(Map<String, String> inputData) {

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        orderSearch.launchOrderSearchScreen();
        orderSearch.performSearch(rxNbr);
        Reporter.log("rxNumber : " + rxNbr);
        String problemMessage = orderSearch.clickUntilElementPresent(0);
        if (problemMessage.equalsIgnoreCase(inputData.get("ProblemDescription"))) {
            Reporter.log("problemMessage : " + problemMessage);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(true);
        } else {
            Assert.fail("Problem description is not in " + inputData.get("ProblemDescription"));
        }
        orderSearch.closeSearch();
    }

    public void verifyPatientWorkQueueAndProblemStatus () {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        ConnexusStartPage connexusStartPage = new ConnexusStartPage();
        F6Search orderSearch = new F6Search();
        patientSearchPage = new PatientSearchPage();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Manual Resolution")) {
                Reporter.log("Patient is in Resolve Queue");
                am.getConnexusWorkFlow().performRphManualResolution(rxNbr);
                Reporter.log("Unauthorised drug problem is resolved");
            }
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            Reporter.log("WorkQueue:" + statusAndProblem.get(0));
            Reporter.log("Problem:" + statusAndProblem.get(1));
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && "Patient Name Mismatch".equalsIgnoreCase(statusAndProblem.get(1))) {
                patientSearchPage.openFirstPatientRecord();
                Reporter.log("Problem is patient Name Mismatch so Resolution Page is launched to create patient");
            }
        } catch (Throwable e) {
            Reporter.log("Patient is not resolve queue or problem message did not match");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performPatientSearchAndPatientCreationWithTP(Map<String, String> inputData) {
        //perform search from resolution page and create Patient With TP
        ResolutionPage resolutionPage = new ResolutionPage();
        resolutionPage.clickPatientSearch();
        createNewPatientWithTP(inputData);
        resolutionPage.selectPriority(String.valueOf(Priority.Today));
        //verifyDetailsFromCentralPatientLookup();
        resolutionPage.clickUsePatientButton();
    }

    public void createNewPatientWithTP(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        ThirdPartyModel thirdPartyModel = new ThirdPartyModel();
        ConnexusStartPage connexusStartPage = new ConnexusStartPage();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            Log.info("" + name[1] + "," + name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            thirdPartyModel.setCarrierBin(inputData.get("TP_CARRIER_BIN"));
            thirdPartyModel.setPlan(inputData.get("TP_PLAN"));
            thirdPartyModel.setCardId(inputData.get("TP_CARD_ID"));
            patient.setPatientTp(thirdPartyModel);
            if(addressModel==null) {
                addressModel = new AddressModel();
                addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
                addressModel.setPatientCity(inputData.get("CITY"));
                addressModel.setPatientState(inputData.get("STATE"));
                addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
                if (patientMaintenancePage.isOkDisplayed()) {
                    patientMaintenancePage.clickOk();
                }
                addressModel.setPatientCountry(inputData.get("COUNTRY"));
                patient.setPatientAddress(addressModel);

                contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
                patient.setPatientContact(contactModel);
            }
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            automationManager.getConnexusWorkFlow().createNewPatientFromResolutionPage(true, patient);

            Reporter.log("Patient has been created.");

        } catch (Throwable e) {
            Reporter.log("Test failed while creating patient");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }


    /**
     * This Method will complete till Filling for Multi RX
     *
     * @param inputData
     * @return
     */
    public List<InputResponse> moveToFillingForMultiRx(Map<String, String> inputData, int patientId, int numOfRxs) throws JsonProcessingException {
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        ndcList = new ArrayList<>();
        for (int i = 0; i < numOfRxs; i++) {
            int temp = i + 1;
            ndcList.add(inputData.get("DRUG_NAME" + temp));
        }
        multiRx4PointCompleteResp = connexusAPIManager.createMultiRxAndMoveToFilling(patientId, siteId, numRefills, ndcList, connexusAPIManager.PrescriberDetails());
        for (int i =0; i < numOfRxs; i++) {
            multiRxNbr.add(String.valueOf(multiRx4PointCompleteResp.get(i).getRxNbr()));
        }
        return multiRx4PointCompleteResp;
    }
    public void searchAndHandleExistingPatient(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            // Extract patient details from inputData
            String firstName = inputData.get("FIRST_NAME");
            String lastName = inputData.get("LAST_NAME");
            String dob = inputData.get("DOB");
            String patientNameForSearch = lastName + ", " + firstName;
            // Search for the patient
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(patientNameForSearch);
            patientSearchPage.clickSearchNow();
            Reporter.logScreenShot("Patient Search screen", patientSearchPage.takeScreenShot());
            // Check if a patient record exists
            if (patientSearchPage.isPatientRecordDisplayed(0)) {
                Reporter.log("Patient found: " + patientNameForSearch);
                patientSearchPage.openFirstPatientRecord();
                patientMaintenancePage.closePTMScreen();
            } else {
                Reporter.log("Patient not found. Creating a new patient: " + firstName + " " + lastName);
                // If doesn't exist,Create a new patient
                PatientProfileModel patient = new PatientProfileModel();
                patient.setPatientFirstName(firstName);
                patient.setPatientLastName(lastName);
                patient.setPatientDob(dob);
                patient.setPatientGender(PatientProfileModel.PatientGender.valueOf(inputData.get("GENDER").toUpperCase()));
                AddressModel address = new AddressModel();
                address.setPatientAddressLine1(inputData.get("ADDRESS"));
                address.setPatientCity(inputData.get("CITY"));
                address.setPatientState(inputData.get("STATE"));
                address.setPatientZipCode(inputData.get("ZIP_CODE"));
                patient.setPatientAddress(address);
                am.getConnexusWorkFlow().createNewPatient(false, patient);
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }


    /*
     * Method to perform Complete Counsel through API
     * */
    public void performCounselAPI() {
        try {
            value = connexusAppUtils.getRxOrderDetailsBasedOnNextWorkQueCode(siteId, rxNbr);
            rxFillId = value.get("rxFillId");
            orderDetailsResponse = connexusAPIManager.getOrderDetailsInfo(siteId, rxFillId);
            resp = connexusAPIManager.counselComplete(orderDetailsResponse.getDataResponse());
            Assert.assertEquals(resp.getStatusCode(), 302, "CounselComplete API response status code did not match");
            Assert.assertFalse(resp.getDataResponse().contains("error"), "Counsel could not be completed");
            Reporter.log("Counselling completed via API for RxNbr: " + rxNbr);
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR via API");
            Reporter.log("Error message in chkDurAPI " + e.getMessage());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /*
     * This method will perform Multi RX Input
     * @param inputData
     * @param addRxUI
     * */
    public void performMultiRxInput(Map<String, String> inputData, boolean addRxUI) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        if (addRxUI) {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            inputPage.addRxButtonAndValidate();
        }
        ndcList = Arrays.asList(inputData.get("DRUG_NAME"), inputData.get("DRUG_NAME2"));
        int totalRxCount = addRxUI ? Integer.parseInt(inputPage.getTextNoOfRxField()) : ndcList.size();
        Reporter.log("totalRxCount:" + totalRxCount);
        try {
            for (int i = 0; i < totalRxCount; i++) {
                rxModel.setPatientLastName(name[0]);
                rxModel.setPatientFirstName(name[1]);
                rxModel.setNdc(ndcList.get(i));
                rxModel.setPrescribedQty(inputData.get("QUANTITY"));
                rxModel.setSigCode(inputData.get("SIG"));
                rxModel.setNoOfRefills(inputData.get("REFILLS"));
                rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
                rxStatus = orderSearch.getRXStatusBasedOnRxIndex(name[0] + "," + name[1], i);
                if (rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue())) {
                    Reporter.log("RX is in Input queue");
                    automationManager.getConnexusWorkFlow().performMultiRxInput(rxModel, i);
                } else {
                    Reporter.log("RX is not in Input queue");
                    Assert.fail();
                }
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Input queue");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /*
     * Method to modify Qty in POS queue
     **/
    public void performPOSModifyQty(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.POS.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.openModifyDetailsScreen();
                if (modifyDetails.isTxtPrescriberQtyDisplayed()) {
                    modifyDetails.clearPrescriberQty();
                    modifyDetails.enterPresQty(inputData.get("PrescribedQuantity"));
                }
                modifyDetails.clickAccept();
                modifyDetails.rxExpAndDrugDateSelection();
                Reporter.logScreenShot(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.checkAndClickWarning();
                modifyDetails.clickAccept();
            }
            Reporter.log("RX is moved to the 4Point queue after updating the Qty in POS");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Test failed at POS queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /*
     * Validates new fill ID is created after modifying quantity in POS
     **/
    public void validateNewFillIdCreatedAfterModifyInPOS() {
        try {
            Integer secondRxFillId = connexusAppUtils.fetchSecondRxFillId(siteId, rxNbr);
            Reporter.log("Validation successful: New fill ID created after modify qty. rxNbr: " + rxNbr + ", New rx_fill_id: " + secondRxFillId);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Failed to validate new fill ID creation after modification: " + e.getMessage());
            Assert.fail(e.toString());
        }
    }
    public void verifyRxInVisualVerifyQueue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0], name[1], siteId);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.VisualVerify.getValue())) {
                takeScreenShotRXStatus(rxNbr, WorkQueue.VISUAL_VERIFY.getWorkQueue(), currentStepMethodName, Status.PASS);
                Assert.assertTrue(true);
                Reporter.log("RX is in Visual Verify queue");
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in Visual Verify Queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at verify Visual Verify queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyRxInResolutionQueueWithExpectedProblem(String expectedProblem) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        ConnexusStartPage connexusStartPage = new ConnexusStartPage();
        F6Search orderSearch = new F6Search();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            Assert.assertEquals(orderSearch.getWorkQueue(0).toLowerCase(), WorkQueue.RESOLVE.getWorkQueue());
            String actualProblem = orderSearch.getProblemMessage(0);
            Assert.assertEquals(actualProblem, expectedProblem, "The problem in resolution queue does not match the expected problem.");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("The problem in resolution queue matches the expected problem: " + expectedProblem);
            orderSearch.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyRxIsChkDur() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                takeScreenShotRXStatus(rxNbr, WorkQueue.CHK_DUR.getWorkQueue(), currentStepMethodName, Status.PASS);
                Assert.assertTrue(true);
                Reporter.log("RX is in chkDur queue");
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in chkDur Queue");
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at ChkDUR queue");
            softAssert.fail(e.toString());
        }
    }
}