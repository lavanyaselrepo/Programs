package connexus.OrderIntake.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.junit.platform.commons.util.StringUtils;
import org.testng.Assert;

import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.prop;

public class OrderIntakeTestScripts extends ConnexusTestScripts {
    String ErrorText, attendingPhysicianAdd;
    long daysDifference = 0;
    String UpdatedExpDate, WrittenDate;
    int fillId;

    public OrderIntakeTestScripts(LoginAs.userType userType) {
        super(userType);
    }

    public void restartService() {
        connexusAPIManager.restartConnexusService(String.valueOf(siteId));
    }

    public Prescriber PrescriberDetails() {
        DBUtils dbUtils = new DBUtils();
        int rxClinicId, prescriberId;
        int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        Prescriber prescriber = new Prescriber();
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        DataRow prescriberDetails = dbUtils.getRxClinicIdAndPrescriberId(cnx);
        rxClinicId = prescriberDetails.getValue("clinic_id");
        prescriberId = prescriberDetails.getValue("prescriber_id");
        prescriber.setFullname(prop.getProperty("fom.connexusWrapper.prescriberFullName"));
        prescriber.setFirstname(prop.getProperty("fom.connexusWrapper.prescriberFirstName"));
        prescriber.setLastname(prop.getProperty("fom.connexusWrapper.prescriberLastName"));
        prescriber.setPhone(prop.getProperty("fom.connexusWrapper.prescriberPhone"));
        prescriber.setState(prop.getProperty("fom.connexusWrapper.prescriberState"));
        prescriber.setPrescriberId(prescriberId);
        prescriber.setRxClinicId(rxClinicId);
        prescriber.setDea(prop.getProperty("fom.connexusWrapper.prescriberDea"));
        prescriber.setNpi(prop.getProperty("fom.connexusWrapper.prescriberNpi"));
        return prescriber;
    }

    public void createMultiRXtoEOD() {
        List<String> ndcList = Arrays.asList("59630007410 ", "68047034316", "11528010516");
        Reporter.log("multi Order creation");
        int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        int patientId = getPatientId();
        int numRefills = 1;
        Prescriber prescriber;
        prescriber = PrescriberDetails();

        connexusAPIManager.createMultiRxDropOffToEod(patientId, siteId, numRefills, ndcList, prescriber);
    }

    public void inputwithPrescriberModifications(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            patientSearchPage.openFirstPatientRecord();
            patientSearchPage.openFirstPatientRecord();
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterAttendingPrescriber(inputData.get("PRESCRIBER"));
            Assert.assertFalse(inputPage.isAttendingPhysicianTabEnabled());
            inputPage.clearPrescriberName();
            inputPage.enterAttendingPrescriber(inputData.get("PRESCRIBER_2"));
            inputPage.inputDxCode("1234");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            Assert.assertTrue(inputPage.isInvalidDataPopUpDisplayed());
            inputPage.clickButtonOk();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterAttendingPhysicianName(inputData.get("ATTENDING_PRESCRBER"));
            inputPage.clickAccept();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            rxNbr = getRxNbr(name[0], name[1], siteId);
            if (rxNbr == null || rxNbr.isEmpty()) {
                Reporter.log("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                Assert.fail("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
            }
            Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void modifyPrescribers(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            patientSearchPage.openFirstPatientRecord();
            performResolveQueue(rxNbr);
            modifyDetails.openModifyDetailsScreen();
            modifyDetails.clearPrescriberName();
            modifyDetails.enterPrescriber(inputData.get("PRESCRIBER"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.escape();
            modifyDetails.clickCancel();
            modifyDetails.clickYes();
            modifyDetails.clickOnPrescriberName1();
            modifyDetails.clickOnReturnToTech();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clearPrescriberName();
            inputPage.enterPrescriber(inputData.get("PRESCRIBER"));
            inputPage.click(modifyDetails.txtpatientName);
            inputPage.clickAccept();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void VerifyAPin4point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                Assert.fail("Rx is not in 4 point");
            }
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            patientSearchPage.openFirstPatientRecord();
            Assert.assertFalse(inputPage.isAttendingPhysicianTabEnabled());
            modifyDetails.openModifyDetailsScreen();
            Assert.assertFalse(inputPage.isAttendingPhysicianTabEnabled());
            Reporter.log("attending physician is not enabled");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    //called from commented(obsoleted) test case
    public void performDropOffForARXWithNoRefills() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickYesInPopUp();
            dropOffPage.selectPriority("Critical");
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickBtnAccept();
            Reporter.log("Drop-Off completed");
            softAssert.assertAll();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }

    public void verifyNoAttendingPhysicianModifyDetails() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            modifyDetails.openModifyDetailsScreen();
            boolean attendingPhysicianTab = modifyDetails.attendingPhysicanDisplayed();
            Assert.assertFalse(attendingPhysicianTab);
            Reporter.log("Validating attending physician tab is not available in modifydetails screen");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickCancel();
            modifyDetails.clickFloatingOkButton();
            modifyDetails.clickYes();
            inputPage.clickCancel();
            inputPage.clickYes();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Attending physician tab is available in modifydetails screen");
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /*
     * Method to enter required details in Input screen for HWPHME2E-3179 test case.
     * Below method will insert details in input screen and select specific prescriber clinic address
     * Author: Niraj Kumar(vn50sfl)
     * */
    public void performInputAndSelectPresAddress(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.openSearch();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            orderSearch.selectRowFromSearch(0);
            inputPage.enterNDCInProductName(inputData.get("PRODUCT_NDC"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.selectDAW(0);
            inputPage.enterPrescriberBasedOnAddress(inputData.get("PRESCRIBER_DEA"), inputData.get("STATE"));
            Reporter.log("Entered drug NDC " + inputData.get("PRODUCT_NDC"));
            Reporter.log("Prescribed by prescriber having DEA " + inputData.get("PRESCRIBER_DEA"));
            boolean isATTabVisible = inputPage.isAttendingPhysicianTabEnabled();
            Assert.assertFalse(isATTabVisible);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Attending  Physician tab is not available in Input");
            inputPage.clickAccept();
            inputPage.clickYesOnValidateRxPopUp();
            inputPage.clickOnOutofStockPopupOk();
            inputPage.clickYesOnValidateRxPopUp();
            rxNbr = getRxNbr(name[0], name[1], siteId);
            if (rxNbr == null || rxNbr.isEmpty()) {
                Reporter.log("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                Assert.fail("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
            }
            Reporter.log("Input completed");
            Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /* Method to just enter required details in Input screen .
     * Below method will only insert details in input screen and select specific prescriber clinic address
     * It will not click on accept button
     * Author: Niraj Kumar(vn50sfl)*/
    public void insertDetailsInInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            orderSearch.selectRowFromSearch(0);
            inputPage.enterNDCInProductName(inputData.get("PRODUCT_NDC"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterPrescriberBasedOnAddress(inputData.get("PRESCRIBER_DEA"), inputData.get("STATE"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            Reporter.log("Entered drug NDC " + inputData.get("PRODUCT_NDC"));
            Reporter.log("Prescribed by prescriber having DEA " + inputData.get("PRESCRIBER_DEA"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void inputComplete() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
                inputPage.inputRandomDXCode();
            }
            inputPage.clickAccept();
        }catch(Throwable e){
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }


    /* Method to validate non-availability of attending physician tab in input
     * Author: Niraj Kumar(vn50sfl) */
    public void validateNoAttendingPhyPopUp() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            boolean isATTabVisible = inputPage.isAttendingPhysicianTabEnabled();
            Assert.assertFalse(isATTabVisible, "Attending  Physician tab is available");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Attending  Physician tab is not available");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Attending  Physician tab is available");
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }


    /* Method to validate availability of attending physician tab
     * Author: Niraj Kumar(vn50sfl) */
    public void validateAttendingPhyDetails(Map<String, String> inputData, String viewName, String operation) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        boolean isATTabVisible;
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            switch (viewName.toLowerCase()) {
                case "input":
                    isATTabVisible = inputPage.isAttendingPhysicianTabDisplayed();
                    Assert.assertTrue(isATTabVisible, "Attending  Physician tab is not available in input");
                    Reporter.log("Attending  Physician tab is available in " + viewName);
                    if (Objects.equals(operation, "enterDetails")) {
                        inputPage.enterAttendingPhyNameAndSelectClinicAdd(inputData.get("ATTENDING_PHYSICIAN_DEA"), Integer.parseInt(inputData.get("ATTENDING_PHYSICIAN_ADD_INDEX")));
                        attendingPhysicianAdd = inputPage.getAttendingPhysicianAddValue();
                        Reporter.log("Attending physician name is " + inputPage.getAttendingPhysicianName());
                        Assert.assertEquals(inputPage.getAttendingPhysicianName(), inputData.get("ATTENDING_PHYSICIAN"));
                        Reporter.log("Attending physician details have been updated in input");
                        Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                        break;
                    }
                    Assert.assertNull(inputPage.getAttendingPhysicianName(), "Attending physician details are missing in input");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                    break;
                case "modifydetails":
                    modifyDetails.launchModifyDetailsPage();
                    if (Objects.equals(operation, "attendingPhyDetailValidation")) {
                        modifyDetails.matchAttendingPhysicianDetails(inputData.get("ATTENDING_PHYSICIAN"), attendingPhysicianAdd);
                        Reporter.log("Attending physician name is " + modifyDetails.getAttendingPhysicianName());
                        break;
                    }
                    modifyDetails.matchAttendingPhysicianDetails(null, attendingPhysicianAdd);
                    break;
                case "4point":
                    rxNbr = getRxNbr(name[0], name[1], siteId);
                    if (rxNbr == null || rxNbr.isEmpty()) {
                        Reporter.log("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                        Assert.fail("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                    }
                    Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
                    if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                        if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                            Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                            performResolveQueue(rxNbr);
                        }
                        if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                            Assert.fail("Rx is not in 4 point");
                        }
                    }
                    Reporter.log("RX have reached 4point queue");
                    fourPoint.ValidateAttendingPhysicianDetails(inputData.get("ATTENDING_PHYSICIAN"), attendingPhysicianAdd);
                    break;
                case "filling":
                    if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue())) {
                        Assert.fail("Rx is not in filling queue");
                    }
                    Reporter.log("Rx is in Filling queue");
                    modifyDetails.selectAttendingPhyTab();
                    modifyDetails.matchAttendingPhysicianDetails(inputData.get("ATTENDING_PHYSICIAN"), attendingPhysicianAdd);
                    Reporter.log("Attending physician name is " + modifyDetails.getAttendingPhysicianName());
                    break;
                default:
                    Assert.fail("Please provide correct viewName in " + currentStepMethodName);
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Attending  Physician tab is not available");
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }


    /*
     * Method to update the prescribed product in input screen itself
     * Author: Niraj Kumar(vn50sfl)
     * */
    public void updatePrescriberProduct(String newNDC) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.log("Updated prescribed product to " + newNDC);
            inputPage.enterNDCInProductName(newNDC);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /* Method to validate Invalid Data popup in input and modify details screen
     * Author: Niraj Kumar(vn50sfl) */
    public void validateInvalidateDataPopup(String processName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String popUpMessage = "State law";
            switch (processName.toLowerCase()) {
                case "input":
                    inputPage.clickAccept();
                    Assert.assertTrue(inputPage.isInvalidDataPopUpDisplayed(popUpMessage), "Validation pop-up did not populate");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                    Reporter.log("Invalid data popup displayed");
                    inputPage.clickButtonOk();
                    break;
                case "modifydetails":
                    modifyDetails.clickAccept();
                    Assert.assertTrue(modifyDetails.isInvalidDataPopUpDisplayed(), "Validation pop-up did not populate");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                    Reporter.log("Invalid data popup displayed");
                    modifyDetails.clickok();
                    modifyDetails.clickCancel();
                    modifyDetails.clickButtonYes();
                    break;
                default:
                    Reporter.log("Provided process " + processName + " does not exist in " + currentStepMethodName);
                    Assert.fail("Invalid process name provided in " + currentStepMethodName);
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to complete " + processName);
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /* Method to complete different processes for different work queues like input , modifydetails
     * Can be used in combination with insertDetailsInInput , modifyDetails.openModifyDetailsScreen(); and so on .
     * Author: Niraj Kumar(vn50sfl) */
    public void completeProcessForDiffWorkQueues(String processName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            switch (processName.toLowerCase()) {
                case "input":
                    inputPage.clickAccept();
                    inputPage.clickYesOnValidateRxPopUp();
                    inputPage.clickOnOutofStockPopupOk();
                    inputPage.clickYesOnValidateRxPopUp();
                    Reporter.log("Input completed");
                    break;
                case "modifydetails":
                    modifyDetails.clickCancel();
                    modifyDetails.clickButtonYes();
                    break;
                case "4point":
                    String[] name = connexusAppUtils.readPatientNameFromFile();
                    rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);
                    break;
                default:
                    Reporter.log("Provided process " + processName + " does not exist in " + currentStepMethodName);
                    Assert.fail("Invalid process name provided in " + currentStepMethodName);
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to complete " + processName);
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }


    /**
     * Validates whether the Attending Physician tab is enabled or disabled.
     *
     * @param expectedEnabled {@code true} to assert the tab is enabled,
     *                        {@code false} to assert it is disabled.
     */
    public void validateAttendingPhysicianTabStatus(boolean expectedEnabled) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            boolean isATTabEnabled = inputPage.isAttendingPhysicianTabEnabled();
            String message = expectedEnabled
                    ? "Attending Physician tab should be enabled"
                    : "Attending Physician tab should be disabled";
            Assert.assertEquals(isATTabEnabled, expectedEnabled, message);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void enterInputDetailsWithAttendingPhysician(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try {
            orderSearch.openSearch();
            orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            orderSearch.selectRowFromSearch(0);
            inputPage.enterProductNameInPrescribedProduct(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.selectDAW(1);
            inputPage.inputPrescriberDetailsAndState(inputData.get("PRESCRIBER_NPI"), 28);
            boolean isATTabVisible = inputPage.isAttendingPhysicianTabDisplayed();
            Assert.assertTrue(isATTabVisible);
            inputPage.getPrescriberDegree();
            inputPage.clickAttendingPhysicianNameTextBox();
            inputPage.enterAttendingPhysicianName(inputData.get("ATTENDING_PHYSICIAN"));
            inputPage.clickOnOutofStockPopupOk();
            inputPage.rxExpiryDateSelection(-90);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        inputPage.clickAccept();
        inputPage.clickOnOutofStockPopupOk();
        rxNbr = getRxNbr(name[0], name[1], siteId);
        if (rxNbr == null || rxNbr.isEmpty()) {
            Reporter.log("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
            Assert.fail("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
        }
        Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
    }


    /**
     * Validates the Attending Physician visibility in 4-Point queue.
     * Navigates to 4-Point, opens the patient record, and asserts whether
     * the Attending Physician tab is displayed or not.
     *
     * @param inputData         test data map; requires "ATTENDING_PHYSICIAN" key when expectedDisplayed is true.
     * @param expectedDisplayed {@code true} to assert AP is displayed,
     *                          {@code false} to assert AP is not displayed.
     */
    public void validateAttendingPhysicianIn4Point(Map<String, String> inputData, boolean expectedDisplayed) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0], name[1], siteId);
            if (rxNbr == null || rxNbr.isEmpty()) {
                Reporter.log("Input Failed or Failed to get the RX number for patient: " + name[0] + " , " + name[1]);
                Assert.fail("Input Failed or Failed to get the RX number for patient: " + name[0] + " , " + name[1]);
            }
            Reporter.log(" In " + currentStepMethodName + " Method, Rx number is " + rxNbr);

            FourPoint fourPoint = new FourPoint();

            if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
                if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                    Assert.fail("Rx is not in 4 point");
                }
            }

            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();

            if (expectedDisplayed) {
                fourPoint.verifyAttendingPhysicianDisplayed(inputData.get("ATTENDING_PHYSICIAN"));
                fourPoint.clickButtonCancel();
            } else {
                fourPoint.verifyAttendingPhysicianNotDisplayed();
            }

            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method takes the rx from pick up queue and opens the rx in rx look up page and transfers the same to outbox in destination store
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void enterRxIntoRxLookUp(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxNumber = getRxNbr(name[0], name[1], siteId);
            String destinationStore = "5521";
            String pharmacist = "THOMAS";
            rxLookUp = new RxLookUp();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(rxNumber);
            rxLookUp.clickSearch();
            rxLookUp.transferOrder(destinationStore, pharmacist);
            rxLookUp.verifyTransferOutbox(rxNumber);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }

    public void verifyCodes(String codes) {
        Assert.assertEquals(codes.trim(), "403,414");
        Reporter.log("Agency requirement param for 32683 is " + "403,414");
    }


    public void verifyDropOffPrescriptionHistory() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        dropOff.enterPatientName(name[0] + "," + name[1]);
        dropOff.clickPatientSearch();
        dropOff.handleAnnualValidatePatInfoPopUp();
        boolean ATPDisplayed = dropOff.verifyAttendingPhysicianColumn();
        if (ATPDisplayed) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            dropOff.clickBtnCancel();
            dropOff.clickYes();
        } else {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void verifyRxIntoRxLookUp(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxNumber = getRxNbr(name[0], name[1], siteId);
            rxLookUp = new RxLookUp();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(rxNumber);
            rxLookUp.clickSearch();
            boolean ATPDisplayed = rxLookUp.verifyAttendingPhysicianInFillHistory();
            Assert.assertTrue(ATPDisplayed);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.closeSearch();
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    //Method to fill details in input till accept
    public void fillingAllDetailsInInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            patientSearchPage.openFirstPatientRecord();
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterDispensedProductQty(inputData.get("DISP_QTY2"));
            Reporter.log("Refill quantity changed as " + inputData.get("REFILLS_CHANGE"));
            Reporter.log("Dispensed quantity given  as " + inputData.get("DISP_QTY2"));
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            if (inputPage.isTMCodeDisplayed()) {
                inputPage.selectTmCodeField(2);
            }
            if (inputPage.isDxCodeDisplayed()) {
                inputPage.inputRandomDXCode();
            }
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }
            Reporter.logScreenShot(Status.PASS, "performInputData", patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Input details are not entered" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public void daysValidationInInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();

        String[] name = connexusAppUtils.readPatientNameFromFile();
        fillingAllDetailsInInput(inputData);
        inputPage.dispenseQuantityPopup();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        String text = inputPage.getTextOnDispensedPopup();
        Assert.assertEquals(text, "Dispensed Quantity is not Valid");
        inputPage.clickButtonOk();
        inputPage.clearDispensedProductQty();
        inputPage.enterDispensedProductQty(inputData.get("DISP_QTY"));
        inputPage.enterProductSupplyDays(inputData.get("DISP_QTY"));
        inputPage.clearRefillField();
        inputPage.enterRefillQty(inputData.get("REFILLS_CHANGE"));
        inputPage.clickYesOnValidateRxPopUp();
        inputPage.clickOnOutofStockPopupOk();
        inputPage.partialpopup();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        inputPage.clickAccept();
        automationManager.performSleep(5);
        Reporter.log("Dispensed quantity changed as " + inputData.get("DISP_QTY"));
        Reporter.log("input is complete when dispensed quantity is changed as " + inputData.get("DISP_QTY"));
        rxNbr = getRxNbr(name[0], name[1], siteId);
        if (rxNbr == null || rxNbr.isEmpty()) {
            Reporter.log("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
            Assert.fail("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
        }
        Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
        if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
            Reporter.log("RX is in 4 point queue");
        }
        orderSearch.launchOrderSearchScreen();
        orderSearch.performSearch(name[0] + "," + name[1]);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
    }

    public void verifyWalmartpolicyPopupInInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            fillingAllDetailsInInput(inputData);
            inputPage.walmartPolicyPopup();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            String text = inputPage.textOnWalmartPolicyPopup();
            Assert.assertEquals(text, "Walmart policy limits the dispensing of Schedule 2 controlled substances to a maximum 90-day supply");
            inputPage.clickButtonOk();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Walmart policy Popup in Input" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void validatingDispensedQuantityInInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            this.fillingAllDetailsInInput(inputData);
            inputPage.checkIfDaysFillPopUpIsDisplayed();
            String ErrorText = inputPage.getTextOnErrorMsg();
            Assert.assertEquals(ErrorText, inputData.get("ERROR_MSG"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickButtonOk();
            inputPage.clearDispensedProductQty();
            inputPage.enterDispensedProductQty(inputData.get("DISP_QTY"));
            inputPage.enterProductSupplyDays(inputData.get("DISP_QTY"));
            inputPage.clickYesOnValidateRxPopUp();
            inputPage.clickOnOutofStockPopupOk();
            inputPage.partialpopup();
            inputPage.clickAccept();
            Reporter.log("Dispensed quantity changed as " + inputData.get("DISP_QTY"));
            Reporter.log("input is complete when dispensed quantity is changed as " + inputData.get("DISP_QTY"));
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /*
     * Method to validate dispensed quantity in both modify details page and four point page
     * Author: snehaa(vn57hhm)
     * */
    public void validateDispQtyInModifyDtlAndFourPoint(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0], name[1], siteId);
            if (rxNbr == null || rxNbr.isEmpty()) {
                Reporter.log("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                Assert.fail("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
            }
            Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
            if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
                if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                    Assert.fail("Rx is not in 4 point");
                }
            }
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            modifyDetails.openModifyDetailsScreen();
            modifyDetails.clearDespQty();
            modifyDetails.enterDespQty(inputData.get("DISP_QTY2"));
            Reporter.log("Dispensed quantity changed as " + inputData.get("DISP_QTY2") + " in modify details page and clicked on accept button");
            modifyDetails.clickAccept();
            inputPage.checkIfDaysFillPopUpIsDisplayed();
            ErrorText = inputPage.getTextOnErrorMsg();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(ErrorText, inputData.get("ERROR_MSG"));
            modifyDetails.clickok();
            modifyDetails.escape();
            modifyDetails.clickCancel();
            modifyDetails.clickYes();
            fourPoint.clickDispensedQty();
            fourPoint.clickReturnToTechButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clearDispensedProductQty();
            inputPage.enterDispensedProductQty(inputData.get("DISP_QTY2"));
            Reporter.log("Dispensed quantity changed as " + inputData.get("DISP_QTY2") + " in input page after clicking return to tech");
            inputPage.clickAccept();
            inputPage.checkIfDaysFillPopUpIsDisplayed();
            ErrorText = inputPage.getTextOnErrorMsg();
            Assert.assertEquals(ErrorText, inputData.get("ERROR_MSG"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickButtonOk();
            Reporter.log("Successfully validated pop ups in input page ,Modify details and Four point page");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /**
     * Method to fill all mandatory fields in input screen without clicking on Accept and without setting up Attending Physician
     * Author: Aparna(vn50izt)
     */
    public void enterInputDetailsWithoutAttendingPhysician(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            inputPage.enterProductNameInPrescribedProduct(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Assert.fail(e.toString());
        }
    }

    /*
     * Method to fill all mandatory fields in input screen without clicking on Accept and without setting up Attending Physician, verify earliest fill date and expiration date
     * Author: Aparna(vn50izt)
     */
    public void enterInputDetailsWithoutAttendingPhysicianForC2(Map<String, String> inputData) {
        try {
            enterInputDetailsWithoutAttendingPhysician(inputData);
            inputPage.selectDAW(1);
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            inputPage.handleOutOfStockPopUp();
            Assert.assertTrue(!inputPage.isAttendingPhysicianTabDisplayed(), "Attending physician should not be visible for Non MD Prescriber with Non TX Clinic Address");
            setEarliestFillDate(10);
            verifyRxExpirationDate();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Assert.fail(e.toString());
        }
    }

    /**
     * Method to check if "Prescriber should have in-state address" popup is displayed while clicking accept in input screen
     * Author: Aparna(vn50izt)
     */
    public void verifyPrescriberINStatePopUp() {
        inputPage.clickAccept();
        inputPage.handleOutOfStockPopUp();
        Reporter.log("Prescriber in-state popUp should display after clicking accept in input queue and should not move to next queue");
        boolean isPopUpDisplayed = inputPage.checkPrescriberInStatePopUps();
        Assert.assertTrue(isPopUpDisplayed, "Prescriber in state popup is not displayed and proceeded with next queue");
    }


    /**
     * Method to change the earliest fill date in input window
     * Author: Aparna(vn50izt)
     */
    public void setEarliestFillDate(int days) {
        LocalDate today = LocalDate.now();
        // Calculate the date 10 days from today
        LocalDate tenDaysLater = today.plusDays(days);

        // Define the date format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

        // Format the result as a string
        String formattedDate = tenDaysLater.format(formatter);
        Reporter.log("Default Earliest Fill date: " + inputPage.getEarliestFillDate());
        Reporter.log("Default Expiration date: " + inputPage.getExpirationDate());
        long daysDifference = findDaysDifference(inputPage.getEarliestFillDate(), inputPage.getExpirationDate());
        Reporter.log("days difference between Earliest fill date and Expiration date:" + daysDifference);
        daysDifference = findDaysDifference(inputPage.getWrittenDate(), inputPage.getExpirationDate());
        Reporter.log("days difference between Rx Written date and Expiration date:" + daysDifference);
        Reporter.log("Setting Earliest Fill Dt (EFD) to Current date+" + days + " days");
        inputPage.EFDDateSelectionWithDate(formattedDate);
    }

    public void setExpirationDate(String date, int days) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        LocalDate newdate = LocalDate.parse(date, formatter);
        // Calculate the date 10 days from today
        LocalDate daysLater = newdate.plusDays(days);

        // Define the date format

        Reporter.log("Changing the Expiration date to DefaultValue+" + days + "days");

        // Format the result as a string
        String formattedDate = daysLater.format(formatter);
        inputPage.ExpirationDateSelectionWithDate(formattedDate);
        String UpdatedEFD = inputPage.getEarliestFillDate();
        Reporter.log("UpdatedEFD: " + UpdatedEFD);
        String UpdatedExpDate = inputPage.getExpirationDate();
        Reporter.log("UpdatedExpDate: " + UpdatedExpDate);

    }

    /**
     * Method to calculate difference between earliestfilldate and expiration date
     * Author: Aparna(vn50izt)
     */

    public long findDaysDifference(String earlieetFillDate, String expirationDate) {
        long daysDifference = 0;
        try {
            SimpleDateFormat sdformat = new SimpleDateFormat("MM/dd/yyyy");
            sdformat.setTimeZone(TimeZone.getTimeZone("UTC"));
            daysDifference = (sdformat.parse(expirationDate).getTime() - sdformat.parse(earlieetFillDate).getTime()) / (1000 * 60 * 60 * 24);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log(e.toString());
        }
        return daysDifference;
    }

    /**
     * Method to check if RX Expiration date changes upon changing the Earliest fill date
     * Author: Aparna(vn50izt)
     */
    public void verifyRxExpirationDate() {

        try {
            long daysDifference = findDaysDifference(inputPage.getEarliestFillDate(), inputPage.getExpirationDate());
            String UpdatedEFD = inputPage.getEarliestFillDate();
            Reporter.log("UpdatedEFD: " + UpdatedEFD);
            String UpdatedExpDate = inputPage.getExpirationDate();
            Reporter.log("UpdatedExpDate: " + UpdatedExpDate);
            Reporter.log("daysDifference:" + daysDifference);
            Reporter.logScreenShot("Input screen after changing the Earliest fill date", inputPage.takeScreenShot());
            Assert.assertEquals(daysDifference, 30, "The difference should be 30 days");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log(e.toString());
        }
    }

    public void validateRxExpiryDateInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            String writtenDate = inputPage.getWrittenDate();
            Reporter.log("writtenDate" + writtenDate);
            String DefaultExpDate = inputPage.getExpirationDate();
            Reporter.log("DefaultExpDate" + DefaultExpDate);
            Reporter.logScreenShot(Status.PASS, "Input screen with Default EFD and Default Rx expiry Date", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterProductNameInPrescribedProduct(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            String daysDifference = DaysDifferencefromWrittenDate(inputPage.getWrittenDate(), inputPage.getExpirationDate());
            Assert.assertEquals(daysDifference, inputData.get("DAYS_DIFFERNCE"));
            String UpdatedExpDate = inputPage.getExpirationDate();
            Reporter.log("writtenDate on Input" + writtenDate);
            Reporter.log("UpdatedExpDate on Input: " + UpdatedExpDate);
            Reporter.log("daysDifference;" + daysDifference);
            Reporter.logScreenShot(Status.PASS, "Updated Rx Expiry Date on Input", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            if (inputPage.isTMCodeDisplayed()) {
                inputPage.selectTmCodeField(2);
            }
            if (inputPage.isDxCodeDisplayed()) {
                inputPage.inputRandomDXCode();
            }
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }
            inputPage.clickAccept();
            inputPage.clickOnOutofStockPopupOk();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void verifyExpiryDateonFourPoint(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0], name[1], siteId);
            if (rxNbr == null || rxNbr.isEmpty()) {
                Reporter.log("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                Assert.fail("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
            }
            Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
            if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
                if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                    Assert.fail("Rx is not in 4 point");
                }
            }
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            String daysDifference = DaysDifferencefromWrittenDate(fourPoint.getWrittenDate(), fourPoint.getRxExpiryDate());
            Assert.assertEquals(daysDifference, inputData.get("DAYS_DIFFERNCE"));
            String writtenDate = fourPoint.getWrittenDate();
            String UpdatedExpDate = fourPoint.getRxExpiryDate();
            Reporter.log("writtenDate on fourpoint" + writtenDate);
            Reporter.log("UpdatedExpDate on fourpoint: " + UpdatedExpDate);
            Reporter.log("daysDifference;" + daysDifference);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at 4 Point queue");
            //e.printStackTrace();
            Assert.fail(e.toString());
        }
    }


    public void verifyExpiryDateonModifyDetails(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            modifyDetails.openModifyDetailsScreen();
            String daysDifference = DaysDifferencefromWrittenDate(modifyDetails.getWrittenDateValue(), modifyDetails.getExpDateValue());
            Assert.assertEquals(daysDifference, inputData.get("DAYS_DIFFERNCE"));
            String writtenDate = modifyDetails.getWrittenDateValue();
            String UpdatedExpDate = modifyDetails.getExpDateValue();
            Reporter.log("writtenDate on ModifyDetails" + writtenDate);
            Reporter.log("UpdatedExpDate on ModifyDetails: " + UpdatedExpDate);
            Reporter.log("daysDifference;" + daysDifference);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.exitModifyDetailsScreen();
            fourPoint.exitfromFourPoint();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void updateStoreState(String state) {
        connexusAppUtils.updateStoreState(state);
    }

    public String DaysDifferencefromWrittenDate(String writtenDate, String expirationDate) {
        try {
            SimpleDateFormat sdformat = new SimpleDateFormat("MM/dd/yyyy");
            sdformat.setTimeZone(TimeZone.getTimeZone("UTC"));
            daysDifference = ((sdformat.parse(expirationDate).getTime() - sdformat.parse(writtenDate).getTime()) / (1000 * 60 * 60 * 24)) % 365;
            return String.valueOf(daysDifference);
        } catch (Exception e) {
            Reporter.log(e.toString());
            return null;
        }
    }

    public void verifyRxExpiry(Map<String, String> inputData) {
        try {
            String daysDifference = DaysDifferencefromWrittenDate(inputPage.getWrittenDate(), inputPage.getExpirationDate());
            String UpdatedEFD = inputPage.getEarliestFillDate();
            Reporter.log("UpdatedEFD: " + UpdatedEFD);
            UpdatedExpDate = inputPage.getExpirationDate();
            WrittenDate = inputPage.getWrittenDate();
            Reporter.log("WrittenDate: " + WrittenDate);
            Reporter.log("UpdatedExpDate: " + UpdatedExpDate);
            Reporter.log("daysDifference:" + daysDifference);
            Reporter.logScreenShot("Input screen after changing the Earliest fill date", inputPage.takeScreenShot());
            Assert.assertEquals(daysDifference, inputData.get("EXPECTED_DAYS"), "The difference days should be matched");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyExpiryDateInInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            this.enterInputDetailsWithoutAttendingPhysician(inputData);
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            inputPage.handleOutOfStockPopUp();
            this.setEarliestFillDate(Integer.parseInt(inputData.get("PLUS_DAYS")));
            this.verifyRxExpiry(inputData);
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void enterOtherInputDetails(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        automationManager.performSleep(10);
        try {
            automationManager.performSleep(10);
            if (inputPage.isAttendingPhysicianTabDisplayed()) {
                inputPage.enterAttendingPhysicianName(inputData.get("ATTENDING_PHYSICIAN"));
            }
            if (inputPage.isTMCodeDisplayed()) {
                inputPage.selectTmCodeField(2);
            }
            if (inputPage.isDxCodeDisplayed()) {
                inputPage.inputRandomDXCode();
            }
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at Input");
            Assert.fail(e.toString());
        }
    }

    public void validateRxExpiryDateFromEFD(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            orderSearch.selectRowFromSearch(0);
            String DefaultEFD = inputPage.getEarliestFillDate();
            Reporter.log("DefaultEFD" + DefaultEFD);
            String DefaultExpDate = inputPage.getExpirationDate();
            Reporter.log("DefaultExpDate" + DefaultExpDate);
            Reporter.logScreenShot(Status.PASS, "Input screen with Default EFD and Default Rx expiry Date", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterProductNameInPrescribedProduct(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.clickEarliestFillDateCheckBox();
            inputPage.EFDDateSelection(2);
            String daysDifference = DaysDifferencefromWrittenDate(inputPage.getWrittenDate(), inputPage.getExpirationDate());
            Assert.assertEquals(daysDifference, inputData.get("DAYS_DIFFERNCE"));
            String UpdatedEFD = inputPage.getEarliestFillDate();
            Reporter.log("UpdatedEFD: " + UpdatedEFD);
            String UpdatedExpDate = inputPage.getExpirationDate();
            String writtenDate = inputPage.getWrittenDate();
            Reporter.log("UpdatedExpDate: " + UpdatedExpDate);
            Reporter.log("WrittenDate: " + writtenDate);
            Reporter.log("daysDifference;" + daysDifference);
            Reporter.logScreenShot(Status.PASS, "Updated Rx Expiry Date", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            enterOtherInputDetails(inputData);
            Reporter.logScreenShot(Status.PASS, "Prescriber added in Input Screen", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            inputPage.clickOnOutofStockPopupOk();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at input queue");
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void selectAndUnSelectEFD(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            orderSearch.selectRowFromSearch(0);
            Reporter.logScreenShot(Status.PASS, "Input screen with Default EFD and Default Rx expiry Date", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterProductNameInPrescribedProduct(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.clickEarliestFillDateCheckBox();
            inputPage.EFDDateSelection(2);
            String daysDifference = DaysDifferencefromWrittenDate(inputPage.getWrittenDate(), inputPage.getExpirationDate());
            Assert.assertEquals(daysDifference, inputData.get("DAYS_DIFFERNCE"));
            Reporter.logScreenShot(Status.PASS, "selecting EFD", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            enterOtherInputDetails(inputData);
            inputPage.unselectEarliestFillDateCheckBox();
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, "unselected EFD", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            inputPage.clickOnOutofStockPopupOk();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at input queue");
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateRxExpiryDateOnInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            enterInputDetailsWithoutAttendingPhysician(inputData);
            String DefaultEFD = inputPage.getEarliestFillDate();
            Reporter.log("DefaultEFD" + DefaultEFD);
            String DefaultExpDate = inputPage.getExpirationDate();
            Reporter.log("DefaultExpDate" + DefaultExpDate);
            String daysDifference = DaysDifferencefromWrittenDate(inputPage.getWrittenDate(), inputPage.getExpirationDate());
            Reporter.log("daysDifference;" + daysDifference);
            Reporter.logScreenShot(Status.PASS, "Input screen with Default EFD and Default Rx expiry Date", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickEarliestFillDateCheckBox();
            inputPage.EFDDateSelection(10);
            daysDifference = DaysDifferencefromWrittenDate(inputPage.getWrittenDate(), inputPage.getExpirationDate());
            Assert.assertEquals(daysDifference, inputData.get("DAYS_DIFFERNCE"));
            String UpdatedEFD = inputPage.getEarliestFillDate();
            Reporter.log("UpdatedEFD: " + UpdatedEFD);
            String UpdatedExpDate = inputPage.getExpirationDate();
            String writtenDate = inputPage.getWrittenDate();
            Reporter.log("UpdatedExpDate: " + UpdatedExpDate);
            Reporter.log("WrittenDate: " + writtenDate);
            Reporter.log("daysDifference;" + daysDifference);
            Reporter.logScreenShot(Status.PASS, "Updated Rx Expiry Date", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            enterOtherInputDetails(inputData);
            inputPage.clickAccept();
            inputPage.clickOnOutofStockPopupOk();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at input queue");
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyRxHoldStatusOnFourPoint(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch = new F6Search();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0], name[1], siteId);
            if (rxNbr == null || rxNbr.isEmpty()) {
                Reporter.log("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                Assert.fail("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
            }
            Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
            if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
                if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                    Assert.fail("Rx is not in 4 point");
                }
            }
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            rxNbr = getRxNbr(name[0], name[1], siteId);
            orderSearch.openFirstPatientRecord();
            fourPoint.onHoldButtonSelected();
            Assert.assertTrue(true);
            Reporter.log("Rx moved to On hold status");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at 4 Point queue");
            //e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /**
     * Method to fill all mandatory fields in input screen without clicking on Accept and without setting up Attending Physician, set earliest fill date and expiration date and set Triplicate
     * Author: Aparna(vn50izt)
     */
    public void enterInputDetailsWithoutAttendingPhysicianGeneric(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            enterInputDetailsWithoutAttendingPhysician(inputData);
            inputPage.selectDAW(1);
            int prescriberindex = Integer.parseInt(inputData.get("STATE_INDEX"));
            inputPage.inputPrescriberDetailsAndState(inputData.get("PRESCRIBER_NPI"), prescriberindex);
            inputPage.handleOutOfStockPopUp();
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }


        } catch (Throwable e) {
            isExceptionCaptured = true;
            Assert.fail(e.toString());
        }
    }

    public void setEarliestFIllDateAndExpirationDate(int efdchange, int expdChange) {
        setEarliestFillDate(efdchange);
        Reporter.log("Updated Earliest Fill date: " + inputPage.getEarliestFillDate());
        Reporter.log("Updated Expiration date: " + inputPage.getExpirationDate());
        setExpirationDate(inputPage.getExpirationDate(), expdChange);
    }

    /**
     * Method to check if "Rx has expired. Select the Earliest fill date if provided by the prescriber on the prescription" popup is displayed while clicking accept in input screen
     * Author: Aparna(vn50izt)
     */
    public void verifyRXOutOfScopePopUp(String message) {
        inputPage.clickAccept();
        inputPage.handleOutOfStockPopUp();
        Reporter.log("RX Expired popUp should display after clicking accept in input queue and should not move to next queue");
        boolean isPopUpDisplayed = inputPage.validatePopUpMessage(message);
        Assert.assertTrue(isPopUpDisplayed, "Rx has expired. Select the Earliest fill date if provided by the prescriber on the prescription PopUp should be displayed");
    }

    public void verifyExpirationDate(int ExpectedDaysDifference) {
        try {
            String oldWrittenDate = inputPage.getWrittenDate().trim();
            String oldExpirationDate = inputPage.getExpirationDate().trim();
            Reporter.log("Default RX Written date: " + oldWrittenDate);
            daysDifference = findDaysDifference(inputPage.getWrittenDate(), inputPage.getExpirationDate());
            Reporter.log("days difference " + daysDifference);
            boolean isDaysDifferenceSameAsExpected = ExpectedDaysDifference == daysDifference;
            Assert.assertTrue(isDaysDifferenceSameAsExpected, "Difference between Rx Written date and Expiration date should be " + ExpectedDaysDifference + " days");
            Reporter.logScreenShot("Expiration date before changing earliest fill date", inputPage.takeScreenShot());
            setEarliestFillDate(2);
            Reporter.log("Updated Earliest Fill date: " + inputPage.getEarliestFillDate());
            Reporter.log("Updated Expiration date: " + inputPage.getExpirationDate());
            Reporter.logScreenShot("Expiration date after changing earliest fill date", inputPage.takeScreenShot());
            boolean isSameExpirationDate = oldExpirationDate.equals(inputPage.getExpirationDate());
            if (isSameExpirationDate) {
                Reporter.log("Expiration date did not change after changing the earliest fill date");
            } else {
                Assert.fail("Expiration date should not change after changing the earliest date");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at input queue");
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


    public void validateRxExpiryAfterEFDIncreamentInInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            enterInputDetailsWithoutAttendingPhysician(inputData);
            setEarliestFillDate(2);
            long daysDifference = findDaysDifference(inputPage.getEarliestFillDate(), inputPage.getExpirationDate());
            String UpdatedEFD = inputPage.getEarliestFillDate();
            Reporter.log("UpdatedEFD: " + UpdatedEFD);
            String UpdatedExpDate = inputPage.getExpirationDate();
            Reporter.log("UpdatedExpDate: " + UpdatedExpDate);
            Reporter.log("daysDifference:" + daysDifference);
            Reporter.logScreenShot("Input screen after changing the Earliest fill date", inputPage.takeScreenShot());
            Assert.assertEquals(daysDifference, 30, "The difference should be 30 days");
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            enterOtherInputDetails(inputData);
            Reporter.logScreenShot("Prescriber added in Input Screen", inputPage.takeScreenShot());
            inputPage.clickAccept();
            inputPage.clickOnOutofStockPopupOk();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at input queue");
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyExpiryDateOn4pointAfterEFDIncreament() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0] , name[1], siteId);
            if(checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                orderSearch.openFirstPatientRecord();
                long daysDifference = findDaysDifference(fourPoint.getEarliestFillDate(), fourPoint.getRxExpiryDate());
                Assert.assertEquals(daysDifference, 30, "The difference should be 30 days");
                String EFD = fourPoint.getEarliestFillDate();
                String UpdatedExpDate = fourPoint.getRxExpiryDate();
                Reporter.log("Earliest Fill Date on fourpoint" + EFD);
                Reporter.log("UpdatedExpDate on fourpoint: " + UpdatedExpDate);
                Reporter.log("daysDifference;" + daysDifference);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            }else{
                Assert.fail("Rx is not in fourpoint");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at 4 Point queue");
            //e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyExpiryDateOnModifyDetailsAfterEFDIncreament(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            modifyDetails.openModifyDetailsScreen();
            long daysDifference = findDaysDifference(modifyDetails.getEarliestFillDateValue(), modifyDetails.getExpDateValue());
            Assert.assertEquals(daysDifference, 30, "The difference should be 30 days");
            String EFD = modifyDetails.getEarliestFillDateValue();
            String UpdatedExpDate = modifyDetails.getExpDateValue();
            Reporter.log("Earliest on ModifyDetails" + EFD);
            Reporter.log("UpdatedExpDate on ModifyDetails: " + UpdatedExpDate);
            Reporter.log("daysDifference;" + daysDifference);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.exitModifyDetailsScreen();
            fourPoint.exitfromFourPoint();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void completeRxOrder(String siteId) {
        if (rxNbr == null) {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0], name[1], Integer.parseInt(siteId));
        }
        Map<String, Integer> rxInfo = connexusAppUtils.getRxIdAndRxFillIdAndOrderSeqNbr(Integer.parseInt(siteId), rxNbr);
        fillId = rxInfo.get("rxFillId");
        int orderId = rxInfo.get("orderId").hashCode();
        int orderSeqNo = rxInfo.get("orderSeqNbr");
        Reporter.log("Order id is " + orderId + " and order seq no. is " + orderSeqNo);

        int rxToComp = connexusAppUtils.completeRxOrder(orderId, orderSeqNo);
        Assert.assertTrue(rxToComp == 1, "Failed to move Rx " + rxNbr + " to Complete");
        Reporter.log("Rx " + rxNbr + " moved to complete status");
    }

    public void transferRxFromF7(Map<String, String> inputData) {
        if (rxNbr == null) {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0], name[1], siteId);
        }
        String transferStore = inputData.get("TRANSFER_STORE");
        Reporter.log("Rx " + rxNbr + " will be transfere to " + transferStore);
        patientMaintenancePage.transferRxFromF7(rxNbr, transferStore, true);
    }

    public void validateFaxOutStatus() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            MenuBar menuBar = new MenuBar();
            if (rxNbr == null) {
                String[] name = connexusAppUtils.readPatientNameFromFile();
                rxNbr = getRxNbr(name[0], name[1], siteId);
            }
            menuBar.selectNavigation(AppMenu.FAX_OUTBOX, AppMenuItemsIndex.TOOLS_FAX_OUTBOX, null, null);
            connexusStartPage.clickOk();
            // To get fax id for the rx
            Map<String, Object> result = connexusAppUtils.getFaxIdForRx(rxNbr);
            Assert.assertNull(result, "Fax was sent for rx " + rxNbr);
            Reporter.log("No fax was sent for Rx " + rxNbr);
            Reporter.logScreenShot(Status.PASS, "Fax Outbox", inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Failed to open FAX outbox due to " + e);
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void validateTransferRxDisabledFromF7(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        if (rxNbr == null) {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0], name[1], siteId);
        }
        Boolean enabled = patientMaintenancePage.isTransferBtnDisabled(rxNbr);
        Reporter.logScreenShot(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Verify transfer button is disabled on PMS");
        Assert.assertEquals(enabled, false, "Transfer button is enabled on PMS ");
        Reporter.log("Assert: Validated Transfer out option is disabled DISABLED with controlled C2 Drug");

    }

    public void validatePutRxOnHold(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (rxNbr == null) {
                softAssert.fail("rxNbn is null. Cannot perform transfer.");
                return;
            }
            if (chkDur == null) {
                softAssert.fail("chkdur is null. Cannot perform key press.");
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                patientSearchPage.PatientSearchCurrentRX();
                String cancelFillPopup = chkdurPage.getTextOfcancelFillPopup();
                Reporter.log("Popup Message :" + cancelFillPopup);
                Assert.assertEquals(cancelFillPopup, inputData.get("POPUP"));
                Reporter.logScreenShot(Status.PASS, "Validate On Hold Popup Message", chkdurPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.clickYes();
                if (!orderSearch.isCheckDURPageDisplayed()) {
                    Assert.fail("Check DUR page not displayed");
                }
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, chkdurPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickTransferBtnRXFromF7(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.transferBtnRxFromF7(rxNbr, true, inputData);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateInvalidDaysSupplyInPerformInputScreen(Map<String, String> inputData, boolean nonOpiod) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            if (nonOpiod) {
                inputPage.enterNdc(inputData.get("DRUG_NAME1"));
                inputPage.clickProductSearch3Dots();
                inputPage.enterPrescribedQty(inputData.get("QUANTITY1"));
            } else {
                inputPage.enterNdc(inputData.get("DRUG_NAME2"));
                inputPage.clickProductSearch3Dots();
                inputPage.enterPrescribedQty(inputData.get("QUANTITY2"));
            }
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            if (inputPage.isTMCodeDisplayed()) {
                inputPage.selectTmCodeField(2);
            }
            if (inputPage.isDxCodeDisplayed()) {
                inputPage.inputRandomDXCode();
            }
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }
            inputPage.clickAccept();
            String invalidDaysTextOnPopUp = inputPage.getInvalidDaysErrorMessageText();
            Assert.assertEquals(invalidDaysTextOnPopUp, inputData.get("InvalidDayspopUpMessgae"), "popUpText not matched");
            Reporter.log("popUp Message : " + invalidDaysTextOnPopUp);
            Reporter.logScreenShot(Status.PASS, "Invalid Days Supply popUp", inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickButtonOk();
            inputPage.clickCancel();
            inputPage.clickInputCancelYesButton();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Input details are not entered" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void performInputForOpiodAndNonOpiodDrug(Map<String, String> inputData, boolean nonOpiodDrug) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            if (nonOpiodDrug) {
                inputPage.enterNdc(inputData.get("DRUG_NAME1"));
                inputPage.clickProductSearch3Dots();
                inputPage.enterPrescribedQty(inputData.get("QUANTITY2"));
            } else {
                inputPage.enterNdc(inputData.get("DRUG_NAME2"));
                inputPage.clickProductSearch3Dots();
                inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            }
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            if (inputPage.isTMCodeDisplayed()) {
                inputPage.selectTmCodeField(2);
            }
            if (inputPage.isDxCodeDisplayed()) {
                inputPage.inputRandomDXCode();
            }
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }
            Reporter.logScreenShot(Status.PASS, "performInputData", inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            inputPage.handleOutOfStockPopUp();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Input details are not entered" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void validatePatientRecordInWorkFlowRsqtTrsfTable() {
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbr(name[0], name[1], siteId);
            Assert.assertTrue(connexusAppUtils.validatePatientRecordInWorkFlowRequestTable(rxNbr));
            Reporter.log("Patient Record is present in store db");
        } catch (Exception e) {
            Reporter.log("Patient Record not present in store db " + e.getMessage());
        }
    }

    //method to Validate TamperResistant RX Popup
    public void ValidateTamperResistantPopup() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            if(inputPage.isValidateRXPopUpDisplayed()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertTrue(inputPage.isCancelBtnDisplayed());
                Assert.assertTrue(inputPage.isNoSendtoResolutionDisplayed());
                inputPage.clickYesOnValidateRxPopUp();
                Reporter.log("Input completed after Tamper alert close");
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Validate RX pop not displayed");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * verify SIG highlight color on Input screen
     * complete Input processing
     * */
    public void validateSigHighlightAndCompleteInput(Map<String, String> inputData, boolean applySigCodeChanges) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (isOrderInInputQueueDB(name[0], name[1], 1)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                orderSearch.openFirstPatientRecord();
                inputPage.clickYesOnConnexusPopup();

                // Validate SIG background color is orange and highlighted
                String expectedSig = inputData.get("SIG");
                String actualSig = inputPage.getSigCode();
                Reporter.log("Expected SIG: " + expectedSig + ", Actual SIG on UI: " + actualSig);
                Assert.assertEquals(actualSig, expectedSig, "SIG value on UI does not match test data");
                Reporter.logScreenShot(Status.PASS, "verifySigHighlightColor", inputPage.takeScreenShot(currentStepMethodName).getValue());
                inputPage.clickSigField();

                // update sig code change, if required
                if (applySigCodeChanges) {
                    String changeSig = inputData.get("updateSIG");
                    String days = inputData.get("DAYS");

                    if (StringUtils.isNotBlank(changeSig)) {
                        inputPage.enterSigCode(changeSig);
                    }
                    if (StringUtils.isNotBlank(days)) {
                        inputPage.enterDaysSupply(days);
                    }
                    Reporter.logScreenShot(Status.PASS, "completeInput", inputPage.takeScreenShot(currentStepMethodName).getValue());
                }
                // Complete Input processing
                inputPage.clickAccept();
                if (inputPage.isOkDisplayed()) {
                    inputPage.clickOK();
                }
                if (inputPage.isValidateRXPopUpDisplayed()) {
                    inputPage.clickYesOnValidateRxPopUp();
                    inputPage.clickAccept();
                    if (inputPage.isOkDisplayed()) {
                        inputPage.clickOK();
                    }
                }
                Reporter.log("Input completed after SIG resolved or no updates needed");
            } else {
                Reporter.log("Order not landed back in Input Queue as expected");
                Assert.fail("Order not landed back in Input Queue as expected");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /*
     * Method to perform additional quality verification popup when there is an input error
     * Handles the verification popup and completes input with updated SIG
     * */
    public void performAdditionalQualityVerificationForInputError(Map<String, String> inputData,int therapyConfirmedIndex) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();

            // handle alert if the Verification popup is displayed
            if (fourPoint.isTitlePopupHeadingDisplayed()) {
                fourPoint.handleAdditionalQualityVerificationPopup(inputData.get("responseType"), therapyConfirmedIndex);
            }
            if (fourPoint.isElementDisplayed(fourPoint.txtDrugReEntry)) {
                fourPoint.enterDrugName(inputData.get("Product_Name"));
                Reporter.logScreenShot(Status.PASS, "handleValidateDrugNameScreen", fourPoint.takeScreenShot(currentStepMethodName).getValue());
                fourPoint.clickBtnValidateReEntry();
            }
            fourPoint.clickReturnToTechButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("clicked ReturnToTech button from 4point and moved to Input");

            //perform additional input and complete
            inputPage.clickSigField();
            inputPage.enterSigCode(inputData.get("updateSIG"));
            inputPage.pressKeys(KeyEvent.VK_TAB);
            Reporter.logScreenShot(Status.PASS, "completeInput", inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed at 4 Point/InPut queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    public void perform4PointForVerificationPopup(Map<String, String> inputData) {
        perform4PointForVerificationPopup(null, inputData);
    }

    /**
     * Method to perform 4-point verification with handling for additional quality verification popup
     * @param responseType
     * @param inputData
     */
    public void perform4PointForVerificationPopup(String responseType, Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            boolean isResponseTypeProvided = responseType != null && !responseType.trim().isEmpty();

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                performResolveQueue(rxNbr);
            }
            if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                Assert.fail("Rx is not in 4 point");
            }
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();

            // handle alert if the Additional Quality Verification Popup is displayed
            if (fourPoint.isElementDisplayed(fourPoint.titlePopupHeading, ConnexusConstants.WAIT_TIMEOUT_10)) {
                if (!isResponseTypeProvided) {
                    Reporter.logScreenShot("performAdditionalQualityVerificationPopup", fourPoint.takeScreenShot());
                    Assert.fail("Additional Quality Verification popup is displayed, but layover screen shouldn't appear in 4Point");
                }
                fourPoint.handleAdditionalQualityVerificationPopup(responseType,0);
            }
            if (fourPoint.isElementDisplayed(fourPoint.txtDrugReEntry)) {
                fourPoint.enterDrugName(inputData.get("Product_Name"));
                Reporter.logScreenShot(Status.PASS, "handleValidateDrugNameScreen", fourPoint.takeScreenShot(currentStepMethodName).getValue());
                fourPoint.clickBtnValidateReEntry();
            }
            fourPoint.chkName();
            fourPoint.chkPrescribed();
            fourPoint.chkStrength();
            fourPoint.chkSIG();
            if (fourPoint.isElementDisplayed(fourPoint.rdbNonAcute)) {
                fourPoint.click(fourPoint.rdbNonAcute);
            }
            if (fourPoint.isElementDisplayed(fourPoint.chkDEA)) {
                fourPoint.click(fourPoint.chkDEA);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            fourPoint.clickAccept();
            Reporter.log("4 point completed");
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Method to validate 4-point verification popup without completing the 4-point process
     * @param responseType The type of response for handling the quality verification popup
     * @param therapyConfirmedIndex option to select for TherapyConfirmed response type
     */
    public void validate4PointVerificationPopupWithoutCompletion(String responseType, int therapyConfirmedIndex) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            boolean isResponseTypeProvided = responseType != null && !responseType.trim().isEmpty();

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                performResolveQueue(rxNbr);
            }
            if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                Assert.fail("Rx is not in 4 point");
            }
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();

            // handle alert if the Additional Quality Verification Popup is displayed
            if (fourPoint.isElementDisplayed(fourPoint.titlePopupHeading, ConnexusConstants.WAIT_TIMEOUT_10)) {
                if (!isResponseTypeProvided) {
                    Reporter.logScreenShot("performAdditionalQualityVerificationPopup", fourPoint.takeScreenShot());
                    Assert.fail("Additional Quality Verification popup is displayed, but layover screen shouldn't appear in 4Point");
                }
                fourPoint.handleAdditionalQualityVerificationPopup(responseType, therapyConfirmedIndex);
            }
            //  Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /*
     * verify SIG highlight color on Input screen
     * Author: Priya
     * */
    public void validateSigHighlight(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (isOrderInInputQueueDB(name[0], name[1], 1)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                orderSearch.openFirstPatientRecord();
                inputPage.clickYesOnConnexusPopup();

                // Validate SIG background color is orange and highlighted
                String expectedSig = inputData.get("SIG");
                String actualSig = inputPage.getSigCode();
                Reporter.log("Expected SIG: " + expectedSig + ", Actual SIG on UI: " + actualSig);
                Assert.assertEquals(actualSig, expectedSig, "SIG value on UI does not match test data");
                Reporter.logScreenShot(Status.PASS, "verifySigHighlightColor", inputPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Input completed after SIG resolved or no updates needed");
            } else {
                Assert.fail("Order not landed back in Input Queue as expected");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Test failed at Input queue" + e.getMessage());
        }
    }

    /*
     * This method will cancel the fill and deactivate prescriptions
     * Verify that fill is cancelled and cancellation reason overlay screen appears
     * Author: Priya
     */
    public void selectCancelFillForDuplicateFill(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Navigate to handle "Current Rx -> Cancel Fill -> Duplicate Fill" workflow
            menuBar.selectNavigation(AppMenu.DUPLICATE_FILL, AppMenuItemsIndex.CURRENTRX_CANCEL_FILL, AppMenuSubItemsIndex.DUPLICATE_FILL, null);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(5); // Adding sleep to ensure the popup is fully loaded before interaction
            // Confirm with YES to cancel the fill and deactivate prescriptions
            inputPage.clickYesOnConnexusPopup();
            // Verify cancellation reason overlay screen displayed
            inputPage.isCancellationReasonTitleDisplayed();
            Reporter.log("Cancel fill and deactivate prescriptions workflow completed successfully");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("Failed to cancel fill and deactivate prescriptions: " + e.getMessage());
        }
    }

    /*
     * This method will cancel the fill and deactivate prescriptions
     * Verify that fill is cancelled and cancellation reason overlay screen appears
     * Author: Priya
     */
    public void selectCancelFillForTherapyDiscontinued(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Navigate to handle "Current Rx -> Cancel Fill -> Duplicate Fill" workflow
            menuBar.selectNavigation(AppMenu.THERAPY_DISCONINUE, AppMenuItemsIndex.CURRENTRX_CANCEL_FILL, AppMenuSubItemsIndex.THERAPY_DISCONTINUED, null);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(5); // Adding sleep to ensure the popup is fully loaded before interaction
            // Confirm with YES to cancel the fill and deactivate prescriptions
            inputPage.clickYesOnConnexusPopup();
            // Verify cancellation reason overlay screen displayed
            inputPage.isCancellationReasonTitleDisplayed();
            Reporter.log("Cancel fill and deactivate prescriptions workflow completed successfully");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("Failed to cancel fill and deactivate prescriptions: " + e.getMessage());
        }
    }

    /*
     * This method will cancel the fill and deactivate prescriptions
     * Verify that fill is cancelled and cancellation reason overlay screen appears
     * Author: Priya
     */
    public void selectCancelFillForPatientWantsWrittenRxBack(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Navigate to handle "Current Rx -> Cancel Fill -> Duplicate Fill" workflow
            menuBar.selectNavigation(AppMenu.PATIENT_WANTS_WRITTEN_RX_BACK, AppMenuItemsIndex.CURRENTRX_CANCEL_FILL, AppMenuSubItemsIndex.PATIENT_WANTS_WRITTEN_RX_BACK, null);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(5); // Adding sleep to ensure the popup is fully loaded before interaction
            // Confirm with YES to cancel the fill and deactivate prescriptions
            inputPage.clickYesOnConnexusPopup();
            // Verify cancellation reason overlay screen displayed
            inputPage.isCancellationReasonTitleDisplayed();
            Reporter.log("Cancel fill and deactivate prescriptions workflow completed successfully");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("Failed to cancel fill and deactivate prescriptions: " + e.getMessage());
        }
    }

    /*
     * Method to handle cancellation reason selection for "Obtained New Prescription"
     * Author: Priya
     */
    public void selectCancelFillWithObtainedNewPrescriptionReason() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Handle cancellation reason overlay
            Reporter.log("Selecting reason on cancellation reason overlay screen");
            inputPage.handleCancellationReasonOverlayScreenValidation("ObtainedNewPrescription");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            Reporter.log("Cancellation with 'Obtained New Prescription' reason completed successfully");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("Failed to complete cancellation with 'Obtained New Prescription' reason: " + e.getMessage());
        }
    }

    /*
     * Method to handle cancellation reason selection for "Prescriber/patient requested cancellation"
     * Author: Priya
     */
    public void selectCancelFillWithPrescriberPatientRequestedReason() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.log("Selecting reason on cancellation reason overlay screen");
            // Handle cancellation reason overlay using existing InputPage method
            inputPage.handleCancellationReasonOverlayScreenValidation("PrescriberOrPatientRequestedCancellation");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            Reporter.log("Cancellation with 'Prescriber/patient requested cancellation' reason completed successfully");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("Failed to complete cancellation with 'Prescriber/patient requested cancellation' reason: " + e.getMessage());
        }
    }

    /*
     * Method to handle cancellation reason selection for "Other"
     * Author: Priya
     */
    public void selectCancelFillWithOtherReason() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.log("Selecting reason on cancellation reason overlay screen");
            // Handle cancellation reason overlay using existing InputPage method
            inputPage.handleCancellationReasonOverlayScreenValidation("CancellationReasonOther");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            Reporter.log("Cancellation with 'Other' reason completed successfully");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("Failed to complete cancellation with 'Other' reason: " + e.getMessage());
        }
    }

    /**
     * Validates the RX Notes message for cancelled RTSA order
     * and RX history status is cancelled in RxLookup(F7) screen
     * Author: Priya
     */
    public void validateRxNotesAndRxHistoryStatus() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            //open RxLookup(F7) screen
            rxLookUp.openAndSearchPatientRecordInF7(name[0] + "," + name[1]);

            // verify Rx Notes contains cancellation reason
            menuBar.navigateToMenu(AppMenu.RX_NOTES);
            consolidatedNotesPage.clickViewMoreLink2();
            String rtsaRxNotes = consolidatedNotesPage.getTxtNotesofRXNotes().trim();
            if (rtsaRxNotes.isEmpty()) {
                Assert.fail("RX Notes text not found for RTSA cancellation");
            }
            Reporter.log("Cancellation reason notes for RTSA: " + rtsaRxNotes);
            Reporter.logScreenShot(Status.PASS,"validateRxNotes", consolidatedNotesPage.takeScreenShot(currentStepMethodName).getValue());
            //exit rx notes
            consolidatedNotesPage.clickCancel();
            // Wait for screenshot to complete before proceeding
            //  automationManager.performSleep(5);
            // verify RX history status is Canceled
            String status = rxLookUp.getStatusForRowIndex(0);
            Assert.assertEquals(status, "Canceled", "RX history status is not canceled after RTSA cancellation");
            Reporter.log("RX history status after RTSA cancellation: " + status);
            Reporter.logScreenShot(Status.PASS,"validateRxHistoryStatus", rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            //close rx lookup
            rxLookUp.click(rxLookUp.btnClose);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("Failed to validate RX history status: " + e.getMessage());
        }
    }

}