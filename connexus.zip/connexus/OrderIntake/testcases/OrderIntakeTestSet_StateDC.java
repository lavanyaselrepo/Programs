package connexus.OrderIntake.testcases;

import connexus.OrderIntake.testscripts.OrderIntakeTestScripts;
import connexus.PMP.testScripts.PMPTestDataGenerationTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.prop;

public class OrderIntakeTestSet_StateDC {
    OrderIntakeTestScripts orderIntakeTestScript;
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ConnexusAPIManager connexusAPIManager= new ConnexusAPIManager();
    PropertyReader prop = PropertyReader.getInstance();
    boolean flagUpdated;

    public void stateUpdate(){
        //Set the state to DC for the current store
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("DC");
    }

    @BeforeClass
    public void loginToConnexus(){
        connexusAppUtils = new ConnexusAppUtils();
        orderIntakeTestScript = new OrderIntakeTestScripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

     /*----------------------------------------------------------------------------------------------------------
      * Test Description:HWPHME2E-3160 - CII Expiration Dates DC State: At 4pt and Modify without EFD - Verify expiry is calculated from Written Date if EFD is not selected and drug is C2 opioid with PA Prescriber.
      * Pre -Conditions :1.Set the store state to DC
                         2.Do the flags check up
      * Author: Nanthini Munusamy(vn576ph)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "CII Expiration Dates DC State: At 4pt and Modify without EFD - Verify expiry is calculated from Written Date if EFD is not selected and drug is C2 opioid with PA Prescriber",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "State_DC_VT")
    public void HWPHME2E_3160_Verify_expiryDate_calculated_from_WrittenDate_if_EFD_not_selected(Map<String, String> inputData) {
        stateUpdate();
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.validateRxExpiryDateInput(inputData);
        orderIntakeTestScript.verifyExpiryDateonFourPoint(inputData);
        orderIntakeTestScript.verifyExpiryDateonModifyDetails(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description:CII Expiration Dates DC State: At 4pt and F9 screen with EFD - Verify expiry is calculated from earliest fill date if EFD is selected and drug is C2 opioid with PA Prescriber.
      * Pre -Conditions :1.Set the store state to DC
                         2.Do the flags check up
      * Author: Nanthini Munusamy(vn576ph)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "HWPHME2E_3161_Verify_expiryDate_calculated_from_WrittenDate_if_EFD_selected",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "State_DC_VT")
    public void HWPHME2E_3161_Verify_expiryDate_calculated_from_WrittenDate_if_EFD_selected(Map<String, String> inputData) {
        stateUpdate();
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.validateRxExpiryDateFromEFD(inputData);
        orderIntakeTestScript.verifyExpiryDateonFourPoint(inputData);
        orderIntakeTestScript.verifyExpiryDateonModifyDetails(inputData);
        Reporter.log("Verified-HWPHME2E_3161_Verify_expiryDate_calculated_from_WrittenDate_if_EFD_selected");
    }


    /*----------------------------------------------------------------------------------------------------------
      * Test Description:CII Expiration Dates DC State: Select and Set EFD>Rx written date and set Rx Expiration Date under the calculated date- Verify Rx should allow to complete input if input drug is C2 non-opioid.
      * Pre -Conditions :1.Set the store state to DC
                         2.Do the flags check up
      * Author: Nanthini Munusamy(vn576ph)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "HWPHME2E_3158_verify_RX_submitted_at_input_if_C2_drug_is_non_opiod.",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "State_DC_VT")
    public void HWPHME2E_3158_verify_RX_submitted_at_input_if_C2_drug_is_non_opiod(Map<String, String> inputData) {
        Reporter.log("Validate HWPHME2E_3158_verify_RX_submitted_at_input_if_C2_drug_is_non_opiod");
        stateUpdate();
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        connexusAPIManager.restartConnexusService(prop.getProperty("cnx.store"));
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff(Priority.Critical);
        orderIntakeTestScript.validateRxExpiryDateFromEFD(inputData);
        orderIntakeTestScript.verifyRxIn4PointQueue();
        Reporter.log("Validate-HWPHME2E_3158_verify_RX_submitted_at_input_if_C2_drug_is_non_opiod");
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description:CII Expiration Dates DC State: Select and Set EFD>Rx written date and unselect EFD- Verify Rx should be submitted at Input if input drug is C2 opioid.
      * Pre -Conditions :1.Set the store state to DC
                         2.Do the flags check up
      * Author: Nanthini Munusamy(vn576ph)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "HWPHME2E_3159_verify_RX_submitted_at_input_if_C2_drug_is_opiod.",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "State_DC_VT")
    public void HWPHME2E_3159_verify_RX_submitted_at_input_if_C2_drug_is_opiod(Map<String, String> inputData) {
        Reporter.log("Validate Rx should be submitted at Input if input drug is C2 opioid");
        stateUpdate();
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.selectAndUnSelectEFD(inputData);
        orderIntakeTestScript.verifyRxIn4PointQueue();
        Reporter.log("Validation is done for HWPHME2E-3159 Rx should be submitted at Input if input drug is C2 opioid");
    }

    @Test(enabled = true, description = "Verify expiry is calculated from earliest fill date if EFD is selected and not selected if input drug is C2 opioid.",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "State_DC_VT")
    public void HWPHME2E_3163_verify_RX_Moving_to_Hold_Status(Map<String, String> inputData) {
        Reporter.log("HWPHME2E_3163_verify_RX_Moving_to_Hold_Status");
        stateUpdate();
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        orderIntakeTestScript.initializeTestCase(false);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff(Priority.Critical);
        orderIntakeTestScript.validateRxExpiryDateOnInput(inputData);
        orderIntakeTestScript.verifyRxHoldStatusOnFourPoint(inputData);
        Reporter.log("HWPHME2E_3163_verify_RX_Moving_to_Hold_Status");
    }
}