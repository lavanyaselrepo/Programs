package connexus.OrderIntake.testcases;

import connexus.OrderIntake.testscripts.OrderIntakeTestScripts;
import connexus.PMP.testScripts.PMPTestDataGenerationTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;

import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import java.util.Map;

public class OrderIntakeTestSet2 {
    OrderIntakeTestScripts orderIntakeTestScript;
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    PropertyReader prop = PropertyReader.getInstance();
    String stateCode;
    String siteId =prop.getProperty("cnx.store");
    boolean flagUpdated;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils.startAppiumServer();
        orderIntakeTestScript = new OrderIntakeTestScripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

     /*----------------------------------------------------------------------------------------------------------
      * Test Description:Dispensed qty more than 90 > prescribed qty for Non-Controlled Drug with Refills greater than zero then hard halt pop-up is not displayed in Input when 9140 Flag is set to 90
      * Pre -Conditions :1.Set the store state to AR
                         2.Do the flags check up
      * Author: Snehaa(vn57hhm)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Dispensed qty more than 90 > prescribed qty for Non-Controlled Drug with Refills greater than zero then hard halt pop-up is not displayed in Input when 9140 Flag is set to 90",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderIntakeSet2.json", sheetName = "OrderI")
    public void HWPHME2E_2671(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("32717", "Y");
        String issueAgencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState("AR");
        Reporter.log("issue_agency_code is " + issueAgencyCode);
        connexusAppUtils.updateAgencyClsRequirementParmTable("90","9140","2304",issueAgencyCode);
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.daysValidationInInput(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description:Dispensed qty > prescribed qty for Non-Controlled Drug with Refills greater than zero then hard halt pop-up is not displayed in Input when 15123 Flag is set to 90
      * Pre -Conditions :1.Set the store state to AK
                         2.Do the flags check up
                         3.Check Dispensed quantity above 90
      * Author: Snehaa(vn57hhm)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Dispensed qty > prescribed qty for Non-Controlled Drug with Refills greater than zero then hard halt pop-up is not displayed in Input when 15123 Flag is set to 90",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderIntakeSet2.json", sheetName = "OrderI")
    public void HWPHME2E_2670(Map<String, String> inputData) {

        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AK");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("32717", "Y");
        String issueAgencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState("AK");
        Reporter.log("issue_agency_code is " + issueAgencyCode);
        connexusAppUtils.updateAgencyClsRequirementParmTable("90","9140","2304",issueAgencyCode);
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.daysValidationInInput(inputData);
    }

     /*----------------------------------------------------------------------------------------------------------
      * Test Description:C2 drug in Input - Validate the Walmart policy pop-up should not be displayed if days supply is >90 for state AR
      * Conditions: 1.Box state should be set to AR
                    2.Walmart's policy pop-up should be displayed if days supply is >90 for state AR
      * Author: Snehaa(vn57hhm)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "C2 drug in Input - Validate the Walmart policy pop-up should not be displayed if days supply is >90 for state AR",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderIntakeSet2.json", sheetName = "OrderI")
    public void HWPHME2E_3175(Map<String, String> inputData) {

        String siteId =prop.getProperty("cnx.store");
        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        String stateCode = connexusAppUtils.getCurrentStoreState();
        String codes = connexusAppUtils.selectAgencyRequirementParm("32496", stateCode);
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.verifyWalmartpolicyPopupInInput(inputData);
    }

     /*----------------------------------------------------------------------------------------------------------
      * Test Description:  MD - Drop an Rx with controlled drug C2 with prescriber clinic address state: MD and prescriber degree as 416
      * Author: Niraj(vn50sfl)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify Attending Physician tab is not displayed for MD prescriber",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_3179(Map<String, String> inputData) {
        Reporter.log("<<<Verify Attending Physician Tab for Certified Nurse Practitioners>>>");
        // Pre-conditions
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("404", "32683", stateCode);
        orderIntakeTestScript.initializeTestCase(flagUpdated);

        // Steps
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        // Here Prescriber clinical address index is being passed along with prescription input details
        orderIntakeTestScript.performInputAndSelectPresAddress(inputData);
        orderIntakeTestScript.validateAttendingPhysicianIn4Point(inputData, false);
        orderIntakeTestScript.verifyNoAttendingPhysicianModifyDetails();
        Reporter.log("<<<Verified Attending Physician Tab for Certified Nurse Practitioners>>>");
    }

     /*----------------------------------------------------------------------------------------------------------
      * Test Description:  MD - Drop an Rx with controlled drug C3/C4/C5 with prescriber clinic address state: MD and prescriber degree as 416
      * Author: Niraj(vn50sfl)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify Attending Physician Tab missing for Certified Nurse Practitioners and C3,C4,C5 products",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_3180(Map<String, String> inputData) {
        Reporter.log("<<<Verify Attending Physician Tab missing for Certified Nurse Practitioners and C3,C4,C5 products>>>");
        // Pre-conditions
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("PRODUCT_NDC"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("404", "32683", stateCode);
        orderIntakeTestScript.initializeTestCase(flagUpdated);

        // Steps
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.insertDetailsInInput(inputData);
        orderIntakeTestScript.validateNoAttendingPhyPopUp();
        orderIntakeTestScript.updatePrescriberProduct(inputData.get("PRODUCT_NDC2"));
        orderIntakeTestScript.validateNoAttendingPhyPopUp();
        orderIntakeTestScript.updatePrescriberProduct(inputData.get("PRODUCT_NDC3"));
        orderIntakeTestScript.validateNoAttendingPhyPopUp();
        Reporter.log("<<<Verified Attending Physician Tab for Certified Nurse Practitioners and C3,C4,C5 products>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description:  MD - Drop an Rx with controlled drug C2 with prescriber clinic address state: TN and prescriber degree as CRNP(403)
      * Author: Niraj(vn50sfl)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify Attending Physician Tab is populating for Certified Nurse Practitioners and C2 products",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_3181(Map<String, String> inputData) {
        Reporter.log("<<<Verify Attending Physician Tab populating for Certified Nurse Practitioners and C2 products>>>");
        // Pre-conditions
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateAgencyRequirementParmTable("403,404,414", "32683", "242");
        orderIntakeTestScript.initializeTestCase(flagUpdated);

        // Steps
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.insertDetailsInInput(inputData);
        // Validates for attendingPhysician tab and name field before entering data in input
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"input","");
        // Validates invalid data popup
        orderIntakeTestScript.validateInvalidateDataPopup("input");
        // Validates for attendingPhician tab and name field before entering data in F9
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"modifydetails","");
        // Validates invalid data popup
        orderIntakeTestScript.validateInvalidateDataPopup("modifydetails");
        // Enter attendingPhysician details in input
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"input","enterDetails");
        // Matches attendingPhysician name as enetered in input
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"modifydetails","attendingPhyDetailValidation");
        // Closes the F9 screen
        orderIntakeTestScript.completeProcessForDiffWorkQueues("modifydetails");
        // Completes input
        orderIntakeTestScript.completeProcessForDiffWorkQueues("input");
        // Launch 4point and validate attendingPhysician details
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"4point","");
        // Opens F9 from 4point and matches attendingPhysisican name as entered in input
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"modifydetails","attendingPhyDetailValidation");
        orderIntakeTestScript.completeProcessForDiffWorkQueues("modifydetails");
        // Completes 4point
        orderIntakeTestScript.completeProcessForDiffWorkQueues("4point");
        orderIntakeTestScript.performChkDUR();
        // Launches filling and validates attendingPhysician name as eneterd in input
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"filling","");
        orderIntakeTestScript.completeProcessForDiffWorkQueues("modifydetails");

        Reporter.log("<<<Verified Attending Physician Tab populating for Certified Nurse Practitioners and C2 products>>>");
    }


     /*----------------------------------------------------------------------------------------------------------
      * Test Description:Dispensed qty > prescribed qty then hard halt_ C4 RX in Input and 4-Point
      *  Conditions: Flags should be updated
      * Author: Snehaa(vn57hhm)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Dispensed qty greater than prescribed qty then hard halt pop up displayed for C4 drug RX in Input and 4-Point",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderIntakeSet2.json", sheetName = "OrderI")
    public void HWPHME2E_2711(Map<String, String> inputData) {

        Reporter.log("<<Validate halt pop up displayed when dispensed quantity is greater than prescribed quantity>>");
        connexusAppUtils.getStoreId();
        //Flag update
        connexusAppUtils.getCurrentStoreState();
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32717", "Y");
        //Log in to connexus
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        //Create patient perform Drop-off move till Input
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        //Validating pop up for Dispensed quantity when given greater than prescribed quantity in input,Modify details and Four point page
        orderIntakeTestScript.validatingDispensedQuantityInInput(inputData);
        orderIntakeTestScript.validateDispQtyInModifyDtlAndFourPoint(inputData);
        Reporter.log("<<Successfully Validated halt pop up displayed when dispensed quantity is greater than prescribed quantity>>");
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description:Dispensed qty > prescribed qty then hard halt_ C5 RX in Input and 4-Point
      *  Conditions: Flags should be updated
      * Author: Snehaa(vn57hhm)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Dispensed qty > prescribed qty then hard halt_ C5 RX in Input and 4-Point",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderIntakeSet2.json", sheetName = "OrderI")
    public void HWPHME2E_2710(Map<String, String> inputData) {

        Reporter.log("Validate halt pop up displayed when dispensed quantity is greater than prescribed quantity for C5 drug");
        connexusAppUtils.getStoreId();
        //Flag update
        connexusAppUtils.getCurrentStoreState();
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32717", "Y");
        //Log in to connexus
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        //Create patient perform Drop-off move till Input
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        //Validating pop up for Dispensed quantity when given greater than prescribed quantity in input,Modify details and Four point page
        orderIntakeTestScript.validatingDispensedQuantityInInput(inputData);
        orderIntakeTestScript.validateDispQtyInModifyDtlAndFourPoint(inputData);
        Reporter.log("Successfully Validated halt pop up displayed when dispensed quantity is greater than prescribed quantity for c5 drug");
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description:Dispensed qty greater than prescribed qty then hard halt_ C3 RX in Input and 4-Point and F9
      *  Conditions: Flags should be updated
      * Author: Snehaa(vn57hhm)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Dispensed qty greater than prescribed qty then hard halt_ C3 RX in Input and 4-Point and F9",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderIntakeSet2.json", sheetName = "OrderI")
    public void HWPHME2E_2712(Map<String, String> inputData) {

        Reporter.log("Validate halt pop up displayed when dispensed quantity is greater than prescribed quantity for C3 drug");
        connexusAppUtils.getStoreId();
        //Flag update
        connexusAppUtils.getCurrentStoreState();
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32717", "Y");
        //Log in to connexus
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        //Create patient perform Drop-off move till Input
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        //Validating pop up for Dispensed quantity when given greater than prescribed quantity in input,Modify details and Four point page
        orderIntakeTestScript.validatingDispensedQuantityInInput(inputData);
        orderIntakeTestScript.validateDispQtyInModifyDtlAndFourPoint(inputData);
        Reporter.log("Successfully Validated halt pop up displayed when dispensed quantity is greater than prescribed quantity for c3 drug");
    }

     /*----------------------------------------------------------------------------------------------------------
      * Test Description:CII Expiration Dates for VT State : At Input with EFD - Verify expiry is calculated from Written date if EFD is selected if input drug is Non-Controlled
      *  Conditions: Store state should be updated
      * Author: Snehaa(vn57hhm)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "CII Expiration Dates for VT State : At Input with EFD - Verify expiry is calculated from Written date if EFD is selected if input drug is Non-Controlled.",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderIntakeSet2.json", sheetName = "OrderI")
    public void HWPHME2E_3164(Map<String, String> inputData) {
        Reporter.log("Validate expiry date for non controlled drug in input when ETD is selected for VT state");
        connexusAppUtils.getStoreId();
        //state update
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STORE_STATE"));
        //Log in to connexus
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        //Create patient perform Drop-off move till Input
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        //Validating expiry date for non controlled drug in input when ETD is selected for VT state
        orderIntakeTestScript.verifyExpiryDateInInput(inputData);
        Reporter.log("Successfully Validated expiry date for non controlled drug in input when ETD is selected for VT state");
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description:CII Expiration Dates for VT State : At Input with EFD - Verify expiry is calculated from written date if EFD is selected  if input drug is C5 opioid.
      *  Conditions: Store state should be updated
      * Author: Snehaa(vn57hhm)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "CII Expiration Dates for VT State : At Input with EFD - Verify expiry is calculated from written date if EFD is selected  if input drug is C5 opioid.",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderIntakeSet2.json", sheetName = "OrderI")
    public void HWPHME2E_3165(Map<String, String> inputData) {
        Reporter.log("Validate expiry date for c5 opioid drug in input when ETD is selected for VT state");
        connexusAppUtils.getStoreId();
        //state update
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STORE_STATE"));
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        //Validating expiry date for c5 opioid drug in input when ETD is selected for VT state
        orderIntakeTestScript.verifyExpiryDateInInput(inputData);
        Reporter.log("Successfully Validated expiry date for c5 opioid drug in input when ETD is selected for VT state");
    }
    /**
     * ----------------------------------------------------------------------------------------------------------
     * Test Description:To verify Validate the Walmart policy pop-up is displayed if days supply is >90 for state that's eligible for 90 days limit
     * JIRA:HWPHME2E_3176
     * <p>
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.C2 drug in Input - Validate the Walmart policy pop-up is displayed if days supply is >90 for state that's eligible for 90 days limit
     * <p>
     * Author: Mallikarjuna(vn58n9x)
     * ----------------------------------------------------------------------------------------------------------
     */
    @Test(enabled = true, description = "HWPHME2E_3176_C2 drug in Input - Validate the Walmart policy pop-up is displayed if days supply is >90 for state that's eligible for 90 days limit",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderIntakeSet2.json", sheetName = "OrderTc")
    public void HWPHME2E_3176(Map<String, String> inputData) {
        Reporter.log("<<<C2 drug in Input - Validate the Walmart policy pop-up is displayed if days supply is >90 for state that's eligible for 90 days limit>>>");
        connexusAppUtils.getlogSiteIdAndState(inputData);
        orderIntakeTestScript.initializeTestCase(false);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.verifyWalmartpolicyPopupInInput(inputData);
        Reporter.log("<<<Validation is done for C2 drug in Input - Validate the Walmart policy pop-up is displayed if days supply is greater than90 for state that's eligible for 90 days limit>>>");
    }
    /*----------------------------------------------------------------------------------------------------------
     * Test Description:  MD - Drop an Rx with controlled Compound drug with prescriber clinic address state: MD and prescriber degree as 416
     * JIRA:HWPHME2E_3177
     *
     *Pre-Conditions:
     *
     * 1.User is logged into Connexus
     * 2.Compound drug in Input -  Prescriber Clinic Address as MD and Prescriber Degree as 416-CRNA
     * 3.Author: Mallikarjuna(vn58n9x)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify Attending Physician tab is not displayed for MD prescriber",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_3177_Verify_Attending_Physician_Tab_is_not_displayed_for_MD_Prescriber(Map<String, String> inputData) {
        Reporter.log("<<<Verify Attending Physician Tab for Certified Nurse Practitioners>>>");
        // Pre-conditions
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        orderIntakeTestScript.initializeTestCase(flagUpdated);

        // Steps
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        // Here Prescriber clinical address index is being passed along with prescription input details
        orderIntakeTestScript.performInputAndSelectPresAddress(inputData);
        orderIntakeTestScript.validateAttendingPhysicianIn4Point(inputData, false);
        orderIntakeTestScript.verifyNoAttendingPhysicianModifyDetails();
        Reporter.log("<<<Verified Attending Physician Tab for Certified Nurse Practitioners>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:  CII Expiration Dates VT State: At 4pt and F9 screen with EFD - Verify expiry is calculated from earliest fill date if EFD is selected and drug is C2 opioid with MD Prescriber.
     * Author: Nanthini Munusamy(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "CII Expiration Dates VT State: At 4pt and F9 screen with EFD - Verify expiry is calculated from earliest fill date if EFD is selected and drug is C2 opioid with MD Prescriber.",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "State_DC_VT")
    public void HWPHME2E_3167_VT_State_Verify_expiryDate_calculated_from_WrittenDate_if_EFD_selected(Map<String, String> inputData) {
        Reporter.log("<<<VCII Expiration Dates VT State: At 4pt and F9 screen with EFD - Verify expiry is calculated from earliest fill date if EFD is selected and drug is C2 opioid with MD Prescriber>>");
        // Pre-conditions
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        // Steps
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.validateRxExpiryDateFromEFD(inputData);
        orderIntakeTestScript.verifyExpiryDateonFourPoint(inputData);
        orderIntakeTestScript.verifyExpiryDateonModifyDetails(inputData);
        Reporter.log("<<<Validation is done for HWPHME2E-3167 >>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:  C3 Expiration Dates VT State: At input screen with EFD - Verify expiry is calculated from earliest fill date if EFD is selected and not selected when drug is C3 opioid.
    * Author: DEVI THUMMALA(d0t0dwk)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "C3 Expiration Dates VT State: At 4pt and F9 screen with EFD - Verify expiry is calculated from earliest fill date if EFD is selected and drug is C3 Opioid with MD Prescriber.",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "State_DC_VT")
    public void HWPHME2E_3162_Verify_expiryDate_calculated_from_WrittenDate_if_EFD_selected_notSelected(Map<String, String> inputData) {
        Reporter.log("<<<C3 Expiration Dates VT State: At 4pt and F9 screen with EFD - Verify expiry is calculated from earliest fill date if EFD is selected and drug is C3 opioid with MD Prescriber>>");
        // Pre-conditions
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        // Steps to Create patient and drop off
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        //Validation
        orderIntakeTestScript.validateRxExpiryDateOnInput(inputData);
        Reporter.log("<<<Validation is done for HWPHME2E-3162 >>>");
    }

       /*----------------------------------------------------------------------------------------------------------
      * Test Description:  MD - Drop a Rx with controlled drug C2 with prescriber clinic address state: MD and prescriber degree as PA
      * Author: Niraj(vn50sfl)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify Attending Physician Tab is populating for PA and C2 products with MD store and MD clinic",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_2799_Verify_attending_phy_tab_populates_for_PA_and_c2_with_MD_store_and_MD_clinic(Map<String, String> inputData) {
        Reporter.log("<<<Verify Attending Physician Tab is populating for PA and C2 products with MD store and MD clinic>>>");
        // Pre-conditions
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateAgencyRequirementParmTable("404", "32683", "220");
        orderIntakeTestScript.initializeTestCase(flagUpdated);

        // Steps
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.insertDetailsInInput(inputData);
        // Validates for attendingPhysician tab and name field before entering data in input
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"input","");
        // Validates invalid data popup
        orderIntakeTestScript.validateInvalidateDataPopup("input");
        // Enter attendingPhysician details in input
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"input","enterDetails");

        // Completes input
        orderIntakeTestScript.completeProcessForDiffWorkQueues("input");
        // Launch 4point and validate attendingPhysician details
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"4point","");
        // Opens F9 from 4point and matches attendingPhysisican name as entered in input
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"modifydetails","attendingPhyDetailValidation");
        orderIntakeTestScript.completeProcessForDiffWorkQueues("modifydetails");

        Reporter.log("<<<Verified Attending Physician Tab is populating for PA and C2 products with MD store and MD clinic>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3166 Test Description: "CII Expiration Dates VT State: Select and Set EFD>Rx written date and set Rx Expiration Date under the calculated date-
           Verify Rx should allow to complete input if input drug is C2 opioid."
   * Pre-Conditions:
   * 1.User is logged into Connexus
   * 2.Update store state to VT
   * Author: Purnima Arora (vn58gdi)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "CII Expiration Dates for VT State : At Input with EFD - Verify expiry is calculated from Written date if EFD is selected if input drug is C2 drug",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_3166(Map<String, String> inputData) {
        Reporter.log(" State-VT Validate expiry date for C2 drug in input when EFD is selected greater than written date and check rx should allow to complete input");
        connexusAppUtils.getStoreId();
        //state update and flushCache if required
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        //Log in to connexus
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        //Create patient perform Drop-off move till Input
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        //Validating expiry date for C2  drug in input when EFD is selected greater than written date for VT state
        orderIntakeTestScript.validateRxExpiryDateFromEFD(inputData);
        Reporter.log("Successfully Validated expiry date for C2 drug in and completed input EFD is selected greater than written for VT state");
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description:  Validate whether Original RX with controlled C3/C4/C5 Drug and refill>0 would just transfer out instead of faxing
      * Author: Niraj(vn50sfl)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify Original RX with controlled C3/C4/C5 Drug and refill>0 would just transfer out instead of faxing",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_1565_Verify_original_RX_with_C3_C4_C5_drug_and_refills_would_just_transfer_out_instead_of_faxing(Map<String, String> inputData) {
        Reporter.log("Verify Original RX with controlled C3/C4/C5 Drug and refill>0 would just transfer out instead of faxing");
        // Pre-conditions
        connexusAppUtils.getlogSiteIdAndState(inputData);
        orderIntakeTestScript.initializeTestCase(false);
        // Steps
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.insertDetailsInInput(inputData);
        // Completes input
        orderIntakeTestScript.completeProcessForDiffWorkQueues("input");
        orderIntakeTestScript.moveRxToEod(siteId);
        orderIntakeTestScript.completeRxOrder(siteId);
        orderIntakeTestScript.transferRxFromF7(inputData);
        orderIntakeTestScript.validateFaxOutStatus();
        Reporter.log("Verified Original RX with controlled C3/C4/C5 Drug and refill>0 would just transfer out instead of faxing");
    }
    /*----------------------------------------------------------------------------------------------------------
      * Test Description:  Validate whether Original RX with controlled C2 Drug would not transfer out
      * Author: Purnima Arora (vn58gdi)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Validate whether Original RX with controlled C2 Drug would not transfer out",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_1566_Verify_original_RX_with_C2_drug_would_not_transfer_out(Map<String, String> inputData) {
        Reporter.log("Verify Original RX with controlled C2 Drug would not transfer out");
        // Pre-conditions
        connexusAppUtils.getlogSiteIdAndState(inputData);
        orderIntakeTestScript.initializeTestCase(false);
        // Steps
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.insertDetailsInInput(inputData);
        // Completes input
        orderIntakeTestScript.completeProcessForDiffWorkQueues("input");
        orderIntakeTestScript.moveRxToEod(siteId);
        orderIntakeTestScript.completeRxOrder(siteId);
        orderIntakeTestScript.validateTransferRxDisabledFromF7(inputData);
        Reporter.log("Verified Original RX with controlled C2 Drug would not transfer out");
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description:  Validate whether Original RX with non-Controlled Drug and refill=0 would faxes out transfers
      * Author: Niraj(vn50sfl)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate whether Original RX with non-Controlled Drug and refill=0 would transfer",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_1564_Verify_original_RX_with_noncontroldrug_and_no_refills_would_transfer(Map<String, String> inputData) {
        Reporter.log("Validate whether Original RX with non-Controlled Drug and refill=0 would transfer");
        // Pre-conditions
        connexusAppUtils.getlogSiteIdAndState(inputData);
        orderIntakeTestScript.initializeTestCase(false);
        // Steps
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.insertDetailsInInput(inputData);
        // Completes input
        orderIntakeTestScript.completeProcessForDiffWorkQueues("input");
        orderIntakeTestScript.moveRxToEod(siteId);
        orderIntakeTestScript.completeRxOrder(siteId);
        orderIntakeTestScript.transferRxFromF7(inputData);
        Reporter.log("Validated whether Original RX with non-Controlled Drug and refill=0 would transfer");
    }
  /*----------------------------------------------------------------------------------------------------------
      * Test Description:  MD - Drop a Rx with controlled drug C2 with prescriber clinic address state: MO and prescriber degree as PA
      * Author: dramas1
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify Attending Physician Tab is populating for PA and C2 products with MD store and MO clinic",
            priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_2798_Verify_attending_phy_tab_populates_for_PA_and_c2_with_MD_store_and_MO_clinic(Map<String, String> inputData) {
        Reporter.log("<<<Verify Attending Physician Tab is populating for PA and C2 products with MD store and MO clinic>>>");
        // Pre-conditions
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateAgencyRequirementParmTable("404", "32683", "220");
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        // Steps
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.insertDetailsInInput(inputData);
        // Validates for attendingPhysician tab and name field before entering data in input
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"input","");
        // Validates invalid data popup
        orderIntakeTestScript.validateInvalidateDataPopup("input");
        // Enter attendingPhysician details in input
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"input","enterDetails");
        // Completes input
        orderIntakeTestScript.completeProcessForDiffWorkQueues("input");
        // Launch 4point and validate attendingPhysician details
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"4point","");
        // Opens F9 from 4point and matches attendingPhysisican name as entered in input
        orderIntakeTestScript.validateAttendingPhyDetails(inputData,"modifydetails","attendingPhyDetailValidation");
        orderIntakeTestScript.completeProcessForDiffWorkQueues("modifydetails");
        Reporter.log("<<<Verified Attending Physician Tab is populating for PA and C2 products with MD store and MO clinic>>>");
    }
    /*----------------------------------------------------------------------------------------------------------
      * Test Description:  Validate whether Original RX with controlled C3/C4/C5 Drug and refill>0 would not transfer out Rx
      * Author: Mallikarjuna M(vn58n9x)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify Original RX with controlled C3/C4/C5 Drug and refill=0 would not transfer out Rx",
            priority = 21, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_1563_Verify_original_RX_with_C3_C4_C5_drug_and_refills_would_not_transfer_out_RX(Map<String, String> inputData) {
        Reporter.log("Verify Original RX with controlled C3/C4/C5 Drug and refill=0 would not transfer out RX");
        // Pre-conditions
        String siteId =prop.getProperty("cnx.store");
        connexusAppUtils.getStoreId();
        //Pre-Conditions
        //1.State should be set to MN
        //Agency param for agency code of MN should be set to F&P for source store and destination store
        //Flag for 15068 and 27126 should be set to QA
        String agencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATES"));
        connexusAppUtils.updateAgencyRequirementParmTable(inputData.get("RestrictTypeValue"),inputData.get("RestrictTypeCode"),agencyCode);
        connexusAppUtils.updateAgencyRequirementParmTableForDestinationStore(inputData.get("RestrictTypeValue"),inputData.get("RestrictTypeCode"),agencyCode, Integer.parseInt(inputData.get("TRANSFER_STORE")));
        connexusAppUtils.updateFlagValue(inputData.get("FLAG_CODE"),inputData.get("FlagValue"));
        connexusAppUtils.updateFlagValue(inputData.get("FLAG_CODE2"),inputData.get("FlagValue"));

        orderIntakeTestScript.initializeTestCase(true);
        // Steps
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.insertDetailsInInput(inputData);

//        // Completes input
        orderIntakeTestScript.completeProcessForDiffWorkQueues("input");
        orderIntakeTestScript.perform4Point();
        orderIntakeTestScript.validatePutRxOnHold(inputData);
        orderIntakeTestScript.clickTransferBtnRXFromF7(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.insertDetailsInInput(inputData);
        orderIntakeTestScript.completeProcessForDiffWorkQueues("input");
        orderIntakeTestScript.moveRxToEod(siteId);
        orderIntakeTestScript.completeRxOrder(siteId);
        orderIntakeTestScript.transferRxFromF7(inputData);

        Reporter.log("Verified Original RX with controlled C3/C4/C5 Drug and refill=0 would not transfer out Rx ");
    }
}