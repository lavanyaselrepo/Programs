package connexus.OrderIntake.testcases;

import connexus.OrderIntake.testscripts.OrderIntakeTestScripts;
import connexus.PMP.testScripts.PMPTestDataGenerationTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.datamodels.connexus.PatientProfileModel;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class OrderIntakeTestSetTX {
    OrderIntakeTestScripts orderIntakeTestScript;
    ConnexusAppUtils connexusAppUtils;
    ConnexusAPIManager connexusAPIManager= new ConnexusAPIManager();
    PropertyReader prop = PropertyReader.getInstance();
    boolean flagUpdated = false;
    String stateCode = "";

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        orderIntakeTestScript = new OrderIntakeTestScripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3172 Test Description: "Verify Rx should not allow to complete input without having the correct Rx expiration if input drug is C2 non-opioid"
   *
   * Pre-Conditions:
   * 1.User is logged into Connexus
   * 2.Update store state to TX
   * Author: Aparna Ramalingam(vn50izt)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify Rx should not allow to complete input without having the correct Rx expiration if input drug is C2 non-opioid",
            dataProviderClass = DataProvider.class, priority = 1, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "StateTX")
    public void HWPHME2E_3172_verify_earliestfilldate(Map<String, String> inputData) {
        String siteId =prop.getProperty("cnx.store");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        connexusAPIManager.restartConnexusService(siteId);
        orderIntakeTestScript.initializeTestCase(true);
        connexusAppUtils.getStoreId();
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.enterInputDetailsWithoutAttendingPhysicianGeneric(inputData);
        orderIntakeTestScript.setEarliestFIllDateAndExpirationDate(2,3);
        orderIntakeTestScript.verifyRXOutOfScopePopUp(inputData.get("POPUP"));
    }
    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3169 Test Description: "Verify expiry is calculated from written date if EFD is selected and not selected if input drug is C5 opioid"
   *
   * Pre-Conditions:
   * 1.User is logged into Connexus
   * 2.Update store state to TX
   * Author: Aparna Ramalingam(vn50izt)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify expiry is calculated from written date if EFD is selected and not selected if input drug is C5 opioid",
            dataProviderClass = DataProvider.class, priority = 2, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "StateTX")
    public void HWPHME2E_3169_verify_expirationdate(Map<String, String> inputData) {
        String siteId =prop.getProperty("cnx.store");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        orderIntakeTestScript.initializeTestCase(true);
        connexusAppUtils.getStoreId();
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.enterInputDetailsWithoutAttendingPhysicianGeneric(inputData);
        orderIntakeTestScript.verifyExpirationDate(180);
    }
    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3171 Test Description: "CII Expiration Dates TX State: At 4pt and Modify with EFD - Verify expiry is calculated from earliest fill date if EFD is selected and drug is C2 opioid"
   *
   * Pre-Conditions:
   * 1.User is logged into Connexus
   * 2.Update store state to TX
   * Author: Purnima Arora (vn58gdi)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify expiry is calculated from earliest fill date if EFD is selected and drug is C2 opioid with MD prescriber ",
            dataProviderClass = DataProvider.class, priority = 3, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "StateTX")
    public void HWPHME2E_3171_verify_expiration_date_at_4point_and_modifyDetails_withEFD(Map<String, String> inputData) {
        String siteId =prop.getProperty("cnx.store");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        orderIntakeTestScript.initializeTestCase(true);
        connexusAppUtils.getStoreId();
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.validateRxExpiryAfterEFDIncreamentInInput(inputData);
        orderIntakeTestScript.verifyExpiryDateOn4pointAfterEFDIncreament();
        orderIntakeTestScript.verifyExpiryDateOnModifyDetailsAfterEFDIncreament(inputData);
    }
    /*----------------------------------------------------------------------------------------------------------
      * HWPHME2E_5252 Test Description: "QE | Regression | Validate Rx is required to be written on tamper-resistant paper"
      *
      * Pre-Conditions:
      * 1.Update store state to TX
      *  2. select * from agency_rqmt_parm where restrict_type_code = 19489 and issue_agency_code = 243; -- should be set as 19489-TRUE
      * update agency_rqmt_parm set restrict_type_val = 'TRUE' where restrict_type_code='19489' and issue_agency_code=243 );
      Note: issue_agency_code - will change based on state wise.
      * Author: Revathi (vn59b4)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate Rx is required to be written on tamper-resistant paper",
            dataProviderClass = DataProvider.class, priority = 1, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "StateTX")
    public void HWPHME2E_5252_Verify_RX_required_Tamper_Resistant_Paper(Map<String, String> inputData) {
        //update state and flag
        connexusAppUtils.updateStateValue(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" + inputData.get("PHARMACY_STATE"));
        flagUpdated = connexusAppUtils.updateAgencyRequirementParmTbl("TRUE", "19489", "243");
        orderIntakeTestScript.restartService();
        orderIntakeTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils.getStoreId();
        orderIntakeTestScript.createNewPatient(inputData, 1);
        orderIntakeTestScript.performDropOff(false);
        orderIntakeTestScript.insertDetailsInInput(inputData);
        orderIntakeTestScript.inputComplete();
        orderIntakeTestScript.ValidateTamperResistantPopup();
    }

}