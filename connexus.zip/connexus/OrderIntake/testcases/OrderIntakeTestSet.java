package connexus.OrderIntake.testcases;


import connexus.OrderIntake.testscripts.OrderIntakeTestScripts;
import connexus.PMP.testScripts.PMPTestDataGenerationTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.pageobjectmodels.connexus.F6Search;

import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class OrderIntakeTestSet {
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    OrderIntakeTestScripts orderIntakeTestScripts;
    boolean flagUpdated = false;

    @BeforeClass
    public void performlogin(){
        connexusAppUtils = new ConnexusAppUtils();
        orderIntakeTestScripts = new OrderIntakeTestScripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

     /*----------------------------------------------------------------------------------------------------------
             * Test Description:Drop-off: Search for a patient → Add a Rx and select the Rx# as >1 in the Rx# drop down and complete the flow till EOD
             *
             * Author: Snehaa(vn57hhm)
             ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "HWPHME2E_1318_Drop_off_Add_multiple_Rx's_through_'# of Rx'_field_in_Order_Information_table",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_1318(Map<String, String> inputData) {
        System.out.println("<<<TC001_Add multiple Rx's through '# of Rx' field in Order Information table>>>");

        connexusAppUtils.getStoreId();
        orderIntakeTestScripts.initializeTestCase(false);
        orderIntakeTestScripts.createNewPatient(inputData);
        orderIntakeTestScripts.performDropOff(3,Priority.Critical);
        orderIntakeTestScripts.createMultiRXtoEOD();

        System.out.println("<<<TC001_Add multiple Rx's through '# of Rx' field in Order Information table>>>");
    }

       /*----------------------------------------------------------------------------------------------------------
      * Test Description:Verify Attending Physician Tab for IL Nurse Practitioner license number starting 277
      *
      * Pre-Conditions: 1.ARP flag 15176 should have restrict_type_val set as "403,414"
                        2.Box state should be set to IL
                        3.Prescriber with degree 403 or 414 should exist with state license number starting 277 or 377
                               414 = ARNP- Advanced Registered Nurse Practitioner
                               403 = CRNP- Cert. Registered Nurse Practitioner
                        4.Add new prescriber in Connexus in case there are no existing prescribers matching search criteria (Sample NPI, Sate license and DEA numbers provided below)
      *
      * Author: Snehaa(vn57hhm)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify Attending Physician Tab for IL Nurse Practitioner license number starting 277",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_1535(Map<String, String> inputData) {

        System.out.println("<<<Verify Attending Physician Tab for IL Nurse Practitioner license number starting 277>>>");
        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("IL");
        Reporter.log("Updated store state is IL");
        String statecode = "";
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState("IL");
        Reporter.log("State code ======" + statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("403,414", "15176", statecode);
        Reporter.log("ARP flag 15176 have restrict_type_val set as 403,414");

        orderIntakeTestScripts.initializeTestCase(flagUpdated);
        orderIntakeTestScripts.createNewPatient(inputData);
        orderIntakeTestScripts.performDropOff();
        orderIntakeTestScripts.inputwithPrescriberModifications(inputData);
        orderIntakeTestScripts.modifyPrescribers(inputData);
        orderIntakeTestScripts.VerifyAPin4point();

        System.out.println("<<<TC001_Add multiple Rx's through '# of Rx' field in Order Information table>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:VerifyRx - Info in store db(drop rx for cash patient, move till filling queue, check
     *                             store db for patients record and then drop rx for TP patient, move till 4Point
     *                             queue and check store db for patients record)
     *
     * Pre-Conditions: 1.VerifyRx flags 26070, 26170, 26071 to be set : TRUE
                       2.Env flag 15068 values :TEST

     * Author: Diya(vn58o0i)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "VerifyRx_Validate_the_Info(success)_response", priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_1169(Map<String, String> inputData){
        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateFlag("26070", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("26170", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("26071", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15068", "TEST");

        orderIntakeTestScripts.initializeTestCase(flagUpdated);
        //create new patient with cash as payment type
        orderIntakeTestScripts.createNewPatient(inputData);
        orderIntakeTestScripts.performDropOff();
        orderIntakeTestScripts.performInput(inputData);
        orderIntakeTestScripts.perform4Point();
        orderIntakeTestScripts.verifyRxInFillingQueue();
//        validate the patient record in store db
        orderIntakeTestScripts.validatePatientRecordInWorkFlowRsqtTrsfTable();

        //create Tp patient
        orderIntakeTestScripts.createNewPatient(inputData, 1);
        orderIntakeTestScripts.performDropOff();
        orderIntakeTestScripts.performInput(inputData);
        orderIntakeTestScripts.verifyRxIn4PointQueue();
        //validate the patient record in store db
        orderIntakeTestScripts.validatePatientRecordInWorkFlowRsqtTrsfTable();
    }

    /**
     * Test Description: verify State NH | C2 non-Opioid in Input - Validate pop-up should not be displayed if days supply <=90
     * @param inputData
     */
    @Test(enabled = true, description = "State NH | C2 non-Opioid in Input - Validate pop-up should not be displayed if days supply <=90",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_5466(Map<String, String> inputData) {
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("NH");
        connexusAppUtils.getStoreId();
        orderIntakeTestScripts.initializeTestCase(flagUpdated);
        orderIntakeTestScripts.createNewPatient(inputData);
        orderIntakeTestScripts.performDropOff();
        //validate restrict perform input based on the qty
        orderIntakeTestScripts.validateInvalidDaysSupplyInPerformInputScreen(inputData,true);
        orderIntakeTestScripts.validateInvalidDaysSupplyInPerformInputScreen(inputData,false);
        orderIntakeTestScripts.performInputForOpiodAndNonOpiodDrug(inputData,true);
        orderIntakeTestScripts.verifyRxIn4PointQueue();
        orderIntakeTestScripts.performDropOff();
        orderIntakeTestScripts.performInputForOpiodAndNonOpiodDrug(inputData,false);
        orderIntakeTestScripts.verifyRxIn4PointQueue();
    }

    /**
     * Test Description: verify State MA | C2 non-Opioid in Input - Validate pop-up should not be displayed if days supply <=90
     * @param inputData
     */
    @Test(enabled = true, description = "Store State MA | C2 non-Opioid in Input - Validate pop-up should not be displayed if days supply <=90",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrdereCreation/OrderCreation.json", sheetName = "OrderCreation")
    public void HWPHME2E_5240(Map<String, String> inputData) {
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("MA");
        connexusAppUtils.getStoreId();
        orderIntakeTestScripts.initializeTestCase(flagUpdated);
        orderIntakeTestScripts.createNewPatient(inputData);
        orderIntakeTestScripts.performDropOff();
        //validate restrict perform input based on the qty
        orderIntakeTestScripts.validateInvalidDaysSupplyInPerformInputScreen(inputData,true);
        orderIntakeTestScripts.validateInvalidDaysSupplyInPerformInputScreen(inputData,false);
        orderIntakeTestScripts.performInputForOpiodAndNonOpiodDrug(inputData,true);
        orderIntakeTestScripts.verifyRxIn4PointQueue();
        orderIntakeTestScripts.performDropOff();
        orderIntakeTestScripts.performInputForOpiodAndNonOpiodDrug(inputData,false);
        orderIntakeTestScripts.verifyRxIn4PointQueue();
    }

}