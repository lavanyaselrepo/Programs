package connexus.OrderIntake.testcases;

import connexus.OrderIntake.testscripts.OrderIntakeTestScripts;
import connexus.PMP.testScripts.PMPTestDataGenerationTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Map;

public class OrderIntakeTestSet1 {
    OrderIntakeTestScripts orderIntakeTestScript;
    ConnexusAppUtils connexusAppUtils;
    ConnexusAPIManager connexusAPIManager;
    PropertyReader prop = PropertyReader.getInstance();
    boolean flagUpdated;
    String siteId =prop.getProperty("cnx.store");
    boolean relaunchConnexus;
    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        orderIntakeTestScript = new OrderIntakeTestScripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils.startAppiumServer();
    }
    @BeforeMethod
    public void setup() {
        connexusAPIManager = new ConnexusAPIManager();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }
    public void restartConnexusService(){
        if (flagUpdated) {
            Reporter.log("Restarting Connexus service to apply updated flags");
            connexusAPIManager.restartConnexusService(siteId);
            relaunchConnexus = true;
        } else {
            Reporter.log("No flags updated, skipping Connexus service restart");
        }
    }
    /*----------------------------------------------------------------------------------------------------------
    * HWPHME2E_1541 Test Description: "Verify Attending Physician tab is not displayed for MD prescriber in IL state"
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.Set Agency Param to IL and update store state to IL
    * Author: Sweety Saxena(vn56iwu)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify Attending Physician tab is not displayed for MD prescriber in IL state", priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_1541(Map<String, String> inputData) {

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.Query to check ARP flag 15176
        //select * from agency_rqmt_parm where issue_agency_code=213 and restrict_type_code=15176 //Query to check and update box state: Box<5514> state should be set to IL
        //select * from Bus_unit_addr; update Bus_unit_addr set state='IL' where bu_nbr=5514 //Queries to check Prescriber in DB:
        //select * from prescriber p join prescriber_degree pd on p.prescriber_id =pd.prescriber_id join prescriber_license pl on pl.prescriber_id =p.prescriber_id where pl.issue_agency_code =213 and pd.degree_code = 400

        flagUpdated = connexusAppUtils.readAndUpdateStoreState("IL");
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        connexusAppUtils.updateAgencyRequirementParmTable("IL", "15176", "213");

        connexusAppUtils.verifyAgencyRequirementsRestrictTypeValue("32683","400");

        restartConnexusService();
        orderIntakeTestScript.initializeTestCase(flagUpdated);


        //2. Create new patient in Connexus | Connexus should allow user to create new patient
        orderIntakeTestScript.createNewPatient(inputData);

        //3.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        orderIntakeTestScript.performDropOff();

        //4.Search for the rx which is in input queue and enter all the required details. | Connexus should allow user to search and the rx and should be able to enter all the required details successfully
        orderIntakeTestScript.performInputAndClickAccept(inputData,false);
        orderIntakeTestScript.validateAttendingPhysicianTabStatus(false);
        orderIntakeTestScript.clickAcceptOnInputPage();

        //5. Add prescriber with state as IL >>>>>>
        orderIntakeTestScript.validateAttendingPhysicianIn4Point(inputData, false);

        //6.Verify Attending Physician is not displaying in Modify Details
        orderIntakeTestScript.verifyNoAttendingPhysicianModifyDetails();

        System.out.println("<<HWPHME2E-1541>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * HWPHME2E_1567 Test Description: "Validate whether Original RX with non-Controlled Drug and refill>0 would faxes out transfers"
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.Update store state to MN
    * Author: Sweety Saxena(vn56iwu)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate whether Original RX with non-Controlled Drug and refill>0 would faxes out transfers",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_1567(Map<String, String> inputData) {

        //Pre-Conditions
        //1.State should be set to MN
        //Agency param for agency code of MN should be set to F&P for source store and destination store
        //Flag for 15068 and 27126 should be set to QA
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("SC");
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        String agencyCode = connexusAppUtils.fetchIssueAgencyCodeOfState("SC");
        connexusAppUtils.updateAgencyRequirementParmTable("F&P","15209",agencyCode);
        connexusAppUtils.updateAgencyRequirementParmTableForDestinationStore("F&P","15209",agencyCode,5521);
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15068", "QA");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("27126", "QA");

        restartConnexusService();
        orderIntakeTestScript.initializeTestCase(flagUpdated);

        orderIntakeTestScript.createNewPatient(inputData);

        //Drop Rx till EOD after completing POS
        orderIntakeTestScript.dropAnRxTillEOD(inputData);

        //Verify Rx transfers from RxLookup and populates in fax outbox
        orderIntakeTestScript.enterRxIntoRxLookUp(inputData);
        System.out.println("<<<HWPHME2E_1567>>>");
    }

     /*----------------------------------------------------------------------------------------------------------
    * HWPHME2E_1552 Test Description: "Patient Maintenance -> Profile View Attending Physician column in MI state"
    * This test is kept as ON HOLD as per discussion and confirmation with Deepa Ramasay over mail
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.Update store state to MI
    * Author: Sweety Saxena(vn56iwu)
    ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "Patient Maintenance -> Profile View Attending Physician column in MI state",priority = 4,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_1552(Map<String, String> inputData) {

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.Change state to MI

        flagUpdated = connexusAppUtils.readAndUpdateStoreState("MI");
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        String stateCode = connexusAppUtils.getCurrentStoreState();
        String codes = connexusAppUtils.selectAgencyRequirementParmTable("32683", stateCode);
        orderIntakeTestScript.verifyCodes(codes);
        restartConnexusService();
        orderIntakeTestScript.initializeTestCase(flagUpdated);

        //2. Create new patient in Connexus | Connexus should allow user to create new patient
        orderIntakeTestScript.createNewPatient(inputData);

        //3.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        orderIntakeTestScript.performDropOff();

        //4.Search for the rx which is in input queue and enter all the required details. | Connexus should allow user to search and the rx and should be able to enter all the required details successfully

        orderIntakeTestScript.performInputAndClickAccept(inputData,false);
        orderIntakeTestScript.validateAttendingPhysicianTabStatus(true);
        orderIntakeTestScript.clickAcceptOnInputPage();
        //5. verify Attending Physician in 4 point

        orderIntakeTestScript.validateAttendingPhysicianIn4Point(inputData, false);
        orderIntakeTestScript.perform4Point();
        //6. Complete CheckDUR
        orderIntakeTestScript.performChkDUR();

        //7. Verify Attending Physician column in RxLookup
        orderIntakeTestScript.verifyRxIntoRxLookUp(inputData);
    }

     /*----------------------------------------------------------------------------------------------------------
    * HWPHME2E_1546 Test Description: "Dropoff prescription history- Attending Physician column display for MI state"
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.Update store state to MI
    * Author: Sweety Saxena(vn56iwu)
    ----------------------------------------------------------------------------------------------------------*/

    @Test(description = "Dropoff prescription history- Attending Physician column display for MI state",priority = 1,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_1546(Map<String, String> inputData) {
        //Pre-Conditions
        //1.User is logged into Connexus
        //2.Updated state to MI
        //3.Verify Attending physician column displays in Drop Off prescription history

        flagUpdated = connexusAppUtils.readAndUpdateStoreState("MI");
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        String statecode = connexusAppUtils.getCurrentStoreState();
        String codes = connexusAppUtils.selectAgencyRequirementParmTable("32683", statecode);
        orderIntakeTestScript.verifyCodes(codes);
        restartConnexusService();
        orderIntakeTestScript.initializeTestCase(flagUpdated);

        //2. Create new patient in Connexus | Connexus should allow user to create new patient
        orderIntakeTestScript.createNewPatient(inputData);

        //3.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        orderIntakeTestScript.performDropOff();

        //4.Search for the rx which is in input queue and enter all the required details. | Connexus should allow user to search and the rx and should be able to enter all the required details successfully
        orderIntakeTestScript.performInputAndClickAccept(inputData,true);

        //5.Add prescriber and Attending physician in four point
        orderIntakeTestScript.validateAttendingPhysicianIn4Point(inputData, true);
        orderIntakeTestScript.perform4Point();

        //6. Verify dropOff screen is having Attending physician column in prescriptin history table
        orderIntakeTestScript.verifyDropOffPrescriptionHistory();

        System.out.println("<<HWPHME2E_1546>>>");
    }


    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3173 Test Description: "Verify expiry is calculated from earliest fill date if EFD is selected and drug is C2 opioid with Non MD Prescriber with Non TX clinic address, Attending Physician"
   *
   * Pre-Conditions:
   * 1.User is logged into Connexus
   * 2.Update store state to TX
   * Author: Aparna Ramalingam(vn50izt)
   ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify expiry is calculated from earliest fill date if EFD is selected and drug is C2 opioid with Non MD Prescriber with Non TX clinic address ",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_3173_verifyefd_nonTxprescriber(Map<String, String> inputData) {

        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.enterInputDetailsWithoutAttendingPhysicianForC2(inputData);
        orderIntakeTestScript.verifyPrescriberINStatePopUp();


    }
     /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3170 Test Description: "Verify expiry is calculated from earliest fill date"
   *
   * Pre-Conditions:
   * 1.User is logged into Connexus
   * 2.Update store state to TX
   * Author: Aparna Ramalingam(vn50izt)
   ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify expiry is calculated from earliest fill date if EFD is selected and drug is C2 opioid ",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_3170_verify_earliestfilldate(Map<String, String> inputData) {
        String siteId =prop.getProperty("cnx.store");
        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.enterInputDetailsWithoutAttendingPhysicianForC2(inputData);
    }
     /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_3170 Test Description: "Validate the prescription restrict is displayed if days supply is >90 for state MO"
   *
   * Pre-Conditions:
   * 1.User is logged into Connexus
   * 2.Update store state to TX
   * Author: Aparna Ramalingam(vn50izt)
   ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Validate the prescription restrict is displayed if days supply is >90 for state MO ",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "OrderIntake")
    public void HWPHME2E_3174_validate_walmart_policy_popup(Map<String, String> inputData) {
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        orderIntakeTestScript.performInputAndClickAccept(inputData,true);
        orderIntakeTestScript.verifyInputPopUpOnly(inputData);
    }

     /*----------------------------------------------------------------------------------------------------------
      * Test Description:C3 Expiration Dates VT State: At Input with EFD - Verify expiry is calculated from Written date even if EFD is selected and not selected if input drug is C3 opioid.
      *  Conditions: Store state should be updated to VT
      * Author: Pranav(vn59m66)
      ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "C3 Expiration Dates VT State: At Input with EFD - Verify expiry is calculated from Written date even if EFD is selected and not selected if input drug is C3 opioid",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "State_DC_VT")
    public void HWPHME2E_3162_Verify_expiryDate_calculated_from_WrittenDate_if_EFD_selected_notSelected(Map<String, String> inputData) {
        Reporter.log("Validate expiry date for c3 opioid drug in input when EFD is selected/not selected for VT state");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        orderIntakeTestScript.initializeTestCase(flagUpdated);
        orderIntakeTestScript.createNewPatient(inputData);
        orderIntakeTestScript.performDropOff();
        //Validating expiry date for c3 opioid drug on input
        orderIntakeTestScript.validateRxExpiryDateOnInput(inputData);

        Reporter.log("Successfully Validated expiry date for c3 opioid drug in input");
    }

}


