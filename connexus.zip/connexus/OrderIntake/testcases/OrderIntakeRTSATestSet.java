package connexus.OrderIntake.testcases;

import connexus.OrderIntake.testscripts.OrderIntakeTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.Reporter;
import org.testng.annotations.*;

import java.util.Map;

public class OrderIntakeRTSATestSet {

    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    OrderIntakeTestScripts orderIntakeTestScripts = new OrderIntakeTestScripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    //boolean testUI = true;
    boolean testUI = Boolean.parseBoolean(System.getProperty("testUI", "true"));
    boolean flagUpdated = false;

    @BeforeClass
    public void performlogin() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    // Jira(testID = "HWPHME2E-5531")
    @Test(enabled = true, description = "Drop a Rx with product-duration mismatch and verify Input - Resolve the RTSA callout in Input",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "RTSA_TestData")
    public void HWPHME2E_5531_DropRx_with_product_duration_mismatch_and_verify_Input(Map<String, String> inputData) {
        Reporter.log("Validate the user able to add Multiple recommendations into the order");

        // Pre-requisite: Get SiteID and State
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        // update RTSA flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32159", "TRUE");
        if (testUI) {
            // create patient and Drop off through UI
            orderIntakeTestScripts.initializeTestCase(flagUpdated);
            orderIntakeTestScripts.createNewPatient(inputData);
            orderIntakeTestScripts.performDropOff();
        } else {
            orderIntakeTestScripts.initializeTestCase(flagUpdated, false);
            // create Patient through API
            orderIntakeTestScripts.createPatientAPI(inputData);
            // Drop off Rx through API
            orderIntakeTestScripts.performCompleteDropOffAPI(inputData);
            orderIntakeTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        orderIntakeTestScripts.performInput(inputData);
        // Validate Sig Highlight Color and complete input screen
        orderIntakeTestScripts.validateSigHighlightAndCompleteInput(inputData, true);
        // perform Additional Quality Verification Popup
        orderIntakeTestScripts.perform4PointForVerificationPopup(inputData);

        if (testUI) {
            //perform Filling and move to EOD using UI
            orderIntakeTestScripts.moveFromChkDurTillEODThroughUI(inputData);
        } else {
            // perform chkDur using API, and perform Filling and move to EOD using API
            orderIntakeTestScripts.performChkDurAPI();
            orderIntakeTestScripts.performSingleRxFillingAndMoveToEOD();
        }
    }

    // Jira(testID = "HWPHME2E-5533")
    @Test(enabled = true, description = "Drop a Rx with product-directions mismatch and verify therapy confirmed- clinically justified flow in 4P layover screen",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "RTSA_TestData")
    public void HWPHME2E_5533_DropRx_with_product_directions_mismatch_and_verify_therapy_confirmation_in_4Point_layover_screen(Map<String, String> inputData) {
        Reporter.log("Validate the user able to add Multiple recommendations into the order");

        // Pre-requisite: Get SiteID and State
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        // update RTSA flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32159", "TRUE");

        if (testUI) {
            // create patient and Drop off through UI
            orderIntakeTestScripts.initializeTestCase(flagUpdated);
            orderIntakeTestScripts.createNewPatient(inputData);
            orderIntakeTestScripts.performDropOff();
        } else {
            orderIntakeTestScripts.initializeTestCase(flagUpdated, false);
            // create Patient through API
            orderIntakeTestScripts.createPatientAPI(inputData);
            // Drop off Rx through API
            orderIntakeTestScripts.performCompleteDropOffAPI(inputData);
            orderIntakeTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        orderIntakeTestScripts.performInput(inputData);
        // Validate Sig Highlight Color and complete input screen
        orderIntakeTestScripts.validateSigHighlightAndCompleteInput(inputData, false);
        // perform Additional Quality Verification Popup
        orderIntakeTestScripts.perform4PointForVerificationPopup(inputData.get("responseType"), inputData);

        if (testUI) {
            //perform Filling and move to EOD using UI
            orderIntakeTestScripts.moveFromChkDurTillEODThroughUI(inputData);
        } else {
            // perform chkDur using API, and perform Filling and move to EOD using API
            orderIntakeTestScripts.performChkDurAPI();
            orderIntakeTestScripts.performSingleRxFillingAndMoveToEOD();
        }
    }

    // Jira(testID = "HWPHME2E-5532")
    @Test(enabled = true, description = "Drop a Rx with product-directions mismatch and Select Input Error in 4P layover screen- resolve the callout in Input",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "RTSA_TestData")
    public void HWPHME2E_5532_DropRx_with_product_duration_mismatch_and_select_Input_Error_in_4Point_layover_screen(Map<String, String> inputData) {
        Reporter.log("Validate the user able to add Multiple recommendations into the order");

        // Pre-requisite: Get SiteID and State
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        // update RTSA flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32159", "TRUE");

        if (testUI) {
            // create patient and Drop off through UI
            orderIntakeTestScripts.initializeTestCase(flagUpdated);
            orderIntakeTestScripts.createNewPatient(inputData);
            orderIntakeTestScripts.performDropOff();
        } else {
            orderIntakeTestScripts.initializeTestCase(flagUpdated, false);
            // create Patient through API
            orderIntakeTestScripts.createPatientAPI(inputData);
            // Drop off Rx through API
            orderIntakeTestScripts.performCompleteDropOffAPI(inputData);
            orderIntakeTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }

        orderIntakeTestScripts.performInput(inputData);
        // Validate Sig Highlight Color and complete input screen
        orderIntakeTestScripts.validateSigHighlightAndCompleteInput(inputData, false);
        // perform Additional Quality Verification Popup
        orderIntakeTestScripts.performAdditionalQualityVerificationForInputError(inputData,0);
        orderIntakeTestScripts.perform4PointForVerificationPopup(inputData);

        if (testUI) {
            //perform Filling and move to EOD using UI
            orderIntakeTestScripts.moveFromChkDurTillEODThroughUI(inputData);
        } else {
            // perform chkDur using API, and perform Filling and move to EOD using API
            orderIntakeTestScripts.performChkDurAPI();
            orderIntakeTestScripts.performSingleRxFillingAndMoveToEOD();
        }
    }

    // Jira(testID = "HWPHME2E-5928")
    @Test(enabled = true, description = "Verify the Cancellation flow for a RTSA drug in Input WQ - Obtained new prescription",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "RTSA_TestData")
    public void HWCUSTEX_23431_Verify_Cancellation_flow_in_Input_WQ_Obtained_new_prescription(Map<String, String> inputData) {
        Reporter.log("Verify the Cancellation flow for a RTSA drug in Input WQ - Obtained new prescription");

        // Pre-requisite: Get SiteID and State
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        // update RTSA flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32159", "TRUE");
        if (testUI) {
            // create patient and Drop off through UI
            orderIntakeTestScripts.initializeTestCase(flagUpdated);
            orderIntakeTestScripts.createNewPatient(inputData);
            orderIntakeTestScripts.performDropOff();
        } else {
            orderIntakeTestScripts.initializeTestCase(flagUpdated, false);
            // create Patient through API
            orderIntakeTestScripts.createPatientAPI(inputData);
            // Drop off Rx through API
            orderIntakeTestScripts.performCompleteDropOffAPI(inputData);
            orderIntakeTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        // perform Input
        orderIntakeTestScripts.performInput(inputData);
        // Validate Sig Highlight Color input screen
        orderIntakeTestScripts.validateSigHighlight(inputData);
        // cancel fill and deactivate prescriptions for duplicate fill input WQ
        orderIntakeTestScripts.selectCancelFillForDuplicateFill();
        // select reason as Obtained new prescription then accept, Rx should be cancelled
        orderIntakeTestScripts.selectCancelFillWithObtainedNewPrescriptionReason();
        // Verify Rx notes and Rx history status shows cancelled
        orderIntakeTestScripts.validateRxNotesAndRxHistoryStatus();
        Reporter.log("Cancellation flow for RTSA drug in Input WQ - Obtained new prescription completed successfully");
    }

    // Jira(testID = "HWPHME2E-5933")
    @Test(enabled = true, description = "Verify the Cancellation flow for a RTSA drug in Input WQ - Other",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "RTSA_TestData")
    public void HWCUSTEX_23432_Verify_Cancellation_flow_in_Input_WQ_Other(Map<String, String> inputData) {
        Reporter.log("Verify the Cancellation flow for a RTSA drug in Input WQ - Other");

        // Pre-requisite: Get SiteID and State
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        // update RTSA flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32159", "TRUE");
        if (testUI) {
            // create patient and Drop off through UI
            orderIntakeTestScripts.initializeTestCase(flagUpdated);
            orderIntakeTestScripts.createNewPatient(inputData);
            orderIntakeTestScripts.performDropOff();
        } else {
            orderIntakeTestScripts.initializeTestCase(flagUpdated, false);
            // create Patient through API
            orderIntakeTestScripts.createPatientAPI(inputData);
            // Drop off Rx through API
            orderIntakeTestScripts.performCompleteDropOffAPI(inputData);
            orderIntakeTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        // perform Input
        orderIntakeTestScripts.performInput(inputData);
        // Validate Sig Highlight Color input screen
        orderIntakeTestScripts.validateSigHighlight(inputData);
        // cancel fill and deactivate prescriptions for duplicate fill input WQ
        orderIntakeTestScripts.selectCancelFillForDuplicateFill();
        // select reason as Other then accept, Rx should be cancelled
        orderIntakeTestScripts.selectCancelFillWithOtherReason();
        // Verify Rx notes and Rx history status shows cancelled
        orderIntakeTestScripts.validateRxNotesAndRxHistoryStatus();
        Reporter.log("Cancellation flow for RTSA drug in Input WQ - Other completed successfully");
    }

    // Jira(testID = "HWPHME2E-5931")
    @Test(enabled = true, description = "Verify the Cancellation flow for a RTSA drug in Input WQ - Prescriber/Patient requested cancellation",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "RTSA_TestData")
    public void HWCUSTEX_23433_Verify_Cancellation_flow_in_Input_WQ_Prescriber_Patient_Requested_Cancellation(Map<String, String> inputData) {
        Reporter.log("Verify the Cancellation flow for a RTSA drug in Input WQ - Prescriber/Patient requested cancellation");

        // Pre-requisite: Get SiteID and State
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        // update RTSA flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32159", "TRUE");
        if (testUI) {
            // create patient and Drop off through UI
            orderIntakeTestScripts.initializeTestCase(flagUpdated);
            orderIntakeTestScripts.createNewPatient(inputData);
            orderIntakeTestScripts.performDropOff();
        } else {
            orderIntakeTestScripts.initializeTestCase(flagUpdated, false);
            // create Patient through API
            orderIntakeTestScripts.createPatientAPI(inputData);
            // Drop off Rx through API
            orderIntakeTestScripts.performCompleteDropOffAPI(inputData);
            orderIntakeTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        // perform Input
        orderIntakeTestScripts.performInput(inputData);
        // Validate Sig Highlight Color input screen
        orderIntakeTestScripts.validateSigHighlight(inputData);
        // cancel fill and deactivate prescriptions for duplicate fill input WQ
        orderIntakeTestScripts.selectCancelFillForDuplicateFill();
        // select reason as Prescriber/Patient requested cancellation
        orderIntakeTestScripts.selectCancelFillWithPrescriberPatientRequestedReason();
        // Verify Rx notes and Rx history status shows cancelled
        orderIntakeTestScripts.validateRxNotesAndRxHistoryStatus();
        Reporter.log("Cancellation flow for RTSA drug in Input WQ - Prescriber/Patient requested cancellation completed successfully");
    }

    // Jira(testID = "HWPHME2E-5930")
    @Test(enabled = true, description = "Verify the Cancellation flow for a RTSA drug in 4Point WQ - Obtained new prescription",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "RTSA_TestData")
    public void HWCUSTEX_23445_Verify_Cancellation_flow_in_4Point_WQ_Obtained_New_Prescription(Map<String, String> inputData) {
        Reporter.log("Verify the Cancellation flow for a RTSA drug in 4Point WQ - Obtained new prescription");

        // Pre-requisite: Get SiteID and State
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        // update RTSA flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32159", "TRUE");
        if (testUI) {
            // create patient and Drop off through UI
            orderIntakeTestScripts.initializeTestCase(flagUpdated);
            orderIntakeTestScripts.createNewPatient(inputData);
            orderIntakeTestScripts.performDropOff();
        } else {
            orderIntakeTestScripts.initializeTestCase(flagUpdated, false);
            // create Patient through API
            orderIntakeTestScripts.createPatientAPI(inputData);
            // Drop off Rx through API
            orderIntakeTestScripts.performCompleteDropOffAPI(inputData);
            orderIntakeTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        // perform Input
        orderIntakeTestScripts.performInput(inputData);
        // Validate Sig Highlight Color and complete input screen
        orderIntakeTestScripts.validateSigHighlightAndCompleteInput(inputData, false);
        // perform Additional Quality Verification Popup
        orderIntakeTestScripts.validate4PointVerificationPopupWithoutCompletion(inputData.get("responseType"),0);
        // cancel fill and deactivate prescriptions for duplicate fill input WQ
        orderIntakeTestScripts.selectCancelFillForDuplicateFill();
        // select reason as Obtained new prescription then accept, Rx should be cancelled
        orderIntakeTestScripts.selectCancelFillWithObtainedNewPrescriptionReason();
        // Verify Rx notes and Rx history status shows cancelled
        orderIntakeTestScripts.validateRxNotesAndRxHistoryStatus();
        Reporter.log("Cancellation flow for RTSA drug in 4Point WQ - Obtained new prescription completed successfully");
    }

    // Jira(testID = "HWPHME2E-5932")
    @Test(enabled = true, description = "Verify the Cancellation flow for a RTSA drug in 4Point WQ - Other",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "RTSA_TestData")
    public void HWCUSTEX_23446_Verify_Cancellation_flow_in_4Point_WQ_Other(Map<String, String> inputData) {
        Reporter.log("Verify the Cancellation flow for a RTSA drug in 4Point WQ - Other");

        // Pre-requisite: Get SiteID and State
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        // update RTSA flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32159", "TRUE");
        if (testUI) {
            // create patient and Drop off through UI
            orderIntakeTestScripts.initializeTestCase(flagUpdated);
            orderIntakeTestScripts.createNewPatient(inputData);
            orderIntakeTestScripts.performDropOff();
        } else {
            orderIntakeTestScripts.initializeTestCase(flagUpdated, false);
            // create Patient through API
            orderIntakeTestScripts.createPatientAPI(inputData);
            // Drop off Rx through API
            orderIntakeTestScripts.performCompleteDropOffAPI(inputData);
            orderIntakeTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        // perform Input
        orderIntakeTestScripts.performInput(inputData);
        // Validate Sig Highlight Color and complete input screen
        orderIntakeTestScripts.validateSigHighlightAndCompleteInput(inputData, false);
        // perform Additional Quality Verification Popup
        orderIntakeTestScripts.validate4PointVerificationPopupWithoutCompletion(inputData.get("responseType"),1);
        // cancel fill and deactivate prescriptions for therapy discontinued 4point WQ
        orderIntakeTestScripts.selectCancelFillForTherapyDiscontinued();
        // select reason as Obtained new prescription then accept, Rx should be cancelled
        orderIntakeTestScripts.selectCancelFillWithOtherReason();
        // Verify Rx notes and Rx history status shows cancelled
        orderIntakeTestScripts.validateRxNotesAndRxHistoryStatus();
        Reporter.log("Cancellation flow for RTSA drug in 4Point WQ - Other completed successfully");
    }

    // Jira(testID = "HWPHME2E-5929")
    @Test(enabled = true, description = "Verify the Cancellation flow for a RTSA drug in 4PointQ - Prescriber/Patient requested cancellation",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntake/OrderIntake.json", sheetName = "RTSA_TestData")
    public void HWCUSTEX_23447_Verify_Cancellation_flow_in_4Point_WQ_Prescriber_Patient_requested_cancellation(Map<String, String> inputData) {
        Reporter.log("Verify the Cancellation flow for a RTSA drug in 4Point WQ - Prescriber/Patient requested cancellation");

        // Pre-requisite: Get SiteID and State
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        // update RTSA flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32159", "TRUE");
        if (testUI) {
            // create patient and Drop off through UI
            orderIntakeTestScripts.initializeTestCase(flagUpdated);
            orderIntakeTestScripts.createNewPatient(inputData);
            orderIntakeTestScripts.performDropOff();
        } else {
            orderIntakeTestScripts.initializeTestCase(flagUpdated, false);
            // create Patient through API
            orderIntakeTestScripts.createPatientAPI(inputData);
            // Drop off Rx through API
            orderIntakeTestScripts.performCompleteDropOffAPI(inputData);
            orderIntakeTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        // perform Input
        orderIntakeTestScripts.performInput(inputData);
        // Validate Sig Highlight Color and complete input screen
        orderIntakeTestScripts.validateSigHighlightAndCompleteInput(inputData, false);
        // perform Additional Quality Verification Popup
        orderIntakeTestScripts.validate4PointVerificationPopupWithoutCompletion(inputData.get("responseType"),1);
        // cancel fill and deactivate prescriptions for 'patient wants written rx back' 4point WQ
        orderIntakeTestScripts.selectCancelFillForPatientWantsWrittenRxBack();
        // select reason as Obtained new prescription then accept, Rx should be cancelled
        orderIntakeTestScripts.selectCancelFillWithPrescriberPatientRequestedReason();
        // Verify Rx notes and Rx history status shows cancelled
        orderIntakeTestScripts.validateRxNotesAndRxHistoryStatus();
        Reporter.log("Cancellation flow for RTSA drug 4Point WQ - Prescriber/Patient requested cancellation completed successfully");
    }

}