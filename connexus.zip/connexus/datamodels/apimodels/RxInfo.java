package connexus.datamodels.apimodels;

@lombok.Getter
@lombok.Setter
public class RxInfo {
    String expSigTxt;
    String originalExpSigTxt;
    String orgPresSigTxt;
    String presSigTxt;
    int onHand;
    int prescQty;
    int labelerId;
    int orgPrescQty;
    int fillQty;
    int fillDaysQty;
    int orgFillDaysQty;
    int remainingQty;
    String addressLine1;
    String homePhone;
    String patCSZ;
    String originalPatientName;
    String requestTypeDescription;
    int dawCode;
    int orgDawCode;
    int fillTypeCode;
    int orgFillTypeCode;
    int expectedSaleAmt;
    int priceClassCode;
    int taxAmt;
    int markupAmt;
    int usualPriceAmt;
    String dawDesc;
    int inputSourceCode;
    int innerPack;
    int erxRespTypeCode;
    int erxResponseId;
}
