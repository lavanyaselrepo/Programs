package connexus.datamodels.apimodels;

@lombok.Getter
@lombok.Setter
public class Prescriber {
    private String fullname="THOMAS, WALDEN MACNAIR";
    private String firstname="WALDEN MACNAIR";
    private String lastname="THOMAS";
    private String phone="(898)989-8999";
    private String state="CA";
    private int  prescriberId=1105;
    private int rxClinicId=5308;
    private String dea="BT2413146";
    private String npi="2999997788";
}
