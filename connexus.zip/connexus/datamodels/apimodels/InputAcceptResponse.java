package connexus.datamodels.apimodels;

@lombok.Getter
@lombok.Setter
public class InputAcceptResponse {
    int requestTypeCode;
    int priorityId;
    boolean changeMode;
    int patientId;
    int orderId;
    private boolean visible;
    private int selectedIndex;
    int siteID;
    String pickUpDate;
    int rxFillId;
    int rxId;
    int orderSeqNbr;
    int inputId;
    int rxNbr;
    int orgPriorityId;
    String fillDate;
    String rxWrittenDate;
    String rxExpDate;
    String inputPickUpDate;
    String inputRxExpDate;
    int dispenseType;
    boolean updateFillViaDB;
    int toteNumber;
    int numRefills;
    int productMdsFamId;
    String ndcnumber;
    Drug drug;
    Prescriber prescriber;
    RxInfo rxInfo;
    boolean orderTypeERx;
}
