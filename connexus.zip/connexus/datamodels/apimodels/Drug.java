package connexus.datamodels.apimodels;

@lombok.Getter
@lombok.Setter

public class Drug {
    String name;
    String ndc;
    int itemId;
    int rxProdId;
    int controlCode;
    int presMultiSrcCode;
    String gpiCode;
//    String name = "PredniSONE 5MG      TAB";
//    String ndc = "59746017210";
//    int itemId = 243361;
//    int rxProdId = 134380;
//    int controlCode = 2304;
//    int presMultiSrcCode = 2603;
//    String gpiCode = "22100045000315";
    String usualCost = "0";
    String actCost = "0";
    String orgUsualCost = "0";
}
