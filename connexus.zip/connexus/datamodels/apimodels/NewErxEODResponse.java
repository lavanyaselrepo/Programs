package connexus.datamodels.apimodels;


import java.util.List;

@lombok.Getter
@lombok.Setter
@lombok.ToString
public class NewErxEODResponse {
    List<Error> Error;
    List<Success> Success;
}
