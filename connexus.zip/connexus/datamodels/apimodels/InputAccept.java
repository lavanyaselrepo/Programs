package connexus.datamodels.apimodels;

@lombok.Getter
@lombok.Setter
public class InputAccept {
    int requestTypeCode = 1600;
    int priorityId;
    boolean changeMode;
    int patientId;
    int orderId;
    int packId = 0;
    int packageId = 0;
    private boolean visible = false;
    private int selectedIndex = 0;
    private int selectedValue = 0;
    private int tempPriority = 0;
    private String controlDate = null;
    int siteID;
    String pickUpDate;
    int rxFillId;
    int rxId;
    int orderSeqNbr;
    int inputId;
    int rxNbr = 0;
    int orgPriorityId;
    String fillDate;
    String rxWrittenDate;
    private int requestSeqNbr = 0;
    String rxExpDate;
    String inputPickUpDate;
    String inputRxExpDate;
    private int requestId = 0;
    int dispenseType;
    boolean updateFillViaDB;
    int toteNumber;
    int numRefills;
    private boolean allowExpiredOrder = false;
    int productMdsFamId;
    private String omsOfferId = null;
    private String omsWtxCode = null;
    private String rxInfo = null;
    private String workQueue = null;
    private String exceptionDetails = null;
    private String shippingResponseData = null;
    private boolean patientHasInsurance = false;
    private boolean shippingSuccessful = false;
    String ndcnumber;
    Drug drug;
    private boolean orderTypeERx = true;
    Prescriber prescriber;
}
