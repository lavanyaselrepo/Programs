package connexus.datamodels.dbmodels;
@lombok.Getter
@lombok.Setter
public class PharmacyProductDB {
    public String short_name;
    public int product_mds_fam_id;
    public int mds_fam_id;
    public int drug_control_code;
    public String gpi_code;
    public int multi_source_code;
}
