package connexus.datamodels.dbmodels;

@lombok.Getter
@lombok.Setter
public class DrugDescDB {
    public String ItemId;
    public String DispensedProductId;
    public String DrugControlCode;
}
