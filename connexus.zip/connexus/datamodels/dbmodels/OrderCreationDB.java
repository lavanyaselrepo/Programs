package connexus.datamodels.dbmodels;

@lombok.Getter
@lombok.Setter
public class OrderCreationDB {
    public String rx_id;
    public String input_Id;
    public String patient_id;
    public String prescriber_id;
    public String clinic_id;
    public String rx_written_date;
    public String rx_exp_date;
    public String order_id;
    public String order_seq_nbr;
    public String priority_id;
    public String rx_fill_id;
    public String FillDate;
}
