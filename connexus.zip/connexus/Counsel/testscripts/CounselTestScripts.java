package connexus.Counsel.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.AppMenu;
import hwqe.baseframework.connexuscontext.ConnexusConstants;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.joda.time.DateTime;
import org.testng.Assert;
import java.util.List;

import java.util.Map;

public class CounselTestScripts extends ConnexusTestScripts {

    public CounselTestScripts(LoginAs.userType loginUserType){
        super(loginUserType);
    }

    private List<String> chkDurMessages;

    /* Method to complete 4point checks
     * Author: Prashant */
    public void validate4pointForCounselRequired(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1],0);

            if(checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(),ConnexusConstants.WAIT_TIMEOUT_60)) {
                connexusAppUtils.writeTextToFile("RX is in 4 point "+rxNbr,"In progress",fileName,40, DateTime.now());
            } else {
                connexusAppUtils.writeTextToFile("RX is not in 4 point "+rxNbr,"In progress",fileName,40, DateTime.now());
                Reporter.log("RX is not in 4 Point, Performing Resolve Queue");
                performResolveQueue(name[0] + "," + name[1]);
            }

            if(checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(),ConnexusConstants.WAIT_TIMEOUT_60)) {
                rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1], inputData, true);
                connexusAppUtils.writeTextToFile("4 point Completed " + rxNbr, "In progress", fileName, 40, DateTime.now());
            }
            else {
                connexusAppUtils.writeTextToFile("4 point not Completed "+rxNbr,"Failed",fileName,40, DateTime.now());
                Assert.fail("Rx failed to reach 4 point");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("4 point not Completed "+rxNbr,"Failed",fileName,40, DateTime.now());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to complete 4point check");
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }


    public void validateChkDURForCounselRequired(Map<String, String> inputData) {
        validateChkDURForCounselRequired(inputData,false);
    }

    /* Method to complete check dur once it is launched .
     * Reason for custom method : This method is required because existing methods will launch chkDUR and complete it ,
     * meanwhile as per our requirement we need to perform validations for counsel details once chkDUR has launched
     * Author: Prashant */
    public void validateChkDURForCounselRequired(Map<String, String> inputData,boolean counselReasonRequired) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            performResolveQueue(rxNbr);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr, inputData, true, counselReasonRequired);
                connexusAppUtils.writeTextToFile("Completed ChkDUR " + rxNbr, "In progress", fileName, 50, DateTime.now());
            } else if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue())) {
                Reporter.log("ChkDUR skipped and moved to Filling Queue");
            } else {
                connexusAppUtils.writeTextToFile("ChkDUR not Completed" + rxNbr, "Failed", fileName, 50, DateTime.now());
                Assert.fail("Rx failed to reach chkDUR queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            AutomationManager.getInstance().getConnexus().closeConnexus();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /* Method to complete visual verify for counsel required NTD
     * Author: Prashant */
    public void validateVVForCounselRequired(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.VisualVerify.getValue())) {
                automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr,inputData);
            } else {
                performResolveQueue(rxNbr);
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.VisualVerify.getValue())) {
                    automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr,inputData);
                } else {
                    Reporter.log("RX is not in Visual Verify queue");
                    takeScreenShotRXStatus(rxNbr,null,currentStepMethodName + ", review the Work Queue status",Status.FAIL);
                    Assert.fail("RX is not in Visual Verify queue");
                }
            }

            connexusAppUtils.writeTextToFile("Visual Verification Completed "+rxNbr,"In progress",fileName,70, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Visual Verification Not Completed "+rxNbr,"Failed",fileName,70, DateTime.now());
            Reporter.log("Test failed at Visual Verify queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            AutomationManager.getInstance().getConnexus().closeConnexus();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /* Method to complete pickup while validating for counsel checks in pickup
     * Updated: Prashant */
    @Override
    public void performPickUp(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Pickup.getValue())) {
                automationManager.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("DOB"), rxNbr , true);
            } else {
                performResolveQueue(rxNbr);
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Pickup.getValue())) {
                    automationManager.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("DOB"), rxNbr , true);
                }else {
                    Reporter.log("RX is not in PickUp queue");
                    takeScreenShotRXStatus(rxNbr,null,currentStepMethodName + ", review the Work Queue status",Status.FAIL);
                    Assert.fail("RX is not in PickUp queue");
                }
            }
            connexusAppUtils.writeTextToFile("Pickup Completed "+rxNbr,"In progress",fileName,80, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Pickup not Completed "+rxNbr,"Failed",fileName,80, DateTime.now());
            Reporter.log("Test failed at PickUp queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            AutomationManager.getInstance().getConnexus().closeConnexus();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /* Method to complete counselling while validating for counsel checks in counsel queue
     * Author: Prashant */
    public void validateCounselRequiredInCounsel(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.Counseling.getValue(),ConnexusConstants.WAIT_TIMEOUT_20)) {
                automationManager.getConnexusWorkFlow().completeCounsel(rxNbr,inputData,true);
            } else {
                if(performResolveQueue(rxNbr)) {
                    if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Counseling.getValue())) {
                        automationManager.getConnexusWorkFlow().completeCounsel(rxNbr,inputData,true);
                    } else {
                        Reporter.log("Moving RX from Resolve to Counsel queue failed");
                        takeScreenShotRXStatus(rxNbr,null,currentStepMethodName,Status.FAIL);
                        Assert.fail("Moving RX from Resolve to Counsel queue failed");
                    }
                }else{
                    if (checkOrderNextWorkQueueDB(rxNbr).equals(WorkQueueSettings.Pickup.getValue())){
                        Reporter.log("RX is still in Pickup queue");
                    } else {
                        Reporter.log("RX is not in Counselling or Resolve queue");
                    }
                    takeScreenShotRXStatus(rxNbr,null,currentStepMethodName + ", review the Work Queue status",Status.FAIL);
                    Assert.fail("RX is not in Counselling queue");
                }
            }
            connexusAppUtils.writeTextToFile("Counselling Completed "+rxNbr,"In progress",fileName,90, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Counselling Not Completed "+rxNbr,"Failed",fileName,90, DateTime.now());
            Reporter.log("Test failed at Counselling queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            AutomationManager.getInstance().getConnexus().closeConnexus();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void chkdurCmtsValidations(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())){
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                if (chkDur.clickRedFlagsBtn()) {
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }
                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectAllCheckBoxes();
                }
                Reporter.logScreenShot(Status.INFO, "Screenshot of ChkDUR Page", chkDur.takeScreenShot("ChkDUR").getValue());
                //Validating comments present in chkdur screen
                List<String> chkDurMessages = chkDur.getDurMessagesText();
                this.chkDurMessages = chkDurMessages;
                Reporter.log("Captured DUR Conflict Descriptions:\n" + String.join("\n⬤ ", chkDurMessages).replaceFirst("^", "⬤"));
                chkDur.clickAccept();
                chkDur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            } else {
                Reporter.log("rx is not in Dur queue");
                Assert.fail("rx is not in Dur queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed without validating chkdur messages");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, counselPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /* Method to validate chkdur comments present in counsel
     ** Author: Snehaa */
    public void validatingChkdurCmtsInCounsel(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.Counseling.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                List<String> CounselDurMsg = counselPage.getCounselDurMsg();
                // Validate DUR messages between ChkDUR and Counsel screen
                for (String durMessage : chkDurMessages) {
                    boolean messageFound = CounselDurMsg.stream()
                            .anyMatch(counselMsg -> counselMsg.equalsIgnoreCase(durMessage));
                    if (messageFound) {
                        Reporter.log("DUR comment validated successfully: " + durMessage);
                    } else {
                        Reporter.log("DUR comment not found: " + durMessage);
                        softAssert.fail("DUR comment not found: " + durMessage);
                    }
                }
            } else {
                Reporter.log("RX is not in Counselling or Resolve queue");
            }

        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Counselling validation Not Completed "+rxNbr,"Failed",fileName,90, DateTime.now());
            Reporter.log("Test failed at Counselling queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, counselPage.takeScreenShot(currentStepMethodName).getValue());
            AutomationManager.getInstance().getConnexus().closeConnexus();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void CompleteCounselWithRefuseBtn() {
        if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Counseling.getValue())) {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            counselPage.refuseBtn();
            Reporter.logScreenShot(Status.INFO, "Screenshot of Counsel Page", chkDur.takeScreenShot("Counsel").getValue());
            Reporter.log("Clicked Refuse Button in counsel page");
            counselPage.clickAccept();
        } else {
            Reporter.log("RX is not in Counselling or Resolve queue");
        }
    }

    /* Method to add Rx notes
     * Author: Snehaa */
    public void addingRxNotes(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                menuBar.navigateToMenu(AppMenu.RX_NOTES);
                chkDur.enterNotes(inputData.get("NOTES_MSG"));
                chkDur.clickSaveAndClose();
                menuBar.navigateToMenu(AppMenu.RX_NOTES);
                String expectedNotesMsg = inputData.get("NOTES_MSG").replaceAll("\\s+", " ").trim();
                String actualNotesMsg = chkDur.isRxMessageDisplayed().replaceAll("\\s+", " ").trim();
                Assert.assertEquals(actualNotesMsg, expectedNotesMsg, "Counsel note message mismatch");
                Reporter.logScreenShot(Status.PASS, "Rx notes", counselPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Rx notes added");
                Reporter.log("Added Rx note: Expected = \"" + expectedNotesMsg + "\", Actual = \"" + actualNotesMsg + "\"");
                chkDur.exitFromDur();
            } else {
                Reporter.log("RX is not in CheckDUR Queue");
                takeScreenShotRXStatus(rxNbr, null, currentStepMethodName, Status.FAIL);
                Assert.fail("RX is not in CheckDUR Queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed while adding noted");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, chkDur.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /* Method to add Counselling notes
     * Author: Snehaa */
    public void addingCounsellingNotes(Map<String, String> inputData){
        String currentStepMethodName = "Adding Counsel Notes";
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                chkDur.clickCounsellingNotes();
                chkDur.enterNotes(inputData.get("NOTES_MSG"));
                chkDur.clickSaveAndClose();
                chkDur.clickCounsellingNotes();
                String expectedNotesMsg = inputData.get("NOTES_MSG").replaceAll("\\s+", " ").trim();
                String actualNotesMsg = counselPage.getCounselText().replaceAll("\\s+", " ").trim();
                Assert.assertEquals(actualNotesMsg, expectedNotesMsg, "Counsel note message mismatch");
                Reporter.logScreenShot(Status.PASS, "Counselling notes", counselPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Counsel Notes added");
                Reporter.log("Added counsel note: Expected = \"" + expectedNotesMsg + "\", Actual = \"" + actualNotesMsg + "\"");
                chkDur.exitFromDur();
            } else {
                Reporter.log("Adding Counsel notes failed");
                takeScreenShotRXStatus(rxNbr, null, currentStepMethodName, Status.FAIL);
                Assert.fail("Adding notes failed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed while adding noted");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, chkDur.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validatingCounselNotes(Map<String, String> inputData){
        String currentStepMethodName = "validating Counsel Notes";
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Counseling.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                counselPage.acceptAll();
                counselPage.clickAccept();
                Assert.assertTrue(counselPage.isCounselPopUpDisplayed(),"pop up not displayed");
                Reporter.logScreenShot(Status.PASS, "Counsel error pop up ", counselPage.takeScreenShot(currentStepMethodName).getValue());
                counselPage.clickOk();
                counselPage.clickCounselNotes();
                String expectedNotesMsg = inputData.get("NOTES_MSG").replaceAll("\\s+", " ").trim();
                String actualNotesMsg = counselPage.getCounselText().replaceAll("\\s+", " ").trim();
                Assert.assertEquals(actualNotesMsg, expectedNotesMsg, "Counsel note message mismatch");
                Reporter.logScreenShot(Status.PASS, "Opened Counsel Notes", counselPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Added counsel note: Expected = \"" + expectedNotesMsg + "\", Actual = \"" + actualNotesMsg + "\"");
                counselPage.exitBtn();
                counselPage.clickAccept();
                Reporter.log("Able to complete counsel after clicking counsel notes");
                Reporter.log("counsel is completed");

            } else {
                Reporter.log("validating popup in counsel fails");
                takeScreenShotRXStatus(rxNbr, null, currentStepMethodName, Status.FAIL);
                Assert.fail("Adding notes failed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed without validating popup in counsel");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /* Method to validate icons present in counsel page
     * Author: Snehaa */
    public void counselIconsValidation(Map<String, String> inputData){
        String currentStepMethodName = "Counsel Icons Validation";
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Counseling.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                counselPage.clickPillImage();
                // Validate the presence of icons and buttons in counsel page
                Assert.assertTrue(counselPage.maxBtn(), "Max button is not displayed");
                Assert.assertTrue(counselPage.rotateBtn(),"Rotate button not displayed");
                Assert.assertTrue(counselPage.zoomIn(),"Zoom in button not displayed");
                Assert.assertTrue(counselPage.zoomOut(),"Zoom out button not displayed");
                Reporter.log("Max,Rotate,Zoom in and Zoom out button displayed while clicking Pill Image Button");
                Reporter.logScreenShot(Status.PASS, "Pill Image Button", counselPage.takeScreenShot(currentStepMethodName).getValue());
                counselPage.closeButton();
                counselPage.rxImageButton();
                Assert.assertTrue(counselPage.maxBtn(), "Max button is not displayed");
                Assert.assertTrue(counselPage.rotateBtn(),"Rotate button not displayed");
                Assert.assertTrue(counselPage.zoomIn(),"Zoom in button not displayed");
                Assert.assertTrue(counselPage.zoomOut(),"Zoom out button not displayed");
                Assert.assertTrue(counselPage.printImage(),"Print image button not displayed");
                Reporter.log("Max,Rotate,Zoom-in,Zoom-out and Print Image button displayed while clicking Rx Image Button");
                Reporter.logScreenShot(Status.PASS, "Rx Image Button", counselPage.takeScreenShot(currentStepMethodName).getValue());
                counselPage.closeButton();
                counselPage.ClickRxFillHistory();
                String query = "select max(rx_fill_id) as rx_fill_id from rx_order_detail where rx_id=" +
                        "(select rx_id from rx where rx_nbr=\"" + rxNbr + "\") and next_work_que_code ='3'";
                Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
                String expectedFillId = rxInfo.get("rx_fill_id").toString();
                Reporter.log("Expected Fill ID retrieved from DB: " + expectedFillId);
                String actualFillId = counselPage.getDisplayedFillId();
                Assert.assertEquals(actualFillId, expectedFillId, "Displayed Fill ID in Fill History row does not match expected value");
                Reporter.log("Validated Fill History Fill ID: Expected = " + expectedFillId + ", Displayed = " + actualFillId);
                Reporter.logScreenShot(Status.PASS, "RX Fill History Button", counselPage.takeScreenShot(currentStepMethodName).getValue());
                counselPage.exitBtn();
                //Validating web page opens and comes back to application
                counselPage.clickDrugRef();
                Reporter.log("Clicked Drug reference button");
                Assert.assertTrue(counselPage.isBrowserOpened(), "browser window was not detected");
                Reporter.logScreenShot(Status.PASS, "Browser Opened", counselPage.takeScreenShot("DrugReferencePage").getValue());
                Assert.assertTrue(counselPage.returnFromDrugReference(), "Failed to return to Connexus window");
                Assert.assertTrue(counselPage.drugbtn(), "Did not return to Counsel page successfully");
                counselPage.clickCounselQue();
                Assert.assertTrue(counselPage.counselRow(),"Counsel queue not displayed");
                Reporter.log("Rx in counsel Queue displayed");
                Reporter.logScreenShot(Status.PASS, "Counsel Queue", counselPage.takeScreenShot(currentStepMethodName).getValue());
                counselPage.crossButton();
                //Validating counselNotes
                counselPage.clickCounselNotes();
                counselPage.counselNotesText(inputData.get("NOTES_MSG"));
                counselPage.clickCounselNotes();
                String expectedNotesMsg = inputData.get("NOTES_MSG").replaceAll("\\s+", " ").trim();
                String actualNotesMsg = counselPage.getCounselText().replaceAll("\\s+", " ").trim();
                Assert.assertEquals(actualNotesMsg, expectedNotesMsg, "Counsel note message mismatch");
                Assert.assertTrue(counselPage.counselMessage(),"Counsel notes not displayed");
                Reporter.log("Counsel notes message displayed");
                Reporter.log("Validated counsel note: Expected = \"" + expectedNotesMsg + "\", Actual = \"" + actualNotesMsg + "\"");
                Reporter.logScreenShot(Status.PASS, "CounselNotes message", counselPage.takeScreenShot(currentStepMethodName).getValue());
                counselPage.exitBtn();
                counselPage.acceptAll();
                counselPage.clickAccept();
            } else {
                Reporter.log("Moving RX from Resolve to Counsel queue failed");
                takeScreenShotRXStatus(rxNbr, null, currentStepMethodName, Status.FAIL);
                Assert.fail("Moving RX from Resolve to Counsel queue failed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed while verifying Counselling");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, counselPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
}