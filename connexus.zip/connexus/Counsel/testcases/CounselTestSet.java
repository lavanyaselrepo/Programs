package connexus.Counsel.testcases;

import connexus.Counsel.testscripts.CounselTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;

import org.json.simple.parser.ParseException;

import java.util.Map;

public class CounselTestSet {

    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    CounselTestScripts counselTestScript = new CounselTestScripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    PropertyReader prop = PropertyReader.getInstance();
    String siteId = prop.getProperty("cnx.store");
    boolean flagUpdated = false;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Update flags for Counsel suppression, dosage trigger, and refill start date
     * Author: Johnvinothkumar (vn58my9)
     */
    public void updateFlags() {
        flagUpdated = connexusAppUtils.readAndUpdateFlag("24500", "TRUE"); // Flag to enable counsel suppression
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("24510", "TRUE"); // Flag to enable counsel dosage trigger
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("32764", "12-31-2099"); // Flag to enable counsel refill start date
    }

    @Test(enabled = true, description = "Counsel | Counsel required for 2nd fill for NTI products - New Rx", priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Counsel/Counsel.json", sheetName = "Counsel")
    public void HWPHME2E_4479(Map<String, String> inputData) {

        Reporter.log("<<<Validate counsel required for 2nd fill for NTI products - New Rx>>>");
        // Pre-checks
        Reporter.log("Logged in store:" + siteId);
        updateFlags(); //update flags for counsel suppression, dosage trigger, and refill start date
        counselTestScript.initializeTestCase(flagUpdated);
        // Counsel validation steps for New RX validation
        counselTestScript.createNewPatient(inputData);
        counselTestScript.performDropOff(Priority.Critical);
        counselTestScript.performInput(inputData);
        counselTestScript.validate4pointForCounselRequired(inputData);
        counselTestScript.validateChkDURForCounselRequired(inputData);
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        counselTestScript.verifyRxInEOD();
        // 2nd New RXFor Same Patient
        counselTestScript.performDropOff(Priority.Critical);
        counselTestScript.performInput(inputData);
        counselTestScript.validate4pointForCounselRequired(inputData);
        counselTestScript.validateChkDURForCounselRequired(inputData);
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        counselTestScript.verifyRxInEOD();

        Reporter.log("<<<Validated counsel required for 2nd rx for NTI products - New Rx>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description:Counsel screen validations - DURs display, Modify Details, Refuse Counsel.
* Author: Snehaa(vn57hhm)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-2382")
    @Test(description = "Counsel screen validations - DURs display, Modify Details, Refuse Counsel.",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Counsel/Counsel.json", sheetName = "Counsels")
    public void HWPHME2E_2382(Map<String, String> inputData) {
        Reporter.log(">>>validating  DURs display, Modify Details, Refuse Counsel in Counsel page<<<");
        connexusAppUtils.getStoreId();
        counselTestScript.initializeTestCase(false);
        //Create patient and move till checkdur
        counselTestScript.createNewPatient(inputData);
        counselTestScript.performDropOff(Priority.Critical);
        counselTestScript.performInput(inputData);
        counselTestScript.perform4Point(Boolean.parseBoolean(inputData.get("VALUE")));
        //Check comments in present in chkdur
        counselTestScript.chkdurCmtsValidations();
        //Moving till counsel queue
        counselTestScript.performFilling();
        counselTestScript.performVisualVerify();
        counselTestScript.performPickUp(inputData);
        //Validating the comments present in chkdur is present in Counsel as well
        counselTestScript.validatingChkdurCmtsInCounsel();
        counselTestScript.CompleteCounselWithRefuseBtn();
        counselTestScript.performPOS();
    }

    @Test(enabled = true, description = "Counsel required for 2nd fill for NTI products - Refill Rx", priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Counsel/Counsel.json", sheetName = "Counsel")
    public void HWPHME2E_4482_counsel_required_for_2nd_fill_for_NTI_products_Refill_Rx(Map<String, String> inputData) {
        Reporter.log("Validate counsel required for 2nd fill for NTI products - Refill Rx");
        // Pre-checks
        Reporter.log("Logged in store:" + siteId);
        updateFlags(); // Update flags for counsel suppression, dosage trigger, and refill start date
        // Restart Connexus service to apply updated flags
        counselTestScript.initializeTestCase(flagUpdated);
        // Counsel validation steps
        // New RX validation
        counselTestScript.createNewPatient(inputData);
        counselTestScript.performDropOff(Priority.Critical);
        counselTestScript.performInput(inputData);
        counselTestScript.validate4pointForCounselRequired(inputData);
        counselTestScript.validateChkDURForCounselRequired(inputData);
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        counselTestScript.verifyRxInEOD();
        // 2nd-Refill RX
        counselTestScript.performDropOffForRXWithRefills();
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        counselTestScript.verifyRxInEOD();
        Reporter.log("Validated counsel required for 2nd fill for NTI products - Refill Rx");
    }

    @Test(enabled = true, description = "Counsel required for 2nd fill for Red DUR - Refill Rx", priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Counsel/Counsel.json", sheetName = "Counsel")
    public void HWPHME2E_4483_counsel_required_for_2nd_fill_for_Red_DUR_Refill_Rx(Map<String, String> inputData) {
        Reporter.log("Validate counsel required for 2nd fill for Red DUR - Refill Rx");
        // Pre-checks
        Reporter.log("Logged in store:" + siteId);
        updateFlags(); //update flags for counsel suppression, dosage trigger, and refill start date
        counselTestScript.initializeTestCase(flagUpdated);
        // Counsel validation steps
        // New RX validation
        counselTestScript.createNewPatient(inputData);
        counselTestScript.addAllergyToPatientProfile(inputData);
        counselTestScript.performDropOff(Priority.Critical);
        counselTestScript.performInput(inputData);
        counselTestScript.validate4pointForCounselRequired(inputData);
        counselTestScript.validateChkDURForCounselRequired(inputData, true);
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        counselTestScript.verifyRxInEOD();
        // 2nd-Refill RX
        counselTestScript.performDropOffForRXWithRefills();
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        counselTestScript.verifyRxInEOD();
        Reporter.log("Validated counsel required for 2nd fill for Red DUR - Refill Rx");
    }

    @Test(enabled = true, description = "Counsel required for 2nd fill for Orange DUR - Refill Rx", priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Counsel/Counsel.json", sheetName = "Counsel")
    public void HWPHME2E_4484_counsel_required_for_2nd_fill_for_Orange_DUR_Refill_Rx(Map<String, String> inputData) {
        Reporter.log("Validate counsel required for 2nd fill for Orange DUR - Refill Rx");
        // Pre-checks
        Reporter.log("Logged in store:" + siteId);
        // C2 drug requires prescriber address be same as pharmacy city
        updateFlags(); // Update flags for counsel suppression, dosage trigger, and refill start date
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState("AR");
        counselTestScript.initializeTestCase(flagUpdated);
        // Counsel validation steps
        // New RX validation
        counselTestScript.createNewPatient(inputData);
        counselTestScript.performDropOff(Priority.Critical);
        counselTestScript.performInput(inputData);
        counselTestScript.validate4pointForCounselRequired(inputData);
        counselTestScript.validateChkDURForCounselRequired(inputData);
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        counselTestScript.verifyRxInEOD();
        // 2nd-Refill RX
        counselTestScript.performDropOffForRXWithRefills();
        counselTestScript.validateChkDURForCounselRequired(inputData);
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        counselTestScript.verifyRxInEOD();
        Reporter.log("Validated counsel required for 2nd fill for Orange DUR - Refill Rx");
    }

    @Test(enabled = true, description = "Counsel required for 2nd fill for Red DUR - New Rx", priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Counsel/Counsel.json", sheetName = "Counsel")
    public void HWPHME2E_4480_counsel_required_for_2nd_fill_for_Red_DUR_New_Rx(Map<String, String> inputData) {
        Reporter.log("Validate counsel required for 2nd fill for Red DUR - New Rx");
        // Pre-checks
        Reporter.log("Logged in store:" + siteId);
        updateFlags(); //update flags for counsel suppression, dosage trigger, and refill start date
        counselTestScript.initializeTestCase(flagUpdated);
        // Counsel validation steps
        // New RX validation
        counselTestScript.createNewPatient(inputData);
        counselTestScript.addAllergyToPatientProfile(inputData);
        counselTestScript.performDropOff(Priority.Critical);
        counselTestScript.performInput(inputData);
        counselTestScript.validate4pointForCounselRequired(inputData);
        counselTestScript.validateChkDURForCounselRequired(inputData, true);
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        counselTestScript.verifyRxInEOD();
        // 2nd-New RX
        counselTestScript.performDropOff(Priority.Critical);
        counselTestScript.performInput(inputData);
        counselTestScript.validate4pointForCounselRequired(inputData);
        counselTestScript.validateChkDURForCounselRequired(inputData, true);
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        counselTestScript.verifyRxInEOD();
        Reporter.log("Validated counsel required for 2nd fill for Red DUR - New Rx");
    }

    @Test(enabled = true, description = "Counsel required for 2nd fill for Orange DUR - New Rx", priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Counsel/Counsel.json", sheetName = "Counsel")
    public void HWPHME2E_4481_counsel_required_for_2nd_fill_for_Orange_DUR_New_Rx(Map<String, String> inputData) {
        Reporter.log("Validate counsel required for 2nd fill for Orange DUR - New Rx");
        // Pre-checks
        Reporter.log("Logged in store:" + siteId);
        // C2 drug requires prescriber address be same as pharmacy city
        updateFlags(); // Update flags for counsel suppression, dosage trigger, and refill start date
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        counselTestScript.initializeTestCase(flagUpdated);
        // Counsel validation steps
        // New RX validation
        counselTestScript.createNewPatient(inputData);
        counselTestScript.performDropOff(Priority.Critical);
        counselTestScript.performInput(inputData);
        counselTestScript.validate4pointForCounselRequired(inputData);
        counselTestScript.validateChkDURForCounselRequired(inputData);
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        counselTestScript.verifyRxInEOD();
        // 2nd-New RX
        counselTestScript.performDropOff(Priority.Critical);
        counselTestScript.performInput(inputData);
        counselTestScript.validate4pointForCounselRequired(inputData);
        counselTestScript.validateChkDURForCounselRequired(inputData);
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        counselTestScript.verifyRxInEOD();
        Reporter.log("Validated counsel required for 2nd fill for Orange DUR - New Rx");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description:Counsel Activity - New Therapy
* Author: Snehaa(vn57hhm)
----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-4665")
    @Test(description = "Counsel Activity - New Therapy.",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Counsel/Counsel.json", sheetName = "Counsels")
    public void HWPHME2E_4665_Counsel_Activity_New_Therapy(Map<String, String> inputData) {
        Reporter.log(">>>validating  Counsel Activity - New Therapy<<<");
        connexusAppUtils.getStoreId();
        counselTestScript.initializeTestCase(false);
        //Create patient and move till checkdur
        counselTestScript.createNewPatient(inputData);
        counselTestScript.performDropOff(Priority.Critical);
        counselTestScript.performInput(inputData);
        counselTestScript.validate4pointForCounselRequired(inputData);
        counselTestScript.validateChkDURForCounselRequired(inputData);
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        counselTestScript.verifyRxInEOD();
        Reporter.log(">>>validated  Counsel Activity - New Therapy<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
 * Test Description:Counseling note blocks refuse/accept until viewed
 * Author: Snehaa(vn57hhm)
 ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-2386")
    @Test(description = "Counseling note blocks refuse/accept until viewed",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Counsel/Counsel.json", sheetName = "Counsels")
    public void HWPHME2E_2386_Counsel_notes_blocks_refuse_accept_until_viewed(Map<String, String> inputData) {

        Reporter.log(">>>Validating Counseling note blocks refuse/accept until viewed<<<");
        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateFlag("26218", "TRUE");
        Reporter.log("Updated parm value for 26218 as TRUE");
        counselTestScript.initializeTestCase(flagUpdated);
        //Creates New patient and move till Four point
        counselTestScript.createNewPatient(inputData);
        counselTestScript.performDropOff(Priority.Critical);
        counselTestScript.performInput(inputData);
        counselTestScript.perform4Point(Boolean.parseBoolean(inputData.get("VALUE")));
        //Adding Rx notes and Counselling Notes
        counselTestScript.addingRxNotes(inputData);
        counselTestScript.addingCounsellingNotes(inputData);
        //From checkdur to counsel
        counselTestScript.performChkDUR();
        counselTestScript.performFilling();
        counselTestScript.performVisualVerify();
        counselTestScript.performPickUp(inputData);
        //Validating Rx cant be moved to next que without handling Counselling notes
        counselTestScript.validatingCounselNotes(inputData);
        counselTestScript.performPOS();
        Reporter.log(">>>Successfully validated Counseling note blocks refuse/accept until viewed<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Counsel Screen validations - Accept, Rx Image, Rx Fill History, Counsel Queue etc. buttons
    * Author: Snehaa(vn57hhm)
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-2383")
    @Test(description = "Counsel Screen validations - Accept, Rx Image, Rx Fill History, Counsel Queue etc. buttons",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Counsel/Counsel.json", sheetName = "Counsels")
    public void HWPHME2E_2383_Counsel_Screen_Validations(Map<String, String> inputData) {
        Reporter.log(">>>Counsel Screen validating - Accept, Rx Image, Rx Fill History, Counsel Queue etc. buttons<<<");
        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateFlag("26218", "TRUE");
        counselTestScript.initializeTestCase(flagUpdated);
        //Creates New patient and move till Counsel
        counselTestScript.createNewPatient(inputData);
        counselTestScript.performDropOff(Priority.Critical);
        counselTestScript.performInput(inputData);
        counselTestScript.perform4Point(Boolean.parseBoolean(inputData.get("VALUE")));
        counselTestScript.performChkDUR();
        counselTestScript.performFilling();
        counselTestScript.performVisualVerify();
        counselTestScript.performPickUp(inputData);
        //Validations of icons in counsel page
        counselTestScript.counselIconsValidation(inputData);
        counselTestScript.performPOS();

        Reporter.log(">>>Counsel Screen validated - Accept, Rx Image, Rx Fill History, Counsel Queue etc. buttons<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Tennessee-All Rx require counseling
    * Author: Niraj(vn50sfl)
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-2387")
    @Test(description = "Tennessee-All Rx require counseling",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Counsel/Counsel.json", sheetName = "Counsel")
    public void HWPHME2E_2387_All_TennesseeRx_Requires_Counseling(Map<String, String> inputData) throws IOException, ParseException {
        Reporter.log(">>>Verify Tennessee-All Rx require counseling<<<");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE"));
        String stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        counselTestScript.initializeTestCase(flagUpdated);
        counselTestScript.createNewPatient(inputData);
        int patientId = counselTestScript.getPatientId();
        counselTestScript.rxNbr = connexusAPIManager.createOrderAndMoveTo4Pt(patientId, Integer.parseInt(siteId), Integer.parseInt(inputData.get("REFILLS")), inputData.get("DRUG_NAME")).get(0);
        counselTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        counselTestScript.validateChkDURForCounselRequired(inputData);
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        // 2nd New RXFor Same Patient
        counselTestScript.rxNbr = connexusAPIManager.createOrderAndMoveTo4Pt(patientId, Integer.parseInt(siteId), Integer.parseInt(inputData.get("REFILLS")), inputData.get("DRUG_NAME")).get(0);
        inputData.put("COUNSEL_REASON", inputData.get("COUNSEL_REASON_1"));
        counselTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        counselTestScript.validateChkDURForCounselRequired(inputData);
        counselTestScript.performFilling();
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        // 3rd scenario, refill for 2nd Rx
        counselTestScript.performDropOffForRXWithRefills();
        counselTestScript.performFilling();
        inputData.put("COUNSEL_REASON", inputData.get("COUNSEL_REASON_2"));
        counselTestScript.validateVVForCounselRequired(inputData);
        counselTestScript.performPickUp(inputData);
        counselTestScript.validateCounselRequiredInCounsel(inputData);
        counselTestScript.performPOS();
        Reporter.log(">>>Verified Tennessee-All Rx requires counseling<<<");
    }
}