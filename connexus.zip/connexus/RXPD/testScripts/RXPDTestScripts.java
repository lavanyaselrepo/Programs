package connexus.RXPD.testScripts;

import centralfilltests.CFDBModels.drugSub.Response;
import com.aventstack.extentreports.Status;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonElement;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.CreatePatientRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.InsuranceDetails;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.connexus.DropRxModel;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.rxonemobileapp.rxpd.api.pojos.PurchaseOrder;
import hwqe.baseframework.utilities.DateUtils;
import hwqe.baseframework.models.pageobjectmodels.rxonemobileapp.rxpd.api.pojos.PoLine;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import hwqe.baseframework.utilities.StringUtils;
import hwqe.baseframework.utilities.StringUtils;
import io.strati.libs.joda.time.DateTime;
import org.testng.Assert;
import rxpd.fulfillment.RxOne.RxPDAPIWrapper;
import rxpd.fulfillment.chainOfCustodyComplete.wrapper.ChainOfCustodyCompleteWrapper;
import rxpd.fulfillment.dispenseOrderCreate.wrapper.DispenseOrderCreateAPIWrapper;
import rxpd.fulfillment.printLabel.wrapper.PrintLabelAPIWrapper;
import rxpd.fulfillment.stagingIssues.wrapper.StagingIssuesAPIWrapper;

import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;

import rxpd.posttransaction.dpsisservices.deliveryapi.DeliveryApiWrapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import static hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager.scanPickUpCodeForCF;
import static hwqe.baseframework.models.pageobjectmodels.rxonemobileapp.RxOneDriverManager.prop;
import org.openjdk.tools.sjavac.Log;


import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class RXPDTestScripts extends ConnexusTestScripts {

    private static String poNumber;
    private static String storeNbr;
    private static String omsOrderId;
    private static int rxFillId;
    private static int patientId;
    private static String packageToteId;
    private static ServiceResponse response = new ServiceResponse();
    private static final DBUtils dbUtils = new DBUtils();
    private static final AutomationManager automationManager = AutomationManager.getInstance();
    static RxPDAPIWrapper rxpdApiWrapper = new RxPDAPIWrapper();
    private static final DispenseOrderCreateAPIWrapper dispenseOrderCreateAPIWrapper = new DispenseOrderCreateAPIWrapper();
    private static final StagingIssuesAPIWrapper stagingIssuesAPIWrapper = new StagingIssuesAPIWrapper();
    private static String schedDate;
    private static String slotStart;
    private static String slotEnd;
    private static int stagingBagNumber;
    private static int bagNumber;
    private static Map<String, Object> presentDispenseTrackingDetails;
    DropRxModel dropRxModel = new DropRxModel();
    ConnexusAPIManager connexusAPIManager= new ConnexusAPIManager();
    private static final DeliveryApiWrapper deliveryApiWrapper = new DeliveryApiWrapper();
    ObjectMapper mapper = new ObjectMapper();
    Map<String, String> poAndOMSId = new HashMap<>();
    private static List<String> rxNum=new ArrayList<>();
    private static Map<String,Map<String,Object>> dispenseOrderDetails = new HashMap<>();
    public static String fillDate;

    public RXPDTestScripts(LoginAs.userType loginUserType) {
        super(loginUserType);
    }

    public void dropAnRxTillPickUp(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        performDropOff(Priority.Critical);
        performInput(inputData);
        perform4Point(false,false);
        performChkDUR();
        performFilling();
        performVisualVerify();
    }

//    public void createOrderTillPickup()
    /*
     * This method will create a dispense order using the DispenseOrderCreate API
     * It generates a unique OMS Order ID and PO number, fetches the latest rxFill
     * Id from the database, and makes the API call to create the dispense order.
     * After successful creation, it initiates and completes the staging process.
     * Author: Prashant */
    public void dispenseOrderCreation(Map<String, String> inputData) {
        try {
            storeNbr = String.valueOf(connexusAppUtils.getStoreId());
            Map<String,Object> orderDetails = new HashMap<>();

            // Generate dynamic OMS Order ID (unique) and PO
            omsOrderId = "RX1" + System.currentTimeMillis();
            Reporter.log("Generated OMS Order ID: " + omsOrderId);

            poNumber = "P0" + omsOrderId.substring(3);
            Reporter.log("Generated PO Number: " + poNumber);

            // Generate dynamic current date (in the format YYYY-MM-DD) using framework utility
            if (schedDate == null || schedDate.isBlank()) {
                schedDate = DateUtils.currentDate("yyyy-MM-dd");
            }

            Reporter.log("Schedule Date: " + schedDate);

            slotStart = inputData.get("slotStart");
            slotEnd = inputData.get("slotEnd");
            Assert.assertNotNull(slotStart, "Missing required input: slotStart");
            Assert.assertFalse(slotStart.trim().isEmpty(), "Invalid input: slotStart is empty");
            Assert.assertNotNull(slotEnd, "Missing required input: slotEnd");
            Assert.assertFalse(slotEnd.trim().isEmpty(), "Invalid input: slotEnd is empty");
            // Ensure time format is zero-padded (e.g., "2:00:00" -> "02:00:00")
            slotStart = formatTimeWithZeroPadding(slotStart);
            slotEnd = formatTimeWithZeroPadding(slotEnd);
            Reporter.log("Slot Start: " + slotStart);
            Reporter.log("Slot End: " + slotEnd);

            // Fetch latest rxFillId using existing framework utility instead of inline SQL
            rxFillId = connexusAppUtils.getFillId(rxNbr);
            Assert.assertTrue(rxFillId > 0, "Unable to fetch rxFillId from DB for rxNbr " + rxNbr);
            Reporter.log("rxFillId is " + rxFillId);

            // Create dispense order
            Reporter.log("Creating Dispense Order for store " + storeNbr + ", rxFillId=" + rxFillId);
            response = dispenseOrderCreateAPIWrapper.DispenseOrderCreate(storeNbr, omsOrderId, poNumber, schedDate, slotStart, slotEnd, 1, rxFillId, "None" );
            orderDetails.put("apiResponse", response);

            Assert.assertNotNull(response, "Dispense Order Creation failed: response was null");
            Assert.assertEquals(response.getStatusCode(), 200, "Dispense Order Creation failed");

            ObjectMapper mapper = new ObjectMapper();
            String json = mapper.writeValueAsString(response);
            Reporter.log("DispenseOrderCreate response: " + json);
            orderDetails.put("omsOrderId", omsOrderId);
            orderDetails.put("poNumber", poNumber);
            orderDetails.put("schedDate", schedDate);
            orderDetails.put("rxFillId", String.valueOf(rxFillId));
            orderDetails.put("apiResponse", response);
            dispenseOrderDetails.put(rxNbr, orderDetails);
        } catch (Exception ex) {
            Assert.fail("Error in dispenseOrderCreation: " + ex.getMessage());
        }
    }

    public void dispenseOrderCreation(Map<String, String> inputData, String transType, boolean deliveryIssue) {
        dispenseOrderCreation(inputData,transType,deliveryIssue,false);
    }

    public void dispenseOrderCreation(Map<String, String> inputData, String transType, boolean deliveryIssue,boolean isPastDate) {
        try {
            storeNbr = String.valueOf(connexusAppUtils.getStoreId());
            Map<String,Object> orderDetails = new HashMap<>();
            // Generate dynamic OMS Order ID (unique) and PO
            omsOrderId = "RX1" + System.currentTimeMillis();
            Reporter.log("Generated OMS Order ID: " + omsOrderId);
            poNumber = "P0" + omsOrderId.substring(3);
            Reporter.log("Generated PO Number: " + poNumber);
            // Generate dynamic current date (in the format YYYY-MM-DD) using framework utility
            if(isPastDate) {
                schedDate = fillDate;
            }else{
                schedDate = DateUtils.currentDate("yyyy-MM-dd");
            }
            Reporter.log("Schedule Date: " + schedDate);
            slotStart = inputData.get("slotStart");
            slotEnd = inputData.get("slotEnd");
            Assert.assertNotNull(slotStart, "Missing required input: slotStart");
            Assert.assertFalse(slotStart.trim().isEmpty(), "Invalid input: slotStart is empty");
            Assert.assertNotNull(slotEnd, "Missing required input: slotEnd");
            Assert.assertFalse(slotEnd.trim().isEmpty(), "Invalid input: slotEnd is empty");
            // Ensure time format is zero-padded (e.g., "2:00:00" -> "02:00:00")
            slotStart = formatTimeWithZeroPadding(slotStart);
            slotEnd = formatTimeWithZeroPadding(slotEnd);
            Reporter.log("Slot Start: " + slotStart);
            Reporter.log("Slot End: " + slotEnd);
            // Fetch latest rxFillId using existing framework utility instead of inline SQL
            rxFillId = connexusAppUtils.getFillId(rxNbr);
            Assert.assertTrue(rxFillId > 0, "Unable to fetch rxFillId from DB for rxNbr " + rxNbr);
            Reporter.log("rxFillId is " + rxFillId);
            // Create dispense order
            Reporter.log("Creating Dispense Order for store " + storeNbr + ", rxFillId=" + rxFillId);
            response = dispenseOrderCreateAPIWrapper.DispenseOrderCreateRXPD(storeNbr, omsOrderId, poNumber, schedDate, slotStart, slotEnd, 1, rxFillId, "None", transType );
            int statusCode = response.getStatusCode();
            if (statusCode == 200) {
                Assert.assertEquals(statusCode, 200, "Dispense Order Creation succeeded");
            } else if (deliveryIssue && statusCode >= 400 && statusCode < 500) {
                Reporter.log("Expected delivery issue: received 4XX client error (statusCode=" + statusCode + ")");
            } else {
                Assert.fail("Unexpected status code: " + statusCode);
            }
            String json = mapper.writeValueAsString(response);
            Reporter.log("DispenseOrderCreate response: " + json);
            orderDetails.put("omsOrderId", omsOrderId);
            orderDetails.put("poNumber", poNumber);
            orderDetails.put("schedDate", schedDate);
            orderDetails.put("rxFillId", String.valueOf(rxFillId));
            orderDetails.put("apiResponse", response);
            dispenseOrderDetails.put(rxNbr, orderDetails);
        } catch (Exception ex) {
            Assert.fail("Error in dispenseOrderCreation: " + ex.getMessage());
        }
    }


    public void performStaging(){
        // Start and complete staging
        startAndCompleteStaging(Integer.parseInt(storeNbr), omsOrderId);
    }

    /* This method will start and complete the staging process for a given store number and OMS order ID
     * storeNumber: The store number for which the staging process is to be performed
     * omsOrderId: The OMS order ID for which the staging process is to be performed
     * return: The staging bag number generated during the staging completion
     * Author: Pranav */
    public void startAndCompleteStaging(int storeNumber, String omsOrderId)  {
        try {
            // Extract current tracking (optional read)
            dbUtils.getDispenseTrackingDetails(storeNumber, omsOrderId);

            // Perform Start Staging API Call
            Reporter.log("Fetching Assign & Fetch Staging Info for store " + storeNumber + ", PO " + poNumber);
            response = rxpdApiWrapper.getAnFStagingInfo(storeNumber, poNumber);

            Assert.assertNotNull(response, "Get Assign & Fetch Staging Info failed: response was null");
            Assert.assertTrue(response.getStatusCode() == 200 || response.getStatusCode() == 204,"Get Assign & Fetch Staging Info failed");
            // Perform Staging Complete
            stagingBagNumber = dbUtils.generateUniqueStagingBagNumber(storeNumber);
            // Validate the generated bag number using check-bag API
            Reporter.log("Validating bag number: " + stagingBagNumber);
            ServiceResponse bagCheckResponse = rxpdApiWrapper.checkBagNumber(stagingBagNumber);
            Reporter.log("Check-bag API Status Code: " + bagCheckResponse.getStatusCode());
            Reporter.log("Check-bag API Response: " + bagCheckResponse.getDataResponse());

            rxFillId = response.getJsonElement("packageToteInfo[0].fillAndBagInfo[0].fills[0].rxFillId");
            packageToteId = response.getJsonElement("packageToteInfo[0].packageToteId");
            bagNumber = response.getJsonElement("packageToteInfo[0].fillAndBagInfo[0].bagNumber");

            Assert.assertTrue(rxFillId > 0, "Invalid rxFillId parsed from staging info");
            Assert.assertNotNull(packageToteId, "Invalid packageToteId parsed from staging info");
            Assert.assertFalse(packageToteId.trim().isEmpty(), "Empty packageToteId parsed from staging info");
            Assert.assertTrue(bagNumber > 0, "Invalid bagNumber parsed from staging info");

            Reporter.log("Completing staging with toteId=" + packageToteId + ", stagingBagNumber=" + stagingBagNumber + ", bagNumber=" + bagNumber + ", rxFillId=" + rxFillId);
            stagingIssuesAPIWrapper.completeStaging(storeNumber + "", packageToteId, stagingBagNumber, bagNumber, rxFillId);

            // Check DB Again to Validate Successful POPC
            presentDispenseTrackingDetails = dbUtils.getDispenseTrackingDetails(storeNumber, omsOrderId);
            Assert.assertNotNull(presentDispenseTrackingDetails, "Staging validation failed: tracking details not found in DB");
            Assert.assertNotNull(presentDispenseTrackingDetails.get("status_code"), "Staging validation failed: status_code missing in DB record");
            Assert.assertEquals(presentDispenseTrackingDetails.get("status_code").toString(), "4",
                    "Staging not completed successfully in DB (expected status 4) for PO: " + poNumber + ", OMS: " + omsOrderId);
            Map<String, Object> orderDetail = new HashMap<>();
            for (Map<String, Object> detail : dispenseOrderDetails.values()) {
                orderDetail.putAll(detail);
            }
            orderDetail.put("packageToteId", packageToteId );
            orderDetail.put("bagNumber", bagNumber);
        } catch (Exception ex) {
            Assert.fail("Error in startAndCompleteStaging: " + ex.getMessage());
        }
    }
    public void DispenseSlotStartTimeUpdated() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Boolean slotTime = connexusAppUtils.updateDispenseSlotStart(poNumber);
            if (slotTime != null){
                Reporter.log("Dispense slot start time should be update for PO: " + slotTime);
            }
        } catch (Exception e) {
            Reporter.log("Test failed during Dispense slot start time should not be updated: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail("Exception occurred: " + e.getMessage());
        }

    }

    public void openRxInModifyScreenAndModifyQty(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        orderSearch.launchOrderSearchScreen();
        orderSearch.performSearch(rxNbr);
        Reporter.log("rxNumber : " + rxNbr);
        orderSearch.openFirstPatientRecord();
        modifyDetails.launchModifyDetailScreen();
        modifyDetails.setDispensedQuantity(inputData.get("DispensedQuantity"));
        modifyDetails.clickAccept();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        modifyDetails.selectCustomerRequestCheckbox();
        modifyDetails.setClickContinue();
        if (pickupPage.isElementDisplayed(pickupPage.btnOK)) {
            if (modifyDetails.getPopUpTextForRxExpire().contains("Prescription is expired as entered.  Check written and expiration dates for accuracy.")){
                pickupPage.rxExpAndDrugDateSelection();
                modifyDetails.selectCustomerRequestCheckbox();
                modifyDetails.setClickContinue();
            }
        }
        modifyDetails.clickButtonYes();
        modifyDetails.clickConnexusOk();
    }

    public void validateRxAndPoStatus(Map<String, String> inputData) throws InterruptedException {
        Assert.assertFalse(poNumber.trim().isEmpty(), "poNumber is empty.");
        Reporter.log("Validating PO status for PO: " + poNumber);
        int statusCode = connexusAppUtils.getStatusCodeFromDispensePoTrackingTable(poNumber);
        Assert.assertEquals(statusCode,inputData.get("statusCode"),"PO status does not match the expected status.");
        Reporter.log("The PO Status code is : " + statusCode);
    }


    public void validateRxPDTables() {
        try {
            Map<String, Object> dispenseOrderDetails = dbUtils.getDispenseOrderTrackingDetails(Integer.parseInt(storeNbr), omsOrderId);
            Assert.assertNotNull(dispenseOrderDetails, "Dispense order details not found in DB for OMS Order ID: " + omsOrderId + " store" + storeNbr);
            Reporter.log(""+dispenseOrderDetails);

            Map<String, Object> dispenseTrackingDetails = dbUtils.getDispenseTrackingDetails(Integer.parseInt(storeNbr), omsOrderId);
            Assert.assertNotNull(dispenseTrackingDetails, "Dispense tracking details not found in DB for OMS Order ID: " + omsOrderId);
            Reporter.log(""+dispenseTrackingDetails);

            Map<String, Object> shippingDetails = dbUtils.getShippingDetails(Integer.parseInt(storeNbr), dispenseTrackingDetails.get("phm_package_id").toString());
            Assert.assertNotNull(shippingDetails, "Shipping details not found in DB for package ID: " + dispenseTrackingDetails.get("phm_package_id"));
            Reporter.log(""+shippingDetails);

            Map<String, Object> dispenseToteDetails = dbUtils.getDispenseToteTrackingDetails(Integer.parseInt(storeNbr), dispenseTrackingDetails.get("purchase_order_id").toString());
            Assert.assertNotNull(dispenseToteDetails, "Dispense tote details not found in DB for PO: " + dispenseTrackingDetails.get("purchase_order_id"));
            Reporter.log(""+dispenseToteDetails);

            Map<String, Object> fillTrackingDetails = dbUtils.getFillTrackingDetails(Integer.parseInt(storeNbr), rxFillId);
            Assert.assertNotNull(fillTrackingDetails, "Fill tracking details not found in DB for rxFillId: " + rxFillId);
            Reporter.log(""+fillTrackingDetails);

            String omsOrderIdLast4 = omsOrderId.substring(omsOrderId.length() - 4).replaceFirst("^0+(?!$)", "");
            Object batchIdObj = dispenseOrderDetails.get("dispense_batch_id");
            Reporter.log("Batch ID: " + batchIdObj.toString());
            boolean isValid = batchIdObj != null && batchIdObj.toString().equals(omsOrderIdLast4);
            Assert.assertTrue(isValid, "dispense_batch_id does not match last 4 of oms_order_id or is 31900");

            Reporter.log("Data is inserted into RXPD tables after dispense order creation request");

            // Fetch rxOrderDetail from DB
            Map<String, Object> rxOrderDetail = dbUtils.getRxOrderDetailTableInfo(Integer.parseInt(storeNbr), rxFillId);
            Assert.assertNotNull(rxOrderDetail, "rxOrderDetail not found in DB");

            //  status_code is 2
            Assert.assertEquals(
                    dispenseTrackingDetails.get("status_code").toString(),
                    "2",
                    "dispense_po_tracking.status_code is not 2"
            );
            Reporter.log("Validated the PO status (dispense_tote_tracking.status_code): "+ dispenseTrackingDetails.get("status_code").toString());
            Assert.assertEquals(
                    dispenseToteDetails.get("status_code").toString(),
                    "2",
                    "dispense_tote_tracking.status_code is not 2"
            );
            Reporter.log("Validated the tote status (dispense_tote_tracking.status_code): "+ dispenseToteDetails.get("status_code").toString());



// Assert label_reprint_ind = N
            Assert.assertEquals(
                    rxOrderDetail.get("label_reprint_ind").toString(),
                    "N",
                    "label_reprint_ind is not N"
            );

// Fetch phm_package_id from dispense_po_tracking
            String expectedPhmPackageId = dispenseTrackingDetails.get("phm_package_id").toString();

// Assert phm_package_id matches
            Assert.assertEquals(
                    rxOrderDetail.get("phm_package_id").toString(),
                    expectedPhmPackageId,
                    "phm_package_id does not match the one assigned to PO in dispense_po_tracking"
            );

// Assert dlvry_method_code = 9
            Assert.assertEquals(
                    rxOrderDetail.get("dlvry_method_code").toString(),
                    "9",
                    "dlvry_method_code is not 9"
            );
            Reporter.log("Validated the rx_order_detail status (label_reprint_ind = N\n" +
                    "Phm_package_id = phm_packge_id assigned to PO in dispense_po_tracking table\n" +
                    "dlvry_method_code = 9): ");

            Map<String, Object> getRequestDetails = dbUtils.getRequestDetails(Integer.parseInt(storeNbr), omsOrderId);
            Assert.assertNotNull(getRequestDetails, "Request details not found in DB for OMS Order ID: " + omsOrderId);

            Map<String, Object> getRxRequestDetails = dbUtils.getRxRequestDetails(Integer.parseInt(storeNbr), getRequestDetails.get("phm_rx_request_id").toString());
            Assert.assertNotNull(getRxRequestDetails, "Rx Request details not found in DB for OMS Order ID: " + omsOrderId);

            // Assert phm_rx_req_src_cd = 3802
            Assert.assertEquals(getRxRequestDetails.get("phm_rx_req_src_cd").toString(), "3802", "phm_rx_req_src_cd is not 3802");
            Assert.assertEquals(getRxRequestDetails.get("status_code").toString(), "21202", "rxRequestDetails.status_code is not 21202( completed )");
            Reporter.log("Validated the phm_rx_request, phm_rx_req_detail tables ");
        } catch (Exception e) {
            Reporter.log("Test failed while validating in rxpd tables " + e.getMessage());
            Assert.fail();
        }
    }

    public void printDeliveryLabel() {
        try {
            Assert.assertNotNull(storeNbr, "storeNbr not initialized");
            Assert.assertNotNull(rxFillId, "rxFillId not initialized");
            PrintLabelAPIWrapper printLabelAPIWrapper = new PrintLabelAPIWrapper();
            // Only pass required arguments: storeNbr, fillId, error
            ServiceResponse response = printLabelAPIWrapper.PrintRXLabelV2(storeNbr, String.valueOf(rxFillId), "");
            String json = mapper.writeValueAsString(response);
            System.out.println("Response String: " + json);
            Assert.assertEquals(response.getStatusCode(), 200, "PrintDeliveryLabel failed");
            Reporter.log("Expected: API 200 OK. Delivery label printed.");
        }
        catch (Exception e) {
            Reporter.log("Test failed at PrintDeliverylabel");
        }
    }

    public void verifyRxInPickup() {
        verifyRxInPickup(rxNbr);
    }

    public void performPoCancel(Map<String, String> inputData) {
        LocalDate currentDate = LocalDate.now();
        String schedDate = currentDate.format(DateTimeFormatter.ISO_DATE); // e.g. "2023-09-19"
        Reporter.log("Schedule Date: " + schedDate);
        List<PoLine> poLinesToUpdate = new ArrayList<>();
        ServiceResponse serRes1 = rxpdApiWrapper.orderModifyLineCancellation(omsOrderId, poNumber, poLinesToUpdate, siteId);
        Assert.assertEquals(serRes1.getStatusCode(), 200, "PO cancel API failed");
    }

    public void validatePOCancellationStatus() {
        Map<String, Object> dispenseTrackingDetails = dbUtils.getDispenseTrackingDetails(Integer.parseInt(storeNbr), omsOrderId);
        Assert.assertNotNull(dispenseTrackingDetails, "Dispense tracking details not found in DB for OMS Order ID: " + omsOrderId);
        Assert.assertEquals(
                dispenseTrackingDetails.get("status_code").toString(),
                "5",
                "dispense_po_tracking.status_code is not 5 (Cancelled)"
        );
    }

    public void validateFillCancellationStatus() {
        Map<String, Object> fillTrackingDetails = dbUtils.getFillTrackingDetails(Integer.parseInt(storeNbr), rxFillId);
        Assert.assertNotNull(fillTrackingDetails, "Fill tracking details not found in DB for rxFillId: " + rxFillId);
        Assert.assertEquals(fillTrackingDetails.get("status_code").toString(), "3", "fill_tracking.status_code is not 3 (Pending Cancel)");
        Reporter.log("The PO cancellation is inserted and order moves to pending cancel and fill status is pedning cancel");
    }

    @Override
    public int performCreatePatientThroughAPI(Map<String, String> inputData, int strNbr) {
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientId = createPatientUsingApi(inputData, strNbr, name[0] + "," + name[1]);
        } catch (Exception e) {
            Reporter.log("Test failed while creating Order via API " + e.getMessage());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }

        return patientId;
    }

    public void createPatientAndMoveToPickup(Map<String, String> inputData, int storeId) {
        patientId = performCreatePatientThroughAPI(inputData, storeId);
        IDatabaseContext cnx = automationManager.getConnexusDB(storeId);
        DataRow drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("NDC_NUMBER"));
        rxNbr = connexusAPIManager.createNewOrderAndMoveToPickup(patientId, storeId, new SimpleDateFormat("MMM dd yyyy").format(Date.from(Instant.now().plus(720, ChronoUnit.DAYS))), new SimpleDateFormat("MMM dd yyyy").format(Date.from(Instant.now().plus(15, ChronoUnit.DAYS))) + " 08:00:00.000 UTC", 25, drugInfo, inputData.get("NDC_NUMBER")).get(0);
    }

    public void dropoffToTillPickUp(Map<String, String> inputData, int storeId) {
        IDatabaseContext cnx = automationManager.getConnexusDB(storeId);
        DataRow drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("NDC_NUMBER"));
        rxNbr = connexusAPIManager.createNewOrderAndMoveToPickup(patientId, storeId, new SimpleDateFormat("MMM dd yyyy").format(Date.from(Instant.now().plus(720, ChronoUnit.DAYS))), new SimpleDateFormat("MMM dd yyyy").format(Date.from(Instant.now().plus(15, ChronoUnit.DAYS))) + " 08:00:00.000 UTC", 25, drugInfo, inputData.get("NDC_NUMBER")).get(0);
    }

    /*
    Method to call Rxupdate API
     */

    public void callRxUpdate(Map<String,String> inputData)  {
        try {
            Assert.assertNotNull(storeNbr, "storeNbr not initialized");
            Assert.assertTrue(rxFillId > 0, "rxFillId not initialized");
            String rxFillStr = String.valueOf(rxFillId);
            Map<String, Object> pay = deliveryApiWrapper.getPaymentdataQuery(storeNbr, rxFillStr);
            double customerPayAmount = Double.parseDouble(inputData.get("AMOUNT"));
            double thirdPartyAmount = Double.parseDouble(inputData.get("AMOUNT"));
            if (pay != null) {
                if (pay.get("customerPayAmount") != null) {
                    customerPayAmount = Double.parseDouble(pay.get("customerPayAmount").toString());
                }
                if (pay.get("thirdPartyAmount") != null) {
                    thirdPartyAmount = Double.parseDouble(pay.get("thirdPartyAmount").toString());
                }
            }
            String posTs = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
            String barcode = storeNbr + rxFillStr;
            int siteId = Integer.parseInt(storeNbr);
            int messageVersion = Integer.parseInt(inputData.get("MESSAGE_VERSION"));
            String messageType = "Update";
            String transType = "SALE";
            int packageCount = Integer.parseInt(inputData.get("PACKAGE_COUNT"));
            int posTransNumber = (int) (System.currentTimeMillis() % 1000000);
            int linkStatus = Integer.parseInt(inputData.get("LINK_STATUS"));
            int pkgSequence = Integer.parseInt(inputData.get("PACKAGE_SEQUENCE"));
            boolean isOverride = false;
            String customerPayType = "CASH";
            int registerNbr = Integer.parseInt(inputData.get("REGISTER_NUMBER"));
            int operatorNbr = Integer.parseInt(inputData.get("OPERATOR_VERSION"));
            double taxAmount = Double.parseDouble(inputData.get("AMOUNT"));

            response = deliveryApiWrapper.rxPosUpdate(
                    siteId,
                    messageVersion,
                    messageType,
                    transType,
                    barcode,
                    packageCount,
                    posTransNumber,
                    posTs,
                    linkStatus,
                    pkgSequence,
                    isOverride,
                    customerPayType,
                    customerPayAmount,
                    registerNbr,
                    operatorNbr,
                    thirdPartyAmount,
                    taxAmount
            );
            Assert.assertEquals(response.getStatusCode(), 200, "RxUpdate Delivery API failed");
        } catch (Exception e) {
            Reporter.log("test failed at RxUpdate API "+e.getMessage());
            Assert.fail();
        }
    }

    /*
    Method to check if Dispense order creation response body is empty after successful ordre creation
     */
    public void validateOrderCreationResponseBody() {
        try {
            String json = response.getDataResponse();
            Assert.assertTrue( json == null || json.isBlank() || json.isEmpty(),"Dispense order creation API response body is not empty"+json+";");
            Reporter.log("Dispense order creation response body is empty as expected");
        }
        catch (Exception e) {
            Reporter.log("Failed while validating dispense order creation body");
            Assert.fail();
        }

    }
     /*
    Method to validate if order is cancelled, fill status set to CANCEL, delivery method code set to 1
     */

    public void validateCancellationStatusesAndUpdates() {
        try {
            int storeId = Integer.parseInt(storeNbr);

            // 1. PO status = 10 (cancelled)
            Reporter.log("PO status = 10 (cancelled)");
            Map<String, Object> poTracking = dbUtils.getDispenseTrackingDetails(storeId, omsOrderId);
            Assert.assertNotNull(poTracking, "PO tracking not found for OMS Order ID: " + omsOrderId);
            Reporter.log("" + poTracking);
            Assert.assertEquals(poTracking.get("status_code").toString(), "10", "PO status_code is not 10 (cancelled)");

            // 2. Tote status = 10 (cancelled)
            Reporter.log("Tote status = 10 (cancelled)");
            Map<String, Object> toteTracking = dbUtils.getDispenseToteTrackingDetails(storeId, poTracking.get("purchase_order_id").toString());
            Assert.assertNotNull(toteTracking, "Tote tracking not found for PO: " + poTracking.get("purchase_order_id"));
            Reporter.log("" + toteTracking);
            Assert.assertEquals(toteTracking.get("status_code").toString(), "10", "Tote status_code is not 10 (cancelled)");

            // 3. Fill status = 2 (Cancelled)
            Reporter.log("Fill status = 2 (Cancelled)");
            Map<String, Object> fillTracking = dbUtils.getFillTrackingDetails(storeId, rxFillId);
            Assert.assertNotNull(fillTracking, "Fill tracking not found for rxFillId: " + rxFillId);
            Reporter.log("" + fillTracking);
            Assert.assertEquals(fillTracking.get("status_code").toString(), "2", "Fill status_code is not 2 (Cancelled)");

            // 4. dlvry_method_code = 1 and phm_package_id = null in rx_order_detail
            Reporter.log("dlvry_method_code = 1 and phm_package_id = null in rx_order_detail");
            Map<String, Object> rxOrderDetail = dbUtils.getRxOrderDetailTableInfo(storeId, rxFillId);
            Assert.assertNotNull(rxOrderDetail, "rx_order_detail not found for rxFillId: " + rxFillId);
            Assert.assertEquals(rxOrderDetail.get("dlvry_method_code").toString(), "1", "dlvry_method_code is not 1");
            Reporter.log("" + rxOrderDetail);
            Assert.assertTrue(rxOrderDetail.get("phm_package_id") == null || rxOrderDetail.get("phm_package_id").toString().isEmpty(), "phm_package_id is not null");

            // 5. Record in dispense_tote_activity with activity_code = 6
            Reporter.log("Record in dispense_tote_activity with activity_code = 6");
            Map<String, Object> totActivity = dbUtils.getToteActivity(storeId, toteTracking.get("package_tote_id").toString());
            Assert.assertNotNull(totActivity, "Tote Activity not found for rxFillId: " + rxFillId);
            Reporter.log("" + totActivity);
            Assert.assertEquals(totActivity.get("activity_code").toString(), "6", " Expected dispense_tote_activity with activity_code = 6 for PO but found :" + totActivity.get("activity_code"));

            Reporter.log("Cancellation status and updates validated for OMS Order ID: " + omsOrderId);
        }
        catch (Exception e){
            Reporter.log("Test failed while validating Cancellation status");
            Assert.fail();
        }
    }

    /*
     * Method to create trip for PO and update driver details
     * Author: Pranav (vn59m66)
     */
    public void createTripForPO() {
        try {
            String tripId = "RXT" + StringUtils.generateRandomNumber(5);
            String driverCode = StringUtils.generateRandomNumber(4);
            PurchaseOrder purchaseOrder = new PurchaseOrder();
            purchaseOrder.setPoNumber(poNumber);
            List<PurchaseOrder> poList = List.of(purchaseOrder);
            ServiceResponse response = rxpdApiWrapper.createTrip(tripId, driverCode, poList, Integer.parseInt(storeNbr));
            Reporter.log("Expected: API 200 OK. Trip created and shipment updated for PO.");
            Assert.assertEquals(response.getStatusCode(), 200, "Create Trip failed!");
        } catch (Exception e) {
            Reporter.log("Test failed at createTripForPO: " + e.getMessage());
            Assert.fail("Error in createTripForPO: " + e.getMessage());
        }
    }

    /*
    * Method performing Staging for MultiRx
    * */
    public void performStagingForMultiRx(){
        try {
            for (Map.Entry<String, Map<String, Object>> s : dispenseOrderDetails.entrySet()) {
                rxNbr = s.getKey();
                Map<String, Object> orderDetail = s.getValue();
                omsOrderId = orderDetail.get("omsOrderId").toString();
                rxFillId = Integer.parseInt(orderDetail.get("rxFillId").toString());
                poNumber = orderDetail.get("poNumber").toString();
                startAndCompleteStaging(Integer.parseInt(storeNbr), omsOrderId);
            }
        }catch (Exception e){
            Reporter.log("failed to perform stagging for multiRx");
            Assert.fail();
        }
    }

    /*
    * Method for performing counsel for MultiRx
    * */
    public void performCounsellingForMultiRx(){
        try {
            for (Map.Entry<String, Map<String, Object>> s : dispenseOrderDetails.entrySet()) {
                rxNbr = s.getKey();
                performCounselling();
            }
        }catch (Exception e){
            Reporter.log("Failed to perform counselling for MultiRx");
            Assert.fail();
        }
    }

    /*
    * Method to create trip for PO and update driver details for MultiRx
    * */
    public void createTripForPOMultiRx(){
        try {
            for(Map.Entry<String, Map<String, Object>> s:dispenseOrderDetails.entrySet()) {
                rxNbr = s.getKey();
                Map<String, Object> orderDetail = s.getValue();
                omsOrderId = orderDetail.get("omsOrderId").toString();
                rxFillId = Integer.parseInt(orderDetail.get("rxFillId").toString());
                poNumber = orderDetail.get("poNumber").toString();
                createTripForPO();
            }
        }catch (Exception e){
            Reporter.log("Failed to create trip for multi Rx" + e.getMessage());
            Assert.fail();
        }
    }

    /*
    * method to start and complete chain of custody delivery for MultiRx
    * */
    public void startAndCompleteChainOfCustodyForMultiRxDelivery(){
        try {
            for(Map.Entry<String, Map<String, Object>> s:dispenseOrderDetails.entrySet()) {
                rxNbr = s.getKey();
                Map<String, Object> orderDetail = s.getValue();
                omsOrderId = orderDetail.get("omsOrderId").toString();
                rxFillId = Integer.parseInt(orderDetail.get("rxFillId").toString());
                poNumber = orderDetail.get("poNumber").toString();
                packageToteId = orderDetail.get("packageToteId").toString();
                startAndCompleteChainOfCustodyForDelivery();
            }
        }catch (Exception e){
            Reporter.log("Failed to complete chain of custody for multi Rx" + e.getMessage());
            Assert.fail();
        }
    }

    /*
    * Method to complete delivery for PO for MultiRx
    * */
    public void completeDeliveryForPOMultiRx(){
        try {
            for(Map.Entry<String, Map<String, Object>> s:dispenseOrderDetails.entrySet()) {
                rxNbr = s.getKey();
                Map<String, Object> orderDetail = s.getValue();
                poNumber = orderDetail.get("poNumber").toString();
                completeDeliveryForPO();
            }
        }catch (Exception e){
            Reporter.log("Failed to compelete delivery for multi Rx" + e.getMessage());
            Assert.fail();
        }
    }

    /*
    *Method to call Rx Update for MultiRx
    * */
    public void callRxUpdateForMutliRx(Map<String,String>inputData){
        try {
            for(Map.Entry<String, Map<String, Object>> s:dispenseOrderDetails.entrySet()) {
                rxNbr = s.getKey();
                Map<String, Object> orderDetail = s.getValue();
                rxFillId = Integer.parseInt(orderDetail.get("rxFillId").toString());
                callRxUpdate(inputData);
            }
        }catch (Exception e){
            Reporter.log("Failed to call Rx Update for multi Rx" + e.getMessage());
            Assert.fail();
        }
    }


    @Override
    public int genericCreatePatient(Map<String, String>inputData) {
        CreatePatientRequest createPatientRequest = new CreatePatientRequest();
        InsuranceDetails insuranceDetails = new InsuranceDetails();
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        siteId = Integer.parseInt(propertyReader.getProperty("cnx.store"));
        //Build input patient
        createPatientRequest.setFirstName(name[0]);
        createPatientRequest.setLastName(name[1]);
        createPatientRequest.setSiteId(siteId);
        createPatientRequest.setHomePhone(inputData.get("PRIMARY_NUMBER"));
        createPatientRequest.setWorkPhone(inputData.get("PRIMARY_NUMBER"));
        createPatientRequest.setCellPhone(inputData.get("PRIMARY_NUMBER"));
        //With TP Details
        createPatientRequest.setPatientHasInsurance(Boolean.parseBoolean(inputData.get("patientHasInsurance")));
        insuranceDetails.setInsuranceCarrierPlanId(Integer.parseInt(inputData.get("carrierPlanId")));
        insuranceDetails.setInsuranceCarrierCompanyId(Integer.parseInt(inputData.get("carrierCompanyCode")));
        insuranceDetails.setBillingSeqNbr(Integer.parseInt(inputData.get("billSeqNbr")));
        insuranceDetails.setCardholderId(inputData.get("cardHolderId"));
        insuranceDetails.setCardholderFirstName(inputData.get("cardHolderFirstName"));
        insuranceDetails.setCardholderLastName(inputData.get("cardHolderLastName"));
        insuranceDetails.setRelationshipCode(Integer.parseInt(inputData.get("relationshipCode")));
        insuranceDetails.setCoverageInd(inputData.get("coverageIndicator"));
        insuranceDetails.setCoverageExpDate(inputData.get("covExpDate"));
        insuranceDetails.setInsPlanTypeCode(Integer.parseInt(inputData.get("planTypeCode")));
        insuranceDetails.setSplitBillInd("");
        createPatientRequest.setInsurance(insuranceDetails);
        patientId= connexusAPIManager.createPaientWithOrWithoutTP(createPatientRequest);
        return patientId;
    }

    /*
    * Method to verify Rx is in EOD for MultiRx
    * */
    public void verifyRxInEODForMultiRx() {
        try {
            for(Map.Entry<String, Map<String, Object>> s:dispenseOrderDetails.entrySet()) {
                rxNbr = s.getKey();
                verifyRxInEOD();
            }
        }catch (Exception e){
            Reporter.log("Failed to while checking if rx is in EOD for multi Rx" + e.getMessage());
            Assert.fail();
        }
    }

    /*
     * Method to start and complete chain of custody for delivery
     * Author: Pranav (vn59m66)
     */
    public void startAndCompleteChainOfCustodyForDelivery(){
        try {
            Assert.assertNotNull(storeNbr, "storeNbr not initialized");
            Assert.assertNotNull(omsOrderId, "omsOrderId not initialized");
            Assert.assertNotNull(packageToteId, "packageToteId not available — ensure staging completed");
            ChainOfCustodyCompleteWrapper coc = new ChainOfCustodyCompleteWrapper();
            Reporter.log("Start Chain of Custody: OMS=" + omsOrderId);
            response = coc.chainOfCustodyStart(1, omsOrderId, storeNbr, "");
            Assert.assertTrue(response.getStatusCode() == 200 || response.getStatusCode() == 204,
                    "ChainOfCustody start failed");
            java.util.List<String> packageTotes = new java.util.ArrayList<>();
            packageTotes.add(packageToteId);
            Reporter.log("Complete Chain of Custody: Tote=" + packageToteId);
            response = coc.chainOfCustodycomplete(1, new java.util.ArrayList<>(), packageTotes, storeNbr, "");
            Assert.assertEquals(response.getStatusCode(), 200, "ChainOfCustody complete failed");
            Reporter.log("Expected: API 200 OK. Chain of Custody complete; PO advances in flow.");
        } catch (Exception e) {
            Reporter.log("Test failed at startAndCompleteChainOfCustodyForDelivery: " + e.getMessage());
            Assert.fail("Error in startAndCompleteChainOfCustodyForDelivery: " + e.getMessage());
        }
    }

    /*
     * Method to complete delivery for PO (set status_code=7 in dispense_po_tracking and dispense_tote_tracking)
     * Author: Pranav (vn59m66)
     */
    public void completeDeliveryForPO() {
        try {
            Assert.assertNotNull(storeNbr, "storeNbr not initialized");
            Assert.assertNotNull(poNumber, "poNumber not initialized");
            Reporter.log("Completing delivery for PO " + poNumber + " (set status_code=7)");
            int store = Integer.parseInt(storeNbr);
            automationManager.getConnexusDB(store).executeUpdateQuery(
                    "update dispense_po_tracking set status_code = 7 where purchase_order_id in ('" + poNumber + "')");
            automationManager.getConnexusDB(store).executeUpdateQuery(
                    "update dispense_tote_tracking set status_code = 7 where purchase_order_id in ('" + poNumber + "')");
            Map<String, Object> dpt = automationManager.getConnexusDB(store)
                    .executeQuery("select status_code from dispense_po_tracking where purchase_order_id='" + poNumber + "'");
            Assert.assertNotNull(dpt, "dispense_po_tracking row not found for PO: " + poNumber);
            Assert.assertEquals(dpt.get("status_code").toString(), "7", "PO not marked Delivered (status 7)");
            Reporter.log("Expected: PO status updated to Delivered (status_code=7) in dispense_po_tracking.");
        } catch (Exception e) {
            Reporter.log("Test failed at completeDeliveryForPO: " + e.getMessage());
            Assert.fail("Error in completeDeliveryForPO: " + e.getMessage());
        }
    }

    /*
     * Method to call RxUpdate with transType information
     * Author: Pranav (vn59m66)
     */
    public void callRxUpdateWithTransType(String transType) {
        try {
            Assert.assertNotNull(storeNbr, "storeNbr not initialized");
            Assert.assertTrue(rxFillId > 0, "rxFillId not initialized");
            Assert.assertTrue("SALE".equalsIgnoreCase(transType) || "REFUND".equalsIgnoreCase(transType),
                    "Invalid transType. Expected SALE or REFUND, but got: " + transType);
            String rxFillStr = String.valueOf(rxFillId);
            Map<String, Object> pay = deliveryApiWrapper.getPaymentdataQuery(storeNbr, rxFillStr);
            double customerPayAmount = 0.0;
            double thirdPartyAmount = 0.0;
            if (pay != null) {
                if (pay.get("customerPayAmount") != null) {
                    customerPayAmount = Double.parseDouble(pay.get("customerPayAmount").toString());
                }
                if (pay.get("thirdPartyAmount") != null) {
                    thirdPartyAmount = Double.parseDouble(pay.get("thirdPartyAmount").toString());
                }
            }
            String posTs = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
            String barcode = storeNbr + rxFillStr;
            int siteId = Integer.parseInt(storeNbr);
            int messageVersion = 2;
            String messageType = "Update";
            int packageCount = 1;
            int posTransNumber = (int)(System.currentTimeMillis() % 1000000);
            int linkStatus = 1;
            int pkgSequence = 1;
            boolean isOverride = false;
            String customerPayType = "CASH";
            int registerNbr = 82;
            int operatorNbr = 9998;
            double taxAmount = 0.0;

            response = deliveryApiWrapper.rxPosUpdate(siteId, messageVersion, messageType, transType, barcode,
                    packageCount, posTransNumber, posTs, linkStatus, pkgSequence, isOverride, customerPayType,
                    customerPayAmount, registerNbr, operatorNbr, thirdPartyAmount, taxAmount);
            Assert.assertEquals(response.getStatusCode(), 200, "RxUpdate Delivery API failed");
            Map<String, Object> pos = deliveryApiWrapper.getPOSDataQuery(storeNbr, rxFillStr);
            Assert.assertNotNull(pos, "POS data not updated for rxFillId=" + rxFillId);
            Reporter.log("Expected: API 200 OK. POS data updated for rxFillId=" + rxFillId + " (transType=" + transType + ")");
        } catch (Exception e) {
            Reporter.log("Test failed at callRxUpdateWithTransType: " + e.getMessage());
            Assert.fail("Error in callRxUpdateWithTransType: " + e.getMessage());
        }
    }

    /**
     * Formats time string to ensure zero-padding for single-digit hours.
     * Examples: "2:00:00" -> "02:00:00", "12:00:00" -> "12:00:00"
     */
    private String formatTimeWithZeroPadding(String time) {
        if (time == null || time.trim().isEmpty()) {
            return time;
        }
        String[] parts = time.split(":");
        if (parts.length >= 1 && parts[0].length() == 1) {
            parts[0] = "0" + parts[0];
        }
        return String.join(":", parts);
    }
    public void cancelFillFromConnexus() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.log("Cancelling fill with Duplicate Fill reason for rxNbr: " + rxNbr);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            connexusStartPage.pressKeys(KeyEvent.VK_ALT, KeyEvent.VK_U);
            connexusStartPage.pressKeys(KeyEvent.VK_C);
            connexusStartPage.pressKeys(KeyEvent.VK_D);
            // To confirm and accept the fill cancellation.
            modifyDetails.clickButtonYes();
            // To accept the RTS (Return to Stock) process after the cancellation.
            modifyDetails.clickButtonYes();
            // To close the open screen once all actions are completed.
            modifyDetails.clickButtonYes();
            Reporter.log("Successfully cancelled fill with Duplicate Fill reason");

        } catch (Exception ex) {
            Reporter.log("Error in " + currentStepMethodName + ": " + ex.getMessage());
            ex.printStackTrace();
            Assert.fail("Failed to cancel fill with Duplicate Fill reason: " + ex.getMessage());
        }
    }

    public void dispenseOrderCreationWithExistingPOAndOmsOrderId(Map<String, String> inputData, String transType, boolean deliveryIssue) {
        dispenseOrderCreationWithExistingPOAndOmsOrderId(inputData, transType,deliveryIssue,false);
    }

    public void dispenseOrderCreationWithExistingPOAndOmsOrderId(Map<String, String> inputData, String transType, boolean deliveryIssue,boolean isPastDate) {
        try {
            //Have to wait 10 sec before running same api 2nd time.
            automationManager.performSleep(10);
            Map<String,Object> orderDetails = new HashMap<>();
            storeNbr = String.valueOf(connexusAppUtils.getStoreId());
            Reporter.log("Generated OMS Order ID: " + omsOrderId);
            Reporter.log("Generated PO Number: " + poNumber);

            // Generate dynamic current date (in the format YYYY-MM-DD) using framework utility

            if(isPastDate) {
                schedDate = fillDate;
            }else{
                schedDate = DateUtils.currentDate("yyyy-MM-dd");
            }
            Reporter.log("Schedule Date: " + schedDate);
            slotStart = inputData.get("slotStart");
            slotEnd = inputData.get("slotEnd");
            Assert.assertNotNull(slotStart, "Missing required input: slotStart");
            Assert.assertFalse(slotStart.trim().isEmpty(), "Invalid input: slotStart is empty");
            Assert.assertNotNull(slotEnd, "Missing required input: slotEnd");
            Assert.assertFalse(slotEnd.trim().isEmpty(), "Invalid input: slotEnd is empty");
            // Ensure time format is zero-padded (e.g., "2:00:00" -> "02:00:00")
            slotStart = formatTimeWithZeroPadding(slotStart);
            slotEnd = formatTimeWithZeroPadding(slotEnd);
            Reporter.log("Slot Start: " + slotStart);
            Reporter.log("Slot End: " + slotEnd);
            // Fetch latest rxFillId using existing framework utility instead of inline SQL
            rxFillId = connexusAppUtils.getFillId(rxNbr);
            Assert.assertTrue(rxFillId > 0, "Unable to fetch rxFillId from DB for rxNbr " + rxNbr);
            Reporter.log("rxFillId is " + rxFillId);
            // Create dispense order
            Reporter.log("Creating Dispense Order for store " + storeNbr + ", rxFillId=" + rxFillId);
            response = dispenseOrderCreateAPIWrapper.DispenseOrderCreateRXPD(storeNbr, omsOrderId, poNumber, schedDate, slotStart, slotEnd, 1, rxFillId, "None", transType );
            int statusCode = response.getStatusCode();
            if (statusCode == 200) {
                Assert.assertEquals(statusCode, 200, "Dispense Order Creation succeeded");
            } else if (deliveryIssue && statusCode >= 400 && statusCode < 500) {
                Reporter.log("Expected delivery issue: received 4XX client error (statusCode=" + statusCode + ")");
            } else {
                Assert.fail("Unexpected status code: " + statusCode);
            }
            String json = mapper.writeValueAsString(response);
            Reporter.log("DispenseOrderCreate response: " + json);
            orderDetails.put("omsOrderId", omsOrderId);
            orderDetails.put("poNumber", poNumber);
            orderDetails.put("schedDate", schedDate);
            orderDetails.put("rxFillId", String.valueOf(rxFillId));
            orderDetails.put("apiResponse", response);
            dispenseOrderDetails.put(rxNbr, orderDetails);
        } catch (Exception ex) {
            Assert.fail("Error in dispenseOrderCreation: " + ex.getMessage());
        }
    }

        /**
         * This method validates that the PO number and OMS order ID exist in the database.
         */
        public void validatePoNumberOmsOrderIdAndRxFillId() {
            try {
                poAndOMSId = connexusAppUtils.getOmsAndPOrderId();
                int fillId = connexusAppUtils.getFillIdFromDispenseFillTrackingTable();
                Assert.assertEquals(omsOrderId, poAndOMSId.get("omsOrderId"));
                Assert.assertEquals(poNumber, poAndOMSId.get("poNumber"));
                Assert.assertEquals(fillId, rxFillId);
                Reporter.log("PO number "+poNumber+" and OMS order id "+omsOrderId+" and RX fill id "+fillId+" found in DB");
            }catch (Exception e) {
                Assert.fail("PO number and OMS order id and rx fill id not found in DB");
            }
        }

        /**
         * This method validates that the status code exist in the database.
         */
        public void validateStatusCodeinDispensePOAndToteTrackingTable(Map<String, String> inputData) {
            try {
                int statusCode_PO_Table = connexusAppUtils.getStatusCodeFromDispensePoTrackingTable(poNumber);
                int statusCode_Tote_Table = connexusAppUtils.getStatusCodeFromDispenseToteTrackingTable(poNumber);
                Assert.assertEquals(statusCode_PO_Table, 2);
                Assert.assertEquals(statusCode_Tote_Table, 2);
                Reporter.log("Status code in Dispense PO table " + statusCode_PO_Table + " and Status code in Dispense Tote table " + statusCode_Tote_Table + " found in DB");
            } catch (Exception e) {
                Assert.fail("Status code not found in DB");
            }
        }
    public void validateLogDispenseOrderTrackingDetails() {
        Reporter.log("Querying dispense order tracking details for OMS Order ID: " + omsOrderId);

        String query = "SELECT dft.rx_fill_id, dpt.purchase_order_id, dtt.status_code as tote_tracking_status " +
                "FROM informix.dispense_fill_tracking dft " +
                "JOIN informix.dispense_tote_tracking dtt ON dft.package_tote_id = dtt.package_tote_id " +
                "JOIN informix.dispense_po_tracking dpt ON dtt.purchase_order_id = dpt.purchase_order_id " +
                "WHERE dpt.oms_order_id = '" + omsOrderId + "'";

        List<Map<String, Object>> trackingDetailsList = null;
        for (int attempt = 1; attempt <= 2; attempt++) {
            trackingDetailsList = automationManager.getConnexusDB(siteId).executeQueryForList(query);
        }
        for (Map<String, Object> trackingDetails : trackingDetailsList) {
            Reporter.log("" + trackingDetails);
        }
    }

    /*
     * Method for creating patient with multi Rx and moving till pickup
     * */
    public void createMultiRxPatienAndMoveToPickup(Map<String, String> inputData, int storeId, boolean isTpRequired) {
        List<String> rxNums = new ArrayList<>();
        try {
            if (isTpRequired) {
                patientId = genericCreatePatient(inputData);
                rxNums = createMultiRxAndMoveToPickupForTp(inputData, patientId);
            }else {
                patientId = performCreatePatientThroughAPI(inputData, storeId);
                rxNums = createMultiRxAndMoveToPickup(inputData, patientId);
            }
            rxNum.addAll(rxNums);
        }catch (Exception e){
            Reporter.log("Failed to create Multi Rx patient and move till pickup");
            Assert.fail();
        }
    }

    List<String> createMultiRxAndMoveToPickup(Map<String, String> inputData, int patientId) {
        List<String> multiRxNbr = new ArrayList<>();
        try {
            int numRefills = Integer.parseInt(inputData.get("REFILLS"));
            List<String> ndcList = Arrays.asList(inputData.get("DRUG_NAME1"), inputData.get("DRUG_NAME2"), inputData.get("DRUG_NAME3"));
            List<InputResponse> multiRxVVCompleteResp = connexusAPIManager.createMultiRxAndMoveToPickup(patientId, siteId, numRefills, ndcList, connexusAPIManager.PrescriberDetails());
            for (InputResponse inputResponse : multiRxVVCompleteResp) {
                rxNbr = String.valueOf(inputResponse.getRxNbr());
                multiRxNbr.add(rxNbr);
                Reporter.log("rxNbrValue:" + rxNbr);
            }
        } catch (Exception e) {
            Reporter.log("MultiRx patient creation failed"+e.getMessage());
        }return multiRxNbr;
    }

    List<String> createMultiRxAndMoveToPickupForTp(Map<String, String> inputData, int patientId) {
        List<String> multiRxNbr = new ArrayList<>();
        try {
            int numRefills = Integer.parseInt(inputData.get("REFILLS"));
            List<String> ndcList = Arrays.asList(inputData.get("DRUG_NAME1"), inputData.get("DRUG_NAME2"), inputData.get("DRUG_NAME3"));
            List<String> multiRxTpCompleteResp = connexusAPIManager.createNewMultiDrugOrderToReadyForPickUp(patientId, siteId,numRefills, ndcList, connexusAPIManager.PrescriberDetails());
            for (String inputResponse : multiRxTpCompleteResp) {
                rxNbr = inputResponse;
                multiRxNbr.add(rxNbr);
            }
        } catch (Exception e) {
            Reporter.log("MultiRx Tp patient creation failed"+e.getMessage());
        }return multiRxNbr;
    }

    /*
     * Method for Dispense Order Creation for MultiRx
     * */
    public void multiRxDispenseOrderCreation(Map<String, String>inputData){
        try {
            ZonedDateTime scheduledStartDate = ZonedDateTime.now(ZoneOffset.UTC)
                    .minusDays(10);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            schedDate = scheduledStartDate.format(formatter);

            for (String rxNumber : rxNum) {
                rxNbr = rxNumber;
                Reporter.log("Dispense order creation for rx: " + rxNbr);
                dispenseOrderCreation(inputData);
            }
        }catch (Exception e){
            Reporter.log("Failed multiRx dispnese order creation"+e.getMessage());
            Assert.fail();
        }
    }

    /*
     * Method for RXPD Validation for multiRx
     * */
    public void multiRxRXPDValidation(){
        try {
            for (Map.Entry<String, Map<String, Object>> s : dispenseOrderDetails.entrySet()) {
                rxNbr = s.getKey();
                Map<String, Object> orderDetail = s.getValue();
                omsOrderId = orderDetail.get("omsOrderId").toString();
                rxFillId = Integer.parseInt(orderDetail.get("rxFillId").toString());

                Map<String, Object> dispenseOrderDetails = dbUtils.getDispenseOrderTrackingDetails(Integer.parseInt(storeNbr), omsOrderId);
                Assert.assertNotNull(dispenseOrderDetails, "Dispense order details not found in DB for OMS Order ID: " + omsOrderId + " store" + storeNbr);
                Reporter.log("" + dispenseOrderDetails);

                Map<String, Object> dispenseTrackingDetails = dbUtils.getDispenseTrackingDetails(Integer.parseInt(storeNbr), omsOrderId);
                Assert.assertNotNull(dispenseTrackingDetails, "Dispense tracking details not found in DB for OMS Order ID: " + omsOrderId);
                Reporter.log("" + dispenseTrackingDetails);

                Map<String, Object> dispenseToteDetails = dbUtils.getDispenseToteTrackingDetails(Integer.parseInt(storeNbr), dispenseTrackingDetails.get("purchase_order_id").toString());
                Assert.assertNotNull(dispenseToteDetails, "Dispense tote details not found in DB for PO: " + dispenseTrackingDetails.get("purchase_order_id"));
                Reporter.log("" + dispenseToteDetails);

                Map<String, Object> fillTrackingDetails = dbUtils.getFillTrackingDetails(Integer.parseInt(storeNbr), rxFillId);
                Assert.assertNotNull(fillTrackingDetails, "Fill tracking details not found in DB for rxFillId: " + rxFillId);
                Reporter.log("" + fillTrackingDetails);

                Assert.assertEquals(
                        dispenseTrackingDetails.get("status_code").toString(),
                        "2",
                        "dispense_po_tracking.status_code is not 2"
                );
                Reporter.log("Validated the PO status (dispense_po_tracking.status_code): " + dispenseTrackingDetails.get("status_code").toString());

                Assert.assertEquals(
                        dispenseToteDetails.get("status_code").toString(),
                        "2",
                        "dispense_tote_tracking.status_code is not 2"
                );
                Reporter.log("Validated the tote status (dispense_tote_tracking.status_code): " + dispenseToteDetails.get("status_code").toString());

                Assert.assertEquals(
                        fillTrackingDetails.get("status_code").toString(),
                        "1",
                        "dispense_fill_tracking.status_code is not 1"
                );
                Reporter.log("Validated the fill status (dispense_fill_tracking.status_code): " + fillTrackingDetails.get("status_code").toString());

                Map<String, Object> rxOrderDetail = dbUtils.getRxOrderDetailTableInfo(Integer.parseInt(storeNbr), rxFillId);
                Assert.assertNotNull(rxOrderDetail, "rxOrderDetail not found in DB");
                Assert.assertEquals(
                        rxOrderDetail.get("dlvry_method_code").toString(),
                        "9",
                        "dlvry_method_code is not 9"
                );
                Reporter.log("Validated the rx_order_detail status (label_reprint_ind = N\n" +
                        "Phm_package_id = phm_packge_id assigned to PO in dispense_po_tracking table\n" +
                        "dlvry_method_code = 9): ");
            }
        }
        catch (Exception e){
            Reporter.log("Test failed at RxPD validation "+e.getMessage());
            Assert.fail();
        }
    }
    public void updateFillDate(String rxNumber) {
        try {
            LocalDate pastDate = LocalDate.now().minusDays(10);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            String fillDate = pastDate.format(formatter);

            String rxFillIdQuery = dbUtils.FillQuery(rxNumber);
            Map<String, Object> fillDetails = automationManager.getConnexusDB(siteId).executeQuery(rxFillIdQuery);
            if (fillDetails !=null && !fillDetails.isEmpty() &&fillDetails.containsKey("rx_fill_id")){
                String rxFillIdstr =fillDetails.get("rx_fill_id").toString();
                int rxFillId=Integer.parseInt(rxFillIdstr);
                dbUtils.updateFillDate(siteId, rxFillId,fillDate);
                Assert.assertTrue(rxFillId > 0 && fillDate != null && !fillDate.isEmpty(),"Fill date update validation failed");
                Reporter.log("Successfully updated fill date for RX " + rxNumber + " to " + fillDate + "with rx_fill_id: " + rxFillId);
            }
        }catch (Exception e){
            Reporter.log("Error upDating fill date for RX "+ rxNumber +": " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void updateFillIdForMultiRx(){
        for (String rxNumber : rxNum) {
            updateFillDate(rxNumber);
        }
    }

    public void updateRxFillDateToOneMonthOld() {
        try {
            rxFillId=connexusAppUtils.getFillId(rxNbr);
            fillDate=getFillDate(30);
            int updatedFillDate=connexusAppUtils.updateFillDateInRxFillTable(fillDate,rxFillId);
            if(updatedFillDate>0){
                Assert.assertTrue(true);
                Reporter.log("Fill Date updated to one month past date "+fillDate);
            }else{
                Assert.fail("FillDate not updated");
            }
        } catch (Exception e) {
            Assert.fail("Date not updated properly in DB" + e.getMessage());
        }
    }

    public String getFillDate(int noOfDays) {
        String date, month, year;
        fillDate = connexusAppUtils.getFillDateFromRxFillTable(rxFillId);
        String datesplit[] = fillDate.split("-");
        year = datesplit[0];
        month = datesplit[1];
        date = datesplit[2];
        fillDate = month + "/" + date + "/" + year;
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        Calendar cal = Calendar.getInstance();
        try {
            cal.setTime(sdf.parse(fillDate));
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        cal.add(Calendar.DAY_OF_MONTH, -noOfDays);
        fillDate = sdf.format(cal.getTime());
        datesplit = fillDate.split("/");
        month = datesplit[0];
        date = datesplit[1];
        year = datesplit[2];
        return fillDate = year + "-" + month + "-" + date;

    }

    public void validateFillIdInDispenseTrackingTable() {
        try {
            int newFillId = connexusAppUtils.getFillIdFromDispenseFillTrackingTable();
            Assert.assertEquals(newFillId, rxFillId);
            Reporter.log("New Rx Fill id  " + newFillId + " added to dispense tracking table");
        } catch (Exception e) {
            Assert.fail("New Rx fill id not added to the DB");
        }
    }

    public void updateRxFillDateForOneRx(int Rx) {
        String rxNumber = rxNum.get(Rx);
        updateFillDate(rxNumber);
    }


    public void updateRxExpDateToLessThanToday(){
        try{
            rxNbr = rxNum.getFirst();
            LocalDate pastDate = LocalDate.now().minusDays(1);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String ExpDate = pastDate.format(formatter);
            dbUtils.updateExpDate(siteId,rxNbr, ExpDate);
            Assert.assertEquals(dbUtils.getExpDate(siteId,rxNbr), ExpDate);
        }catch (Exception e){
            Reporter.log("Failed to update the Rx expiration date"+ e.getMessage());
            Assert.fail();
        }
    }
    public void updateRxExpDateToPastYear(){
        try{
            rxNbr = rxNum.getFirst();
            LocalDate pastDate = LocalDate.now().minusDays(365);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String ExpDate = pastDate.format(formatter);
            dbUtils.updateExpDate(siteId,rxNbr, ExpDate);
            Assert.assertEquals(dbUtils.getExpDate(siteId,rxNbr), ExpDate);
        }catch (Exception e){
            Reporter.log("Failed to update the Rx expiration date"+ e.getMessage());
            Assert.fail();
        }
    }

    /*
     * Method for creating patient with  Rx and moving till pickup
     * */
    public void createRxPatientAndMoveToPickup(Map<String, String> inputData, int storeId, boolean isTpRequired) {
        try {
            if (isTpRequired) {
                patientId = genericCreatePatient(inputData);
                rxNum = createRxAndMoveToPickupForTp(inputData, patientId);
            }
        }catch (Exception e){
            Reporter.log("Failed to create  Rx patient and move till pickup");
            Assert.fail();
        }
    }

    @Override
    public List<String> createRxAndMoveToPickupForTp(Map<String, String> inputData, int patientId) {
        List<String> multiRxNbr = new ArrayList<>();
        try {
            int numRefills = 0;
            List<String> ndcList = Arrays.asList(inputData.get("DRUG_NAME1"));
            List<String> multiRxTpCompleteResp = connexusAPIManager.createNewMultiDrugOrderToReadyForPickUp(patientId, siteId,numRefills, ndcList, connexusAPIManager.PrescriberDetails());
            for (String inputResponse : multiRxTpCompleteResp) {
                rxNbr = inputResponse;
                multiRxNbr.add(rxNbr);
            }
        } catch (Exception e) {
            Reporter.log("MultiRx Tp patient creation failed"+e.getMessage());
        }return multiRxNbr;
    }
    public void validateFuturePriorityAndPickupTimeInDB() {
        try {
            String query = "SELECT rod.est_pickup_ts, rod.priority_id, rpt.priority_desc " +
                    "FROM rx_order_detail rod " +
                    "JOIN rx rx1 ON rx1.rx_id = rod.rx_id " +
                    "LEFT JOIN rx_priority_txt rpt ON rpt.priority_id = rod.priority_id " +
                    "WHERE rx1.rx_nbr = '" + rxNbr + "' " +
                    "AND rod.rx_fill_id = (SELECT MAX(rx_fill_id) FROM rx_order_detail rod1 WHERE rod1.rx_id = rx1.rx_id)";
            Reporter.log("Executing query to validate order priority and pickup time : " + query);
            List<Map<String, Object>> result = automationManager.getConnexusDB(siteId).executeQueryForList(query);

            if (!result.isEmpty()) {
                String est_pickup_ts = result.get(0).get("est_pickup_ts").toString();
                String priority_id = result.get(0).get("priority_id").toString();
                String priority_desc = result.get(0).get("priority_desc").toString();

                Reporter.log("Est Pickup TS: " + est_pickup_ts);
                Reporter.log("Priority ID: " + priority_id);
                Reporter.log("Priority Description: " + priority_desc);

                String futureDate = connexusAppUtils.getPastOrFutureTimestamp("yyyy-MM-dd", 1);
                String expected_est_pickup_ts = "" + futureDate + " 14:00:00.0";
                String expected_priority_des = "Future";
                Reporter.log("Expected pick up time as past 1 PM : " + expected_est_pickup_ts);
                Reporter.log("Expected priority as Future :" + expected_priority_des);
                Assert.assertEquals(est_pickup_ts, expected_est_pickup_ts, "est_pickup_ts not VALID");
                Assert.assertEquals(priority_desc.trim(), expected_priority_des, "priority_Description not VALID");
            } else {
                String errorMsg = "FAILED: No order details found in database for RX: " + rxNbr;
                Reporter.log(errorMsg);
            }
        } catch (Exception e) {
            Reporter.log("Exception occurred while validating Future priority and pickup time: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("Exception during validation: " + e.getMessage());

        }
    }

    public void validateStagingProcessWithBagAssignment(){
        try {

            // Extract current tracking (optional read)
            dbUtils.getDispenseTrackingDetails(Integer.parseInt(storeNbr), omsOrderId);

            // Perform Start Staging API Call
            Reporter.log("Fetching Assign & Fetch Staging Info for store " + Integer.parseInt(storeNbr) + ", PO " + poNumber);
            response = rxpdApiWrapper.getAnFStagingInfo(Integer.parseInt(storeNbr), poNumber);

            Map<String, Object> dispenseTrackingDetails = dbUtils.getDispenseTrackingDetails(Integer.parseInt(storeNbr), omsOrderId);
            Assert.assertNotNull(dispenseTrackingDetails, "Dispense tracking details not found in DB for OMS Order ID: " + omsOrderId);
            Reporter.log(""+dispenseTrackingDetails);
            //  status_code is 3 for PO Inprogress
            Assert.assertEquals(dispenseTrackingDetails.get("status_code").toString(), "3", "dispense_po_tracking.status_code is not 3");
            Reporter.log("Validated the PO status (dispense_tote_tracking.status_code): "+ dispenseTrackingDetails.get("status_code").toString());

            Assert.assertNotNull(response, "Get Assign & Fetch Staging Info failed: response was null");
            Assert.assertTrue(response.getStatusCode() == 200 || response.getStatusCode() == 204,"Get Assign & Fetch Staging Info failed");

            // Assigning previous staging bagNumber
            Reporter.log("Assigned bag number: " + stagingBagNumber);
            ServiceResponse bagCheckResponse = rxpdApiWrapper.checkBagNumber(stagingBagNumber);
            Reporter.log("Check-bag API Status Code: " + bagCheckResponse.getStatusCode());
            Reporter.log("Check-bag API Response: " + bagCheckResponse.getDataResponse());

            rxFillId = response.getJsonElement("packageToteInfo[0].fillAndBagInfo[0].fills[0].rxFillId");
            packageToteId = response.getJsonElement("packageToteInfo[0].packageToteId");
            bagNumber = response.getJsonElement("packageToteInfo[0].fillAndBagInfo[0].bagNumber");

            Assert.assertTrue(rxFillId > 0, "Invalid rxFillId parsed from staging info");
            Assert.assertNotNull(packageToteId, "Invalid packageToteId parsed from staging info");
            Assert.assertFalse(packageToteId.trim().isEmpty(), "Empty packageToteId parsed from staging info");
            Assert.assertTrue(bagNumber > 0, "Invalid bagNumber parsed from staging info");

            Reporter.log("Completing staging with toteId=" + packageToteId + ", stagingBagNumber=" + stagingBagNumber + ", bagNumber=" + bagNumber + ", rxFillId=" + rxFillId);
            ServiceResponse serviceResponse = stagingIssuesAPIWrapper.completeStaging(Integer.parseInt(storeNbr) + "", packageToteId, stagingBagNumber, bagNumber, rxFillId);
            if(serviceResponse.getStatusCode() == 410){
                Assert.assertTrue(true);
            }
            else{
                Assert.fail("Status code is not 410");
            }
        } catch (Exception ex) {
            Assert.fail("Error in startAndCompleteStaging: " + ex.getMessage());
        }
    }

    /*
     * Method to validate CPR/Register refund Screen from rx lookup screen
     * */
    public void performRefundReFillMenuOptionsFromCurrentRXInF7() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            rxLookUp.openAndSearchPatientRecordInF7(rxNbr);
            // open CPR and close browser
            menuBar.selectNavigation(AppMenu.CPR, AppMenuItemsIndex.CURRENT_RX_REFUND_REFILL, AppMenuSubItemsIndex.CPR, null);
            Reporter.logScreenShot("CPR Browser", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.closeBrowser();
            Reporter.log("Current RX CPR browser opened and closed successfully");
            // Register refund will enable and open
            rxLookUp.clickSearch();
            menuBar.selectNavigation(AppMenu.REGISTER_REFUND, AppMenuItemsIndex.CURRENT_RX_REFUND_REFILL, AppMenuSubItemsIndex.REGISTER_REFUND, null);
            // Able to initiate the refund
            Reporter.logScreenShot(Status.PASS, "initiateRefund", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.clickYesButton();
            // STR is printing
            Reporter.logScreenShot(Status.PASS, "voidStrIsPrinting", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.clickOkButton();
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("CPR/Register refund Screen not found from rx lookup screen" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    public void validateModificationNotAllowedPopup(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            Reporter.log("rxNumber : " + rxNbr);
            Reporter.logScreenShot(Status.PASS, "Rx Is In EOD", modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            orderSearch.openFirstPatientRecord();
            String popupText = modifyDetails.getTextFromPopUp();
            Assert.assertTrue(popupText.contains("This Rx is marked for delivery and modifications cannot be allowed at this time"));
            Reporter.logScreenShot(Status.PASS, "Modification Not Allowed Popup", modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Popup message: " + popupText);
            //click ok on the popup for closing it
            modifyDetails.clickok();
            //to close the modify details screen
            modifyDetails.clickCancel();
            //for confirming the cancel action
            modifyDetails.clickYes();
        }catch (Exception e){
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
}