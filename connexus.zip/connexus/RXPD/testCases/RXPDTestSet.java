package connexus.RXPD.testCases;

import com.fasterxml.jackson.core.JsonProcessingException;
import connexus.RXPD.testScripts.RXPDTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

public class RXPDTestSet {

    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    RXPDTestScripts rxpdTestScripts = new RXPDTestScripts(LoginAs.userType.PHARMACIST_ADFlagOff);
    PropertyReader prop = PropertyReader.getInstance();
    String siteId = prop.getProperty("cnx.store");
    boolean flagUpdated = false;
    ConnexusAPIManager connexusAPIManager= new ConnexusAPIManager();

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description: To convert connexus order from pickup into RxPD Order and insert Dispatcher issue followed by PO reschedule and Staging Issues completion
      * Test Case ID: HWPHME2E-3183
      * Author: Pranav(vn59m66)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "RxPD Enabled | Staging Issues | Dispatcher issue and PO reschedule combination", priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_3183_DispatcherIssueAndPOReschedule(Map<String, String> inputData)  {

        //Enabling RxPD flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32000", "TRUE");
        rxpdTestScripts.initializeTestCase(flagUpdated);
        rxpdTestScripts.createNewPatient(inputData,1);
        rxpdTestScripts.dropAnRxTillPickUp(inputData);
        //Converting order to RxPD order
        rxpdTestScripts.dispenseOrderCreation(inputData, "NewOrder", false);
        //Call staging API and complete the staging process
        rxpdTestScripts.performStaging();
        Reporter.log("Partial Automation is done since shell script for dispatcher issue insertion is not automated");
        Reporter.log("Pending Steps: Rm Job runs and srxCheckAndInsertDispatcherIssue script runs, Hit PO reschedule API, Hit Staging Issue API complete the Staging Issue Process");
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description: To convert connexus order from pickup into RxPD Order and insert Dispatcher issue followed by PO Partial Cancellation
      * Test Case ID: HWPHME2E-3184
      * Author: Prashant(vn52our)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "RxPD Enabled | Staging Issues | Dispatcher issue and Line Cancellation combination", priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_3184_DispatcherIssueAndPOPartialCancellation(Map<String, String> inputData) {

        //Enabling RxPD flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32000", "TRUE");
        rxpdTestScripts.initializeTestCase(flagUpdated);
        rxpdTestScripts.createNewPatient(inputData,1);
        rxpdTestScripts.dropAnRxTillPickUp(inputData);
        //Converting order to RxPD order
        rxpdTestScripts.dispenseOrderCreation(inputData, "NewOrder", false);
        //Call staging API and complete the staging process
        rxpdTestScripts.performStaging();
        Reporter.log("Partial Automation is done since shell script for dispatcher issue insertion is not automated");
        Reporter.log("Pending Steps: Rm Job runs and srxCheckAndInsertDispatcherIssue script runs, Hit Partial Cancellation API");
    }
    /*----------------------------------------------------------------------------------------------------------
     * Test Description: RxPD enabled | RxPd fill should be cancelled when sold at register
     * Test Case ID: HWPHME2E-4655
     * Author: Aparna Ramalingam(vn50izt)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "RxPD enabled | RxPd fill should be cancelled when sold at register", priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_4655_fillCancelledWhenSoldAtRegister(Map<String, String> inputData) {
        int storeNbr = connexusAppUtils.getStoreId();
        rxpdTestScripts.initializeTestCase(false);
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        //Converting order to RxPD order
        rxpdTestScripts.dispenseOrderCreation(inputData, "NewOrder", false);
        rxpdTestScripts.validateRxPDTables();
        Reporter.log("Complete staging for the PO");
        rxpdTestScripts.performStaging();
        rxpdTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        rxpdTestScripts.printDeliveryLabel();
        Reporter.log("Complete counselling for the fill in PO");
        rxpdTestScripts.performCounselling();
        rxpdTestScripts.verifyRxInPickup();
        Reporter.log("Hit the PO Cancel API");
        rxpdTestScripts.performPoCancel(inputData);
        rxpdTestScripts.validatePOCancellationStatus();
        rxpdTestScripts.validateFillCancellationStatus();
        Reporter.log("Hit the Rxupdate api with register not 82 aqnd operatore number not as 9998 or sell it at register");
        rxpdTestScripts.callRxUpdate(inputData);
        // rxpdTestScripts.validateOrderCancelledAndFillStatus();
        rxpdTestScripts.validateCancellationStatusesAndUpdates();
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description: RxPD Enabled | Single Rx Scheduled Delivery PO - Modify fill from connexus
      * Test Case ID: HWPHME2E-2938
      * Author: Prashant(vn52our)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "RxPD Enabled | Single Rx Scheduled Delivery PO - Modify fill from connexus", priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_2938_Single_Rx_Scheduled_Delivery_PO(Map<String, String> inputData) throws InterruptedException {

        flagUpdated = connexusAppUtils.readAndUpdateFlag("32000", "TRUE");
        rxpdTestScripts.initializeTestCase(flagUpdated);
        rxpdTestScripts.createNewPatient(inputData);
        rxpdTestScripts.dropAnRxTillPickUp(inputData);
        rxpdTestScripts.dispenseOrderCreation(inputData, "NewOrder", false);
        rxpdTestScripts.performStaging();
        rxpdTestScripts.performCounselling();
        rxpdTestScripts.openRxInModifyScreenAndModifyQty(inputData);
        rxpdTestScripts.validateRxAndPoStatus(inputData);

    }

    /*----------------------------------------------------------------------------------------------------------
    * HWPHME2E_3185_Staging_Issues_Dispatcher_issue_PO_Cancellation
    *
    * Pre-Conditions:
    * 1.User is logged into Connexions
    * 2.Rx In Pickup
    * 3.The Rx is scheduled for delivery
    * 4.The order goes to Staging complete
    * Author: Mallikarjuna(vn58n9x).
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify that the Staging Issues and Dispatcher issue and PO Cancellation..",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_3185_Staging_Issues_Dispatcher_issue_PO_Cancellation(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateFlag(inputData.get("FlagCode"),inputData.get("FlagValue"));
        rxpdTestScripts.initializeTestCase(flagUpdated);
        rxpdTestScripts.createNewPatient(inputData,1);
        rxpdTestScripts.dropAnRxTillPickUp(inputData);
        rxpdTestScripts.dispenseOrderCreation(inputData, "NewOrder", false);
        rxpdTestScripts.validateRxPDTables();
        rxpdTestScripts.performStaging();
        rxpdTestScripts.DispenseSlotStartTimeUpdated();

        Reporter.log("Executed successfully ,Validate that the Staging Issues and Dispatcher issue and PO Cancellation.");
    }

    /*----------------------------------------------------------------------------------------------------------
  * Test Description: RxPD Enabled | Single Rx Scheduled Delivery PO move to EOD
  * This involves E2E flow starting from patient creation till reprint of delivery label after delivery completion
  * Test Case ID: HWPHME2E-2932
  * Author: Pranav(vn59m66)
  ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "RxPD Enabled | Single Rx Scheduled Delivery PO move to EOD", priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_2932_Single_Rx_Scheduled_Delivery_EOD(Map<String, String> inputData) throws JsonProcessingException {
        int storeNbr = connexusAppUtils.getStoreId();
        rxpdTestScripts.initializeTestCase(false);

        //Create Patient with TP using API and move to pickup
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);

        //Converting order to RxPD order
        rxpdTestScripts.dispenseOrderCreation(inputData);
        //Validate the RXPD tables content after DispenseOrderCreate
        rxpdTestScripts.validateRxPDTables();
        //Call staging API and complete the staging process
        rxpdTestScripts.performStaging();
        //Perform Counselling
        rxpdTestScripts.performCounselling();
        //Call the print label API and validate the response
        rxpdTestScripts.printDeliveryLabel();
        //Create the Trip for PO and Update Driver Details
        rxpdTestScripts.createTripForPO();
        //Start and Complete Chain of Custody for Delivery
        rxpdTestScripts.startAndCompleteChainOfCustodyForDelivery();
        //Complete delivery for PO
        rxpdTestScripts.completeDeliveryForPO();
        //Validate Chain of custody report ->  not required as per domain owner confirmation
        // Call RxUpdate with Sale information
        rxpdTestScripts.callRxUpdateWithTransType("SALE");
        // Validate Proof of delivery report -> not required as per domain owner confirmation
        // Reprint the delivery label
        rxpdTestScripts.printDeliveryLabel();

        Reporter.log("Flow executed: label printed, trip created, CoC done, delivery completed, RxUpdate posted, label reprinted.");
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description: Amends flow for staging complete order - Create new Order and Pass previous Order Id and PO Id and New Fill Id
      * Test Case ID: HWPHME2E_5124
      * Author: Pranav(vn59m66)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Amends flow for staging complete order - Create new Order and Pass previous Order Id and PO Id and New Fill Id", priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_5124_Amends_flow(Map<String, String> inputData) {

        int storeNbr = connexusAppUtils.getStoreId();
        rxpdTestScripts.initializeTestCase(false);
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);

        //Converting order to RxPD order
        rxpdTestScripts.dispenseOrderCreation(inputData);
        rxpdTestScripts.validateOrderCreationResponseBody();
        rxpdTestScripts.validateRxPDTables();
        Reporter.log("Complete staging for the PO");
        rxpdTestScripts.performStaging();
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        rxpdTestScripts.dispenseOrderCreationWithExistingPOAndOmsOrderId(inputData,"NewOrder",false);
        rxpdTestScripts.validateRxPDTables();
        Reporter.log("Flow executed: Amends flow for staging complete order");

    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: RxPD Enabled | Single Rx Scheduled Delivery PO - Cancel fill from connexus
     * Test Case ID: HWPHME2E-2937
     * Author: Prashant(vn52our)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "RxPD Enabled | Single Rx Scheduled Delivery PO - Cancel fill from connexus", priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_2937_SingleRxScheduledDeliveryPOCancelFillFromConnexus(Map<String, String> inputData) throws InterruptedException {

        int storeNbr = connexusAppUtils.getStoreId();
        rxpdTestScripts.initializeTestCase(false);
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        //Converting order to RxPD order
        rxpdTestScripts.dispenseOrderCreation(inputData);
        rxpdTestScripts.performStaging();
        rxpdTestScripts.performCounselling();
        rxpdTestScripts.cancelFillFromConnexus();
        rxpdTestScripts.validateRxAndPoStatus(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: With same PO and Omsoder Id the dispense_order_create Api should give 200 ok status.
     * Test Case ID: HWPHME2E-4947
     * Author: Nagarjuna(vn575ve)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "With same PO and Omsoder Id the dispense_order_create Api should give 200 ok status", priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_4947_Validate_Dispense_Order_Create_Api_With_Same_PO_And_Omsoder_Id(Map<String, String> inputData) {

        //Enabling RxPD flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32000", "TRUE");
        rxpdTestScripts.initializeTestCase(flagUpdated);
        int storeNbr = connexusAppUtils.getStoreId();
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        //Converting order to RxPD order
        rxpdTestScripts.dispenseOrderCreation(inputData,"NewOrder",false);
        rxpdTestScripts.dispenseOrderCreationWithExistingPOAndOmsOrderId(inputData,"NewOrder",false);

        Reporter.log("Validated_Dispense_Order_Create_Api_With_Same_PO_And_Omsoder_Id");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Amends flow for staging issues order _line cancel
     * Test Case ID: HWPHME2E-5129
     * Author: Nagarjuna(vn575ve)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Amends flow for staging issues order _line cancel", priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_5129_Amends_Flow_For_Staging_Issues_Order_Line_Cancel(Map<String, String> inputData) {

        //Enabling RxPD flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32000", "TRUE");
        rxpdTestScripts.initializeTestCase(flagUpdated);
        int storeNbr = connexusAppUtils.getStoreId();
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        rxpdTestScripts.dispenseOrderCreation(inputData,"NewOrder",false);
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        rxpdTestScripts.performStaging();
        rxpdTestScripts.performPoCancel(inputData);
        rxpdTestScripts.dispenseOrderCreationWithExistingPOAndOmsOrderId(inputData,"AddNewPoLine",false);
        rxpdTestScripts.validatePoNumberOmsOrderIdAndRxFillId();

        Reporter.log("Validated_Amends_Flow_For_Staging_Issues_Order_Line_Cancel");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Amend Flow For Ready For Staging order
     * Test Case ID: HWPHME2E-4947
     * Author: Nagarjuna(vn575ve)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Amends Flow for ready For Staging order", priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_5121_Amends_Flow_For_Staging_order(Map<String, String> inputData) throws InterruptedException {
        flagUpdated = connexusAppUtils.updateFlagValueBasedOnCode("32000", "TRUE");
        rxpdTestScripts.initializeTestCase(false);
        int storeNbr = connexusAppUtils.getStoreId();
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        rxpdTestScripts.dispenseOrderCreation(inputData,"NewOrder",false);
        Thread.sleep(20000);
        rxpdTestScripts.validateStatusCodeinDispensePOAndToteTrackingTable(inputData);
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        rxpdTestScripts.dispenseOrderCreationWithExistingPOAndOmsOrderId(inputData,"AddNewPoLine",false);
        rxpdTestScripts.validatePoNumberOmsOrderIdAndRxFillId();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: RxPD Enabled | Amends flow for Cancelled order
    * Test Case ID: HWPHME2E-5127
    * Author: Prashant(vn52our)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "RxPD Enabled | Amends flow for Cancelled order", priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_5127_Amends_flow_for_Cancelled_order(Map<String, String> inputData) throws InterruptedException {

        int storeNbr = connexusAppUtils.getStoreId();
        rxpdTestScripts.initializeTestCase(false);
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        //Converting order to RxPD order
        rxpdTestScripts.dispenseOrderCreation(inputData);
        rxpdTestScripts.cancelFillFromConnexus();
        rxpdTestScripts.validateRxAndPoStatus(inputData);
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        rxpdTestScripts.dispenseOrderCreationWithExistingPOAndOmsOrderId(inputData,"AddNewPoLine",false);
        rxpdTestScripts.validateLogDispenseOrderTrackingDetails();
    }

    /*----------------------------------------------------------------------------------------------------------
    * HWPHME2E_2936__Multi Rx Scheduled Delivery PO move to EOD | Fill does not need re-adjudication - TP rx with fill date current and scheduled date > 10 days
    *
    * Pre-Conditions:
    * Flag 32000 set True
    *
    * Author: Diya Steephen(vn58o0i)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Multi Rx Scheduled Delivery PO move to EOD, Fill does not need re-adjudication - TP rx with fill date current and scheduled date > 10 days", priority = 13,
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_2936_Multi_Rx_Scheduled_Delivery_PO_move_to_EOD(Map<String, String> inputData) {
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32000", "TRUE");
        rxpdTestScripts.initializeTestCase(flagUpdated);
        rxpdTestScripts.createMultiRxPatienAndMoveToPickup(inputData, connexusAppUtils.getStoreId(), true);
        rxpdTestScripts.multiRxDispenseOrderCreation(inputData);
        rxpdTestScripts.multiRxRXPDValidation();
        rxpdTestScripts.performStagingForMultiRx();
        rxpdTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        rxpdTestScripts.performCounsellingForMultiRx();
        rxpdTestScripts.createTripForPOMultiRx();
        rxpdTestScripts.startAndCompleteChainOfCustodyForMultiRxDelivery();
        rxpdTestScripts.completeDeliveryForPOMultiRx();
        //Validate Chain of custody report ->  not required as per domain owner confirmation
        rxpdTestScripts.callRxUpdateForMutliRx(inputData);
        // Validate Proof of delivery report -> not required as per domain owner confirmation
        rxpdTestScripts.verifyRxInEODForMultiRx();
    }

    /*----------------------------------------------------------------------------------------------------------
          * Test Description: If PO in DELIVERY ISSUES / DELIVERED/ RETURNED / MISSING / PARTIAL MISSING — 4XX response received.
          * This involves E2E flow starting from patient creation till reprint of delivery label after delivery completion
          * Test Case ID: HWPHME2E-5122
          * Author: Nanthini Munusamy (vn576ph)
          ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "If PO in DELIVERY ISSUES / DELIVERED/ RETURNED / MISSING / PARTIAL MISSING — 4XX response received.", priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_5122_PO_Delivery_Issues_Delivered_Returned_Missing_Partial_Missing_4XX_Response_Received(Map<String, String> inputData) throws JsonProcessingException {

        int storeNbr = connexusAppUtils.getStoreId();
        rxpdTestScripts.initializeTestCase(false);
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        rxpdTestScripts.dispenseOrderCreation(inputData, "NewOrder", false);
        rxpdTestScripts.validateOrderCreationResponseBody();
        //Validate the RXPD tables content after DispenseOrderCreate
        rxpdTestScripts.validateRxPDTables();
        //Call staging API and complete the staging process
        rxpdTestScripts.performStaging();
        rxpdTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //Perform Counselling
        rxpdTestScripts.performCounselling();
        //Call the print label API and validate the response
        rxpdTestScripts.printDeliveryLabel();
        //Create the Trip for PO and Update Driver Details
        rxpdTestScripts.createTripForPO();
        //Start and Complete Chain of Custody for Delivery
        rxpdTestScripts.startAndCompleteChainOfCustodyForDelivery();
        //Complete delivery for PO
        rxpdTestScripts.completeDeliveryForPO();
        //Validate Chain of custody report ->  not required as per domain owner confirmation
        // Call RxUpdate with Sale information
        rxpdTestScripts.callRxUpdateWithTransType("SALE");
        // Validate Proof of delivery report -> not required as per domain owner confirmation
        // Reprint the delivery label
        rxpdTestScripts.printDeliveryLabel();
        //creating dispense order with AddNewPoLine to verify 4xx response
        rxpdTestScripts.dispenseOrderCreation(inputData, "AddNewPoLine", true);

        Reporter.log("Flow executed: label printed, trip created, CoC done, delivery completed, RxUpdate posted, label reprinted.");
    }


    /*----------------------------------------------------------------------------------------------------------
* HWPHME2E_2935__Multi Rx Scheduled Delivery PO move to EOD | Fill does not need re-adjudication - CashPatient rx with fill date current and scheduled date > 10 days
*
* Pre-Conditions:
* Flag 32000 set True
*
* Author: M Mallikarjuna(vn58n9x)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Multi Rx Scheduled Delivery PO move to EOD, Fill does not need re-adjudication - Patient rx with fill date current and scheduled date > 10 days", priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_2935_Multi_Rx_Scheduled_Delivery_move_to_EOD(Map<String, String>inputData)  {
        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32000", "TRUE");
        rxpdTestScripts.initializeTestCase(flagUpdated);
        rxpdTestScripts.createMultiRxPatienAndMoveToPickup(inputData, connexusAppUtils.getStoreId(), false);
        rxpdTestScripts.updateFillIdForMultiRx();
        rxpdTestScripts.multiRxDispenseOrderCreation(inputData);
        rxpdTestScripts.multiRxRXPDValidation();
        rxpdTestScripts.performStagingForMultiRx();
        rxpdTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        rxpdTestScripts.performCounsellingForMultiRx();
        rxpdTestScripts.createTripForPOMultiRx();
        rxpdTestScripts.startAndCompleteChainOfCustodyForMultiRxDelivery();
        rxpdTestScripts.completeDeliveryForPOMultiRx();
        //Validate Chain of custody report ->  not required as per domain owner confirmation
        rxpdTestScripts.callRxUpdateForMutliRx(inputData);
        // Validate Proof of delivery report -> not required as per domain owner confirmation
        rxpdTestScripts.verifyRxInEODForMultiRx();

        Reporter.log("Executed successfully: Validated that for Multi Rx Scheduled Delivery POs moved to EOD, if the patient’s prescription has a current fill date and the scheduled delivery date is more than 10 days later,the fill does not require re-adjudication.");
    }

    /**
     * Test Description: Amends flow for not ready for staging order- readjudication needed
     * Test Case ID: HWPHME2E-5123
     * Author: Nagarjuna(vn575ve)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Amends flow for not ready for staging order- readjudication needed", priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_5123_Amends_Flow_For_Not_Ready_For_Staging_Order_Readjudication_Needed(Map<String, String> inputData) {
        flagUpdated = connexusAppUtils.updateFlagValueBasedOnCode("32000", "TRUE");
        int storeNbr = connexusAppUtils.getStoreId();
        rxpdTestScripts.initializeTestCase(flagUpdated,false);
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        rxpdTestScripts.updateRxFillDateToOneMonthOld();
        rxpdTestScripts.dispenseOrderCreation(inputData,"NewOrder",false,true);
        rxpdTestScripts.dropoffToTillPickUp(inputData,storeNbr);
        rxpdTestScripts.dispenseOrderCreationWithExistingPOAndOmsOrderId(inputData,"AddNewPoLine",false,true);
        rxpdTestScripts.validateFillIdInDispenseTrackingTable();

    }
    @Test(enabled = true, description = "Multi Rx Scheduled Delivery PO move to EOD | Fill needs re-adjudication – expired", priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_2933_Multi_Rx_Scheduled_Fill_Needs_Readjudication_Expired(Map<String, String> inputData) {
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32000", "TRUE");
        rxpdTestScripts.initializeTestCase(flagUpdated);
        rxpdTestScripts.createMultiRxPatienAndMoveToPickup(inputData, connexusAppUtils.getStoreId(), true);
        rxpdTestScripts.updateRxFillDateForOneRx(0);
        rxpdTestScripts.updateRxExpDateToLessThanToday();
        rxpdTestScripts.updateRxFillDateForOneRx(1);
        rxpdTestScripts.createMultiRxPatienAndMoveToPickup(inputData, connexusAppUtils.getStoreId(),false);
        rxpdTestScripts.updateRxFillDateForOneRx(3);
        rxpdTestScripts.multiRxDispenseOrderCreation(inputData);
        rxpdTestScripts.multiRxRXPDValidation();
        rxpdTestScripts.performStagingForMultiRx();
        rxpdTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        rxpdTestScripts.performCounsellingForMultiRx();
        rxpdTestScripts.createTripForPOMultiRx();
        rxpdTestScripts.startAndCompleteChainOfCustodyForMultiRxDelivery();
        rxpdTestScripts.completeDeliveryForPOMultiRx();
        //Validate Chain of custody report ->  not required as per domain owner confirmation
        rxpdTestScripts.callRxUpdateForMutliRx(inputData);
        // Validate Proof of delivery report -> not required as per domain owner confirmation
    }
    @Test(enabled = true, description = "RxPD Enabled | Multi Rx Scheduled Delivery PO move to EOD | Fill needs re-adjudication - not expired", priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_2934_Multi_Rx_Scheduled_Fill_Needs_Readjudication_not_expired(Map<String, String> inputData) {
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32000", "TRUE");
        rxpdTestScripts.initializeTestCase(flagUpdated);
        rxpdTestScripts.createMultiRxPatienAndMoveToPickup(inputData, connexusAppUtils.getStoreId(), true);
        rxpdTestScripts.updateRxFillDateForOneRx(0);
        rxpdTestScripts.updateRxExpDateToPastYear();
        rxpdTestScripts.updateRxFillDateForOneRx(1);
        rxpdTestScripts.multiRxDispenseOrderCreation(inputData);
        rxpdTestScripts.multiRxRXPDValidation();
        rxpdTestScripts.performStagingForMultiRx();
        rxpdTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        rxpdTestScripts.performCounsellingForMultiRx();
        rxpdTestScripts.createTripForPOMultiRx();
        rxpdTestScripts.startAndCompleteChainOfCustodyForMultiRxDelivery();
        rxpdTestScripts.completeDeliveryForPOMultiRx();
        //Validate Chain of custody report ->  not required as per domain owner confirmation
        rxpdTestScripts.callRxUpdateForMutliRx(inputData);
        // Validate Proof of delivery report -> not required as per domain owner confirmation
    }

    /**
     * Test Description: Amends flow for staging issues order.
     * Test Case ID: HWPHME2E-5125
     * Author: Nagarjuna(vn575ve)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Amends flow for staging issues order", priority = 18, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_5125_Amends_Flow_For_Staging_Issues_Order(Map<String, String> inputData) throws InterruptedException {
        flagUpdated = connexusAppUtils.updateFlagValueBasedOnCode("32000", "TRUE");
        int storeNbr = connexusAppUtils.getStoreId();
        rxpdTestScripts.initializeTestCase(flagUpdated,false);
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        rxpdTestScripts.dispenseOrderCreation(inputData,"NewOrder",false);
        rxpdTestScripts.performStaging();
        rxpdTestScripts.loginConnexus();
        rxpdTestScripts.openRxInModifyScreenAndModifyQty(inputData);
        rxpdTestScripts.validateRxAndPoStatus(inputData);
        rxpdTestScripts.dropoffToTillPickUp(inputData,storeNbr);
        rxpdTestScripts.dispenseOrderCreationWithExistingPOAndOmsOrderId(inputData,"AddNewPoLine",false);
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description: Amends flow for staging issues order PO cancel - Create new Order and Pass previous Order Id and PO Id and New Fill Id
      * Test Case ID: HWPHME2E_5126
      * Author: Pranav(vn59m66)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Amends flow for PO_Cancel complete order - Create new Order and Pass previous Order Id and PO Id and New Fill Id", priority = 19, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_5126_Amends_flow_PO_Cancel (Map<String, String> inputData) {

        int storeNbr = connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.updateFlagValueBasedOnCode("32000", "TRUE");
        rxpdTestScripts.initializeTestCase(false);
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        rxpdTestScripts.dispenseOrderCreation(inputData, "NewOrder", false);
        rxpdTestScripts.validateOrderCreationResponseBody();
        //Call staging API and complete the staging process
        rxpdTestScripts.performStaging();
        rxpdTestScripts.DispenseSlotStartTimeUpdated();
        Reporter.log("Shell script steps for dispatcher issue insertion is not to be implemented as per TC Owner");
        Reporter.log("Hit the PO Cancel API");
        rxpdTestScripts.performPoCancel(inputData);
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        rxpdTestScripts.dispenseOrderCreationWithExistingPOAndOmsOrderId(inputData,"AddNewPoLine",false,false);
        Reporter.log("Dispense Order Creation API Executed with existing PO and OMS ID and new fill id.");
        rxpdTestScripts.validateFillIdInDispenseTrackingTable();
        Reporter.log("New Fill-Id is validated while RxPD Table Validation");
        Reporter.log("Flow executed: Amends flow for PO Cancel");
    }

    /*----------------------------------------------------------------------------------------------------------
      * Test Description: Signature_on_Delivery_REPORT
      * Test Case ID: HWPHME2E-3186
      * Author: kruthika(vn59ehu)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Signature_On_Delivery_report", priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/" + "RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_3186_Signature_On_Delivery_report(Map<String, String> inputData) {

        int storeNbr = connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.updateFlagValueBasedOnCode("32000", "TRUE");
        rxpdTestScripts.initializeTestCase(false);
        rxpdTestScripts.createRxPatientAndMoveToPickup(inputData, storeNbr,true);
        rxpdTestScripts.dispenseOrderCreation(inputData, "NewOrder", false);
        //Validate the RXPD tables content after DispenseOrderCreate
        rxpdTestScripts.validateRxPDTables();
        //Call staging API and complete the staging process
        rxpdTestScripts.performStaging();
        //Create the Trip for PO and Update Driver Details
        rxpdTestScripts.createTripForPO();
        //Start and Complete Chain of Custody for Delivery
        rxpdTestScripts.startAndCompleteChainOfCustodyForDelivery();
    }

    /**
     * Test Case: Validate staging process with bag assignment
     * Description: This test simulates the staging workflow for an RXPD order, including bag assignment validation.
     * @param inputData
     * Expected Result: The system should allow staging progression and return an error when assigning a bag already linked to another order.
     */
    @Test(enabled = true, description = "Verify that the WCB assigned to counter pickup dispense method can be used during complete staging flow", priority = 23, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_5251_validateWcbAssignmentDuringCounterPickupStaging(Map<String, String> inputData) {
        int storeNbr = connexusAppUtils.getStoreId();
        rxpdTestScripts.initializeTestCase(false);
        rxpdTestScripts.createPatientAndMoveToPickup(inputData, storeNbr);
        //Converting order to RxPD order
        rxpdTestScripts.dispenseOrderCreation(inputData);
        rxpdTestScripts.validateRxPDTables();
        Reporter.log("Complete staging for the PO");
        rxpdTestScripts.performStaging();
        rxpdTestScripts.createPatientAndMoveToPickup(inputData, storeNbr);
        //Converting order to RxPD order
        rxpdTestScripts.dispenseOrderCreation(inputData);
        rxpdTestScripts.validateRxPDTables();
        rxpdTestScripts.validateStagingProcessWithBagAssignment();
    }


    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Verify the refund flow when the rxpd order is returned back to the store
    * Test Case ID: HWPHME2E-5457
    * Author: Lavanya(vn575up)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify the refund flow when the rxpd order is returned back to the store",
            priority = 24, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_5457_Verify_the_refund_flow_when_the_rxpd_order_is_returned_back_to_the_store(Map<String, String> inputData) {
        Reporter.log("Verify the refund flow when the rxpd order is returned back to the store");
        //Pre-condition
        int storeNbr = connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32000", "TRUE");
        flagUpdated = connexusAppUtils.readAndUpdateFlag("9360", "TRUE");
        flagUpdated = connexusAppUtils.readAndUpdateFlag("32106", "TRUE");
        rxpdTestScripts.initializeTestCase(true, false);

        // Steps
        rxpdTestScripts.createPatientAndMoveToPickup(inputData, storeNbr);
        //Create the RXPD order and take the order till EOD - Able to take the order till EOD
        rxpdTestScripts.dispenseOrderCreation(inputData, "NewOrder", false);
        //Call staging API and complete the staging process
        rxpdTestScripts.performStaging();
        //Perform Counselling using API
        rxpdTestScripts.performCounselAPI();
        //--below all steps until transfer type Sale are performing EOD through RXPD flow--
        //Call the print label API and validate the response
        rxpdTestScripts.printDeliveryLabel();
        //Create the Trip for PO and Update Driver Details
        rxpdTestScripts.createTripForPO();
        //Start and Complete Chain of Custody for Delivery
        rxpdTestScripts.startAndCompleteChainOfCustodyForDelivery();
        //Complete delivery for PO
        rxpdTestScripts.completeDeliveryForPO();
        // Call RxUpdate with Sale information - order move to EOD
        rxpdTestScripts.callRxUpdateWithTransType("SALE");
        // perform initiate the refund and able to see that Void str is printed
        rxpdTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        rxpdTestScripts.performRefundReFillMenuOptionsFromCurrentRXInF7();
        // Call RxUpdate with Refund information
        rxpdTestScripts.callRxUpdateWithTransType("REFUND");
        //Updating any quantity in the Modify Details in pos and new fill id is created
        rxpdTestScripts.performPOSModifyQty(inputData);
        // Validate that new fill id is created after modify in POS
        rxpdTestScripts.validateNewFillIdCreatedAfterModifyInPOS();
        // Print the str - New str gets printed with no Void at register -> not required as per domain owner confirmation
        Reporter.log("Verified the refund flow when the rxpd order is returned back to the store");
    }

    /*----------------------------------------------------------------------------------------------------------
   * Test Description: Verify that once the order is delivered we are not able to modify the details for that order in CNX.
   * Test Case ID: HWPHME2E_5458
   * Author: Diya Steephen(vn58o0i)
  ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify that once the order is delivered we are not able to modify the details for that order in CNX", priority = 20, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RXPD/RXPD.json", sheetName = "RXPD")
    public void HWPHME2E_5458_Verify_That_Once_Order_Is_Delivered_The_Details_Cannot_Be_Modified(Map<String, String> inputData){
        int storeNbr = connexusAppUtils.getStoreId();
        rxpdTestScripts.initializeTestCase(false, false);
        //Create Patient with TP using API and move to pickup
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        //Converting order to RxPD order
        rxpdTestScripts.dispenseOrderCreation(inputData);
        //Validate the RXPD tables content after DispenseOrderCreate
        rxpdTestScripts.validateRxPDTables();
        //Call staging API and complete the staging process
        rxpdTestScripts.performStaging();
        //Perform Counselling
        rxpdTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        rxpdTestScripts.performCounselling();
        //Call the print label API and validate the response
        rxpdTestScripts.printDeliveryLabel();
        //Create the Trip for PO and Update Driver Details
        rxpdTestScripts.createTripForPO();
        //Start and Complete Chain of Custody for Delivery
        rxpdTestScripts.startAndCompleteChainOfCustodyForDelivery();
        //Complete delivery for PO
        rxpdTestScripts.completeDeliveryForPO();
        //Validate Chain of custody report ->  not required as per domain owner confirmation
        // Call RxUpdate with Sale information
        rxpdTestScripts.callRxUpdateWithTransType("SALE");
        // Validate Proof of delivery report -> not required as per domain owner confirmation
        // Reprint the delivery label not required for this tc as per domain owner confirmation
        //Open order in modify details screen and validate the popup
        rxpdTestScripts.validateModificationNotAllowedPopup();
        Reporter.log("Modification not allowed popup is displayed as expected");
    }
}