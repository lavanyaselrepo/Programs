package connexus.Inventory_Testcases.testcases;

import connexus.Inventory_Testcases.testScripts.Inventory_TestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class Inventory_Testcases {
    
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ConnexusAPIManager connexusAPIManager=new ConnexusAPIManager();
    public static LoginAs.userType loginUserType = LoginAs.userType.PHARMACIST_ADFlagOff;
    Inventory_TestScripts inventoryTestScripts=new Inventory_TestScripts(loginUserType);
    PropertyReader prop = PropertyReader.getInstance();

    @BeforeClass
    public void performlogin() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }


    /**
     * Validate open and close task in Connexus.
     *
     */
    //@Jira(testID = "HWPHME2E-1411")//@Jira(testID = "HWPHME2E-1414")
    @Test(enabled = true, description = "Event Task Service | Initiate a Transfer | Opens and close a Task at Sending Store | Verify the Task open and close in Connexus", priority = 1)
    public void HWPHME2E_1411_1414_Open_And_Close_task() {
        inventoryTestScripts.initializeTestCase(false);
        connexusAppUtils.getStoreId();
        String siteId = prop.getProperty("cnx.store");
        String eventId = String.valueOf(connexusAppUtils.randomNumber());
        String openTaskItemName = prop.getProperty("fom.Item_Name_INV");
        String active_Status_Open_Task = prop.getProperty("fom.Active_Status_Open_Task_INV");
        String requestType=prop.getProperty("fom.RequestType_INV");
        connexusAPIManager.openAndCloseTaskForInventory(requestType,active_Status_Open_Task,siteId,eventId);
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.TASKS, AppMenuItemsIndex.TOOLS_TASKS, null, null);
        inventoryTestScripts.validateEventIdInTaskUnderTools(eventId,openTaskItemName);
        String active_Status_Close_Task = prop.getProperty("fom.Active_Status_Close_Task_INV");
        connexusAPIManager.openAndCloseTaskForInventory(requestType,active_Status_Close_Task,siteId,eventId);
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.TASKS, AppMenuItemsIndex.TOOLS_TASKS, null, null);
        inventoryTestScripts.validateEventIdInTaskUnderTools(eventId,openTaskItemName);
    }

    /**
     * Validate In trnasit task in Connexus.
     *
     */
    //@Jira(testID = "HWPHME2E-1412")//@Jira(testID = "HWPHME2E-1413")
    @Test(enabled = true, description = "Event Task Service | Initiate a Transfer | Opens and close a Task at Sending Store| Initiate InTransit Event at Receiving Store | Verify the Transit Event is opened Connexus", priority = 2)
    public void HWPHME2E_1412_1413_InTransit_and_Delivered() {
        inventoryTestScripts.initializeTestCase(false);
        connexusAppUtils.getStoreId();
        String recvsiteId = prop.getProperty("cnx.store");
        String sourcesiteId = prop.getProperty("fom.cnx.Sourcestore");
        String eventId = String.valueOf(connexusAppUtils.randomNumber());
        String active_Status_Open_Task = prop.getProperty("fom.Active_Status_Open_Task_INV");
        String inTransitItemName = prop.getProperty("fom.inv.itemName");
        String activityType = prop.getProperty("fom.inv.inTransitActivityType");
        String deliveredActivityType = prop.getProperty("fom.inv.deliveredActivityType");
        String requestType=prop.getProperty("fom.RequestType_INV");
        connexusAPIManager.openAndCloseTaskForInventory(requestType,active_Status_Open_Task,sourcesiteId,eventId);
        connexusAPIManager.inTransitAndDeliveredForInventory(activityType,sourcesiteId,recvsiteId,eventId);
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.TASKS, AppMenuItemsIndex.TOOLS_TASKS, null, null);
        inventoryTestScripts.validateEventIdInTaskUnderTools(eventId,inTransitItemName);
        connexusAPIManager.inTransitAndDeliveredForInventory(deliveredActivityType,sourcesiteId,recvsiteId,eventId);
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.TASKS, AppMenuItemsIndex.TOOLS_TASKS, null, null);
        inventoryTestScripts.validateEventIdRemovalInTaskUnderTools(eventId,inTransitItemName);
        String active_Status_Close_Task = prop.getProperty("fom.Active_Status_Close_Task_INV");
        connexusAPIManager.openAndCloseTaskForInventory(requestType,active_Status_Close_Task,sourcesiteId,eventId);
    }

    /**
     * Validate open and close Return task in Connexus.
     *
     */
    //@Jira(testID = "HWPHME2E-4632")//@Jira(testID = "HWPHME2E-24633")
    @Test(enabled = true, description = "Event Task Service | Initiate a Transfer | Opens and close a Return Task at Sending Store | Verify the Task open and close in Connexus", priority = 3)
    public void HWPHME2E_4632_4633_Open_And_Close_Return_Task() {
        inventoryTestScripts.initializeTestCase(false);
        connexusAppUtils.getStoreId();
        String siteId = prop.getProperty("cnx.store");
        String eventId = String.valueOf(connexusAppUtils.randomNumber());
        String openTaskItemName = prop.getProperty("fom.Item_Name_Return_INV");
        String active_Status_Open_Task = prop.getProperty("fom.Active_Status_Open_Task_INV");
        String requestType=prop.getProperty("fom.Return.RequestType_INV");
        connexusAPIManager.openAndCloseTaskForInventory(requestType,active_Status_Open_Task,siteId,eventId);
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.TASKS, AppMenuItemsIndex.TOOLS_TASKS, null, null);
        inventoryTestScripts.validateEventIdInTaskUnderTools(eventId,openTaskItemName);
        String active_Status_Close_Task = prop.getProperty("fom.Active_Status_Close_Task_INV");
        connexusAPIManager.openAndCloseTaskForInventory(requestType,active_Status_Close_Task,siteId,eventId);
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.TASKS, AppMenuItemsIndex.TOOLS_TASKS, null, null);
        inventoryTestScripts.validateEventIdRemovalInTaskUnderTools(eventId,openTaskItemName);
    }

    /**
     * Validate Cycle count report page validation.
     *
     */
    //@Jira(testID = "HWPHME2E-1435")
    @Test(enabled = true, description = "Inventory Report | Cycle Count Reports page validation", priority = 4,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Inventory/Inventory.json", sheetName = "Inventory")
    public void HWPHME2E_1435_Cycle_Count_Report_Page_Validation(Map<String, String> inputData) {
        inventoryTestScripts.initializeTestCase(false);
        connexusAppUtils.getStoreId();
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.CYCLE_COUNT, AppMenuItemsIndex.INVENTORY_REPORTS, AppMenuSubItemsIndex.CYCLE_COUNT_REPORT, null);
        inventoryTestScripts.validateCycleCountReportHeader(inputData);
    }

    /**
     * Validate Return to Inmar or McKesson Report.
     *
     */
    //@Jira(testID = "HWPHME2E-1438")
    @Test(enabled = true, description = "Inventory Report | Return to Inmar or McKesson Report", priority = 5,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Inventory/Inventory.json", sheetName = "Inventory")
    public void HWPHME2E_1438_Return_To_Inmar_Or_McKesson_Report(Map<String, String> inputData) {
        inventoryTestScripts.initializeTestCase(false);
        connexusAppUtils.getStoreId();
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.RETURN_TO_INMAR_MCKES, AppMenuItemsIndex.INVENTORY_REPORTS, AppMenuSubItemsIndex.CII_REPORTS, AppMenuSuperSubItemsIndex.RETURN_TO_INMAR_MCKES);
        inventoryTestScripts.validateReturnToInmarMckesPageAndSubmitByProvidingDetails(inputData);
        inventoryTestScripts.validateOnHandQuantityAdjustmentInItemMaintenanceHistoryPage(inputData,false);
    }

    /**
     * Validate OnHands Inventory Detailed Report.
     *
     */
    //@Jira(testID = "HWPHME2E-1439")
    @Test(enabled = true, description = "Inventory Report | OnHands Inventory Detailed Report", priority = 6,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Inventory/Inventory.json", sheetName = "Inventory")
    public void HWPHME2E_1439_OnHand_Inventory_Detailed_Report(Map<String, String> inputData) {
        inventoryTestScripts.initializeTestCase(false);
        connexusAppUtils.getStoreId();
        inventoryTestScripts.updateOnHandQuantityInItemMaintenancePage(inputData,true);
        inventoryTestScripts.validateUpdatedOnHandQuantityInProductScreen(inputData);
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.CURRENT_ONHAND_INVENTORY, AppMenuItemsIndex.INVENTORY_REPORTS, AppMenuSubItemsIndex.CURRENT_ONHAND_INVENTORY, null);
        inventoryTestScripts.validateOnHandInventoryDetailedReport(inputData);
    }

    /**
     * Inventory Report | OnHands Inventory History Report
     * @param inputData
     */
    //@Jira(testID = "HWPHME2E-1434")
    @Test(enabled = true, description = "Inventory Report | OnHands Inventory History Report", priority =7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Inventory/Inventory.json", sheetName = "Inventory")
    public void HWPHME2E_1434_OnHand_Inventory_History_Report(Map<String, String> inputData) {
        inventoryTestScripts.initializeTestCase(false);
        connexusAppUtils.getStoreId();
        inventoryTestScripts.updateOnHandQuantityInItemMaintenancePage(inputData, true);
        inventoryTestScripts.validateOnHandQuantityAdjustmentInItemMaintenanceHistoryPage(inputData, true);
        inventoryTestScripts.updateOnHandQuantityInItemMaintenancePage(inputData, false);
        inventoryTestScripts.validateOnHandQuantityAdjustmentInItemMaintenanceHistoryPage(inputData, false);
    }

    /**
     * Validate OnHands Inventory History Report for Prescription Filled and Cancelled Fill type for 38N drug.
     */
    //@Jira(testID = "HWPHME2E-1434")
    @Test(enabled = true, description = "Inventory Report | OnHands Inventory History Report for Fillid and Cancelled Prescriptions for 38N drug", priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Inventory/Inventory.json", sheetName = "Inventory")
    public void HWPHME2E_4652_OnHand_Inventory_Filled_Cancelled_Prescription_History_Report_For_38N_Drug(Map<String, String> inputData) {
        inventoryTestScripts.initializeTestCase(false);
        Reporter.log("<<<OnHand_Inventory_Filled_Cancelled_Prescription_History_Report_For_38N_Drug>>");
        connexusAppUtils.getStoreId();
        inventoryTestScripts.createNewPatient(inputData);
        inventoryTestScripts.performDropOff(Priority.Critical);
        inventoryTestScripts.performInput(inputData);
        inventoryTestScripts.perform4Point(true);
        inventoryTestScripts.performFilling();
        inventoryTestScripts.validatePrescriptionFilledAndCancelledFillInItemMaintenanceHistoryPage(inputData,false);
        inventoryTestScripts.performVisualVerify();
        inventoryTestScripts.cancelFilledPrescription();
        inventoryTestScripts.validatePrescriptionFilledAndCancelledFillInItemMaintenanceHistoryPage(inputData,true);
    }

    /**
     * Validate OnHands Inventory History Report for Prescription Filled and Cancelled Fill type for 38Y drug.
     */
    //@Jira(testID = "HWPHME2E-4653")
    @Test(enabled = true, description = "Inventory Report | OnHands Inventory History Report for Fillid and Cancelled Prescriptions for 38Y drug", priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Inventory/Inventory.json", sheetName = "Inventory")
    public void HWPHME2E_4653_OnHand_Inventory_Filled_Cancelled_Prescription_History_Report_For_38Y_Drug(Map<String, String> inputData) {
        inventoryTestScripts.initializeTestCase(false);
        Reporter.log("<<<OnHand_Inventory_Filled_Cancelled_Prescription_History_Report_For_38Y_Drug>>");
        connexusAppUtils.getStoreId();
        inventoryTestScripts.createNewPatient(inputData);
        inventoryTestScripts.performDropOff(Priority.Critical);
        inventoryTestScripts.performInput(inputData);
        inventoryTestScripts.perform4Point(true);
        inventoryTestScripts.performFilling();
        inventoryTestScripts.validatePrescriptionFilledAndCancelledFillInItemMaintenanceHistoryPage(inputData,false);
        inventoryTestScripts.performVisualVerify();
        inventoryTestScripts.cancelFilledPrescription();
        inventoryTestScripts.validatePrescriptionFilledAndCancelledFillInItemMaintenanceHistoryPage(inputData,true);
    }

    //@Jira(testID = "HWPHME2E-1441")
    @Test(enabled = true, description = "Inventory Report | CII Manual Adjustment Report", priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Inventory/Inventory.json", sheetName = "Inventory")
    public void HWPHME2E_1441_Inventory_CII_Manual_Adjustment_Report(Map<String, String> inputData) {
        inventoryTestScripts.initializeTestCase(false);
        connexusAppUtils.getStoreId();
        inventoryTestScripts.updateOnHandQuantityInItemMaintenancePage(inputData, true);
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.CII_ADJUSTMENT, AppMenuItemsIndex.INVENTORY_REPORTS, AppMenuSubItemsIndex.CII_REPORTS, AppMenuSuperSubItemsIndex.CII_ADJUSTMENTS);
        inventoryTestScripts.validatePageTitle();
        inventoryTestScripts.validateNdcPresenceInCIIAdjustmentReportPage(inputData);
    }

    /** === These tese steps are need to be reviewed ===
     * Inventory Cycle Count | Validate the Inventory Cycle Count Connexus Report | Login as Pharmacist |
     */
    //@Jira(testID = "HWPHME2E-4634")
    @Test(enabled = true, description = "Inventory Cycle Count | Validate the Inventory Cycle Count Connexus Report | Login as Pharmacist |", priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Inventory/Inventory.json", sheetName = "Inventory")
    public void HWPHME2E_4634_Cycle_Count_Report(Map<String, String> inputData) {
        inventoryTestScripts.initializeTestCase(false);
        connexusAppUtils.getStoreId();
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.CYCLE_COUNT, AppMenuItemsIndex.INVENTORY_REPORTS, AppMenuSubItemsIndex.CYCLE_COUNT_REPORT, null);
        inventoryTestScripts.validateCycleCountReportHeader(inputData);
    }

    //@Jira(testID = "HWPHME2E-4654")
    @Test(enabled = true, description = "Inventory Reports | Inventory History Report | Cycle Count", priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Inventory/Inventory.json", sheetName = "Inventory")
    public void HWPHME2E_4654_Inventory_History_Report_For_CycleCount(Map<String, String> inputData) {
        inventoryTestScripts.initializeTestCase(false);
        connexusAppUtils.getStoreId();
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.CYCLE_COUNT, AppMenuItemsIndex.INVENTORY_REPORTS, AppMenuSubItemsIndex.CYCLE_COUNT_REPORT, null);
        inventoryTestScripts.processCycleCountSndCloseWindow();
        inventoryTestScripts.updateOnHandQuantityInItemMaintenancePage(inputData, true);
        inventoryTestScripts.validateOnHandQuantityAdjustmentInItemMaintenanceHistoryPage(inputData, true);
    }

    //@Jira(testID = "HWPHME2E-241")
    @Test(enabled = true, description = "Verify whether the Mandatory Blank column names are displayed in All Control Schedules \"Controlled substance inventory report\" to allow Rph to write in Total quantities",
            priority = 13)
    public void HWPHME2E_241_Controlled_Substance_Inventory_Report_For_Rph_User() {
        Reporter.log("Verify whether the Mandatory Blank column names are displayed in All Control Schedules Controlled substance inventory report to allow Rph to write in Total quantities");
        inventoryTestScripts.initializeTestCase(false);
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.CONTROLLED_SUBSTANCE_INVENTORY, AppMenuItemsIndex.INVENTORY_REPORTS, AppMenuSubItemsIndex.CONTROLLED_SUBSTANCE_INVENTORY_REPORT,null);
        inventoryTestScripts.selectAuditTypeAnsClickOnSearchButton();
        inventoryTestScripts.validateTableHasMoreThanZeroRowsAndDataPresent();
        inventoryTestScripts.openReportByClickingOnShowReportButton();

        Reporter.log("Controlled inventory report displayed with show report button and different columns without blank data");
    }

    //@Jira(testID = "HWPHME2E-240")
    @Test(enabled = true, description = "Verify whether the Mandatory Blank column names are displayed in All Control Schedules \"Controlled substance inventory report\" to allow Rph to write in Total quantities",
            priority = 14)
    public void HWPHME2E_240_Controlled_Substance_Inventory_Report() {
        inventoryTestScripts.setLoginUserType(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        inventoryTestScripts.initializeTestCase(false);
        Reporter.log("Verify whether the Mandatory Blank column names are displayed in All Control Schedules Controlled substance inventory report to allow Rph to write in Total quantities");
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.CONTROLLED_SUBSTANCE_INVENTORY, AppMenuItemsIndex.INVENTORY_REPORTS, AppMenuSubItemsIndex.CONTROLLED_SUBSTANCE_INVENTORY_REPORT,null);
        inventoryTestScripts.selectAuditTypeAnsClickOnSearchButton();
        inventoryTestScripts.validateTableHasMoreThanZeroRowsAndDataPresent();
        inventoryTestScripts.openReportByClickingOnShowReportButton();

        Reporter.log("Controlled inventory report displayed with show report button and different columns without blank data");
    }

    /**
     * Cycle count report for Technician Login
     */
    //@Jira(testID = "HWPHME2E-4672")
    @Test(enabled = true, description = "Inventory Cycle Count | Validate the Inventory Cycle Count Connexus Report | Login as Tehnician |", priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Inventory/Inventory.json", sheetName = "Inventory")
    public void HWPHME2E_4672_Cycle_Count_Report_TechnicianLogin(Map<String, String> inputData) {
        inventoryTestScripts.setLoginUserType(LoginAs.userType.TECHNICIAN_ADFlagOff);
        inventoryTestScripts.initializeTestCase(false);
        connexusAppUtils.getStoreId();
        inventoryTestScripts.menuBar.selectNavigation(AppMenu.CYCLE_COUNT, AppMenuItemsIndex.INVENTORY_REPORTS, AppMenuSubItemsIndex.CYCLE_COUNT_REPORT, null);
        inventoryTestScripts.validateCycleCountReportHeader(inputData);
    }

    /**
     * Cycle Count | Resolving the Cycle Count for Non-CII | Increments or Decrements the On Hands Qty OR If the Entered Qty Matches with System Qty then It will Not adjust any Qty
     */
    //@Jira(testID = "HWPHME2E-1428")
    @Test(enabled = true, description = "Cycle Count | Resolving the Cycle Count for Non-CII | Increments or Decrements the On Hands Qty OR If the Entered Qty Matches with System Qty then It will Not adjust any Qty", priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Inventory/Inventory.json", sheetName = "Inventory")
    public void HWPHME2E_1428_ResolvingCycleCountForNonCII(Map<String, String> inputData) {
        inventoryTestScripts.initializeTestCase(false);
        connexusAppUtils.getStoreId();
        //Resolving Increments Cycle Count For NonCII
        inventoryTestScripts.validateResolvingCycleCountForNonCII(inputData,10);
        //Resolving Decrements Cycle Count For NonCII
        inventoryTestScripts.validateResolvingCycleCountForNonCII(inputData,-10);
        //Skip Adjustment If Entered Qty Matches Cycle Count For Non CII
        inventoryTestScripts.validateResolvingCycleCountForNonCII(inputData,0);
    }
    /**
     * Cycle Count | Resolving the Cycle Count for CII | Increments or Decrements the On Hands Qty OR If the Entered Qty Matches with System Qty then It will Not adjust any Qty
     */
    //@Jira(testID = "HWPHME2E-1429")
    @Test(enabled = true, description = "Cycle Count | Resolving the Cycle Count for CII | Increments or Decrements the On Hands Qty OR If the Entered Qty Matches with System Qty then It will Not adjust any Qty", priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Inventory/Inventory.json", sheetName = "Inventory")
    public void HWPHME2E_1429_ResolvingCycleCountForCII(Map<String, String> inputData) {
        inventoryTestScripts.initializeTestCase(false);
        inventoryTestScripts.validateAllCycleCountOperationsForCII(inputData);
        Reporter.log("All Three Operations Completed Successfully");
    }
}