package connexus.Inventory_Testcases.testScripts;

import com.aventstack.extentreports.Status;
import com.github.sardine.model.Report;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Inventory.AddNDCToCycleCountPageCountList;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.appium.java_client.AppiumBy;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Inventory_TestScripts extends ConnexusTestScripts {
    int previousOnHandQuantity;
    int newOnHandQuantity;
    int actualOnHandQuantity;
    PropertyReader prop = PropertyReader.getInstance();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();

    public Inventory_TestScripts(LoginAs.userType loginUserType){
        super(loginUserType);
    }

    /**
     * This method will validate event is logged in connexus.
     * @param eventId
     */
    public void validateEventIdInTaskUnderTools(String eventId, String inTransitItemName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            List<WebElement> itemList = menuBar.getItemList();
            String eventDescription;
            int i = 0;
            for (WebElement item : itemList) {
                if (item.getText().equalsIgnoreCase(inTransitItemName)) {
                    eventDescription = menuBar.getItemDescription(i);
                    if (eventDescription.contains(eventId)) {
                        Assert.assertTrue(true, "task created");
                        Reporter.log("Event record is available under tasks");
                        menuBar.clickOnEvent(item);
                        Reporter.logScreenShot(Status.PASS, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
                        Reporter.log("Event id is" + eventId);
                        break;
                    } else if (i == itemList.size()) {
                        Reporter.log("Event id not logged");
                        Reporter.logScreenShot(Status.FAIL, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
                        Assert.fail("Task not created");
                    }
                }
                i++;
            }
            connexusStartPage.pressEscapeKey();
        }catch(Throwable e){
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Tasks page not opened");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * This method will validate event is Removed in connexus.
     * @param eventId
     */
    public void validateEventIdRemovalInTaskUnderTools(String eventId, String itemName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            List<WebElement> itemList = menuBar.getItemList();
            String eventDescription;
            int i = 0;
            for (WebElement item : itemList) {
                if (item.getText().equalsIgnoreCase(itemName)) {
                    eventDescription = menuBar.getItemDescription(i);
                    if (eventDescription.contains(eventId)) {
                        Reporter.log("Task is not removed for" + eventId);
                        Reporter.logScreenShot(Status.PASS, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
                        Assert.fail("Task not removed");
                    } else if (i == itemList.size()) {
                        Reporter.logScreenShot(Status.PASS, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
                        Assert.assertTrue(true, "Task is removed");
                        Reporter.log("Task is removed for" + eventId);
                        break;
                    }
                } else {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
                    Assert.assertTrue(true, "Task is removed");
                    Reporter.log("Task is removed for" + eventId);
                    break;
                }
                i++;
            }
            connexusStartPage.pressEscapeKey();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Tasks page not opened");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * Validating Cycle Count Report page header.
     */
    public void validateCycleCountReportHeader(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (returnToInmarMckesPage.getPageTitleText().equalsIgnoreCase(inputData.get("PAGE_HEADER"))) {
                Reporter.log("Cycle Count Report page opened");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                cycleCountReportPage.clickClose();

            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Cycle Count report page opened");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Title not matching");
        }
    }

    /**
     * Validate Return to Inmar/Mckes page and submit by providing Required details.
     */
    public void validateReturnToInmarMckesPageAndSubmitByProvidingDetails(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (returnToInmarMckesPage.getPageTitleText().equalsIgnoreCase(inputData.get("PAGE_HEADER"))) {
                previousOnHandQuantity = (int) Double.parseDouble(connexusAppUtils.getOnHandQuantity(inputData.get("NDC_NUMBER").replaceAll("-", "")));
                if (previousOnHandQuantity < Integer.parseInt(inputData.get("REMAINING_QUANTITY"))) {
                    connexusAppUtils.updateOnhandQuantity(inputData.get("NDC_NUMBER").replaceAll("-", ""));
                    previousOnHandQuantity = (int) Double.parseDouble(connexusAppUtils.getOnHandQuantity(inputData.get("NDC_NUMBER").replaceAll("-", "")));
                }
                returnToInmarMckesPage.inputDeaNumber(inputData.get("DEA_NUMBER"));
                returnToInmarMckesPage.ReEnterDeaNumber(inputData.get("DEA_NUMBER"));
                returnToInmarMckesPage.EnterNdcNumber(inputData.get("NDC_NUMBER").replaceAll("-", ""));
                returnToInmarMckesPage.EnterQuantity(inputData.get("REMAINING_QUANTITY"));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                returnToInmarMckesPage.clickSubmitButton();
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Title not matching");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Title not matching");
        }
    }

    /**
     * Validate on hand quantity adjustment in item maintenance history page.
     * @param inputData
     */
    public void validateOnHandQuantityAdjustmentInItemMaintenanceHistoryPage(Map<String, String> inputData, boolean adjustmentType) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            productSearchPage.launchProductSearchScreen();
            productSearchPage.enterProductNDC(inputData.get("NDC_NUMBER"));
            productSearchPage.clickSearchNow();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.doubleClickOnSearchGridRow(0);
            List<WebElement> itemList = productSearchPage.getNDCList();
            for (int i = 0; i < itemList.size(); i++) {
                if (itemList.get(i).getText().equalsIgnoreCase(inputData.get("NDC_NUMBER"))) {
                    actualOnHandQuantity = Integer.parseInt(productSearchPage.getOnHandQuantity(i));
                    newOnHandQuantity = (int) Double.parseDouble(connexusAppUtils.getOnHandQuantity(inputData.get("NDC_NUMBER").replaceAll("-", "")));
                    Assert.assertEquals(actualOnHandQuantity, newOnHandQuantity, "On hand Quantity not matching");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                    productSearchPage.clickOnNDCNumber(i);
                    break;
                }
            }
            if (productSearchPage.isElementDisplayed(itemMaintenancePage.historyButton, 90)) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                itemMaintenancePage.click(itemMaintenancePage.historyButton);
                itemMaintenancePage.isElementDisplayed(itemMaintenancePage.type, 30);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertEquals(Integer.parseInt(itemMaintenancePage.getText(itemMaintenancePage.preQuantity)), previousOnHandQuantity, "Previous on hand quantity not matching");
                Assert.assertEquals(Integer.parseInt(itemMaintenancePage.getText(itemMaintenancePage.newQuantity)), newOnHandQuantity, "New on hand quantity not matching");
                if (adjustmentType) {
                    Reporter.log("Validating Positive Adjustment History log");
                    Assert.assertEquals(itemMaintenancePage.getText(itemMaintenancePage.type), inputData.get("HISTORY_TYPE"), "Type not matching");
                    Assert.assertEquals(Integer.parseInt(itemMaintenancePage.getText(itemMaintenancePage.diffQuantity)), Integer.parseInt(inputData.get("REMAINING_QUANTITY")), "Difference quantity not matching");
                } else {
                    Reporter.log("Validating Negative Adjustment History log");
                    Assert.assertEquals(itemMaintenancePage.getText(itemMaintenancePage.type), inputData.get("HISTORY_TYPE_NEGATIVE"), "Type not matching");
                    Assert.assertEquals(Integer.parseInt(itemMaintenancePage.getText(itemMaintenancePage.diffQuantity)), -Integer.parseInt(inputData.get("REMAINING_QUANTITY")), "Difference quantity not matching");
                }
                itemMaintenancePage.click(itemMaintenancePage.okButton);
                connexusStartPage.pressEscapeKey();
                patientSearchPage.clickYes();
                itemMaintenancePage.clickAccept();
                connexusStartPage.pressEscapeKey();
                itemMaintenancePage.waitUntillProductScreenClosure();
            } else {
                Assert.fail("History button not displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Inventory History Details not Matching");
        }
    }

    /**
     * Update on hand quantity in Item Maintenance page.
     * @param inputData
     */
    public void updateOnHandQuantityInItemMaintenancePage(Map<String, String> inputData,boolean adjustmentType) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            previousOnHandQuantity= (int)Double.parseDouble(connexusAppUtils.getOnHandQuantity(inputData.get("NDC_NUMBER").replaceAll("-","")));
            productSearchPage.launchProductSearchScreen();
            productSearchPage.enterProductNDC(inputData.get("NDC_NUMBER"));
            productSearchPage.clickSearchNow();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.doubleClickOnSearchGridRow(0);
            List<WebElement> itemList = productSearchPage.getNDCList();
            for (int i=0;i<itemList.size();i++) {
                if (itemList.get(i).getText().equalsIgnoreCase(inputData.get("NDC_NUMBER"))) {
                    actualOnHandQuantity=Integer.parseInt(productSearchPage.getOnHandQuantity(i));
                    Assert.assertEquals(actualOnHandQuantity,previousOnHandQuantity,"On hand Quantity not matching");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                    productSearchPage.clickOnNDCNumber(i);
                    break;
                }
            }
            if(productSearchPage.isElementDisplayed(itemMaintenancePage.historyButton,120)){
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                itemMaintenancePage.clearOnHandDrugQty();
                if(adjustmentType){
                    Reporter.log("POSITIVE ADJUSTMENT");
                    newOnHandQuantity = previousOnHandQuantity + 100;
                }else{
                    Reporter.log("NEGATIVE ADJUSTMENT");
                    newOnHandQuantity = previousOnHandQuantity - 100;
                }
                itemMaintenancePage.inputOnHandDrugQty(String.valueOf(newOnHandQuantity));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                itemMaintenancePage.clickAccept();
                if (itemMaintenancePage.getText(itemMaintenancePage.pageOrRphPopUpTitleBar).contains("R.Ph. Verification")) {
                    Reporter.log("Password authentication pop up is displayed");
                    itemMaintenancePage.inputRphPasswordOnRphVerifyPopUp();
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                    itemMaintenancePage.clickAcceptOnRphVerifyPopUp();
                }
                c2LogBookAdjustmentReasonPage.clickHazWasteAdjustmentReason();
                c2LogBookAdjustmentReasonPage.clickContinue();
                if(c2LogBookAdjustmentReasonPage.isDeaFormNbrDisplayed()){
                    c2LogBookAdjustmentReasonPage.inputDeaFormNbr(inputData.get("DEA_NUMBER"));
                    c2LogBookAdjustmentReasonPage.inputRetypeDEAFormNbr(inputData.get("DEA_NUMBER"));
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                    c2LogBookAdjustmentReasonPage.clickAccept();
                }
                itemMaintenancePage.clickAccept();
                connexusStartPage.pressEscapeKey();
                itemMaintenancePage.waitUntillProductScreenClosure();
            }else{
                Assert.fail("History button not displayed");
            }
        }
        catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Inventory History Details not Matching");
        }
    }

    /**
     * Validate updated on hand quantity in product screen.
     * @param inputData
     */
    public void validateUpdatedOnHandQuantityInProductScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            productSearchPage.launchProductSearchScreen();
            productSearchPage.enterProductNDC(inputData.get("NDC_NUMBER"));
            productSearchPage.clickSearchNow();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.doubleClickOnSearchGridRow(0);
            List<WebElement> itemList = productSearchPage.getNDCList();
            for (int i = 0; i < itemList.size(); i++) {
                if (itemList.get(i).getText().equalsIgnoreCase(inputData.get("NDC_NUMBER"))) {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                    actualOnHandQuantity = Integer.parseInt(productSearchPage.getOnHandQuantity(i));
                    Assert.assertEquals(actualOnHandQuantity, newOnHandQuantity, "On hand Quantity not matching");
                    itemMaintenancePage.clickAccept();
                    break;
                }
            }
        }
        catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("On Hand Quantity not Matching");
        }
    }

    /**
     * Validate on hand inventory detail report.
     * @param inputData
     */
    public void validateOnHandInventoryDetailedReport(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            onHandInventoryDetailPage.EnterNdcNumber(inputData.get("NDC_NUMBER").replaceAll("-", ""));
            onHandInventoryDetailPage.clickSearchButton();
            if (onHandInventoryDetailPage.isElementDisplayed(onHandInventoryDetailPage.noResultFound)) {
                onHandInventoryDetailPage.EnterNdcNumber(inputData.get("NDC_NUMBER").replaceAll("-", ""));
                onHandInventoryDetailPage.clickSearchButton();
            }
            List<WebElement> itemList = productSearchPage.getNDCList();
            for (int i = 0; i < itemList.size(); i++) {
                if (itemList.get(i).getText().equalsIgnoreCase(inputData.get("NDC_NUMBER"))) {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                    actualOnHandQuantity = Integer.parseInt(onHandInventoryDetailPage.getOnHandQuantity(i).replace(",", ""));
                    Reporter.log("Updated On Hand Quantity in Detail Page is" + actualOnHandQuantity);
                    Assert.assertEquals(actualOnHandQuantity, newOnHandQuantity, "On hand Quantity not matching");
                    onHandInventoryDetailPage.clickCloseButton();
                    break;
                }
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("On hand Quantity not matching");
        }
    }

    /** This Method will sort the create date column in cycle count report page and bring it to currentDate
     */
    public void sortCreateDateColumn() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        ArrayList<AddNDCToCycleCountPageCountList> countList = new ArrayList<>();
        List<String> ndcNumbersToAdd = connexusAppUtils.getOnNDCNumberToAddInCycleCount();
        String currentDate = ConnexusAppUtils.getCurrentTimestamp("M/d/yyyy");
        try {
            for (int i = 0; i < 4; i++) {
                if (cycleCountReportPage.getFirstRowDate().trim().equalsIgnoreCase(currentDate.trim())) {
                    break;
                } else {
                    cycleCountReportPage.clickCreateDateColumnHeader();
                    if (i == 3) {
                        int k = 0;
                        for (String ndc : ndcNumbersToAdd) {
                            AddNDCToCycleCountPageCountList addNdc = new AddNDCToCycleCountPageCountList();
                            k++;
                            addNdc.setNdc(ndc);
                            addNdc.setPriority(Integer.parseInt(prop.getProperty("fom.Priority")));
                            addNdc.setCountReasonCode(Integer.parseInt(prop.getProperty("fom.ReasonCode")));
                            countList.add(addNdc);
                            if (k == 4) {
                                break;
                            }
                        }
                        connexusAppUtils.resolveAllBackdatedNdc();
                        connexusAPIManager.addNdcInCycleCountReportPage(countList, prop.getProperty("cnx.store"));
                        cycleCountReportPage.clickRefreshButton();
                        Reporter.logScreenShot(Status.PASS, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
                    }
                }
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("There is no NDC with current Date: " + currentDate);
        }
    }


    /**
     * This method will retrive the on hand qty from Map<String,Map<String,Object>>
     **/

    public int getOnHandQty(Map<String, Map<String, Object>> drugInfo, String ndcNumber) {
        int onHandQty = 0;
        if (drugInfo.containsKey(ndcNumber.trim())) {
            Map<String, Object> drugDetails = drugInfo.get(ndcNumber);
            onHandQty = (int) drugDetails.get("onHandQty");
        }
        return onHandQty;
    }

    /**
     * This method will retrive the Fill id from Map<String,Map<String,Object>>
     **/

    public int getFamId(Map<String, Map<String, Object>> drugInfo, String ndcNumber) {
        int fillId = 0;
        if (drugInfo.containsKey(ndcNumber.trim())) {
            Map<String, Object> drugDetails = drugInfo.get(ndcNumber);
            Object famIdObj = drugDetails.get("famId");
            fillId = ((Number) famIdObj).intValue();
        }
        return fillId;
    }

    /**
     * This Method will perform the process count steps.
     * @param qty
     * @param index
     */
    public void processCycleCountForNonC2Drug(int qty, int index, String NdcNumber, String drugSchedule, String loginType, int adjustmentType) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            cycleCountReportPage.clickQuantity("Enter Quantity Row", index);
            cycleCountReportPage.enterQuantity(String.valueOf(qty), "Enter Quantity Row ", index);
            cycleCountReportPage.pressTABKey();

            //if drug schedule is not equals to NONE and Login Type as Technician and Adjustment Type is Exact (=on hand) then it will validate see pharmacist popup
            if ((!"NONE".equalsIgnoreCase(drugSchedule)) && loginType.equalsIgnoreCase(prop.getProperty("inv.loginType.Tech")) && adjustmentType != 1) {
                String popupMessage = cycleCountReportPage.hanldeSeePharamsistPopup();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
                if (popupMessage.equalsIgnoreCase(prop.getProperty("technician.adjtmnt.popup.message"))) {
                    Reporter.log("SEE PHARMACIST Popup Validated Successfully || Popup Message: " + popupMessage);
                } else {
                    Assert.fail("SEE PHARMACIST Popup Message Validation failed");
                }
                // Else it will follow normal popup validation
            } else {
                String popupMessage = cycleCountReportPage.handleCycleCountAdjustmentPopup();
                Reporter.log("PopUp Message: " + popupMessage);
                cycleCountReportPage.handleAdjustmentReasonPopup();
                cycleCountReportPage.handleDEAForm();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Unable to perform process cycle count");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * This method will check the particular NDC is removed from the table.
     */

    public void validateNDCRemoval(String NdcNumber) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        List<WebElement> NDCList = cycleCountReportPage.getNDCItemList();
        boolean drugRemove = false;
        for (WebElement element : NDCList) {
            if (element.getText().replace("-", "").trim().equals(NdcNumber)) {
                Assert.fail("NDC " + NdcNumber + " is not removed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
                drugRemove = true;
            }
        }
        if (!drugRemove) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, cycleCountReportPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("NDC " + NdcNumber + " is removed");
        }
    }

    /**
     * This method will validate the Adjustment Type code
     */
    public String validateAjustmentTypeCode(String famId, String expectedCode) {
        String adjustmentTypeCode = String.valueOf(connexusAppUtils.getAdjmtTypeCode(famId.trim()));
        Reporter.log("Adjustment Type code is " + adjustmentTypeCode.trim());
        Assert.assertEquals(adjustmentTypeCode, expectedCode);
        Reporter.log("Actual Code: " + adjustmentTypeCode + "|| Expected Code: " + expectedCode);
        return adjustmentTypeCode;
    }

    /** Method to confirm the Header is there
     * Then iterate over NDC List
     * then will go to consecutive drug schedule list and check
     * Based on that popup handle
     * then click process cycle
     */
    public void processCycleCounts(String loginType){
        String nDCNumber = "";
        String adjustmentoccurrence = "";
        Map<String, Integer> drugType = new HashMap<>();
        Map<String, Integer> ndcToAdjustmentCase = new HashMap<>();
        Map<String, String> ndcToFamId = new HashMap<>();
        Map<String, String> ndcToDrugSchedule = new HashMap<>();
        Set<String> adjustedNdcs = new HashSet<>();
        Set<String> ndcToAdjustmentoccurrence = new HashSet<>();

        sortCreateDateColumn();
        /**To store the NDC number, on hand qty and fill id*/
        List<WebElement> NDCList = cycleCountReportPage.getNDCItemList();

        //This will validate whether there is no CII drug present in Cycle count Report Page in Technician Login
        if (loginType.equalsIgnoreCase(prop.getProperty("inv.loginType.Tech"))) {
            boolean c2Presnece = false;
            for (int j = 0; j < NDCList.size(); j++) {
                String drugSchedule = cycleCountReportPage.getItemText(j, "Drug Schedule Row");
                nDCNumber = NDCList.get(j).getText().replace("-", "").trim();
                if ("2".equalsIgnoreCase(drugSchedule)) {
                    Assert.fail("CII drug NDC NUmber: " + nDCNumber + " is there drug present in Cycle Count Report Page for Technician login");
                    c2Presnece = true;
                }
                cycleCountReportPage.scrollDown();
            }
            if (!c2Presnece) {
                Reporter.log("There is No CII drug present in Cycle Count Report Page for Technician login");
            }
            cycleCountReportPage.clickCreateDateColumnHeader();
            cycleCountReportPage.pressHomeKey();
        }
        List<String> ndcNumberList = new ArrayList<>();
        for (WebElement element : NDCList) {
            ndcNumberList.add(element.getText().trim());
        }
        String ndcClause = ndcNumberList.stream().map(ndc -> "'" + ndc.replace("-", "") + "'").collect(Collectors.joining(","));
        Map<String, Map<String, Object>> drugInfo = connexusAppUtils.getOnHandQtyAndFillIdForNDC(ndcClause);

        String[] date = cycleCountReportPage.getFirstRowDate().trim().split("/");
        if (Objects.equals(date[1], prop.getProperty("inv.adjustment.specialDay"))) {
            for (int i = 0; i < NDCList.size(); i++) {
                String drugSchedule = cycleCountReportPage.getItemText(i, "Drug Schedule Row");
                if (Objects.equals(drugSchedule, "2")) {
                    Assert.fail("Date is 26th but Drug Schedule Type 2 is present in th list");
                }
            }
        }

        for(int i = 0;i< NDCList.size();i++) {
            nDCNumber = NDCList.get(i).getText().replace("-","").trim();
            int onHandQty = getOnHandQty(drugInfo,nDCNumber);//Calling the method to get the on hand qty
            String famId = String.valueOf(getFamId(drugInfo,nDCNumber));
            String drugSchedule = cycleCountReportPage.getItemText(i, "Drug Schedule Row").trim();

            if ("2".equalsIgnoreCase(drugSchedule)) {
                try {
                    adjustmentoccurrence = connexusAppUtils.getAdjustmentoccurrence(nDCNumber).trim();
                } catch (Exception e) {
                    adjustmentoccurrence = "2";
                }
                if ("0".equalsIgnoreCase(adjustmentoccurrence)) {
                    ndcToAdjustmentoccurrence.add(nDCNumber);
                }
            }
            int newCount = drugType.getOrDefault(drugSchedule,-1)+1;
            drugType.put(drugSchedule,newCount);
            ndcToAdjustmentCase.put(nDCNumber,newCount);
            ndcToFamId.put(nDCNumber,famId);
            ndcToDrugSchedule.put(nDCNumber,drugSchedule);
            switch (newCount){
                case 0:
                    processCycleCountForNonC2Drug(onHandQty + 10,  i,nDCNumber,drugSchedule,loginType,newCount);
                    Reporter.log("NDC Number: "+nDCNumber+"|| On Hand Qty: "+onHandQty+"|| Entered Qty: "+(onHandQty+10));
                    Reporter.log("Process Cycle count completed for NDC: "+nDCNumber);
                    adjustedNdcs.add(nDCNumber);
                    break;
                case 1:
                    processCycleCountForNonC2Drug(onHandQty,  i,nDCNumber,drugSchedule,loginType,newCount);
                    Reporter.log("NDC Number: "+nDCNumber+"|| On Hand Qty: "+onHandQty+"|| Entered Qty: "+onHandQty);
                    Reporter.log("Process Cycle count completed for NDC: "+nDCNumber);
                    adjustedNdcs.add(nDCNumber);
                    break;
                case 2:
                    if(onHandQty!=0) {
                        processCycleCountForNonC2Drug(onHandQty - 1, i,nDCNumber,drugSchedule,loginType,newCount);
                        Reporter.log("NDC Number: " + nDCNumber + "|| On Hand Qty: " + onHandQty + "|| Entered Qty: " + (onHandQty - 1));
                        Reporter.log("Process Cycle count completed for NDC: " + nDCNumber);
                        adjustedNdcs.add(nDCNumber);
                    }else{
                        Reporter.log("Skipping Negative Adjustment validation for "+nDCNumber+"  as on hand Qty is 0");
                        newCount--;
                        drugType.put(drugSchedule,newCount);
                    }
                    break;
            }
            cycleCountReportPage.scrollDown();
        }
        cycleCountReportPage.clickProcessCycleCountsButton();
        //Assign the columns names
        String getColumnNames = prop.getProperty("inv.report.table.columns");
        List<String> columnNames=Arrays.asList(getColumnNames.split("\\s*,\\s*"));
        List<List<String>>rows = new ArrayList<>();
        for(String ndcumber:adjustedNdcs) {
            validateNDCRemoval(ndcumber);
            int adjustmentCase = ndcToAdjustmentCase.get(ndcumber);
            String famid = ndcToFamId.get(ndcumber);
            String drugSchedule = ndcToDrugSchedule.get(ndcumber);
            String expectedCode = "";
            String message="";

            //Technician Login Special Handling
            String type = adjustmentCase == 1 ? "Equal Adjustment" : adjustmentCase == 0 ? "Positive Adjustment" : adjustmentCase == 2 ? "Negative Adjustment" : "Unknown";
            if ("Technician".equalsIgnoreCase(loginType) && (!"NONE".equalsIgnoreCase(drugSchedule)) && adjustmentCase!=1) {
                Reporter.log("For Technician login Skipping Adjustment Type Validation in DB as it has to be resolved in Pharmacist Login");
                message="Skipping Adjustment Type Validation in DB";
                //Add the rowa values for Table
                rows.add(Arrays.asList(ndcumber,drugSchedule,type,message));
                continue;
            }

            if (prop.getProperty("inv.drug.schedule").equalsIgnoreCase(drugSchedule)) {
                if (ndcToAdjustmentoccurrence.contains(ndcumber)) {
                    expectedCode = prop.getProperty("inv.expected.c2.adjustmentType");
                } else {
                    Reporter.log("NDC Number " + ndcumber + " There is already existing adjustment in the same month");
                    expectedCode = adjustmentCase == 0 || adjustmentCase == 1 ? prop.getProperty("inv.expected.positive.adjustmentType") : prop.getProperty("inv.expected.negetive.adjustmentType");
                }
            } else {
                expectedCode = adjustmentCase == 0 || adjustmentCase == 1 ? prop.getProperty("inv.expected.positive.adjustmentType") : prop.getProperty("inv.expected.negetive.adjustmentType");
            }
            String actualCode = validateAjustmentTypeCode(famid, expectedCode);
            message = "Validation Completed\n Actual Code: "+actualCode+" || Expected Code: "+expectedCode;
            //Add the rows value for table
            rows.add(Arrays.asList(ndcumber,drugSchedule,type,message));
        }
        //Create the table
        cycleCountReportPage.createDynamicTable(columnNames,rows,"Adjustment Summary("+loginType+" Login)");
    }

    /**
     * Validate on hand quantity adjustment in item maintenance history page.
     * @param inputData
     */
    public void validatePrescriptionFilledAndCancelledFillInItemMaintenanceHistoryPage(Map<String, String> inputData, boolean adjustmentType) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            newOnHandQuantity = (int) Double.parseDouble(connexusAppUtils.getOnHandQuantity(inputData.get("NDC_NUMBER").replaceAll("-", "")));
            productSearchPage.launchProductSearchScreen();
            productSearchPage.enterProductNDC(inputData.get("NDC_NUMBER"));
            productSearchPage.clickSearchNow();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.doubleClickOnSearchGridRow(0);
            List<WebElement> itemList = productSearchPage.getNDCList();
            for (int i = 0; i < itemList.size(); i++) {
                if (itemList.get(i).getText().equalsIgnoreCase(inputData.get("NDC_NUMBER"))) {
                    actualOnHandQuantity = Integer.parseInt(productSearchPage.getOnHandQuantity(i));
                    Assert.assertEquals(actualOnHandQuantity, newOnHandQuantity, "On hand Quantity not matching");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                    productSearchPage.clickOnNDCNumber(i);
                    break;
                }
            }
            if (productSearchPage.isElementDisplayed(itemMaintenancePage.historyButton, 90)) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                itemMaintenancePage.click(itemMaintenancePage.historyButton);
                itemMaintenancePage.clickIncludeFilledRxChkBox();
                itemMaintenancePage.isElementDisplayed(itemMaintenancePage.type, 30);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertEquals(Integer.parseInt(itemMaintenancePage.getText(itemMaintenancePage.newQuantity)), newOnHandQuantity, "New on hand quantity not matching");
                if (adjustmentType) {
                    Reporter.log("Validating Positive Adjustment History log");
                    Assert.assertEquals(itemMaintenancePage.getText(itemMaintenancePage.type), inputData.get("HISTORY_TYPE"), "Type not matching");
                    Assert.assertEquals(itemMaintenancePage.getText(itemMaintenancePage.usedId), prop.getProperty("cnx.rph.userName"), "User id not matching");
                } else {
                    Reporter.log("Validating Negative Adjustment History log");
                    Assert.assertEquals(itemMaintenancePage.getText(itemMaintenancePage.type), inputData.get("HISTORY_TYPE_NEGATIVE"), "Type not matching");
                    Assert.assertEquals(itemMaintenancePage.getText(itemMaintenancePage.usedId), inputData.get("USER_ID"), "User id not matching");
                }
                itemMaintenancePage.click(itemMaintenancePage.okButton);
                connexusStartPage.pressEscapeKey();
                patientSearchPage.clickYes();
                itemMaintenancePage.clickAccept();
                connexusStartPage.pressEscapeKey();
                itemMaintenancePage.waitUntillProductScreenClosure();
            } else {
                Assert.fail("History button not displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Inventory History Details not Matching");
        }
    }

    /**
     * This Method will process the adjustment for 2 NDc 1 positive 1 negative
     *
     * @return
     */
    public Map<String, Integer> processAdjustment(String loginType) {
        List<WebElement> NDCList = cycleCountReportPage.getNDCItemList();
        Map<String, Integer> ndcToAdjustmentCase = new HashMap<>();
        String ndcNumber = "";
        try {
            sortCreateDateColumn();
            for (int i = 0; i < NDCList.size(); i++) {
                ndcNumber = NDCList.get(i).getText().replace("-", "").trim();
                String drugSchedule = cycleCountReportPage.getItemText(i, "Drug Schedule Row").trim();
                double qty = Double.parseDouble(connexusAppUtils.getOnHandQuantity(ndcNumber));
                int onHandQty = (int) Math.round(qty);
                if (i == 0) {
                    processCycleCountForNonC2Drug(onHandQty + 10, i, ndcNumber,drugSchedule,loginType,i);
                    Reporter.log("NDC Number: " + ndcNumber + "|| On Hand Qty: " + onHandQty + "|| Entered Qty: " + (onHandQty + 10));
                    Reporter.log("Process Cycle count completed for NDC: " + ndcNumber);
                    ndcToAdjustmentCase.put(ndcNumber, i);
                } else {
                    if (onHandQty != 0) {
                        processCycleCountForNonC2Drug(onHandQty - 1, i, ndcNumber,drugSchedule,loginType,i);
                        Reporter.log("NDC Number: " + ndcNumber + "|| On Hand Qty: " + onHandQty + "|| Entered Qty: " + (onHandQty - 1));
                        Reporter.log("Process Cycle count completed for NDC: " + ndcNumber);
                        ndcToAdjustmentCase.put(ndcNumber, i);
                        return ndcToAdjustmentCase;
                    } else {
                        Reporter.log("Skipping negative adjustment for " + ndcNumber + "  as on hand Qty is 0");
                    }
                }
                cycleCountReportPage.scrollDown();
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Unable to perform Process Cycle Count");
        }
        return ndcToAdjustmentCase;
    }

    public void validateAdjustmentTypeInItemMaintenancePage(Map<String,Integer> ndcToAdjustmentCase){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            for (String key : ndcToAdjustmentCase.keySet()) {
                productSearchPage.launchProductSearchScreen();
                productSearchPage.enterProductNDC(key);
                productSearchPage.clickSearchNow();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                productSearchPage.doubleClickOnSearchGridRow(0);
                List<WebElement> itemList = productSearchPage.getNDCList();
                for (int i = 0; i < itemList.size(); i++) {
                    String ndcNumber = itemList.get(i).getText().replace("-", "").trim();
                    if (ndcNumber.equalsIgnoreCase(key)) {
                        Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                        productSearchPage.clickOnNDCNumber(i);
                        break;
                    }
                    productSearchPage.scrollDown();
                }
                if (productSearchPage.isElementDisplayed(itemMaintenancePage.historyButton, 90)) {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                    itemMaintenancePage.click(itemMaintenancePage.historyButton);
                    itemMaintenancePage.isElementDisplayed(itemMaintenancePage.type, 30);
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                    String adjustmentType = itemMaintenancePage.getText(itemMaintenancePage.type);
                    Reporter.log("NDC Number: " + key);
                    Reporter.log("Previous Onhand Quantity: " + itemMaintenancePage.getText(itemMaintenancePage.preQuantity));
                    Reporter.log("New Onhand Quantity: " + itemMaintenancePage.getText(itemMaintenancePage.newQuantity));
                    Reporter.log("Difference: " + itemMaintenancePage.getText(itemMaintenancePage.diffQuantity));
                    if (ndcToAdjustmentCase.get(key) == 0) {
                        Assert.assertEquals(adjustmentType, prop.getProperty("inv.positive.adjustment.type"));
                    } else {
                        Assert.assertEquals(adjustmentType, prop.getProperty("inv.negative.adjustment.type"));
                    }
                }
                itemMaintenancePage.click(itemMaintenancePage.okButton);
                connexusStartPage.pressEscapeKey();
                patientSearchPage.clickYes();
                itemMaintenancePage.clickAccept();
                connexusStartPage.pressEscapeKey();
                itemMaintenancePage.waitUntillProductScreenClosure();
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Validation failed at Item Maintenance Page");
        }
    }

    /**
     * This method will click on Process cycle count button and close the window
     */
    public void processCycleCountSndCloseWindow(){
        try {
            cycleCountReportPage.clickProcessCycleCountsButton();
            cycleCountReportPage.clickClose();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Unable to click process cycle count button/Close the window");
        }
    }

    /**
     * Thi Method will validate the Titlt of the page
     */
    public void validatePageTitle() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertEquals(c2AdjustmentPage.getHeaderText(), prop.getProperty("inv.c2.popup.message"));
            Reporter.log("Landed on CII Manual Adjustment Report Page");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("CII Adjustment Page didn't opened");
        }
    }

    /**
     * This Method will validateNdc Presence In CII Adjustment Report Page
     * @param inputData
     */

    public void validateNdcPresenceInCIIAdjustmentReportPage(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        c2AdjustmentPage.clickHazardousWasteCheckBox();
        c2AdjustmentPage.clickOnSearchButton();
        List<WebElement> ndcList = c2AdjustmentPage.getNDCItemList();
        String ndcNumber = "";
        int i = 0;
        for (WebElement ndc : ndcList) {
            ndcNumber = ndc.getText().trim();
            if (ndcNumber.equalsIgnoreCase(inputData.get("NDC_NUMBER"))) {
                ndc.click();
                Reporter.log("NDC " + ndcNumber + " is present in CII Manual Adjustment Report Page");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                break;
            }
            if (i == ndcList.size()) {
                Reporter.log("NDC " + ndcNumber + " is NOT present in CII Manual Adjustment Report Page");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("NDC is not present in the Table");
            }
            i++;
        }
        cycleCountReportPage.clickClose();
    }

    public void selectNavigation(AppMenu menu, AppMenuItemsIndex menuNavigation, AppMenuSubItemsIndex subMenuNavigation, AppMenuSuperSubItemsIndex superSubMenuNavigation) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        Robot robot;
        try {
            String[] menuItems = menu.getAppMenu().split("->");
            menuBar.selectMenuItem(menuItems[0]);
            automationManager.performSleep(3);
            Reporter.logScreenShot(Status.PASS, menu.getAppMenu(), menuBar.takeScreenShot(currentStepMethodName).getValue());
            robot = new Robot();
            for (int i = 0; i < menuNavigation.getAppMenu(); i++) {
                automationManager.performSleep(1);
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            automationManager.performSleep(1);
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            automationManager.performSleep(2);
            robot.keyPress(KeyEvent.VK_UP);
            robot.keyRelease(KeyEvent.VK_UP);
            for (int i = 0; i < subMenuNavigation.getAppMenu(); i++) {
                automationManager.performSleep(2);
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            automationManager.performSleep(3);
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            automationManager.performSleep(2);
            robot.keyPress(KeyEvent.VK_UP);
            robot.keyRelease(KeyEvent.VK_UP);
            for (int i = 0; i < superSubMenuNavigation.getAppMenu(); i++) {
                automationManager.performSleep(2);
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            Reporter.logScreenShot(Status.PASS, menu.getAppMenu(), menuBar.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(2);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
        } catch (Exception exception) {
            int count = 0;
            while (count < 3) {
                menuBar.pressKeys(KeyEvent.VK_ESCAPE);
                count++;
            }
        }
    }

    public void selectAuditTypeAnsClickOnSearchButton() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectUserName(menuBar.CmbAuditType);
            menuBar.click(menuBar.btnSearch);
            Reporter.logScreenShot(Status.PASS, "Selected Audit Type and Click on Search button", menuBar.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
        }
    }

    public void validateTableHasMoreThanZeroRowsAndDataPresent(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
            for (int i = 0; i <= 5; i++) {
                String drugName = menuBar.getText(AppiumBy.name("Short Name Row " + i));
                String ndcNumber = menuBar.getText(AppiumBy.name("NDC Row " + i));
                String dosageForm = menuBar.getText(AppiumBy.name("Dosage Form Row " + i));
                if (drugName.length() > 0 && ndcNumber.length() > 0 && dosageForm.length() > 0) {
                    Assert.assertTrue(true);
                    Reporter.log("Data Present in the table with " + drugName + ndcNumber + dosageForm);
                } else {
                    Assert.fail("Data not present");
                }
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("Data not present");
            patientSearchPage.closeIfAnyPopUpOpened();
        }
    }

    public void openReportByClickingOnShowReportButton() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.clickShowReport();
            AutomationManager.getInstance().performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
            menuBar.click(menuBar.btnCancel);
            menuBar.click(menuBar.btnClose);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
        }
    }

    public void validateResolvingCycleCountForNonCII(Map<String, String> inputData,int a){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        menuBar.selectNavigation(AppMenu.CYCLE_COUNT, AppMenuItemsIndex.INVENTORY_REPORTS, AppMenuSubItemsIndex.CYCLE_COUNT_REPORT, null);
        try {
            if (returnToInmarMckesPage.getPageTitleText().equalsIgnoreCase(inputData.get("PAGE_HEADER"))) {
                Reporter.log("Cycle Count Report page opened");
                cycleCountReportPage.clickGetMoreCount();
                cycleCountReportPage.sortByDrugSchedule();
                List<WebElement> drugScheduleList = cycleCountReportPage.getDrugScheduleList();
                // Find the first index in drugScheduleList where drugSchedule is not "2"
                OptionalInt firstNonC2Index = IntStream.range(0, drugScheduleList.size())
                        .filter(i -> !"2".equalsIgnoreCase(cycleCountReportPage.getItemText(i, "Drug Schedule Row").trim()))
                        .findFirst();

                if (firstNonC2Index.isPresent()) {
                    int i = firstNonC2Index.getAsInt();
                    String nDCNumber = cycleCountReportPage.getNdcNbr(i);
                    Reporter.log(" Drug is an non C2 drug " + nDCNumber);
                    nDCNumber = nDCNumber.replace("-", "").trim();
                    int currentOnHandQty = (int) Double.parseDouble(connexusAppUtils.getOnHandQuantity(nDCNumber));
                    Reporter.log("Current OnHand Quantity for "+ nDCNumber + " : " + currentOnHandQty);
                    int updatedOnHandQty = currentOnHandQty + a;
                    Reporter.log("Updated onHand Quantity for ndcNumber: " + updatedOnHandQty);
                    cycleCountReportPage.inputDrugQty(i, String.valueOf(updatedOnHandQty));
                    cycleCountReportPage.pressTabKey();
                    cycleCountReportPage.handleCycleCountAdjustmentPopup();
                    cycleCountReportPage.handleAdjustmentReasonPopup();
                    cycleCountReportPage.clickProcessCycleCountsButton();
                    cycleCountReportPage.clickClose();
                    Reporter.logScreenShot("Cycle Count Report", connexusStartPage.takeScreenShot("Cycle Count Report").getValue());
                    int newOnHandQty = (int) Double.parseDouble(connexusAppUtils.getOnHandQuantity(nDCNumber));
                    Reporter.log("After Process Cycle Count, new OnHand Quantity for ndcNumber: " + newOnHandQty);
                    if (newOnHandQty == updatedOnHandQty) {
                        Reporter.log("New Onhand Quantity " + newOnHandQty + " matching with the updated Onhand Quantity " + updatedOnHandQty + " for the NDC " + nDCNumber);
                        Assert.assertTrue(true);
                    } else {
                        Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                        Assert.fail("New Onhand Quantity not matching with the current Onhand Quantity");
                    }
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Assert.fail("No Non CII drug present in the Cycle Count Report Page");
                }
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Cycle Count report page not opened");
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }
    /**
     * Method to validate all three cycle count operations (ADD, REDUCE, VALIDATE) for C2 drugs
     * Each operation uses a different C2 NDC from the Cycle Count Report
     * @param inputData - Input data map
     * Test Flow:
     * 1. Operation 1 - ADD: Get C2 NDC from row 0, add quantity and validate
     * 2. Operation 2 - REDUCE: Get C2 NDC from row 1, subtract quantity and validate
     * 3. Operation 3 - VALIDATE: Get C2 NDC from row 2, validate without update
     */
    public void validateAllCycleCountOperationsForCII(Map<String, String> inputData) {

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        // Define three operations to test: ADD, REDUCE, and VALIDATE
        String[] operations = {"ADD", "REDUCE", "VALIDATE"};
        // Array to store NDC numbers used in each operation for summary
        String[] ndcList = new String[3];
        try {
            Reporter.log("Starting all three cycle count operations for C2 drugs - Each operation uses different NDC");
            // Loop through all three operations (ADD, REDUCE, VALIDATE)
            for (int i = 0; i < operations.length; i++) {
                // Get current operation type
                String operation = operations[i];
                // Use row index matching operation index (0, 1, 2)
                int rowIndex = i;
                Reporter.log("Operation " + (i + 1) + ": " + operation );
                // Navigate to Cycle Count Report page
                menuBar.selectNavigation(AppMenu.CYCLE_COUNT,
                        AppMenuItemsIndex.INVENTORY_REPORTS,
                        AppMenuSubItemsIndex.CYCLE_COUNT_REPORT, null);
                // Sort by Drug Schedule column to group C2 drugs together
                Reporter.log("Clicking Drug Schedule column to sort and group C2 drugs together");
                cycleCountReportPage.sortByDrugSchedule();
                // Extract NDC number from the specified row
                String ndcNumber = cycleCountReportPage.getNdcNbr(rowIndex);
                Reporter.log(operation + " Operation - C2 Drug NDC (row " + rowIndex + "): " + ndcNumber);
                // Remove hyphens and trim whitespace from NDC
                String nDCNumber = ndcNumber.replace("-", "").trim();
                // Store NDC in array for final summary
                ndcList[i] = nDCNumber;
                // Query database to get current on-hand quantity for this NDC
                int currentOnHandQty = (int) Double.parseDouble(connexusAppUtils.getOnHandQuantity(nDCNumber));
                Reporter.log("Current OnHand Quantity: " + currentOnHandQty);
                // Initialize expected quantity (will be modified based on operation)
                int expectedOnHandQty = currentOnHandQty;
                // Flag to determine if we need to update quantity or just validate
                boolean performUpdate = true;
                // Calculate expected quantity based on operation type
                switch (operation) {
                    case "ADD":
                        // Add 10 units to current quantity
                        expectedOnHandQty = currentOnHandQty + 10;
                        Reporter.log("Expected OnHand Quantity after ADD: " + expectedOnHandQty);
                        break;
                    case "REDUCE":
                        // Subtract 10 units from current quantity
                        expectedOnHandQty = currentOnHandQty - 10;
                        // Ensure quantity doesn't go negative
                        if (expectedOnHandQty < 0) {
                            expectedOnHandQty = 0;
                        }
                        Reporter.log("Expected OnHand Quantity after REDUCE: " + expectedOnHandQty);
                        break;
                    case "VALIDATE":
                        // No change to quantity, just validate existing count
                        performUpdate = false;
                        Reporter.log("Expected OnHand Quantity after VALIDATE (no change): " + expectedOnHandQty);
                        break;
                }
                // Update quantity only if operation requires it (ADD or REDUCE)
                if (performUpdate) {
                    // Enter new quantity in the input field
                    cycleCountReportPage.inputDrugQty(rowIndex, String.valueOf(expectedOnHandQty));
                    // Press Tab to trigger validation
                    cycleCountReportPage.pressTabKey();
                    // Handle adjustment confirmation popup
                    cycleCountReportPage.handleCycleCountAdjustmentPopup();
                    // Handle adjustment reason popup
                    cycleCountReportPage.handleAdjustmentReasonPopup();
                }
                // Click Process button to complete the cycle count
                cycleCountReportPage.clickProcessCycleCountsButton();
                Reporter.logScreenShot("Cycle Count Report - " + operation, connexusStartPage.takeScreenShot(operation + " Operation").getValue());
                // Wait for processing to complete because it will take some time to sync the data
                automationManager.performSleep(30);
                // Query database again to get updated on-hand quantity
                int newOnHandQty = (int) Double.parseDouble(connexusAppUtils.getOnHandQuantity(nDCNumber));
                Reporter.log("After " + operation + " operation, new OnHand Quantity: " + newOnHandQty);
                // Verify that actual quantity matches expected quantity
                if (newOnHandQty == expectedOnHandQty) {
                    Reporter.log(operation + " Operation SUCCESS: Quantity " + newOnHandQty + " matches expected " + expectedOnHandQty + " for NDC " + nDCNumber);
                } else {
                    // Fail test if quantities don't match
                    Assert.fail(operation + " Operation FAILED: Quantity " + newOnHandQty + " does not match expected " + expectedOnHandQty);
                }
                // Close the Cycle Count Report page
                cycleCountReportPage.clickClose();
            }
            // Log summary of all operations with NDCs used
            Reporter.log("All Three Operations Completed Successfully");
            Reporter.log("ADD Operation used NDC: " + ndcList[0]);
            Reporter.log("REDUCE Operation used NDC: " + ndcList[1]);
            Reporter.log("VALIDATE Operation used NDC: " + ndcList[2]);
        } catch (Throwable e) {
            // Log and fail test if any exception occurs
            Reporter.log("Error in " + currentStepMethodName + ": " + e.getMessage());
            e.printStackTrace();
            Assert.fail("Test failed: " + e.getMessage());
        }
    }
}