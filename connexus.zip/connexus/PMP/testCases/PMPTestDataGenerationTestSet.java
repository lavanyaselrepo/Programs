package connexus.PMP.testCases;

import connexus.PMP.testScripts.PMPTestDataGenerationTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

public class PMPTestDataGenerationTestSet {

    PMPTestDataGenerationTestScripts pmpTestScripts = new PMPTestDataGenerationTestScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();

    @BeforeClass
    public void startAppiumServer() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    public void flagsCheckUp(String pharmacyState){
        //c2 drug popup flag should set <past date>
        connexusAppUtils.readAndUpdateFlag("27107","2021-07-08");
        //Verify and set the flag 27268 for c2 control drug  to TRUE
        connexusAppUtils.readAndUpdateFlag("27268", "TRUE");

        connexusAppUtils.updateStateValue(pharmacyState);
        pmpTestScripts.restartService();
        pmpTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils.getStoreId();
    }

    @Test(enabled = true, description = "Verify data for OK state real time flow on PMP Clearing House",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_2674(Map<String, String> inputData) {
        /*
        Precondition: State of the box should be set to OK
        Prescription with control substance
         */
        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));
        String rxNum = pmpTestScripts.performCreatePatientAndCompletePickup(inputData);
        Reporter.log("pickup is completed:" + rxNum);
    }

    @Test(enabled = true, description = "Verify if there are any duplicate data submissions. Ex : We submit the data file real time and in batch process we create one more file.",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_2675(Map<String, String> inputData) {
        /*
        "Precondition: State of the box should be set to OK
        Set RTPMP flag 23506 to 'F' --ignoring this
        Login to Connexus application."
         */
        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));
        String rxNum = pmpTestScripts.performCreatePatientAndCompletePickup(inputData);
        Reporter.log("pickup is completed:" + rxNum);
    }

    @Test(enabled = true, description = "verify the data populated and the format of the RTPMP report generated for RX in the state OH state and verifing Dxcode is populated",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_145(Map<String, String> inputData) {
        /*
        "Precondition: State of the box should be set to OH
         Set RTPMP flag 23506 to 'P'
         Login to Connexus application."
         */
        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));

        pmpTestScripts.performcreatePatientAndCompleteDropOff(inputData);
        pmpTestScripts.performInput(inputData);
        pmpTestScripts.perform4Point();
        pmpTestScripts.performFilling();
        pmpTestScripts.performVVandPickup(inputData);
    }

    @Test(enabled = true, description = "verify the data populated and the format of the RTPMP report generated for single RX having Triplicate number picked up through TASCO in TX state",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_148(Map<String, String> inputData) {
        /*
        State of the box should be set to TX.
    select * from bu_phm_parm where phm_parm_code = 5318; – value should be TRUE
    Login to Connexus application."
         */
        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));

        pmpTestScripts.performcreatePatientAndCompleteDropOff(inputData);
        pmpTestScripts.performInput(inputData);
        pmpTestScripts.perform4Point();
        pmpTestScripts.performFilling();
        pmpTestScripts.performVVandPickup(inputData);
    }

    @Test(enabled = true, description = "verify the data populated and the format of the RTPMP report generated for RX picked up through TASCO AR state",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_142(Map<String, String> inputData) {
        /*
        "Precondition: State of the box should be set to AR.
         Prescription with control substance
         Login to Connexus application."
         */
        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));

        pmpTestScripts.performCreatePatientAndCompleteTillEOD(inputData);
        pmpTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);

        //Perform DropOff for an RX which has Refills
        pmpTestScripts.performDropOffForRXWithRefills();
        //perform resolution for EarlyRefill
        pmpTestScripts.performEarlyRefillsAuthorization();
        //Complete Filling
        pmpTestScripts.performFilling();
        //Complete VV, Pickup and move to Counselling
        pmpTestScripts.performVVandPickupForMatchingWorkqueueCode(inputData);
    }

    @Test(enabled = true, description = "verify the data populated and the format of the RTPMP report generated for RX picked up through TASCO AR stateverify the data populated and the format of the RTPMP report generated for Refill auth RX picked up through TASCO",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_140(Map<String, String> inputData) {
        /*
        "Precondition: State of the box should be set to AR.
         Prescription with control substance
         Login to Connexus application"
         */
        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));

        pmpTestScripts.performCreatePatientAndCompleteTillEOD(inputData);
        pmpTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);

        //Perform DropOff for an RX which has no Refills
        pmpTestScripts.performDropOffForARXWithNoRefills();

        //Verify whether RX moved toResolution queue due to zero refills
        pmpTestScripts.verifyIfRxIsInResolutionQueue();

        //making 0 refills authorized
        pmpTestScripts.performRefillsAuthorized(inputData);

        //it performs input
        pmpTestScripts.performInput(inputData);

        //it performs four point
        pmpTestScripts.perform4Point();

        //Complete Filling
        pmpTestScripts.performFilling();

        pmpTestScripts.performVVandPickupForMatchingWorkqueueCode(inputData);
    }

    //HWPHME2E-147

    @Test(enabled = true, description = "verify the data populated and the format of the RTPMP report generated for single RX picked up through TASCO in KY state and patient is having SSN and DL in his profile. Also for another patient with no SSN and DL in profile.",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_147(Map<String, String> inputData) {
        /* "Precondition: State of the box should be set to KY and Flag value of 26449 to 'P'
            Login to Connexus application."*/

        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));

        //create patient with Out SSN OR DL
        int patientWithOutSSN= pmpTestScripts.createPatientWithOutSSN(inputData);

        //Create Patient with SSN and DL
        int patientWithSSNDL= pmpTestScripts.createPatientWithSSN(inputData);
        //perform dropOFF to VV
        String rxNbrWithOutSSN=pmpTestScripts.performOrderDropOffAndCompleteVV(inputData,patientWithOutSSN);

        String rxNbrWithSSN=pmpTestScripts.performOrderDropOffAndCompleteVV(inputData,patientWithSSNDL);

        connexusAppUtils.updateStateValue(inputData.get("PHARMACY_STATE"));
        pmpTestScripts.restartService();
        pmpTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);

        //Complete PickUp for rxNbr with SSNValidation
        pmpTestScripts.performPickUpWithSSNValidation(inputData,rxNbrWithOutSSN,patientWithOutSSN);

        //Complete PickUp with SSN/DL
        pmpTestScripts.performPickUpWithRxNbr(inputData,rxNbrWithSSN,patientWithSSNDL);

    }

    //Not Valid
    /*@Test(enabled = true, description = "verify the data populated and the format of the RTPMP report generated for compound filled RX picked up through TASCO",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMPTestDataGeneration/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_141(Map<String, String> inputData) {
        *//* "Precondition: State of the box should be set to AR
            Login to Connexus application.""*//*
        pmpTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        if (connexusAppUtils.updateStateValue(inputData.get("PHARMACY_STATE"))) {
            pmpTestScripts.clearCache();
          //  closeConnexus();
            pmpTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));
        pmpTestScripts.performCreatePatientWithTPToPickUpCompletion(inputData);
    }*/

    @Test(enabled = true, description = "verify the data neither populated and nor the format of the RTPMP report generated for single RX picked up through TASCO with not a control substance in NE state",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_138(Map<String, String> inputData) {
        /* "Precondition: State of the box should be set to NE
            Login to Connexus application.""*/

        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));

        pmpTestScripts.performCreatePatientWithTPToPickUpCompletion(inputData);
    }

    @Test(enabled = true, description = "verify the data populated and the format of the RTPMP report generated for single RX picked up through TASCO with control substance id capture in MA state",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_137(Map<String, String> inputData) {
        /* "Precondition: State of the box should be set to MA
            Login to Connexus application.""*/

        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));

        pmpTestScripts.performCreatePatientWithTPToCounsel(inputData);
    }

    @Test(enabled = true, description = "verify the data populated and the format of the RTPMP report generated for single RX picked up through TASCO without control substance id capture in AR state. Verify DSP16 for payment",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_146(Map<String, String> inputData) {
        /* "Precondition: State of the box should be set to AR
            Login to Connexus application.""
            Control Substance ID capture Window is not displayed*/

        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));

        pmpTestScripts.performCreatePatientWithTPToCounsel(inputData);
    }

    @Test(enabled = true, description = "verify the data populated and the format of the RTPMP report generated for single RX picked up through TASCO with control substance id capture in SC state",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_143(Map<String, String> inputData) {
        /* "Precondition: State of the box should be set to SC
            Login to Connexus application.""
           */

        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));

        pmpTestScripts.performCreatePatientWithTPToCounsel(inputData);
    }


    @Test(enabled = true, description = "verify the data populated and the format of the RTPMP report generated for ERX in the state of MAINE (ME).",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_149(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        /* "Precondition: State of the box should be set to ME
            Login to Connexus application."
           */

        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        String xmlPayload="src//test//resources//TestData//Connexus//ERXpayload_withDrugDbCode.xml";
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));

        pmpTestScripts.performERXWithNewPatient(inputData,xmlPayload);

        pmpTestScripts.performInput(inputData);

        pmpTestScripts.perform4Point();

        pmpTestScripts.performFilling();

        pmpTestScripts.performVVandPickup(inputData);
    }

    @Test(enabled = true, description = "verify the data populated and the format of the RTPMP report generated for ERX in the state of OK.",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_150(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        /* "Precondition: State of the box should be set to OK
            Login to Connexus application."
           */

        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        String xmlPayload="src//test//resources//TestData//Connexus//ERXpayload.xml";
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));

        pmpTestScripts.performERXWithNewPatient(inputData,xmlPayload);

        pmpTestScripts.performInput(inputData);

        pmpTestScripts.perform4Point();

        pmpTestScripts.performFilling();

        //Complete visual verify and PickUp
        pmpTestScripts.performVVandPickup(inputData);
    }

    @Test(enabled = true, description = "verify the data populated and the format of the RTPMP report generated for PharmacyTransfer\\NPI origin prescription is partilly picked up through TASCO",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPTestDataGenerationFile.json", sheetName = "PMPReports")
    public void HWPHME2E_139(Map<String, String> inputData) {
        /*  "Precondition: State of the box should be set to AR
             Login to Connexus application.""*/

        flagsCheckUp(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));

        pmpTestScripts.performCreatePatientUIAndCompleteDUR(inputData);
        pmpTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        //Perform PartialFill
        pmpTestScripts.performPartialFilling();
        // Perform initial fill of final fill
        pmpTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        pmpTestScripts.performInitialFill();
        //Completes Visual Verify and Pickup
        pmpTestScripts.performVVandPickupForMatchingWorkqueueCode(inputData);
    }
}