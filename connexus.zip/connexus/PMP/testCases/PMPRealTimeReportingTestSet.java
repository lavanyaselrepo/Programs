package connexus.PMP.testCases;

import connexus.ConnexusTestScripts;
import connexus.PMP.testScripts.PMPRealTimeReportingTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;

public class PMPRealTimeReportingTestSet {

    PMPRealTimeReportingTestScript pmpRealTimeReportingTestScript = new PMPRealTimeReportingTestScript();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    ConnexusTestScripts connexusTestScripts = new ConnexusTestScripts();
    PropertyReader prop = PropertyReader.getInstance();
    String siteId = prop.getProperty("cnx.store");
    String statecode = "";
    List<String> respList = new ArrayList<>();

    @BeforeClass
    public void startAppiumServer() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    public void NarxCareFlagsSetUP() {

        //Verify and set the flag 27268 to FALSE
        connexusAppUtils.readAndUpdateFlag("27268", "FALSE");

        //Verify and set the flag 31010 to TRUE
        connexusAppUtils.readAndUpdateFlag("31010", "TRUE");

        //Verify and set the flag 1667 to TRUE
        connexusAppUtils.readAndUpdateFlag("1667", "TRUE");

        //Verify and set the flag 1666 to FALSE
        connexusAppUtils.readAndUpdateFlag("1666", "FALSE");

        //Verify and set the flag 31011 to 300
        connexusAppUtils.readAndUpdateFlag("31011", "300");
        connexusAppUtils.readAndUpdateFlag("27268", "FALSE");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To Validate Whether High Profile Non Controlled Drugs are getting reported to PMP in MO state.
     * Pre-Conditions:
       1. Set the store state as : MO
          select * from bus_unit_addr;
       2. To enable the 'Protocol  for State Specific standing order:
          ACR - agency_rqmt_parm table should be set as 'TRUE'
          select * from agency_rqmt_parm where issue_agency_code = 236 and restrict_type_code in (23506,23508,19570)
            * ARP - 23506 = B–(agency requirment param table), ARP -19570 = N and ARP – 23508 = N
          ACRP - agency_rqmt_parm table should be set as 'TRUE'
          select * from agcy_cls_rqmt_parm where issue_agency_code =236 and restrict_type_code=23507 and drug_control_code in (2303);
            * ACRP – 23507 (agency class rqt param table) -> 2303 – N
     *
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-2432")
    @Test(description = "To Validate Whether High Profile Non Controlled Drugs are getting reported to PMP in MO state.",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPRealTimeReportingTestData.json", sheetName = "PMPRealTimeReportingDataSheet")
    public void HWPHME2E_2432_Validate_PMP_RealTimeReporting_NoEntryInDB_For_MO_State(Map<String, String> inputData) {
    Reporter.log(">>>HWPHME2E_2432_Validate Whether High Profile Non Controlled Drugs are getting reported No Entry in DB to PMP in MO state<<<");

        //Pre-condition
        if(connexusAppUtils.updateStateValue(inputData.get("STATE"))) {
            statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
            Reporter.log("State code:" + statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("B", "23506", statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("N", "23508", statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("N", "19570", statecode);
            connexusAppUtils.updateAgencyClsRequirementParmTable("N", "23507", "2303", statecode);
            NarxCareFlagsSetUP();
            connexusAppUtils.updateAgencyRequirementParmTable("Y","14500",statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("N","14501",statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("FALSE","19666",statecode);
            pmpRealTimeReportingTestScript.clearCache();
        }
        //Create a new patient, drop an order of High profile non controlled drugs and process the Rx till pickup.
        respList = pmpRealTimeReportingTestScript.performCreateOrderAndMoveTocheckDUR(inputData);
        String rxNbr = respList.get(0);
        String fillId = respList.get(1);
        String patientId = respList.get(2);
        pmpRealTimeReportingTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        pmpRealTimeReportingTestScript.performChkDURResolved(inputData);
        connexusTestScripts.getOrderDetailsAndMoveToPickup(Integer.parseInt(fillId));
        pmpRealTimeReportingTestScript.performPickupForDBEntry(inputData, rxNbr, Integer.parseInt(patientId));

        //Once checkout is complete,validate whether there is any entry in audit table in DB
        pmpRealTimeReportingTestScript.verifyNoEntryInAuditTable(fillId);
        Reporter.log(">>>HWPHME2E_2432_High Profile Non Controlled Drugs are getting reported No Entry in DB to PMP in MO state<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:To Validate Multiple Rxs Whether all the orders including High Profile Non Controlled Drugs are getting reported to PMP in MO state.
     * Pre-Conditions:
       1. Set the store state as : MO
          select * from bus_unit_addr;
       2. To enable the 'Protocol  for State Specific standing order:
          ACR - agency_rqmt_parm table should be set as 'TRUE'
          select * from agency_rqmt_parm where issue_agency_code = 236 and restrict_type_code in (23506,23508,19570)
            * ARP - 23506 = B–(agency requirment param table), ARP -19570 = Y and ARP – 23508 = N
          ACRP - agency_rqmt_parm table should be set as 'TRUE'
          select * from agcy_cls_rqmt_parm where issue_agency_code =236 and restrict_type_code=23507 and drug_control_code in (2301,2304);
            * ACRP – 23507 (agency class rqt param table) -> 2301 – Y , 2304 – N
     *
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-2433")
    @Test(description = "To Validate Multiple Rxs Whether all the orders including High Profile Non Controlled Drugs are getting reported to PMP in MO state.",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPRealTimeReportingTestData.json", sheetName = "PMPRealTimeReportingDataSheet")
    public void HWPHME2E_2433_Validate_Multiple_Rxs_PMP_RealTimeReporting_EntryInDB_For_MO_State(Map<String, String> inputData) {
        Reporter.log(">>>HWPHME2E_2433_Validate_Multiple Rxs Whether all the orders including High Profile Non Controlled Drugs are getting reported Entry in DB to PMP in MO state<<<");

        //Pre-condition
        if(connexusAppUtils.updateStateValue(inputData.get("STATE"))) {
            statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
            Reporter.log("State code:" + statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("B", "23506", statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("N", "23508", statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("Y", "19570", statecode);
            connexusAppUtils.updateAgencyClsRequirementParmTable("Y", "23507", "2301", statecode);
            connexusAppUtils.updateAgencyClsRequirementParmTable("N", "23507", "2304", statecode);
            NarxCareFlagsSetUP();
            connexusAppUtils.updateAgencyRequirementParmTable("Y","14500",statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("N","14501",statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("FALSE","19666",statecode);
            pmpRealTimeReportingTestScript.clearCache();
        }
        //Create a new patient, drop an order of High profile non controlled drugs and process the Rx till pickup.
        List<String> multiRxResponseList = pmpRealTimeReportingTestScript.CreatePatientAndMultiRxOrderMoveTocheckDUR(inputData);
        pmpRealTimeReportingTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        for (int i = 0; i < multiRxResponseList.size(); i += 2) {
            String fillId = multiRxResponseList.get(i);
            String rxNbr = multiRxResponseList.get(i + 1);

            Log.info("Processing RxNbr: " + rxNbr + " | FillId: " + fillId);

            pmpRealTimeReportingTestScript.performMultiChkDURResolvedInUI(inputData, rxNbr);

            connexusTestScripts.getOrderDetailsAndMoveToPickup(Integer.parseInt(fillId));
        }
        pmpRealTimeReportingTestScript.performMultiRxPickUp(inputData);

        //Once checkout is complete, validate whether there is any entry in audit table in DB
        pmpRealTimeReportingTestScript.verifyMultiEntryInAuditTable();
        Reporter.log(">>>HWPHME2E_2433_Multiple Rxs for all the orders including High Profile Non Controlled Drugs are getting reported Entry in DB to PMP in MO state<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:To Validate Whether High Profile Non Controlled Drugs are getting reported to PMP in OK state
    * Pre-Conditions:
       1. Set the store state as : OK
          select * from bus_unit_addr;
       2. To enable the 'Protocol  for State Specific standing order:
          ACR - agency_rqmt_parm table should be set as 'TRUE'
          select * from agency_rqmt_parm where issue_agency_code = 236 and restrict_type_code in (23506,23508,19570)
            * ARP - 23506 = B–(agency requirment param table), ARP -19570 = Y and ARP – 23508 = Y
          ACRP - agency_rqmt_parm table should be set as 'TRUE'
          select * from agcy_cls_rqmt_parm where issue_agency_code =236 and restrict_type_code=23507 and drug_control_code in (2303);
            * ACRP – 23507 (agency class rqt param table) -> 2303 – Y
     *
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-2434")
    @Test(description = "To Validate Whether High Profile Non Controlled Drugs are getting reported to PMP in OK state.",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPRealTimeReportingTestData.json", sheetName = "PMPRealTimeReportingDataSheet")
    public void HWPHME2E_2434_Validate_PMP_RealTimeReporting_EntryInDB_For_OK_State(Map<String, String> inputData) {
        Reporter.log(">>>HWPHME2E_2434_Validate Whether High Profile Non Controlled Drugs are getting reported Entry in DB to PMP in OK state<<<");

        //Pre-condition
        if(connexusAppUtils.updateStateValue(inputData.get("STATE"))) {
            statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
            Reporter.log("State code:" + statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("B", "23506", statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("Y", "23508", statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("Y", "19570", statecode);
            connexusAppUtils.updateAgencyClsRequirementParmTable("Y", "23507", "2303", statecode);
            NarxCareFlagsSetUP();
            connexusAppUtils.updateAgencyRequirementParmTable("Y","14500",statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("N","14501",statecode);
            connexusAppUtils.updateAgencyRequirementParmTable("FALSE","19666",statecode);
            pmpRealTimeReportingTestScript.clearCache();
        }
        //Create a new patient, drop an order of High profile non controlled drugs and process the Rx till pickup.
        respList = pmpRealTimeReportingTestScript.performCreateOrderAndMoveTocheckDUR(inputData);
        String rxNbr = respList.get(0);
        String fillId = respList.get(1);
        String patientId = respList.get(2);
        pmpRealTimeReportingTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        pmpRealTimeReportingTestScript.performChkDURResolved(inputData);
        connexusTestScripts.getOrderDetailsAndMoveToPickup(Integer.parseInt(fillId));
        pmpRealTimeReportingTestScript.performPickupForDBEntry(inputData, rxNbr, Integer.parseInt(patientId));

        //Once checkout is complete,validate whether there is any entry in audit table in DB
        pmpRealTimeReportingTestScript.verifyEntryInAuditTable(fillId);
        Reporter.log(">>>HWPHME2E_2434_High Profile Non Controlled Drugs are getting reported Entry in DB to PMP in OK state<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
        * Test Description: In OH state, ID scan enabled for multiple states for CSID flow
        * Jira(testID = "HWPHME2E-2800")
        * Author: Lavanya Torrikonda(vn575up)
        ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate in OH state, ID scan enabled for multiple states for CSID flow",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/PMP/PMPRealTimeReportingTestData.json",sheetName = "PMPRealTimeReportingDataSheet")
    public void HWPHME2E_2800_ID_scan_enabled_for_multiple_states_for_CSID_flow_in_OH_state(Map<String, String> inputData) {
        Reporter.log("Validate in OH state, ID scan enabled for multiple states for CSID flow");
        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) TRUE to login to Home office
        connexusAppUtils.readAndUpdateFlag("28750", "TRUE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        //c2 control drug flag
        connexusAppUtils.readAndUpdateFlag("27268", "TRUE");
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        connexusAppUtils.readAndUpdateFlag("29891", "TRUE");
        connexusAppUtils.readAndUpdateFlag("29892", "TRUE");
        connexusAppUtils.updateAgencyRequirementParmTable("TRUE", "11981", statecode);
        connexusAPIManager.flushCache(siteId);
        //steps
        // add insurance with no active card to Patient
        int patient_Id = connexusTestScripts.createPatientAPI(inputData);
        //perform drop off to and move to pickup
        List<String> responseList = connexusTestScripts.createNewOrderTillPickup(inputData,inputData.get("DRUG_NAME1"), patient_Id );
        Reporter.log("Validated in OH state, ID scan enabled for multiple states for CSID flow");
    }

}
