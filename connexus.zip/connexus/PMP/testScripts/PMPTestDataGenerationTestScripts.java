package connexus.PMP.testScripts;
import com.aventstack.extentreports.Status;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import fom.NewERXorderTest;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Drug;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Order;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.CreatePatientRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.InsuranceDetails;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Poller;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import io.strati.libs.forklift.org.apache.commons.io.FileUtils;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

public class PMPTestDataGenerationTestScripts {
    HashMap<String, String> headers = new HashMap<>();
    LoginPage loginPage;
    ConnexusStartPage connexusStartPage;
    PatientSearchPage patientSearchPage;
    TascoPage tascoPage;
    PatientMaintenancePage patientMaintenancePage;
    F6Search orderSearch;
    DropOffPage dropOffPage;
    FourPoint fourPoint;
    InputPage inputPage;
    RxLookUp rxLookUp;
    ChkDur chkdurPage;
    ModifyDetails modifyDetails;
    ConnexusAppUtils connexusAppUtils;
    DropRxModel dropRxModel;
    RxModel rxModel;
    SoftAssert softAssert = new SoftAssert();
    String rxNbr;
    int rxFillId,orderId,rxId,orderSeqNbr;
    AutomationManager am = AutomationManager.getInstance();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    WrapperUtils wrapperUtils = new WrapperUtils();
    DBUtils dbUtils = new DBUtils();
    ServiceResponse resp, durResp, fillResp, vvResp, pickUpResp;
    ServiceRequest req = new ServiceRequest();
    InputResponse inputResponse = new InputResponse();
    int patientID, siteId, orderID, nxtWrkQueCode;
    String inputPickupDate, inputRxExpDate,rxClinicId,prescriberId;
    DataRow drugInfo;
    PropertyReader prop = PropertyReader.getInstance();
    PatientProfileModel patient = new PatientProfileModel();
    AddressModel addressModel = new AddressModel();
    ContactModel contactModel = new ContactModel();
    PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
    ThirdPartyModel thirdPartyModel = new ThirdPartyModel();
    PatientIdentityModel patientIdentityModel=new PatientIdentityModel();
    VisVerPage visVerPage;
    Map<String, Object> visualVerifyRow;

    public PMPTestDataGenerationTestScripts() {
        prop.loadCustomProperties("config/connexus/");
        prop.loadCustomProperties("config/connexustestharness/");
        prop.loadCustomProperties("config/fom/");
    }


    public void loginConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        loginPage = new LoginPage();
        connexusStartPage = new ConnexusStartPage();
        patientSearchPage = new PatientSearchPage();
        tascoPage = new TascoPage();
        patientMaintenancePage = new PatientMaintenancePage();
        dropOffPage = new DropOffPage();
        orderSearch = new F6Search();
        fourPoint = new FourPoint();
        inputPage = new InputPage();
        modifyDetails = new ModifyDetails();
        dropRxModel = new DropRxModel();
        rxModel = new RxModel();
        rxLookUp = new RxLookUp();
        chkdurPage = new ChkDur();
        connexusAppUtils = new ConnexusAppUtils();
        am = AutomationManager.getInstance();
        visVerPage= new VisVerPage();
        loginPage.loginConnexus(userType);
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
    }


    public String performCreatePatientAndCompletePickup(Map<String, String> inputData) {
        siteId=Integer.parseInt(prop.getProperty("cnx.store"));
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        //create patient through API
        resp = connexusAPIManager.createPatient(name[0], name[1], inputData.get("DOB_TIMESTAMP"), Integer.parseInt(prop.getProperty("cnx.store")), Long.parseLong(inputData.get("HOME_PHONE")), Long.parseLong(inputData.get("WORK_PHONE")), Long.parseLong(inputData.get("CELL_PHONE")));
        Log.info(resp.getDataResponse());
        inputResponse = resp.getDataResponse(InputResponse.class);
        Log.info(String.valueOf(inputResponse.getPatientId()));
        patientID = inputResponse.getPatientId();

        //move order to PickUp
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow prescriberDetails=dbUtils.getRxClinicIdAndPrescriberId(cnx);
        rxClinicId=prescriberDetails.getValue("clinic_id").toString().trim();
        prescriberId=prescriberDetails.getValue("prescriber_id").toString().trim();
        inputResponse = connexusAPIManager.createNewOrderToCounsel(patientID, siteId, Integer.parseInt(inputData.get("REFILLS")), inputData.get("DRUG_NAME"), inputData.get("PRESCRIBER_NAME"), inputData.get("PRESCRIBER_FNAME"), inputData.get("PRESCRIBER_LNAME"), inputData.get("PRESCRIBER_PHONE"), inputData.get("PRESCRIBER_STATE"), Integer.parseInt(prescriberId), Integer.parseInt(rxClinicId), Integer.parseInt(inputData.get("rxOriginCode")));
        Reporter.log("orderId = " + inputResponse.getOrderId() + ", rxNbr = " + inputResponse.getRxNbr() + ", rxId = " + inputResponse.getRxId() + ", rxFillId = " + inputResponse.getRxFillId());

        Log.info("RxNbr:" + inputResponse.getRxNbr());
        return String.valueOf(inputResponse.getRxNbr());
    }

    public void performCreatePatientAndCompleteDropOff(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        //setting properties
        int requestTypeCode = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrderPriorityId"));
        int dispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        resp = connexusAPIManager.createPatient(name[1], name[0], inputData.get("DOB_TIMESTAMP"), siteId, Long.parseLong(inputData.get("HOME_PHONE")), Long.parseLong(inputData.get("WORK_PHONE")), Long.parseLong(inputData.get("CELL_PHONE")));
        Log.info(resp.getDataResponse());
        Assert.assertEquals(resp.getStatusCode(), 201, "createPatient API response status code did not match");
        inputResponse = resp.getDataResponse(InputResponse.class);
        patientID = inputResponse.getPatientId();
        inputRxExpDate = wrapperUtils.getExpiryDate();
        inputPickupDate = wrapperUtils.getPickUpDate();
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        //get drug details
        drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("DRUG_NAME"));

        resp = connexusAPIManager.createOrderAndDropOff(requestTypeCode, priorityId, dispenseType, patientID, siteId, inputPickupDate, inputRxExpDate, Integer.parseInt(inputData.get("REFILLS")), drugInfo);
        Assert.assertEquals(resp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");
        inputResponse = resp.getDataResponse(InputResponse.class);
        orderID = inputResponse.getOrderId();
        Reporter.log("orderId = " + inputResponse.getOrderId() + ", rxNbr = " + inputResponse.getRxNbr() + ", rxId = " + inputResponse.getRxId() + ", rxFillId = " + inputResponse.getRxFillId());
    }

    public void durToPickupCompletion(Map<String, String> inputData) {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        chkdurPage.exitFromDur();
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(name[0] + "," + name[1]);
        rxNbr = orderSearch.getRxNbr(0);
        Log.info(rxNbr);
        Reporter.log("Rx number is " + rxNbr);
        orderSearch.closeSearch();
        //setting payload for check DUR based on Rxnbr
        Map<String, Object> rxOrderDetailsFromRxnbr;
        Order order = new Order();
        Drug drug = new Drug();
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        rxOrderDetailsFromRxnbr = dbUtils.getRxOrderDetails(siteId, rxNbr);
        inputRxExpDate = wrapperUtils.getExpiryDate();
        inputPickupDate = wrapperUtils.getPickUpDate();
        int rxFillId = (Integer) rxOrderDetailsFromRxnbr.get("rx_fill_id");
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);

        //get drug details
        DataRow drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("DRUG_NAME"));

        //Set parameters for request payload
        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(prop.getProperty("fom.OrderPriorityId")));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setPatientId(patientID);
        order.setOrderId((Integer) rxOrderDetailsFromRxnbr.get("order_id"));
        order.setSiteID(siteId);
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);
        order.setRxFillId(rxFillId);
        order.setNumRefills(Integer.parseInt(inputData.get("REFILLS")));
        order.setRxId((Integer) rxOrderDetailsFromRxnbr.get("rx_id"));
        order.setOrderSeqNbr(1);
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr"));
        drug.setItemId(drugInfo.getValue("mds_fam_id"));
        drug.setRxProdId(drugInfo.getValue("product_mds_fam_id"));
        drug.setControlCode(drugInfo.getValue("drug_control_code"));
        drug.setPresMultiSrcCode(drugInfo.getValue("multi_source_code"));
        drug.setOnHandQty(Integer.parseInt(drugInfo.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
        drug.setGpiCode(drugInfo.getValue("gpi_code"));
        drug.setUsualCost("0");
        drug.setActCost("0");
        drug.setOrgUsualCost("0");
        order.setPrescriber(wrapperUtils.PrescriberDetails());
        order.setDrug(drug);
        req.setRequestPayloadWithNulls(order);

        //Check DUR
        req.setUrl(prop.getProperty("fom.connexusWrapper.checkDURCompleteUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("CheckDUR Request endpoint: " + req.getUrl());
        Reporter.logJSON("CheckDUR Request", req.getRequestPayload());
        Log.info("CheckDUR RequestPayload:\n" + req.getRequestPayload() + "\n");
        durResp = am.getRestContext().performPost(req);
        Reporter.logJSON("CheckDUR Response", resp.getDataResponse());
        Log.info("CheckDUR ResponsePayload:\n" + resp.getDataResponse() + "\n");
        Assert.assertEquals(durResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
        Assert.assertEquals(durResp.getDataResponse().contains("error"), false, "Check DUR could not be completed");
        Reporter.log("Order successfully moved to Filling queue");

        //Fillcomplete
        fillResp = connexusAPIManager.fillComplete(durResp.getDataResponse());
        Assert.assertEquals(fillResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillResp.getDataResponse().contains("error"), "Fill Complete could not be completed");

        //vvComplete
        vvResp = connexusAPIManager.vvComplete(fillResp.getDataResponse());
        Assert.assertEquals(vvResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvResp.getDataResponse().contains("error"), "Visual Verify could not be completed");
        am.performSleep(10);
        Log.info("VV Complete ResponsePayload:\n" + vvResp.getDataResponse() + "\n");

        //Completes PickUp
        pickUpResp = connexusAPIManager.pickupComplete(vvResp.getDataResponse());
        Assert.assertEquals(pickUpResp.getStatusCode(), 302, "pickUpComplete API response status code did not match");
        Assert.assertFalse(pickUpResp.getDataResponse().contains("error"), "pickUp could not be completed");
        am.performSleep(5);
        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId);
        if (nxtWrkQueCode == WorkQueueCode.COUNSEL.getWorkQueueCode()) {
            Reporter.log("RX is in Counsel queue");
        } else {
            Log.info("RX is not in Counsel Queue");
            Reporter.log("RX is not in counsel queue");
            Assert.fail();
        }
    }

    public void performCreatePatientAndCompleteTillEOD(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        connexusAppUtils.addRandomNamesInFile();
        //setting properties
        int requestTypeCode = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrderPriorityId"));
        int dispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        createNewPatient(inputData);
        patientID=getPatientId(inputData);
        inputRxExpDate = wrapperUtils.getExpiryDate();
        inputPickupDate = wrapperUtils.getPickUpDate();
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        //get drug details
        drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("DRUG_NAME"));

        DataRow prescriberDetails=dbUtils.getRxClinicIdAndPrescriberId(cnx);
        rxClinicId=prescriberDetails.getValue("clinic_id").toString().trim();
        prescriberId=prescriberDetails.getValue("prescriber_id").toString().trim();


        Prescriber prescriber = new Prescriber();
        prescriber.setFullname(inputData.get("PRESCRIBER_FULLNAME"));
        prescriber.setFirstname(inputData.get("PRESCRIBER_FNAME"));
        prescriber.setLastname(inputData.get("PRESCRIBER_LNAME"));
        prescriber.setPhone(inputData.get("PRESCRIBER_PHONE"));
        prescriber.setState(inputData.get("PRESCRIBER_STATE"));
        prescriber.setPrescriberId(Integer.parseInt(prescriberId));
        prescriber.setRxClinicId(Integer.parseInt(rxClinicId));
        prescriber.setDea(prop.getProperty("fom.connexusWrapper.prescriberDea"));
        prescriber.setNpi(prop.getProperty("fom.connexusWrapper.prescriberNpi"));

        //complete drop-off
        resp = connexusAPIManager.createOrderAndDropOff(requestTypeCode, priorityId, dispenseType, patientID, siteId, inputPickupDate, inputRxExpDate, Integer.parseInt(inputData.get("REFILLS")), drugInfo,prescriber,Integer.parseInt(inputData.get("rxOriginCode")));
        Assert.assertEquals(resp.getStatusCode(), 201, "createOrderToPickup API response status code did not match");

        //moveOrderToEOD
        resp = connexusAPIManager.moveOrderToEOD(resp.getDataResponse());
        Assert.assertEquals(resp.getStatusCode(), 201, "NewOrderToEOD API response status code did not match");
        Log.info("resp" + resp.getDataResponse());
        inputResponse=resp.getDataResponse(InputResponse.class);
        Reporter.log("orderId = " + inputResponse.getOrderId() + ", rxNbr = " + inputResponse.getRxNbr() + ", rxId = " + inputResponse.getRxId() + ", rxFillId = " + inputResponse.getRxFillId());
        rxNbr= String.valueOf(inputResponse.getRxNbr());
    }

    public void performDropOffForRXWithRefills() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            dropOffPage.handleEarlyRefillReason();
            dropOffPage.checkAndClickDropOffStation();
            dropOffPage.selectPriority("Critical");
            dropOffPage.clickBtnAccept();
            dropOffPage.checkAndClickDropOffStation();
            dropOffPage.handleStorePickupTimePopup();
            Reporter.log("Drop-Off completed");
        } catch (Throwable e) {
            Reporter.log("Failed at DropOff for RX with Refills");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }
    public void performFilling() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {

            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            Log.info("Rx status" + rxStatus);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                am.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                am.getConnexusWorkFlow().completeFilling(rxNbr);
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                am.getConnexusWorkFlow().completeResolution(rxNbr);
                am.getConnexusWorkFlow().completeFilling(rxNbr);
                Reporter.log("RX is in Resolve queue");
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                Reporter.log("RX is in CASH queue");
                am.getConnexusWorkFlow().completeFilling(rxNbr);
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Filling queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performVisualVerify() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
                am.getConnexusWorkFlow().completeVisualVerify(rxNbr);
            } else {
                Reporter.log("RX is not in Visual Verify queue");
                Assert.fail("RX is not in Visual Verify queue");
            }
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at Visual Verify queue");
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performPickUpForExistingPatient(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())) {
                am.getConnexusWorkFlow().completePickup(inputData.get("FIRST_NAME"), inputData.get("LAST_NAME"), inputData.get("DOB"), rxNbr);
            } else {
                Reporter.log("RX is not in PickUp queue");
                Assert.fail("RX is not in PickUp queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at PickUp queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }


    public void fillingToTillPickUpCompletion(Map<String, String> inputData) {
        Map<String, Object> rxOrderDetailsFromRxnbr;
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        rxOrderDetailsFromRxnbr = dbUtils.getRxOrderDetails(siteId, rxNbr);
        int rxFillId = (Integer) rxOrderDetailsFromRxnbr.get("rx_fill_id");
        int rxId = (int) rxOrderDetailsFromRxnbr.get("rx_id");

        vvResp = connexusAPIManager.fillingToPickup(patientID, orderID, siteId, rxFillId, rxId, Integer.parseInt(inputData.get("REFILLS")), inputData.get("DRUG_NAME"), wrapperUtils.PrescriberDetails());
        Assert.assertEquals(vvResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvResp.getDataResponse().contains("error"), "Visual Verify could not be completed");

        //Completes PickUp
        pickUpResp = connexusAPIManager.pickupComplete(vvResp.getDataResponse());
        Assert.assertEquals(pickUpResp.getStatusCode(), 302, "pickUpComplete API response status code did not match");
        Assert.assertFalse(pickUpResp.getDataResponse().contains("error"), "pickUp could not be completed");
        am.performSleep(5);
        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId);
        if (nxtWrkQueCode == WorkQueueCode.COUNSEL.getWorkQueueCode()) {
            Reporter.log("RX is in Counsel queue");
        } else {
            Log.info("RX is not in Counsel Queue");
            Reporter.log("RX is not in counsel queue");
            Assert.fail();
        }
    }

    public int genericCreatePatientWithTP(Map<String, String> inputData) {

        CreatePatientRequest createPatientRequest = new CreatePatientRequest();
        InsuranceDetails insuranceDetails = new InsuranceDetails();
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        //Build input patient
        createPatientRequest.setFirstName(name[0]);
        createPatientRequest.setLastName(name[1]);
        createPatientRequest.setDob(inputData.get("DOB_TIMESTAMP"));
        createPatientRequest.setSiteId(siteId);
        createPatientRequest.setHomePhone(inputData.get("HOME_PHONE"));
        createPatientRequest.setWorkPhone(inputData.get("WORK_PHONE"));
        createPatientRequest.setCellPhone(inputData.get("CELL_PHONE"));

        //With TP Details
        createPatientRequest.setPatientHasInsurance(Boolean.parseBoolean(inputData.get("patientHasInsurance")));
        insuranceDetails.setInsuranceCarrierPlanId(Integer.parseInt(inputData.get("carrierPlanId")));
        insuranceDetails.setInsuranceCarrierCompanyId(Integer.parseInt(inputData.get("carrierCompanyCode")));
        insuranceDetails.setBillingSeqNbr(Integer.parseInt(inputData.get("billSeqNbr")));
        insuranceDetails.setCardholderId(inputData.get("cardHolderId"));
        insuranceDetails.setCardholderFirstName(inputData.get("cardHolderFirstName"));
        insuranceDetails.setCardholderLastName(inputData.get("cardHolderLastName"));
        insuranceDetails.setRelationshipCode(Integer.parseInt(inputData.get("relationshipCode")));
        insuranceDetails.setCoverageInd(inputData.get("coverageIndicator"));
        insuranceDetails.setCoverageExpDate(inputData.get("covExpDate"));
        insuranceDetails.setSplitBillInd(inputData.get("splitBillInd"));
        insuranceDetails.setInsPlanTypeCode(Integer.parseInt(inputData.get("planTypeCode")));

        createPatientRequest.setInsurance(insuranceDetails);
        int patientId = connexusAPIManager.createPaientWithOrWithoutTP(createPatientRequest);
        return patientId;
    }

    public void performCreatePatientWithTPToPickUpCompletion(Map<String, String> inputData) {
        patientID = genericCreatePatientWithTP(inputData);
        siteId=Integer.parseInt(prop.getProperty("cnx.store"));
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow prescriberDetails=dbUtils.getRxClinicIdAndPrescriberId(cnx);
        rxClinicId=prescriberDetails.getValue("clinic_id").toString().trim();
        prescriberId=prescriberDetails.getValue("prescriber_id").toString().trim();
        inputResponse = connexusAPIManager.createNewOrderToCounsel(patientID, siteId, Integer.parseInt(inputData.get("REFILLS")), inputData.get("DRUG_NAME"), inputData.get("PRESCRIBER_NAME"), inputData.get("PRESCRIBER_FNAME"), inputData.get("PRESCRIBER_LNAME"), inputData.get("PRESCRIBER_PHONE"), inputData.get("PRESCRIBER_STATE"), Integer.parseInt(prescriberId), Integer.parseInt(rxClinicId), Integer.parseInt(inputData.get("rxOriginCode")));
        Reporter.log("orderId = " + inputResponse.getOrderId() + ", rxNbr = " + inputResponse.getRxNbr() + ", rxId = " + inputResponse.getRxId() + ", rxFillId = " + inputResponse.getRxFillId());
        Log.info("RxNbr:" + inputResponse.getRxNbr());
    }

    public void performCreatePatientWithTPToCounsel(Map<String, String> inputData) {
        patientID = genericCreatePatientWithTP(inputData);
        //setting properties
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        inputRxExpDate = wrapperUtils.getExpiryDate();
        inputPickupDate = wrapperUtils.getPickUpDate();
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        //get drug details
        drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("DRUG_NAME"));
        //to get rxClinicId and Prescriber ID
        DataRow prescriberDetails=dbUtils.getRxClinicIdAndPrescriberId(cnx);
        rxClinicId=prescriberDetails.getValue("clinic_id").toString().trim();
        prescriberId=prescriberDetails.getValue("prescriber_id").toString().trim();
        inputResponse = connexusAPIManager.createNewOrderToCounsel(patientID, siteId, Integer.parseInt(inputData.get("REFILLS")), inputData.get("DRUG_NAME"), inputData.get("PRESCRIBER_NAME"), inputData.get("PRESCRIBER_FNAME"), inputData.get("PRESCRIBER_LNAME"), inputData.get("PRESCRIBER_PHONE"), inputData.get("PRESCRIBER_STATE"), Integer.parseInt(prescriberId), Integer.parseInt(rxClinicId), Integer.parseInt(inputData.get("rxOriginCode")));
        Reporter.log("orderId = " + inputResponse.getOrderId() + ", rxNbr = " + inputResponse.getRxNbr() + ", rxId = " + inputResponse.getRxId() + ", rxFillId = " + inputResponse.getRxFillId());

        Log.info("RxNbr:" + inputResponse.getRxNbr());
    }

    public void performERX(Map<String, String> inputData, String xmlPath) throws SQLException, ParserConfigurationException, IOException, SAXException {
        NewERXorderTest newERXorderTest = new NewERXorderTest();
        File xmlData;
        String messageId, inputPayload, ndc, drugName;
        int rxResponseId, fillCount, index;
        List<Integer> respIds = new ArrayList<>();
        Random random_method = new Random();
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        patientID=getPatientIdWithExistingPatient(inputData);
        List<String> orderListFromDB = new ArrayList<>(getOrderIdFromStoreDb(patientID));
        for(int i=0; i<orderListFromDB.size();i++){
            connexusAPIManager.deleteRx(siteId, Integer.parseInt(orderListFromDB.get(i)),patientID);
        }
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);

        //get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientID);

        //get xml file to generate input payload
        xmlData = new File(xmlPath);
        ndc = inputData.get("DRUG_NAME");
        drugName = getDrugName(cnx, inputData.get("DRUG_NAME"));
        Reporter.log("Drug name :" + drugName);
        //update the xml with required storeNbr, Date-time and a unique messageId
        messageId = UUID.randomUUID().toString().substring(0, 35);
        inputPayload = updateXML(xmlData, String.valueOf(siteId), messageId, patientInfo, ndc, drugName);
        Log.info("inputPayload:" +inputPayload);
        //drop ERX order
        rxResponseId =dropERX(inputPayload, String.valueOf(siteId), patientID, messageId, cnx);
        respIds.add(rxResponseId);

    }


    public void performDropOffForARXWithNoRefills() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            dropOffPage.clickDropOffQueue();
            Log.info("RXNBR in dropOFF:" + rxNbr);
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            Assert.assertTrue(dropOffPage.getTextFromRefillRequestPopup().contains("The Prescription is Out Of Refills"));
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickOKonRefillRequestPopUp();
            Assert.assertTrue(dropOffPage.isFaxSendPopUpDisplayed());
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickSendToResolutionOnFaxSendPopUp();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickYesOnFaxNumberPopUp();
            dropOffPage.selectPriority("Critical");
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickBtnAccept();
            dropOffPage.handleStorePickupTimePopup();
            Reporter.log("Drop-Off completed");
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("Failed at dropOff for RX with No Refills");
        }
    }

    public void verifyIfRxIsInResolutionQueue() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            Assert.assertEquals(orderSearch.getWorkQueue(0).toLowerCase(), WorkQueue.RESOLVE.getWorkQueue(),"Order is not in Resolve Queue");
            Assert.assertEquals(orderSearch.getProblemMessage(0), "Need to Call Doctor for Refills");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            orderSearch.closeSearch();
            Reporter.log("RX is in Resolution Queue");
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("RX failed at resolution Queue");
        }
    }

    public void performRefillsAuthorized(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                am.getConnexusWorkFlow().completeResolutionForRefills(rxNbr, inputData.get("REFILLS"), connexusAppUtils.randomName());
            } else {
                Reporter.log("RX is not in Resolve queue");
                Assert.fail("RX is not in Resolve queue");
            }
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("RX failed at Resolve Queue");
        }
    }

    public void performEarlyRefillsAuthorization() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                am.getConnexusWorkFlow().completeResolutionForEarlyRefill(rxNbr);
            } else {
                Reporter.log("RX is not in Resolve queue");
                Assert.fail("RX is not in Resolve queue");
            }
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("Failed while performing early Refills Authorization");
        }
    }

    public void performInput(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxModel.setNdc(inputData.get("DRUG_NAME"));
            rxModel.setPrescribedQty(inputData.get("QUANTITY"));
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            Poller poller =new Poller();
            boolean rxInInputQueue = poller.pollForSuccess(() -> {
                String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
                return rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue());
            });
            if (rxInInputQueue) {
                am.getConnexusWorkFlow().performInput(rxModel);
            } else {
                Reporter.log("RX is not in Input queue");
                Assert.fail("RX is not in Input queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void perform4Point() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue());
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                am.getConnexusWorkFlow().completeResolution(name[0] + "," + name[1]);
            }
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.FOUR_POINT.getWorkQueue())) {
                rxNbr = am.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);
            } else {
                Reporter.log("Rx failed to move to 4 Point queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    public DataRow getPatientInfo(IDatabaseContext cnx, int patientId) {
        String getPatientInfo = "select last_name, first_name, gender_code, birth_date from rx21c:informix.patient \n" +
                "where patient_id = " + patientId + ";";
        DataTable dt = cnx.getDataTable(getPatientInfo);
        Assert.assertEquals(dt.getRowCount(), 1);
        DataRow row = dt.getDataRows().get(0);
        return row;
    }

    public String getDrugName(IDatabaseContext cnx, String ndc) {
        String drugName;
        String getDrugName = "select pp.short_name from pharmacy_offering:pharmacy_product as pp \n" +
                "join pharmacy_offering:pharmacy_item as pi \n" +
                "on pp.product_mds_fam_id = pi.product_mds_fam_id \n" +
                "where pi.ndc_nbr = " + ndc + ";";
        drugName = cnx.getScalar(getDrugName, String.class).trim();
        return drugName;
    }

    public String updateXML(File xmlData, String storeNbr, String messageId, DataRow patientInfo, String ndc, String drugName)
            throws ParserConfigurationException, SAXException, IOException {

        String fileContext = FileUtils.readFileToString(xmlData, StandardCharsets.UTF_8);
        fileContext = fileContext.replaceAll("storeNbr", storeNbr);
        fileContext = fileContext.replaceAll("messageId", messageId);
        String currentTime = getCurrentTime();
        fileContext = fileContext.replaceAll("sentTime", currentTime);
        fileContext = fileContext.replaceAll("writtenDate", currentTime);
        fileContext = fileContext.replaceAll("patientLastName", patientInfo.getValue("last_name").toString().trim());
        fileContext = fileContext.replaceAll("patientFirstName", patientInfo.getValue("first_name").toString().trim());
        fileContext = fileContext.replaceAll("patientGender", patientInfo.getValue("gender_code"));
        fileContext = fileContext.replaceAll("patientDOB", patientInfo.getValue("birth_date").toString());
        fileContext = fileContext.replaceAll("drugName", drugName);
        fileContext = fileContext.replaceAll("ndc", ndc);
        return fileContext;
    }

    public String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String Ts = sdf.format(timestamp);
        return Ts;
    }

    public int dropERX(String inputPayload, String storeNbr, int patientId, String messageId, IDatabaseContext cnx) throws SQLException {

        //drop ERX via POST
        headers.put("content-type", "application/xml");
        headers.put("User-Agent", "PostmanRuntime/7.28.4");
        headers.put("Accept", "*/*");
        headers.put("Accept-Encoding", "gzip, deflate, br");
        headers.put("Connection", "keep-alive");
        req.setHeaders(headers);
        req.setUrl("https://rxInt-PharmacySSerxv2inboundreq-qa-edc.wal-mart.com/services/ProcessERx");
        req.setRequestPayload(inputPayload);
        Reporter.log("Drop ERX Request Payload" +req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        Reporter.log("Drop ERX response" +resp.getDataResponse());

        //verify POST request is successful
        Assert.assertEquals(resp.getStatusCode(), 200, "Drop ERX POST request returned error");
        Reporter.log("ERX order posting successful for patientId = " + patientId + " in store # " + storeNbr +
                ". The resp message_id is " + messageId);

        // verify ERX order is created --> response_stat_code = 26005 in raw_eltnc_rx_resp table
        int rxResponseId=0;
        //rxResponseId  = verifyOrderCreation(cnx, messageId);

        return rxResponseId;
    }

    public int verifyOrderCreation(IDatabaseContext cnx, String messageId) throws SQLException {

        String query = "select response_stat_code, rx_response_id from rx21c:informix.raw_eltnc_rx_resp where \n" +
                "resp_message_id = '" + messageId + "';";
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1,"Required message id is not available in Informix DB");
        DataRow row = dt.getDataRows().get(0);
        int respStatCode = (short) row.getValue("response_stat_code");
        Reporter.log("respStatCode:" +respStatCode);
        Assert.assertEquals(respStatCode, 26005, "ERX order processing failed");
        int rxRespId = row.getValue("rx_response_id");
        return rxRespId;
    }

    public void clearCache(){
        callFlushCacheAPI(prop.getProperty("cnx.store"));
    }
    public void callFlushCacheAPI(String siteID) {
        String serviceEndPointURL = StoreIDManager.createEndPointURL(siteID, prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexustestharness.flushCacheEndPoint"));
        req.setUrl(serviceEndPointURL);
        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        resp = am.getRestContext().performPost(req);
        Assert.assertEquals(resp.getStatusCode(), 200, "Flush Cache not Successful");
        Log.info("Flush Cache Successful");
    }
    public int getPatientId(Map<String, String> inputData){
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String query = "select patient_id from patient where first_name= " + "'" + name[1].toUpperCase() + "'" + " and last_name = " + "'" + name[0].toUpperCase() + "';";
        Log.info(query);
        int siteID = Integer.parseInt(prop.getProperty("cnx.store"));
        IDatabaseContext cnx = am.getConnexusDB(siteID);
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1,"PatientId is not reflecting in informix DB with required patient firstname and lastname");
        DataRow row = dt.getDataRows().get(0);
        int patientId = row.getValue("patient_id");
        return patientId;
    }
    public int getPatientIdWithExistingPatient(Map<String, String> inputData){
        String query = "select patient_id from patient where first_name= " + "'" + inputData.get("FIRST_NAME") + "'" + " and last_name = " + "'" + inputData.get("LAST_NAME") + "';";
        Log.info(query);
        int siteID = Integer.parseInt(prop.getProperty("cnx.store"));
        Log.info("siteId:" +siteID);
        int patientId = am.getConnexusDB(siteID).getScalar
                (query, Integer.class);
        Log.info("patientId:" +patientId);
        return patientId;
    }


    public void performInputWithExistingPatientName(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            rxModel.setPatientLastName(inputData.get("LAST_NAME"));
            rxModel.setPatientFirstName(inputData.get("FIRST_NAME"));
            rxModel.setNdc(inputData.get("DRUG_NAME"));
            rxModel.setPrescribedQty(inputData.get("QUANTITY"));
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            String rxStatus = orderSearch.getRXStatusForPatient(inputData.get("LAST_NAME") + "," + inputData.get("FIRST_NAME"), 0);
            orderSearch.getRXStatusForPatient(inputData.get("LAST_NAME") + "," + inputData.get("FIRST_NAME"), 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue())) {
                am.getConnexusWorkFlow().performInput(rxModel);
            } else {
                Reporter.log("RX is not in Input queue");
                Assert.fail();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Input queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void perform4PointWithExistingPatient(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(inputData.get("LAST_NAME") + "," + inputData.get("FIRST_NAME"), 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                am.performSleep(10);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                am.getConnexusWorkFlow().completeResolution(inputData.get("LAST_NAME") + "," + inputData.get("FIRST_NAME"));
            }
            rxNbr = am.getConnexusWorkFlow().performFourPoint(inputData.get("LAST_NAME") + "," + inputData.get("FIRST_NAME"));
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void performcreatePatientAndCompleteDropOff(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        createNewPatient(inputData);
        patientID = getPatientId(inputData);
        //setting properties
        int requestTypeCode = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrderPriorityId"));
        int dispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        inputRxExpDate = wrapperUtils.getExpiryDate();
        inputPickupDate = wrapperUtils.getPickUpDate();
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        //get drug details
        drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("DRUG_NAME"));

        resp = connexusAPIManager.createOrderAndDropOff(requestTypeCode, priorityId, dispenseType, patientID, siteId, inputPickupDate, inputRxExpDate, Integer.parseInt(inputData.get("REFILLS")), drugInfo);
        Assert.assertEquals(resp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");
        inputResponse = resp.getDataResponse(InputResponse.class);
        orderID = inputResponse.getOrderId();
        Reporter.log("orderId = " + inputResponse.getOrderId() + ", rxNbr = " + inputResponse.getRxNbr() + ", rxId = " + inputResponse.getRxId() + ", rxFillId = " + inputResponse.getRxFillId());
    }
    public void createNewPatient(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);

            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            patient.setPatientTp(thirdPartyModel);
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
            patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
            patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));
            patient.setPatientIdentityModel(patientIdentityModel);


            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);
            if (connexusStartPage.isConnexusLaunched()) {
                am.getConnexusWorkFlow().createNewPatient(false, patient);
                Reporter.log("Patient has been created.");
            } else {
                Reporter.log("Connexus not launched");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Connexus not launched");
                }

        } catch (Throwable e) {
            Reporter.log("Failed while creating patient");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public List<String> getOrderIdFromStoreDb(int patientId) {
        List<String> orderColumnValues = new ArrayList<>();
        String query =
                "select order_id from informix.rx_order_detail where rx_id in (select rx_id from rx where patient_id=" + patientId +");";

        List<Map<String, Object>> resultSet;
        resultSet = am.getConnexusDB().executeQueryForList(query);
        if (resultSet != null) {
            for(Map<String,Object> row : resultSet) {
                String values = row.get("order_id").toString().trim();
                orderColumnValues.add(values);
            }
        }
        Reporter.log("State list size from DB:" + orderColumnValues.size());
        return orderColumnValues;
    }



    public void durToPickupCompletionWithExistingPatient(Map<String, String> inputData) {
        chkdurPage.exitFromDur();
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(inputData.get("LAST_NAME") + "," + inputData.get("FIRST_NAME"));
        rxNbr = orderSearch.getRxNbr(0);
        Reporter.log("Rx number is " + rxNbr);
        orderSearch.closeSearch();
        //setting payload for check DUR based on Rxnbr
        Map<String, Object> rxOrderDetailsFromRxnbr;
        Order order = new Order();
        Drug drug = new Drug();
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        rxOrderDetailsFromRxnbr = dbUtils.getRxOrderDetails(siteId, rxNbr);
        inputRxExpDate = wrapperUtils.getExpiryDate();
        inputPickupDate = wrapperUtils.getPickUpDate();
        int rxFillId = (Integer) rxOrderDetailsFromRxnbr.get("rx_fill_id");
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);

        //get drug details
        DataRow drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("DRUG_NAME"));

        //Set parameters for request payload
        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(prop.getProperty("fom.OrderPriorityId")));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setPatientId(patientID);
        order.setOrderId((Integer) rxOrderDetailsFromRxnbr.get("order_id"));
        order.setSiteID(siteId);
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);
        order.setRxFillId(rxFillId);
        order.setNumRefills(Integer.parseInt(inputData.get("REFILLS")));
        order.setRxId((Integer) rxOrderDetailsFromRxnbr.get("rx_id"));
        order.setOrderSeqNbr(1);
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr"));
        drug.setItemId(drugInfo.getValue("mds_fam_id"));
        drug.setRxProdId(drugInfo.getValue("product_mds_fam_id"));
        drug.setControlCode(drugInfo.getValue("drug_control_code"));
        drug.setPresMultiSrcCode(drugInfo.getValue("multi_source_code"));
        drug.setOnHandQty(Integer.parseInt(drugInfo.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
        drug.setGpiCode(drugInfo.getValue("gpi_code"));
        drug.setUsualCost("0");
        drug.setActCost("0");
        drug.setOrgUsualCost("0");
        order.setPrescriber(wrapperUtils.PrescriberDetails());
        order.setDrug(drug);
        req.setRequestPayloadWithNulls(order);

        //Check DUR
        req.setUrl(prop.getProperty("fom.connexusWrapper.checkDURCompleteUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("CheckDUR Request endpoint: " + req.getUrl());
        Reporter.logJSON("CheckDUR Request", req.getRequestPayload());
        Log.info("CheckDUR RequestPayload:\n" + req.getRequestPayload() + "\n");
        durResp = am.getRestContext().performPost(req);
        Reporter.logJSON("CheckDUR Response", resp.getDataResponse());
        Log.info("CheckDUR ResponsePayload:\n" + resp.getDataResponse() + "\n");
        Assert.assertEquals(durResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
        Assert.assertEquals(durResp.getDataResponse().contains("error"), false, "Check DUR could not be completed");
        Reporter.log("Order successfully moved to Filling queue");

        //Fillcomplete
        fillResp = connexusAPIManager.fillComplete(durResp.getDataResponse());
        Assert.assertEquals(fillResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillResp.getDataResponse().contains("error"), "Fill Complete could not be completed");

        //vvComplete
        vvResp = connexusAPIManager.vvComplete(fillResp.getDataResponse());
        Assert.assertEquals(vvResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvResp.getDataResponse().contains("error"), "Visual Verify could not be completed");
        am.performSleep(10);
        Log.info("VV Complete ResponsePayload:\n" + vvResp.getDataResponse() + "\n");

        //Completes PickUp
        pickUpResp = connexusAPIManager.pickupComplete(vvResp.getDataResponse());
        Assert.assertEquals(pickUpResp.getStatusCode(), 302, "pickUpComplete API response status code did not match");
        Assert.assertFalse(pickUpResp.getDataResponse().contains("error"), "pickUp could not be completed");
        am.performSleep(5);
        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId);
        if (nxtWrkQueCode == WorkQueueCode.COUNSEL.getWorkQueueCode()) {
            Reporter.log("RX is in Counsel queue");
        } else {
            Log.info("RX is not in Counsel Queue");
            Reporter.log("RX is not in counsel queue");
            Assert.fail("RX is not in counsel queue");
        }
    }
    public void performPickUpWithRxNbr(Map<String, String> inputData,String rxNbr,int patientId) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            resp = connexusAPIManager.getPatientInformation(siteId,patientId,"");
            Gson gson = new Gson();
            JsonObject root = gson.fromJson(resp.getDataResponse(), JsonObject.class);

            JsonObject patient = root.getAsJsonObject("Patient");
            JsonObject generalInfo = patient.getAsJsonObject("PatGeneralInfo");
            JsonObject personalInfo = generalInfo.getAsJsonObject("PersonalInfo");
            String firstName = personalInfo.get("FirstName").getAsString();
            String lastName = personalInfo.get("LastName").getAsString();
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())) {
                am.getConnexusWorkFlow().completePickup(firstName.trim(), lastName.trim(), inputData.get("DOB"), rxNbr);
            } else {
                Reporter.log("RX is not in PickUp queue");
                Assert.fail("RX is not in PickUp queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at PickUp queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void fillingToPickUpCompletion(Map<String, String> inputData){
        //setting payload for Filling based on Rxnbr
        Map<String, Object> getRxOrderDetailsFromPatientId;
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        getRxOrderDetailsFromPatientId = dbUtils.getRxOrderDetailsFromPatientId(siteId, String.valueOf(patientID),WorkQueueCode.FILLING.getWorkQueueCode());
        inputRxExpDate = wrapperUtils.getExpiryDate();
        inputPickupDate = wrapperUtils.getPickUpDate();
        int rxFillId = (Integer) getRxOrderDetailsFromPatientId.get("rx_fill_id");
        int orderId = (Integer) getRxOrderDetailsFromPatientId.get("order_id");
        int rxId = (Integer) getRxOrderDetailsFromPatientId.get("rx_id");
        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId);
        Assert.assertEquals(WorkQueueCode.FILLING.getWorkQueueCode(),nxtWrkQueCode,"Rx is not Filling Queue");
        Prescriber prescriber = new Prescriber();
        prescriber.setFullname(inputData.get("PRESCRIBER_FULLNAME"));
        prescriber.setFirstname(inputData.get("PRESCRIBER_FNAME"));
        prescriber.setLastname(inputData.get("PRESCRIBER_LNAME"));
        prescriber.setPhone(inputData.get("PRESCRIBER_PHONE"));
        prescriber.setState(inputData.get("PRESCRIBER_STATE"));
        prescriber.setPrescriberId(Integer.parseInt(inputData.get("PRESCRIBER_ID")));
        prescriber.setRxClinicId(Integer.parseInt(inputData.get("PRESCRIBER_RX_CLINIC_ID")));
        prescriber.setDea(prop.getProperty("fom.connexusWrapper.prescriberDea"));
        prescriber.setNpi(prop.getProperty("fom.connexusWrapper.prescriberNpi"));
        vvResp=connexusAPIManager.fillingToPickup(424780,orderId,siteId,rxFillId,rxId, Integer.parseInt(inputData.get("REFILLS")),inputData.get("DRUG_NAME"),prescriber);
        //complete PickUp
        pickUpResp=connexusAPIManager.pickupComplete(vvResp.getDataResponse());
        Assert.assertEquals(pickUpResp.getStatusCode(), 302, "PickupComplete API response status code did not match");
        Assert.assertFalse(pickUpResp.getDataResponse().contains("error"), "Pickup could not be completed");
        inputResponse=pickUpResp.getDataResponse(InputResponse.class);

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId);
        Assert.assertEquals(WorkQueueCode.COUNSEL.getWorkQueueCode(),nxtWrkQueCode,"Rx is in counsel Queue");
        Log.info("Rx Nbr After pickUp:"  +inputResponse.getRxNbr());
        Reporter.log("Rx Nbr After pickUp:"  +inputResponse.getRxNbr());

    }
    public int createPatientWithOutSSN(Map<String, String> inputData){
        createNewPatient(inputData);
        patientID = getPatientId(inputData);
        return patientID;
    }
    public int createPatientWithSSN(Map<String, String> inputData){
        createNewPatientWithSSNDL(inputData);
        patientID = getPatientId(inputData);
        return patientID;
    }


    public String performOrderDropOffAndCompleteVV(Map<String, String> inputData,int patient) {
        siteId=Integer.parseInt(prop.getProperty("cnx.store"));
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow prescriberDetails=dbUtils.getRxClinicIdAndPrescriberId(cnx);
        rxClinicId=prescriberDetails.getValue("clinic_id").toString().trim();
        prescriberId=prescriberDetails.getValue("prescriber_id").toString().trim();
        inputResponse = connexusAPIManager.createNewOrderToVV(patient, siteId, Integer.parseInt(inputData.get("REFILLS")), inputData.get("DRUG_NAME"), inputData.get("PRESCRIBER_FULLNAME"), inputData.get("PRESCRIBER_FNAME"), inputData.get("PRESCRIBER_LNAME"), inputData.get("PRESCRIBER_PHONE"), inputData.get("PRESCRIBER_STATE"), Integer.parseInt(prescriberId), Integer.parseInt(rxClinicId), Integer.parseInt(inputData.get("rxOriginCode")));
        Reporter.log("orderId = " + inputResponse.getOrderId() + ", rxNbr = " + inputResponse.getRxNbr() + ", rxId = " + inputResponse.getRxId() + ", rxFillId = " + inputResponse.getRxFillId());

        Log.info("RxNbr:" + inputResponse.getRxNbr());
        return String.valueOf(inputResponse.getRxNbr());
    }

    public void performDropOff() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            am.getConnexusWorkFlow().performDropRx(dropRxModel);
        } catch (Throwable e) {
            Reporter.log("Test failed at DropOff queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performERXWithNewPatient(Map<String, String> inputData, String xmlPath) throws SQLException, ParserConfigurationException, IOException, SAXException {
        NewERXorderTest newERXorderTest = new NewERXorderTest();
        File xmlData;
        String messageId, inputPayload, ndc, drugName;
        int rxResponseId, fillCount, index;
        List<Integer> respIds = new ArrayList<>();
        Random random_method = new Random();
        String siteID =prop.getProperty("cnx.store");
        createNewPatient(inputData);
        patientID = getPatientId(inputData);
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(Integer.parseInt(siteID));
        //get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientID);
        //get xml file to generate input payload
        xmlData = new File(xmlPath);
        ndc = inputData.get("DRUG_NAME");
        drugName = getDrugName(cnx, inputData.get("DRUG_NAME"));
        Reporter.log("Drug name :" + drugName);
        //update the xml with required storeNbr, Date-time and a unique messageId
        messageId = UUID.randomUUID().toString().substring(0, 35);
        if(siteID.length()==4) {
            siteID="0"+siteID;
        }
        inputPayload = updateXML(xmlData, siteID, messageId, patientInfo, ndc, drugName);
        Log.info("inputPayload:" +inputPayload);
        //drop ERX order
        rxResponseId =dropERX(inputPayload, siteID, patientID, messageId, cnx);
        respIds.add(rxResponseId);
        Log.info("Dropping ERX is completed");
    }

    public String performCreatePatientUIAndCompleteDUR(Map<String, String> inputData) {
        siteId=Integer.parseInt(prop.getProperty("cnx.store"));
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        //get drug details
        drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("DRUG_NAME"));
        //to get rxClinicId and Prescriber ID
        DataRow prescriberDetails=dbUtils.getRxClinicIdAndPrescriberId(cnx);
        rxClinicId=prescriberDetails.getValue("clinic_id").toString().trim();
        prescriberId=prescriberDetails.getValue("prescriber_id").toString().trim();

        createNewPatient(inputData);
        patientID = getPatientId(inputData);
        Log.info("rxOriginCode:" +inputData.get("rxOriginCode"));
        inputResponse = connexusAPIManager.createNewOrderToDur(patientID, siteId, Integer.parseInt(inputData.get("REFILLS")), inputData.get("DRUG_NAME"), inputData.get("PRESCRIBER_FULLNAME"), inputData.get("PRESCRIBER_FNAME"), inputData.get("PRESCRIBER_LNAME"), inputData.get("PRESCRIBER_PHONE"), inputData.get("PRESCRIBER_STATE"), Integer.parseInt(prescriberId), Integer.parseInt(rxClinicId), inputData.get("rxOriginCode"));
        Reporter.log("orderId = " + inputResponse.getOrderId() + ", rxNbr = " + inputResponse.getRxNbr() + ", rxId = " + inputResponse.getRxId() + ", rxFillId = " + inputResponse.getRxFillId());
        rxNbr= String.valueOf(inputResponse.getRxNbr());
        rxFillId=inputResponse.getRxFillId();

        Log.info("RxNbr:" + rxNbr);
        nxtWrkQueCode=dbUtils.getNextWorkQueCode(siteId,rxFillId);
        if(nxtWrkQueCode==WorkQueueCode.FILLING.getWorkQueueCode()){
            Reporter.log("Order is in filling");
        }
        else{
            Assert.fail("Order not moved to filling. Please verify the rxNbr");
        }
        return String.valueOf(rxNbr);
    }

    public void performInitialFill() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusBasedOnRxIndex(rxNbr, 1);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                am.performSleep(20);
            }

            if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                am.getConnexusWorkFlow().completeFilling(rxNbr);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                am.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusBasedOnRxIndex(rxNbr, 1);
            if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                am.getConnexusWorkFlow().completeFilling(rxNbr);
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                am.getConnexusWorkFlow().completeResolution(rxNbr);
                am.getConnexusWorkFlow().completeFilling(rxNbr);
                Reporter.log("RX is in Resolve queue");
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                Reporter.log("RX is in CASH queue");
                am.performSleep(10);
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr,1);
                if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
                {
                    am.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                am.getConnexusWorkFlow().completeFilling(rxNbr);
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Filling queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }
    public void performVisualVerify(int index){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        try {
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            patientSearchPage.openSecondPatientRecord();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
            visVerPage.handleIHaveOrderPopUp();
            visVerPage.clickCancelButtonOnPopUp();
            visVerPage.clickAccept();
            visVerPage.clickOk();
            Reporter.log("Visual Verify completed");
        } catch (Throwable e) {
            Reporter.log("Test failed at Visual Verify queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }
    public void performPickupForInialFill(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())) {
                am.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("DOB"), rxNbr);
            } else {
                Reporter.log("RX is not in PickUp queue");
                Assert.fail("RX is not in PickUp queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at PickUp queue");
            softAssert.fail("Test failed at PickUp queue");
        }

    }

    public void performPartialFilling(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if(rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())){
                am.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if(rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())){
                am.getConnexusWorkFlow().completePartialFilling(rxNbr);
            }
            else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                am.getConnexusWorkFlow().completeResolution(rxNbr);
                am.getConnexusWorkFlow().completePartialFilling(rxNbr);
                Reporter.log("RX is in Resolve queue");
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                Reporter.log("RX is in CASH queue");
                am.performSleep(10);
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr,1);
                if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
                {
                    am.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                am.getConnexusWorkFlow().completePartialFilling(rxNbr);
            }
        }catch (Throwable e) {
            Reporter.log("Test failed at Filling queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }
    public void performVVandPickup(Map<String, String> inputData){
        //setting payload for Filling based on Rxnbr
        Map<String, Object> getRxOrderDetailsFromPatientId;
        Map<String, Object> getRxOrderDetails;
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        getRxOrderDetails=dbUtils.getRxOrderDetails(siteId,rxNbr);
        int nxt_wrk_que_code= (short) getRxOrderDetails.get("next_work_que_code");
        if(nxt_wrk_que_code ==WorkQueueCode.VISUALVERIFY.getWorkQueueCode()) {
            getRxOrderDetailsFromPatientId = dbUtils.getRxOrderDetailsFromPatientId(siteId, String.valueOf(patientID), WorkQueueCode.VISUALVERIFY.getWorkQueueCode());
            inputRxExpDate = wrapperUtils.getExpiryDate();
            inputPickupDate = wrapperUtils.getPickUpDate();
            am.performSleep(3);
            int rxFillId = (int) getRxOrderDetailsFromPatientId.get("rx_fill_id");
            int orderId = (int) getRxOrderDetailsFromPatientId.get("order_id");
            int rxId = (int) getRxOrderDetailsFromPatientId.get("rx_id");
            int orderSeqNbr = (short) getRxOrderDetailsFromPatientId.get("order_seq_nbr");

            IDatabaseContext cnx = am.getConnexusDB(siteId);
            DataRow prescriberDetails = dbUtils.getRxClinicIdAndPrescriberId(cnx);
            rxClinicId = prescriberDetails.getValue("clinic_id").toString().trim();
            prescriberId = prescriberDetails.getValue("prescriber_id").toString().trim();


            Prescriber prescriber = new Prescriber();
            prescriber.setFullname(inputData.get("PRESCRIBER_FULLNAME"));
            prescriber.setFirstname(inputData.get("PRESCRIBER_FNAME"));
            prescriber.setLastname(inputData.get("PRESCRIBER_LNAME"));
            prescriber.setPhone(inputData.get("PRESCRIBER_PHONE"));
            prescriber.setState(inputData.get("PRESCRIBER_STATE"));
            prescriber.setPrescriberId(Integer.parseInt(prescriberId));
            prescriber.setRxClinicId(Integer.parseInt(rxClinicId));
            prescriber.setDea(prop.getProperty("fom.connexusWrapper.prescriberDea"));
            prescriber.setNpi(prop.getProperty("fom.connexusWrapper.prescriberNpi"));

            inputResponse = connexusAPIManager.performVisualVerifyAndPickup(patientID, orderId, siteId, rxFillId, rxId, Integer.parseInt(rxNbr), Integer.parseInt(inputData.get("REFILLS")), orderSeqNbr, inputData.get("DRUG_NAME"), prescriber);

            Reporter.log("orderId = " + inputResponse.getOrderId() + ", rxNbr = " + inputResponse.getRxNbr() + ", rxId = " + inputResponse.getRxId() + ", rxFillId = " + inputResponse.getRxFillId());

            Log.info("RxNbr:" + inputResponse.getRxNbr());
        }
        else {
            Assert.fail("Order not in visual verify or failed while processing the API related to VV and Pickup");
        }
    }

    public void performPickUpWithSSNValidation(Map<String, String> inputData,String rxNbr,int patientId ) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        siteId=Integer.parseInt(prop.getProperty("cnx.store"));
        try {
            resp = connexusAPIManager.getPatientInformation(siteId,patientId,"");
            Gson gson = new Gson();
            JsonObject root = gson.fromJson(resp.getDataResponse(), JsonObject.class);

            JsonObject patient = root.getAsJsonObject("Patient");
            JsonObject generalInfo = patient.getAsJsonObject("PatGeneralInfo");
            JsonObject personalInfo = generalInfo.getAsJsonObject("PersonalInfo");
            String firstName = personalInfo.get("FirstName").getAsString();
            String lastName = personalInfo.get("LastName").getAsString();
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())) {
                am.getConnexusWorkFlow().completePickupWithSSNValidation(firstName.trim(), lastName.trim(), inputData.get("DOB"), rxNbr, String.valueOf(siteId));
            } else {
                Reporter.log("RX is not in PickUp queue");
                Assert.fail("RX is not in PickUp queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at PickUp queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void createNewPatientWithSSNDL(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);

            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            patient.setPatientTp(thirdPartyModel);
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
            patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
            patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));
            patientIdentityModel.setPatientSSNNumber(Long.valueOf(inputData.get("SSN")));
            patient.setPatientIdentityModel(patientIdentityModel);


            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);
            if (connexusStartPage.isConnexusLaunched()) {
                am.getConnexusWorkFlow().createNewPatient(false, patient);
                Reporter.log("Patient has been created.");
            } else {
                Reporter.log("Connexus not launched");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Connexus not launched");
                }

        } catch (Throwable e) {
            Reporter.log("Failed while creating patient");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }
    public String performCreatePatientUIWithSSNDLAndCompleteVV(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        createNewPatientWithSSNDL(inputData);
        patientID = getPatientId(inputData);
        inputResponse = connexusAPIManager.createNewOrderToVV(patientID, Integer.parseInt(prop.getProperty("cnx.store")), Integer.parseInt(inputData.get("REFILLS")), inputData.get("DRUG_NAME"), inputData.get("PRESCRIBER_FULLNAME"), inputData.get("PRESCRIBER_FNAME"), inputData.get("PRESCRIBER_LNAME"), inputData.get("PRESCRIBER_PHONE"), inputData.get("PRESCRIBER_STATE"), Integer.parseInt(inputData.get("PRESCRIBER_ID")), Integer.parseInt(inputData.get("PRESCRIBER_RX_CLINIC_ID")), Integer.parseInt(inputData.get("rxOriginCode")));
        Reporter.log("orderId = " + inputResponse.getOrderId() + ", rxNbr = " + inputResponse.getRxNbr() + ", rxId = " + inputResponse.getRxId() + ", rxFillId = " + inputResponse.getRxFillId());
        rxNbr= String.valueOf(inputResponse.getRxNbr());
        Log.info("RxNbr:" + inputResponse.getRxNbr());
        return rxNbr;
    }
    public void performPickUp(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())) {
                am.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("DOB"), rxNbr);
            } else {
                Reporter.log("RX is not in PickUp queue");
                Assert.fail("RX is not in PickUp queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at PickUp queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }
    public String getPatientFN(int storeNumber, int patientId){
        String query = "select * from informix.patient where patient_id = " + patientId + ";";
        Map<String, Object> patientDetails = am.getConnexusDB(storeNumber).executeQuery(query);
        Object firstName = patientDetails.get("first_name");
        return (String) firstName;
    }
    public String getPatientLN(int storeNumber, int patientId){
        String query = "select  * from informix.patient where patient_id = " + patientId + ";";
        Map<String, Object> patientDetails = am.getConnexusDB(storeNumber).executeQuery(query);
        Object lastName = patientDetails.get("last_name");
        return (String) lastName;
    }

    public void restartService(){
        connexusAPIManager.restartConnexusService(prop.getProperty("cnx.store"));
    }
    public void performVVandPickupForMatchingWorkqueueCode(Map<String, String> inputData){
        //setting payload for Filling based on Rxnbr
        Poller poller1 = new Poller();
        boolean isVVRowAvailable = poller1.pollForSuccess(() -> {
            visualVerifyRow = null;
            List<Map<String, Object>> rows;
            rows = dbUtils.getRxOrderDetailsForList(siteId, rxNbr);
            for (Map<String, Object> row : rows) {
                Object nxt_wrk_que_codeObj = row.get("next_work_que_code");
                if (nxt_wrk_que_codeObj != null) {
                    String nxt_wrk_que_codeStr = nxt_wrk_que_codeObj.toString().trim();
                    if (!nxt_wrk_que_codeStr.isEmpty()) {
                        int nxt_wrk_que_code = Integer.parseInt(nxt_wrk_que_codeStr);
                        if (nxt_wrk_que_code == 10) {
                            visualVerifyRow = row;
                            return true;
                        }
                    }
                }
            }
            return false;
        });
        if(!isVVRowAvailable){
            Assert.fail("No matching order found with next work queue as 10");
        }
        rxFillId = (int) visualVerifyRow.get("rx_fill_id");
        orderId = (int) visualVerifyRow.get("order_id");
        rxId = (int) visualVerifyRow.get("rx_id");
        orderSeqNbr = (short) visualVerifyRow.get("order_seq_nbr");
        Poller poller2 = new Poller();
        boolean isWorkQueueCodeAvailable = poller2.pollForSuccess(() -> {
            int nxt_wrk_que_code = dbUtils.getNextWorkQueCode(siteId, rxFillId);
            return nxt_wrk_que_code == WorkQueueCode.VISUALVERIFY.getWorkQueueCode();
        });
        if(isWorkQueueCodeAvailable) {
            inputRxExpDate = wrapperUtils.getExpiryDate();
            inputPickupDate = wrapperUtils.getPickUpDate();
            IDatabaseContext cnx = am.getConnexusDB(siteId);
            DataRow prescriberDetails = dbUtils.getRxClinicIdAndPrescriberId(cnx);
            rxClinicId = prescriberDetails.getValue("clinic_id").toString().trim();
            prescriberId = prescriberDetails.getValue("prescriber_id").toString().trim();
            Prescriber prescriber= connexusAPIManager.PrescriberDetails();
            inputResponse = connexusAPIManager.performVisualVerifyAndPickup(patientID, orderId, siteId, rxFillId, rxId, Integer.parseInt(rxNbr), Integer.parseInt(inputData.get("REFILLS")), orderSeqNbr, inputData.get("DRUG_NAME"), prescriber);
            Reporter.log("orderId = " + inputResponse.getOrderId() + ", rxNbr = " + inputResponse.getRxNbr() + ", rxId = " + inputResponse.getRxId() + ", rxFillId = " + inputResponse.getRxFillId());
            Log.info("RxNbr:" + inputResponse.getRxNbr());
        }
        else {
            Assert.fail("Order not in visual verify or failed while processing the API related to VV and Pickup");
        }
    }

}