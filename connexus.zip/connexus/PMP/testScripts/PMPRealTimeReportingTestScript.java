package connexus.PMP.testScripts;

import com.aventstack.extentreports.Status;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.*;

public class PMPRealTimeReportingTestScript {

    LoginPage loginPage;
    ConnexusStartPage connexusStartPage;
    PatientSearchPage patientSearchPage;
    TascoPage tascoPage;
    PatientMaintenancePage patientMaintenancePage;
    DropOffPage dropOffPage;
    ConnexusAppUtils connexusAppUtils;
    AutomationManager automationManager;
    FourPoint fourPoint;
    PropertyReader prop = PropertyReader.getInstance();
    SoftAssert softAssert = new SoftAssert();
    ModifyDetails modifyDetails;
    InputPage inputPage;
    VisVerPage visVerPage;
    String rxNbr = null;
    PatientProfileModel patient = new PatientProfileModel();
    AddressModel addressModel = new AddressModel();
    ThirdPartyModel thirdPartyModel = new ThirdPartyModel();
    ContactModel contactModel = new ContactModel();
    PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
    AutomationManager am = AutomationManager.getInstance();
    ServiceResponse resp;
    InputResponse inputResp = new InputResponse();
    ConnexusAPIManager connexusApiManager = new ConnexusAPIManager();
    int siteId, rxFillId, orderId, orderSeqNbr,rxId;
    int patientId, numRefills, patientIdFromName;
    List<String> ndcList;
    F6Search orderSearch;
    DropRxModel dropRxModel;
    RxModel rxModel;
    RxLookUp rxLookUp;

    List<InputResponse> multiRx4PointCompleteResp = new ArrayList<>();
    List<String> multiRxNbr = new ArrayList<>();
    List<String> multiRxVVCompleteResp = new ArrayList<>();
    List<String> rxResponseList = new ArrayList<>();
    List<String> multiRxNbrList = new ArrayList<>();
    ServiceResponse vvCompleteResp;
    Map<String, Object> values = new HashMap<>();
    Map<String, Integer> value = new HashMap<>();
    List<String> orderInfoList = new ArrayList<>();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    ConnexusTestScripts connexusTestScripts = new ConnexusTestScripts();

    public PMPRealTimeReportingTestScript() {
        connexusAppUtils = new ConnexusAppUtils();
        automationManager = AutomationManager.getInstance();
        prop.loadCustomProperties("config/connexus/");
        prop.loadCustomProperties("config/connexusharness/");
        prop.loadCustomProperties("config/connexuswrapperapicontext/");
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
    }

    public void loginConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        loginPage = new LoginPage();
        connexusStartPage = new ConnexusStartPage();
        patientSearchPage = new PatientSearchPage();
        tascoPage = new TascoPage();
        patientMaintenancePage = new PatientMaintenancePage();
        dropOffPage = new DropOffPage();
        orderSearch = new F6Search();
        fourPoint = new FourPoint();
        inputPage = new InputPage();
        modifyDetails = new ModifyDetails();
        connexusAppUtils = new ConnexusAppUtils();
        dropRxModel = new DropRxModel();
        rxModel = new RxModel();
        rxLookUp = new RxLookUp();
        visVerPage = new VisVerPage();
        automationManager = AutomationManager.getInstance();
        loginPage.loginConnexus(userType);
    }

    public void performChkDURResolved(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatientSelfHelp(rxNbr, 0, inputData);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDURResolved(rxNbr);
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void performPickupForDBEntry(Map<String, String> inputData, String rxNbr, int patientId) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String rxStatus,firstName, lastName;
        try {
            resp = connexusAPIManager.getPatientInformation(siteId,patientId,"");
            Gson gson = new Gson();
            JsonObject root = gson.fromJson(resp.getDataResponse(), JsonObject.class);

            JsonObject patient = root.getAsJsonObject("Patient");
            JsonObject generalInfo = patient.getAsJsonObject("PatGeneralInfo");
            JsonObject personalInfo = generalInfo.getAsJsonObject("PersonalInfo");
            firstName = personalInfo.get("FirstName").getAsString();
            lastName = personalInfo.get("LastName").getAsString();

            rxStatus = orderSearch.getRXStatusForPatientSelfHelp(rxNbr, 0, inputData);
            if (rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completePickup(firstName.trim(), lastName.trim(), inputData.get("DOB"),rxNbr);
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at PickUp queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void verifyEntryInAuditTable(String rx_fill_id){

        int rowCount = connexusAppUtils.verifyEntryInAuditActivityTable(Integer.parseInt(rx_fill_id));
        Assert.assertTrue(rowCount > 0, "Expected entry in the audit table in DB for rxFillId:" + rx_fill_id);
        Reporter.log("Entry found in DB for rxFillId:" + rxFillId);
    }

    public int getPatientId(Map<String, String> inputData){
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            automationManager.performSleep(3);
            String firstName = name[0];
            String lastName = name[1];
            long homePhone, workPhone, cellPhone;
            siteId = Integer.parseInt(prop.getProperty("cnx.store"));
            homePhone = Long.parseLong(inputData.get("HOME_PHONE"));
            workPhone = Long.parseLong(inputData.get("WORK_PHONE"));
            cellPhone = Long.parseLong(inputData.get("CELL_PHONE"));
            resp = connexusApiManager.createPatient(lastName, firstName, inputData.get("DOB"), siteId, homePhone, workPhone, cellPhone);
            Assert.assertEquals(resp.getStatusCode(), 201, "Create Patient details" + resp.getDataResponse());
            inputResp = resp.getDataResponse(InputResponse.class);
            patientId = inputResp.getPatientId();
            Log.info("patientId = " + patientId);
            Reporter.log("Patient has been created.");
        return patientId;
    }

    public List<String> CreatePatientAndMultiRxOrderMoveTocheckDUR(Map<String, String> inputData) {
        patientId = getPatientId(inputData);
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        ndcList = Arrays.asList(inputData.get("DRUG_NAME1"), inputData.get("DRUG_NAME2"));
        String priorityId = prop.getProperty("fom.OrderPriorityId");
        multiRx4PointCompleteResp = connexusApiManager.createMultiRxDropOffAndMoveTocheckDUR(patientId, siteId, numRefills, ndcList, priorityId,connexusApiManager.PrescriberDetails());
        for (InputResponse input : multiRx4PointCompleteResp) {
            String rxNbr = String.valueOf(input.getRxNbr());
            String fillId = String.valueOf(input.getRxFillId());
            rxResponseList.add(fillId);
            rxResponseList.add(rxNbr);
            Log.info("RxNbr: " + rxNbr + " | FillId: " + fillId);
        }
        return rxResponseList;
    }

    public List<String> performCreateOrderAndMoveTocheckDUR(Map<String, String> inputData) {
        patientId = getPatientId(inputData);
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        String ndc = inputData.get("DRUG_NAME1");
        inputResp = connexusApiManager.createOrderAndMoveTocheckDUR(patientId, siteId, numRefills, ndc, connexusApiManager.PrescriberDetails());
        rxNbr= String.valueOf(inputResp.getRxNbr());
        String rxFillId= String.valueOf(inputResp.getRxFillId());
        Reporter.log("RxNbr:" + inputResp.getRxNbr());
        orderInfoList.add(rxNbr);
        orderInfoList.add(rxFillId);
        orderInfoList.add(String.valueOf(patientId));
        return orderInfoList;
    }

    public Prescriber PrescriberDetails(Map<String, String> inputData) {
        Prescriber prescriber = new Prescriber();
        int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        prescriber.setFullname(inputData.get("PRESCRIBER_FULLNAME"));
        prescriber.setFirstname(inputData.get("PRESCRIBER_FIRSTNAME"));
        prescriber.setLastname(inputData.get("PRESCRIBER_LASTNAME"));
        prescriber.setPhone(inputData.get("PRESCRIBER_PHONE"));
        prescriber.setState(inputData.get("PRESCRIBER_STATE"));
        prescriber.setPrescriberId(Integer.parseInt(inputData.get("PRESCRIBER_ID")));
        prescriber.setRxClinicId(Integer.parseInt(inputData.get("PRESCRIBER_RXCLINICID")));
        prescriber.setDea(inputData.get("PRESCRIBER_DEA"));
        prescriber.setNpi(inputData.get("PRESCRIBER_NPI"));
        return prescriber;
    }

    public void verifyNoEntryInAuditTable(String rxFillId){
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        automationManager.performSleep(20);
        boolean noEntriesFound = connexusAppUtils.verifyNoEntryInAuditActivityTable(Integer.parseInt(rxFillId));
        Assert.assertTrue(noEntriesFound, "Expected no entry found in audit table in DB for rxFillId:" +rxFillId);
        Reporter.log("No entry found in DB for rxFillId:" + rxFillId);
    }

    public void performMultiChkDURResolvedInUI(Map<String, String> inputData, String rxNbr) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
                String rxStatus = orderSearch.getRXStatusForPatientSelfHelp(rxNbr, 0, inputData);
                System.out.println("rxStatus:" +rxNbr + rxStatus);
                if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                    automationManager.getConnexusWorkFlow().checkAndPerformCheckDURResolved(rxNbr);
                }
        } catch (Throwable e) {
            Reporter.log("Test failed at chkDUR queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void performMultiRxPickUp(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String rxStatus, currentRxNbr, firstName, lastName;
        values = connexusAppUtils.getPatientFirstNameAndLastName(siteId,patientId);
        firstName = (String) values.get("first_name");
        lastName = (String) values.get("last_name");
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = multiRxNbr.get(i);
                multiRxNbrList.add(currentRxNbr);
                rxStatus = orderSearch.getRXStatusForPatientSelfHelp(currentRxNbr, 0, inputData);
                Assert.assertTrue(rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue()));
            }
            automationManager.getConnexusWorkFlow().completeMultiRxPickup(firstName.trim(), lastName.trim(), inputData.get("DOB"), multiRxNbrList,String.valueOf(siteId));
        }   catch(Throwable e){
            Reporter.log("Test failed at PickUp queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void verifyMultiEntryInAuditTable(){
        String currentRxNbr; int rowCount;
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbr.get(i));
                rxFillId = connexusAppUtils.getRxFillIdTableInfo(siteId, currentRxNbr);
                rowCount = connexusAppUtils.verifyEntryInAuditActivityTable(rxFillId);
                if(rowCount > 0){
                    Assert.assertTrue(rowCount > 0, "Expected entry in the audit table in DB for rxFillId:" + rxFillId);
                    Reporter.log("Entry found in DB for rxFillId:" + rxFillId + "  " + "Row count: " + rowCount);
                }else {
                    Assert.assertTrue(rowCount == 0, "Expected no entry in the audit table in DB for rxFillId:" + rxFillId);
                    Reporter.log("No Entry found in DB for rxFillId:" + rxFillId + "  " + "Row count: " + rowCount);
                }
            }
        }catch(Throwable e){
            Reporter.log("Exception occurred:" + e);
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performFillingAndMoveToPickup(Map<String, String> inputData){
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        String ndc = inputData.get("DRUG_NAME1");
        value = connexusAppUtils.getRxIdAndRxFillIdAndOrderSeqNbr(siteId, rxNbr);
        try {
            orderId = connexusAppUtils.getRxOrderIdFromTable(siteId, rxNbr);
            rxId = value.get("rxId");
            rxFillId = value.get("rxFillId");
            orderSeqNbr = value.get("orderSeqNbr");
            vvCompleteResp = connexusApiManager.fillingToPickup(patientId, orderId, siteId, rxFillId, rxId, numRefills, ndc, connexusApiManager.PrescriberDetails());
        }
        catch(Throwable e){
            Log.info("Test failed at Filling or VV queue");
            Reporter.log("Test failed at Filling or Visual Verify queue");
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void clearCache() {
        connexusAppUtils.callFlushCacheAPI(String.valueOf(siteId));
    }
}
