package connexus.Narxcare_testcases.testcases;

import connexus.Narxcare_testcases.testScripts.NarxCareTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.prop;

public class NarxCare_Testcases {
    public static LoginAs.userType loginUserType = LoginAs.userType.PHARMACIST_ADFlagOff;
    NarxCareTestScripts narxCareTestScripts = new NarxCareTestScripts(loginUserType);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    public boolean flagUpdated = false;

    public void NarxCareFlagsSetUP(){
        //Set the state to AR for the current store

        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");

        //Verify and set the flag 28750 to TRUE
        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        flagUpdated |= connexusAppUtils.readAndUpdateFlag("28750", "FALSE");

        //Verify and set the flag 27268 to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("27268", "FALSE");

        //Verify and set the flag 31010 to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31010", "TRUE");

        //Verify and set the flag 1667 to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("1667", "TRUE");

        //Verify and set the flag 1666 to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("1666", "FALSE");

        //Verify and set the flag 31011 to 300
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31011", "300");

        flagUpdated |= connexusAppUtils.updateNarxCareRequirementParmTable("Y","14500","203");

        flagUpdated |= connexusAppUtils.updateNarxCareRequirementParmTable("N","14501","203");

        flagUpdated |= connexusAppUtils.updateNarxCareRequirementParmTable("FALSE","19666","203");

    }

    @BeforeClass
    public void loginToConnexus(){
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: E2E_Cash_Flow_Non_Controlled_Drug
     * Author: Nagarjuna(vn575ve)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-2341")
    @Test(enabled = true, description = "Drop C2 | narcotic score >300 <500",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_2341_validating_Narxcare_Report_For_Narcotic_Score_GreaterThan_300_LessThan_500_for_C2_Controlled_Drug(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate narxcare report for the patient having Narcotic score GreaterThan 300 and LessThan 500 for Controled Drug");

        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validateNarxcareReportAndPerform4Point(inputData);
        narxCareTestScripts.validateRequiredLableShouldNotBeAvailable(inputData);
        narxCareTestScripts.performFilling();
        narxCareTestScripts.performVisualVerify();
        narxCareTestScripts.performPickUp(inputData);
        narxCareTestScripts.performCounselling();
        narxCareTestScripts.performPOS();

        Reporter.log("Validate Required label not present as the patient score is between 300 and 500 and Refused to fill radio button should be displayed and Approved to fill radio button should not be displayed");
    }

    //@Jira(testID = "HWPHME2E-1677")
    @Test(enabled = true, description = "Drop Controlled Drugs | narcotic score >300 <500",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMaps")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE_300_500")
    public void validating_Narxcare_Report_For_Narcotic_Score_GreaterThan_300_LessThan_500(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate narxcare report for the patient having Narcotic score GreaterThan 300 and LessThan 500 for Controled Drug");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validateNarxcareReportAndPerform4Point(inputData);
        narxCareTestScripts.validateRequiredLableShouldNotBeAvailable(inputData);

        Reporter.log("Validate Required label not present as the patient score is between 300 and 500 and Refused to fill radio button should be displayed and Approved to fill radio button should not be displayed");
    }

    //@Jira(testID = "HWPHME2E-1684")
    @Test(enabled = true, description = "Drop C2 | narcotic score >500",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_1684_validate_NarxCare_Report_For_Narcotic_Score_Greater_Than_500_for_C2_Controlled_Drug(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate narxcare report for the patient having Narcotic score Greater Than 500 for Controlled Drug");

        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validateNarxcareReportAndPerform4PointforFlowA(inputData);
        narxCareTestScripts.validateNarxCareReportOnDURForGreaterThan500(inputData);
        narxCareTestScripts.performFilling();
        narxCareTestScripts.performVisualVerify();
        narxCareTestScripts.performPickUp(inputData);
        narxCareTestScripts.performCounselling();
        narxCareTestScripts.performPOS();
        Reporter.log("Validated narxcare report successfully for the patient having Narcotic score Greater Than 500");
    }

    //@Jira(testID = "HWPHME2E-157")
    @Test(enabled = true, description = "Drop Controlled Drugs | narcotic score >500",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMaps")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE_500")
    public void validate_NarxCare_Report_For_Narcotic_Score_Greater_Than_500(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate narxcare report for the patient having Narcotic score Greater Than 500 for Controlled Drug");

        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validateNarxcareReportAndPerform4PointforFlowA(inputData);
        narxCareTestScripts.validateNarxCareReportOnDURForGreaterThan500(inputData);

        Reporter.log("Validated narxcare report successfully for the patient having Narcotic score Greater Than 500");
    }

    //@Jira(testID = "HWPHME2E-155")
    @Test(enabled = true, description = "Maximize Narxcare report Through F7 Screen",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_155_Maximize_Narxcare_Report_F7_Screen(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate maximize functionality of narxcare report by clicking on Narxcare button in F7 screen");

        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.launchF7ScreenAndSearchPatient(inputData);
        narxCareTestScripts.validateNarxcareReportMaximizeFunctionality(inputData);

        Reporter.log("Narxcare report successfully opened in full size through F7 screen.");
    }

    //@Jira(testID = "HWPHME2E-1708")
    @Test(enabled = true, description = "View_Narxcare_Report_Under_CurrentRx in 4 point screen",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_1708_View_Narxcare_Report_Under_CurrentRx_In_4Point(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate narxcare report by cling on view narxcare report under CurrentRx in 4 point screen");

        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.viewNarxcareOrLogicoyReportUnderCurrentRxIn4PointScreen(inputData);

        Reporter.log("Able to view narxcare report by clicking on view narxcare report under CurrentRx menu option under 4 point.");
    }

    //@Jira(testID = "HWPHME2E-1699")
    @Test(enabled = true, description = "View_Narxcare_Report_Under_CurrentRx in ChkDUR screen",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_1699_View_Narxcare_Report_Under_CurrentRx_In_CheDur(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate narxcare report by cling on view narxcare report under CurrentRx in ChkDUR screen");

        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.viewNarxcareOrLogicoyReportUnderCurrentRxInChkDurScreen(inputData);

        Reporter.log("Able to view narxcare report by clicking on view narxcare report under CurrentRx menu option in ChkDUR screen.");
    }

    //@Jira(testID = "HWPHME2E-1702")
    @Test(enabled = true, description = "View_Narxcare_Report_Under_F7_screen_For_RxNumber_4Point_Queue",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_1702_View_Narxcare_Report_Under_F7_screen_For_RxNumber_4Point_Queue(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate narxcare report in F7 screen For RxNumber 4Point Queue");

        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.viewNarxcareOrLogicoyReportIn4PointScreen(inputData);
        narxCareTestScripts.launchF7ScreenAndSearchPatient(inputData);
        narxCareTestScripts.validateNarxcareReportMaximizeFunctionality(inputData);

        Reporter.log("Able to view narxcare report by clicking on view narxcare report button under F7 screen.");
    }

    //@Jira(testID = "HWPHME2E-1693")
    @Test(enabled = true, description = "View_Narxcare_Report_Under_F7_screen_For_RxNumber_ChkDUR_Queue",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_1693_View_Narxcare_Report_Under_F7_screen_For_RxNumber_ChkDUR_Queue(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate narxcare report in F7 screen For RxNumber ChkDUR Queue");

        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.viewNarxcareReportInChkDURScreen(inputData);
        narxCareTestScripts.launchF7ScreenAndSearchPatient(inputData);
        narxCareTestScripts.validateNarxcareReportMaximizeFunctionality(inputData);

        Reporter.log("Able to view narxcare report by clicking on view narxcare report button under F7 screen.");
    }

    //@Jira(testID = "HWPHME2E-1718")
    @Test(enabled = true, description = "validate_NarxCare_Report_For_Non_Controlled_Drug",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_1718_validate_NarxCare_Report_For_Non_Controlled_Drug(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("HWPHME2E-1718-Validate narxcare report for Non Controlled Drug");

        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validateNarxcareReportForNonControlledDrug(inputData);
        narxCareTestScripts.validateNarxCareReportOnDURForNonControlledDrugs(inputData);

        Reporter.log("Validatio is done for Narxcare report for Non Controlled Drug");
    }

    //@Jira(testID = "HWPHME2E-1719")
    @Test(enabled = true, description = "Validate_pediatric_Weight_In_DUR_Request",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_1719_Validate_pediatric_Weight_In_DUR_Request(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("HWPHME2E-1719 - Validate Calculate pediatric weight in DUR request");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.createNewPatient(inputData);
        narxCareTestScripts.performDropOff(Priority.Critical);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.verfiyPatientweight();
        Reporter.log("Validation is done for Calculate pediatric weight in DUR request");
    }

    //@Jira(testID = "HWPHME2E-1675")
    @Test(enabled = true, description = "validate_Narxcare_Report_for_Blank_DUR",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_1675_validate_Narxcare_Report_for_Blank_DUR(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("HWPHME2E-1675 - Narxcare Report for Blank DUR");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.createNewPatient(inputData);
        narxCareTestScripts.performDropOff(Priority.Critical);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.validateNarxCareReportOnDURForGreaterThan500(inputData);
        Reporter.log("Validatioin is done for HWPHME2E-1675 - Narxcare Report for Blank DUR");
    }

    //@Jira(testID = "HWPHME2E-156")
    @Test(enabled = true, description = "validate_Narxcare_With_C2_Drug_For_New_Patient",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_156_validate_Narxcare_With_C2_Drug_For_New_Patient(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("HWPHME2E-156 - Verify the flow of prescription dropped for a new patient with C2 drug to DUR queue after 4 point when patient is having narxcare score >700");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.createNewPatient(inputData);
        narxCareTestScripts.performDropOff(Priority.Critical);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.validateNarxCareReportOnDURForGreaterThan500(inputData);
        narxCareTestScripts.performFilling();
        narxCareTestScripts.performVisualVerify();
        narxCareTestScripts.performPickUp(inputData);
        narxCareTestScripts.performCounselling();
        narxCareTestScripts.performPOS();
        Reporter.log("Validatioin is done for HWPHME2E-156-Verify the flow of prescription dropped for a new patient with C2 drug to DUR queue after 4 point when patient is having narxcare score >700");
    }

    //@Jira(testID = "HWPHME2E-1698")
    @Test(enabled = true, description = "Drop Controlled Drug | narcotic score <299",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMaps")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE_299")
    public void validating_Narxcare_Report_And_Grid_Not_Displayed_in_CHKDURF_For_LessaThan_299_Score(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate narxcare report and grid should not be displayed in ChkDUR screen for the patient having Narcotic score Lessthan 299 for Controled Drug");

        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validateNarxcareReportAndPerform4Point(inputData);
        narxCareTestScripts.validateReportAndGridNotAvailableInChkDURForPatientScoreLessThan299(inputData);

        Reporter.log("narxcare report and grid not displayed in chkDUR screen for the patient having Narcotic score Lessthan 299 for Controled Drug");
    }

    @Test(enabled = true, description = "Verify the flow of prescription dropped for a new patient with C2-C5 drug to DUR queue after 4 point when patient is having narxcare score",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_154_validate_Patient_Request_Table_For_New_Patient(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("HWPHME2E_154_validate_Patient_Request_Table_For_New_Patient");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.createNewPatient(inputData);
        narxCareTestScripts.performDropOff(Priority.Critical);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validatePatientDBOnFourPoint(inputData);
        Reporter.log(" Validating NarxCare Details in patientRequestTable while moving from fourpoint to checkDUR");
        narxCareTestScripts.verifyNarxCareDetailsinDB();
        narxCareTestScripts.validateNarxCareReportOnDURForGreaterThan500(inputData);
        Reporter.log(" Validating NarxCare Details in patientRequestTable for viewing Narxcare Report on CheckDUR");
        narxCareTestScripts.verifyNarxCareDetailsinDB();
        Reporter.log("Completed validation for HWPHME2E_154_validate_Patient_Request_Table_For_New_Patient");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Verify whether user is able refuse to fill
     * JIRA: HWPHME2E-151
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Verify whether user is able refuse to fill",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_151_validating_User_able_refuse_to_fill(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-151-Verify whether user is able refuse to fill");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOff(Priority.Critical);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.validateRefusalToFill(inputData);
        narxCareTestScripts.launchF7ScreenAndSearchPatient(inputData);
        narxCareTestScripts.validateRxstatusinF7(inputData);

        Reporter.log("Validation is done successfully for HWPHME2E-151-Verify whether user is able refuse to fill");
    }
    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Validate Cosmos For Narxcare Service
     * JIRA: HWPHME2E-1707
     * Author: Purnima Arora(vn58gdi)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "HWPHME2E_1707_Validate_Cosmos_Narxcare_Service",
            priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_1707_Validate_Cosmos_Narxcare_Service(Map<String, String> inputData) {
        Reporter.log("HWPHME2E_1707_Validate_Cosmos_For_Narxcare_Service");
        NarxCareFlagsSetUP();
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.createNewPatient(inputData);
        narxCareTestScripts.performDropOff(Priority.Critical);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point();
        narxCareTestScripts.validateNarxCareReportOnDURForGreaterThan500(inputData);
        narxCareTestScripts.validateNarxCareDetailsInCosmos(inputData);
        Reporter.log("Validated Cosmos for Narxcare Service");
    }

    @Test(enabled = true, description = "Validate that Technician is unable to view Narxcare report from F7 screen",
            priority = 18, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "TECHNICIAN")
    public void HWPHME2E_5546_Validate_that_Technician_is_unable_to_view_Narxcare_report_from_F7_screen(Map<String, String> inputData) {

        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate that Technician is unable to view Narxcare report from F7 screen");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        narxCareTestScripts.createNewPatient(inputData);
        narxCareTestScripts.performDropOff(Priority.Critical);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateViewNarxcareReportDisabledInF7ScreenForTechnician();
        Reporter.log("Validate that Technician is unable to view Narxcare report from F7 screen");
    }

    @Test(enabled = true, description = "Validate that Technician is unable to view Narxcare report from Current Rx menu",
            priority = 19, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "TECHNICIAN")
    public void HWPHME2E_5547_Validate_that_Technician_is_unable_to_view_Narxcare_report_from_Current_Rx_menu(Map<String, String> inputData) {

        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate that Technician is unable to view Narxcare report from Current Rx menu");

        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        narxCareTestScripts.createNewPatient(inputData);
        narxCareTestScripts.performDropOff(Priority.Critical);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateNarxcareReportUnderCurrentRxIn4PointScreen(inputData);
        Reporter.log("Validate that Technician is unable to view Narxcare report from Current Rx menu");
    }

    @Test(enabled = true, description = "Validate that Technician is unable to view Narxcare report from 4point screen",
            priority = 20, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "TECHNICIAN")
    public void HWPHME2E_5548_Validate_that_Technician_is_unable_to_view_Narxcare_report_from_4point_screen(Map<String, String> inputData) {

        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate that Technician is unable to view Narxcare report from 4point");

        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        narxCareTestScripts.createNewPatient(inputData);
        narxCareTestScripts.performDropOff(Priority.Critical);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validate4PointScreenNotComingUpForTechnician();
        Reporter.log("Validate that Technician is unable to view Narxcare report from 4point");
    }

    @Test(enabled = true, description = "Validate that Technician is unable to view Narxcare report from CheckDUR screen",
            priority = 21, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "TECHNICIAN")
    public void HWPHME2E_5548_Validate_that_Technician_is_unable_to_view_Narxcare_report_from_CheckDUR_screen(Map<String, String> inputData) {

        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate that Technician is unable to view Narxcare report from CheckDUR screen");

        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        narxCareTestScripts.createNewPatient(inputData);
        narxCareTestScripts.performDropOff(Priority.Critical);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateChkDURScreenNotComingUpForTechnician();
        Reporter.log("Validate that Technician is unable to view Narxcare report from CheckDUR screen");
    }

}