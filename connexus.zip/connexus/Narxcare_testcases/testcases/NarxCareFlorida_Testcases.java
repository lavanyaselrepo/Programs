package connexus.Narxcare_testcases.testcases;

import connexus.Narxcare_testcases.testScripts.NarxCareTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.prop;

public class NarxCareFlorida_Testcases {
    public static LoginAs.userType loginUserType = LoginAs.userType.PHARMACIST_ADFlagOff;
    NarxCareTestScripts narxCareTestScripts = new NarxCareTestScripts(loginUserType);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    public boolean flagUpdated = false;

    public void NarxCareFlagsSetUP(){
        //Set the state to FL for the current store
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("FL");

        //Verify and set the flag 27268 to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("27268", "FALSE");

        //Verify and set the flag 31010 to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31010", "TRUE");

        //Verify and set the flag 1667 to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("1667", "TRUE");

        //Verify and set the flag 1666 to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("1666", "FALSE");

        //Verify and set the flag 31011 to 300
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31011", "300");

        flagUpdated |= connexusAppUtils.updateNarxCareRequirementParmTable("Y","14500","209");

        flagUpdated |= connexusAppUtils.updateNarxCareRequirementParmTable("Y","14501","209");

        flagUpdated |= connexusAppUtils.updateNarxCareRequirementParmTable("FALSE","19666","209");

    }

    @BeforeClass
    public void loginToConnexus(){
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }
    
    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Florida | C5 Stimulant | >500 | Validate that viewing of report is mandatory and consolidated notes does popup
     * JIRA: HWPHME2E-3080
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Florida | C5 Stimulant | >500 | Validate that viewing of report is mandatory and consolidated notes does popup",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_3080_validating_Florida_Consolidate_Popup_for_C5_Stimulant_greaterthan500(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-3080-Validate Florida | C5 Stimulant | >500 | Validate that viewing of report is mandatory and consolidated notes does popup");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.validateConsolidateReportsForGreaterThan500(inputData);
        Reporter.log("HWPHME2E-3080-Validate Florida | C5 Stimulant | >500 | Validate that viewing of report is mandatory and consolidated notes does popup");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Florida | C3 Opioid | >500 | Validate that viewing of report is mandatory and consolidated notes does popup
     * JIRA: HWPHME2E-3084
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Florida | C3 Opioid | >500 | Validate that viewing of report is mandatory and consolidated notes does popup",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_3084_validating_Florida_Consolidate_Popup_for_C3_Opioid_greaterthan500(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-3084-Validate Florida | C3 Opioid | >500 | Validate that viewing of report is mandatory and consolidated notes does popup");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.validateConsolidateReportsForGreaterThan500(inputData);
        Reporter.log("HWPHME2E-3084-Validate Florida | C3 Opioid | >500 | Validate that viewing of report is mandatory and consolidated notes does popup");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Florida | C2 Stimulant | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup
     * JIRA: HWPHME2E-3085
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Florida | C2 Stimulant | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_3085_validating_Florida_Consolidate_Popup_C2_Stimulant_for_300to499(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-3085-Florida | C2 Stimulant | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.ValidateConsolidatePopupfor300to500(inputData);
        Reporter.log("Validation is done for HWPHME2E-3085-Florida | C2 Stimulant | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Florida | C4 Stimulant | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup
     * JIRA: HWPHME2E-3083
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Florida | C4 Stimulant | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_3083_validating_Florida_Consolidate_Popup_for_C4_Stimulant_for_300to499(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-3083-Florida | C4 Stimulant | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.ValidateConsolidatePopupfor300to500(inputData);
        Reporter.log("Validation is done for HWPHME2E-3083-Florida | C4 Stimulant | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Florida | C5 Stimulant | 300-499 | Validate that viewing of report is optional and consolidated notes does not popup
     * JIRA: HWPHME2E-3081
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Florida | C5 Stimulant | 300-499 | Validate that viewing of report is optional and consolidated notes does not popup",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_3081_validating_Florida_Consolidate_Popup_for_C5_Stimulant_for_300to499(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-3081-Florida | C5 Stimulant | 300-499 | Validate that viewing of report is optional and consolidated notes does not popup");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.validateViewReportOptionalonchkDUR(inputData);
        Reporter.log("Validation is done for HWPHME2E-3081-Florida | C5 Stimulant | 300-499 | Validate that viewing of report is optional and consolidated notes does not popup");
    }


    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Florida | C2 Opioid | 0-299 | Validate that viewing of report is mandatory and consolidated notes does not popup
     * JIRA: HWPHME2E-3086
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Florida | C2 Opioid | 0-299 | Validate that viewing of report is mandatory and consolidated notes does not popup",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_3086_validating_Florida_Consolidate_Popup_for_C2_Opiod_for_0to299(Map<String, String> inputData) {
        Reporter.log("HWPHME2E_3086-Florida | C2 Opioid | 0-299 | Validate that viewing of report is mandatory and consolidated notes does not popup");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.validateConsolidateReportForPatientScoreLessThan299(inputData);
        Reporter.log("Validation is done for HWPHME2E_3086-Florida | C2 Opioid | 0-299 | Validate that viewing of report is mandatory and consolidated notes does not popup");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Florida | C5 Stimulant | 0-299 | Validate that consolidated notes does not popup
     * JIRA: HWPHME2E-3082
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Florida | C2 Opioid | 0-299 | Validate that viewing of report is mandatory and consolidated notes does not popup",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_3082_validating_Florida_Consolidate_Popup_for_C5_Stimulant_for_0to299(Map<String, String> inputData) {
        Reporter.log("HWPHME2E_3086-Florida | C2 Opioid | 0-299 | Validate that viewing of report is mandatory and consolidated notes does not popup");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.validateReportAndGridNotAvailableInChkDURForPatientScoreLessThan299(inputData);
        Reporter.log("Validation is done for HWPHME2E_3086-Florida | C2 Opioid | 0-299 | Validate that viewing of report is mandatory and consolidated notes does not popup");
    }
}