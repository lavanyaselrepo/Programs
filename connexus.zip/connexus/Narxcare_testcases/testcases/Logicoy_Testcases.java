package connexus.Narxcare_testcases.testcases;

import connexus.Narxcare_testcases.testScripts.NarxCareTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class Logicoy_Testcases {
    public static LoginAs.userType loginUserType = LoginAs.userType.PHARMACIST_ADFlagOff;
    NarxCareTestScripts narxCareTestScripts = new NarxCareTestScripts(loginUserType);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    public boolean flagUpdated = false;

    public void logicoyFlagsSetUP(){
        //Set the state to AR for the current store
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("IL");

        //Verify and set the flag 28750 to TRUE
        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        flagUpdated |= connexusAppUtils.readAndUpdateFlag("28750", "FALSE");

        //Verify and set the flag 27268 to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("27268", "FALSE");

        //Verify and set the flag 31010 to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31010", "TRUE");

        //Verify and set the flag 1667 to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("1667", "FALSE");

        //Verify and set the flag 1666 to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("1666", "TRUE");

        //Verify and set the flag 31011 to 300
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31011", "0");

        flagUpdated |= connexusAppUtils.readAndUpdateFlag("26720", "TRUE");

        flagUpdated |= connexusAppUtils.updateNarxCareRequirementParmTable("Y","14500","213");

        flagUpdated |= connexusAppUtils.updateNarxCareRequirementParmTable("Y","14501","213");

        flagUpdated |= connexusAppUtils.updateNarxCareRequirementParmTable("FALSE","19666","213");

    }

    @BeforeClass
    public void loginToConnexus(){
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: validate_Logicoy_Report_Viewed_In_CurrentRx_RxNotes
     * Author: Nagarjuna(vn575ve)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1685")
    @Test(enabled = true, description = "validate_Logicoy_Report_Viewed_In_CurrentRx_RxNotes",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "LOGICOY")
    public void HWPHME2E_1685_validate_Logicoy_Report_Viewed_In_CurrentRx_RxNotes(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate viewed logicoy report card under Rx notes for 4 point, ChkDUR, F7 screen Current Rx notes");

        logicoyFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validateLogicoyReportViewedInCurrentRxNotesFor4Point(inputData);
        narxCareTestScripts.launchF7ScreenAndSearchPatient(inputData);
        narxCareTestScripts.viewLogicoyReportAndValidateRecordShouldNotBeAddedToRxnotesInF7Screen(inputData);
        narxCareTestScripts.validateLogicoyReportViewedInCurrentRxNotesForChkDUR(inputData);
        narxCareTestScripts.launchF7ScreenAndSearchPatient(inputData);
        narxCareTestScripts.viewLogicoyReportAndValidateRecordShouldNotBeAddedToRxnotesInF7Screen(inputData);
        narxCareTestScripts.performFilling();
        narxCareTestScripts.performVisualVerify();
        narxCareTestScripts.performPickUp(inputData);
        narxCareTestScripts.performCounselling();
        narxCareTestScripts.performPOS();

        Reporter.log("Able to see LogiCoy viewed report card for 4 point, ChkDUR screens under current RX notes and logicoy viewed report card not added when we click on view logicoy report button underF7 screen.");
    }

    //@Jira(testID = "HWPHME2E-1680")
    @Test(enabled = true, description = "View_Logicoy_Report_Under_F7_screen_For_RxNumber_4Point_Queue",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "LOGICOY")
    public void HWPHME2E_1680_View_Logicoy_Report_Under_F7_screen_For_RxNumber_4Point_Queue(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate narxcare report in F7 screen For RxNumber 4Point Queue");

        logicoyFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.viewNarxcareOrLogicoyReportIn4PointScreen(inputData);
        narxCareTestScripts.launchF7ScreenAndSearchPatient(inputData);
        narxCareTestScripts.validateLogicoyReportInF7Screen(inputData);

        Reporter.log("Able to view Logicoy report by clicking on view Logicoy report button under F7 screen.");
    }

    //@Jira(testID = "HWPHME2E-1687")
    @Test(enabled = true, description = "View_LogiCoy_Report_Under_CurrentRx in 4 Point screen",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "LOGICOY")
    public void HWPHME2E_1687_View_LogiCoy_Report_Under_CurrentRx_In_4point(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate Logicoy report by cling on view Logicoy report under CurrentRx in 4 point screen");

        logicoyFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.viewNarxcareOrLogicoyReportUnderCurrentRxIn4PointScreen(inputData);

        Reporter.log("Able to view Logicoy report by clicking on view Logicoy report under CurrentRx menu option in 4 point screen.");
    }

    //@Jira(testID = "HWPHME2E-1706")//@Jira(testID = "HWPHME2E-157")
    @Test(enabled = true, description = "View_LogiCoy_Report_Under_CurrentRx in ChkDUR screen",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "LOGICOY")
    public void HWPHME2E_157_1706_View_LogiCoy_Report_Under_CurrentRx_In_CheDur(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate Logicoy report by cling on view Logicoy report under CurrentRx in ChkDUR screen");

        logicoyFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.viewNarxcareOrLogicoyReportUnderCurrentRxInChkDurScreen(inputData);

        Reporter.log("Able to view Logicoy report by clicking on view Logicoy report under CurrentRx menu option in ChkDUR screen.");
    }

    //@Jira(testID = "HWPHME2E-1690")
    @Test(enabled = true, description = "validate_Logicoy_Report_In_4point",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "LOGICOY")
    public void HWPHME2E_1690_validate_Logicoy_Report_In_4Point(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate Logicoy report in 4 point screen.");

        logicoyFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validateLogicoyReportIn4Point(inputData);

        Reporter.log("Able to view logicoy report in 4 point screen.");
    }

    //@Jira(testID = "HWPHME2E-1692")
    @Test(enabled = true, description = "validate_Logicoy_Report_In_ChkDUR",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "LOGICOY")
    public void HWPHME2E_1692_validate_Logicoy_Report_In_ChkDUR_C2drug(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate Logicoy report in ChkDUR screen for C2 drug.");

        logicoyFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.validateLogicoyReportInChkDUR(inputData);

        Reporter.log("Able to view logicoy report in ChkDUR screen for C2 drug.");
    }

    //@Jira(testID = "HWPHME2E-1678")
    //@Jira(testID = "HWPHME2E-1683")
    @Test(enabled = true, description = "Validate_view_Logicoy_Report_Option_not_displayed_in_4Point_And_In_ChkDUR_For_Controlled_drug",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "LOGICOY")
    public void HWPHME2E_1678_1683_validate_view_Logicoy_Report_Option_not_displayed_in_4Point_And_In_ChkDUR_For_Controlled_drug(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate Logicoy report should not be displayed in 4 point and ChkDUR screen for non controlled drugs.");

        logicoyFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validateViewLogicoyReportNotDisplayedIn4PointForNonControlledDrug(inputData);
        narxCareTestScripts.validateLogicoyReportLinkNotDisplayedInChkDURForNonControlledDrug(inputData);

        Reporter.log("Logicoy report not displayed in 4 point and ChkDUR screen for non controlled drugs.");
    }

    //@Jira(testID = "HWPHME2E-1712")
    @Test(enabled = true, description = "View_LogiCoy_Report_Under_CurrentRx in 4 Point screen for C5 drug",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "LOGICOY")
    public void HWPHME2E_1712_View_LogiCoy_Report_Under_CurrentRx_In_4point_For_C5Drug(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate Logicoy report by cling on view Logicoy report under CurrentRx in 4 point screen for C5 drug");

        logicoyFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.viewNarxcareOrLogicoyReportUnderCurrentRxIn4PointScreen(inputData);

        Reporter.log("Able to view Logicoy report by clicking on view Logicoy report under CurrentRx menu option in 4 point screen for C5 drug.");
    }

    //@Jira(testID = "HWPHME2E-1715")
    @Test(enabled = true, description = "validate_Logicoy_Report_In_4point_And_ChkDUR_screen_for_c4drug",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "LOGICOY")
    public void HWPHME2E_1715_Validate_Logicoy_Report_In_4point_And_ChkDUR_screen_for_c4drug(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate view logicoy report in 4 point and ChkDUR screen for C4 drug.");

        logicoyFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validateLogicoyReportIn4Point(inputData);
        narxCareTestScripts.validateLogicoyReportInChkDUR(inputData);

        Reporter.log("Able to view logicoy report in 4 point and ChkDUR screen for C4 drug.");
    }

    //@Jira(testID = "HWPHME2E-1681")
    @Test(enabled = true, description = "validate_Logicoy_Report_In_ChkDUR",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "LOGICOY")
    public void HWPHME2E_1681_validate_Logicoy_Report_In_ChkDUR_C3Drug(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate Logicoy report in ChkDUR screen for C3 drug.");

        logicoyFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.validateLogicoyReportInChkDUR(inputData);

        Reporter.log("Able to view logicoy report in ChkDUR screen for C3 drug.");
    }

    //@Jira(testID = "HWPHME2E-1704")
    @Test(enabled = true, description = "Drop Controlled Drug | Logicoy no risk user",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "LOGICOY")
    public void HWPHME2E_1704_validating_Logicoy_Report_And_Grid_Should_Be_Displayed_with_Zero_values_For_No_Risk_User(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate Logicoy report and Grid should be displayed with zero values for no risk user");

        logicoyFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validateNarxcareReportAndPerform4Point(inputData);
        narxCareTestScripts.validateGridShouldBeDisplayedWithZeroValuesInChkDURForNoRiskUser(inputData);

        Reporter.log("Logicoy report and Grid should be displayed with zero values for no risk user");
    }

    //@Jira(testID = "HWPHME2E-1689")
    @Test(enabled = true, description = "Launch_RTF_Platform",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "LOGICOY")
    public void HWPHME2E_1689_Launch_RTF_Platform(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("Validate launching RTF platform");

        logicoyFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.launchRTFPlatformIn4Point(inputData);

        Reporter.log("Able to launch RTF platform");
    }

    @Test(enabled = true, description = "HWPHME2E_1705_validate_Logicoy_in_4Point_DUR_F7",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "LOGICOY")
    public void HWPHME2E_1705_validate_Logicoy_in_4Point_DUR_F7(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("HWPHME2E_1705_validate_Logicoy_in_4Point_DUR_F7");
        logicoyFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.createNewPatient(inputData);
        narxCareTestScripts.performDropOff(Priority.Critical);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.validateLogicoyReportInChkDUR(inputData);
        narxCareTestScripts.launchF7ScreenAndSearchNewPatient(inputData);
        narxCareTestScripts.validateLogicoyReportInF7Screen(inputData);
        Reporter.log("HWPHME2E_1705_validate_Logicoy_in_4Point_DUR_F7");
    }
}