package connexus.Narxcare_testcases.testcases;

import connexus.Narxcare_testcases.testScripts.NarxCareTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class NarxCareTexas_Testcases {
    public static LoginAs.userType loginUserType = LoginAs.userType.PHARMACIST_ADFlagOff;
    NarxCareTestScripts narxCareTestScripts = new NarxCareTestScripts(loginUserType);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    public boolean flagUpdated = false;

    public void NarxCareFlagsSetUP(){
        //Set the state to AR for the current store
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("TX");

        //Verify and set the flag 27268 to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("27268", "FALSE");

        //Verify and set the flag 31010 to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31010", "TRUE");

        //Verify and set the flag 1667 to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("1667", "TRUE");

        //Verify and set the flag 1666 to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("1666", "FALSE");

        //Verify and set the flag 31011 to 300
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31011", "300");

        flagUpdated |= connexusAppUtils.updateNarxCareRequirementParmTable("Y","14500","243");

        flagUpdated |= connexusAppUtils.updateNarxCareRequirementParmTable("Y","14501","243");

        flagUpdated |= connexusAppUtils.updateNarxCareRequirementParmTable("FALSE","19666","243");

    }

    @BeforeClass
    public void loginToConnexus(){
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }


    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Texas | carisoprodol | >500 | Validate that viewing of report is mandatory and consolidated notes does popup
     * JIRA: HWPHME2E-3088
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Texas | carisoprodol | >500 | Validate that viewing of report is mandatory and consolidated notes does popup",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_3088_validating_Texas_Consolidate_Popup_for_carisoprodol_greaterthan500(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("HWPHME2E_3088-Validate Texas | carisoprodol | >500 | Validate that viewing of report is mandatory and consolidated notes does popup");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.validateConsolidateReportsForGreaterThan500(inputData);
        Reporter.log("Validation is Done for HWPHME2E_3088-Validate Texas | carisoprodol | >500 | Validate that viewing of report is mandatory and consolidated notes does popup");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Texas | Opioid | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup
     * JIRA: HWPHME2E-3090
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Texas | Opioid | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_3090_validating_Texas_Consolidate_Popup_for_Opioid_for_300to499(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-3090-Texas | Opioid | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.ValidateConsolidatePopupfor300to500(inputData);
        Reporter.log("Validation is done for HWPHME2E-3090-Texas | Opioid | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup");
    }

    /*//**----------------------------------------------------------------------------------------------------------
     * Test Description: Texas | benzodiazepine | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup
     * JIRA: HWPHME2E-3087
     * Author: Nanthini(vn576ph)
     ---------------------------------------------------------------------------------------------------------- //***/

    @Test(enabled = true, description = "Texas | Opioid | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_3087_validating_Texas_Consolidate_Popup_for_benzodiazepine_for_300to499(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-3087-Texas | benzodiazepine | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validateNarxcareReportAndPerform4Point(inputData);
        narxCareTestScripts.ValidateConsolidatePopupfor300to500(inputData);
        Reporter.log("Validation is done for HWPHME2E-3090-Texas | benzodiazepine | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Texas | barbiturates | 0-299 | Validate that viewing of report is mandatory and consolidated notes does not popup
     * JIRA: HWPHME2E-3089
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Texas | Opioid | 300-499 | Validate that viewing of report is mandatory and consolidated notes does not popup",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_3089_validating_Texas_Consolidate_Popup_for_barbiturates_for_0to299(Map<String, String> inputData) {
        Reporter.log("HWPHME2E_3089-Texas | barbiturates | 0-299 | Validate that viewing of report is mandatory and consolidated notes does not popup");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.performDropOffForExistingPatient(inputData);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.perform4Point(true);
        narxCareTestScripts.validateConsolidateReportForPatientScoreLessThan299(inputData);
        Reporter.log("Validation is done for HWPHME2E_3089-Texas | barbiturates | 0-299 | Validate that viewing of report is mandatory and consolidated notes does not popup");
    }

   /* ----------------------------------------------------------------------------------------------------------
     * Test Description: Texas | carisoprodol | >500 | Validate that viewing of report is mandatory and consolidated notes does popup
     * JIRA: HWPHME2E-3088
     * Author: Nanthini(vn576ph)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Texas|Opioids, Benzoid, Barbiturate and Carisoprodol|Required label| 4 Point, Rx History",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/NarxCare/NarxCareFile.json", sheetName = "NARXCARE")
    public void HWPHME2E_1709_validating_Texas_FourPoint_RxHistory(Map<String, String> inputData) {
        Reporter.log(inputData.get("DRUG_TYPE"));
        Reporter.log("HWPHME2E_3088-HWPHME2E_1709_validating_Texas_FourPoint_RxHistory");
        NarxCareFlagsSetUP();
        narxCareTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.getlogSiteIdAndState(inputData);
        narxCareTestScripts.createNewPatient(inputData);
        narxCareTestScripts.performDropOff(Priority.Critical);
        narxCareTestScripts.performInput(inputData);
        narxCareTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        narxCareTestScripts.validateNarxcareOnFourPointforNewPatient(inputData);
        narxCareTestScripts.launchF7ScreenAndSearchNewPatient(inputData);
        narxCareTestScripts.validateNarxcareReportMaximizeFunctionality(inputData);
        Reporter.log("Validation is Done for HWPHME2E_1709_validating_Texas_FourPoint_RxHistory");
    }
}