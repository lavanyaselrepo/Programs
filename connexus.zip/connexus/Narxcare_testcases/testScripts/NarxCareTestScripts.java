package connexus.Narxcare_testcases.testScripts;

import com.aventstack.extentreports.Status;
import com.fasterxml.jackson.databind.JsonNode;
import connexus.Narxcare_testcases.testcases.Logicoy_Testcases;
import connexus.Narxcare_testcases.testcases.NarxCareTexas_Testcases;
import connexus.OrderCreation.PayloadResource;
import connexus.e2e.testcases.E2E_TestCases;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.WindowsBasePage;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StringUtils;
import io.strati.libs.joda.time.DateTime;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.utilities.StackUtils;

public class NarxCareTestScripts extends ConnexusTestScripts {
    Map<String, Object> values = new HashMap<>();
    public static int narcoticScore;
    String patientId, requestId, scoreExpireTsStr, narcoticScoreUI, dbScore;
    int storeNbr;

    public NarxCareTestScripts(LoginAs.userType userType) {
        super(LoginAs.userType.PHARMACIST_ADFlagOff);
    }


    public void validateEarlyRefillPopUpAndCompleteInput(Map<String, String> inputData) {
        if (inputPage.getInputScreenPopupMessage().contains(inputData.get("EARLIST_FILL_DATE_MESSAGE"))) {
            inputPage.clickButtonOk();
            automationManager.performSleep(5);
            inputPage.clickEarliestFillDateCheckBox();
            inputPage.clickAccept();
            automationManager.performSleep(5);
            inputPage.clickYesOnValidateRxPopUp();
            inputPage.clickOnOutofStockPopupOk();
            inputPage.partialpopup();
            inputPage.clickYesOnValidateRxPopUp();
        }
    }

    public void launchRTFPlatformIn4Point(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                orderSearch.openFirstPatientRecord();
                automationManager.performSleep(5);
                if (fourPoint.isElementDisplayed(fourPoint.rtfLink, 5)) {
                    fourPoint.clickRtfLink();
                    Reporter.log("Clicked on RTF link");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Runtime.getRuntime().exec("TASKKILL /F /IM chrome.exe");
                    Reporter.log("Browser Closed");
                }
                automationManager.performSleep(20);
                //String title = fourPoint.getTitle();
                //System.out.println("title of the page is " + title);
                rxNbr = automationManager.getConnexusWorkFlow().performFourPointForControlledDrug(rxNbr, productName);
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in 4 Point Queue to proceed");
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("RTF link not opened.");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void viewNarxcareOrLogicoyReportUnderCurrentRxIn4PointScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                automationManager.performSleep(5);
                menuBar.launchNarxcareReport();
                automationManager.performSleep(20);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.maximizeNarxReport();
                    Reporter.logScreenShot(Status.PASS, "Maximized Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.minimizeNarxReport();
                    Reporter.logScreenShot(Status.PASS, "Restored Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                orderSearch.closeNarxcarePopUp();
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, "Closed the Narxcare pop up", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                fourPoint.clickButtonCancel();
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in 4 Point Queue to proceed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            // patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void viewNarxcareOrLogicoyReportIn4PointScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                automationManager.performSleep(5);
                if (fourPoint.isElementDisplayed(fourPoint.btnViewNarxCareReport, 30)) {
                    Assert.assertTrue(fourPoint.isElementEnabled(fourPoint.btnViewNarxCareReport));
                    fourPoint.clickViewNarxcareReportButton();
                    automationManager.performSleep(10);
                    if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                        Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    }
                }
                orderSearch.closeNarxcarePopUp();
                fourPoint.clickButtonCancel();
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in 4 Point Queue to proceed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void viewNarxcareReportInChkDURScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in CheckDUR " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(15);
                if (chkDur.clickRedFlagsBtn()) {
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }
                automationManager.performSleep(10);
                chkDur.clickCounsellingNotes();
                automationManager.performSleep(5);
                chkDur.exitFromDur();
                chkDur.clickViewNarxcareReportButtonOnDUR();
                automationManager.performSleep(20);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                orderSearch.closeNarxcarePopUp();
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, "Closed the Narxcare pop up", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                fourPoint.clickButtonCancel();
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            // patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void viewNarxcareOrLogicoyReportUnderCurrentRxInChkDurScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in CheckDUR " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(10);
                menuBar.launchNarxcareReport();
                automationManager.performSleep(20);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.maximizeNarxReport();
                    Reporter.logScreenShot(Status.PASS, "Maximized Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.minimizeNarxReport();
                    Reporter.logScreenShot(Status.PASS, "Restored Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                orderSearch.closeNarxcarePopUp();
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, "Closed the Narxcare pop up", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                fourPoint.clickButtonCancel();
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            // patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateNarxcareReportAndPerform4Point(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                patientSearchPage.openFirstPatientRecord();
                if (fourPoint.isElementDisplayed(fourPoint.btnViewNarxCareReport, 30)) {
                    Assert.assertTrue(fourPoint.isElementEnabled(fourPoint.btnViewNarxCareReport));
                    fourPoint.clickViewNarxcareReportButton();
                    automationManager.performSleep(10);
                    if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                        Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    }
                }
                orderSearch.closeNarxcarePopUp();
                rxNbr = automationManager.getConnexusWorkFlow().performFourPointForControlledDrug(rxNbr, productName);
            }
            automationManager.performSleep(5);
            if (fourPoint.isElementDisplayed(fourPoint.cmbReason, 5)) {
                fourPoint.selectEarlyRefillReson();
                fourPoint.clickOkInEarlyRefillPopUp();
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            // patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateRequiredLableShouldNotBeAvailable(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in CheckDUR " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                if (chkDur.clickRedFlagsBtn()) {
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }
                if (!chkDur.isElementDisplayed(chkDur.lblRequired, 30)) {
                    Assert.assertTrue(true);
                    Reporter.log("Required label not present as the patient score is between 300 and 500");
                }
                if (chkDur.isElementDisplayed(chkDur.narxcare_grid, 30)) {
                    Assert.assertTrue(true);
                    int narxcare_value = Integer.parseInt(chkDur.getnarxcareTextvalue());
                    if (narxcare_value > 300 && narxcare_value < 500) {
                        Assert.assertTrue(true);
                    }
                    Reporter.log("Narxcare grid should be present with data");
                }
                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectCheckBoxes();
                }
                Reporter.log("Accept button enabled with out viewing Narxcare report.");
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + "NarxCare Browser", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                chkDur.clickCounsellingNotes();
                automationManager.performSleep(5);
                chkDur.exitFromDur();
                chkDur.clickViewNarxcareReportButtonOnDUR();
                automationManager.performSleep(20);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + "NarxCare Browser", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }

                orderSearch.closeNarxcarePopUp();
                if ((chkDur.isElementDisplayed(chkDur.rdbRefuseToFill, 30)) && (!chkDur.isElementDisplayed(chkDur.rdbApprovedToFill, 30))) {
                    Assert.assertTrue(true);
                    Reporter.log("Refused to fill radio button should be displayed and Approved to fill radio button should not be displayed");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + "NarxCare Browser", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                chkDur.clickAccept();
                chkDur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            // patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateNarxcareReportAndPerform4PointforFlowA(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                patientSearchPage.openFirstPatientRecord();
                if (fourPoint.isElementDisplayed(fourPoint.btnViewNarxCareReport, 30)) {
                    Assert.assertTrue(fourPoint.isElementEnabled(fourPoint.btnViewNarxCareReport));
                    fourPoint.clickViewNarxcareReportButton();
                    automationManager.performSleep(10);
                    if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                        Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + "NarxCare Browser", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                        connexusStartPage.maximizeNarxReport();
                        Reporter.logScreenShot(Status.PASS, "Maximized Narx Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                        connexusStartPage.minimizeNarxReport();
                        Reporter.logScreenShot(Status.PASS, "Restored Narx Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    }
                }
                orderSearch.closeSearch();
                rxNbr = automationManager.getConnexusWorkFlow().performFourPointForControlledDrug(rxNbr, productName);
            }
            automationManager.performSleep(5);
            if (fourPoint.isElementDisplayed(fourPoint.cmbReason, 5)) {
                fourPoint.selectEarlyRefillReson();
                fourPoint.clickOkInEarlyRefillPopUp();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            isExceptionCaptured = true;
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateNarxCareReportOnDURForGreaterThan500(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in CheckDUR " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(10);

                if (chkDur.clickRedFlagsBtn()) {
                    Reporter.logScreenShot(Status.PASS, "Resolving Red flags", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }

                if (chkDur.isElementDisplayed(chkDur.lblRequired, 30)) {
                    Assert.assertTrue(true);
                    Reporter.log("Required label is present");
                }

                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectAllCheckBoxes();
                    Reporter.logScreenShot(Status.PASS, "Accept button is not enabled", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Reporter.log("Accept button should not be enabled without viewing Narxcare report.");
                }
                if (chkDur.isElementDisplayed(chkDur.narxcare_grid, 30)) {
                    Assert.assertTrue(true);
                    int narxcare_value = Integer.parseInt(chkDur.getnarxcareTextvalue());
                    if (narxcare_value > 500) {
                        Assert.assertTrue(true);
                    }
                    Reporter.log("Narxcare grid displayed with Narcotics value greater than 500");
                }
                automationManager.performSleep(10);
                chkDur.clickCounsellingNotes();
                automationManager.performSleep(5);
                chkDur.exitFromDur();
                chkDur.clickViewNarxcareReportButtonOnDUR();
                automationManager.performSleep(10);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + "NarxCare Browser", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.maximizeNarxReport();
                    Reporter.logScreenShot(Status.PASS, "Maximized Narx Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.minimizeNarxReport();
                    Reporter.logScreenShot(Status.PASS, "Restored Narx Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                orderSearch.closeSearch();

                if ((chkDur.isElementDisplayed(chkDur.rdbRefuseToFill, 30)) && (chkDur.isElementDisplayed(chkDur.rdbApprovedToFill, 30))) {
                    Assert.assertTrue(true);
                    Reporter.log("Approved to fill radio button and Refused to fill radio button should be displayed");
                    chkDur.clickApprovedFillRadioButton();
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + "NarxCare Browser", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                chkDur.clickAccept();
                chkDur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            //patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void launchF7ScreenAndSearchPatient(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(name[0] + "," + name[1]);
            rxLookUp.clickSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.log("F7 screen not launched");
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void launchF7ScreenAndSearchNewPatient(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(name[0] + "," + name[1]);
            rxLookUp.clickSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.log("F7 screen not launched");
            isExceptionCaptured = true;
            // patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateNarxcareReportMaximizeFunctionality(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            rxLookUp.clickViewNarxcareReportButton();
            automationManager.performSleep(20);
            if (connexusStartPage.isElementDisplayed(connexusStartPage.narxCarePopup, 10)) {
                Reporter.logScreenShot(Status.PASS, "Opened NarxCare Browser in F7 screen", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.maximizeNarxReport();
                Reporter.logScreenShot(Status.PASS, "Maximized Narx Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.minimizeNarxReport();
                Reporter.logScreenShot(Status.PASS, "Restored Narx Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            orderSearch.closeNarxcarePopUp();
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, "Closed the Narxcare pop up", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.closeSearch();

        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Maximize Functionality not working.");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            //patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateLogicoyReportInF7Screen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(5);
            rxLookUp.clickViewNarxcareReportButton();
            automationManager.performSleep(10);
            Reporter.logScreenShot(Status.PASS, "Opened Logicoy Browser in F7 screen", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                Reporter.logScreenShot(Status.PASS, "Opened Logicoy Browser in F7 screen", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.maximizeNarxReport();
                Reporter.logScreenShot(Status.PASS, "Maximized Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.minimizeNarxReport();
                Reporter.logScreenShot(Status.PASS, "Restored Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            orderSearch.closeNarxcarePopUp();
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            Reporter.log("Unable to open Logicoy report.");
            isExceptionCaptured = true;
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateLogicoyReportViewedInCurrentRxNotesFor4Point(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                orderSearch.openFirstPatientRecord();
                if (fourPoint.isElementDisplayed(fourPoint.btnViewNarxCareReport, 30)) {
                    Assert.assertTrue(fourPoint.isElementEnabled(fourPoint.btnViewNarxCareReport));
                    fourPoint.clickViewNarxcareReportButton();
                    automationManager.performSleep(10);
                    if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                        Reporter.logScreenShot(Status.PASS, "Opened LogiCoy Browser in 4 point", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    }
                }
                orderSearch.closeNarxcarePopUp();
                menuBar.launchRxNotesScreen();
                String date = consolidatedNotesPage.getTxtDate().trim();
                String time = consolidatedNotesPage.getTxtTime().trim();
                String username = consolidatedNotesPage.getTxtUser().trim();
                String siteId = consolidatedNotesPage.getTxtSiteId().trim();
                String rxNumber = consolidatedNotesPage.getRxNbr().trim();
                String notes = consolidatedNotesPage.getTxtNotes().trim();
                String drugName = consolidatedNotesPage.getDrugName().trim();
                Reporter.log("Rx notes card displayed with " + date + time + username + siteId + rxNumber + drugName + notes);
                Reporter.logScreenShot(Status.PASS, "Viewed Rx notes UnderCurrentRX in 4 Point", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                consolidatedNotesPage.clickCancel();
                Assert.assertEquals(drugName.trim(), productName);
                Assert.assertEquals(notes, inputData.get("CARD_NOTES"));
                Assert.assertEquals(siteId, propertyReader.getProperty("cnx.store"));
                Assert.assertEquals(username, propertyReader.getProperty("cnx.rph.userName"));
                rxNbr = automationManager.getConnexusWorkFlow().performFourPointForControlledDrug(rxNbr, productName);
                Assert.assertEquals(rxNumber, rxNbr);
            }
            automationManager.performSleep(5);
            if (fourPoint.isElementDisplayed(fourPoint.cmbReason, 5)) {
                fourPoint.selectEarlyRefillReson();
                fourPoint.clickOkInEarlyRefillPopUp();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            isExceptionCaptured = true;
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateLogicoyReportIn4Point(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                orderSearch.openFirstPatientRecord();
                if (fourPoint.isElementDisplayed(fourPoint.btnViewNarxCareReport, 30)) {
                    Assert.assertTrue(fourPoint.isElementEnabled(fourPoint.btnViewNarxCareReport));
                    fourPoint.clickViewNarxcareReportButton();
                    automationManager.performSleep(10);
                    if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                        Reporter.logScreenShot(Status.PASS, "Opened LogiCoy Browser in 4 point", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    }
                }
                orderSearch.closeNarxcarePopUp();
                rxNbr = automationManager.getConnexusWorkFlow().performFourPointForControlledDrug(rxNbr, productName);
            }
            if (fourPoint.isElementDisplayed(fourPoint.cmbReason, 5)) {
                fourPoint.selectEarlyRefillReson();
                fourPoint.clickOkInEarlyRefillPopUp();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            isExceptionCaptured = true;
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateLogicoyReportViewedInCurrentRxNotesForChkDUR(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in CheckDUR " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                if (chkDur.clickRedFlagsBtn()) {
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }
                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectCheckBoxes();
                }
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                chkDur.clickCounsellingNotes();
                automationManager.performSleep(5);
                chkDur.exitFromDur();
                chkDur.clickViewNarxcareReportButtonOnDUR();
                automationManager.performSleep(20);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, "Opening Logicoy browser in ChkDUR", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                orderSearch.closeNarxcarePopUp();
                menuBar.launchRxNotesScreen();
                String date = consolidatedNotesPage.getTxtDate().trim();
                String time = consolidatedNotesPage.getTxtTime().trim();
                String username = consolidatedNotesPage.getTxtUser().trim();
                String siteId = consolidatedNotesPage.getTxtSiteId().trim();
                String rxNumber = consolidatedNotesPage.getRxNbr().trim();
                String notes = consolidatedNotesPage.getTxtNotes().trim();
                String drugName = consolidatedNotesPage.getDrugName().trim();
                Reporter.log("Rx notes card displayed with " + date + time + username + siteId + rxNumber + drugName + notes);
                Reporter.logScreenShot(Status.PASS, "Validating Rx notes LogiCoy Browser", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                consolidatedNotesPage.clickCancel();
                Assert.assertEquals(drugName.trim(), productName);
                // Date date1 =new Date();
                Assert.assertEquals(notes, inputData.get("CARD_NOTES"));
                Assert.assertEquals(siteId, propertyReader.getProperty("cnx.store"));
                Assert.assertEquals(username, propertyReader.getProperty("cnx.rph.userName"));
                Assert.assertEquals(rxNumber, rxNbr);
                chkDur.clickAccept();
                chkDur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            //.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateLogicoyReportInChkDUR(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolutionForEarlyRefill(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                if (chkDur.clickRedFlagsBtn()) {
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }
                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectCheckBoxes();
                }
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                chkDur.clickCounsellingNotes();
                automationManager.performSleep(5);
                chkDur.exitFromDur();
                chkDur.clickViewNarxcareReportButtonOnDUR();
                automationManager.performSleep(20);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, "Opening Logicoy browser in ChkDUR", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                orderSearch.closeNarxcarePopUp();
                chkDur.clickAccept();
                chkDur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR queue");
            isExceptionCaptured = true;
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void viewLogicoyReportAndValidateRecordShouldNotBeAddedToRxnotesInF7Screen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(5);
            menuBar.launchRxNotesScreen();
            int actualRxNotes = patientMaintenancePage.getNotesCount().size();
            Reporter.logScreenShot(Status.PASS, "Getting RX notes Count before clicking Logicoy report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            consolidatedNotesPage.clickButtonExit();
            automationManager.performSleep(10);
            rxLookUp.clickViewNarxcareReportButton();
            automationManager.performSleep(20);
            if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                Reporter.logScreenShot(Status.PASS, "Opened LogiCoy Browser in F7 screen", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            orderSearch.closeNarxcarePopUp();
            menuBar.launchRxNotesScreen();
            int expectedRxNotes = patientMaintenancePage.getNotesCount().size();
            Reporter.logScreenShot(Status.PASS, "Getting RX notes Count After clicking Logicoy report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            consolidatedNotesPage.clickButtonExit();
            Assert.assertEquals(actualRxNotes, expectedRxNotes, "Rx notes not added");
            Reporter.log("Logicoy report viewed rx notes not added after clicking on view logicoy report button in F7 screen.");
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateViewLogicoyReportNotDisplayedIn4PointForNonControlledDrug(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                orderSearch.openFirstPatientRecord();
                if (fourPoint.isElementDisplayed(fourPoint.btnViewNarxCareReport, 30)) {
                    Assert.fail("View logicoy button should not be displayed for non controlled drugs in 4 point screen.");
                }
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("View logicoy button should not be displayed for non controlled drugs in 4 point screen.");
                rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(rxNbr);
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            isExceptionCaptured = true;
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateLogicoyReportLinkNotDisplayedInChkDURForNonControlledDrug(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolutionForEarlyRefill(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                if (chkDur.clickRedFlagsBtn()) {
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }
                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectCheckBoxes();
                }
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                if (chkDur.isElementDisplayed(chkDur.viewNarxcareReport, 10)) {
                    Assert.fail("View logicoy button should not be displayed for non controlled drugs in ChkDUR screen.");
                }
                Reporter.log("View logicoy button should not be displayed for non controlled drugs in ChkDUR screen.");
                chkDur.clickAccept();
                chkDur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR queue");
            isExceptionCaptured = true;
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateNarxcareReportForNonControlledDrug(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                patientSearchPage.openFirstPatientRecord();
                if (!fourPoint.isElementDisplayed(fourPoint.btnViewNarxCareReport, 30)) {
                    Assert.assertTrue(true);
                    Reporter.log("NarxCare Report button is not displayed on four point for Non Controlled Drugs");
                    Reporter.logScreenShot(Status.PASS, "Restored Narx Report should not be displayed for Non Controlled Drugs", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    automationManager.performSleep(2);
                }
                rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(rxNbr);
            }
            automationManager.performSleep(5);
            if (fourPoint.isElementDisplayed(fourPoint.cmbReason, 5)) {
                fourPoint.selectEarlyRefillReson();
                fourPoint.clickOkInEarlyRefillPopUp();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            //patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateNarxCareReportOnDURForNonControlledDrugs(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in CheckDUR " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(10);
                if (chkDur.clickRedFlagsBtn()) {
                    Reporter.logScreenShot(Status.PASS, "Resolving Red flags", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }
                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectAllCheckBoxes();
                }
                automationManager.performSleep(10);
                if (!chkDur.isElementDisplayed(chkDur.viewNarxcareReport, 30)) {
                    Assert.assertTrue(true);
                    Reporter.log("NarxCare Report link is not displayed on DUR for Non Controlled Drugs");
                    Reporter.logScreenShot(Status.PASS, "Narx Report should not be displayed for Non Controlled Drugs", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    automationManager.performSleep(2);
                }
                chkDur.clickAccept();
                chkDur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            // patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


    public void verfiyPatientweight() {
        F6Search rxSearch = new F6Search();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(name[0] + "," + name[1]);
        automationManager.performSleep(5);
        rxNbr = rxSearch.getRxNbr(0);
        Reporter.log("Rx number is " + rxNbr);
        String weight = connexusAppUtils.getRequestDesc(rxNbr);
        Reporter.log("Weight for Pediatric patient" + weight);
        orderSearch.closeSearch();
    }


    public void validateGridShouldBeDisplayedWithZeroValuesInChkDURForNoRiskUser(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in CheckDUR " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                if (chkDur.clickRedFlagsBtn()) {
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }
                chkDur.clickCounsellingNotes();
                automationManager.performSleep(5);
                chkDur.exitFromDur();
                chkDur.clickViewNarxcareReportButtonOnDUR();
                automationManager.performSleep(20);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, "Opening Logicoy browser in ChkDUR", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                orderSearch.closeNarxcarePopUp();
                if (chkDur.isElementDisplayed(chkDur.narxcare_grid, 30)) {
                    Assert.assertTrue(true);
                    int narxcare_value = Integer.parseInt(chkDur.getnarxcareTextvalue());
                    int sedatives_value = Integer.parseInt(chkDur.getSedativesTextvalue());
                    int stimulant_value = Integer.parseInt(chkDur.getStimulantTextvalue());
                    int overdose_value = Integer.parseInt(chkDur.getOverdoseTextvalue());
                    if (narxcare_value == 0 && sedatives_value == 0 && stimulant_value == 0 && overdose_value == 0) {
                        Assert.assertTrue(true);
                        Reporter.log("Narxcare grid should be present with zero data for all boxes");
                        Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    }
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Assert.fail("Narxcare grid having values greater than zero for no risk user");
                }
                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectCheckBoxes();
                }
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                chkDur.clickAccept();
                chkDur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR queue");
            isExceptionCaptured = true;
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateReportAndGridNotAvailableInChkDURForPatientScoreLessThan299(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in CheckDUR " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                if (chkDur.clickRedFlagsBtn()) {
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }
                if (!chkDur.isElementDisplayed(chkDur.viewNarxcareReport, 10) && (chkDur.isElementDisplayed(chkDur.narxcare_grid, 10))) {
                    Assert.assertTrue(true);
                    Reporter.log("Narxcare Report link and grid not present as the patient score is Lessthan 299");
                } else {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Assert.fail("Narxcare Report link and grid present as the patient score is Lessthan 299");
                }
                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectCheckBoxes();
                }
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                chkDur.clickAccept();
                chkDur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR queue");
            isExceptionCaptured = true;
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateConsolidateReportsForGreaterThan500(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in CheckDUR " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                String productName = orderSearch.getProductName(0);
                automationManager.performSleep(10);

                if (chkDur.clickRedFlagsBtn()) {
                    Reporter.logScreenShot(Status.PASS, "Resolving Red flags", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }

                if (chkDur.isElementDisplayed(chkDur.lblRequired, 30)) {
                    Assert.assertTrue(true);
                    Reporter.log("Required label is present");
                }

                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectAllCheckBoxes();
                    Reporter.logScreenShot(Status.PASS, "Accept button is not enabled", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Reporter.log("Accept button should not be enabled without viewing Narxcare report.");
                }
                automationManager.performSleep(10);
                chkDur.clickCounsellingNotes();
                automationManager.performSleep(5);
                chkDur.exitFromDur();
                chkDur.clickViewNarxcareReportButtonOnDUR();
                automationManager.performSleep(10);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, "NarxCare Report is opened", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                orderSearch.closeSearch();
                Reporter.log("Closed NarxCare Report");
                Reporter.logScreenShot(Status.PASS, "NarxCare Report is Closed", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

                if ((chkDur.isElementDisplayed(chkDur.rdbRefuseToFill, 30)) && (chkDur.isElementDisplayed(chkDur.rdbApprovedToFill, 30))) {
                    Assert.assertTrue(true);
                    Reporter.logScreenShot(Status.PASS, "Approved to Fill and Refuse To Fill Radio Buttons are displayed", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Reporter.log("Consolidated popup is opened when clicks on Approved Fill adio Button");
                    chkDur.clickApprovedFillRadioButtonforenterTxt();
                    Reporter.logScreenShot(Status.PASS, "Consolidate Popup is closed", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                automationManager.performSleep(2);
                menuBar.launchRxNotesScreen();
                String date = consolidatedNotesPage.getTxtDate().trim();
                String time = consolidatedNotesPage.getTxtTime().trim();
                String username = consolidatedNotesPage.getTxtUser().trim();
                String siteId = consolidatedNotesPage.getTxtSiteId().trim();
                String rxNumber = consolidatedNotesPage.getRxNbr().trim();
                String notes = consolidatedNotesPage.getTxtNotes().trim();
                String drugName = consolidatedNotesPage.getDrugName().trim();
                String narxcareNotes = consolidatedNotesPage.getTxtNotesofRXNotes().trim();
                Reporter.log("Rx notes card displayed with entered Notes " + date + time + username + siteId + rxNumber + drugName + notes);
                Reporter.log("Rx notes card for viewing Report " + date + time + username + siteId + rxNumber + drugName + narxcareNotes);
                Reporter.logScreenShot(Status.PASS, "Validating Rx notes", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                consolidatedNotesPage.clickCancel();
                chkDur.clickAccept();
                Reporter.logScreenShot(Status.PASS, "Accepting DUR", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                chkDur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void ValidateConsolidatePopupfor300to500(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in CheckDUR " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                Reporter.logScreenShot(Status.PASS, "Open CheckDUR", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                patientSearchPage.openFirstPatientRecord();
                String productName = orderSearch.getProductName(0);
                if (chkDur.clickRedFlagsBtn()) {
                    Reporter.logScreenShot(Status.PASS, "Resolving Red Flags", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    chkDur.selectResolvedCheckBoxes();
                    Reporter.log("Resolvd Red Flags");
                    chkDur.clickDurBtn();
                }

                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectAllCheckBoxes();
                }
                Reporter.logScreenShot(Status.PASS, "Selected Checkboxes on DUR", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                automationManager.performSleep(5);
                chkDur.clickCounsellingNotes();
                automationManager.performSleep(5);
                chkDur.exitFromDur();
                chkDur.clickViewNarxcareReportButtonOnDUR();
                automationManager.performSleep(5);
                Reporter.log("Clicked Narxcare Report Link");
                automationManager.performSleep(20);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, "Opened Narxcare Browser", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                orderSearch.closeNarxcarePopUp();
                Reporter.logScreenShot(Status.PASS, "Closed Narxcare Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                if (chkDur.isElementDisplayed(chkDur.rdbApprovedToFill, 30)) {
                    Reporter.logScreenShot(Status.PASS, "Approved to fill radio button is displayed", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    chkDur.clickApprovedbuttonforlessthan500users();
                    if (!consolidatedNotesPage.isElementDisplayed(consolidatedNotesPage.ConsoildatePopup)) {
                        Assert.assertTrue(true);
                        Reporter.log("consolidate popup does not displayed while clicks on Approved to Fill radio button");
                    }
                    Reporter.logScreenShot(Status.PASS, "Consolidate popup does not displayed", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                menuBar.launchRxNotesScreen();
                String date = consolidatedNotesPage.getTxtDate().trim();
                String time = consolidatedNotesPage.getTxtTime().trim();
                String username = consolidatedNotesPage.getTxtUser().trim();
                String siteId = consolidatedNotesPage.getTxtSiteId().trim();
                String rxNumber = consolidatedNotesPage.getRxNbr().trim();
                String notes = consolidatedNotesPage.getTxtNotes().trim();
                String drugName = consolidatedNotesPage.getDrugName().trim();
                Reporter.log("Rx notes card displayed with " + date + time + username + siteId + rxNumber + drugName + notes);
                Reporter.logScreenShot(Status.PASS, "Validating Rx notes", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                consolidatedNotesPage.clickCancel();
                chkDur.clickAccept();
                Reporter.logScreenShot(Status.PASS, "Accepting DUR", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                chkDur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateConsolidateReportForPatientScoreLessThan299(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in CheckDUR " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                Reporter.logScreenShot(Status.PASS, "Performing ChkDUR", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                patientSearchPage.openFirstPatientRecord();
                String productName = orderSearch.getProductName(0);
                if (chkDur.clickRedFlagsBtn()) {
                    Reporter.logScreenShot(Status.PASS, "Resolving Red flags", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    chkDur.selectResolvedCheckBoxes();
                    Reporter.log("Resolved Red Flags");
                    chkDur.clickDurBtn();
                }

                if (chkDur.isElementDisplayed(chkDur.lblRequired, 30)) {
                    Assert.assertTrue(true);
                    Reporter.log("Required label is present");
                }

                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectAllCheckBoxes();
                    Reporter.logScreenShot(Status.PASS, "Accept button is not enabled", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Reporter.log("Accept button should not be enabled without viewing Narxcare report.");
                }
                automationManager.performSleep(10);
                chkDur.clickCounsellingNotes();
                automationManager.performSleep(5);
                chkDur.exitFromDur();
                chkDur.clickViewNarxcareReportButtonOnDUR();
                automationManager.performSleep(10);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, "NarxCare Report is opened", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                orderSearch.closeNarxcarePopUp();
                Reporter.log("Closed NarxCare Report");
                Reporter.logScreenShot(Status.PASS, "NarxCare Report is Closed", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

                if (chkDur.isElementDisplayed(chkDur.rdbApprovedToFill, 30)) {
                    Reporter.logScreenShot(Status.PASS, "Approved to Fill radio button is displayed", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    chkDur.clickApprovedbuttonforlessthan500users();
                    if (!consolidatedNotesPage.isElementDisplayed(consolidatedNotesPage.ConsoildatePopup)) {
                        Assert.assertTrue(true);
                        Reporter.log("consolidate popup does not displayed");
                    }
                    Reporter.logScreenShot(Status.PASS, "Consolidate popup does not displayed when clicks on approved to fill radio button", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }

                menuBar.launchRxNotesScreen();
                String date = consolidatedNotesPage.getTxtDate().trim();
                String time = consolidatedNotesPage.getTxtTime().trim();
                String username = consolidatedNotesPage.getTxtUser().trim();
                String siteId = consolidatedNotesPage.getTxtSiteId().trim();
                String rxNumber = consolidatedNotesPage.getRxNbr().trim();
                String notes = consolidatedNotesPage.getTxtNotes().trim();
                String drugName = consolidatedNotesPage.getDrugName().trim();
                Reporter.log("Rx notes card displayed with " + date + time + username + siteId + rxNumber + drugName + notes);
                Reporter.logScreenShot(Status.PASS, "Validating Rx notes", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                consolidatedNotesPage.clickCancel();
                chkDur.clickAccept();
                chkDur.clickConnexusOk();
                Reporter.logScreenShot(Status.PASS, "CheckDUR Completed", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("ChkDUR completed");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateViewReportOptionalonchkDUR(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in CheckDUR " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                Reporter.logScreenShot(Status.PASS, "Open DUR", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, "On CheckDUR Page", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                if (chkDur.clickRedFlagsBtn()) {
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }
                if (!chkDur.isElementDisplayed(chkDur.lblRequired, 30)) {
                    Assert.assertTrue(true);
                    Reporter.log("Required label not present");
                }
                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectCheckBoxes();
                }
                Reporter.log("Accept button enabled with out viewing Narxcare report.");
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, "Selected checkboxes on DUR", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                chkDur.clickCounsellingNotes();
                automationManager.performSleep(5);
                chkDur.exitFromDur();
                chkDur.clickViewNarxcareReportButtonOnDUR();
                automationManager.performSleep(10);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, "Opend NarxCare Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                orderSearch.closeNarxcarePopUp();
                Reporter.logScreenShot(Status.PASS, "Closed NarxCare Report", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                if ((chkDur.isElementDisplayed(chkDur.rdbRefuseToFill, 30)) && (!chkDur.isElementDisplayed(chkDur.rdbApprovedToFill, 30))) {
                    Assert.assertTrue(true);
                    Reporter.log("Only Refused to fill radio button is displayed and Approved to fill radio button is not displayed");
                    Reporter.logScreenShot(Status.PASS, "Only RefuseTofill radio button is displayed", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                menuBar.launchRxNotesScreen();
                String date = consolidatedNotesPage.getTxtDate().trim();
                String time = consolidatedNotesPage.getTxtTime().trim();
                String username = consolidatedNotesPage.getTxtUser().trim();
                String siteId = consolidatedNotesPage.getTxtSiteId().trim();
                String rxNumber = consolidatedNotesPage.getRxNbr().trim();
                String notes = consolidatedNotesPage.getTxtNotes().trim();
                String drugName = consolidatedNotesPage.getDrugName().trim();
                Reporter.log("Rx notes card displayed with " + date + time + username + siteId + rxNumber + drugName + notes);
                Reporter.logScreenShot(Status.PASS, "Validating Rx notes", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                consolidatedNotesPage.clickCancel();
                Reporter.logScreenShot(Status.PASS, "Closed RX notes Popup", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                chkDur.clickAccept();
                chkDur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            }
        } catch (Exception e) {
            Reporter.log("Test failed at ChkDUR queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateRefusalToFill(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in CheckDUR " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {

                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                String productName = orderSearch.getProductName(0);
                automationManager.performSleep(10);

                if (chkDur.clickRedFlagsBtn()) {
                    Reporter.logScreenShot(Status.PASS, "Resolving Red flags", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }

                if (chkDur.isElementDisplayed(chkDur.lblRequired, 30)) {
                    Assert.assertTrue(true);
                    Reporter.log("Required label is present");
                }

                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectAllCheckBoxes();
                    Reporter.logScreenShot(Status.PASS, "Accept button is not enabled", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Reporter.log("Accept button should not be enabled without viewing Narxcare report.");
                }
                automationManager.performSleep(5);
                chkDur.clickCounsellingNotes();
                automationManager.performSleep(5);
                chkDur.exitFromDur();
                chkDur.clickViewNarxcareReportButtonOnDUR();
                automationManager.performSleep(20);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, "NarxCare Report is opened", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                orderSearch.closeSearch();
                Reporter.log("Closed NarxCare Report");
                Reporter.logScreenShot(Status.PASS, "NarxCare Report is Closed", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

                if ((chkDur.isElementDisplayed(chkDur.rdbRefuseToFill, 30)) && (chkDur.isElementDisplayed(chkDur.rdbApprovedToFill, 30))) {
                    Assert.assertTrue(true);
                    Reporter.logScreenShot(Status.PASS, "Approved to Fill and Refuse To Fill Radio Buttons are displayed", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    chkDur.clickRDBRefusetoFill();
                    Reporter.logScreenShot(Status.PASS, "clicked Refuse to Fill Radio Button", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    automationManager.performSleep(10);
                    Runtime.getRuntime().exec("TASKKILL /F /IM chrome.exe");
                    Reporter.logScreenShot(Status.PASS, "Closing Browser", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Reporter.log("Closed the Browser");
                    automationManager.performSleep(2);
                    chkDur.clickBtnCancelFill();
                    chkDur.clickYes();
                }
            }
            Reporter.log("Fill is cancelled successfully");

        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    public void validateNarxcareOnFourPointforNewPatient(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (rxNbr == null || rxNbr.isEmpty()) {
                rxNbr = getRxNbr(name[0], name[1], siteId);
                if (rxNbr == null || rxNbr.isEmpty()) {
                    Reporter.log("Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                    Assert.fail("Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                }
                Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            String productName = orderSearch.getProductName(0);
            patientSearchPage.openFirstPatientRecord();
            if (fourPoint.isElementDisplayed(fourPoint.btnViewNarxCareReport, 30)) {
                Assert.assertTrue(fourPoint.isElementEnabled(fourPoint.btnViewNarxCareReport));
                fourPoint.clickViewNarxcareReportButton();
                automationManager.performSleep(10);
                if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
            }
            orderSearch.closeSearch();
            rxNbr = automationManager.getConnexusWorkFlow().performFourPointForControlledDrug(name[0] + "," + name[1], productName);
            automationManager.performSleep(5);
            if (fourPoint.isElementDisplayed(fourPoint.cmbReason, 5)) {
                fourPoint.selectEarlyRefillReson();
                fourPoint.clickOkInEarlyRefillPopUp();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validatePatientDBOnFourPoint(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                patientSearchPage.openFirstPatientRecord();
                if (!fourPoint.isElementDisplayed(fourPoint.btnViewNarxCareReport, 30)) {
                    productName = orderSearch.getProductName(0);
                    patientSearchPage.openFirstPatientRecord();
                    if (fourPoint.isElementDisplayed(fourPoint.btnViewNarxCareReport, 30)) {
                        Assert.assertTrue(fourPoint.isElementEnabled(fourPoint.btnViewNarxCareReport));
                        fourPoint.clickViewNarxcareReportButton();
                        automationManager.performSleep(10);
                        if (connexusStartPage.getTextFromAppTitleBar(1).contains(inputData.get("NARXCARE_BROWSER_TITLE"))) {
                            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                        }
                    }
                    orderSearch.closeSearch();
                    Reporter.log("NarxCare Details in patientRequestTable for viewing Narxcare Report on fourPoint");
                    verifyNarxCareDetailsinDB();
                }
                rxNbr = automationManager.getConnexusWorkFlow().performFourPointForControlledDrug(rxNbr, productName);
            }
            automationManager.performSleep(5);
            if (fourPoint.isElementDisplayed(fourPoint.cmbReason, 5)) {
                fourPoint.selectEarlyRefillReson();
                fourPoint.clickOkInEarlyRefillPopUp();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    public void verifyNarxCareDetailsinDB() {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String patientId = connexusAppUtils.getPatientId(name[0], name[1]);
        values = connexusAppUtils.fetchNarxPatientTableDetails(patientId);
        int statusCode = (int) values.get("svc_rqst_status_code");
        System.out.println("statusCode" + statusCode);
        String errorMsg = values.get("error_message_txt").toString();
        if (statusCode == 200) {
            Assert.assertTrue(true, "NarxCare Details are updated in patientRequestTable");
            Reporter.log("NarxCare Details are updated in patientRequestTable");
        } else {
            Assert.fail("NarxCare Details are not updated in DB");
        }
    }

    public void validateRxstatusinF7(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            rxLookUp.getRxStatus();
            System.out.println(rxLookUp.getRxStatus());
            Assert.assertEquals(rxLookUp.getRxStatus(), "Canceled");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public String validateNarxCareDetailsInCosmos(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientId = connexusAppUtils.getPatientId(name[0], name[1]);
            storeNbr = connexusAppUtils.getStoreId();
            String query = "SELECT * FROM c WHERE c.storeNbr=" + storeNbr + " AND c.patientId=" + patientId;
            Reporter.log("executing query: " + query);
            JsonNode record = automationManager.getNarxcareCosmosDb().executeQuery("logiCoy_narxcare_report", query, JsonNode.class);
            Reporter.logJSON("Cosmos DB Response", StringUtils.convertToJson(record));
            Assert.assertFalse(record.isEmpty(), "No record found in DB");
            dbScore = record.path("bambooNarcoticsScore").asText();
            narcoticScoreUI = String.valueOf(narcoticScore);
            Reporter.log("Narcotic Score from UI: " + narcoticScoreUI + "And Narcotic score fetched from db: " + dbScore);
            Assert.assertEquals(dbScore, narcoticScoreUI, "Narcotics scores are not matching");
            long tsEpoch = record.path("_ts").asLong();
            Assert.assertTrue(Math.abs(Instant.now().getEpochSecond() - tsEpoch) <= 180, "_ts is not close to current time stamp");
            Reporter.log("_ts from Cosmos DB Response is current time stamp: " + tsEpoch);
            scoreExpireTsStr = record.path("scoreExpireTS").asText();
            Instant scoreExpireTs = Instant.parse(scoreExpireTsStr + "Z");
            Instant expectedExpire = Instant.ofEpochSecond(tsEpoch).plusSeconds(24 * 3600);
            Assert.assertTrue(Math.abs(Duration.between(expectedExpire, scoreExpireTs).getSeconds()) <= 180, "scoreExpireTs is not 24hrs from_ts");
            Reporter.log("scoreExpireTs from Cosmos DB response is ~24hrs from _ts: " + scoreExpireTs);
            requestId = record.path("requestId").asText();
            if (requestId == null || requestId.isEmpty()) {
                Reporter.log("Request Id is missing in cosmos DB response");
            }
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
        return requestId;
    }

    public void validateViewNarxcareReportDisabledInF7ScreenForTechnician() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openRxLookUpPage();
            if (!rxLookUp.isViewNarxcareReportButton()) {
                Reporter.log("View Narxcare Report Button is Disabled");

                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

            } else {
                Assert.fail("View Narxcare Report BUtton is Enabled");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at F7 Screen");
            softAssert.fail(e.toString());
        }
    }

    public void openRxLookUpPage() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(name[0] + "," + name[1]);
            rxLookUp.clickSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Rx look up page not opened");
            softAssert.fail(e.toString());
        }
    }

    public void validateNarxcareReportUnderCurrentRxIn4PointScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                menuBar.validateNarxcareReportDisabledAtCurrentRXMenu();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in 4 Point Queue to proceed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            // patientSearchPage.closeIfAnyPopUpOpened();

            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validate4PointScreenNotComingUpForTechnician(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                if(modifyDetails.isModifyDetailsOpened())
                {
                    Reporter.log("Technician is unable to access 4point screen");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                else if(rxSearch.isFourPointPageDisplayed() ){
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Assert.fail("Technician should not have access to 4 Point");
                }
            }
        }
        catch(Throwable e){
            Reporter.log("Test failed at 4 Point queue");
            isExceptionCaptured = true;
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void validateChkDURScreenNotComingUpForTechnician(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                if(modifyDetails.isModifyDetailsOpened())
                {
                    Reporter.log("Technician is unable to access chkDUR screen");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
                else if(rxSearch.isCheckDURPageDisplayed() ){
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Assert.fail("Technician should not have access to chkDUR");
                }
            }
        }
        catch(Throwable e){
            Reporter.log("Test failed at 4 Point queue");
            isExceptionCaptured = true;
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
}