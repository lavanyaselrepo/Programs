package connexus.M3P.testscripts;

import com.aventstack.extentreports.Status;
import connexus.TPFlows.TpTestscripts;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;

import java.util.*;

/**
 * M3P (Medicaid/Medicare) test scripts for error verification and payer of last resort logic.
 */
public class M3PFlowTestscripts extends TpTestscripts {

    @Override
    public void loginConnexus(LoginAs.userType userType) {
        initSharedDependencies();
        super.loginConnexus(userType);
    }

    public void verifyM3PErrorInResolution(Integer rxNbr, Map<String, Object> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(15);
            patientSearchPage.launchOrderSearchScreen();
            automationManager.performSleep(10);
            patientSearchPage.performSearch(String.valueOf(rxNbr));
            patientSearchPage.openFirstPatientRecord();
            automationManager.performSleep(10);
            String pblmDesc = resolutionPage.getTPProblemDescription();
            Assert.assertEquals(pblmDesc.trim(), inputData.get("TPERROR_TEXT"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }
    }

    public void verifyDowntimeCashButtonsForM3PError(Integer rxNbr, Map<String, Object> inputData, boolean verify, String enable) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientSearchPage.launchOrderSearchScreen();
            automationManager.performSleep(5);
            patientSearchPage.performSearch(String.valueOf(rxNbr));
            patientSearchPage.openFirstPatientRecord();
            automationManager.performSleep(10);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(5);
            if ((resolutionPage.isDowntimeButtonEnabled() == verify) && (resolutionPage.isSwitchToCashEnabled() == verify)) {
                Assert.assertTrue(true, "DowntimeButton & SwitchToCash button are " + enable);
                Reporter.log("Downtime Button & SwitchToCash" + enable);
                modifyDetails.clickCancel();
            } else {
                Assert.fail("DowntimeButton/SwitchToCash not " + enable);
            }
            resolutionPage.clickCancel();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }
    }

    public void modifyRX() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(3);
            modifyDetails.openModifyDetailsScreen();
            automationManager.performSleep(3);
            modifyDetails.inputDrugExpDate("09/09/2026");
            modifyDetails.clickAccept();
            automationManager.performSleep(3);
            Reporter.log("RX in modify details screen");
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickYes();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void submitResolutionPage() {
        resolutionPage.clickSubmit();
    }

    public void verifyMP3Error() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        Assert.assertTrue(resolutionPage.checkErrorTextExist());
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
    }

    public void verifyPayerOfLastResortError(Integer patientId, Map<String, Object> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String patCarrier = inputData.get("TP_CARRIER_BIN_2").toString();
            String patPlan = inputData.get("TP_PLAN_2").toString();
            addAdditionalPayerAndProcess(patientId, patCarrier, patPlan, inputData);
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }
}