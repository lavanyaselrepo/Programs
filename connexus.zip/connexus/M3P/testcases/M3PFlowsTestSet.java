package connexus.M3P.testcases;

import bom.tests.WrapperTestScript;
import connexus.M3P.testscripts.M3PFlowTestscripts;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Map;

import static connexus.ConnexusTestScripts.requireNonNullId;
import static connexus.ConnexusTestScripts.safeTearDown;

/**
 * M3P (Medicaid/Medicare) pharmacy claim tests. Login: HOMEOFFICE_ADFlagOn (session reused). Flags: 28750=TRUE (default, not set explicitly).
 * Recovery: relaunches only on flag change or exception. No restart required.
 * @author Anju Mohan (a0m1jtc), Prasanna Yaragani (p0y00v9)
 */
public class M3PFlowsTestSet {

    private final M3PFlowTestscripts m3PFlowTestscripts = new M3PFlowTestscripts();

    @BeforeClass
    public void beforeClass() {
        m3PFlowTestscripts.connexusAppUtils.startAppiumServer();
        m3PFlowTestscripts.loginUserType = LoginAs.userType.HOMEOFFICE_ADFlagOn;
    }

    @BeforeMethod(alwaysRun = true)
    public void beforeMethod() {
        System.setProperty("testcaseId", getClass().getSimpleName());
        m3PFlowTestscripts.initializeTestCase(false);
        m3PFlowTestscripts.waitForConnexusReady();
    }

    /**
     * On test failure, presses Escape 3–5x to close any orphaned screens before next test.
     */
    @AfterMethod(alwaysRun = true)
    public void afterMethod(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            m3PFlowTestscripts.escapeToHome();
        }
    }

    @AfterClass
    public void closeConnexus() {
        safeTearDown(m3PFlowTestscripts.connexusAppUtils);
    }

    /**
     * HWPHME2E-3253: Verify Switch to CASH & Downtime disabled in Resolution screen for orders with 057 Approved Message Code
     * @author Anju Mohan (a0m1jtc)
     */
    @Test(enabled = true, description = "Verify Switch to CASH & Downtime disabled in Resolution screen for orders with 057 Approved Message Code",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/M3P/M3PFlows.json", sheetName = "BOMM3PFLOWS")
    public void HWPHME2E_3253(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_3253 - Verify Switch to CASH & Downtime disabled in Resolution screen for orders with 057 Approved Message Code");
        // Guard: a null rxNbr would silently String.valueOf("null") downstream and search for the wrong order.
        int rxNbr = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_3253");
        m3PFlowTestscripts.verifyDowntimeCashButtonsForM3PError(rxNbr, inputData, false, "disabled");
    }

    /**
     * HWPHME2E-3254: Verify Rx lands in resolution with "Splitbill Expected with M3P" if M3P not associated with TP plans MPD057 or MPD574RX
     * @author Anju Mohan (a0m1jtc)
     */
    @Test(enabled = true, description = "Verify Rx lands in resolution with \"Splitbill Expected with M3P\" if M3P not associated with TP plans MPD057 or MPD574RX",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/M3P/M3PFlows.json", sheetName = "BOMM3PFLOWS")
    public void HWPHME2E_3254(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_3254 - Verify Rx lands in resolution with \"Splitbill Expected with M3P\" if M3P not associated with TP plans MPD057 or MPD574RX");
        int rxNbr = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_3254");
        m3PFlowTestscripts.verifyM3PErrorInResolution(rxNbr, inputData);
    }

    /**
     * HWPHME2E-4369: Verify user cannot bypass M3P validations on modify details screen with QA MPD057 Plan
     * @author Anju Mohan (a0m1jtc)
     */
    @Test(enabled = true, description = "Verify user not able to bypass M3P validations on modify details screen when order dropped with QA MPD057 Plan",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/M3P/M3PFlows.json", sheetName = "BOMM3PFLOWS")
    public void HWPHME2E_4369(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_4369 - Verify user not able to bypass M3P validations on modify details screen when order dropped with QA MPD057 Plan");
        int rxNbr = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_4369");
        m3PFlowTestscripts.verifyM3PErrorInResolution(rxNbr, inputData);
        m3PFlowTestscripts.modifyRX();
        m3PFlowTestscripts.submitResolutionPage();
    }

    /**
     * HWPHME2E-4370: Verify user cannot bypass M3P validations on modify details screen with QA MPD574RX Plan
     * @author Anju Mohan (a0m1jtc)
     */
    @Test(enabled = true, description = "Verify user not able to bypass M3P validations on modify details screen when order dropped with QA MPD574RX Plan",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/M3P/M3PFlows.json", sheetName = "BOMM3PFLOWS")
    public void HWPHME2E_4370(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_4370 - Verify user not able to bypass M3P validations on modify details screen when order dropped with QA MPD574RX Plan");
        int rxNbr = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_4370");
        m3PFlowTestscripts.verifyM3PErrorInResolution(rxNbr, inputData);
        m3PFlowTestscripts.modifyRX();
        m3PFlowTestscripts.submitResolutionPage();
        m3PFlowTestscripts.verifyMP3Error();
    }

    /**
     * HWPHME2E-3255: Verify payer of last resort error when M3P is not last payer and no medicaid on patient profile
     * @author Prasanna Yaragani (p0y00v9)
     */
    @Test(enabled = true, description = "Verify payer of last resort error message when M3P is not the last payer and no medicaid on patient profile",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/M3P/M3PFlows.json", sheetName = "BOMM3PFLOWS")
    public void HWPHME2E_3255(Map<String, Object> inputData) {
        Integer patientId = WrapperTestScript.createPatient(inputData,
                "HWPHME2E_3255 - Verify payer of last resort error message when M3P is not the last payer and no medicaid on patient profile");
        m3PFlowTestscripts.verifyPayerOfLastResortError(patientId, inputData);
    }
}
