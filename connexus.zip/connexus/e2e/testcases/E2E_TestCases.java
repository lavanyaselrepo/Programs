package connexus.e2e.testcases;

import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import io.strati.libs.joda.time.DateTime;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class E2E_TestCases {
    public static LoginAs.userType loginUser_Type=LoginAs.userType.PHARMACIST_ADFlagOff;
    public static String fileName = "E2E_execution_status.txt";
    ConnexusTestScripts connexusTestScripts = new ConnexusTestScripts(loginUser_Type, fileName);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    PropertyReader propertyReader = PropertyReader.getInstance();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    boolean flagUpdated;

    public void flagsCheckUp(){
        //Set the state to AR for the current store
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");

        //Verify and set the flag 26849 (Redesign Contact Information) to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("26849", "TRUE");

        //Verify and set the flag 8670 (Enable/Disable Bagging queue) to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("8670", "FALSE");

        flagUpdated |= connexusAppUtils.readAndUpdateFlag("1667", "FALSE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("1666", "TRUE");

        flagUpdated |= connexusAppUtils.readAndUpdateFlag("26218", "TRUE");

        //Verify and set the flag 15166 (Flag to Enable ABN Changes) to TRUE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15166", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("5300", "UPC");

        //Verify and set the flag 24550 (Advanced Beneficiary Notice (ABN) Requirement) to FALSE
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("24550", "FALSE");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Warning: Check with your team before running this test suite, it will clear up all the prescriptions in the store
     ----------------------------------------------------------------------------------------------------------*/
    public void clearDataInStore(){
        //Clear data in DropOff
        connexusAppUtils.clearDataInQueue(WorkQueueCode.DROPOFF.getWorkQueueCode());

        //Clear data in Input
        connexusAppUtils.clearDataInQueue(WorkQueueCode.INPUT.getWorkQueueCode());

        //Clear data in Counsel
        connexusAppUtils.clearDataInQueue(WorkQueueCode.COUNSEL.getWorkQueueCode());

        //Clear data in Filling
        connexusAppUtils.clearDataInQueue(WorkQueueCode.FILLING.getWorkQueueCode());

        //Clear data in 4 Point
        connexusAppUtils.clearDataInQueue(WorkQueueCode.FOURPOINT.getWorkQueueCode());

        //Clear data in PickUp
        connexusAppUtils.clearDataInQueue(WorkQueueCode.PICKUP.getWorkQueueCode());

        //Clear data in Resolve
        connexusAppUtils.clearDataInQueue(WorkQueueCode.RESOLVE.getWorkQueueCode());

        //Clear data in TP
        connexusAppUtils.clearDataInQueue(WorkQueueCode.TP.getWorkQueueCode());

        //Clear data in DUR
        connexusAppUtils.clearDataInQueue(WorkQueueCode.DUR.getWorkQueueCode());

        //Clear data in Visual Verify
        connexusAppUtils.clearDataInQueue(WorkQueueCode.VISUALVERIFY.getWorkQueueCode());

        //Clear data in Modify Details
        connexusAppUtils.clearDataInQueue(WorkQueueCode.MODIFYDETAILS.getWorkQueueCode());

        //Clear data in ChkDUR
        connexusAppUtils.clearDataInQueue(WorkQueueCode.CHKDUR.getWorkQueueCode());

        //Clear data in Call Dr
        connexusAppUtils.clearDataInQueue(WorkQueueCode.CALLDR.getWorkQueueCode());

        //Clear data in POS
        connexusAppUtils.clearDataInQueue(WorkQueueCode.POS.getWorkQueueCode());
    }

    @BeforeClass
    public void loginToConnexus(){
        connexusTestScripts.siteId = connexusAppUtils.getStoreId();
        connexusAppUtils.startAppiumServer();
        connexusAppUtils.clearFile(fileName);
        connexusAppUtils.writeTextToFile("Auto Sanity has started for Store " + connexusTestScripts.siteId, null, fileName, 0, DateTime.now());
    }

    @AfterClass
    public void closeConnexus() {
        connexusAppUtils.writeTextToFile("Auto Sanity has ended", null, fileName, 0, DateTime.now());
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: E2E_Cash_Flow_Non_Controlled_Drug
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-2")
    @Test(enabled = true, description = "E2E_Cash_Flow_Non_Controlled_Drug",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/E2E/E2EDataBook.json", sheetName = "E2E")
    public void HWPHME2E_2_E2E_Cash_Flow_Non_Controlled_Drug(Map<String, String> inputData) {
        Reporter.log("=== Validating E2E cash flow for non controlled drug ===");
        connexusAppUtils.writeTextToFile("HWPHME2E_2_E2E_Cash_Flow_Non_Controlled_Drug",null,fileName,0, DateTime.now());

        Reporter.log("Logged in store:" + connexusTestScripts.siteId);
        flagsCheckUp();

        //initialize the test case
        connexusTestScripts.initializeTestCase(flagUpdated);

        //Create a new patient
        connexusTestScripts.createNewPatient(inputData);

        //Complete DropOff
        connexusTestScripts.performDropOff(Priority.Critical);

        //Complete Input
        connexusTestScripts.performInput(inputData);

        //Complete 4Point
        connexusTestScripts.perform4Point(false);

        //Complete Filling
        connexusTestScripts.performFilling();

        //Complete Visual Verify
        connexusTestScripts.performVisualVerify();

        //Complete PickUp
        connexusTestScripts.performPickUp(inputData);

        //Complete Counselling
        connexusTestScripts.performCounselling();

        //Perform POS - Offline Sale
        connexusTestScripts.performPOS();

        //Verify Rx is in EOD Queue
        connexusTestScripts.verifyRxInEOD();

        Reporter.log("=== RX Work queue status should be EOD ===");

    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: E2E_TP_Flow_Non_Controlled_Drug
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-40")
    @Test(enabled = true, description = "E2E_TP_Flow_Non_Controlled_Drug",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/E2E/E2EDataBook.json", sheetName = "E2E")
    public void HWPHME2E_40_E2E_TP_Flow_Non_Controlled_Drug(Map<String, String> inputData) {
        Reporter.log("=== Validating E2E TP flow for non controlled drug ===");
        connexusAppUtils.writeTextToFile("HWPHME2E_40_E2E_TP_Flow_Non_Controlled_Drug",null,fileName,0, DateTime.now());

        flagsCheckUp();

        //initialize the test case
        connexusTestScripts.initializeTestCase(flagUpdated);

        //Create a new patient with 1 TP plan
        connexusTestScripts.createNewPatient(inputData,1);

        //Complete DropOff
        connexusTestScripts.performDropOff(Priority.Critical);

        //Complete Input
        connexusTestScripts.performInput(inputData);

        //Complete 4Point, arg. controlled Drug - false
        connexusTestScripts.perform4PointForTPPatient(false);

        //Complete Filling
        connexusTestScripts.performFilling();

        //Complete Visual Verify
        connexusTestScripts.performVisualVerify();

        //Complete PickUp
        connexusTestScripts.performPickUp(inputData);

        //Complete Counselling
        connexusTestScripts.performCounselling();

        //Perform POS - Offline Sale
        connexusTestScripts.performPOS();

        //Verify Rx is in EOD Queue
        connexusTestScripts.verifyRxInEOD();

        Reporter.log("=== RX Work queue status should be EOD ===");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: E2E_Cash_Flow_Controlled_Drug
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-4")
    @Test(enabled = true, description = "E2E_Cash_Flow_Controlled_Drug",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/E2E/E2EDataBook.json", sheetName = "E2E")
    public void HWPHME2E_4_E2E_Cash_Flow_Controlled_Drug(Map<String, String> inputData) {
        Reporter.log("=== Validating E2E cash flow for controlled drug ===");
        connexusAppUtils.writeTextToFile("HWPHME2E_4_E2E_Cash_Flow_Controlled_Drug",null,fileName,0, DateTime.now());

        flagsCheckUp();

        //initialize the test case
        connexusTestScripts.initializeTestCase(flagUpdated);

        //Create a new patient
        connexusTestScripts.createNewPatient(inputData);

        //Complete DropOff
        connexusTestScripts.performDropOff(Priority.Critical);

        //Complete Input
        connexusTestScripts.performInput(inputData);

        //Complete 4Point, Controlled Drug - true
        connexusTestScripts.perform4Point(true);

        //Complete Filling
        connexusTestScripts.performFilling();

        //Complete Visual Verify
        connexusTestScripts.performVisualVerify();

        //Complete PickUp
        connexusTestScripts.performPickUp(inputData);

        //Complete Counselling
        connexusTestScripts.performCounselling();

        //Perform POS - Offline Sale
        connexusTestScripts.performPOS();

        //Verify Rx is in EOD Queue
        connexusTestScripts.verifyRxInEOD();

        Reporter.log("=== RX Work queue status should be EOD ===");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: E2E_TP_Flow_Controlled_Drug
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-42")
    @Test(enabled = true, description = "E2E_TP_Flow_Controlled_Drug",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/E2E/E2EDataBook.json", sheetName = "E2E")
    public void HWPHME2E_42_E2E_TP_Flow_Controlled_Drug(Map<String, String> inputData) {
        Reporter.log("=== Validating E2E TP flow for controlled drug ===");
        connexusAppUtils.writeTextToFile("HWPHME2E_42_E2E_TP_Flow_Controlled_Drug",null,fileName,0, DateTime.now());

        flagsCheckUp();

        //initialize the test case
        connexusTestScripts.initializeTestCase(flagUpdated);

        //Create a new patient, with 1 TP plan
        connexusTestScripts.createNewPatient(inputData,1);

        //Complete DropOff
        connexusTestScripts.performDropOff(Priority.Critical);

        //Complete Input
        connexusTestScripts.performInput(inputData);

        //Complete 4Point, Controlled Drug - true
        connexusTestScripts.perform4PointForTPPatient(true);

        //Complete Filling
        connexusTestScripts.performFilling();

        //Complete Visual Verify
        connexusTestScripts.performVisualVerify();

        //Complete PickUp
        connexusTestScripts.performPickUp(inputData);
        //Complete Counselling
        connexusTestScripts.performCounselling();

        //Perform POS - Offline Sale
        connexusTestScripts.performPOS();

        //Verify Rx is in EOD Queue
        connexusTestScripts.verifyRxInEOD();

        Reporter.log("=== RX Work queue status should be EOD ===");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Drop a refill for an RX which has zero refills
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-292")
    @Test(enabled = true, description = "Drop a refill for an RX which has zero refills",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/E2E/E2EDataBook.json", sheetName = "E2E")
    public void HWPHME2E_292_E2E_Drop_A_Refill_For_RX_With_Zero_Number_Refills(Map<String, String> inputData) {
        Reporter.log("=== Validating drop a refill for an RX which has zero refills ===");
        connexusAppUtils.writeTextToFile("HWPHME2E_292_E2E_Drop_A_Refill_For_RX_With_Zero_Number_Refills",null,fileName,0, DateTime.now());

        flagsCheckUp();

        //initialize the test case
        connexusTestScripts.initializeTestCase(flagUpdated);

        //Create a new patient
        connexusTestScripts.createNewPatient(inputData);

        //Complete DropOff
        connexusTestScripts.performDropOff(Priority.Critical);

        //Complete Input
        connexusTestScripts.performInput(inputData);

        //Complete 4Point, Controller Drug - false
        connexusTestScripts.perform4Point(false);

        //Complete Filling
        connexusTestScripts.performFilling();

        //Complete Visual Verify
        connexusTestScripts.performVisualVerify();

        //Complete PickUp
        connexusTestScripts.performPickUp(inputData);

        //Complete Counselling
        connexusTestScripts.performCounselling();

        //Perform POS - Offline Sale
        connexusTestScripts.performPOS();

        //Verify Rx is in EOD Queue
        connexusTestScripts.verifyRxInEOD();

        //Perform DropOff for an RX which has no Refills
        connexusTestScripts.performDropOffForRXWithNoRefills();

        //Verify whether RX moved toResolution queue due to zero refills
        connexusTestScripts.verifyIfRxIsInResolutionQueue();

        Reporter.log("=== RX Work queue status should be in Resolution ===");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Drop a refill for an RX which has few refills
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-270")
    @Test(enabled = true, description = "Drop a refill for an RX which has few refills",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/E2E/E2EDataBook.json", sheetName = "E2E")
    public void HWPHME2E_270_E2E_Drop_A_Refill_For_RX_With_Few_Refills(Map<String, String> inputData) {
        Reporter.log("=== Validating drop a refill for an RX which has few refills ===");
        connexusAppUtils.writeTextToFile("HWPHME2E_270_E2E_Drop_A_Refill_For_RX_With_Few_Refills",null,fileName,0, DateTime.now());

        flagsCheckUp();

        //initialize the test case
        connexusTestScripts.initializeTestCase(flagUpdated);

        //Create a new patient
        connexusTestScripts.createNewPatient(inputData);

        //Complete DropOff
        connexusTestScripts.performDropOff(Priority.Critical);

        //Complete Input
        connexusTestScripts.performInput(inputData);

        //Complete 4Point, Controlled Drug - false
        connexusTestScripts.perform4Point(false);

        //Complete Filling
        connexusTestScripts.performFilling();

        //Complete Visual Verify
        connexusTestScripts.performVisualVerify();

        //Complete PickUp
        connexusTestScripts.performPickUp(inputData);

        //Complete Counselling
        connexusTestScripts.performCounselling();

        //Perform POS - Offline Sale
        connexusTestScripts.performPOS();

        //Verify Rx is in EOD Queue
        connexusTestScripts.verifyRxInEOD();

        //Perform DropOff for an RX which has Refills
        connexusTestScripts.performDropOffForRXWithRefills();

        //Complete Filling
        connexusTestScripts.performFilling();

        //Complete Visual Verify
        connexusTestScripts.performVisualVerify();

        //Complete PickUp
        connexusTestScripts.performPickUp(inputData);

        //Perform POS - Offline Sale
        connexusTestScripts.performPOS();

        Reporter.log("=== RX Work queue status should be in EOD ===");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: E2E_Switch to TP from CASH in Filling
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-291")
    @Test(enabled = true, description = "E2E_Switch to TP from CASH in Filling",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/E2E/E2EDataBook.json", sheetName = "E2E")
    public void HWPHME2E_291_E2E_Switch_to_TP_From_CASH_in_Filling(Map<String, String> inputData) {
        Reporter.log("=== Validating E2E flow by switching to TP from CASH in Filling ===");
        connexusAppUtils.writeTextToFile("HWPHME2E_291_E2E_Switch_to_TP_From_CASH_in_Filling",null,fileName,0, DateTime.now());

        flagsCheckUp();

        //initialize the test case
        connexusTestScripts.initializeTestCase(flagUpdated);

        //Create a new patient, with 1 TP plan
        connexusTestScripts.createNewPatient(inputData,1);

        //Change payment method on Patient profile from CASH to TP
        connexusTestScripts.changePaymentFromTPtoCASHForAPatient();

        //Complete DropOff
        connexusTestScripts.performDropOff(Priority.Critical);

        //Complete Input
        connexusTestScripts.performInput(inputData);

        //Complete 4Point, Controller Drug - false
        connexusTestScripts.perform4Point(false);

        //Complete chkDUR
        connexusTestScripts.performChkDUR();

        //Switch to CASH from TP plan in Filling queue
        connexusTestScripts.switchToTPFromCASH(inputData);

        //Complete Filling
        connexusTestScripts.performFilling();

        //Complete Visual Verify
        connexusTestScripts.performVisualVerify();

        //Complete PickUp
        connexusTestScripts.performPickUp(inputData);

        //Complete Counselling
        connexusTestScripts.performCounselling();

        //Perform POS - Offline Sale
        connexusTestScripts.performPOS();

        //Verify Rx is in EOD Queue
        connexusTestScripts.verifyRxInEOD();

        Reporter.log("=== RX Work queue status should be in EOD ===");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: E2E_Switch to CASH from TP in Filling
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-293")
    @Test(enabled = true, description = "E2E_Switch to CASH from TP in Filling",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/E2E/E2EDataBook.json", sheetName = "E2E")
    public void HWPHME2E_293_E2E_Switch_to_CASH_From_TP_in_Filling(Map<String, String> inputData) {
        Reporter.log("=== Validating E2E flow by switching to CASH from TP in Filling ===");
        connexusAppUtils.writeTextToFile("HWPHME2E_293_E2E_Switch_to_CASH_From_TP_in_Filling",null,fileName,0, DateTime.now());

        flagsCheckUp();

        //initialize the test case
        connexusTestScripts.initializeTestCase(flagUpdated);

        //Create a new patient with 1 TP plan
        connexusTestScripts.createNewPatient(inputData,1);

        //Complete DropOff
        connexusTestScripts.performDropOff(Priority.Critical);

        //Complete Input
        connexusTestScripts.performInput(inputData);

        //Complete 4Point, Controller Drug - false
        connexusTestScripts.perform4PointForTPPatient(false);

        //Complete chkDUR
        connexusTestScripts.performChkDUR();

        //Switch to CASH from TP plan in Filling queue
        connexusTestScripts.switchToCASHFromTP();

        //Complete Filling
        connexusTestScripts.performFilling();

        //Complete Visual Verify
        connexusTestScripts.performVisualVerify();

        //Complete PickUp
        connexusTestScripts.performPickUp(inputData);

        //Complete Counselling
        connexusTestScripts.performCounselling();

        //Perform POS - Offline Sale
        connexusTestScripts.performPOS();

        //Verify Rx is in EOD Queue
        connexusTestScripts.verifyRxInEOD();

        Reporter.log("=== RX Work queue status should be in EOD ===");
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: E2E_Switch to another TP plan at 4 Point and take to EOD
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-294")
    @Test(enabled = true, description = "E2E_Switch to another TP plan at 4 Point and take to EOD",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/E2E/E2EDataBook.json", sheetName = "E2E")
    public void HWPHME2E_294_E2E_Switch_To_Another_TP_in_4Point(Map<String, String> inputData) {
        Reporter.log("=== Validating E2E flow by switching one TP to another TP in 4 point ===");
        connexusAppUtils.writeTextToFile("HWPHME2E_294_E2E_Switch_To_Another_TP_in_4Point",null,fileName,0, DateTime.now());

        flagsCheckUp();

        //initialize the test case
        connexusTestScripts.initializeTestCase(flagUpdated);

        //Create a new patient with 2 TP plan
        connexusTestScripts.createNewPatient(inputData,2);

        //Complete DropOff
        connexusTestScripts.performDropOff(Priority.Critical);

        //Complete Input
        connexusTestScripts.performInput(inputData);

        //Change the TP Plan in 4 Point
        connexusTestScripts.changeTPPlanIn4Point(inputData);

        //Complete 4Point, Controller Drug - false
        connexusTestScripts.perform4PointForTPPatient(false);

        //Complete Filling
        connexusTestScripts.performFilling();

        //Complete Visual Verify
        connexusTestScripts.performVisualVerify();

        //Complete PickUp
        connexusTestScripts.performPickUp(inputData);

        //Complete Counselling
        connexusTestScripts.performCounselling();

        //Perform POS - Offline Sale
        connexusTestScripts.performPOS();

        //Verify Rx is in EOD Queue
        connexusTestScripts.verifyRxInEOD();

        Reporter.log("=== RX Work queue status should be in EOD ===");
    }
}