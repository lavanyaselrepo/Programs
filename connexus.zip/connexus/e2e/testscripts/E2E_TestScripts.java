package connexus.e2e.testscripts;

import com.aventstack.extentreports.Status;
import connexus.OrderCreation.PayloadResource;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexusharnessapicontext.apimanager.CacheServiceManager;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.WindowsBasePage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import io.strati.libs.joda.time.DateTime;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import static connexus.e2e.testcases.E2E_TestCases.loginUser_Type;

public class E2E_TestScripts {

    LoginPage loginPage;
    ConnexusStartPage connexusStartPage;
    PatientSearchPage patientSearchPage;
    TascoPage tascoPage;
    PatientMaintenancePage patientMaintenancePage;
    DropOffPage dropOffPage;
    F6Search orderSearch;
    FourPoint fourPoint;
    InputPage inputPage;
    RxLookUp rxLookUp;
    ModifyDetails modifyDetails;
    ConnexusAppUtils connexusAppUtils;
    AutomationManager automationManager;
    DropRxModel dropRxModel;
    RxModel rxModel;
    SoftAssert softAssert = new SoftAssert();
    PayloadResource payloadResource = new PayloadResource();
    String rxNbr = null;
    PatientProfileModel patient = new PatientProfileModel();
    AddressModel addressModel = new AddressModel();
    ContactModel contactModel = new ContactModel();
    PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
    ThirdPartyModel thirdPartyModel = new ThirdPartyModel();
    PropertyReader propertyReader = PropertyReader.getInstance();
    CacheServiceManager cacheManager = new CacheServiceManager();

    WindowsBasePage windowsBasePage;

    public void loginConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        loginPage = new LoginPage();
        connexusStartPage = new ConnexusStartPage();
        patientSearchPage = new PatientSearchPage();
        tascoPage = new TascoPage();
        patientMaintenancePage = new PatientMaintenancePage();
        dropOffPage = new DropOffPage();
        orderSearch = new F6Search();
        fourPoint = new FourPoint();
        inputPage = new InputPage();
        modifyDetails = new ModifyDetails();
        connexusAppUtils = new ConnexusAppUtils();
        dropRxModel = new DropRxModel();
        rxModel = new RxModel();
        rxLookUp = new RxLookUp();
        automationManager = AutomationManager.getInstance();
        loginPage.loginConnexus(userType);
    }

    /**
     * Performing drop off.
     *
     */
    public void performDropOff() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);
            connexusAppUtils.writeTextToFile("Dropoff Completed","In progress","E2E_execution_status.txt",20, DateTime.now());
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed at DropOff queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Dropoff Not completed","Failed","E2E_execution_status.txt",20, DateTime.now());
            loginConnexus(loginUser_Type);

        }
    }

    public void click4Point() {
        FourPoint fourPoint = new FourPoint();
        fourPoint.click4Point();
    }

    public void performModifyDrugAtAnyWorkqueue(String workqueue) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

                patientSearchPage.launchOrderSearchScreen();
                automationManager.performSleep(5);
                patientSearchPage.performSearch(rxNbr);
                automationManager.performSleep(5);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                modifyDetails.launchModifyDetailScreen();

                automationManager.performSleep(6);
                modifyDetails.enterProductNameInPrescribedProduct("50474091050");
                inputPage.clickAccept();
                try {
                    inputPage.clickYes();
                } catch (Exception e) {
                    Reporter.log("RTS lable not available");
                }
                inputPage.clickButtonOk();
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

                patientSearchPage.launchOrderSearchScreen();
                automationManager.performSleep(5);
                patientSearchPage.performSearch(rxNbr);
                automationManager.performSleep(5);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                modifyDetails.launchModifyDetailScreen();

                automationManager.performSleep(6);
                modifyDetails.enterProductNameInPrescribedProduct("50474091050");
                inputPage.clickAccept();
                try {
                    inputPage.clickYes();
                } catch (Exception e) {
                    Reporter.log("RTS lable not available");
                }
                inputPage.clickButtonOk();
            }
        } catch (Exception e) {
            Reporter.log("Test failed at ChkDUR queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void performNaloxoneDropOff() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().performNaloxoneDropRx(dropRxModel);
        } catch (Exception e) {
            Reporter.log("Test failed at DropOff queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    public void performIMZDropOff() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().performIMZDropOff(dropRxModel);
        } catch (Exception e) {
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.log("Test failed at DropOff queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Performing Input by providing all mandatory fields.
     *
     * */
    public void performInput(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxModel.setNdc(inputData.get("DRUG_NAME"));
            rxModel.setPrescribedQty(inputData.get("QUANTITY"));
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            String rxStatus = orderSearch.getRXStatusForPatient(name[0]+","+name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().performInput(rxModel);
            } else {
                Reporter.log("RX is not in Input queue");
                Assert.fail();
            }
            connexusAppUtils.writeTextToFile("Input Completed","In progress","E2E_execution_status.txt",30, DateTime.now());
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Input not Completed","Failed","E2E_execution_status.txt",30, DateTime.now());
            loginConnexus(loginUser_Type);
        }
    }

    public void perform4Point() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                for (int index = 0; index <= 4; index++) {
                    automationManager.performSleep(10);
                    int isOrderIn4point = checkOrderIn4pointAndNotDUR(rxNbr);
                    System.out.println("check order in 4 point"+isOrderIn4point);
                    if (isOrderIn4point > 0) {
                        break;
                    }
                }
                Reporter.log("RX in TP flow");
            }
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(name[0] + "," + name[1]);
            }
            rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);
            connexusAppUtils.writeTextToFile("Completed 4 point and the RX number is "+rxNbr,"In progress","E2E_execution_status.txt",40, DateTime.now());
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            connexusAppUtils.writeTextToFile("4 point Not Completed","Failed","E2E_execution_status.txt",40, DateTime.now());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(loginUser_Type);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*
     * Performing 4 Point by Checking all the details.
     *
     * */
    public void perform4PointForTPPatient() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            F6Search rxSearch = new F6Search();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            rxNbr = rxSearch.getRxNbr(0);
            rxSearch.closeSearch();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                for (int index = 0; index <= 4; index++) {
                    automationManager.performSleep(10);
                     int isOrderIn4point = checkOrderIn4pointAndNotDUR(rxNbr);
                    System.out.println("check order in 4 point"+isOrderIn4point);
                    if (isOrderIn4point > 0) {
                        break;
                    }
                }
                Reporter.log("RX in TP flow");
            }
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(name[0] + "," + name[1]);
                automationManager.performSleep(2);
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Patient created with TP details, so it should not move to Resolve queue");
                Assert.fail("Patient created with TP details, so it should not move to Resolve queue");
                automationManager.performSleep(2);
                orderSearch.closeSearch();
            }
            rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);
            connexusAppUtils.writeTextToFile("Completed 4 point and the RX number is "+rxNbr,"In progress","E2E_execution_status.txt",40, DateTime.now());
        } catch (Throwable e) {
            e.printStackTrace();
            connexusAppUtils.writeTextToFile("4 point Not Completed","Failed","E2E_execution_status.txt",40, DateTime.now());
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

        }
    }

    public void performDouble4Point() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            automationManager.getConnexusWorkFlow().performDoubleFourPoint(name[0] + "," + name[1]);
        } catch (Exception e) {
            Reporter.log("Test failed at 4 Point queue");

            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

        }
    }

    public void workQueue() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        F6Search rxSearch = new F6Search();
        boolean isInQueue = false;
        try {
            String[] name =  connexusAppUtils.readPatientNameFromFile();
            orderSearch.openSearch();
            orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            for (int i = 0; i < 4; i++) {
                if (rxSearch.getWorkQueue(0).replace(" ", "").equalsIgnoreCase(WorkQueue.EOD.getWorkQueue())) {
                    isInQueue = true;
                    break;
                } else {
                    Assert.fail("Rx not in 4point");
                }
            }
            rxSearch.closeSearch();
        } catch (Exception e) {
            Reporter.log("Test failed rx not in 4point");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }


    public void perform4PointForControlledDrug() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                for (int index = 0; index <= 4; index++) {
                    automationManager.performSleep(10);
                    int isOrderIn4point = checkOrderIn4pointAndNotDUR(rxNbr);
                    System.out.println("check order in 4 point"+isOrderIn4point);
                    if (isOrderIn4point > 0) {
                        break;
                    }
                }
                Reporter.log("RX in TP flow");
            }
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(name[0] + "," + name[1]);
            }
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            String productName = orderSearch.getProductName(0);
            orderSearch.closeSearch();
            rxNbr = automationManager.getConnexusWorkFlow().performFourPointForControlledDrug(name[0] + "," + name[1], productName);
            connexusAppUtils.writeTextToFile("4 point Completed "+rxNbr,"In progress","E2E_execution_status.txt",40, DateTime.now());
        } catch (Throwable e) {
            connexusAppUtils.writeTextToFile("4 point not Completed "+rxNbr,"Failed","E2E_execution_status.txt",40, DateTime.now());
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(loginUser_Type);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void perform4PointForControlledDrugForTPPatient() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                for (int index = 0; index <= 4; index++) {
                    automationManager.performSleep(10);
                    int isOrderIn4point = checkOrderIn4pointAndNotDUR(rxNbr);
                    System.out.println("check order in 4 point"+isOrderIn4point);
                    if (isOrderIn4point > 0) {
                        break;
                    }
                }
                Reporter.log("RX in TP flow");
            }
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(name[0] + "," + name[1]);
                automationManager.performSleep(2);
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Patient created with TP details, so it should not move to Resolve queue");
                Assert.fail("Patient created with TP details, so it should not move to Resolve queue");
                automationManager.performSleep(2);
                orderSearch.closeSearch();
            }
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            String productName = orderSearch.getProductName(0);
            orderSearch.closeSearch();
            rxNbr = automationManager.getConnexusWorkFlow().performFourPointForControlledDrug(name[0] + "," + name[1], productName);
            connexusAppUtils.writeTextToFile("4 point Completed "+rxNbr,"In progress","E2E_execution_status.txt",40, DateTime.now());
        } catch (Throwable e) {
            connexusAppUtils.writeTextToFile("4 point not Completed "+rxNbr,"Failed","E2E_execution_status.txt",40, DateTime.now());
            Reporter.log("Test failed at 4 Point queue");
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performChkDUR() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }
        } catch (Exception e) {
            Reporter.log("Test failed at ChkDUR queue");
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void performFillingForRow(int index) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {

            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,index);
            System.out.println("Rx status" + rxStatus);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,index);
            if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
                Reporter.log("RX is in Resolve queue");
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                Reporter.log("RX is in CASH queue");
                automationManager.performSleep(5);
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            }
        } catch (Exception e) {
            Reporter.log("Test failed at Filling queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Performing Checkdur and Filling by providing all the fields.
     *
     * */
    public void performFilling() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            System.out.println("Rx status" + rxStatus);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
                connexusAppUtils.writeTextToFile("Completed ChkDUR "+rxNbr,"In progress","E2E_execution_status.txt",50, DateTime.now());
            }
            automationManager.performSleep(30);
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                automationManager.performSleep(45);
                Reporter.log("RX is in CASH queue");
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
                {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            }else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
                Reporter.log("RX is in Resolve queue");
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            }
            connexusAppUtils.writeTextToFile("Filling Completed "+rxNbr,"In progress","E2E_execution_status.txt",60, DateTime.now());
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Filling notCompleted "+rxNbr,"Failed","E2E_execution_status.txt",60, DateTime.now());
            Reporter.log("Test failed at Filling queue");
            loginConnexus(loginUser_Type);
        }
    }
    public void performPartialFilling() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatus(rxNbr);
            System.out.println("Rx status" + rxStatus);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

            } rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                Reporter.log("RX is in CASH queue");
                automationManager.performSleep(15);
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
                {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                automationManager.getConnexusWorkFlow().completePartialFilling(rxNbr);
            }else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                automationManager.getConnexusWorkFlow().completePartialFilling(rxNbr);
                Reporter.log("RX is in Resolve queue");
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completePartialFilling(rxNbr);
            }
        } catch (Exception e) {
            Reporter.log("Test failed at Filling queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performVisualVerify() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
            } else {
                Reporter.log("RX is not in Visual Verify queue");
                Assert.fail("RX is not in Visual Verify queue");
            }
            connexusAppUtils.writeTextToFile("Visual Verification Completed "+rxNbr,"In progress","E2E_execution_status.txt",70, DateTime.now());
        } catch (Throwable e) {
            connexusAppUtils.writeTextToFile("Visual Verification Not Completed "+rxNbr,"Failed","E2E_execution_status.txt",70, DateTime.now());
            Reporter.log("Test failed at Visual Verify queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(loginUser_Type);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void performPickUp(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("DOB"), rxNbr);
            } else {
                Reporter.log("RX is not in PickUp queue");
                Assert.fail("RX is not in PickUp queue");
            }
            connexusAppUtils.writeTextToFile("Pickup Completed "+rxNbr,"In progress","E2E_execution_status.txt",80, DateTime.now());
        } catch (Throwable e) {
            connexusAppUtils.writeTextToFile("Pickup not Completed "+rxNbr,"Failed","E2E_execution_status.txt",80, DateTime.now());
            Reporter.log("Test failed at PickUp queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(loginUser_Type);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void performCounselling() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);

            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.COUNSEL.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeCounsel(rxNbr);
            } else {
                Reporter.log("RX is not in Counselling queue");
                Assert.fail();
            }
            connexusAppUtils.writeTextToFile("Counselling Completed "+rxNbr,"In progress","E2E_execution_status.txt",90, DateTime.now());
        } catch (Throwable e) {
            connexusAppUtils.writeTextToFile("Counselling Not Completed "+rxNbr,"Failed","E2E_execution_status.txt",90, DateTime.now());
            Reporter.log("Test failed at Counselling queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(loginUser_Type);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void performPOS() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.POS.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeOfflineSale(rxNbr);
            } else {
                Reporter.log("RX is not in POS queue");
                Assert.fail("RX is not in POS queue");
            }
            connexusAppUtils.writeTextToFile("POS Completed "+rxNbr,"Passed","E2E_execution_status.txt",100, DateTime.now());
        } catch (Throwable e) {
            connexusAppUtils.writeTextToFile("POS Not Completed "+rxNbr,"Failed","E2E_execution_status.txt",100, DateTime.now());
            Reporter.log("Test failed at POS queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(loginUser_Type);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyRxInEOD() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.EOD.getWorkQueue())) {
                Assert.assertTrue(true);
                Reporter.log("RX is in EOD queue");
            } else {
                Reporter.log("RX is not in EOD queue");
                Assert.fail("RX is not in EOD queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at EOD queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(loginUser_Type);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void performRxComments() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatus(rxNbr);
            if (rxStatus.equalsIgnoreCase(WorkQueue.EOD.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().enterRxComments("rxnotes", "pharmacynotes", "counselingnotes");
            } else {
                Reporter.log("RX is not in EOD rx comments");
                Assert.fail("RX is not in EOD rx comments");
            }
        } catch (Exception e) {
            Reporter.log("Test failed at EOD rx comments");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }

    /*
     * Create New patient without providing TP details.
     *
     * */
    public void createNewPatient(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);

            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            System.out.println("" + name[1] + " " + name[0]);
            connexusAppUtils.writeTextToFile("Started E2E cash flow","Started","E2E_execution_status.txt",0,null );
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            patient.setPatientTp(thirdPartyModel);
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);
            if (connexusStartPage.isConnexusLaunched()) {
                automationManager.getConnexusWorkFlow().createNewPatient(false, patient);
                Reporter.log("Patient has been created.");
            } else {
                softAssert.fail("Connexus not launched");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertAll();
            }
            connexusAppUtils.writeTextToFile("Created Patient  With "+ name[1] + " " + name[0],"In progress","E2E_execution_status.txt",10, DateTime.now());
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Create Patient","Failed","E2E_execution_status.txt",10, DateTime.now());
            loginConnexus(loginUser_Type);
        }
    }

    /*
     * Create new patient with TP details.
     *
     * */
    public void createNewPatientWithTP(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusAppUtils.addBlankLine("E2E_execution_status.txt");
            connexusAppUtils.writeTextToFile("Started E2E TP flow","Started","E2E_execution_status.txt",0,null );
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            thirdPartyModel.setCarrierBin(inputData.get("TP_CARRIER_BIN"));
            thirdPartyModel.setPlan(inputData.get("TP_PLAN"));
            thirdPartyModel.setCardId(inputData.get("TP_CARD_ID"));
            patient.setPatientTp(thirdPartyModel);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            patientMaintenancePage.sendHotKeys(Keys.TAB);
            if (patientMaintenancePage.isOkDisplayed()) {
                patientMaintenancePage.clickOk();
            }
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);

            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            automationManager.getConnexusWorkFlow().createNewPatient(true, patient);

            Reporter.log("Patient has been created.");
            connexusAppUtils.writeTextToFile("Created Patient  "+ name[1] + " " + name[0],"In progress","E2E_execution_status.txt",10, DateTime.now());
        } catch (Throwable e) {
            e.printStackTrace();
            connexusAppUtils.writeTextToFile("Create Patient","Failed","E2E_execution_status.txt",10, DateTime.now());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Patient not created");
            loginConnexus(loginUser_Type);

        }
    }

    public void createNewPatientWith2TPPlans(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            thirdPartyModel.setCarrierBin(inputData.get("TP_CARRIER_BIN"));
            thirdPartyModel.setPlan(inputData.get("TP_PLAN"));
            thirdPartyModel.setCardId(inputData.get("TP_CARD_ID"));
            thirdPartyModel.setCarrierBin2(inputData.get("TP_CARRIER_BIN_2"));
            thirdPartyModel.setPlan2(inputData.get("TP_PLAN_2"));
            thirdPartyModel.setCardId2(inputData.get("TP_CARD_ID_2"));
            patient.setPatientTp(thirdPartyModel);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            patientMaintenancePage.sendHotKeys(Keys.TAB);
            if (patientMaintenancePage.isOkDisplayed()) {
                patientMaintenancePage.clickOk();
            }
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);

            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            automationManager.getConnexusWorkFlow().createNewPatient(true, patient);

            Reporter.log("Patient has been created.");
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(loginUser_Type);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void performDropOffForARXWithNoRefills() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(10);
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickOKonRefillRequestPopUp();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickSendToResolutionOnFaxSendPopUp();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickYesOnFaxNumberPopUp();
            dropOffPage.selectPriority("Critical");
            dropOffPage.clickBtnAccept();
            dropOffPage.handleStorePickupTimePopup();
            Reporter.log("Drop-Off completed");
        } catch (Throwable e) {
           e.printStackTrace();
        }
    }

    public void performDropOffForRXWithRefills() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(10);
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            dropOffPage.checkAndClickDropOffStation();
            dropOffPage.selectPriority("Critical");
            dropOffPage.clickBtnAccept();
            dropOffPage.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed");
        } catch (Throwable e) {
           e.printStackTrace();
        }
    }

    public void verifyIfRxIsInResolutionQueue() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            Assert.assertEquals(orderSearch.getWorkQueue(0).toLowerCase(), WorkQueue.RESOLVE.getWorkQueue());
            Assert.assertEquals(orderSearch.getProblemMessage(0), "Need to Call Doctor for Refills");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            orderSearch.closeSearch();
            Reporter.log("RX is in Resolution Queue");
        } catch (Throwable e) {
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void switchToCASHFromTP() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(10);
                modifyDetails.selectClaimsDropDown();
                automationManager.performSleep(5);
                Robot robot = new Robot();
                robot.keyPress(KeyEvent.VK_UP);
                robot.keyRelease(KeyEvent.VK_UP);
                robot.keyPress(KeyEvent.VK_ENTER);
                robot.keyRelease(KeyEvent.VK_ENTER);
                modifyDetails.clickAccept();
                automationManager.performSleep(5);
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_ENTER);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.OkWarningClick();
                automationManager.performSleep(10);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being reprocessed");
                modifyDetails.checkAndClickWarning();
            } else {
                Reporter.log("RX is not in Visual verify queue");
                Assert.fail("RX is not in Visual verify queue");
            }
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(loginUser_Type);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void switchToTPFromCASH(String TP) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatus(rxNbr);
            if (rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())) {
                orderSearch.performSearch(rxNbr, SearchType.PatientRx);
                orderSearch.selectRowFromSearch(0);
                automationManager.performSleep(5);
                modifyDetails.selectClaimsDropDown();
                modifyDetails.click2ndOption(TP);
                modifyDetails.clickAccept();
                modifyDetails.OkWarningClick();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                automationManager.performSleep(5);
                modifyDetails.selectReasonForSwitchToCash();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                automationManager.performSleep(5);
                softAssert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being reprocessed");
                modifyDetails.checkAndClickWarning();
            } else {
                Reporter.log("RX is not in Visual verify queue");
                Assert.fail("RX is not in Visual verify queue");
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void switchToTPFromTP(Map<String, String> inputData, WorkQueue workQueue) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatus(rxNbr);
            if (rxStatus.equalsIgnoreCase(workQueue.getWorkQueue())) {
                orderSearch.performSearch(rxNbr, SearchType.PatientRx);
                orderSearch.selectRowFromSearch(0);
                automationManager.performSleep(5);
                modifyDetails.selectClaimsDropDown();
                String planName = inputData.get("TP_CARRIER_BIN") + " / " + inputData.get("TP_PLAN") + " / " + inputData.get("TP_CARD_ID");
                System.out.println("Plan name " + planName);
                modifyDetails.switchToInsurance(planName);
                modifyDetails.clickAccept();
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.selectReasonForSwitchToCash();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                automationManager.performSleep(5);
                softAssert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being sent to the \n" + "Third Party queue.");
                modifyDetails.checkAndClickWarning();
            } else {
                Reporter.log("RX is not in Filling queue");
                Assert.fail("RX is not in Filling queue");
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void switchToTPFromCASH(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(name[0] + "," + name[1]);
            }
            automationManager.performSleep(30);
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                automationManager.performSleep(45);
                Reporter.log("RX is in CASH queue");
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue()) || (rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue() ))) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(10);
                modifyDetails.selectClaimsDropDown();
                String planName = inputData.get("TP_CARRIER_BIN") + " / " + inputData.get("TP_PLAN") + " / " + inputData.get("TP_CARD_ID");
                modifyDetails.switchToInsurance(planName);
                automationManager.performSleep(10);
                modifyDetails.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                automationManager.performSleep(10);
                softAssert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being sent to the \n" + "Third Party queue.");
                modifyDetails.clickOnConnexusPopUp();
                modifyDetails.checkAndClickWarning();
            } else {
                Reporter.log("RX is not in Filling queue");
                Assert.fail("RX is not in Filling queue");
            }
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(loginUser_Type);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void changeTPPlanIn4Point(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.DUR.getWorkQueue())) {
                automationManager.performSleep(15);
            }
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                for (int index = 0; index <= 4; index++) {
                    automationManager.performSleep(10);
                    int isOrderIn4point = checkOrderIn4pointAndNotDUR(rxNbr);
                    System.out.println("check order in 4 point"+isOrderIn4point);
                    if (isOrderIn4point > 0) {
                        break;
                    }
                }
                Reporter.log("RX in TP flow");
            }
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(name[0] + "," + name[1]);
            }
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.FOUR_POINT.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(name[0] + "," + name[1]);
                patientSearchPage.openFirstPatientRecord();
                modifyDetails.launchModifyDetailScreen();
                automationManager.performSleep(10);
                modifyDetails.selectClaimsDropDown();
                String planName = inputData.get("TP_CARRIER_BIN") + " / " + inputData.get("TP_PLAN") + " / " + inputData.get("TP_CARD_ID");
                automationManager.performSleep(5);
                modifyDetails.switchToInsurance(planName);
                automationManager.performSleep(5);
                modifyDetails.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertEquals(modifyDetails.getTextFromPopUp(), "Because of changes made to this fill, it is being sent to the \n" + "Third Party queue.");
                automationManager.performSleep(10);
                modifyDetails.clickOnConnexusPopUp();
                modifyDetails.checkAndClickWarning();
            } else {
                Reporter.log("RX is not in 4 Point queue");
                Assert.fail("RX is not in 4 Point queue");
            }
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(loginUser_Type);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void getNoOfRxNotes() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        PropertyReader propertyReader = PropertyReader.getInstance();
        int panes = 0;
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try {
            patientSearchPage.patientSearchShotCutKeys();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRow(0);
            patientMaintenancePage.clickNotesButton();
            panes = patientMaintenancePage.getSiteIdsCount().size();
            for (int i = 0; i <= panes - 1; i++) {

                String siteId = patientMaintenancePage.getSiteIdsCount().get(i).getAttribute("Value.Value");

                if (siteId.equalsIgnoreCase(PropertyReader.getInstance().getProperty("cnx.store"))) {
                    System.out.println("ok");
                } else {
                    Assert.assertFalse(false, "SiteId not matched");
                }
            }
            String conNotes = "";
            for (int j = 0; j <= patientMaintenancePage.getNotesCount().size() - 1; j++) {
                String notes = patientMaintenancePage.getNotesCount().get(j).getAttribute("Value.Value");
                conNotes = conNotes + notes;
            }
            String consolidatedNotes = conNotes.toLowerCase().trim();
            if (consolidatedNotes.contains("rxnotes".toLowerCase()) && consolidatedNotes.contains("pharmacynotes".toLowerCase())
                    && consolidatedNotes.contains("counselingnotes".toLowerCase())) {

            } else {
                Assert.assertFalse(false, "Notes not matched");
            }
            patientMaintenancePage.closeNotes();
            patientMaintenancePage.clickExit();
        } catch (Exception e) {
            System.out.println(e.getLocalizedMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }

    }
    public void verifyRxNotes(String Notes) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            patientSearchPage.launchPatientSearchScreen();

            if (patientSearchPage.isPatientSearchWindowDisplayed()) {
                patientSearchPage.inputPatientName(patientName);
                patientSearchPage.clickSearchNow();
                patientSearchPage.selectRowFromSearch(0);
            }

            int counter = 0;
            while (patientMaintenancePage.isGeneralInformationTabDisplayed() && counter <= 3) {
                patientMaintenancePage.switchWindow();
                counter++;
            }

            patientMaintenancePage.clickSaveAndClose();
            patientMaintenancePage.switchWindow();

            patientMaintenancePage.clickNotesButton();
            automationManager.performSleep(5);
            String conNotes = "";
            for (int j = 0; j <= patientMaintenancePage.getNotesCount().size() - 1; j++) {
                String notes = patientMaintenancePage.getNotesCount().get(j).getAttribute("Value.Value");
                conNotes = conNotes + notes;
            }
            String consolidatedNotes = conNotes.toLowerCase().trim();
            Reporter.logScreenShot(currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (consolidatedNotes.contains(Notes.toLowerCase())) {
                Reporter.log("Notes matched");
            } else {
                Reporter.log("Notes matched");
                Assert.assertFalse(false, "Notes not matched");
            }
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();
        } catch (Exception e) {
            Reporter.log(e.getLocalizedMessage());
            Reporter.logScreenShot(currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void verifyIMZModufyDetails() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        automationManager.performSleep(5);
        patientSearchPage.launchOrderSearchScreen();
        automationManager.performSleep(5);
        patientSearchPage.performSearch(name[0] + "," + name[1]);
        automationManager.performSleep(5);
        patientSearchPage.openFirstPatientRecord();
        automationManager.performSleep(5);
        if (fourPoint.overDose()) {
            fourPoint.clickOverDoseButton();
        }
        //fourPoint.sendHotKeys(Keys.F9);
        modifyDetails.launchModifyDetailScreen();
        automationManager.performSleep(2);
        if (modifyDetails.isPrescribedPdtEnabled()) {
            Assert.fail("Prescribed Product field enabled");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
        if (modifyDetails.isDispensedQntyEnabled()) {
            Assert.fail("Dispensed Quantity field enabled");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
        if (modifyDetails.isRefillAuthEnabled()) {
            Assert.fail("Refill Auth field enabled");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
        modifyDetails.clickCancel();
        modifyDetails.clickYes();
        modifyDetails.clickCancel();

    }

    public void verifyThirdPartyDaysSupplyField(String stagedRxNbr, WorkQueue workQueue, Boolean verifyCase, String enable) {
        automationManager.performSleep(5);
        patientSearchPage.launchOrderSearchScreen();
        automationManager.performSleep(5);
        patientSearchPage.performSearch(stagedRxNbr);
        automationManager.performSleep(3);
        orderSearch.selectRowFromSearchRX();
        automationManager.performSleep(6);
        modifyDetails.launchtpExtraInfo();
        automationManager.performSleep(3);
        System.out.println(modifyDetails.isThirdPartyDaysSupply());
        if (modifyDetails.isThirdPartyDaysSupply() == verifyCase) {
            Assert.assertTrue(true, "ThirdPartyDaysSupply" + enable);
            modifyDetails.clickCancel();
        } else {
            Assert.fail("ThirdPartyDaysSupply " + enable);
        }

    }

    public void verifyTPDaysSupplyValue(String TPDaaysSuppy, Boolean value, String matchValue) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        modifyDetails.enterTPDaysSupply(TPDaaysSuppy);
        modifyDetails.clickAccept();
        ResolutionTPRejPage resolutionTPRejPage = new ResolutionTPRejPage();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        if (TPDaaysSuppy.equalsIgnoreCase(verifyTPDaySupplyValue(rxNbr))) {
            Assert.assertTrue(value, "TPDaysSupply" + matchValue);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            resolutionTPRejPage.clickClose();
        } else {
            Assert.fail("TPDaysSupply " + matchValue);
        }

    }

    public void verifyTPDaysSupplyValueWithValue(String stagedRxNbr,String TPDaaysSuppy, Boolean value, String matchValue) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(stagedRxNbr);
        patientSearchPage.openFirstPatientRecord();
        TPExtraInfoPage tpExtraInfoPage = new TPExtraInfoPage();
        ResolutionTPRejPage resolutionTPRejPage = new ResolutionTPRejPage();
        tpExtraInfoPage.openTPExtraInfo();
        tpExtraInfoPage.enterTPDaySupply(TPDaaysSuppy);
        System.out.println("Enetered" + TPDaaysSuppy);
        tpExtraInfoPage.clickAcceptBtn();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
        modifyDetails.clickAccept();
        automationManager.performSleep(3);
        String rx_ID = automationManager.getConnexusDB().getScalar("select rx_id from rx where rx_nbr =" +stagedRxNbr, String.class);
        String rx_fill_id =automationManager.getConnexusDB().getScalar("select rx_fill_id from rx_fill where rx_id =" +rx_ID, String.class);

        String addition_val =automationManager.getConnexusDB().getScalar("SELECT addition_val from clm_override_addtn WHERE rx_fill_id=" + rx_fill_id + "AND addtn_class_code = 23232", String.class);
        Assert.assertEquals(addition_val,TPDaaysSuppy);
        Reporter.log("Value matched");
        resolutionTPRejPage.clickClose();
    }

    public String verifyTPDaySupplyValue(String rxnbr) {
        ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
        String value = "";
        value = connexusAppUtils.fetchTPFillDetails(rxnbr, "rx_fill_id", false);
        return value;
    }

    /*public void getFillId() {
        String query = "select max(rx_fill_id) as rx_fill_id  from  rx_order_detail where rx_id =(select rx_id from rx where rx_nbr=\"" + rxNbr + "\") and next_work_que_code ='6'";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        String fillId = rxInfo.get("rx_fill_id").toString();
        System.out.println(fillId);
        if(fillId.length()==8) {
            connexusAppUtils.readAndUpdateFlag("26218", "TRUE");
            connexusAppUtils.readAndUpdateFlag("5300", "UPC");
            String siteId = propertyReader.getProperty("cnx.store");
            cacheManager.callFlushCacheAPI(siteId);
        }
    }*/

    public String verifyTPDaySupplyValueWithValue(String rxnbr) {
        ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
        String value = "";
        value = connexusAppUtils.fetchTPFillDetailsWithValue(rxnbr, "addition_val",false);
        automationManager.performSleep(10);
        return value;
    }

    public void verifyDirectionOfUse(String rxNbrStr) {

        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbrStr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbrStr);
                patientSearchPage.launchOrderSearchScreen();
                automationManager.performSleep(5);
                patientSearchPage.performSearch(rxNbrStr);
                automationManager.performSleep(5);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                modifyDetails.launchModifyDetailScreen();
                modifyDetails.clearSigField();
                automationManager.performSleep(5);
                modifyDetails.enterSig1("TAD");
                modifyDetails.enterDaysSupply("15");
                automationManager.performSleep(5);
                System.out.println("entered sig and days");
                modifyDetails.clickAccept();
                automationManager.performSleep(2);
                if (modifyDetails.getDirectionUseText().equalsIgnoreCase("This prescription requires  specific directions for use. Please contact the prescriber to obtain detailed instructions, then annotate the prescription image.\n" +
                        "DirectionThis")) {

                    softAssert.assertTrue(true, "expected condition matched");
                }

            }

            else if(rxStatus.equalsIgnoreCase(WorkQueue.FOUR_POINT.getWorkQueue())){
                patientSearchPage.launchOrderSearchScreen();
                automationManager.performSleep(5);
                patientSearchPage.performSearch(rxNbrStr);
                automationManager.performSleep(5);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                modifyDetails.launchModifyDetailScreen();
                modifyDetails.clearSigField();
                modifyDetails.enterSig1("TAD");
                modifyDetails.enterDaysSupply("15");
                modifyDetails.clickAccept();
                automationManager.performSleep(2);
                if (modifyDetails.getDirectionUseText().equalsIgnoreCase("This prescription requires  specific directions for use. Please contact the prescriber to obtain detailed instructions, then annotate the prescription image.\n" +
                        "DirectionThis")) {
                    softAssert.assertTrue(true, "expected condition matched");
                }
            }
        } catch(Throwable e){
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.log("Test failed at 4 Point queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyWorkQueue(WorkQueue workQueue) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatus(rxNbr);
            orderSearch.performSearch(rxNbr, SearchType.PatientRx);
            if (rxStatus.equalsIgnoreCase(workQueue.getWorkQueue())) {
                Reporter.log("RX is in Pick up queue");
                orderSearch.closeSearch();
            } else {
                Reporter.log("RX is not in Pick up queue");
                Assert.fail("RX is not in Pick up queue");
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void changeTPtoTP(Map<String, String> inputData, WorkQueue workQueue) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            F6Search search = new F6Search();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            automationManager.performSleep(10);
            String rxStatus = orderSearch.getRXStatus(rxNbr);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

            }
            automationManager.performSleep(5);
            rxStatus = orderSearch.getRXStatus(rxNbr);
            if (rxStatus.equalsIgnoreCase(workQueue.getWorkQueue())) {
                switchToTPFromTP(inputData, workQueue);

            } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                Reporter.log("RX is in Resolve queue");
                Assert.fail("RX is in Resolve queue");
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                Reporter.log("RX is in CASH queue");
                Assert.fail("RX is in CASH queue");
            }
        } catch (Throwable e) {
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.log("Test failed at Filling queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyWorkQueue(String workQueue) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            F6Search search = new F6Search();
            automationManager.performSleep(2);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = search.getRXStatus(name[0] + "," + name[1]);
            if (rxStatus.equalsIgnoreCase(workQueue)) {
                Assert.assertTrue(true, "Workqueue Matched");
            } else {

                Assert.fail("Workqueue not Matched, current work queue is " + rxStatus);
            }
        } catch (Exception e) {
            softAssert.fail(workQueue + " " + "not matched");
            Reporter.log(workQueue + " " + "not matched");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }


    public void performResolution()
    {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                for (int index = 0; index <= 4; index++) {
                    automationManager.performSleep(10);
                    int isOrderIn4point = checkOrderIn4pointAndNotDUR(rxNbr);
                    System.out.println("check order in 4 point"+isOrderIn4point);
                    if (isOrderIn4point > 0) {
                        break;
                    }
                }
                Reporter.log("RX in TP flow");
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(name[0] + "," + name[1]);
            }

        }
        catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


    public void changePaymentFromTPtoCASHForAPatient() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.inputPatientDob(patient.getPatientDob());
            System.out.println(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            softAssert.assertTrue(patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(name[0] + "," + name[1]));
            patientSearchPage.openFirstPatientRecord();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.switchPaymentMethodFromTPtoCASH();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(loginUser_Type);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void performSameDayRefillResolution() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        ResolutionPage resolutionPage = new ResolutionPage();
        try{
            String[] name = connexusAppUtils.readPatientNameFromFile();

            orderSearch.openSearch();
            String rxStatus  = orderSearch.getRXStatusForPatient(rxNbr,0);
            orderSearch.selectRowFromSearchRX();
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                orderSearch.performSearch(rxNbr, SearchType.PatientRx);
                automationManager.performSleep(3);
                orderSearch.selectRowFromSearchRX();
                automationManager.performSleep(5);
                resolutionPage.clickSubmit();
            }
        } catch (Exception e) {
            Reporter.log(e.getMessage() + " Resolution not completed");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }
    public void uncheckVoidRemaingCheckBox( int index) {

        F6Search search = new F6Search();
        VisVerPage visVerPage = new VisVerPage();
        ChkDur dur = new ChkDur();
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        automationManager.performSleep(5);
        String rxStatus = orderSearch.getRXStatusBasedOnRxIndex(rxNbr, index);
        if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {  // perform checkDUR
            try {
                search.performSearch(rxNbr, SearchType.PatientRx);
                search.selectRowFromSearch(index);
                automationManager.performSleep(4);
                modifyDetails.openModifyDetailsScreen();
                modifyDetails.clickVoidRemaining();
                modifyDetails.uncheckVoidRemaining();
                modifyDetails.clickAccept();
                modifyDetails.OkWarningClick();
                modifyDetails.clickFloatingOkButton();
                modifyDetails.clickok();
                automationManager.performSleep(4);
                visVerPage.handleIHaveOrderPopUp();
                visVerPage.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } catch (Exception e) {
                Assert.fail("CheckDUR failed" + e.getStackTrace());
                Reporter.log("Test failed at ChkDUR queue" + e.getStackTrace());
            }
        }
    }
    public void selectOrDeselectVoidRemaingCheckBox( int index) {

        F6Search search = new F6Search();
        VisVerPage visVerPage = new VisVerPage();
        ChkDur dur = new ChkDur();
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {

            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusBasedOnRxIndex(rxNbr, index);

            if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) { //select void remaining in filling modify
                try {
                    System.out.println(" 1" + rxStatus);
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    automationManager.performSleep(4);
                    modifyDetails.openModifyDetailsScreen();
                    modifyDetails.clickVoidRemaining();
                    modifyDetails.OkWarningClick();
                    modifyDetails.clickAccept();
                    modifyDetails.clickFloatingOkButton();
                    modifyDetails.acceptAndClose();
                    modifyDetails.clickFloatingOkButton();
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                } catch (Exception a) {
                    Assert.fail("Filliing failed" + a.getStackTrace());
                    Reporter.log("Test failed at filling queue" + a.getStackTrace());
                }
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {  // perform checkDUR
                try {
                    System.out.println(" 2 " + rxStatus);
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    if (dur.checkIfAcceptIsEnabled()) {
                        dur.clickAccept();
                    }
                    modifyDetails.clickFloatingOkButton();
                    modifyDetails.saveConsolidatedNotes();
                } catch (Exception e) {
                    Assert.fail("CheckDUR failed" + e.getStackTrace());
                    Reporter.log("Test failed at ChkDUR queue" + e.getStackTrace());
                }
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) { //Uncheck void remaning if VV
                try {
                    ResolutionPage resolutionPage = new ResolutionPage();
                    System.out.println(" 3" + rxStatus);
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    automationManager.performSleep(4);
                    //resolutionPage.clickDownTime();
                    automationManager.performSleep(4);
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    automationManager.performSleep(4);
                    modifyDetails.openModifyDetailsScreen();
                    modifyDetails.clickVoidRemaining();
                    modifyDetails.OkWarningClick();
                    modifyDetails.clickAccept();
                    modifyDetails.clickFloatingOkButton();
                    modifyDetails.saveConsolidatedNotes();
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    automationManager.performSleep(4);
                    resolutionPage.clickDownTime();
                    automationManager.performSleep(4);
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    automationManager.performSleep(4);
                    visVerPage.handleIHaveOrderPopUp();
                    visVerPage.clickAccept();
                } catch (Exception e) {
                    Assert.fail("VV failed" + e.getStackTrace());
                    Reporter.log("Test failed at VV queue" + e.getStackTrace());
                }
            }else if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {  // perform checkDUR
                try {
                    search.performSearch(rxNbr, SearchType.PatientRx);
                    search.selectRowFromSearch(index);
                    automationManager.performSleep(4);
                    modifyDetails.openModifyDetailsScreen();
                    modifyDetails.clickVoidRemaining();
                    modifyDetails.uncheckVoidRemaining();
                    modifyDetails.clickAccept();
                    modifyDetails.OkWarningClick();
                    modifyDetails.clickFloatingOkButton();
                    automationManager.performSleep(4);
                    visVerPage.handleIHaveOrderPopUp();
                    visVerPage.clickAccept();
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                } catch (Exception e) {
                    Assert.fail("CheckDUR failed" + e.getStackTrace());
                    Reporter.log("Test failed at ChkDUR queue" + e.getStackTrace());
                }
            }
        } catch (Exception e) {
            Reporter.log("Test failed");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyRxStatusFromDropOff(String status) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            dropOffPage.clickDropOffQueue();
            automationManager.performSleep(3);
            dropOffPage.enterPatientName(rxNbr);
            automationManager.performSleep(3);
            dropOffPage.clickPatientSearch();
            automationManager.performSleep(5);
            dropOffPage.clickOkButton();
            if(dropOffPage.isRxStatusAvailable(0)){
                Reporter.log(dropOffPage.getRxStatusAvailable(0));
                if(dropOffPage.getRxStatusAvailable(0).equalsIgnoreCase(status)) {
                    Reporter.logScreenShot(currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                }else{
                    Assert.fail("rx status not matched, Expected " + status);
                    Reporter.logScreenShot(Status.FAIL,currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                }
            }
            else{
                Assert.fail("rx status available");
                Reporter.logScreenShot(Status.FAIL,currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            }

        } catch (Exception e) {
            Reporter.logScreenShot(currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }
    public void performPartialFill(String workqueue) {
        F6Search search = new F6Search();
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            MenuBar menuBar = new MenuBar();
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatus(rxNbr);
            if (rxStatus.equalsIgnoreCase(workqueue)) {
                search.performSearch(rxNbr, SearchType.PatientRx);
                search.selectRowFromSearch(0);
                modifyDetails.clickCurrentRX();
                //menuBar.navigateToMenu(AppMenu.PARTIAL_FILL);
                modifyDetails.clickOnCancelRx();
                //menuBar.navigateToMenu(AppMenu.PARTIAL_FILL);
                modifyDetails.clickOnPartialFill();
                modifyDetails.enterPartialFillQuantity();
                modifyDetails.enterOnHandQuantity();
                modifyDetails.clickAccept();
                modifyDetails.switchWindow();
                modifyDetails.selectQtyDiscrepency();
                modifyDetails.clickContinue();
                dropOffPage.checkAndClickDropOffStation();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void cancelRxWithErxAndVerifyRxsStaus(String workqueue,String isOriginalRxCrossedPickUp,String status0,String status1,String status2) {
        F6Search search = new F6Search();
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            automationManager.performSleep(10);
            String rxStatus = orderSearch.getRXStatus(name[0]);
            if (rxStatus.equalsIgnoreCase(workqueue)) {
                search.performSearch(name[0], SearchType.PatientRx);
                search.selectRowFromSearch(0);
                search.moveMouselocationTo(551,1248);
                search.selectCancelRx(0);
                modifyDetails.clickAccept();
                if("notCrossedPickUp".equalsIgnoreCase(isOriginalRxCrossedPickUp)) {
                    if(modifyDetails.isYesDisplayed()) {
                        modifyDetails.clickYes();
                    }else{
                        Assert.fail("Return to pickup not happening");
                    }
                }
                modifyDetails.clickFloatingOkButton();
                automationManager.performSleep(5);
                rxLookUp.launchRxLookUpPage();
                rxLookUp.inputSearch(rxNbr);
                rxLookUp.clickSearch();
                automationManager.performSleep(5);
                if(inputPage.getRxStatusFromShowOrderPopUp(0).equalsIgnoreCase(status0)
                        &&inputPage.getRxStatusFromShowOrderPopUp(1).equalsIgnoreCase(status1)
                        &&inputPage.getRxStatusFromShowOrderPopUp(2).equalsIgnoreCase(status2)){
                }else{
                    Reporter.log("Fill status not matched");
                    Assert.fail("Fill status not matched");
                }
                rxLookUp.closeSearch();
            }
            else{
                Reporter.log("CancelErx not created");
                Assert.fail("CancelErx not created");
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void cancelRxWithErxAndVerifyRxStaus(String workqueue,String isOriginalRxCrossedPickUp,String status0) {
        F6Search search = new F6Search();
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            automationManager.performSleep(10);
            String rxStatus = orderSearch.getRXStatus(name[0]);
            if (rxStatus.equalsIgnoreCase(workqueue)) {
                search.performSearch(name[0], SearchType.PatientRx);
                search.selectRowFromSearch(0);
                search.moveMouselocationTo(551,1248);
                search.selectCancelRx(0);
                modifyDetails.clickAccept();
                if("crossedPickUp".equalsIgnoreCase(isOriginalRxCrossedPickUp)) {
                    if(modifyDetails.isYesDisplayed()) {
                        modifyDetails.clickYes();
                    }else{
                        Assert.fail("Return to pickup not happening");
                    }
                }
                modifyDetails.clickFloatingOkButton();
                automationManager.performSleep(5);
                rxLookUp.launchRxLookUpPage();
                rxLookUp.inputSearch(rxNbr);
                rxLookUp.clickSearch();
                automationManager.performSleep(5);
                if(inputPage.getRxStatusFromShowOrderPopUp(0).equalsIgnoreCase(status0)){
                    Reporter.log("Fill status matched");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }else{
                    Reporter.log("Fill status not matched");
                    Assert.fail("Fill status not matched");
                }
                rxLookUp.closeSearch();
            }
            else{
                Reporter.log("CancelErx not created");
                Assert.fail("CancelErx not created");
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void sendErxMessage(String payloadType,Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        MenuBar menuBar = new MenuBar();
        F6Search search = new F6Search();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();

            automationManager.performSleep(10);
            patientSearchPage.launchAboutScreen();
            automationManager.performSleep(10);
            String dob = inputData.get("DOB");
            switch(payloadType)
            {
                case "surescriptFutureFill":
                case "surescriptNewRequst":
                    System.out.print("payload"+payloadResource.getPayload(payloadType,name,dob));
                    search.sendErxMsg(payloadResource.getPayload(payloadType,name,dob));
                    search.selectSurescriptsRadioButton();
                    break;
                case "cancelsurescriptrequest":
                    search.sendErxMsg(payloadResource.getPayload(payloadType,name,dob));
                    search.selectSurescriptsRadioButton();
                    break;
            }
            search.sendErxMessage();
            automationManager.performSleep(3);
            if("Failure".equalsIgnoreCase(search.getErxResponseMessage())){
                search.clickOk();
                search.closeAboutWindow();
                Assert.fail("Failed to send Erx Message");
            }else{
                search.clickOk();
                search.closeAboutWindow();

            }

        } catch (Exception e) {
            Reporter.log("Test failed at sending ERX");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void selectFutureFill() {
        F6Search search = new F6Search();
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            FourPoint fourPoint = new FourPoint();

            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus  = orderSearch.getRXStatusForPatient(name[0]+","+name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.FOUR_POINT.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                automationManager.performSleep(5);
                patientSearchPage.performSearch(name[0]+","+name[1]);
                automationManager.performSleep(5);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                modifyDetails.launchModifyDetailScreen();
                automationManager.performSleep(4);
                modifyDetails.selectFutureFill();
                modifyDetails.clickFutureFilldropdown();
                modifyDetails.clickAccept();
                modifyDetails.clickCancel();
                automationManager.performSleep(10);
                if (fourPoint.isNameChkBoxDisplayed()) {
                    fourPoint.chkName();
                    fourPoint.chkPrescribed();
                    if (fourPoint.ischkStrength()) {
                        fourPoint.chkStrength();
                    }
                    fourPoint.chkSIG();
                    if (fourPoint.isDeaChkBoxDisplayed()) {
                        fourPoint.chkDEA();
                    }
                    if (fourPoint.isNonAcuteRdbDisplayed()) {
                        fourPoint.clickNonAcute();
                    }

                    fourPoint.clickAccept();
                }
            }
        } catch (Exception e) {
            Reporter.log("Test failed at ChkDUR queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyClaimSubmission(String claimStatus) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

            }
            automationManager.performSleep(5);
            orderSearch.clickClaim();
            connexusStartPage.performSearch(rxNbr);
            automationManager.performSleep(4);
            connexusStartPage.clickSearchButton();
            if(connexusStartPage.getCailnSatus(0).equalsIgnoreCase(claimStatus)||connexusStartPage.getCailnSatus(1).equalsIgnoreCase(claimStatus)){
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

            }
            connexusStartPage.clickClose();
        }
        catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();

        }
    }
    public String erxPayload(String payLoad){
        DropOffPage dropOff = new DropOffPage();
        String storeNo="";
        storeNo="990"+propertyReader.getProperty("cnx.store").toString();
        System.out.print("StoreNumber" + storeNo);
        String messageID="";
        String random = dropOff.generateRxBarCode();
        messageID = "narayan"+random;
        System.out.println(messageID);
        SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.s");
        Date date = new Date(System.currentTimeMillis());
        System.out.println(formatter.format(date));
        String payload ="";
        String[] name = connexusAppUtils.readPatientNameFromFile();
        if("surescriptNewRequst".equalsIgnoreCase(payLoad)) {
            payload = "<?xml version=\"1.0\"?><Message xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
                    "DatatypesVersion=\"20170715\" TransportVersion=\"20170715\" TransactionDomain=\"SCRIPT\" TransactionVersion=\"20170715\" StructuresVersion=\"20170715\" ECLVersion=\"20170715\">" +
                    "<Header><To Qualifier=\"P\">" + storeNo + "</To><From Qualifier=\"D\">5262234330002</From><MessageID>" + messageID + "</MessageID>" +
                    "<SentTime>2020-09-08T11:57:00.0364904Z</SentTime><SenderSoftware><SenderSoftwareDeveloper>Surescripts</SenderSoftwareDeveloper><SenderSoftwareProduct>ErxMessageManager</SenderSoftwareProduct>" +
                    "<SenderSoftwareVersionRelease>1.15.0</SenderSoftwareVersionRelease></SenderSoftware><PrescriberOrderNumber>61dfe7a3531a4c8eb10788bb3e3bc8d3</PrescriberOrderNumber></Header>" +
                    "<Body><NewRx><BenefitsCoordination><PayerIdentification><PayerID>T00000000021633</PayerID><ProcessorIdentificationNumber>CAR-123</ProcessorIdentificationNumber><NAICCode>BIN123</NAICCode></PayerIdentification>" +
                    "<CardholderID>MID4444444444444</CardholderID><GroupID>CG1111111111/CGID333333X</GroupID><PBMMemberID>ZZQ%PBM-UID-888877222-%VVVVAAAA10011XX-XX261L</PBMMemberID></BenefitsCoordination><Patient><HumanPatient><Name><LastName>" + name[0] + "</LastName>" +
                    "<FirstName>" + name[1] + "</FirstName></Name><Gender>M</Gender><DateOfBirth><Date>1981-01-09</Date></DateOfBirth><Address><AddressLine1>64 Violet Lane</AddressLine1><City>Howey In The Hills</City><StateProvince>FL</StateProvince><PostalCode>34737</PostalCode>" +
                    "<CountryCode>US</CountryCode></Address><CommunicationNumbers><PrimaryTelephone><Number>9508450398</Number></PrimaryTelephone></CommunicationNumbers></HumanPatient></Patient><Pharmacy><Identification><NCPDPID>9905561</NCPDPID></Identification><BusinessName>Walmart Pharmacy 5561</BusinessName>" +
                    "<Address><AddressLine1>1102 SE 5th Street</AddressLine1><City>Bentonville</City><StateProvince>TX</StateProvince><PostalCode>72712</PostalCode><CountryCode>US</CountryCode></Address><CommunicationNumbers><PrimaryTelephone><Number>4798667575</Number></PrimaryTelephone><Fax><Number>4798667576</Number></Fax>" +
                    "</CommunicationNumbers></Pharmacy><Prescriber><NonVeterinarian><Identification><DEANumber>MN3192301</DEANumber><NPI>1811908056</NPI></Identification><Name><LastName>BINGHAM</LastName><FirstName>PETER</FirstName><MiddleName>H</MiddleName></Name><Address><AddressLine1>3305 ROOSEVELT ST</AddressLine1>" +
                    "<City>CARLSBAD</City><StateProvince>CA</StateProvince><PostalCode>920081619</PostalCode><CountryCode>US</CountryCode></Address><CommunicationNumbers><PrimaryTelephone><Number>7617412814</Number></PrimaryTelephone><Fax><Number>7607207700</Number></Fax></CommunicationNumbers></NonVeterinarian></Prescriber>" +
                    "<Observation><Measurement><VitalSign>8302-2</VitalSign><LOINCVersion>2.42</LOINCVersion><Value>62</Value><UnitOfMeasure>[in_i]</UnitOfMeasure><UCUMVersion>!</UCUMVersion><ObservationDate><Date>2018-01-20</Date></ObservationDate></Measurement><Measurement><VitalSign>29463-7</VitalSign><LOINCVersion>2.42</LOINCVersion>" +
                    "<Value>140</Value><UnitOfMeasure>[lb_av]</UnitOfMeasure><UCUMVersion>!</UCUMVersion><ObservationDate><Date>2018-01-23</Date></ObservationDate></Measurement></Observation><MedicationPrescribed><DrugDescription>Magic Mouthwash Diphenhydramine 12.5 mg/5 mL, Viscous lidocaine 2%, Maalox 1 part</DrugDescription><Quantity><Value>900</Value>" +
                    "<CodeListQualifier>CF</CodeListQualifier><QuantityUnitOfMeasure><Code>C28254</Code></QuantityUnitOfMeasure></Quantity><DaysSupply>30</DaysSupply><WrittenDate><DateTime>"+formatter.format(date)+"</DateTime></WrittenDate><Substitutions>0</Substitutions><NumberOfRefills>1</NumberOfRefills><Diagnosis><ClinicalInformationQualifier>2</ClinicalInformationQualifier>" +
                    "<Primary><Code>K1233</Code><Qualifier>ABF</Qualifier><Description>Oral mucositis (ulcerative) due to radiation</Description></Primary></Diagnosis>" +
                    "<Note>Patient requested peppermint flavoring if possible. Please provide appropriate documentation to patient for how to use this product, including not swallowing solution. A child-resistant package also requested.</Note><DrugCoverageStatusCode>UN</DrugCoverageStatusCode><Sig><SigText>Swish and spit 15 mL orally for 1 minute every 12 hours</SigText>" +
                    "<CodeSystem><SNOMEDVersion>20170131</SNOMEDVersion><FMTVersion>16.03d</FMTVersion></CodeSystem><Instruction><DoseAdministration><DoseDeliveryMethod><Text>Swish</Text><Qualifier>SNOMED</Qualifier><Code>421805007</Code></DoseDeliveryMethod><Dosage><DoseQuantity>15</DoseQuantity><DoseUnitOfMeasure><Text>mL</Text><Qualifier>DoseUnitOfMeasure</Qualifier><Code>C28254</Code>" +
                    "</DoseUnitOfMeasure></Dosage><RouteOfAdministration><Text>oral route</Text><Qualifier>SNOMED</Qualifier><Code>26643006</Code></RouteOfAdministration></DoseAdministration><TimingAndDuration><Interval><IntervalNumericValue>12</IntervalNumericValue><IntervalUnits><Text>hours</Text><Qualifier>SNOMED</Qualifier><Code>307467005</Code></IntervalUnits></Interval>" +
                    "<TimingClarifyingFreeText>for 1 minute every 12 hours</TimingClarifyingFreeText></TimingAndDuration></Instruction></Sig><RxFillIndicator>All Fill Statuses</RxFillIndicator><DeliveryRequest>FIRST FILL DELIVERY</DeliveryRequest><DeliveryLocation>CONTACT PATIENT FOR DELIVERY</DeliveryLocation><FlavoringRequested>Y</FlavoringRequested><CompoundInformation>" +
                    "<FinalCompoundPharmaceuticalDosageForm>C28254</FinalCompoundPharmaceuticalDosageForm><CompoundIngredientsLotNotUsed><CompoundIngredient><CompoundIngredientItemDescription>Diphenhydramine 12.5 mg/5 mL</CompoundIngredientItemDescription><Strength><StrengthValue>12.5</StrengthValue><StrengthForm><Code>C42986</Code></StrengthForm><StrengthUnitOfMeasure><Code>C91131</Code>" +
                    "</StrengthUnitOfMeasure></Strength></CompoundIngredient><Quantity><Value>300</Value><CodeListQualifier>38</CodeListQualifier><QuantityUnitOfMeasure><Code>C28254</Code></QuantityUnitOfMeasure></Quantity></CompoundIngredientsLotNotUsed><CompoundIngredientsLotNotUsed><CompoundIngredient><CompoundIngredientItemDescription>Viscous lidocaine 2%</CompoundIngredientItemDescription>" +
                    "<Strength><StrengthValue>2</StrengthValue><StrengthForm><Code>C42986</Code></StrengthForm><StrengthUnitOfMeasure><Code>C25613</Code></StrengthUnitOfMeasure></Strength></CompoundIngredient><Quantity><Value>300</Value><CodeListQualifier>38</CodeListQualifier><QuantityUnitOfMeasure><Code>C28254</Code></QuantityUnitOfMeasure></Quantity></CompoundIngredientsLotNotUsed><CompoundIngredientsLotNotUsed><CompoundIngredient>" +
                    "<CompoundIngredientItemDescription>Maalox oral suspension</CompoundIngredientItemDescription><Strength><StrengthValue>200/200/20</StrengthValue><StrengthForm><Code>C68992</Code></StrengthForm><StrengthUnitOfMeasure><Code>C91131</Code></StrengthUnitOfMeasure></Strength></CompoundIngredient><Quantity><Value>300</Value><CodeListQualifier>38</CodeListQualifier><QuantityUnitOfMeasure><Code>C28254</Code></QuantityUnitOfMeasure>" +
                    "</Quantity></CompoundIngredientsLotNotUsed></CompoundInformation></MedicationPrescribed></NewRx></Body></Message>";
        }
        else if("cancelsurescriptrequest".equalsIgnoreCase(payLoad)){
            payload="<?xml version=\"1.0\"?>\n" +
                    "<Message xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" DatatypesVersion=\"20170715\" TransportVersion=\"20170715\" TransactionDomain=\"SCRIPT\" TransactionVersion=\"20170715\" StructuresVersion=\"20170715\" ECLVersion=\"20170715\">\n" +
                    "  <Header>\n" +
                    "    <To Qualifier=\"P\">"+storeNo+"</To>\n" +
                    "    <From Qualifier=\"D\">2449809346001</From>\n" +
                    "    <MessageID>"+messageID+"</MessageID>\n" +
                    "    <RelatesToMessageID>ECHO FROM REFRES</RelatesToMessageID>\n" +
                    "    <SentTime>2022-05-18T01:59:57.5620906Z</SentTime>\n" +
                    "    <SenderSoftware>\n" +
                    "      <SenderSoftwareDeveloper>Surescripts</SenderSoftwareDeveloper>\n" +
                    "      <SenderSoftwareProduct>ErxMessageManager</SenderSoftwareProduct>\n" +
                    "      <SenderSoftwareVersionRelease>1.9.0</SenderSoftwareVersionRelease>\n" +
                    "    </SenderSoftware>\n" +
                    "    <PrescriberOrderNumber>a461281967db4ee3b6a181d3c13f4afa</PrescriberOrderNumber>\n" +
                    "  </Header>\n" +
                    "  <Body>\n" +
                    "    <CancelRx>\n" +
                    "      <Patient>\n" +
                    "        <HumanPatient>\n" +
                    "          <Name>\n" +
                    "            <LastName>"+name[0]+"</LastName>\n" +
                    "            <FirstName>"+name[1]+"</FirstName>\n" +
                    "          </Name>\n" +
                    "          <Gender>M</Gender>\n" +
                    "          <DateOfBirth>\n" +
                    "            <Date>1981-01-09</Date>\n" +
                    "          </DateOfBirth>\n" +
                    "          <Address>\n" +
                    "            <AddressLine1>27732 West Alameda Potholeladen Street</AddressLine1>\n" +
                    "            <AddressLine2>Apt 425-B</AddressLine2>\n" +
                    "            <City>Rancho Cucamonga</City>\n" +
                    "            <StateProvince>CA</StateProvince>\n" +
                    "            <PostalCode>917011515</PostalCode>\n" +
                    "            <CountryCode>US</CountryCode>\n" +
                    "          </Address>\n" +
                    "          <CommunicationNumbers>\n" +
                    "            <PrimaryTelephone>\n" +
                    "              <Number>7075214577</Number>\n" +
                    "              <SupportsSMS>Y</SupportsSMS>\n" +
                    "            </PrimaryTelephone>\n" +
                    "            <ElectronicMail>Juancarlos.Usacruz@hotmail.com</ElectronicMail>\n" +
                    "            <HomeTelephone>\n" +
                    "              <Number>7075576314</Number>\n" +
                    "            </HomeTelephone>\n" +
                    "            <WorkTelephone>\n" +
                    "              <Number>8903456098</Number>\n" +
                    "              <Extension>45422142</Extension>\n" +
                    "              <SupportsSMS>N</SupportsSMS>\n" +
                    "            </WorkTelephone>\n" +
                    "            <OtherTelephone>\n" +
                    "              <Number>1709863483</Number>\n" +
                    "            </OtherTelephone>\n" +
                    "          </CommunicationNumbers>\n" +
                    "        </HumanPatient>\n" +
                    "      </Patient>\n" +
                    "      <Pharmacy>\n" +
                    "        <Identification>\n" +
                    "          <NCPDPID>9905510</NCPDPID>\n" +
                    "          <NPI>5689648728</NPI>\n" +
                    "        </Identification>\n" +
                    "        <BusinessName>Wal-Mart Pharmacy 5510</BusinessName>\n" +
                    "        <Address>\n" +
                    "          <AddressLine1>805 SE Moberly Lane</AddressLine1>\n" +
                    "          <City>Bentonville</City>\n" +
                    "          <StateProvince>TX</StateProvince>\n" +
                    "          <PostalCode>72712</PostalCode>\n" +
                    "          <CountryCode>US</CountryCode>\n" +
                    "        </Address>\n" +
                    "        <CommunicationNumbers>\n" +
                    "          <PrimaryTelephone>\n" +
                    "            <Number>4798675309</Number>\n" +
                    "          </PrimaryTelephone>\n" +
                    "          <Fax>\n" +
                    "            <Number>4798675310</Number>\n" +
                    "          </Fax>\n" +
                    "        </CommunicationNumbers>\n" +
                    "      </Pharmacy>\n" +
                    "      <Prescriber>\n" +
                    "        <NonVeterinarian>\n" +
                    "          <Identification>\n" +
                    "            <DEANumber>AN1234561</DEANumber>\n" +
                    "            <NPI>2677842447</NPI>\n" +
                    "          </Identification>\n" +
                    "          <Name>\n" +
                    "            <LastName>Napoletani</LastName>\n" +
                    "            <FirstName>Levi</FirstName>\n" +
                    "          </Name>\n" +
                    "          <Address>\n" +
                    "            <AddressLine1>342 Miles Street</AddressLine1>\n" +
                    "            <City>Sylvania</City>\n" +
                    "            <StateProvince>OH</StateProvince>\n" +
                    "            <PostalCode>43560</PostalCode>\n" +
                    "            <CountryCode>US</CountryCode>\n" +
                    "          </Address>\n" +
                    "          <CommunicationNumbers>\n" +
                    "            <PrimaryTelephone>\n" +
                    "              <Number>4792543838</Number>\n" +
                    "            </PrimaryTelephone>\n" +
                    "            <Fax>\n" +
                    "              <Number>4792543838</Number>\n" +
                    "            </Fax>\n" +
                    "          </CommunicationNumbers>\n" +
                    "        </NonVeterinarian>\n" +
                    "      </Prescriber>\n" +
                    "      <MedicationPrescribed>\n" +
                    "        <DrugDescription>Magic Mouthwash Diphenhydramine 12.5 mg/5 mL, Viscous lidocaine 2%, Maalox 1 part</DrugDescription>\n" +
                    "        <Quantity>\n" +
                    "          <Value>900</Value>\n" +
                    "          <CodeListQualifier>CF</CodeListQualifier>\n" +
                    "          <QuantityUnitOfMeasure>\n" +
                    "            <Code>C28254</Code>\n" +
                    "          </QuantityUnitOfMeasure>\n" +
                    "        </Quantity>\n" +
                    "        <DaysSupply>30</DaysSupply>\n" +
                    "        <WrittenDate>\n" +
                    "          <DateTime>"+ formatter.format(date)+"</DateTime>\n" +
                    "        </WrittenDate>\n" +
                    "        <Substitutions>0</Substitutions>\n" +
                    "        <NumberOfRefills>1</NumberOfRefills>\n" +
                    "        <Diagnosis>\n" +
                    "          <ClinicalInformationQualifier>2</ClinicalInformationQualifier>\n" +
                    "          <Primary>\n" +
                    "            <Code>K1233</Code>\n" +
                    "            <Qualifier>ABF</Qualifier>\n" +
                    "            <Description>Oral mucositis (ulcerative) due to radiation</Description>\n" +
                    "          </Primary>\n" +
                    "          <Secondary>\n" +
                    "            <Code>Z510</Code>\n" +
                    "            <Qualifier>ABF</Qualifier>\n" +
                    "            <Description>Encounter for antineoplastic radiation therapy</Description>\n" +
                    "          </Secondary>\n" +
                    "        </Diagnosis>\n" +
                    "        <Note>Patient requested peppermint flavoring if possible. Please provide appropriate documentation to patient for how to use this product, including not swallowing solution. A child-resistant package also requested.</Note>\n" +
                    "        <Sig>\n" +
                    "          <SigText>Swish and spit 15 mL orally for 1 minute every 12 hours</SigText>\n" +
                    "          <CodeSystem>\n" +
                    "            <SNOMEDVersion>20170131</SNOMEDVersion>\n" +
                    "            <FMTVersion>16.03d</FMTVersion>\n" +
                    "          </CodeSystem>\n" +
                    "          <Instruction>\n" +
                    "            <DoseAdministration>\n" +
                    "              <DoseDeliveryMethod>\n" +
                    "                <Text>Swish</Text>\n" +
                    "                <Qualifier>SNOMED</Qualifier>\n" +
                    "                <Code>421805007</Code>\n" +
                    "              </DoseDeliveryMethod>\n" +
                    "              <Dosage>\n" +
                    "                <DoseQuantity>15</DoseQuantity>\n" +
                    "                <DoseUnitOfMeasure>\n" +
                    "                  <Text>mL</Text>\n" +
                    "                  <Qualifier>DoseUnitOfMeasure</Qualifier>\n" +
                    "                  <Code>C28254</Code>\n" +
                    "                </DoseUnitOfMeasure>\n" +
                    "              </Dosage>\n" +
                    "              <RouteOfAdministration>\n" +
                    "                <Text>oral route</Text>\n" +
                    "                <Qualifier>SNOMED</Qualifier>\n" +
                    "                <Code>26643006</Code>\n" +
                    "              </RouteOfAdministration>\n" +
                    "            </DoseAdministration>\n" +
                    "            <TimingAndDuration>\n" +
                    "              <Interval>\n" +
                    "                <IntervalNumericValue>12</IntervalNumericValue>\n" +
                    "                <IntervalUnits>\n" +
                    "                  <Text>hours</Text>\n" +
                    "                  <Qualifier>SNOMED</Qualifier>\n" +
                    "                  <Code>307467005</Code>\n" +
                    "                </IntervalUnits>\n" +
                    "              </Interval>\n" +
                    "              <TimingClarifyingFreeText>for 1 minute every 12 hours</TimingClarifyingFreeText>\n" +
                    "            </TimingAndDuration>\n" +
                    "          </Instruction>\n" +
                    "        </Sig>\n" +
                    "        <CompoundInformation>\n" +
                    "          <FinalCompoundPharmaceuticalDosageForm>C28254</FinalCompoundPharmaceuticalDosageForm>\n" +
                    "          <CompoundIngredientsLotNotUsed>\n" +
                    "            <CompoundIngredient>\n" +
                    "              <CompoundIngredientItemDescription>Diphenhydramine 12.5 mg/5 mL</CompoundIngredientItemDescription>\n" +
                    "              <Strength>\n" +
                    "                <StrengthValue>12.5</StrengthValue>\n" +
                    "                <StrengthForm>\n" +
                    "                  <Code>C42986</Code>\n" +
                    "                </StrengthForm>\n" +
                    "                <StrengthUnitOfMeasure>\n" +
                    "                  <Code>C91131</Code>\n" +
                    "                </StrengthUnitOfMeasure>\n" +
                    "              </Strength>\n" +
                    "            </CompoundIngredient>\n" +
                    "            <Quantity>\n" +
                    "              <Value>300</Value>\n" +
                    "              <CodeListQualifier>38</CodeListQualifier>\n" +
                    "              <QuantityUnitOfMeasure>\n" +
                    "                <Code>C28254</Code>\n" +
                    "              </QuantityUnitOfMeasure>\n" +
                    "            </Quantity>\n" +
                    "          </CompoundIngredientsLotNotUsed>\n" +
                    "          <CompoundIngredientsLotNotUsed>\n" +
                    "            <CompoundIngredient>\n" +
                    "              <CompoundIngredientItemDescription>Viscous lidocaine 2%</CompoundIngredientItemDescription>\n" +
                    "              <Strength>\n" +
                    "                <StrengthValue>2</StrengthValue>\n" +
                    "                <StrengthForm>\n" +
                    "                  <Code>C42986</Code>\n" +
                    "                </StrengthForm>\n" +
                    "                <StrengthUnitOfMeasure>\n" +
                    "                  <Code>C25613</Code>\n" +
                    "                </StrengthUnitOfMeasure>\n" +
                    "              </Strength>\n" +
                    "            </CompoundIngredient>\n" +
                    "            <Quantity>\n" +
                    "              <Value>300</Value>\n" +
                    "              <CodeListQualifier>38</CodeListQualifier>\n" +
                    "              <QuantityUnitOfMeasure>\n" +
                    "                <Code>C28254</Code>\n" +
                    "              </QuantityUnitOfMeasure>\n" +
                    "            </Quantity>\n" +
                    "          </CompoundIngredientsLotNotUsed>\n" +
                    "          <CompoundIngredientsLotNotUsed>\n" +
                    "            <CompoundIngredient>\n" +
                    "              <CompoundIngredientItemDescription>Maalox oral suspension</CompoundIngredientItemDescription>\n" +
                    "              <Strength>\n" +
                    "                <StrengthValue>200/200/20</StrengthValue>\n" +
                    "                <StrengthForm>\n" +
                    "                  <Code>C68992</Code>\n" +
                    "                </StrengthForm>\n" +
                    "                <StrengthUnitOfMeasure>\n" +
                    "                  <Code>C91131</Code>\n" +
                    "                </StrengthUnitOfMeasure>\n" +
                    "              </Strength>\n" +
                    "            </CompoundIngredient>\n" +
                    "            <Quantity>\n" +
                    "              <Value>300</Value>\n" +
                    "              <CodeListQualifier>38</CodeListQualifier>\n" +
                    "              <QuantityUnitOfMeasure>\n" +
                    "                <Code>C28254</Code>\n" +
                    "              </QuantityUnitOfMeasure>\n" +
                    "            </Quantity>\n" +
                    "          </CompoundIngredientsLotNotUsed>\n" +
                    "        </CompoundInformation>\n" +
                    "      </MedicationPrescribed>\n" +
                    "    </CancelRx>\n" +
                    "  </Body>\n" +
                    "</Message>";
        }
        return payload;
    }
    public void performCancelPrescription() {
        CancelPrescription cancelPrescription = new CancelPrescription();
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(name[0]+","+name[1]);
        try {
            String workQueue = orderSearch.getWorkQueue(0);
            if(workQueue.equalsIgnoreCase(WorkQueue.CANCELRX.getWorkQueue())) {
                patientSearchPage.openFirstPatientRecord();
                cancelPrescription.selectCancelCheckBox(0);
                cancelPrescription.clickAcceptCancelBtn();
                automationManager.performSleep(5);
                cancelPrescription.confirmCancelPrescription();
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                cancelPrescription.clickReturn2Stock();
                automationManager.performSleep(10);
                cancelPrescription.clickCancelbuttonk();
                automationManager.performSleep(15);
                patientSearchPage.launchOrderSearchScreen();
                automationManager.performSleep(10);
                patientSearchPage.performSearch(name[0]+","+name[1]);
                automationManager.performSleep(5);
                orderSearch.closeSearch();
            } else {
                Reporter.log("RX is not in CancelRx queue, It is in" + workQueue);
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());

            }
        }  catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void performRefillDropOff(){
        dropOffPage.clickDropOffQueue();
        VisVerPage visVerPage = new VisVerPage();
        automationManager.performSleep(5);
        String[] name = connexusAppUtils.readPatientNameFromFile();
        dropOffPage.enterPatientName(name[0]+","+name[1]);
        dropOffPage.clickPatientSearch();
        dropOffPage.handleAnnualValidatePatInfoPopUp();
        patientSearchPage.selectRowFromSearch(0);
        automationManager.performSleep(5);
        dropOffPage.dropOffOnExistingRx();
        visVerPage.clickOkButton();
        automationManager.performSleep(2);
        dropOffPage.handlePatientPaymentAlert();
        if (dropOffPage.outOFFStock()) {
            dropOffPage.clickOutOFFStock();
        }
        automationManager.performSleep(2);
        visVerPage.clickOkButton();
        visVerPage.clickOkButton();
        automationManager.performSleep(5);
        dropOffPage.selectPriority("Critical");
        dropOffPage.clickBtnAccept();
        automationManager.performSleep(6);
        dropOffPage.handleStorePickupTimePopup();
        Reporter.log("Drop-Off completed");

    }
    public void clickCancelBtn(){
        ResolutionPage resolutionPage= new ResolutionPage();
        resolutionPage.clickCancel();
    }

    public void verifyTPdaysSupplyOnTPInfoPage(String rxNbr,String patientId){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                for (int index = 0; index <= 4; index++) {
                    automationManager.performSleep(10);
                    int isOrderIn4point = checkOrderIn4pointAndNotDUR(rxNbr);
                    System.out.println("check order in 4 point"+isOrderIn4point);
                    if (isOrderIn4point > 0) {
                        break;
                    }
                }
                Reporter.log("RX in TP flow");
            }
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            patientSearchPage.openFirstPatientRecord();
            TPExtraInfoPage tpExtraInfoPage = new TPExtraInfoPage();
            ResolutionTPRejPage resolutionTPRejPage = new ResolutionTPRejPage();
            tpExtraInfoPage.openTPExtraInfo();
            tpExtraInfoPage.enterTPDaySupply("0");
            tpExtraInfoPage.clickAcceptBtn();
            String rx_ID = automationManager.getConnexusDB().getScalar("select rx_id from rx where patient_id =" +patientId, String.class);
            String rx_fill_id =automationManager.getConnexusDB().getScalar("select rx_fill_id from rx_fill where rx_id =" +rx_ID, String.class);

            String addition_val =automationManager.getConnexusDB().getScalar("SELECT addition_val from clm_override_addtn WHERE rx_fill_id=" + rx_fill_id + "AND addtn_class_code = 23232", String.class);
            Assert.assertEquals(addition_val,null);
            Reporter.log("addition_val column in null when value is removed/entered 0 in ‘Third party days supply");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            resolutionTPRejPage.clickClose();
        }catch (Throwable e) {
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performDropOffForRXWithNoRefills() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            dropOffPage.dropOffOnExistingRx();
            softAssert.assertTrue(dropOffPage.getTextFromRefillRequestPopup().contains("The Prescription is Out Of Refills"));
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickOKonRefillRequestPopUp();
            softAssert.assertTrue(dropOffPage.isFaxSendPopUpDisplayed());
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickSendToResolutionOnFaxSendPopUp();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickYesOnFaxNumberPopUp();
            dropOffPage.selectPriority("Critical");
            dropOffPage.clickBtnAccept();
            dropOffPage.handleStorePickupTimePopup();
            Reporter.log("Drop-Off completed");
            softAssert.assertAll();
        } catch (Throwable e) {
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performRefillsAuthorized(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolutionForRefills(rxNbr, inputData.get("REFILLS"), connexusAppUtils.randomName());
            } else {
                Reporter.log("RX is not in Resolve queue");
                Assert.fail("RX is not in Resolve queue");
            }
        } catch (Throwable e) {
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performInitialFill() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusBasedOnRxIndex(rxNbr, 1);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(20);
            }

            if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusBasedOnRxIndex(rxNbr, 1);
            if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
                Reporter.log("RX is in Resolve queue");
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                Reporter.log("RX is in CASH queue");
                automationManager.performSleep(10);
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 1);
                if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            }
        } catch (Exception e) {
            Reporter.log("Test failed at Filling queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performNaloxoneDropOffForPatient() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().performNaloxoneDropRxForPatient(dropRxModel);
        } catch (Throwable e) {
            Reporter.log("Test failed at DropOff queue");
            patientSearchPage.closeIfAnyPopUpOpened();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void performCancelPrescriptions() {
        CancelPrescription cancelPrescription = new CancelPrescription();
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(name[0]+","+name[1]);
        try {
            String workQueue = orderSearch.getWorkQueue(0);
            if(workQueue.equalsIgnoreCase(WorkQueue.CANCELRX.getWorkQueue())) {
                patientSearchPage.openFirstPatientRecord();
                cancelPrescription.selectCancelCheckBox(2);
                cancelPrescription.clickAcceptCancelBtn();
                cancelPrescription.clickOK();
                automationManager.performSleep(5);
                /*cancelPrescription.confirmCancelPrescription();
                automationManager.performSleep(5);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                cancelPrescription.clickReturn2Stock();
                automationManager.performSleep(10);
                cancelPrescription.clickCancelbuttonk();
                automationManager.performSleep(15);*/
                patientSearchPage.launchOrderSearchScreen();
                automationManager.performSleep(10);
                patientSearchPage.performSearch(name[0]+","+name[1]);
                automationManager.performSleep(5);
                orderSearch.closeSearch();
            } else {
                Reporter.log("RX is not in CancelRx queue, It is in" + workQueue);
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());

            }
        }  catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void performChkDURRedFlag(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            ChkDur dur = new ChkDur();
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(10);

                if (dur.clickRedFlagsBtn()) {
                    Reporter.logScreenShot(Status.PASS, "Resolving Red flags", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    dur.selectResolvedCheckBoxes();
                    dur.clickDurBtn();
                }

                if (dur.isElementDisplayed(dur.lblRequired, 30)) {
                    Assert.assertTrue(true);
                }

                if (!dur.clickClearConflictsBtn()) {
                    dur.selectAllCheckBoxes();
                }
                dur.clickNarxCareCheckBox();
                dur.clickAccept();
                ResolutionPage resolutionPage = new ResolutionPage();
                resolutionPage.clickProblemResolved();
            }


        }
        catch (Exception e) {
            Reporter.log("Test failed at ChkDUR queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void performChkDURInitialFill() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxNbr1 = orderSearch.getRxNbr(1);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr1, 1);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr1);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(10);
                ChkDur dur = new ChkDur();
                dur.clickNarxCareCheckBox();
                dur.clickAccept();

            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

        } catch (Exception e) {
            Reporter.log("Test failed at ChkDUR queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void performModifyDrugAtAnyWorkqueue(String workqueue, Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(5);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                //automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

                patientSearchPage.launchOrderSearchScreen();
                automationManager.performSleep(5);
                patientSearchPage.performSearch(rxNbr);
                automationManager.performSleep(5);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                modifyDetails.launchModifyDetailScreen();

                automationManager.performSleep(6);
                modifyDetails.enterProductNameInPrescribedProduct(inputData.get("UPDATED_DRUG"));
                inputPage.clickAccept();
                try {
                    inputPage.clickYes();
                } catch (Exception e) {
                    Reporter.log("RTS lable not available");
                }
                inputPage.clickButtonOk();
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

                patientSearchPage.launchOrderSearchScreen();
                automationManager.performSleep(5);
                patientSearchPage.performSearch(rxNbr);
                automationManager.performSleep(5);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(5);
                modifyDetails.launchModifyDetailScreen();

                automationManager.performSleep(6);
                modifyDetails.enterProductNameInPrescribedProduct(inputData.get("UPDATED_DRUG"));
                inputPage.clickAccept();
                try {
                    inputPage.clickYes();
                } catch (Exception e) {
                    Reporter.log("RTS lable not available");
                }
                inputPage.clickButtonOk();
            }
        } catch (Exception e) {
            Reporter.log("Test failed at ChkDUR queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void verifyVoidRemaingCheckBoxDisabled( int index) {

        F6Search search = new F6Search();
        VisVerPage visVerPage = new VisVerPage();
        ChkDur dur = new ChkDur();
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        automationManager.performSleep(5);
        String rxStatus = orderSearch.getRXStatusBasedOnRxIndex(rxNbr, index);
        if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {  // perform checkDUR
            try {
                search.performSearch(rxNbr, SearchType.PatientRx);
                search.selectRowFromSearch(index);
                automationManager.performSleep(4);
                modifyDetails.openModifyDetailsScreen();
                modifyDetails.clickButtonClose();
                modifyDetails.clickCancel();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }   catch (Exception e) {
                Assert.fail("CheckDUR failed" + e.getStackTrace());
                Reporter.log("Test failed at ChkDUR queue" + e.getStackTrace());
            }
        }
    }

    public int checkOrderIn4pointAndNotDUR(String rxNbr) {
        int workQueueCode = 0;
        int siteId = Integer.parseInt(propertyReader.getProperty("cnx.store"));
        try {
            workQueueCode = checkOrderWorkqueueCode(siteId,rxNbr);
            System.out.println("next work queue code is"+workQueueCode);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        if (workQueueCode == WorkQueueSettings.wm4PointCheck.getValue()) {
            return 1;
        } else {
            return 0;
        }
    }

    public int checkOrderWorkqueueCode(int siteId,String rxNbr) {
        int rxFillId=getFillId(rxNbr);
        Map<String, Object> rxInfo = automationManager.getConnexusDB(siteId).executeQuery("select next_work_que_code from rx21c: rx_order_detail where rx_fill_id =" + rxFillId);
        int nextWorkQueueCode = Integer.parseInt(rxInfo.get("next_work_que_code").toString());
        return nextWorkQueueCode;
    }

    public int getFillId(String rxNbr){
        String query = "select max(rx_fill_id) as rx_fill_id  from  rx_order_detail where rx_id =(select rx_id from rx where rx_nbr=\"" + rxNbr + "\")";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        int fillId = Integer.parseInt(rxInfo.get("rx_fill_id").toString());
        System.out.println("Filld is "+fillId);
        return fillId;
    }
}

