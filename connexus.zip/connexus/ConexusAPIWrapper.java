package connexus;

import connexus.datamodels.apimodels.Drug;
import connexus.datamodels.apimodels.InputAccept;
import connexus.datamodels.apimodels.Prescriber;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.json.JSONArray;
import org.json.JSONObject;
import prm.erx.ERXUtility.ErxUtils;
import java.util.HashMap;


public class ConexusAPIWrapper {
    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReader.getInstance();
    ErxUtils erxUtils = new ErxUtils();
    ServiceRequest requestBody = new ServiceRequest();
    ServiceResponse resp=new ServiceResponse();
    InputAccept inputAccept = new InputAccept();
    Drug drug = new Drug();
    Prescriber prescriber = new Prescriber();

    public ConexusAPIWrapper() {
        prop.loadCustomProperties("config/prm/erx/");
    }

    private HashMap<String, String> getHeaders() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        return headers;
    }

    public InputAccept createErxInputAcceptRequest(String storeNbr, String rxId, String inputId, String patientId, String prescriberId, String clinicId, String rxWrittenDate, String rxExpDate, String orderId, String orderSeqNbr, String priorityId, String rxFillId, int dispensedProductId, int dispensedItemtId, int drugControlCode, String drugName, String gpi, int multiSrcCode, String ndc){
        Reporter.log("Create Input Accept Request body");
        inputAccept.setRxId(Integer.parseInt(rxId));
        inputAccept.setInputId(Integer.parseInt(inputId));
        inputAccept.setPriorityId(Integer.parseInt(priorityId));
        inputAccept.setPatientId(Integer.parseInt(patientId));
        inputAccept.setRxFillId(Integer.parseInt(rxFillId));
        inputAccept.setOrderId(Integer.parseInt(orderId));
        inputAccept.setOrderSeqNbr(Integer.parseInt(orderSeqNbr));
        inputAccept.setSiteID(Integer.parseInt(storeNbr));
        Reporter.log("Request Payload for Drug");
        drug.setName(drugName);
        drug.setGpiCode(gpi);
        drug.setControlCode(drugControlCode);
        drug.setItemId(dispensedItemtId);
        drug.setPresMultiSrcCode(multiSrcCode);
        drug.setRxProdId(dispensedProductId);
        drug.setNdc(ndc);
        inputAccept.setDrug(drug);
        inputAccept.setPrescriber(prescriber);
        inputAccept.setRxWrittenDate(erxUtils.dbDateToEpoch(rxWrittenDate));
        inputAccept.setRxExpDate(erxUtils.dbDateToEpoch(rxExpDate));
        inputAccept.setFillDate(erxUtils.dbDateToEpoch(rxWrittenDate));
        String pickdate = erxUtils.getFutureDate();
        inputAccept.setPickUpDate(erxUtils.dbDateToEpoch(pickdate));
        inputAccept.setInputPickUpDate(erxUtils.dateToInputRxPickUpDate());
        inputAccept.setInputRxExpDate(erxUtils.dateToInputRxExpDate());
        return inputAccept;
    }
    public ServiceResponse connexusWrapperErxInputAcceptAPI(InputAccept erxInputAccept) {

        requestBody.setRequestPayload(inputAccept);
        requestBody.setHeaders(getHeaders());
        requestBody.setUrl(prop.getProperty("prm.connexusWrapper.erxInputAcceptUrl"));
        Reporter.log("Erx Input Accept Request endpoint: " + requestBody.getUrl());
        Reporter.logJSON("Erx Input Accept Request", inputAccept);
        resp = am.getRestContext().performPost(requestBody);
        Reporter.log("Service Actual Response StatusCode : " + resp.getStatusCode());
        Reporter.logXML("HTTP Response :  " + "\n", resp.getDataResponse());
        return resp;
    }

    public ServiceResponse conexusWrapperErxEODapi(InputAccept erxInputAccept) {
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonData = new JSONObject(erxInputAccept);
        requestBody.setRequestPayload(jsonArray.put(jsonData).toString());
        requestBody.setHeaders(getHeaders());
        requestBody.setUrl(prop.getProperty("prm.connexusWrapper.newOrderToEODUrl"));
        Reporter.log("NewOrderToEOD Request endpoint: " + requestBody.getUrl());
        Reporter.logJSON("NewErxOrderToEOD Request", jsonArray.put(jsonData).toString());
        resp = am.getRestContext().performPost(requestBody);
        Reporter.log("NewERXOrderToEOD Response StatusCode : " + resp.getStatusCode());
        Reporter.logJSON("NewERXOrderToEOD Response", resp.getDataResponse());
        return resp;
    }
}
