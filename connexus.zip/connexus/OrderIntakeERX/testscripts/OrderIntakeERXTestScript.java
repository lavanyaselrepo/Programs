package connexus.OrderIntakeERX.testscripts;
import com.aventstack.extentreports.Status;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import connexus.ConnexusTestScripts;
import connexusharnessapi.utils.DBUtils;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.connexus.PatientProfileModel;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Poller;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.forklift.org.apache.commons.io.FileUtils;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.CreatePatientRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.InsuranceDetails;
import hwqe.baseframework.connexuscontext.LoginAs;
import java.util.Map;

import static connexus.e2e.testcases.E2E_TestCases.loginUser_Type;

public class OrderIntakeERXTestScript extends ConnexusTestScripts {

    private static ServiceResponse response;

    public OrderIntakeERXTestScript(LoginAs.userType loginUserType) {
        super(loginUserType);
    }

    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;
    ServiceRequest req = new ServiceRequest();
    int patientID, siteId;
    String firstName, lastName;
    PropertyReader prop = PropertyReader.getInstance();
    DBUtils dbUtils = new DBUtils();
    String fillId, newFillId, originalFillId;


    public OrderIntakeERXTestScript() {
        prop.loadCustomProperties("config/connexus/");
        prop.loadCustomProperties("config/connexustestharness/");
        prop.loadCustomProperties("config/fom/");
    }

    /**
     * Method to check if RX is in 4 point Queue (returns boolean for conditional logic)
     **/
    public boolean isRxIn4PointQueue() {
        try {
            Reporter.log("Waiting 30 seconds for ERx processing to complete...");
            Thread.sleep(60000);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            siteId = Integer.parseInt(prop.getProperty("cnx.store"));
            rxNbr = getRxNbr(name[0], name[1], siteId);
            if (rxNbr == null || rxNbr.isEmpty()) {
                Reporter.log("Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                return false;
            }
            return checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue());
        } catch (Throwable e) {
            Reporter.log("Error checking 4 Point queue: " + e.getMessage());
            return false;
        }
    }

    public String performERXForPet(Map<String, String> inputData, String xmlPath) throws SQLException, ParserConfigurationException, IOException, SAXException {
        File xmlData;
        String inputPayload, ndc, drugName;
        String[] name = connexusAppUtils.readPatientNameFromFile();
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        //connect to store DB
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        //get pet patient id
        patientID = Integer.parseInt(connexusAppUtils.getPatientId(name[0], name[1]));
        //get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientID);
        //get xml file to generate input payload
        xmlData = new File(xmlPath);
        ndc = inputData.get("DRUG_NAME");
        drugName = inputData.get("DRUG_NAME");
        Reporter.log("Drug name :" + drugName);
        //update the xml with required storeNbr, Date-time and a unique messageId
        String generatedString = RandomStringUtils.randomAlphanumeric(10);
        String updateMsgId = String.valueOf(siteId) + generatedString;
        inputPayload = updateXML(xmlData, String.valueOf(siteId), updateMsgId, patientInfo, ndc, drugName);
        Log.info("inputPayload:" + inputPayload);
        //drop ERX order
        dropERX(inputPayload, String.valueOf(siteId), patientID, updateMsgId);
        return updateMsgId;
    }

    @Override
    public String performERX(Map<String, String> inputData, String xmlPath, boolean verifyOrder) throws SQLException, ParserConfigurationException, IOException, SAXException {
        File xmlData;
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String messageId, inputPayload, ndc, drugName;
        String storeId = prop.getProperty("cnx.store");
        if (storeId.length() == 4) {
            storeId = "0" + storeId;
        }

        // Connect to store DB
        IDatabaseContext cnx = automationManager.getConnexusDB(Integer.parseInt(storeId));
        // Get patient ID
        patientID = Integer.parseInt(connexusAppUtils.getPatientId(name[0], name[1]));
        // Get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientID);
        // Get XML file to generate input payload
        xmlData = new File(xmlPath);
        ndc = inputData.get("DRUG_NAME");
        drugName = inputData.get("DRUG_NAME");
        Reporter.log("Drug name: " + drugName);
        // Update the XML with required storeNbr, Date-time, and a unique messageId
        String generatedString = RandomStringUtils.randomAlphanumeric(10);
        String updateMsgId = storeId + generatedString;
        inputPayload = updateXML(xmlData, storeId, updateMsgId, patientInfo, ndc, drugName);
        Log.info("inputPayload: " + inputPayload);
        // Drop ERX order
        dropERX(inputPayload, storeId, patientID, updateMsgId);
        //verification order creation
        if (verifyOrder) {
            verifyOrderCreation(updateMsgId);
        }
        return updateMsgId;
    }

    public String performERXFutureDate(Map<String, String> inputData, String xmlPath, boolean verifyOrder) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        File xmlData;
        String inputPayload, ndc, drugName;
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        //connect to store DB
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        //get pet patient id
        patientID = Integer.parseInt(connexusAppUtils.getPatientId(name[0], name[1]));
        //get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientID);
        //get xml file to generate input payload
        xmlData = new File(xmlPath);
        ndc = inputData.get("DRUG_NAME");
        drugName = inputData.get("DRUG_NAME");
        Reporter.log("Drug name :" + drugName);
        //update the xml with required storeNbr, Date-time and a unique messageId
        String generatedString = RandomStringUtils.randomAlphanumeric(10);
        String updateMsgId = String.valueOf(siteId) + generatedString;
        inputPayload = updateXMLWithFutureMedicationDate(xmlData, String.valueOf(siteId), updateMsgId, patientInfo, ndc, drugName);
        Log.info("inputPayload:" + inputPayload);
        //drop ERX order
        dropERX(inputPayload, String.valueOf(siteId), patientID, updateMsgId);
        //verification order creation
        if (verifyOrder) {
            verifyOrderCreation(updateMsgId);
        }
        return updateMsgId;
    }

    public String performERXFourPoint(Map<String, String> inputData, String xmlPath, boolean verifyOrder) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        File xmlData;
        String messageId, inputPayload, ndc, drugName;
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        //connect to store DB
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        //get pet patient id
        patientID = Integer.parseInt(connexusAppUtils.getPatientId(name[0], name[1]));
        //get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientID);
        //get xml file to generate input payload
        xmlData = new File(xmlPath);
        ndc = inputData.get("DRUG_NAME");
        drugName = dbUtils.getDrugName(cnx, inputData.get("DRUG_NAME"));
        Reporter.log("Drug name :" + drugName);
        //update the xml with required storeNbr, Date-time and a unique messageId
        String generatedString = RandomStringUtils.randomAlphanumeric(10);
        String updateMsgId = String.valueOf(siteId) + generatedString;
        inputPayload = updateXMLWithFutureMedicationDateValidation(xmlData, String.valueOf(siteId), updateMsgId, patientInfo, ndc, drugName);
        Log.info("inputPayload:" + inputPayload);
        //drop ERX order
        dropERX(inputPayload, String.valueOf(siteId), patientID, updateMsgId);
        //verification order creation
        if (verifyOrder) {
            verifyOrderCreation(updateMsgId);
        }
        return updateMsgId;
    }

    public void performInputVerifications(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxModel.setNdc(inputData.get("DRUG_NAME"));
            rxModel.setPrescribedQty(inputData.get("QUANTITY"));
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            String priority = orderSearch.getPriorityForPatient(name[0] + "," + name[1], 0);
            Assert.assertEquals(priority, "Dr. Call In");
            if (rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue())) {
                int rxDays = this.getRxDaysControlled();
                this.performInputVerifyExpirationDate(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxModel.getNdc(), rxModel.getPrescribedQty(), rxModel.getSigCode(), rxModel.getNoOfRefills(), rxDays);
                automationManager.getConnexusWorkFlow().performInput(rxModel);
            } else {
                Reporter.log("RX is not in Input queue");
                Assert.fail();
            }
        } catch (Exception e) {
            Reporter.log("Test failed at Input queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performInputVerifyExpirationDate(String patientName, String ndc, String prescribedQty, String sigCode, String refills, int rxDaysNum) throws ParseException {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(patientName);
            orderSearch.openFirstPatientRecord();
            inputPage.enterNdc(ndc);
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(prescribedQty);
            inputPage.enterSigCode(sigCode);
            inputPage.enterRefillQty(refills);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate expirationDate = LocalDate.parse(inputPage.getExpirationDate(), dtf);
            LocalDate earliestFillDate = LocalDate.parse(inputPage.getEarliestFillDate(), dtf);
            long daysDifference = ChronoUnit.DAYS.between(earliestFillDate, expirationDate);
            Assert.assertEquals(daysDifference, rxDaysNum);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.launchModifyDetailScreen();
            LocalDate modifyExpDate = LocalDate.parse(modifyDetails.getExpDateValue(), dtf);
            LocalDate modifyEarliestFillDate = LocalDate.parse(modifyDetails.getEarliestFillDate(), dtf);
            long daysDiffModifyDetails = ChronoUnit.DAYS.between(modifyEarliestFillDate, modifyExpDate);
            Assert.assertEquals(daysDiffModifyDetails, rxDaysNum);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickCancel();
            modifyDetails.clickYes();
        } catch (Exception e) {
            Reporter.log("Test failed at 4 Point queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void perform4PointVerifications() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(name[0] + "," + name[1]);
            }
            if (checkOrderQueueDB(name[0] + "," + name[1], WorkQueueSettings.wm4PointCheck.getValue())) {
                Reporter.log("Order is in 4 point");
            } else {
                Reporter.log("Rx didn't reach fourpoint and landed in input instead");
                Assert.fail();
            }
            String priority = orderSearch.getPriorityForPatient(name[0] + "," + name[1], 0);
            Assert.assertTrue(priority.contains("Future"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);
            super.performChkDUR();
        } catch (Exception e) {
            Reporter.log("Test failed at 4 Point queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyAttendingPhysicianNotDisplayedIn4Point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(name[0] + "," + name[1]);
            }
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            fourPoint.verifyAttendingPhysicianNotDisplayed();
        } catch (Exception e) {
            Reporter.log("Test failed at 4 Point queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyProblemResolvedButtonInResolution() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            ResolutionPage resolutionPage = new ResolutionPage();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.selectRowFromSearch(0);
            boolean PRDisabled = resolutionPage.IsProblemSolvedElementDisabled();
            Assert.assertFalse(PRDisabled);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            String actualText = resolutionPage.reasonTextExist();
            if (actualText.contains("Waiting For Filling-Future Date.")) {
                Assert.assertTrue(true);
            } else {
                Assert.fail();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            resolutionPage.clickCancel();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    @Override
    public DataRow getPatientInfo(IDatabaseContext cnx, int patientId) {
        String getPatientInfo = "select last_name, first_name, gender_code, birth_date from rx21c:informix.patient \n" +
                "where patient_id = " + patientId + ";";
        DataTable dt = cnx.getDataTable(getPatientInfo);
        Assert.assertEquals(dt.getRowCount(), 1);
        DataRow row = dt.getDataRows().get(0);
        return row;
    }

    @Override
    public String updateXML(File xmlData, String storeNbr, String messageId, DataRow patientInfo, String ndc, String drugName)
            throws ParserConfigurationException, SAXException, IOException {
        String fileContext = FileUtils.readFileToString(xmlData, StandardCharsets.UTF_8);
        fileContext = fileContext.replaceAll("storeNbr", storeNbr);
        fileContext = fileContext.replaceAll("messageId", messageId);
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedDate = today.format(formatter);
        String currentTime = getCurrentTime();
        fileContext = fileContext.replaceAll("sentTime", currentTime);
        fileContext = fileContext.replaceAll("effectiveDate", formattedDate);
        fileContext = fileContext.replaceAll("writtenDate", currentTime);
        fileContext = fileContext.replaceAll("patientLastName", patientInfo.getValue("last_name").toString().trim());
        fileContext = fileContext.replaceAll("patientFirstName", patientInfo.getValue("first_name").toString().trim());
        fileContext = fileContext.replaceAll("patientGender", patientInfo.getValue("gender_code"));
        fileContext = fileContext.replaceAll("patientDOB", patientInfo.getValue("birth_date").toString());
        fileContext = fileContext.replaceAll("drugName", drugName);
        fileContext = fileContext.replaceAll("ndc", ndc);
        return fileContext;
    }

    public String updateXMLWithFutureMedicationDate(File xmlData, String storeNbr, String messageId, DataRow patientInfo, String ndc, String drugName)
            throws ParserConfigurationException, SAXException, IOException {

        String fileContext = FileUtils.readFileToString(xmlData, StandardCharsets.UTF_8);
        fileContext = fileContext.replaceAll("storeNbr", storeNbr);
        fileContext = fileContext.replaceAll("messageId", messageId);
        String currentTime = getCurrentTime();
        LocalDate today = LocalDate.now();
        // Subtract 3 days
        LocalDate threeDaysAfter = today.plusDays(3);
        // Format the date as "yyyy-MM-dd"
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedDate = threeDaysAfter.format(formatter);
        fileContext = fileContext.replaceAll("sentTime", currentTime);
        fileContext = fileContext.replaceAll("effectiveDate", formattedDate);
        fileContext = fileContext.replaceAll("writtenDate", currentTime);
        fileContext = fileContext.replaceAll("patientLastName", patientInfo.getValue("last_name").toString().trim());
        fileContext = fileContext.replaceAll("patientFirstName", patientInfo.getValue("first_name").toString().trim());
        fileContext = fileContext.replaceAll("patientGender", patientInfo.getValue("gender_code"));
        fileContext = fileContext.replaceAll("patientDOB", patientInfo.getValue("birth_date").toString());
        fileContext = fileContext.replaceAll("drugName", drugName);
        fileContext = fileContext.replaceAll("ndc", ndc);
        return fileContext;
    }

    @Override
    public String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String Ts = sdf.format(timestamp);
        return Ts;
    }

    @Override
    public void dropERX(String inputPayload, String storeNbr, int patientId, String messageId) {
        //drop ERX via POST
        headers.put("content-type", "application/xml");
        headers.put("User-Agent", "PostmanRuntime/7.28.4");
        headers.put("Accept", "*/*");
        headers.put("Accept-Encoding", "gzip, deflate, br");
        headers.put("Connection", "keep-alive");
        headers.put("wm_consumer.id", prop.getProperty("prm.erx.dpremoval.wm_consumer.id"));
        req.setHeaders(headers);
        req.setUrl("https://hw-erx-inbound-processor.stg.walmart.net/api/v2017/erx");
        req.setRequestPayload(inputPayload);
        Reporter.logXML("ReqPayload: ", req.getRequestPayload());
        resp = automationManager.getRestContext().performPost(req);
        Reporter.log("Response status code is" + resp.getStatusCode());
        //verify POST request is successful
        Assert.assertEquals(resp.getStatusCode(), 200, "POST request returned error");
        Reporter.log("ERX order posting successful for patientId = " + patientId + " in store # " + storeNbr +
                ". The resp message_id is " + messageId);
    }

//Use Patient Name in UpdateXML
public String updateXMLwithPatientName(File xmlData, String storeNbr, String messageId, String lastName, String firstName, String ndc, String drugName)
        throws ParserConfigurationException, SAXException, IOException {
    String fileContext = FileUtils.readFileToString(xmlData, StandardCharsets.UTF_8);
    fileContext = fileContext.replaceAll("storeNbr", storeNbr);
    fileContext = fileContext.replaceAll("messageId", messageId);
    LocalDate today = LocalDate.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    String formattedDate = today.format(formatter);
    String currentTime = getCurrentTime();
    fileContext = fileContext.replaceAll("sentTime", currentTime);
    fileContext = fileContext.replaceAll("effectiveDate", formattedDate);
    fileContext = fileContext.replaceAll("writtenDate", currentTime);
    fileContext = fileContext.replaceAll("patientLastName", lastName.toString().trim());
    fileContext = fileContext.replaceAll("patientFirstName", firstName.toString().trim());
    fileContext = fileContext.replaceAll("drugName", drugName);
    fileContext = fileContext.replaceAll("ndc", ndc);
    return fileContext;
}

    @Override
    public void verifyOrderCreation(String messageId) {
        try {
            Poller poller = new Poller(30, 500);
            boolean isOrderCreated = poller.pollForSuccess(() -> {
                String queryMsg = "select * from raw_eltnc_rx_resp where resp_message_id = '" + messageId + "'";
                Map<String, Object> resultSet = automationManager.getConnexusDB().executeQuery(queryMsg);
                return resultSet != null && !resultSet.isEmpty() && (short) resultSet.get("response_stat_code") == 26005;
            });
            if (isOrderCreated) {
                Reporter.log("ERX order successfully created for messageId: " + messageId);
            } else {
                Assert.fail("ERX order creation failed for messageId: " + messageId);
            }
        } catch (Throwable e) {
            Assert.fail("Exception during order creation verification: " + e.toString());
        }
    }

    public int getRxDaysControlled() {
        String pharmQuery = "select * from issuing_agency where state_prov_code=(select state from bus_unit_addr) limit 1";
        Map<String, Object> resultSet = automationManager.getConnexusDB().executeQuery(pharmQuery);
        int issueCode = (int) resultSet.get("issue_agency_code");
        String rxDaysQuery = "select * from agncy_class_rqmt where issue_agency_code =" + issueCode + " and drug_control_code ='2300'";
        Map<String, Object> rxDays = automationManager.getConnexusDB().executeQuery(rxDaysQuery);
        return (short) rxDays.get("rx_days_qty");
    }

    public void verifyInStatePrescriberPopup() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            inputPage.checkIfDaysFillPopUpIsDisplayed();
            String text = inputPage.getTextOnErrorMsg();
            Assert.assertEquals(text, "This controlled prescription requires a prescriber with an in-state address. Validate that the correct prescriber and address have been entered or cancel the prescription. Notify the patient and prescriber.");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickButtonOk();
            inputPage.clickBtnCancel();
            inputPage.clickYesOnAbondonPopup();
        } catch (Exception e) {
            Reporter.log("Test failed at Instate popup verification");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validatingExpiryDateInFourPoint() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(name[0] + "," + name[1]);
            }
            int rxDays = this.getRxDaysControlled();
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            Reporter.log("Rx status" + rxStatus);
            this.perform4PointVerifyExpirationDate(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxDays);
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at four point");
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void perform4PointVerifyExpirationDate(String patientName, int rxDaysNum) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(patientName);
            orderSearch.openFirstPatientRecord();
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            modifyDetails.launchModifyDetailScreen();
            Reporter.log("Earliest fill date" + modifyDetails.getEarliestFillDateValue());
            LocalDate modifyExpDate = LocalDate.parse(modifyDetails.getExpDateValue(), dtf);
            LocalDate modifyEarliestFillDate = LocalDate.parse(modifyDetails.getEarliestFillDateValue(), dtf);
            long daysDiffModifyDetails = ChronoUnit.DAYS.between(modifyEarliestFillDate, modifyExpDate);
            Assert.assertEquals(daysDiffModifyDetails, rxDaysNum);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertNotEquals(modifyDetails.getExpDateValue(), modifyDetails.getEarliestFillDateValue());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickCancel();
            modifyDetails.clickYes();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at four point");
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public String updateXMLWithFutureMedicationDateValidation(File xmlData, String storeNbr, String messageId, DataRow patientInfo, String ndc, String drugName)
            throws ParserConfigurationException, SAXException, IOException {

        String fileContext = FileUtils.readFileToString(xmlData, StandardCharsets.UTF_8);
        fileContext = fileContext.replaceAll("storeNbr", storeNbr);
        fileContext = fileContext.replaceAll("messageId", messageId);
        String currentTime = getCurrentTime();

        LocalDate today = LocalDate.now();
        // adding 10 days
        LocalDate TenDaysAfter = today.plusDays(10);
        // Format the date as "yyyy-MM-dd"
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedDate = TenDaysAfter.format(formatter);
        fileContext = fileContext.replaceAll("sentTime", currentTime);
        fileContext = fileContext.replaceAll("effectiveDate", formattedDate);
        fileContext = fileContext.replaceAll("writtenDate", currentTime);
        fileContext = fileContext.replaceAll("patientLastName", patientInfo.getValue("last_name").toString().trim());
        fileContext = fileContext.replaceAll("patientFirstName", patientInfo.getValue("first_name").toString().trim());
        fileContext = fileContext.replaceAll("patientGender", patientInfo.getValue("gender_code"));
        fileContext = fileContext.replaceAll("patientDOB", patientInfo.getValue("birth_date").toString());
        fileContext = fileContext.replaceAll("drugName", drugName);
        fileContext = fileContext.replaceAll("ndc", ndc);
        return fileContext;
    }

    public void validatingExpiryDateIn4PTQueue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            int rxDays = this.getRxDaysControlledValidation();
            System.out.println("Daya :" + rxDays);
            Reporter.log("expiration date = written date + rx_days_qty  expected");
            this.performExpirationDateIn4PT(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxDays);
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performExpirationDateIn4PT(String patientName, int rxDaysNum) throws ParseException {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            modifyDetails.launchModifyDetailScreen();
            SimpleDateFormat sdformat = new SimpleDateFormat("MM/dd/yyyy");
            Date expDate = sdformat.parse(modifyDetails.getExpDateValue());
            Date writtenDate = sdformat.parse(modifyDetails.getWrittenDateValue());
            long timeDiffMillis = expDate.getTime() - writtenDate.getTime();
            long daysDiffModifyDetails = TimeUnit.MILLISECONDS.toDays(timeDiffMillis);
            Assert.assertEquals(daysDiffModifyDetails, rxDaysNum);
            Assert.assertNotEquals(modifyDetails.getExpDateValue(), modifyDetails.getWrittenDateValue());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("As expected the expiry date equals to 180 + written date");
            modifyDetails.clickCancel();
            modifyDetails.clickYes();
        } catch (ParseException e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("failed to parse date :" + e.getMessage());
            Assert.fail("date parsing failed");
        } catch (Exception e) {
            Reporter.log("Unexpected error :" + e.getMessage());
            Assert.fail("Test failed");
        }
    }

    public int getRxDaysControlledValidation() {
        String pharmQuery = "select * from issuing_agency where state_prov_code=(select state from bus_unit_addr) limit 1";
        Map<String, Object> resultSet = automationManager.getConnexusDB().executeQuery(pharmQuery);
        int issuecode = (int) resultSet.get("issue_agency_code");
        String rxDaysQuery = "select * from agncy_class_rqmt where issue_agency_code =" + issuecode + " and drug_control_code ='2301'";
        Map<String, Object> rxDays = automationManager.getConnexusDB().executeQuery(rxDaysQuery);
        short days = (short) rxDays.get("rx_days_qty");
        return days;
    }

    public void inputforAP() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();

            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            orderSearch.openFirstPatientRecord();
            if (inputPage.isAttendingPhysicianTabDisplayed()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("All details are filled in input and input screen is present with Attending physician Tab");
            }
            inputPage.clickCancel();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performInputTillAccept(Map<String, String> inputData) {

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        if (isOrderInInputQueueDB(name[0], name[1], 1)) {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
        } else {
            Reporter.log("RX is not in Input queue");
            Assert.fail("RX is not in Input queue");
        }
    }

    /**
     * Method to Host pull the Patient Details from Another store.
     *
     * @param inputData
     */
    public void hostPullPatient(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(lastName + "," + firstName);
            patientSearchPage.inputPatientDob(inputData.get("DOB"));
            patientSearchPage.clickSearchNow();
            patientSearchPage.hostSearchPatient();
            patientSearchPage.doubleClickOnSearchGridRowforPatient(1);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickSaveAndClose();
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * Method to create Patient using API
     * Supports both Cash patients and patients with TP (Third Party) insurance plans.
     * For TP patients, provide the following columns in inputData:
     *   - patientHasInsurance: "true"
     *   - carrierPlanId: insurance carrier plan ID
     *   - carrierCompanyCode: insurance carrier company ID
     *   - billSeqNbr: billing sequence number (default: 1)
     *   - cardHolderId: cardholder ID (e.g., TP_CARD_ID)
     *   - cardHolderFirstName: cardholder first name
     *   - cardHolderLastName: cardholder last name
     *   - relationshipCode: relationship code (default: 3201)
     *   - coverageIndicator: coverage indicator (default: "Y")
     *   - covExpDate: coverage expiration date
     *   - planTypeCode: plan type code (default: 1000)
     *
     * @param inputData patient information from input Excel
     */
    public void createPatient(Map<String, String> inputData) throws JsonProcessingException {

        ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        lastName = name[0];
        firstName = name[1];
        try {
            boolean hasInsurance = "true".equalsIgnoreCase(inputData.get("patientHasInsurance"));

            if (hasInsurance && isNotEmpty(inputData.get("carrierPlanId")) && isNotEmpty(inputData.get("carrierCompanyCode"))) {
                CreatePatientRequest createPatientRequest = new CreatePatientRequest();
                InsuranceDetails insuranceDetails = new InsuranceDetails();

                createPatientRequest.setFirstName(firstName);
                createPatientRequest.setLastName(lastName);
                createPatientRequest.setSiteId(connexusAppUtils.getStoreId());
                createPatientRequest.setDob(inputData.get("dob"));
                createPatientRequest.setHomePhone(inputData.get("PRIMARY_NUMBER"));
                createPatientRequest.setWorkPhone(inputData.get("WORK_PHONE"));
                createPatientRequest.setCellPhone(inputData.get("CELL_PHONE"));

                createPatientRequest.setPatientHasInsurance(true);
                insuranceDetails.setInsuranceCarrierPlanId(Integer.parseInt(inputData.get("carrierPlanId")));
                insuranceDetails.setInsuranceCarrierCompanyId(Integer.parseInt(inputData.get("carrierCompanyCode")));
                insuranceDetails.setBillingSeqNbr(isNotEmpty(inputData.get("billSeqNbr")) ? Integer.parseInt(inputData.get("billSeqNbr")) : 1);
                insuranceDetails.setCardholderId(isNotEmpty(inputData.get("cardHolderId")) ? inputData.get("cardHolderId") : inputData.get("TP_CARD_ID"));
                insuranceDetails.setCardholderFirstName(isNotEmpty(inputData.get("cardHolderFirstName")) ? inputData.get("cardHolderFirstName") : firstName);
                insuranceDetails.setCardholderLastName(isNotEmpty(inputData.get("cardHolderLastName")) ? inputData.get("cardHolderLastName") : lastName);
                insuranceDetails.setRelationshipCode(isNotEmpty(inputData.get("relationshipCode")) ? Integer.parseInt(inputData.get("relationshipCode")) : 3201);
                insuranceDetails.setCoverageInd(isNotEmpty(inputData.get("coverageIndicator")) ? inputData.get("coverageIndicator") : "Y");
                insuranceDetails.setCoverageExpDate(isNotEmpty(inputData.get("covExpDate")) ? inputData.get("covExpDate") : null);
                insuranceDetails.setInsPlanTypeCode(isNotEmpty(inputData.get("planTypeCode")) ? Integer.parseInt(inputData.get("planTypeCode")) : 1000);
                insuranceDetails.setSplitBillInd("");

                createPatientRequest.setInsurance(insuranceDetails);
                int patientId = connexusAPIManager.createPaientWithOrWithoutTP(createPatientRequest);
                Reporter.log("Created patient with TP plan. Patient ID: " + patientId);
            } else {
                Long homePhone = Long.parseLong(inputData.get("PRIMARY_NUMBER"));
                Long workPhone = Long.parseLong(inputData.get("WORK_PHONE"));
                Long cellPhone = Long.parseLong(inputData.get("CELL_PHONE"));
                response = connexusAPIManager.createPatient(firstName, lastName, inputData.get("dob"), connexusAppUtils.getStoreId(), homePhone, workPhone, cellPhone);
                JSONObject res = new JSONObject(response);
                String dataresponse = res.optString("dataResponse", null);
                if (dataresponse != null) {
                    JSONObject innerres = new JSONObject(dataresponse);
                    firstName = innerres.optString("firstName", null);
                    lastName = innerres.optString("lastName", null);
                }
                Reporter.log("Created patient without TP plan (Cash).");
            }
        } catch (Exception e) {
            Reporter.log("Failed to create patient: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private boolean isNotEmpty(String value) {
        return value != null && !value.trim().isEmpty();
    }

    public void addSecondaryThirdPartyDetails(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String patCarrier = inputData.get("TP_CARRIER_BIN_2");
            String patPlan = inputData.get("TP_PLAN_2");
            String patCardId = inputData.get("TP_CARD_ID_2");
            patientMaintenancePage.addAdditionalTPPlan(patCarrier, patPlan, patCardId);
            Reporter.logScreenShot(Status.PASS, "Added Third party Details", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            softAssert.assertAll();
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    @Override
    public void performFourPointWithOnHoldStatus() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            if (fourPoint.isElementDisplayed(fourPoint.rdbNonAcute, 1)) {
                fourPoint.click(fourPoint.rdbNonAcute);
            }
            if (!fourPoint.onHoldButtonSelected()) {
                fourPoint.unCheckOnHold();
            }
            fourPoint.chkName();
            fourPoint.chkPrescribed();
            if (fourPoint.ischkStrength()) {
                fourPoint.chkStrength();
            }
            fourPoint.chkSIG();
            if (fourPoint.isElementDisplayed(fourPoint.chkDEA, 1)) {
                fourPoint.click(fourPoint.chkDEA);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            fourPoint.clickAccept();
            Reporter.log("4 point completed");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at 4 Point queue");
        }
    }

    public void verifyRxMovedToFourPointWithOnHoldSelected() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            rxNbr = orderSearch.getRxNbr(0);
            Reporter.log("Rx number is " + rxNbr);
            if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
                if (!checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                    Assert.fail("Rx is not in 4 point");
                }
            }
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            if (fourPoint.onHoldButtonSelected()) {
                Assert.assertTrue(true);
                Reporter.log("Rx moved to 4 point with On Hold Checkbox selected by default");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
                fourPoint.clickBtnCancel();
            } else {
                Assert.fail("On Hold Checkbox not selected");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void validateRxStatusOnF7screen(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(rxNbr);
            rxLookUp.clickSearch();
            rxLookUp.getRxStatus();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(rxLookUp.getRxStatus(), inputData.get("HOLD_STATUS"));
            Reporter.log("Rx status showing as Hold in F7 screen");
            fillId = String.valueOf(connexusAppUtils.getFillId(rxNbr));
            Reporter.log("Fill id " + fillId);

        } catch (Throwable e) {
            isExceptionCaptured = true;
            Assert.fail("Rx status not on Hold");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void validateNewFillIdNotCreated() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            newFillId = String.valueOf(connexusAppUtils.getFillId(rxNbr));
            Assert.assertEquals(newFillId, fillId);
            Reporter.log("New Fill id not created");
            menuBar.pressKeys(KeyEvent.VK_ESCAPE);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Assert.fail("New Fill id created");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void updatePatientDetailsInModifyDetailsScreen(Map<String, String> inputData) {

        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            modifyDetails.launchModifyDetailScreen();
            modifyDetails.clearDespQty();
            modifyDetails.enterDespQty(inputData.get("UPDATED_QTY"));
            modifyDetails.clearSigField();
            modifyDetails.enterSig(inputData.get("UPDATED_SIGCODE"));
            modifyDetails.clearPrescriberName();
            modifyDetails.enterPrescriber(inputData.get("UPDATED_PRESCRIBER"));
            Reporter.log("Qty, Sig Code and Prescriber details are updated");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickAccept();
            inputPage.clickOnOutofStockPopupOk();
            menuBar.pressKeys(KeyEvent.VK_ESCAPE);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Assert.fail("Rx status not on Hold");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void performCancelFillShouldBeOnHoldAtModifyDetailsScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            menuBar.selectNavigation(AppMenu.SHOUD_BE_ON_HOLD, AppMenuItemsIndex.CURRENTRX_CANCEL_FILL, AppMenuSubItemsIndex.SHOULD_BE_ON_HOLD, null);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickButtonYes();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(rxNbr);
            rxLookUp.clickSearch();
            rxLookUp.getRxStatus();
            Reporter.logScreenShot(Status.PASS, "RX Status", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Rx status is ON-Hold with cancelled status");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Failed to cancel fill from modify details screen");
            Assert.fail(e.toString());
        }
    }

    public void validateRxStatusForOriginalFillAndNewFill(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(rxNbr);
            rxLookUp.clickSearch();
            rxLookUp.getRxStatusOriginalFill();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(rxLookUp.getRxStatusOriginalFill(), inputData.get("Original_Fill_Status"));
            Reporter.log("Original Fill status is Cancelled in F7 screen");
            originalFillId = rxLookUp.getOriginalfillId();
            Reporter.log("originalFillId " + originalFillId);
            rxLookUp.getRxStatus();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(rxLookUp.getRxStatus(), inputData.get("HOLD_STATUS"));
            Reporter.log("New Fill status is Hold in F7 screen");
            newFillId = rxLookUp.getNewfillId();
            Reporter.log("newfillId " + newFillId);
            menuBar.pressKeys(KeyEvent.VK_ESCAPE);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Assert.fail("Rx status not on Hold");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void validateTriplicateValue(Map<String, String> inputData, boolean isERX) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.selectRowFromSearch(0);
            inputPage.enterProductNameInPrescribedProduct(inputData.get("DRUG_NAME"));
            String triplicate = inputPage.readTriplicateValue();
            Reporter.log("autopopulated Triplicate is " + triplicate);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            if (inputPage.isTriplicateDisplayed()) {
                Reporter.logScreenShot(Status.PASS, "Triplicate Number is displayed for C2 drug", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                triplicate = inputPage.readTriplicateValue();
                Reporter.log("autopopulated Triplicate is " + triplicate);
                if(isERX) {
                    Assert.assertEquals(triplicate, inputData.get("TRIPLICATE_NY"));
                } else {
                    Assert.assertEquals(triplicate, inputData.get("TRIPLICATE"));
                }
            }else {
                   Reporter.logScreenShot(Status.FAIL, "Triplicate Number is not displayed for C2 drug", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                   Assert.fail("Triplicate number should be displayed for C2 drug");
            }
            inputPage.clickAccept();
           Reporter.log("Input Accepted");
        } catch (Throwable e) {
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public void validateTriplicateInput(Map<String, String> inputData, boolean triplicateDisplay) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            ConnexusStartPage connexusStartPage = new ConnexusStartPage();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.selectRowFromSearch(0);
            inputPage.enterProductNameInPrescribedProduct(inputData.get("DRUG_NAME"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            if(!triplicateDisplay) {
                if (!inputPage.isTriplicateDisplayed()) {
                    Reporter.logScreenShot(Status.PASS, "Triplicate Number is not displayed", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    inputPage.clickAccept();
                    inputPage.clickOnOutofStockPopupOk();
                    Reporter.log("Input Accepted");
                }
            }else{
            if (inputPage.isTriplicateDisplayed()) {
                Reporter.logScreenShot(Status.PASS, "Triplicate Number is displayed", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                String triplicate = inputPage.readTriplicateValue();
                Reporter.log("autopopulated Triplicate is " + triplicate);
                Assert.assertEquals(triplicate, inputData.get("TRIPLICATE"));
                inputPage.clickAccept();
                inputPage.clickOnOutofStockPopupOk();
                Reporter.log("Input Accepted");
            } else {
                Reporter.logScreenShot(Status.FAIL, "Triplicate Number is not displayed", inputPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Triplicate number should be displayed");
            }
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public String createERX(Map<String, String> inputData, String xmlPath, boolean verifyOrder) throws SQLException, ParserConfigurationException, IOException, SAXException {
        File xmlData;
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        Log.info(name[0] + ',' + name[1]);
        Reporter.log("Patient Name: "+ name[0] + ',' + name[1]);
        String lastName = name[0];
        String firstName = name[1];
        String messageId, inputPayload, ndc, drugName;
        String storeId = prop.getProperty("cnx.store");
        if (storeId.length() == 4) {
            storeId = "0" + storeId;
        }
        // Connect to store DB
        IDatabaseContext cnx = automationManager.getConnexusDB(Integer.parseInt(storeId));
        // Get patient ID
        patientID = Integer.parseInt(RandomStringUtils.randomNumeric(6));
        // Get XML file to generate input payload
        xmlData = new File(xmlPath);
        ndc = inputData.get("DRUG_NAME");
        drugName = inputData.get("DRUG_NAME");
        Reporter.log("Drug name: " + drugName);
        // Update the XML with required storeNbr, Date-time, and a unique messageId
        String generatedString = RandomStringUtils.randomAlphanumeric(10);
        String updateMsgId = storeId + generatedString;
        inputPayload = updateXMLwithPatientName(xmlData, storeId, updateMsgId, lastName, firstName, ndc, drugName);
        Log.info("inputPayload: " + inputPayload);
        // Drop ERX order
        dropERX(inputPayload, storeId, patientID, updateMsgId);
        //verification order creation
        if (verifyOrder) {
            verifyOrderCreation(updateMsgId);
        }
        return updateMsgId;
    }

    public void validateTriplicateInClaimPage(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            automationManager.performSleep(10);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            claimPage.launchClaimPage();
            claimPage.performClaimSearch(name[0] + "," + name[1]);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(10);
            patientSearchPage.openFirstPatientRecord();
            orderSearch.openFirstPatientRecord();
            claimPage.clickClaimDetailsTab();
            Reporter.log("Claim Details page opened");
            claimPage.clickNCPDPNames();
            if(claimPage.isTriplicateDisplayed()) {
                String triplicateValue = claimPage.readTriplicateCode();
                Reporter.log("autopopulated Triplicate is " + triplicateValue);
                Assert.assertEquals(triplicateValue, inputData.get("TRIPLICATE"));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, claimPage.takeScreenShot(currentStepMethodName).getValue());
            }else {
                Reporter.logScreenShot(Status.FAIL, "Triplicate Number is not displayed", claimPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Triplicate number should be displayed");
            }
            claimPage.closeClaimDetailsScreen();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, claimPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to validate Claims Page Triplicate: " + e.getMessage());
        }
    }

    public void validateTriplicateinModifyDetails(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(10);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.selectRowFromSearch(0);
            Reporter.log("Modify Details page opened");
            if(modifyDetails.isTriplicateDisplayed()){
                Reporter.logScreenShot(Status.PASS, "Triplicate Number is displayed", modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                String triplicate = modifyDetails.readTriplicateCode();
                Reporter.log("autopopulated Triplicate is " + triplicate);
                Assert.assertEquals(triplicate, inputData.get("TRIPLICATE"));
            }else {
                Reporter.logScreenShot(Status.FAIL, "Triplicate Number is not displayed", modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Triplicate number should be displayed");
            }
        }catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to validate Modify Details Page Triplicate: " + e.getMessage());
        }
    }

    public void validateTriplicateInClaimDetails(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            automationManager.performSleep(10);
            claimPage.launchClaimPage();
            claimPage.performClaimSearch(name[0] + "," + name[1]);
            Reporter.logScreenShot(Status.PASS, "Claim Search Page", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(10);
            patientSearchPage.openFirstPatientRecord();
            orderSearch.openFirstPatientRecord();
            claimPage.clickClaimDetailsTab();
            Reporter.log("Claim Details page opened");
            claimPage.clickNCPDPNumbers();
            if(claimPage.isTriplicateDisplayed()) {
                String triplicateValue = claimPage.readTriplicateCode();
                Reporter.log("autopopulated Triplicate is " + triplicateValue);
                Assert.assertEquals(triplicateValue, inputData.get("TRIPLICATE"));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, claimPage.takeScreenShot(currentStepMethodName).getValue());
            }else {
                Reporter.logScreenShot(Status.FAIL, "Triplicate Number is not displayed", claimPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Triplicate number should be displayed");
            }
            claimPage.closeClaimDetailsScreen();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, claimPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to validate Claims Page Triplicate: " + e.getMessage());
        }
    }

    public void selectBrandToGenericFromCurrentRx() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            menuBar.selectBrandToGenericChangeRequest();
            Reporter.log("Selected Brand to Generic change request from Current Rx Menu");
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed at Brand to Generic changes " + e.getMessage());
        }
    }

    public String sendPayloadWithRelatesToMessageId(Map<String, String> inputData, String xmlPath, boolean verifyOrder) throws SQLException, ParserConfigurationException, IOException, SAXException {
        File xmlData;
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String inputPayload, ndc, drugName;
        String storeId = prop.getProperty("cnx.store");
        if (storeId.length() == 4) {
            storeId = "0" + storeId;
        }
        int requestId = connexusAppUtils.getRxRequestId();
        //Get request Id
        Reporter.log("RequestId: " + requestId);
        // Connect to store DB
        IDatabaseContext cnx = automationManager.getConnexusDB(Integer.parseInt(storeId));
        // Get patient ID
        patientID = Integer.parseInt(connexusAppUtils.getPatientId(name[0], name[1]));
        // Get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientID);
        // Get XML file to generate input payload
        xmlData = new File(xmlPath);
        ndc = inputData.get("DRUG_NAME");
        drugName = inputData.get("DRUG_NAME");
        Reporter.log("Drug name: " + drugName);
        // Update the XML with required storeNbr, Date-time, and a unique messageId
        String generatedString = RandomStringUtils.randomAlphanumeric(10);
        String updateMsgId = storeId + generatedString;
        inputPayload = updateXMLwithRelatesToMessageId(xmlData, storeId, updateMsgId, requestId, patientInfo, ndc, drugName);
        Log.info("inputPayload: " + inputPayload);
        // Drop ERX order
        dropERX(inputPayload, storeId, patientID, updateMsgId);
        //verification order creation
        if (verifyOrder) {
            verifyOrderCreation(updateMsgId);
        }
        return updateMsgId;
    }

    public String updateXMLwithRelatesToMessageId(File xmlData, String storeNbr, String messageId, int requestId, DataRow patientInfo, String ndc, String drugName)
            throws ParserConfigurationException, SAXException, IOException {
        String fileContext = FileUtils.readFileToString(xmlData, StandardCharsets.UTF_8);
        String relatesToMessageId = storeNbr + requestId;
        fileContext = fileContext.replaceAll("storeNbr", storeNbr);
        fileContext = fileContext.replaceAll("messageId", messageId);
        fileContext = fileContext.replaceAll("relatesToId", relatesToMessageId);
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedDate = today.format(formatter);
        String currentTime = getCurrentTime();
        fileContext = fileContext.replaceAll("sentTime", currentTime);
        fileContext = fileContext.replaceAll("effectiveDate", formattedDate);
        fileContext = fileContext.replaceAll("writtenDate", currentTime);
        fileContext = fileContext.replaceAll("patientLastName", patientInfo.getValue("last_name").toString().trim());
        fileContext = fileContext.replaceAll("patientFirstName", patientInfo.getValue("first_name").toString().trim());
        fileContext = fileContext.replaceAll("patientGender", patientInfo.getValue("gender_code"));
        fileContext = fileContext.replaceAll("patientDOB", patientInfo.getValue("birth_date").toString());
        fileContext = fileContext.replaceAll("drugName", drugName);
        fileContext = fileContext.replaceAll("ndc", ndc);
        return fileContext;
    }

    public void select30To90DaySupplyCurrentRx() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            menuBar.selectDaySupplyRequest();
            Reporter.log("Selected 30 to 90 Day Supply change request from Current Rx Menu");
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed at Brand to Generic changes " + e.getMessage());
        }
    }

    /**
     * Method to perform Resolve Queue
     **/
    public void performResolveQueueFromModifyDetails(String rxNbr){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try{
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.TroubleShooting.getValue(),ConnexusConstants.WAIT_TIMEOUT_10)) {
                Reporter.log("RX is in Resolve queue");
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.launchModifyDetailsPage();
                modifyDetails.clickAccept();
                Reporter.log("Resolution completed");
            }
        }
        catch(Throwable e){
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Test failed at Resolve queue " + e.getMessage());
        }
    }
}
