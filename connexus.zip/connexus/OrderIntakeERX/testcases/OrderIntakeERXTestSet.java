package connexus.OrderIntakeERX.testcases;

import connexus.OrderIntakeERX.testscripts.OrderIntakeERXTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.datamodels.connexus.PatientProfileModel;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Map;

public class OrderIntakeERXTestSet {

    OrderIntakeERXTestScript orderIntakeERXTestScript = new OrderIntakeERXTestScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ConnexusAPIManager connexusAPIManager;
    PropertyReader prop = PropertyReader.getInstance();
    String siteId =prop.getProperty("cnx.store");
    boolean flagUpdated = false;
    boolean relaunchConnexus = true;

    @BeforeClass
    public void performLogin() {
        connexusAppUtils.startAppiumServer();
    }

    @BeforeMethod
    public void setup() {
        connexusAPIManager = new ConnexusAPIManager();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    public void updateFlags() {
        flagUpdated = connexusAppUtils.readAndUpdateFlag("9061","TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("9062","TRUE");
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("20051","TRUE");
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("9063","2");
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("31026","1");
    }

    public void restartConnexusService(){
        if (flagUpdated) {
            Reporter.log("Restarting Connexus service to apply updated flags");
            connexusAPIManager.restartConnexusService(siteId);
            relaunchConnexus = true;
        } else {
            Reporter.log("No flags updated, skipping Connexus service restart");
        }
    }

    /*----------------------------------------------------------------------------------------------------------
          * 491 Drop a new ERX for a pet patient (create a patient type as 'Pet' ) and validate the ERX flow. Process the ERX in Connexus store front.
          * Author: Sweety Saxena
          ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Creation of PET Patient Profile",
            enabled = true, priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "PetPatient")
    public void HWPHME2E_491_Validate_ERX_PET_Patient_Profile(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String xmlPayload="src//test//resources//TestData//Connexus//OrderIntakeERX//newERX.xml";
        connexusAppUtils.getStoreId();
        updateFlags();
        restartConnexusService();
        orderIntakeERXTestScript.initializeTestCase(relaunchConnexus);
        //1. Validate Creation of PET Patient Profile
        orderIntakeERXTestScript.createNewPatient(inputData,0, PatientProfileModel.PatientType.PET);
        //Send Surescript request to perform ERX
        orderIntakeERXTestScript.performERXForPet(inputData,xmlPayload);
       // complete from input to completion
        orderIntakeERXTestScript.performInput(inputData,"Regular");
        orderIntakeERXTestScript.perform4Point(false);
        Reporter.log("ERX has been verified for Pet Patient");
    }
    /*----------------------------------------------------------------------------------------------------------
        * HWPHME2E_1884 EPCS | C3 | Drop a ERx and verify the expiration date in input screen when product & sig isn't auto populated
        * Author: Sweety Saxena
        ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "EPCS | C3 | Drop a ERx and verify the expiration date in input screen when product & sig isn't auto populated",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_1884(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException, ParseException {
        String xmlPayload="src//test//resources//TestData//Connexus//OrderIntakeERX/newERX.xml";

        connexusAppUtils.getStoreId();
        updateFlags();
        connexusAppUtils.updateStateValue(inputData.get("PHARMACY_STATE"));
        connexusAPIManager.restartConnexusService(siteId);
        orderIntakeERXTestScript.initializeTestCase(relaunchConnexus);
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERX(inputData,xmlPayload,true);
        orderIntakeERXTestScript.performInputVerifications(inputData);
        orderIntakeERXTestScript.validatingExpiryDateInFourPoint();
    }

    /*----------------------------------------------------------------------------------------------------------
          * HWPHME2E_1895 EPCS | TX | C2 | Drop a ERx with an out of state MD (400) prescriber and NO supervisor details |
          verify whether Rx hasn't bypassed input and a popup for in state prescriber for C2 is displayed.
          * Author: Sweety Saxena
          ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "EPCS | TX | C2 | Drop a ERx with an out of state MD (400) prescriber and NO supervisor details"+
            "verify whether Rx hasn't bypassed input and a popup for in state prescriber for C2 is displayed.",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_1895(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String xmlPayload="src//test//resources//TestData//Connexus//OrderIntakeERX//newERX.xml";
        connexusAppUtils.getStoreId();
        updateFlags();
        connexusAPIManager.restartConnexusService(siteId);
        connexusAppUtils.updateStateValue(inputData.get("PHARMACY_STATE"));
        orderIntakeERXTestScript.initializeTestCase(relaunchConnexus);
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERX(inputData,xmlPayload,true);
        orderIntakeERXTestScript.performInputTillAccept(inputData);
        orderIntakeERXTestScript.verifyInStatePrescriberPopup();
    }
    /*----------------------------------------------------------------------------------------------------------
          * HWPHME2E_1878 EPCS | C2 | Drop a ERx with Other medication date as future date in XML and verify the input screen whether
           effective fill date is populated correctly and the expiration date is calculated as per rx_days_qty value for the store state
          * Author: Sweety Saxena
          ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "EPCS | C2 | Drop a ERx with Other medication date as future date in XML and verify the input screen whether " +
            "effective fill date is populated correctly and the expiration date is calculated as per rx_days_qty value for the store state",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_1878(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException, ParseException {
        String xmlPayload="src//test//resources//TestData//Connexus//OrderIntakeERX/newERX.xml";
        connexusAppUtils.getStoreId();
        updateFlags();
        connexusAppUtils.updateStateValue(inputData.get("PHARMACY_STATE"));
        connexusAPIManager.restartConnexusService(siteId);
        orderIntakeERXTestScript.initializeTestCase(relaunchConnexus);
        Reporter.log("State of the box is set to:" +inputData.get("PHARMACY_STATE"));
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERXFutureDate(inputData,xmlPayload,true);
        orderIntakeERXTestScript.performInputVerifications(inputData);
        orderIntakeERXTestScript.validatingExpiryDateInFourPoint();
    }
    /*----------------------------------------------------------------------------------------------------------
          * HWPHME2E_1201  ByPassInput-Verify that ERx Skip Input and is held in future fill resolution after 4 point completion
          if ERx written date is 1-to-3 days prior to EarliestFillDate
          * Author: Sweety Saxena
          ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "ByPassInput-Verify that ERx Skip Input and is held in future fill resolution after 4 point completion",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_1201(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {

        String xmlPayload="src//test//resources//TestData//Connexus//OrderIntakeERX//ERXFourPoint.xml";
        connexusAppUtils.getStoreId();
        updateFlags();
        connexusAppUtils.updateStoreState("AR");
        restartConnexusService();
        orderIntakeERXTestScript.initializeTestCase(relaunchConnexus);
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERXFourPoint(inputData,xmlPayload,true);
        orderIntakeERXTestScript.perform4PointVerifications();
        orderIntakeERXTestScript.verifyProblemResolvedButtonInResolution();
    }

    /**
     * eRx Modify Post-Onhold - ERX placed on hold using "on hold" checkbox, never dispensed.
     * @param inputData
     * @throws SQLException
     * @throws ParserConfigurationException
     * @throws IOException
     * @throws SAXException
     */
    @Test(enabled = true, description = "eRx Modify Post-Onhold - ERX placed on hold using on hold checkbox, never dispensed",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_5337_ERX_Placed_On_Hold_Using_OnHold_Checkbox_Never_Dispensed(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {

        String xmlPayload="src//test//resources//TestData//Connexus//ERX_1896.xml";
        connexusAppUtils.getStoreId();
        updateFlags();
        restartConnexusService();
        orderIntakeERXTestScript.initializeTestCase(flagUpdated);
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERX(inputData,xmlPayload,true);
       if (orderIntakeERXTestScript.isRxIn4PointQueue()) {
            orderIntakeERXTestScript.performFourPointWithOnHoldStatus();
        } else {
            orderIntakeERXTestScript.performInput(inputData,"Regular");
            orderIntakeERXTestScript.performFourPointWithOnHoldStatus();
        }
        
        orderIntakeERXTestScript.validateRxStatusOnF7screen(inputData);
        orderIntakeERXTestScript.updatePatientDetailsInModifyDetailsScreen(inputData);
        orderIntakeERXTestScript.verifyRxMovedToFourPointWithOnHoldSelected();
        orderIntakeERXTestScript.performFourPointWithOnHoldStatus();
        orderIntakeERXTestScript.validateRxStatusOnF7screen(inputData);
        orderIntakeERXTestScript.validateNewFillIdNotCreated();

        Reporter.log("eRx Modify Post-Onhold - ERX placed on hold using on hold checkbox, never dispensed");
    }
    @Test(enabled = true, description = "eRx Modify Post-Onhold - ERX placed on hold through cancel fill should be on hold never dispensed",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_5338_ERX_Placed_On_Hold_through_cancel_fill_should_be_on_hold_never_dispensed(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {

        String xmlPayload="src//test//resources//TestData//Connexus//ERX_1896.xml";
        connexusAppUtils.getStoreId();
        updateFlags();
        restartConnexusService();
        orderIntakeERXTestScript.initializeTestCase(flagUpdated);
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERX(inputData,xmlPayload,true);
       if (orderIntakeERXTestScript.isRxIn4PointQueue()) {
            orderIntakeERXTestScript.perform4Point();
        } else {
            orderIntakeERXTestScript.performInput(inputData,"Regular");
            orderIntakeERXTestScript.perform4Point();
        }
        orderIntakeERXTestScript.performChkDUR();
        orderIntakeERXTestScript.verifyRxInFillingQueue();
        orderIntakeERXTestScript.performCancelFillShouldBeOnHoldAtModifyDetailsScreen();
        orderIntakeERXTestScript.updatePatientDetailsInModifyDetailsScreen(inputData);
        orderIntakeERXTestScript.verifyRxMovedToFourPointWithOnHoldSelected();
        orderIntakeERXTestScript.performFourPointWithOnHoldStatus();
        orderIntakeERXTestScript.validateRxStatusForOriginalFillAndNewFill(inputData);

        Reporter.log("eRx Modify Post-Onhold - ERX placed on hold through cancel fill should be on hold never dispensed");
    }

    @Test(enabled = true, description = "eRx Modify Post-Onhold - ERX placed on hold through cancel fill should be on hold never dispensed for Controlled Drug",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_5339_ERX_Placed_On_Hold_through_cancel_fill_should_be_on_hold_never_dispensed_Controlled_drug(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {

        String xmlPayload="src//test//resources//TestData//Connexus//ERX_1896.xml";
        connexusAppUtils.getStoreId();
        updateFlags();
        restartConnexusService();
        orderIntakeERXTestScript.initializeTestCase(flagUpdated);
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERX(inputData,xmlPayload,true);
        if (orderIntakeERXTestScript.isRxIn4PointQueue()) {
            orderIntakeERXTestScript.perform4Point();
        } else {
            orderIntakeERXTestScript.performInput(inputData,"Regular");
            orderIntakeERXTestScript.perform4Point();
        }
        orderIntakeERXTestScript.performChkDUR();
        orderIntakeERXTestScript.verifyRxInFillingQueue();
        orderIntakeERXTestScript.performCancelFillShouldBeOnHoldAtModifyDetailsScreen();
        orderIntakeERXTestScript.updatePatientDetailsInModifyDetailsScreen(inputData);
        orderIntakeERXTestScript.verifyRxMovedToFourPointWithOnHoldSelected();
        orderIntakeERXTestScript.performFourPointWithOnHoldStatus();
        orderIntakeERXTestScript.validateRxStatusForOriginalFillAndNewFill(inputData);

        Reporter.log("eRx Modify Post-Onhold - ERX placed on hold through cancel fill should be on hold never dispensed for Controlled Drug");
    }



  /*Pre-Requisite
    Change the store NY
    Patient has medicaid insurance associated ex: (patient with QA/MEDICAID as insurance)
    C2 drugs*/
    @Test(enabled = true, description = "ERX and Store Rx | Validate triplicate nbr autopopulation for NY state",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_5253_ERX_and_StoreRx_Validate_triplicate_nbr_autopopulation_for_NY_state(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String xmlPayload="src//test//resources//TestData//Connexus//OrderIntakeERX//newERX.xml";
        //update state
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" + inputData.get("PHARMACY_STATE"));
        connexusAppUtils.getStoreId();
        updateFlags();
        restartConnexusService();
        orderIntakeERXTestScript.initializeTestCase(flagUpdated);
        orderIntakeERXTestScript.performCreatePatientThroughAPI(inputData, connexusAppUtils.getStoreId());
        orderIntakeERXTestScript.performDropOff(false);
        orderIntakeERXTestScript.validateTriplicateValue(inputData, false);
        Reporter.log("serial/Triplicate number is displayed in input screen for Insurance patient RX associated with C2 Drug ");
        orderIntakeERXTestScript.performERX(inputData,xmlPayload,true);
        orderIntakeERXTestScript.validateTriplicateValue(inputData, true);
        Reporter.log("Triplicate is auto populated for C2 Drug of NY State ");
    }

}
