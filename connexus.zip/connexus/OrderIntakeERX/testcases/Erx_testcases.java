package connexus.OrderIntakeERX.testcases;

import connexus.OrderIntakeERX.testscripts.OrderIntakeERXTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.datamodels.connexus.PatientProfileModel;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

public class Erx_testcases {
    public static LoginAs.userType loginUser_Type=LoginAs.userType.HOMEOFFICE_ADFlagOn;
    OrderIntakeERXTestScript orderIntakeERXTestScript = new OrderIntakeERXTestScript(loginUser_Type);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    PropertyReader prop = PropertyReader.getInstance();
    String siteId =prop.getProperty("cnx.store");
    boolean flagUpdated = false;
    boolean relaunchConnexus = false;

    @BeforeClass
    public void performlogin(){
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    public void updateFlags() {
        flagUpdated = connexusAppUtils.readAndUpdateFlag("9061","TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("9062","TRUE");
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("20051","TRUE");
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("9063","2");
        flagUpdated |=connexusAppUtils.readAndUpdateFlag("31026","1");
    }

    public void updateTriplicateFlags(){
        flagUpdated = connexusAppUtils.updateAgencyRequirementParmTbl("N", "15138 ", "232");
        String restrictValue = "EEEEEEEE";
        connexusAppUtils.selectAgencyClassParmTable(restrictValue, "15034", "2304", "232");

        connexusAppUtils.selectAgencyClassParmTable(restrictValue, "15039","2304","232");
        connexusAppUtils.selectAgencyClassParmTable(restrictValue, "15038", "2304", "232");
        restrictValue = "99999999";
        connexusAppUtils.updateAgencyClassParmTable(restrictValue,"15038","232" );

    }

    public void restartConnexusService(){
        if (flagUpdated) {
            Reporter.log("Restarting Connexus service to apply updated flags");
            connexusAPIManager.restartConnexusService(siteId);
            relaunchConnexus = true;
        } else {
            Reporter.log("No flags updated, skipping Connexus service restart");
            relaunchConnexus = true;
        }
    }

    /*----------------------------------------------------------------------------------------------------------
             * Test Description:Drop a ERx with an In state MD (400) prescriber and NO supervisor details | verify whether Rx bypassed input and landed in 4point without Attending physician.
             *
             * Pre-Conditions:  1. Store state should be AR
             *                  2.In state MD (400) prescriber
             * Author: snehaa(vn57hhm)
             ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Drop a ERx with an In state MD (400) prescriber and NO supervisor details | verify whether Rx bypassed input and landed in 4point without Attending physician.",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_1896(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {

        String xmlPayload="src//test//resources//TestData//Connexus//ERX_1896.xml";
        connexusAppUtils.getStoreId();
        updateFlags();
        restartConnexusService();
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.initializeTestCase(relaunchConnexus);
        Reporter.log("State of the box is set to:" + inputData.get("PHARMACY_STATE"));

        orderIntakeERXTestScript.performERX(inputData,xmlPayload,true);
        orderIntakeERXTestScript.verifyRxIn4PointQueue();
        orderIntakeERXTestScript.verifyAttendingPhysicianNotDisplayedIn4Point();
        Reporter.log(" Entered Instate MD prescriber(400) and Landed in fourpoint screen without Attending Physician");
    }
    /*----------------------------------------------------------------------------------------------------------
             * Test Description:Drop a ERx with an In state CRNP (403) prescriber and supervisor details | verify whether Rx bypassed input and landed in 4point with Attending physician details.
             *
             * Pre-Conditions:  1. ERx should be dropped successfully with a Message ID generated.
                                2.Store state should be MO
             * Author: snehaa(vn57hhm)
             ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Drop a ERx with an In state CRNP (403) prescriber and supervisor details | verify whether Rx bypassed input and landed in 4point with Attending physician details.",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_1897(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {

        String xmlPayload="src//test//resources//TestData//Connexus//ERX_1897.xml";
        connexusAppUtils.getStoreId();
        connexusAppUtils.updateStateValue(inputData.get("PHARMACY_STATE"));
        updateFlags();
        restartConnexusService();
        orderIntakeERXTestScript.initializeTestCase(relaunchConnexus);
        Reporter.log("State of the box is set to:" + inputData.get("PHARMACY_STATE"));
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERX(inputData,xmlPayload,true);
        orderIntakeERXTestScript.inputforAP();
        Reporter.log("When Entered CRNP (403) in MO state attending physician tab is diplayed as expected ");
    }
    /*----------------------------------------------------------------------------------------------------------
            * Test Description:Drop a ERx with an out of state MD (400) prescriber and NO supervisor details | verify whether Rx bypassed input and landed in 4point without Attending physician.
            *
            * Pre-Conditions:  1. ERx should be dropped successfully with a Message ID generated.
                               2. Store state should be TX
            * Author:snehaa(vn57hhm)
            ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Drop a ERx with an out of state MD (400) prescriber and NO supervisor details | verify whether Rx bypassed input and landed in 4point without Attending physician.",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_1898(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {

        String xmlPayload="src//test//resources//TestData//Connexus//ERX_1898.xml";
        connexusAppUtils.getStoreId();
        connexusAppUtils.updateStateValue(inputData.get("PHARMACY_STATE"));
        updateFlags();
        restartConnexusService();
        orderIntakeERXTestScript.initializeTestCase(relaunchConnexus);
        Reporter.log("State of the box is set to:" + inputData.get("PHARMACY_STATE"));
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERX(inputData,xmlPayload,true);
        orderIntakeERXTestScript.verifyRxIn4PointQueue();
        orderIntakeERXTestScript.verifyAttendingPhysicianNotDisplayedIn4Point();
        Reporter.log(" Entered Prescriber from out of state MD prescriber(400) and Landed in fourpoint screen without Attending Physician");
    }
    /*----------------------------------------------------------------------------------------------------------
             * Test Description:Drop a ERx with an In state ARNP (403) prescriber and NO supervisor details | verify whether Rx bypassed input and landed in 4point without Attending physician.

             * Pre-Conditions:1.Store state should be set to MO
                              2.9061 and 9062 flag should be -> TRUE
                              3. ERx should be dropped successfully with a Message ID generated.
             * Author:snehaa(vn57hhm)
             ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Drop a ERx with an In state ARNP (403) prescriber and NO supervisor details | verify whether Rx bypassed input and landed in 4point without Attending physician.",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_1905(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {

        String xmlPayload="src//test//resources//TestData//Connexus//ERX_1905.xml";
        connexusAppUtils.getStoreId();
        connexusAppUtils.updateStateValue(inputData.get("PHARMACY_STATE"));
        updateFlags();
        restartConnexusService();
        orderIntakeERXTestScript.initializeTestCase(relaunchConnexus);
        Reporter.log("State of the box is set to:" + inputData.get("PHARMACY_STATE"));
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERX(inputData,xmlPayload,true);
        orderIntakeERXTestScript.verifyRxIn4PointQueue();
        orderIntakeERXTestScript.verifyAttendingPhysicianNotDisplayedIn4Point();
        Reporter.log("Bypassed input and landed in four point without Attending physician details as expected");
    }
    /*----------------------------------------------------------------------------------------------------------
            * Test Description:Drop a ERx - switch the quantity > 5 in Input screen and verify the expiration date is calculated as per rx_days_qty value for the store state.
            *
            * Pre-Conditions:1.Store state should be set to MO
                             2.9061 and 9062 flag should be -> TRUE
                             3. ERx should be dropped successfully with a Message ID generated.
            * Author: snehaa(vn57hhm)
            ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Drop a ERx - switch the quantity > 5 in Input screen and verify the expiration date is calculated as per rx_days_qty value for the store state.",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_1912(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {

        String xmlPayload = "src//test//resources//TestData//Connexus//ERX_1912.xml";
        connexusAppUtils.getStoreId();
        updateFlags();
        connexusAppUtils.updateStateValue(inputData.get("PHARMACY_STATE"));
        connexusAPIManager.restartConnexusService(siteId);
        orderIntakeERXTestScript.initializeTestCase(relaunchConnexus);
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERX(inputData,xmlPayload,true);
        orderIntakeERXTestScript.performInputVerifications(inputData);
    }
    /*----------------------------------------------------------------------------------------------------------
             * Test Description:E2E of Maximally Populated NewRx
             *
             * Pre-Conditions:  1. ERx should be dropped successfully with a Message ID generated.
                                2. ERX should be in input
             * Author: snehaa(vn57hhm)
             ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Regression | OFF | E2E of Maximally Populated NewRx",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_1240(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {

        String xmlPayload = "src//test//resources//TestData//Connexus//ERX_Test1.xml";
        connexusAppUtils.getStoreId();
        updateFlags();
        orderIntakeERXTestScript.initializeTestCase(relaunchConnexus);
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERX(inputData,xmlPayload,true);
        Reporter.log("Entered Maximally populated xml");
        orderIntakeERXTestScript.verifyRXInInputQueue();
        Reporter.log("Order is in input queue");
    }

    /*----------------------------------------------------------------------------------------------------------
           * HWPHME2E-3168 Drop ERX with EFD that by-passed input - Verify expiry is calculated from Written date even if EFD is selected if input drug is C3/C4/C5.
           * Verify Expiration date should be Written Date +180Days.
           * Author:Mallikarjun
           ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate the expiry date calculated for ERX in the 4PT page and Modify page workflow ",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX2")
    public void HWPHME2E_3168_Expiry_Date_calculated_for_ERX_4PT_Page(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {

        String xmlPayload="src//test//resources//TestData//Connexus//ERX_1905.xml";
        connexusAppUtils.getStoreId();
        connexusAppUtils.updateStateValue(inputData.get("PHARMACY_STATE"));
        updateFlags();
        orderIntakeERXTestScript.initializeTestCase(relaunchConnexus);
        Reporter.log("State of the box is set to:" + inputData.get("PHARMACY_STATE"));
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERX(inputData,xmlPayload,true);
        orderIntakeERXTestScript.verifyRxIn4PointQueue();
        orderIntakeERXTestScript.validatingExpiryDateIn4PTQueue();
        Reporter.log(" Verify expiry is calculated from Written date even if EFD is selected if input drug is C3/C4/C5");
    }

    /*----------------------------------------------------------------------------------------------------------
             * Test Description: Verify Patient Mismatch using Host Pull Functionality
             *  Pre-Conditions:  1. ERx should be dropped successfully with a Message ID generated.
             * Author: Avantika(vn598z6)
             ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify Patient Mismatch using Host Pull Functionality",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "RXPD")
    public void HWPHME2E_265(Map<String, String> inputData) throws IOException {

        connexusAppUtils.getStoreId();
        updateFlags();
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.initializeTestCase(flagUpdated);
        orderIntakeERXTestScript.hostPullPatient(inputData);
        Reporter.log("Verified Patient Details using Host Pull Functionality");

    }
    @Test(enabled = true, description = " Drop a ERx with 2TP plans and apply split bill details" +
            "verify whether user is able to modify the payment method(split bill) for an ERX prescription",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_153(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String xmlPayload = "src//test//resources//TestData//Connexus//OrderIntakeERX//newERX.xml";
        connexusAppUtils.getStoreId();
        updateFlags();
        orderIntakeERXTestScript.initializeTestCase(flagUpdated);

        //create patient with TP
        orderIntakeERXTestScript.createPatient(inputData);
        orderIntakeERXTestScript.performERX(inputData, xmlPayload, true);
        orderIntakeERXTestScript.performInput(inputData);
        orderIntakeERXTestScript.perform4Point(false);
        orderIntakeERXTestScript.searchPatient();
        //enable splitbill checkbox
        orderIntakeERXTestScript.addSecondaryThirdPartyDetails(inputData);
        orderIntakeERXTestScript.clickonSplitBoxCheck();
        orderIntakeERXTestScript.performFilling();
        orderIntakeERXTestScript.performVisualVerify();
        orderIntakeERXTestScript.performPickUp(inputData);
        orderIntakeERXTestScript.performCounselling();
        orderIntakeERXTestScript.performPOS();
    }

    //@Jira(testID = "HWPHME2E-170")
    @Test(enabled = true, description = "HWPHME2E_170_Verify_Error_message_For_Rx_Expiration_Days_Supply_Input_And_Modify_Detail_Screen_CRNP_Prescriber",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_170_Verify_Error_message_For_Rx_Expiration_Days_Supply_Input_And_Modify_Detail_Screen_CRNP_Prescriber(Map<String, String> inputData) {
        Reporter.log("Verify, error message for RX Expiration and Days supply violation displayed in input and modify when RX written date is >90 days and Days supply is >90 respectively & excess qty is Voided for CRNP Prescriber from TX state.");
        //no specific user login
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        orderIntakeERXTestScript.initializeTestCase(false);
        orderIntakeERXTestScript.createPatientAPI(inputData);
        orderIntakeERXTestScript.sendErxMessage("surescriptNewRequst", inputData);
        orderIntakeERXTestScript.performInputWithWrittenDateLessThan90Days(inputData);
        orderIntakeERXTestScript.verifyInvalidRxDatePopUpAndClickYes(inputData);
        orderIntakeERXTestScript.performInputWithGreaterThanDaysSupplyLimitAndUpdateDispenseQty(inputData);
        orderIntakeERXTestScript.perform4Point(false);
        orderIntakeERXTestScript.ClickOnAcceptButtonByProvidingWrittenDateLessThan90Days(inputData);
        orderIntakeERXTestScript.verifyInvalidRxDatePopUpAndClickYes(inputData);
        orderIntakeERXTestScript.ClickOnAcceptButtonByProvidingrxExpiryDateSelectionThan90Days(inputData);

        Reporter.log("Validated error message for RX Expiration and Days supply violation displayed in input and modify when RX written date is >90 days and Days supply is >90 respectively & excess qty is Voided for CRNP Prescriber from TX state.");
    }

    //@Jira(testID = "HWPHME2E-180")
    @Test(enabled = true, description = "Verify_Remaining_quantity_voided_Before_Filling_C3_Opioid_For_PA_Prescriber",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_180_Verify_Remaining_quantity_voided_Before_Filling_C3_Opioid_For_PA_Prescriber(Map<String, String> inputData) {
        Reporter.log("Verify, remaining qty is voided before Filling when a CIII Opioid drug is prescribed above the days supply limit by PA prescriber from MO state");
        //no specific user login
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        flagUpdated = connexusAppUtils.readAndUpdateFlag("15238", "TRUE");
        orderIntakeERXTestScript.initializeTestCase(flagUpdated);
        orderIntakeERXTestScript.createPatientAPI(inputData);
        orderIntakeERXTestScript.sendErxMessage("surescriptNewRequst", inputData);
        orderIntakeERXTestScript.performInputWithGreaterThanDaysSupplyLimitAndUpdateDispenseQty(inputData);
        orderIntakeERXTestScript.perform4Point(false);
        orderIntakeERXTestScript.validateRemainingQuantityAndRxNotesInModifyDetailsScreen(inputData);
        orderIntakeERXTestScript.verifyActivityCodeInRxActivityTable();

        Reporter.log("Validated remaining qty is voided before Filling when a CIII Opioid drug is prescribed above the days supply limit by ARNP prescriber from MO state");
    }

    //@Jira(testID = "HWPHME2E-5108")
    @Test(enabled = true, description = " Auto populated Triplicate Number in Claim Submission Screen" +
            "Triplicate Number displaying in field 454-EK in claim submission screen when eRx doesn't bypasses input",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/BOM_Claims/BOM_Claim.json", sheetName = "BOM_Claim")
    public void HWPHME2E_5108(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String xmlPayload = "src//test//resources//TestData//Connexus//BOM_Claims//createERX.xml";
        //update state
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" + inputData.get("PHARMACY_STATE"));
        updateTriplicateFlags();
        connexusAppUtils.getStoreId();
        updateFlags();
        connexusAPIManager.restartConnexusService(siteId);
        orderIntakeERXTestScript.initializeTestCase(flagUpdated);
        orderIntakeERXTestScript.createERX(inputData, xmlPayload, true);
        orderIntakeERXTestScript.verifyPatientWorkQueueAndProblemStatus();
        orderIntakeERXTestScript.performPatientSearchAndPatientCreationWithTP(inputData);
        //Validate Triplicate in the Input Page
        orderIntakeERXTestScript.validateTriplicateInput(inputData, true);
        //Validate Triplicate in the Claims Page
        orderIntakeERXTestScript.validateTriplicateInClaimPage(inputData);
    }

    //@Jira(testID = "HWPHME2E-5109")
    @Test(enabled = true, description = " Auto populated Triplicate Number in Input Screen" +
            "Triplicate Number displaying field in input screen when eRx doesn't bypasses input",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/BOM_Claims/BOM_Claim.json", sheetName = "BOM_Claim")
    public void HWPHME2E_5109(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String xmlPayload = "src//test//resources//TestData//Connexus//BOM_Claims//createERX.xml";
        //update state
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" + inputData.get("PHARMACY_STATE"));
        updateTriplicateFlags();

        connexusAppUtils.getStoreId();
        updateFlags();
        connexusAPIManager.restartConnexusService(siteId);
        orderIntakeERXTestScript.initializeTestCase(flagUpdated);
        orderIntakeERXTestScript.createERX(inputData, xmlPayload, true);
        orderIntakeERXTestScript.verifyPatientWorkQueueAndProblemStatus();
        orderIntakeERXTestScript.performPatientSearchAndPatientCreationWithTP(inputData);
        //Validate Triplicate in the Input Page
        orderIntakeERXTestScript.validateTriplicateInput(inputData, true);
    }

    //@Jira(testID = "HWPHME2E-5110")
    @Test(enabled = true, description = "Not Auto populated Triplicate Number in Input Screen - Un Happy Path" +
            "Triplicate Number shouldnt populate in field 454-EK in D0 and in UI as well - Un Happy Path",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/BOM_Claims/BOM_Claim.json", sheetName = "BOM_Claim")
    public void HWPHME2E_5110(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String xmlPayload = "src//test//resources//TestData//Connexus//BOM_Claims//createERX.xml";
        //update state
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" + inputData.get("PHARMACY_STATE"));
        updateTriplicateFlags();

        connexusAppUtils.getStoreId();
        updateFlags();
        connexusAPIManager.restartConnexusService(siteId);
        orderIntakeERXTestScript.initializeTestCase(flagUpdated);
        connexusAppUtils.getStoreId();
        orderIntakeERXTestScript.createERX(inputData, xmlPayload, true);
        orderIntakeERXTestScript.verifyPatientWorkQueueAndProblemStatus();
        orderIntakeERXTestScript.performPatientSearchAndPatientCreationWithTP(inputData);
        //Validate Triplicate in the Input Page
        orderIntakeERXTestScript.validateTriplicateInput(inputData,false);
    }

    //@Jira(testID = "HWPHME2E-5114")
    @Test(enabled = true, description = "populated Triplicate Number in 4-Point Screen" +
            "Triplicate Number displaying field in Modify detail screen when eRx bypasses input screen",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/BOM_Claims/BOM_Claim.json", sheetName = "BOM_Claim")
    public void HWPHME2E_5114(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String xmlPayload = "src//test//resources//TestData//Connexus//BOM_Claims//createERX.xml";
        //update state
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" + inputData.get("PHARMACY_STATE"));
        updateTriplicateFlags();

        connexusAppUtils.getStoreId();
        updateFlags();
        connexusAPIManager.restartConnexusService(siteId);
        orderIntakeERXTestScript.initializeTestCase(flagUpdated);
        orderIntakeERXTestScript.createERX(inputData, xmlPayload, true);
        orderIntakeERXTestScript.verifyPatientWorkQueueAndProblemStatus();
        orderIntakeERXTestScript.performPatientSearchAndPatientCreationWithTP(inputData);
        //Validate Triplicate in the Input Page
        orderIntakeERXTestScript.validateTriplicateInput(inputData, true);
        //Validate Triplicate in the Perform 4Point Page
        orderIntakeERXTestScript.perform4Point(false);
    }

    //@Jira(testID = "HWPHME2E-5115")
    @Test(enabled = true, description = "populated Triplicate Number in Modify Details Screen" +
            "Triplicate Number displaying in field Triplicate number field in Modify detail screen and 4 point check screen when eRx doesn't bypasses input screen",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/BOM_Claims/BOM_Claim.json", sheetName = "BOM_Claim")
    public void HWPHME2E_5115(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String xmlPayload = "src//test//resources//TestData//Connexus//BOM_Claims//createERX.xml";
        //update state
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" + inputData.get("PHARMACY_STATE"));
        updateTriplicateFlags();

        connexusAppUtils.getStoreId();
        updateFlags();
        connexusAPIManager.restartConnexusService(siteId);
        orderIntakeERXTestScript.initializeTestCase(flagUpdated);
        orderIntakeERXTestScript.createERX(inputData, xmlPayload, true);
        orderIntakeERXTestScript.verifyPatientWorkQueueAndProblemStatus();
        orderIntakeERXTestScript.performPatientSearchAndPatientCreationWithTP(inputData);
        //Validate Triplicate in the Input Page
        orderIntakeERXTestScript.validateTriplicateInput(inputData, true);
        //Validate Triplicate in the Perform 4Point Page
        orderIntakeERXTestScript.perform4Point(false);
        orderIntakeERXTestScript.performChkDurAPI();
        orderIntakeERXTestScript.validateTriplicateinModifyDetails(inputData);
    }

    //@Jira(testID = "HWPHME2E-5106")
    @Test(enabled = true, description = " Auto populated Triplicate Number in Claim Submission Screen" +
            "Triplicate Number auto-populating in field 454-EK of D0 request when eRx doesn't bypasses input",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/BOM_Claims/BOM_Claim.json", sheetName = "BOM_Claim")
    public void HWPHME2E_5106(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String xmlPayload = "src//test//resources//TestData//Connexus//BOM_Claims//createERX.xml";
        //update state
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("PHARMACY_STATE"));
        Reporter.log("State of the box is set to:" + inputData.get("PHARMACY_STATE"));
        updateTriplicateFlags();

        connexusAppUtils.getStoreId();
        updateFlags();
        connexusAPIManager.restartConnexusService(siteId);
        orderIntakeERXTestScript.initializeTestCase(flagUpdated);
        orderIntakeERXTestScript.createERX(inputData, xmlPayload, true);
        orderIntakeERXTestScript.verifyPatientWorkQueueAndProblemStatus();
        orderIntakeERXTestScript.performPatientSearchAndPatientCreationWithTP(inputData);
        //Validate Triplicate in the Input Page
        orderIntakeERXTestScript.validateTriplicateInput(inputData, true);
        //Validate Triplicate in the Claims Page
        orderIntakeERXTestScript.validateTriplicateInClaimDetails(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
   * Change Rx | Verify that store is able to process the denied response for Brand to Generic Rx change request and validate rx is moving to denied resolution
   * Test Case ID: HWPHME2E_893
   * Author: Diya Steephen(vn58o0i)
  ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify that store is able to process the denied response for Brand to Generic Rx change request and validate rx is moving to denied resolution",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_893_Verify_That_Store_Is_Able_To_Process_The_Denied_Response_For_Brand_T0_Generic_Rx_change(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String xmlPayload = "src//test//resources//TestData//Connexus//erx_zestril_payload.xml";
        String deniedResponsePayload = "src//test//resources//TestData//Connexus//erx_deniedResolution_payload.xml";
        connexusAppUtils.getStoreId();
        orderIntakeERXTestScript.initializeTestCase(false);
        orderIntakeERXTestScript.createPatientAPI(inputData);
        orderIntakeERXTestScript.performERX(inputData, xmlPayload, true);
        orderIntakeERXTestScript.performInput(inputData);
        orderIntakeERXTestScript.selectBrandToGenericFromCurrentRx();
        orderIntakeERXTestScript.verifyRxInResolutionQueueWithExpectedProblem("Rx Change Request - Waiting for doctor approval");
        orderIntakeERXTestScript.sendPayloadWithRelatesToMessageId(inputData, deniedResponsePayload, true);
        orderIntakeERXTestScript.performResolveQueue(orderIntakeERXTestScript.rxNbr);
        orderIntakeERXTestScript.verifyRxIn4PointQueue();
        orderIntakeERXTestScript.perform4Point(false, false, inputData, false);
        orderIntakeERXTestScript.verifyRxIsChkDur();
    }

    /*----------------------------------------------------------------------------------------------------------
* Change Rx | Verify that RX moves to 30 to 90 days supply approved resolution
* Test Case ID: HWPHME2E_890
* Author: Mallikarjuna M(vn58n9x)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify that RX moves to 30 to 90 days supply approved resolution",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeERX/OrderIntakeERX.json", sheetName = "OrderERX")
    public void HWPHME2E_890_Verify_RX_moves_to_30_to_90_days_supply_approved_resolution(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String xmlPayload = "src//test//resources//TestData//Connexus//erx_zestril_payload.xml";
        String ApproveResponsePayload = "src//test//resources//TestData//Connexus//30_to_90_approve_payload.xml";
        connexusAppUtils.getStoreId();
        orderIntakeERXTestScript.initializeTestCase(false);
        orderIntakeERXTestScript.createPatientAPI(inputData);
        orderIntakeERXTestScript.performERX(inputData, xmlPayload, true);
        orderIntakeERXTestScript.performInput(inputData);
        orderIntakeERXTestScript.select30To90DaySupplyCurrentRx();
        orderIntakeERXTestScript.verifyRxInResolutionQueueWithExpectedProblem("Rx Change Request - Waiting for doctor approval");
        orderIntakeERXTestScript.sendPayloadWithRelatesToMessageId(inputData, ApproveResponsePayload, true);
        orderIntakeERXTestScript.performResolveQueueFromModifyDetails(orderIntakeERXTestScript.rxNbr);
        orderIntakeERXTestScript.verifyRxIn4PointQueue();
        orderIntakeERXTestScript.perform4Point(false, false, inputData, false);
        orderIntakeERXTestScript.performChkDurAPI();
        orderIntakeERXTestScript.verifyRxInFillingQueue();
    }
}

