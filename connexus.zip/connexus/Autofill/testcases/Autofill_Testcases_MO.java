package connexus.Autofill.testcases;

import connexus.Autofill.testscripts.Autofill_scripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Autofill_Testcases_MO {
    Autofill_scripts autofillTestScripts = new Autofill_scripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    boolean flagUpdated = false;

    @BeforeClass
    public void loginToConnexus() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    @Test(enabled = true, description = "MO Store| Validate AF status is set to Unenrolled with today's date in Verbal Consent States when Rx is unenrolled via Connexus AF Checkbox in Dropoff screen, F7 screen and modify details screen",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_1657(Map<String, String> inputData) {
        Reporter.log("MO Store| Validate AF status is set to Unenrolled with today's date in Verbal Consent States when Rx is unenrolled via Connexus AF Checkbox in Dropoff screen, F7 screen and modify details screen");
        Reporter.log("executing test case in 5528 store As A MO Store");
        connexusAppUtils.readAndUpdateStoreState("AR");
        autofillTestScripts.restartConnexusService();
        autofillTestScripts.initializeTestCase(false, false);
        autofillTestScripts.CreatePatientAndMoveOrderToChkDUR(inputData);
        autofillTestScripts.loginConnexus();
        autofillTestScripts.verifyAutoFillStatusInDropOffISEnrolled();
        autofillTestScripts.verifyAutoFillStatusInDropOffISEnrolled();
        autofillTestScripts.launchF7ScreenAndSearchPatient();
        autofillTestScripts.launchModifyDetailsScreenAndValidateAutoFillStatusISEnrolledOrUnEnrolled();
        autofillTestScripts.verifyAutoFillStatusISUnEnrolledInDropOff();
        autofillTestScripts.launchModifyDetailsScreenAndValidateAutoFillStatusISEnrolledOrUnEnrolled();
        autofillTestScripts.launchF7ScreenAndSearchPatient();

        Reporter.log("Validate AF status is set to Unenrolled with today's date in Verbal Consent States when Rx is unenrolled via Connexus AF Checkbox in Dropoff screen, F7 screen and modify details screen");
    }

    @Test(enabled = true, description = "MO Store | Restrict AF for 2302 drug_control_code drugs",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_4691(Map<String, String> inputData) {
        Reporter.log("MO Store | Restrict AF for 2302 drug_control_code drugs");
        Reporter.log("executing test case in 5528 store As A MO store");
        autofillTestScripts.restartConnexusService();
        autofillTestScripts.initializeTestCase(false, true);
        autofillTestScripts.CreatePatientAndMoveOrderToChkDURThroughUI(inputData,true);
        autofillTestScripts.TryEnrollingAutoFillStatusInF7ScreenAndVerifyAFIsDisabled();
        autofillTestScripts.launchModifyDetailsScreenAndValidateAutoFillStatusISEnrolledOrUnEnrolled();
        autofillTestScripts.verifyAutoFillStatusIsDisabledInDropOff();
        Reporter.log("MO Store | Restrict AF for 2302 drug_control_code drugs");
    }

    @Test(enabled = true, description = "MO Store | Validate Rx Enrollment Status for written constent states whether Pending/Enrolled or unenrolled in Connexus UI Dropoff screen, Modify details & F7 Loopup screen",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_1656(Map<String, String> inputData) {
        Reporter.log("MO Store | Validate Rx Enrollment Status whether Pending/Enrolled or unenrolled in Connexus UI Dropoff screen, Modify details & F7 Loopup screen");
        Reporter.log("executing test case in 5528 store as MO Store");
        connexusAppUtils.readAndUpdateStoreState("OK");
        connexusAppUtils.getStoreId();
        autofillTestScripts.restartConnexusService();
        autofillTestScripts.initializeTestCase(false, false);
        autofillTestScripts.CreatePatientAndMoveOrderToChkDUR(inputData);
        autofillTestScripts.loginConnexus();
        autofillTestScripts.enrollAutoFillStatusInF7Screen();
        autofillTestScripts.launchModifyDetailsScreenAndValidateAutoFillStatusISEnrolledOrUnEnrolled();
        autofillTestScripts.checkAutoFillStatusInDropOffIsPending();
        autofillTestScripts.verifyAutoFillStatusISUnEnrolledInDropOff();
        autofillTestScripts.launchModifyDetailsScreenAndValidateAutoFillStatusISEnrolledOrUnEnrolled();
        autofillTestScripts.launchF7ScreenAndSearchPatient();
        Reporter.log("MO Store | Validate Rx Enrollment Status whether Pending/Enrolled or unenrolled in Connexus UI Dropoff screen, Modify details & F7 Loopup screen");
    }

    @Test(enabled = true, description = "MO Store |  Validate AutoFill Enrollment Report with All Status -Enrolled,Unenrolled,PENDING",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_1655(Map<String, String> inputData) {
        Reporter.log("MO Store |  Validate AutoFill Enrollment Report with All Status -Enrolled,Unenrolled,PENDING");
        Reporter.log("executing test case in 5528 store as MO Store with state as written consent");
        autofillTestScripts.initializeTestCase(false, false);
        autofillTestScripts.loginConnexus();
        autofillTestScripts.autoRefillEnrollmentReport();

        Reporter.log("MO Store | Validated Rx Enrollment Status as Enrolled, unenrolled and Pending");
    }

    @Test(enabled = true, description = "Validate_AF_enroll_compound_drug",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_1660(Map<String, String> inputData) {
        Reporter.log("<<<Validate AF enrolled for compound drug>>>");
        connexusAppUtils.readAndUpdateStoreState("AR");
        connexusAppUtils.getStoreId();
        autofillTestScripts.restartConnexusService();
        autofillTestScripts.initializeTestCase(false, false);
        autofillTestScripts.CreatePatientAndMoveOrderToChkDUR(inputData);
        autofillTestScripts.loginConnexus();
        autofillTestScripts.enrollAFInF7Screen("True");
    }

    @Test(enabled = true, description = "AF_verbal_to_written_state",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_4689(Map<String, String> inputData) {
        Reporter.log("<<<Validating AF enrolled status changed to pending on updating verbal to written state>>>");
        connexusAppUtils.readAndUpdateStoreState("AR");
        connexusAppUtils.getStoreId();
        autofillTestScripts.restartConnexusService();
        autofillTestScripts.initializeTestCase(false, false);
        autofillTestScripts.CreatePatientAndMoveOrderToChkDUR(inputData);
        autofillTestScripts.loginConnexus();
        autofillTestScripts.enrollAFInF7Screen(0);
        autofillTestScripts.updatePatientState("ToWritten");
        autofillTestScripts.AutoFillStatusInF7ScreenIsPending();
    }

    @Test(enabled = true, description = "AF_verbal_to_written_state",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_1647(Map<String, String> inputData) {
        List<String> multiRxNbr;
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        autofillTestScripts.restartConnexusService();
        autofillTestScripts.initializeTestCase(false, false);
        multiRxNbr = autofillTestScripts.CreatePatientAndMultiRxOrderMoveToChkDUR(inputData, 2, true);
        autofillTestScripts.loginConnexus();
        autofillTestScripts.enrollAFInF7Screen(0);
        autofillTestScripts.enrollAFInF7Screen(1);
        autofillTestScripts.verifyStatusCode(multiRxNbr.get(0), "2");
        Reporter.log("RX Number: " + multiRxNbr.get(0) + ", Autofill Status Code Updated to 2(Enrolled)");
        autofillTestScripts.verifyStatusCode(multiRxNbr.get(1), "2");
        Reporter.log("RX Number: " + multiRxNbr.get(1) + ", Autofill Status Code Updated to 2(Enrolled)");
        autofillTestScripts.updatePatientState("ToWritten");
        Reporter.log("Patient State updated to Written Consent State");
        autofillTestScripts.verifyStatusCode(multiRxNbr.get(0), "4");
        Reporter.log("RX Number: " + multiRxNbr.get(0) + ", Autofill Status Code Updated to 4 (Pending)");
        autofillTestScripts.verifyStatusCode(multiRxNbr.get(1), "4");
        Reporter.log("RX Number: " + multiRxNbr.get(1) + ", Autofill Status Code Updated to 4 (Pending)");
    }

    @Test(enabled = true, description = "AF_written_to_verbal_state",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_1648(Map<String, String> inputData) {
        List<String> multiRxNbr;
        connexusAppUtils.readAndUpdateStoreState("OK");
        autofillTestScripts.restartConnexusService();
        autofillTestScripts.initializeTestCase(false, false);
        multiRxNbr = autofillTestScripts.CreatePatientAndMultiRxOrderMoveToChkDUR(inputData, 2, true);
        autofillTestScripts.loginConnexus();
        autofillTestScripts.enrollAFInF7Screen(0);
        autofillTestScripts.enrollAFInF7Screen(1);
        autofillTestScripts.verifyStatusCode(multiRxNbr.get(0), "4");
        Reporter.log("RX Number: " + multiRxNbr.get(0) + ", Autofill Status Code Updated to 4(Pending)");
        autofillTestScripts.verifyStatusCode(multiRxNbr.get(1), "4");
        Reporter.log("RX Number: " + multiRxNbr.get(1) + ", Autofill Status Code Updated to 4(Pending)");
        autofillTestScripts.updatePatientState("ToVerbal");
        autofillTestScripts.verifyStatusCode(multiRxNbr.get(0), "2");
        Reporter.log("RX Number: " + multiRxNbr.get(0) + ", Autofill Status Code Updated to 2(Enrolled)");
        autofillTestScripts.verifyStatusCode(multiRxNbr.get(1), "2");
        Reporter.log("RX Number: " + multiRxNbr.get(1) + ", Autofill Status Code Updated to 2(Enrolled)");
    }

    @Test(enabled = true, description = "AF_written_to_verbal_state",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_4690(Map<String, String> inputData) {
        Reporter.log("<<<Validating AF enrolled status changed to Enrolled on updating verbal from written state>>>");
        connexusAppUtils.getStoreId();
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("OK");
        autofillTestScripts.restartConnexusService(flagUpdated);
        autofillTestScripts.initializeTestCase(false, false);
        autofillTestScripts.CreatePatientAndMoveOrderToChkDUR(inputData);
        autofillTestScripts.loginConnexus();
        autofillTestScripts.enrollAFInF7Screen(0);
        autofillTestScripts.verifyStatusCode("4");
        Reporter.log("Status Code Updated to 4 - Pending");
        autofillTestScripts.updatePatientState("ToVerbal");
        Reporter.log("State is changed to verbal consent state (AR)");
        autofillTestScripts.launchF7ScreenAndValidateAutofillCheckboxIsEnrolled();
        Reporter.log("Autofill status update to enroll status when updating written to verbal");
    }
}