package connexus.Autofill.testcases;

import connexus.Autofill.testscripts.Autofill_scripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

public class Autofill_testcases {

    Autofill_scripts autofillScripts = new Autofill_scripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    PropertyReader prop = PropertyReader.getInstance();
    String siteId =prop.getProperty("cnx.store");
    boolean flagUpdated = false;

    @BeforeClass
    public void loginToConnexus() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    @Test(enabled = true, description = "AF status is set to Unenrolled with today's date in Verbal Consent States " +
            "when Rx is unenrolled via Connexus AF Checkbox in F7 Lookup screen",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_1645(Map<String, String> inputData) {
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        autofillScripts.restartConnexusService();
        autofillScripts.initializeTestCase(false,false);
        autofillScripts.CreatePatientAndMoveOrderToChkDUR(inputData);
        autofillScripts.loginConnexus();
        autofillScripts.enrollAutoFillInF7Screen();
        autofillScripts.verifyStatusCode("2");
        Reporter.log("Status Code Updated to 2");
        autofillScripts.unenrollAutoFillInF7Screen();
        autofillScripts.verifyStatusCode("3");
        Reporter.log("Status Code Updated to 3");
    }

    @Test(enabled = true, description = "Restrict AF for 2301 drug_control_code drugs.",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_1646(Map<String, String> inputData) {
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        autofillScripts.restartConnexusService(flagUpdated);
        autofillScripts.initializeTestCase(false, false);
        autofillScripts.CreatePatientAndMoveOrderToChkDUR(inputData);
        autofillScripts.loginConnexus();
        autofillScripts.validateAFDisabledAtF7();
        autofillScripts.verifyAFDisabledatModifyDetailsScreen();
        autofillScripts.verifyAFDisabledatDropoffScreen();
    }

    @Test(enabled = true, description = "Validate_AF_enroll_compound_drug_written_state",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_1651(Map<String, String> inputData) {
        Reporter.log("<<<Validate AF enrolled for compound drug>>>");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        autofillScripts.restartConnexusService(flagUpdated);
        autofillScripts.initializeTestCase(false, false);
        autofillScripts.CreatePatientAndMoveOrderToChkDUR(inputData);
        autofillScripts.loginConnexus();
        autofillScripts.enrollAFInF7Screen(0);
        autofillScripts.verifyStatusCode("2");
        Reporter.log("Status Code Updated to 2 - Enrolled");
    }

    @Test(enabled = true, description = "Validate AF status is set to Pending with today's date in Written Consent States when Rx is enrolled via Connexus using AF Checkbox in Dropoff screen",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_1642(Map<String, String> inputData) {
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("OK");
        autofillScripts.restartConnexusService(flagUpdated);
        autofillScripts.initializeTestCase(false, false);
        autofillScripts.CreatePatientAndMoveOrderToChkDUR(inputData);
        autofillScripts.loginConnexus();
        autofillScripts.enrolledAutoFillInDropOff();
        autofillScripts.validateAFDisabledAtF7();
        autofillScripts.moveRxToEod(siteId);
        autofillScripts.validateunenrollAutoFillInF7Screen();
        autofillScripts.verifyStatusCode("4");
        Reporter.log("Autofill Status Code remain 4 - pending");
    }

    @Test(enabled = true, description = "Validate AF Refill Rx is dropped in Written consent states even when the enrollment status is Pending.",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_1639(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("OK");
        autofillScripts.restartConnexusService(flagUpdated);
        autofillScripts.initializeTestCase(false,false);
        autofillScripts.CreatePatientAndMoveOrderToChkDUR(inputData);
        autofillScripts.loginConnexus();
        autofillScripts.enrollAutoRefillModifyDetails(0);
        autofillScripts.verifyStatusCode("4");
        Reporter.log("Status Code Updated to 4");
        Reporter.log("Autofill Status : Pending");
        autofillScripts.moveRxToEod(siteId);
        autofillScripts.performDropOffForRXWithNoRefills();
        autofillScripts.launchModifyDetailsScreenAndValidateAutoFillStatusISEnrolledOrUnEnrolled();
        Reporter.log("Validated AF status is unenrolled at Modify Details Screen");
    }

    @Test(enabled = true, description = "Verify if the AF Out of Refills/Expired Report in CNX is discontinued",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_1653(Map<String, String> inputData) {
        autofillScripts.initializeTestCase(false, false);
        autofillScripts.CreatePatientAndMoveOrderToChkDUR(inputData);
        autofillScripts.loginConnexus();
        autofillScripts.enrollAutoFillInF7Screen();
        autofillScripts.moveRxToEod(siteId);
        autofillScripts.checkPatientStatusOnAutoRefillReport();
        Reporter.log("RX is enrolled in Autofill and the patient status is checked on the Autofill Report");
    }

    @Test(enabled = true, description = "Check that tooltip is showing up when we hover -over on Auto fill checkbox in Modify details screen.",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Autofill/Autofill.xlsx", sheetName = "Autofill")
    public void HWPHME2E_1931(Map<String, String> inputData) {
        autofillScripts.restartConnexusService(true);
        autofillScripts.initializeTestCase(false, false);
        autofillScripts.CreatePatientAndMoveOrderToChkDUR(inputData);
        autofillScripts.insertCodeInDB(inputData);
        autofillScripts.loginConnexus();
        autofillScripts.performChkDUR();
        autofillScripts.launchModifyDetailsAndValidateAutoFillTooltip(WorkQueue.FILLING);
        Reporter.log("Tooltip is shown up when we hover -over on Auto fill checkbox in Modify details screen");
    }
}