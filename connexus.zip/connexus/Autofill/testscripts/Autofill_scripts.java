package connexus.Autofill.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.appium.java_client.AppiumBy;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.Map;

public class Autofill_scripts extends ConnexusTestScripts {

    private String rxNbr1;
    ServiceRequest req = new ServiceRequest();
    PropertyReader prop = PropertyReader.getInstance();
    ServiceResponse resp;
    HashMap<String, String> headers = new HashMap<>();

    public Autofill_scripts(LoginAs.userType loginUserType) {
        super(loginUserType);
    }

    public void openRxLookUpPage() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(name[0] + "," + name[1]);
            rxLookUp.clickSearch();
            rxLookUp.isElementDisplayed(AppiumBy.name("Auto Refill Row " + 0));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Rx look up page not opened");
            softAssert.fail(e.toString());
        }
    }

    public void enrollAFInF7Screen(String enrollmentStatus) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openRxLookUpPage();
            if (rxLookUp.isAutoFillCheckBoxEnabled(0)) {
                rxLookUp.selectAutoFillCheckBox(0);
                rxLookUp.clickUpdateBtn();
                rxLookUp.clickbtnYes();
                rxLookUp.changesbutton();
                rxLookUp.changesbutton();

                if (!rxLookUp.isAutoFillSelected(0).equals(enrollmentStatus)) {
                    String msg = "Autofill check not " + (enrollmentStatus.equals("True") ? "Selected" : enrollmentStatus);
                    Reporter.log(msg);
                    Assert.fail(msg);
                }
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                rxLookUp.closeSearch();
            } else {
                Assert.fail("Autofill checkbox is not enabled");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at enrollement queue");
            softAssert.fail(e.toString());
        }
    }

    public void AutoFillStatusInF7ScreenIsPending() {
        try {
            openRxLookUpPage();
            String status = rxLookUp.getautorefillstatus(0);
            Reporter.log("Auto-refill_status in UI " + "---" + status);
            Assert.assertEquals(status, "Pending");
            String statusCode=connexusAppUtils.getStatusCodeFromDB(rxNbr,"status_Code");
            Reporter.log("Autofill status Pending as " + statusCode + " in DB");
            if ("4".equals(statusCode)) {
                Assert.assertTrue(true, "Pending");
            } else {
                Assert.fail("Autofill is not in Pending state");
            }
            Reporter.log("Autofill is Pending Status In DB");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Rx_lookup");
            softAssert.fail(e.toString());
        }
    }

    public void updatePatientState(String toState) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            String patientName = name[0] + "," + name[1];
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRow(0);
            if (toState.equalsIgnoreCase("ToWritten")) {
                patientMaintenancePage.updateZipCode("73101");
            } else {
                patientMaintenancePage.updateZipCode("72713");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            patientSearchPage.clickasEntered();
            patientSearchPage.clickasEnteredOK();
            patientMaintenancePage.clickOk();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public void searchPatientWithName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRow(0);
            patientMaintenancePage.selectStateDropDownValue();
            patientMaintenancePage.clickSaveAndClose();
            patientMaintenancePage.selectAsEnteredRadioButtonAndClickOkOnAddressValidation();
            patientMaintenancePage.clickOk();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());

        }
    }

    public void enrollAutoFillInF7Screen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openRxLookUpPage();
            rxLookUp.clickAutoFillCheckBox();
            rxLookUp.clickUpdateBtn();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.clickbtnYes();
            rxLookUp.clickconnexusOkButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.closeSearch();
            rxLookUp.clickSubmit();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void launchModifyDetailsScreenAndValidateAutoFillStatusISEnrolledOrUnEnrolled() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            modifyDetails.openModifyDetailsScreen();
            modifyDetails.clickAutoFillPending();
            if (modifyDetails.isChkBoxAutoFillEnabled()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            }
            else{
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Autofill status is Disabled or Unenrolled in Modify screen");
            }
            modifyDetails.clickCancel();
            modifyDetails.clickButtonYes();
            VisVerPage visVerPage = new VisVerPage();
            visVerPage.clickCancel();
        } catch(Throwable e){
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }

    }
    public void verifyAutoFillStatusisEnrolledInDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            Assert.assertTrue(dropOffPage.isAutoFillCheckBoxEnabled(0));
            if (dropOffPage.isAutoFillCheckBoxEnabled(0)) {
                Reporter.log("Autofill status is pending in Drop Off");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                dropOffPage.clickBtnAccept();
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void launchF7ScreenAndSearchPatient() {
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            openRxLookUpPage();
            if (rxLookUp.isAutoFillCheckBoxEnabled(0)) {
                Reporter.log("AF is UnEnrolled in F7");
            } else {
                Reporter.log("AF is Enrolled in F7");
                Assert.fail("AF is Enrolled in F7");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("F7 screen not launched");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enrollAutoRefillModifyDetails(int index) {

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue()) || checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue()) || checkOrderQueueDB(rxNbr, WorkQueueSettings.Filling.getValue())) {
            try {
                orderSearch.openSearch();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.openModifyDetailsScreen();
                modifyDetails.clickAutoFillCheckBox();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickAccept();
                modifyDetails.clickok();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } catch (Exception e) {
                isExceptionCaptured = true;
                Assert.fail("CheckDUR failed" + e.getStackTrace());
                Reporter.log("Test failed at ChkDUR queue" + e.getStackTrace());
            }
        } else {
            Assert.fail("RX is not in CheckDUR | 4Point | Filling work queue");
            Reporter.log("RX is not in CheckDUR | 4Point | Filling work queue");
        }
    }


    public void validateAFDisabledAtF7() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openRxLookUpPage();
            rxLookUp.disabledAutoFillCheckBox();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.closeSearch();
            rxLookUp.clickSubmit();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyStatusCode(String rxNbr, String statusCodeToValidate) {
        try {
            String statusCode=connexusAppUtils.getStatusCodeFromDB(rxNbr,"status_Code");
            Assert.assertEquals(statusCode, statusCodeToValidate);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyStatusCode(String expectedStatusCode) {
        try {
            String statusCode = connexusAppUtils.getStatusCodeFromDB(rxNbr, "status_code");
            Assert.assertEquals(statusCode, expectedStatusCode);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void unenrollAutoFillInF7Screen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        F6Search f6Search = new F6Search();
        try {
            openRxLookUpPage();
            rxLookUp.clickAutoFillCheckBox();
            rxLookUp.clickUpdateBtn();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, f6Search.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.clickbtnYes();
            rxLookUp.clickconnexusOkButton();
            rxLookUp.clickconnexusOkButton();
            rxLookUp.closeSearch();
            rxLookUp.clickSubmit();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void verifyAFDisabledatModifyDetailsScreen() {

        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())){
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                orderSearch.openFirstPatientRecord();
                modifyDetails.launchModifyDetailScreen();
                modifyDetails.verifyAFDisabled();
                modifyDetails.clickCancel();
                modifyDetails.clickYes();
                modifyDetails.clickCancel();
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            throw new RuntimeException(e);
        }

    }

    public void verifyAFDisabledatDropoffScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        dropOff.enterPatientName(name[0] + "," + name[1]);
        dropOff.clickPatientSearch();
        dropOff.handleAnnualValidatePatInfoPopUp();
        dropOff.verifyAFDisabled();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        dropOff.clickBtnCancel();
        dropOff.clickYes();
    }

    public void drop2RXTillChkDUR(Map<String, String> inputData) {
        DropRxModel dropRxModel = new DropRxModel();
        RxModel rxModel = new RxModel();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        dropOffWith2Drug(name[0] + "," + name[1], Priority.Critical, 1, "12:30");

        rxModel.setPatientLastName(name[0]);
        rxModel.setPatientFirstName(name[1]);
        rxModel.setNdc(inputData.get("DRUG_NAME"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
        automationManager.getConnexusWorkFlow().performInput(rxModel);

        performInput2ndRX(name[0] + "," + name[1], inputData.get("DRUG_NAME"), inputData.get("QUANTITY"), inputData.get("SIG"), inputData.get("REFILLS"), inputData.get("PRESCRIBER_NAME"));
        F6Search rxSearch = new F6Search();
        rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
        rxNbr = rxSearch.getRxNbr(0);
        System.out.println(rxNbr);
        rxNbr1 = rxSearch.getRxNbr(1);
        System.out.println(rxNbr1);
        rxSearch.closeSearch();
        automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);
        this.performFourPoint2ndRX(name[0] + "," + name[1]);

    }

    public void dropOffWith2Drug(String patientName, Priority priority, int noOfRx, String pickupTime) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        dropOff.enterPatientName(patientName);
        dropOff.clickPatientSearch();
        dropOff.handleAnnualValidatePatInfoPopUp();
        dropOff.clickScanNewRx();
        dropOff.switchWindow();
        String barCode = dropOff.generateRxBarCode();
        dropOff.enterBarCode(barCode);
        Reporter.log("New barcode entered " + barCode);
        dropOff.clickBtnAccept();
        dropOff.switchWindow();
        dropOff.clickVerifyBarCode();
        dropOff.selectRxOrigin();
        dropOff.clickBtnAccept();

        //2nd RX  :

        dropOff.clickScanNewRx();
        dropOff.switchWindow();
        String barCode1 = dropOff.generateRxBarCode();
        dropOff.enterBarCode(barCode1);
        Reporter.log("New barcode entered " + barCode1);
        dropOff.clickBtnAccept();
        dropOff.switchWindow();
        dropOff.clickVerifyBarCode();
        dropOff.selectRxOrigin();
        dropOff.clickBtnAccept();
        dropOff.addNoOfRx(barCode1, noOfRx);
        dropOff.selectPriority(priority.getPriority());
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        if (priority == Priority.Future) {
            dropOff.selectPickupTime(pickupTime);
        }
        dropOff.clickBtnAccept();
        dropOff.checkAndClickDropOffStation();
        Reporter.log("Drop-Off completed");
    }

    public void performInput2ndRX(String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        F6Search rxSearch = new F6Search();
        InputPage inputPage = new InputPage();
        rxSearch.performSearch(patientName, SearchType.PatientRx);
        rxSearch.selectRowFromSearch(1);
        inputPage.enterNdc(ndc);
        inputPage.clickProductSearch3Dots();
        inputPage.enterPrescribedQty(prescribedQty);
        inputPage.enterSigCode(sigCode);
        inputPage.enterRefillQty(refills);
        inputPage.selectDAW(1);
        inputPage.enterPrescriber(prescriberName);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        inputPage.clickAccept();
        inputPage.pressKeys(KeyEvent.VK_ENTER);
        Reporter.log("Input completed for 2nd RX");
    }

    public String performFourPoint2ndRX(String patNameOrRxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        automationManager.getConnexusWorkFlow().checkRxWorkQue(patNameOrRxNbr, WorkQueue.FOUR_POINT);
        FourPoint fourpoint = new FourPoint();
        F6Search rxSearch = new F6Search();
        rxSearch.performSearch(patNameOrRxNbr, SearchType.PatientRx);
        rxNbr1 = rxSearch.getRxNbr(1);
        Reporter.log("Rx number is " + rxNbr1);
        while ("DUR".equalsIgnoreCase(rxSearch.getWorkQueue(1))) {
            rxSearch.pressKeys(KeyEvent.VK_F6);
        }
        rxSearch.selectRowFromSearch(1);
        fourpoint.chkName();
        fourpoint.chkPrescribed();
        if (fourpoint.ischkStrength()) {
            fourpoint.chkStrength();
        }
        fourpoint.chkSIG();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
        fourpoint.clickAccept();
        Reporter.log("4 point completed");
        ChkDur dur = new ChkDur();
        if (dur.isChkDurOpen()) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("CheckDUR " + dur.takeScreenShot("CheckDUR").getKey());
            dur.selectCheckBoxes();
            dur.clickAccept();
        }
        return rxNbr1;
    }
    public void enrollAFInF7Screen(int index) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openRxLookUpPage();
            if (rxLookUp.isAutoFillCheckBoxEnabled(index)) {
                rxLookUp.selectAutoFillCheckBox(index);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                rxLookUp.clickUpdateBtn();
                rxLookUp.clickbtnYes();
                rxLookUp.changesbutton();
                rxLookUp.changesbutton();
                rxLookUp.closeSearch();
            } else {
                Assert.fail("Autofill is not Pending state");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at enrollement queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void enrollAFInF7Screen2rx() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openRxLookUpPage();
            if (rxLookUp.isAutoFillCheckBoxEnabled(1)) {
                rxLookUp.selectAutoFillCheckBox(1);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                rxLookUp.clickUpdateBtn();
                rxLookUp.clickbtnYes();
                rxLookUp.changesbutton();
                rxLookUp.closeSearch();
            } else {
                Assert.fail("Autofill is not Pending state");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at enrollement queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enrollAutoFillStatusInF7Screen1rx() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openRxLookUpPage();
            String status = rxLookUp.getautorefillstatus(0);
            System.out.println("Auto-refill_status" + "---" + status);
            Assert.assertEquals(status, "Pending");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enrollAutoFillStatusInF7Screen2rx() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openRxLookUpPage();
            String status = rxLookUp.getautorefillstatus(1);
            System.out.println("Auto-refill_status" + "---" + status);
            Assert.assertEquals(status, "Pending");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void enrolledAutoFillInDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();

            dropOffPage.clickDropOffQueue();
            if (!rxSearch.isDropOffDisplayed()) {
                Assert.fail("DropOff page - failed to load");
            }
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            if (dropOffPage.isAutoFillCheckBoxEnabled(0)) {
                dropOffPage.selectAutoFillCheckBox(0);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Autofill Status is enrolled in DropOff");
                dropOffPage.clickBtnAccept();
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at enrolledAutoFillInDropOff method");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void validateunenrollAutoFillInF7Screen() {
        String currentStepMethodName =StackUtils.getCurrentMethodName();
        try {
            openRxLookUpPage();
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void launchF7ScreenAndValidateAutofillCheckboxIsEnrolled() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(name[0] + "," + name[1]);
            rxLookUp.clickSearch();
            if (rxLookUp.isAutoFillCheckBoxEnabled(0)) {
                String statusCode=connexusAppUtils.getStatusCodeFromDB(rxNbr,"status_Code");
                Reporter.log("Status_code:=  " + statusCode);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
                if ("2".equals(statusCode)) {
                    Assert.assertTrue(true, "Enrolled");
                    Reporter.log("Validate Autofill status is Enrolled in DB");
                } else {
                    Assert.fail("Autofill is not Enrolled");
                }
                Reporter.log("Autofill checkbox is enrolled in F7 screen");
            } else {
                Assert.fail("AF is Enrolled in F7");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("F7 screen not launched");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void insertCodeInDB(Map<String, String> inputData) {
        try {
            connexusAppUtils.insertRequestTypeCode(rxNbr, inputData.get("REQUEST_TYPE_CODE"), inputData.get("USER_ID"));
            Reporter.log("Code inserted to DB for RX: " + rxNbr);
        } catch (Exception e) {
            Reporter.log("Failed to insert code to DB");
            softAssert.fail(e.toString());
        }
    }

    public void launchModifyDetailsAndValidateAutoFillTooltip(WorkQueue workQueue) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(workQueue.getWorkQueue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                orderSearch.openFirstPatientRecord();
                modifyDetails.launchModifyDetailsPage();
                modifyDetails.verifyAFandGetTooltip();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickCancel();
                modifyDetails.clickButtonYes();
            } else {
                Reporter.log(String.format("RX is not in %s queue", workQueue.getWorkQueue()));
                Assert.fail(String.format("RX is not in %s queue", workQueue.getWorkQueue()));
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }

    }

    public void updateStoreState(String state) {
        connexusAppUtils.updateStoreState(state);
    }

    public void clearCache(){
        callFlushCacheAPI(prop.getProperty("cnx.store"));
    }
    public void callFlushCacheAPI(String siteID) {
        String serviceEndPointURL = StoreIDManager.createEndPointURL(siteID, prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexustestharness.flushCacheEndPoint"));
        req.setUrl(serviceEndPointURL);
        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        resp = automationManager.getRestContext().performPost(req);
        Assert.assertEquals(resp.getStatusCode(), 200, "Flush Cache not Successful");
        Log.info("Flush Cache Successful");
    }

    public void verifyAutoFillStatusInDropOffISEnrolled() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            DropOffPage dropOff = new DropOffPage();
            dropOff.clickDropOffQueue();
            dropOff.enterPatientName(name[0] + "," + name[1]);
            dropOff.clickPatientSearch();
            dropOff.handleAnnualValidatePatInfoPopUp();
            if (dropOffPage.isAutoFillCheckBoxEnabled(0)) {
                Reporter.log("AutoFill box is checked and enrolled");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                dropOffPage.clickBtnAccept();
                String statusCode=connexusAppUtils.getStatusCodeFromDB(rxNbr,"status_Code");
                Reporter.log("status_Code is " + statusCode);
                if (statusCode.equals("2")) {
                    Assert.assertTrue(true, "Enrolled");
                    Reporter.log("Autofill Status is validate Enrolled(2) in DB");
                } else {
                    Reporter.log("Autofill is not Enrolled state in DB");
                    Assert.fail("Autofill is not Enrolled state in DB for dropoff screen");
                }
                Reporter.log("Autofill status is Enrolled in Drop off");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue for enrolled status");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyAutoFillStatusISUnEnrolledInDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            Assert.assertTrue(dropOffPage.isAutoFillCheckBoxEnabled(0));
            if (dropOffPage.isAutoFillCheckBoxEnabled(0)) {
                dropOffPage.selectAutoFillCheckBox(0);
                Reporter.log("AutoFill is UnEnrolled in DropOff");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                dropOffPage.clickBtnAccept();
                String statusCode=connexusAppUtils.getStatusCodeFromDB(rxNbr,"status_Code");
                if (statusCode.equals("3")) {
                    Assert.assertTrue(true, "UnEnrolled");
                } else if (statusCode.equals("null")) {
                    Assert.assertTrue(true, "Disabled");
                    Reporter.log("Autofill is Disabled");
                }
                Reporter.log("Autofill Status is validate in UnEnrolled in DB");
            } else {
                Reporter.log("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue for Unenrolled status");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyAutoFillStatusIsDisabledInDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            Assert.assertTrue(dropOffPage.isAutoFillCheckBoxEnabled(0));
            if (dropOffPage.isAutoFillCheckBoxEnabled(0)) {
                dropOffPage.selectAutoFillCheckBox(0);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("AutoFill is Disabled in DropOff");
                dropOffPage.clickBtnAccept();
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enrollAutoFillStatusInF7Screen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(name[0] + "," + name[1]);
            rxLookUp.clickSearch();
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (rxLookUp.isAutoFillCheckBoxEnabled(0)) {
                rxLookUp.selectAutoFillCheckBox(0);
                rxLookUp.clickUpdateBtn();
                rxLookUp.clickYesButton();
                rxLookUp.clickOkButton();
                rxLookUp.clickOkButton();
                rxLookUp.closeSearch();
                String statusCode=connexusAppUtils.getStatusCodeFromDB(rxNbr,"status_Code");
                if (statusCode.equals("4")) {
                    Reporter.log("Autofill status is Pending in F7 screen");
                } else {
                    Assert.fail("Autofill is not Pending state");
                }

                dropOffPage.clickBtnAccept();
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void TryEnrollingAutoFillStatusInF7ScreenAndVerifyAFIsDisabled() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(name[0] + "," + name[1]);
            rxLookUp.clickSearch();
            rxLookUp.selectAutoFillCheckBox(0);
            if (rxLookUp.isAutoFillSelected(0).equals("True")) {
                Reporter.log("Auto Fill Check Box is Enabled for Control Drug");
                Assert.fail("Auto Fill Check Box is Enabled for Control Drug");
            } else {
                Reporter.log("Autofill Checkbox is disabled as expected");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                rxLookUp.closeSearch();
                rxLookUp.clickYesButton();
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at F7 screen");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void checkAutoFillStatusInDropOffIsPending() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropOffPage.clickDropOffQueue();
            if (!rxSearch.isDropOffDisplayed()) {
                Assert.fail("DropOff page - failed to load");
            }
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            dropOffPage.chkDropOffStationPopup();
            if (dropOffPage.isAutoFillCheckBoxEnabled(0)) {
                String statusCode=connexusAppUtils.getStatusCodeFromDB(rxNbr,"status_Code");
                if (statusCode.equals("4")) {
                    Assert.assertTrue(true, "Pending");
                } else {
                    Assert.fail("Autofill is not Pending Status in DB");
                }
                Reporter.log("Autofill Status is validate in DB- Pending");
                Reporter.log("Autofill Status Is Pending in Drop Off");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                dropOffPage.clickBtnAccept();
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void checkPatientStatusOnAutoRefillReport() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.AUTO_REFILL_ENROLLMENT_REPORT, AppMenuItemsIndex.RX_REPORTS, AppMenuSubItemsIndex.AUTO_REFILL_ENROLLMENT_REPORT,null);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            menuBar.clickOnPatientRdBtnforAutofillReport(name[0] + "," + name[1]);
            menuBar.openReportByClickingOnShowReportButton();
            Reporter.log("Report is generated with Enrolled/UnEnrolled/Pending status");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Show Report screen not launched");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void autoRefillEnrollmentReport() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.AUTO_REFILL_ENROLLMENT_REPORT_MO, AppMenuItemsIndex.RX_REPORTS, AppMenuSubItemsIndex.AUTO_REFILL_ENROLLMENT_REPORT_MO,null);
            menuBar.clickEnrollmentStatusSort();
            menuBar.clickBtnShowReport();
            menuBar.findReport("Enrolled");
            Reporter.logScreenShot(Status.PASS, "AutoRefill - Enrolled", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            menuBar.findReport("Unenrolled");
            Reporter.logScreenShot(Status.PASS, "AutoRefill - Unenrolled", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            menuBar.findReport("Pending");
            Reporter.logScreenShot(Status.PASS, "AutoRefill - Pending", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Show Report screen not launched");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void restartConnexusService(boolean flagUpdated) {
        if (flagUpdated) {
            Reporter.log("Restarting Connexus service to apply updated flags");
            connexusAPIManager.restartConnexusService(siteIDString);
            relaunchConnexus = true;
        }
    }
}