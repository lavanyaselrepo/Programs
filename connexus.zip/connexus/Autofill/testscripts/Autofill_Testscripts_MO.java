package connexus.Autofill.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import connexus.Narxcare_testcases.testcases.Logicoy_Testcases;
import connexus.OrderCreation.testcases.OrderCreationRegressionTestSet2;
import connexus.OrderCreation.testcases.OrderCreationRegressionTestSet5;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import java.util.HashMap;
import java.util.Map;

public class Autofill_Testscripts_MO extends ConnexusTestScripts {

    ServiceRequest req = new ServiceRequest();
    PropertyReader prop = PropertyReader.getInstance();
    ServiceResponse resp;
    HashMap<String, String> headers = new HashMap<>();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();

    public Autofill_Testscripts_MO(LoginAs.userType loginUserType){
        super(loginUserType);
        connexusAppUtils = new ConnexusAppUtils();
        automationManager = AutomationManager.getInstance();
    }

    public void restartService() {
        connexusAPIManager.restartConnexusService(String.valueOf(siteId));
    }

    public void updateState(Map<String, String> inputData) {
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
    }

    public void searchPatientWithName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRow(0);
            patientMaintenancePage.selectStateDropDownValue();
            patientMaintenancePage.clickSaveAndClose();
            patientMaintenancePage.selectAsEnteredRadioButtonAndClickOkOnAddressValidation();
            patientMaintenancePage.clickOk();
            Reporter.logScreenShot(Status.PASS, inputData.get("TEST_NAME") + "_" + currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }


    public void updateStoreState(String state) {
        connexusAppUtils.updateStoreState(state);
    }

    public void clearCache(){
        callFlushCacheAPI(prop.getProperty("cnx.store"));
    }
    public void callFlushCacheAPI(String siteID) {
        String serviceEndPointURL = StoreIDManager.createEndPointURL(siteID, prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexustestharness.flushCacheEndPoint"));
        req.setUrl(serviceEndPointURL);
        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        resp = automationManager.getRestContext().performPost(req);
        Assert.assertEquals(resp.getStatusCode(), 200, "Flush Cache not Successful");
        Log.info("Flush Cache Successful");
    }

    public void verifyAutoFillStatusInDropOffISEnrolled() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            DropOffPage dropOff = new DropOffPage();
            dropOff.clickDropOffQueue();
            dropOff.enterPatientName(name[0] + "," + name[1]);
            dropOff.clickPatientSearch();
            if (dropOffPage.isAutoFillCheckBoxEnabled(0)) {
                Reporter.log("AutoFill box is checked and enrolled");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                dropOffPage.clickBtnAccept();
                String statusCode=connexusAppUtils.getStatusCodeFromDB(rxNbr,"status_Code");
                Reporter.log("status_Code is " + statusCode);
                if ("2".equals(statusCode)) {
                    Assert.assertTrue(true, "Enrolled");
                    Reporter.log("Autofill Status is validate Enrolled(2) in DB");
                } else {
                    Reporter.log("Autofill is not Enrolled state in DB");
                    Assert.fail("Autofill is not Enrolled state in DB for dropoff screen");
                }
                Reporter.log("Autofill status is Enrolled in Drop off");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue for enrolled status");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void launchF7ScreenAndSearchPatient() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(name[0] + "," + name[1]);
            rxLookUp.clickSearch();
            if(rxLookUp.isAutoFillCheckBoxEnabled(0)){
                Assert.assertTrue(true, "UnEnrolled");
                Reporter.log("AF is UnEnrolled in F7") ;
            }
            else{
                Reporter.log("AF is Enrolled in F7");
                Assert.fail("AF is Enrolled in F7");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("F7 screen not launched");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void launchModifyDetailsScreenAndValidateAutoFillStatusISEnrolledOrUnEnrolled(WorkQueue workQueue) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(workQueue.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(name[0] + "," + name[1]);
                patientSearchPage.openFirstPatientRecord();
                modifyDetails.launchModifyDetailsPage();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                if (modifyDetails.isChkBoxAutoFillEnabled()) {
                    Reporter.log("Autofill is enrollred in modify screen");
                } else {
                    Reporter.log("Autofill is unenrolled in modify screen");
                }
                modifyDetails.clickCancel();
                modifyDetails.clickButtonYes();
            } else {
                Reporter.log(String.format("RX is not in %s queue", workQueue.getWorkQueue()));
                Assert.fail(String.format("RX is not in %s queue", workQueue.getWorkQueue()));
            }
        } catch(Throwable e){
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }

    }

    public void verifyAutoFillStatusISUnEnrolledInDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();

            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            Assert.assertTrue(dropOffPage.isAutoFillCheckBoxEnabled(0));
            if (dropOffPage.isAutoFillCheckBoxEnabled(0)) {
                dropOffPage.selectAutoFillCheckBox(0);
                Reporter.log("AutoFill is UnEnrolled in DropOff");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                dropOffPage.clickBtnAccept();
                String statusCode=connexusAppUtils.getStatusCodeFromDB(rxNbr,"status_Code");
                if ("3".equals(statusCode)) {
                    Assert.assertTrue(true, "UnEnrolled");
                } else if ("null".equals(statusCode)) {
                    Assert.assertTrue(true, "Disabled");
                    Reporter.log("Autofill is Disabled");
                }
                Reporter.log("Autofill Status is validate in UnEnrolled in DB");
            } else {
                Reporter.log("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue for Unenrolled status");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyAutoFillStatusIsDisabledInDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            Assert.assertTrue(dropOffPage.isAutoFillCheckBoxEnabled(0));
            if (dropOffPage.isAutoFillCheckBoxEnabled(0)) {
                dropOffPage.selectAutoFillCheckBox(0);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("AutoFill is Disabled in DropOff");
                dropOffPage.clickBtnAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enrollAutoFillStatusInF7Screen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(name[0] + "," + name[1]);
            rxLookUp.clickSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (rxLookUp.isAutoFillCheckBoxEnabled(0)) {
                rxLookUp.selectAutoFillCheckBox(0);
                rxLookUp.clickUpdateBtn();
                rxLookUp.clickYesButton();
                rxLookUp.clickOkButton();
                rxLookUp.clickOkButton();
                rxLookUp.closeSearch();
                String statusCode=connexusAppUtils.getStatusCodeFromDB(rxNbr,"status_Code");
                if ("4".equals(statusCode)) {
                    Assert.assertTrue(true, "Pending");
                } else {
                    Assert.fail("Autofill is not Pending state");
                }
                Reporter.log("Autofill status is Pending in F7 screen");
                Reporter.log("Autofill status is validate In DB-Pending");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
                dropOffPage.clickBtnAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void TryEnrollingAutoFillStatusInF7ScreenAndVerifyAFIsDisabled() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(name[0] + "," + name[1]);
            rxLookUp.clickSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (rxLookUp.isAutoFillCheckBoxEnabled(0)) {
                rxLookUp.selectAutoFillCheckBox(0);
                Reporter.log("Autofill Box is disabled");
                rxLookUp.clickUpdateBtn();
                rxLookUp.clickYesButton();
                rxLookUp.closeSearch();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at F7 queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void checkAutoFillStatusInDropOffIsPending() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            dropOffPage.chkDropOffStationPopup();
            if (dropOffPage.isAutoFillCheckBoxEnabled(0)) {
                String statusCode=connexusAppUtils.getStatusCodeFromDB(rxNbr,"status_Code");
                if ("4".equals(statusCode)) {
                    Assert.assertTrue(true, "Pending");
                } else {
                    Assert.fail("Autofill is not Pending Status in DB");
                }
                Reporter.log("Autofill Status is validate in DB- Pending");
                Reporter.log("Autofill Status Is Pending in Drop Off");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                dropOffPage.clickBtnAccept();
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void checkAutofillAsEnrolledinF7() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(name[0] + "," + name[1]);
            rxLookUp.clickSearch();
            if (rxLookUp.isAutoFillCheckBoxEnabled(0)) {
                Assert.assertTrue(true, "Enrolled");
                Reporter.log("Autofill is Enrolled in F7");
            } else {
                Assert.fail("Autofill is not Enrolled");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.clickUpdateBtn();
            rxLookUp.clickbtnYes();
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("F7 screen not launched");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public int updateStatusCode(Map<String, String> inputData) {
        try {
            String statuscode = inputData.get("STATUS_CODE");
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientId = connexusAppUtils.getPatientId(name[0], name[1]);
            String rxID = automationManager.getConnexusDB().getScalar("select rx_id from rx where patient_id =" + patientId, String.class);
            String updateQuery = "update rx_autofill_enrollment set status_code = \"" + statuscode + "\" where rx_id = \"" + rxID + "\"" + ";";
            Reporter.log("Status code:" + updateQuery);
            Reporter.log("Status code updated to Enrolled in DB");
            return automationManager.getConnexusDB().executeUpdateQuery(updateQuery);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void enrollAutoFillStatusInF7ScreenAndVerifyIsPending(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(name[0] + "," + name[1]);
            rxLookUp.clickSearch();
            if (rxLookUp.isAutoFillCheckBoxEnabled(0)) {
                rxLookUp.selectAutoFillCheckBox(0);
                rxLookUp.clickUpdateBtn();
                rxLookUp.clickYesButton();
                rxLookUp.clickOkButton();
                String status = rxLookUp.getautorefillstatus(0);
                Reporter.log("Auto-refill_status in UI " + "---" + status);
                Assert.assertEquals(status, "Pending");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
                rxLookUp.closeSearch();
                String statusCode=connexusAppUtils.getStatusCodeFromDB(rxNbr,"status_Code");
                String statusCodeValue= inputData.get("STATUS_VALUE");
                Reporter.log("Status code in DB is " + statusCode);
                if (statusCode.equals(statusCodeValue)) {
                    Assert.assertTrue(true, "Pending");
                } else {
                    Assert.fail("Autofill is not Pending state");
                }
                Reporter.log("Autofill status is Pending in F7 screen");
                Reporter.log("Autofill status is validate In DB-Pending");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
                org.junit.Assert.fail("Auto Fill Check Box is not Displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at F7 screen ");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void selectVerbalConsentState(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRow(0);
            patientMaintenancePage.selectAnotherCountryStateDropdownValues();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("State is updated to Verbal Consent");
            patientMaintenancePage.clickSaveAndClose();
            patientMaintenancePage.selectAsEnteredRadioButtonAndClickOkOnAddressValidation();
            patientMaintenancePage.clickOk();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, inputData.get("TEST_NAME") + "_" + currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public void checkPatientStatusOnAutoRefillReport() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.AUTO_REFILL_ENROLLMENT_REPORT, AppMenuItemsIndex.RX_REPORTS, AppMenuSubItemsIndex.AUTO_REFILL_ENROLLMENT_REPORT,null);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            menuBar.clickOnPatientRdBtnforAutofillReport(name[0] + "," + name[1]);
            menuBar.openReportByClickingOnShowReportButton();
            Reporter.log("Report is generated with Pending and unenrolled status");
            Reporter.log("Enrolled status is not displayed in report as it updated through DB");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Show Report screen not launched");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
}


