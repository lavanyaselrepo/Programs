package connexus.OrderIntake_rxTransfer.TestCases;

import connexus.OrderIntakeERX.testscripts.OrderIntakeERXTestScript;
import connexus.OrderIntake_rxTransfer.TestScripts.RXTransferTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import prm.rxTransfer.api.wrapper.TransferInWrapper;
import prm.rxTransfer.api.wrapper.TransferOutWrapper;
import prm.rxTransfer.ui.testscripts.TransferInFlow_TestScripts;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;


public class RXTransferTestSet {
    RXTransferTestScript rxTransferTestScript = new RXTransferTestScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    TransferOutWrapper transferOutWrapper = new TransferOutWrapper();
    TransferInFlow_TestScripts transferInFlowTestScripts= new TransferInFlow_TestScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    boolean flagUpdated = false;
    TransferInWrapper transferINWrapper = new TransferInWrapper();
    PropertyReader prop = PropertyReader.getInstance();
    String stateCode;
    String siteId =prop.getProperty("cnx.store");

    @BeforeClass
    public void loginToConnexus() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    @Test(enabled = true, description = "When competitor request Rx to Walmart,pharmacist should able to reject the transfer by selecting the rejecting reason in eTransfer-request response screen",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/PrmData/RxTransferTestData/RXTTestData.json", sheetName = "TransferOut")
    public void HWPHME2E_5144_Reject_Transfer_By_Selecting_Rrejecting_Reason_When_Competitor_Request_Rx_To_Walmart(Map<String, String> inputData) throws Exception {

        //setting this flag,RX not authorised to transferred
        flagUpdated = connexusAppUtils.readAndUpdateFlag("27310", "N");
        rxTransferTestScript.initializeTestCase(flagUpdated,false);
        ServiceResponse initiationResponse = transferOutWrapper.sendTransferOutInitiationRequest(inputData);
        Reporter.log("Initiation Status code : " + initiationResponse.getStatusCode());
        if(initiationResponse.getStatusCode()==200) {
            rxTransferTestScript.loginConnexus();
            rxTransferTestScript.createRxTransfer(inputData);
            rxTransferTestScript.rejectETransferRequest(inputData);
            rxTransferTestScript.validateReasonCode(inputData);
        }
        else{
            Reporter.log(" Failed to Transfer Out Initiation Request ");
            Assert.fail();
        }
    }

    /**
     * Load the Rx in Requested eTransfer Out resolution in order search ( F6) screen and verify the eTransfer request screen.
     * @param inputData
     * @throws SQLException
     * @throws ParserConfigurationException
     * @throws IOException
     * @throws SAXException
     */
    @Test(enabled = true, description = "Load the Rx in Requested eTransfer Out resolution in order search ( F6) screen and verify the eTransfer request screen ( Patient details, requesting pharmacy , Eligible Rx's , Accept , Reject and Cancel buttons )",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RxTransferTestData/RXTTestData.json", sheetName = "TransferOut")
    public void HWPHME2E_5146_Verify_The_ETransfer_Request_Screen(Map<String, String> inputData) throws SQLException, ParserConfigurationException, IOException, SAXException {

        String xmlPayload="src//test//resources//TestData//Connexus//ERX_5337.xml";
        String initiationRequestPayload="src//test//resources//TestData//Connexus//eTransfer_5146.xml";
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("DRUG_NAME"));
        rxTransferTestScript.initializeTestCase(flagUpdated);
        rxTransferTestScript.createPatientAPI(inputData);
        rxTransferTestScript.performERX(inputData,xmlPayload,true);
        rxTransferTestScript.performInput(inputData,"Regular");
        rxTransferTestScript.verifyRxIn4PointQueue();
        rxTransferTestScript.performFourPointWithOnHoldStatus();
        rxTransferTestScript.PerformTransferRequest(inputData,initiationRequestPayload);
        rxTransferTestScript.validateRxInETransferQueue(inputData.get("PROBLEMDESCRIPTION"));
        rxTransferTestScript.validateTransferRequestScreen(inputData);
        rxTransferTestScript.validateElegibleRxCheckBoxFunctionality();

        Reporter.log("Verified the eTransfer request screen");
    }

    /**
     * Load Rx from Competitor store to Walmart and the pharmacist accepts the Etransferrred RX
     * @param inputData
     * @throws SQLException
     */
    @Test(enabled = true, description = "When competitor request Rx to Walmart,pharmacist should able to accept the transfer request",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RxTransferTestData/RXTTestData.json", sheetName = "TransferIn")
    public void HWPHME2E_5135_Rx_is_Processed_successfully_When_Competitor_Request_Rx_To_Walmart(Map<String, String> inputData) throws Exception {
        rxTransferTestScript.initializeTestCase(flagUpdated, false);
        ServiceResponse initiationResponse = transferINWrapper.sendUnsolicitedResponse(inputData, TransferInWrapper.ResponseType.unsolicited_response).getResponse();
        Reporter.log("Initiation Status code : " + initiationResponse.getStatusCode());
        if (initiationResponse.getStatusCode() == 200) {
            rxTransferTestScript.loginConnexus();
            rxTransferTestScript.eTranferVericationQuery(inputData);
            rxTransferTestScript.validatePatientWorkQueueAndProblemCode(inputData);
            rxTransferTestScript.acceptETransferRequest(inputData);
            rxTransferTestScript.posteTransferQueryValidation(inputData);
            rxTransferTestScript.validateRxWorkqueue(inputData);
        } else {
            Reporter.log(" Failed to Transfer In Initiation Request ");
            Assert.fail();
        }
    }


    @Test(enabled = true, description = "Walmart initiates transfer (Unsolicited - F7)- For already transferred Rx , eTransfer option disabled in Rx Lookup screen for pharmacist to transfer",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/PrmData/RxTransferTestData/RXTTransferTestData.json", sheetName = "RxTransfer")
    public void HWPHME2E_5143_For_Already_Transferred_Rx_eTransfer_Option_Disabled_In_Rx_Lookup_screen_for_Pharmacist_ToTransfer(Map<String, String> inputData) throws Exception {
        String transferOutResponseXml="prm.RxTransfer.TransferOutResponse.filePath";
        //setting this flag to enable RXT
        flagUpdated = connexusAppUtils.readAndUpdateFlag("27310", "N");
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("DRUG_NAME"));
        //initialize the test case
        rxTransferTestScript.initializeTestCase(flagUpdated);
        // create Patient through API
        rxTransferTestScript.createPatientAPI(inputData);
        // Drop off Rx through API
        rxTransferTestScript.performCompleteDropOffAPI(inputData);
        //Complete Input
        rxTransferTestScript.performInput(inputData);
        //Complete 4Point with OnHold checkbox clicked
        rxTransferTestScript.perform4PointWithOnHold();
        rxTransferTestScript.verifyeTransferInRxLookUpScreen(inputData);
        rxTransferTestScript.performETransferOutRequest(inputData);
        rxTransferTestScript.verifyDetailsOnOrderSearchScreen(inputData);
        rxTransferTestScript.validateDBForETransferRequest();
        rxTransferTestScript.verifyAndSendTransferOutResponse(inputData,transferOutResponseXml);
        rxTransferTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        rxTransferTestScript.verifyeTransferInRxLookUpScreen(inputData);

    }
    @Test(enabled = true, description = "When walmart request transferin to Walmart,competitor approve request then pharmacist should able to reject and then accept the transfer",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/PrmData/RxTransferTestData/RXTTransferTestData.json", sheetName = "RxTransfer")
    public void HWPHME2E_5250_Send_denial_response_but_then_click_Accept_to_send_the_Confirm_response_from_Walmart_to_Competitor(Map<String, String> inputData) throws Exception {
        String transferApprovedXml="prm.RxTransfer.TransferApproved.filePath";
        //setting this flag,RX not authorised to transferred
        flagUpdated = connexusAppUtils.readAndUpdateFlag("27310", "N");
        connexusAppUtils.getlogSiteIdAndState(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("DRUG_NAME"));
        transferInFlowTestScripts.initializeTestCase(flagUpdated,true);
        // create Patient through API
        transferInFlowTestScripts.createPatientAPI(inputData);
        String[] drugNames ={inputData.get("DRUG_NAME")};
        transferInFlowTestScripts.initiateTransferInRequestFromDropOff(inputData.get("PRIORITY"), inputData.get("COMPETITOR_PHARMACY_SEARCH"), drugNames);
        rxTransferTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        rxTransferTestScript.validateRxInETransferQueue(inputData.get("PROBLEMDESCRIPTION"));
        rxTransferTestScript.validateDBForETransferRequest(false);
        rxTransferTestScript.verifyAndSendTransferOutResponse(inputData,transferApprovedXml);
        rxTransferTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        rxTransferTestScript.validateRxInETransferQueue(inputData.get("PROBLEMDESCRIPTION1"));
        rxTransferTestScript.rejectAndAcceptConfirmETransferIn();
        rxTransferTestScript.validateWQAfterAcceptedConfirmETransferIn();
        Reporter.log("Verified the Confirm response from Walmart to Competitor");
    }


    @Test(enabled = true, description = "Perform eTransferIn for multiRx with delegating prescriber",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/PrmData/RxTransferTestData/RXTTransferTestData.json", sheetName = "RxTransfer")
    public void HWPHME2E_5138_MultiRx_XferIn_For_Delegating_Prescriber(Map<String, String> inputData) throws InterruptedException, IOException {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER1"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER2"));
        rxTransferTestScript.initializeTestCase(false);
        transferInFlowTestScripts.createPatientAPI(inputData);
        String[] drugNames = {inputData.get("NDC_NUMBER1"), inputData.get("NDC_NUMBER2")};
        transferInFlowTestScripts.initiateTransferInRequestFromDropOff(inputData.get("PRIORITY"), inputData.get("COMPETITOR_PHARMACY_SEARCH"), drugNames);
        rxTransferTestScript.checkProblemMessage("Pending eTransfer In", "Pending eTransfer In", false, false,false);
        rxTransferTestScript.validateDBPendingTransFerInMultiRx();
        String xmlPayload = "src//test//resources//TestData//PrmData//RxTransfer//transferIn_AttendingPhysician_Paylooad.xml";
        rxTransferTestScript.performTransferIn(inputData, xmlPayload, 0, inputData.get("NDC_NUMBER1"), inputData.get("DRUG_NAME"));
        rxTransferTestScript.checkProblemMessage("Pending eTransfer In", "Confirm eTransfer In", false, false,false);
        rxTransferTestScript.responseDBValidationTransferIn(0, 0,false);
        //rxImage validation required as per domain teams confirmation
        rxTransferTestScript.performTransferIn(inputData, xmlPayload, 1, inputData.get("NDC_NUMBER2"), inputData.get("DRUG_NAME"));
        rxTransferTestScript.checkProblemMessage("Confirm eTransfer In", "Confirm eTransfer In", true, false,false);
        //checking blob not required as per domain team confiramtion
        rxTransferTestScript.responseDBValidationTransferIn(1, 1,false);
        rxTransferTestScript.checkProblemMessage("Confirm eTransfer In", "Confirm eTransfer In", true, true,false);
        rxTransferTestScript.validateDBPostConfirmTransFerInMultiRx();
        rxTransferTestScript.performMultiRxInput(inputData);
        rxTransferTestScript.moveMultiRxToEod();
        rxTransferTestScript.verifyRxInEODForMultiRx();
    }


    @Test(enabled = true, description = "User is able to successfully transfer in and process multiple Rx with non-controlled drug,C3-C5 combined",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/PrmData/RxTransferTestData/RXTTransferTestData.json", sheetName = "RxTransfer")
    public void HWPHME2E_5139_MultiRx_XferIn_Happy_Path(Map<String, String>inputData) throws InterruptedException, IOException {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER1"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER2"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER3"));
        rxTransferTestScript.initializeTestCase(false);
        rxTransferTestScript.createPatientAPI(inputData);
        String[] drugNames ={inputData.get("NDC_NUMBER1"), inputData.get("NDC_NUMBER2") ,inputData.get("NDC_NUMBER3")};
        transferInFlowTestScripts.initiateTransferInRequestFromDropOff(inputData.get("PRIORITY"),inputData.get("COMPETITOR_PHARMACY_SEARCH"), drugNames);
        rxTransferTestScript.checkProblemMessages("Pending eTransfer In", "Pending eTransfer In","Pending eTransfer In",false, false);
        rxTransferTestScript.validateDBPendingTransFerInMultiRx();
        String xmlPayload = "src//test//resources//TestData//PrmData//RxTransfer//eTransferIn_payload.xml";
        rxTransferTestScript.performTransferIn(inputData, xmlPayload, 0, inputData.get("NDC_NUMBER1"), inputData.get("DRUG_NAME1"));
        rxTransferTestScript.checkProblemMessages("Pending eTransfer In", "Pending eTransfer In","Confirm eTransfer In", false, false);
        rxTransferTestScript.responseDBValidationTransferIn(0, 0,false);
        //rxImage validation required as per domain teams confirmation
        rxTransferTestScript.performTransferIn(inputData, xmlPayload, 1, inputData.get("NDC_NUMBER2"), inputData.get("DRUG_NAME2"));
        rxTransferTestScript.checkProblemMessages("Pending eTransfer In","Confirm eTransfer In", "Confirm eTransfer In",false, false);
        //checking blob not required as per domain team confiramtion
        rxTransferTestScript.responseDBValidationTransferIn(1, 1,false);
        rxTransferTestScript.performTransferIn(inputData, xmlPayload, 2, inputData.get("NDC_NUMBER3"), inputData.get("DRUG_NAME3"));
        rxTransferTestScript.checkProblemMessages("Confirm eTransfer In","Confirm eTransfer In", "Confirm eTransfer In",true, false);
        rxTransferTestScript.responseDBValidationTransferIn(2, 2,false);
        rxTransferTestScript.checkProblemMessages("Confirm eTransfer In", "Confirm eTransfer In","Confirm eTransfer In",true, true);
        rxTransferTestScript.validateDBPostConfirmTransFerInMultiRx();
        rxTransferTestScript.performMultiRxInput(inputData);
        rxTransferTestScript.moveMultiRxToEod();
        rxTransferTestScript.verifyRxInEODForMultiRx();

        Reporter.log("Executed successfully ,Validate the User is able to successfully transfer in and process multiple Rx with non-controlled drug,C3-C5 combined ");
    }

    /**
     * Load Rx from Competitor store to Walmart and the pharmacist accepts the Etransferrred RX
     * @param inputData
     * @throws SQLException
     */
    @Test(enabled = true, description = "When competitor request Rx to Walmart,pharmacist should able to accept the transfer request",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/RxTransferTestData/RXTTestData.json", sheetName = "TransferIn")
    public void HWPHME2E_5160_Rx_is_Processed_successfully_When_Competitor_Request_Rx_To_Walmart_Decimal_Prescribed_Quantity(Map<String, String> inputData) throws Exception {
        rxTransferTestScript.initializeTestCase(flagUpdated, false);
        ServiceResponse initiationResponse = transferINWrapper.sendUnsolicitedResponse(inputData, TransferInWrapper.ResponseType.unsolicited_decimal_qty_response).getResponse();
        Reporter.log("Initiation Status code : " + initiationResponse.getStatusCode());
        if (initiationResponse.getStatusCode() == 200) {
            rxTransferTestScript.loginConnexus();
            rxTransferTestScript.eTranferVericationQuery(inputData);
            rxTransferTestScript.validatePatientWorkQueueAndProblemCode(inputData);
            rxTransferTestScript.acceptETransferRequest(inputData);
            rxTransferTestScript.posteTransferQueryValidation(inputData);
            rxTransferTestScript.validateRxWorkqueue(inputData);

        } else {
            Reporter.log(" Failed to Transfer In Initiation Request ");
            Assert.fail();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * HWPHME2E_5459 Test Description : Validate Duplicate Fill Creation via DUR Check in chkDUR Component
   *
   * Pre-Conditions:
   * 1.User is logged into Connexions
   * Author: Mallikarjuna(vn58n9x)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate the report has multiple rows for the number of Medication dispensed section in RxTransfer or the fills dispensed is being displayed in the report",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/PrmData/RxTransferTestData/RXTTransferTestData.json", sheetName = "RxTransfer")
    public void HWPHME2E_5459_Validate_Report_Multiple_Rows_For_Number_of_Medication_Dispensed_Section(Map<String, String> inputData) throws InterruptedException {
        String transferApprovedXml = "prm.RxTransfer.TransferApprove.filePath";
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER1"));
        rxTransferTestScript.initializeTestCase(false);
        rxTransferTestScript.createPatientAPI(inputData);
        String[] drugNames = {inputData.get("NDC_NUMBER1")};
        transferInFlowTestScripts.initiateTransferInRequestFromDropOff(inputData.get("PRIORITY"), inputData.get("COMPETITOR_PHARMACY_SEARCH"), drugNames);
        rxTransferTestScript.checkProblemMessage("Pending eTransfer In", false, false);
        rxTransferTestScript.validateDBForETransferRequest(false);
        rxTransferTestScript.verifyAndSendTransferOutResponse(inputData, transferApprovedXml);
        rxTransferTestScript.checkProblemMessage("Confirm eTransfer In", true, true);
        rxTransferTestScript.validateWQAfterAcceptedConfirmETransferIn();
        rxTransferTestScript.validateRecentDbTable();
        rxTransferTestScript.validatePastMonthReport();

        Reporter.log("Executed successfully ,Validate the report has multiple rows for the number of Medication dispensed section in RxTransfer or the fills dispensed is being displayed in the report");
    }
    @Test(enabled = true, description = "Perform eTransferIn for multiRx with delegating prescriber",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/PrmData/RxTransferTestData/RXTTransferTestData.json", sheetName = "RxTransfer")
    public void HWPHME2E_5136_MultiRx_XferIn_Sent_As_Info_Only_By_Competitor(Map<String, String> inputData) throws InterruptedException, IOException {
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER1"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC_NUMBER2"));
        rxTransferTestScript.initializeTestCase(false);
        rxTransferTestScript.createPatientAPI(inputData);
        String[] drugNames = {inputData.get("NDC_NUMBER1"), inputData.get("NDC_NUMBER2")};
        transferInFlowTestScripts.initiateTransferInRequestFromDropOff(inputData.get("PRIORITY"), inputData.get("COMPETITOR_PHARMACY_SEARCH"), drugNames);
        rxTransferTestScript.checkProblemMessage("Pending eTransfer In", "Pending eTransfer In", false, false,false);
        rxTransferTestScript.validateDBPendingTransFerInMultiRx();
        String xmlPayload = "src//test//resources//TestData//PrmData//RxTransfer//transferIn_InfoOnly.xml";
        rxTransferTestScript.performTransferIn(inputData, xmlPayload, 0, inputData.get("NDC_NUMBER1"), inputData.get("DRUG_NAME"));
        rxTransferTestScript.checkProblemMessage("Pending eTransfer In", "Confirm eTransfer In", false, false,false);
        rxTransferTestScript.responseDBValidationTransferIn(0, 0,true);
        //rxImage validation required as per domain teams confirmation
        rxTransferTestScript.performTransferIn(inputData, xmlPayload, 1, inputData.get("NDC_NUMBER2"), inputData.get("DRUG_NAME"));
        rxTransferTestScript.checkProblemMessage("Confirm eTransfer In", "Confirm eTransfer In", true, false,false);
        //checking blob not required as per domain team confirmtion
        rxTransferTestScript.responseDBValidationTransferIn(1, 1,true);
        rxTransferTestScript.checkProblemMessage("Confirm eTransfer In", "Confirm eTransfer In", true, false,true);
        rxTransferTestScript.checkProblemMessage("eTransfer Info Only", "eTransfer Info Only", false, false,false);
    }
}