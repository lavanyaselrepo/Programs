package connexus.OrderIntake_rxTransfer.TestScripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.apache.commons.io.FileUtils;
import org.jline.utils.Log;
import org.junit.platform.commons.util.StringUtils;
import org.testng.Assert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.HashMap;


public class RXTransferTestScript extends ConnexusTestScripts {

    Map<String, String> rxIdAndResponseId = new HashMap<>();
    Map<String, String> responseMessage = new HashMap<>();
    Map<String, String> resMessageandStat = new HashMap<>();
    Map<String, String> rxIdAndRequestId = new HashMap<>();
    Map<String, String> orddtlPrblm = new HashMap<>();
    List<Integer> rxRequestIds = new ArrayList<>();
    List<Integer> reqIdList = new ArrayList<>();
    int rx_response_id;
    List<String> rxIds=new ArrayList<>();
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    java.util.List<Integer> multiRxNbr = new ArrayList<>();
    java.util.List<String> ndcList;


    public RXTransferTestScript(LoginAs.userType loginUserType) {
        super(loginUserType);

    }

    DBUtils dbUtils = new DBUtils();
    PropertyReader propertyReader = PropertyReader.getInstance();
    int rx_request_Id;
    String dbMessageId;

    public void createRxTransfer(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(inputData.get("lastName") + ',' + inputData.get("firstName"));
            String problemMessage = orderSearch.getProblemMessage(0);
            Reporter.log("searchedpatient :" + (inputData.get("lastName") + ',' + inputData.get("firstName")));
            Reporter.log("problemDescription: " + problemMessage);
            Reporter.logScreenShot(currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            if (problemMessage.equalsIgnoreCase(inputData.get("PROBLEMDESCRIPTION"))) {
                orderSearch.openRecordForETransfer(0);
                Reporter.log("Opened First patient");
            } else {
                Assert.fail("Problem description is not in Requested eTransfer Out");
            }

        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void rejectETransferRequest(Map<String, String> inputData) {
        try {
            eTransferRequestPage.clickRejectBtn(inputData);
            eTransferRequestPage.selectRejectionReason();
            eTransferRequestPage.clickAcceptBtn();
            eTransferRequestPage.getTextFromPopUp();
        } catch (AWTException e) {
            isExceptionCaptured = true;
            throw new RuntimeException(e);
        }
    }

    public void validateReasonCode(Map<String, String> inputData) {
        String reasonCodeFromDB = connexusAppUtils.getReasonCode(inputData.get("denialReason"));
        if (reasonCodeFromDB.equalsIgnoreCase(inputData.get("denialReasonCode"))) {
            Reporter.log("Reason Code " + reasonCodeFromDB + " and " + inputData.get("denialReasonCode") + " matched ");
            Assert.assertTrue(true);
        } else {
            Reporter.log("Reason Code " + reasonCodeFromDB + " and " + inputData.get("denialReasonCode") + " not matched ");
            Assert.fail();
        }
    }

    public void validateRxInETransferQueue(String expectedProblemMsg) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            //Added wait,since workQueue update is taking long time to reflect in order search result
            automationManager.performSleep(10);
            orderSearch.performSearch(name[0] + "," + name[1]);
            String problemMessage = orderSearch.getProblemName(0);
            if (problemMessage == null) {
                orderSearch.performSearch(name[0] + "," + name[1]);
                problemMessage = orderSearch.getProblemMessage(0);
            }
            Reporter.log("searched patient :" + name[0] + ',' + name[1]);
            Reporter.log("problemDescription: " + problemMessage);
            Reporter.logScreenShot(currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            if (problemMessage.equalsIgnoreCase(expectedProblemMsg)) {
                orderSearch.openRecordForETransfer(0);
                Reporter.log("Opened First patient");
            } else {
                Assert.fail("Problem description is not as expected. Expected: '" + expectedProblemMsg + "' but found: '" + problemMessage + "'");
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateTransferRequestScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            Assert.assertTrue(eTransferRequestPage.isElementDisplayed(eTransferRequestPage.acceptBtn),"Accept button not displayed");
            Assert.assertTrue(eTransferRequestPage.isElementDisplayed(eTransferRequestPage.rejectBtn),"Reject button not displayed");
            Assert.assertTrue(eTransferRequestPage.isElementDisplayed(eTransferRequestPage.eligibleRxCheckBox),"Eligible Checkbox not displayed");
            Reporter.log("Accept, Reject and Eligible Check boxes are displayed in Ex Transfer Request page.");
            Assert.assertEquals(eTransferRequestPage.getRxnumber(),rxNbr,"Rx number not matching");
            Assert.assertEquals(eTransferRequestPage.getDrugName(),inputData.get("drugDescription"),"Drug name not matching");
            Assert.assertEquals(eTransferRequestPage.getParticipatName(),name[0].toUpperCase()+", "+name[1].toUpperCase(),"Patient name not matching");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Transfer info page not displayed with proper details");
        }
    }

    public void validateElegibleRxCheckBoxFunctionality() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            eTransferRequestPage.click(eTransferRequestPage.eligibleRxCheckBox);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(eTransferRequestPage.getRxnumber(),rxNbr,"Rx number not matching");
            Reporter.log("Rx Eligible details displayed under patient prescription profile");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Rx number not matching");
        }
    }

    public void validatePatientWorkQueueAndProblemCode(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(inputData.get("LastName") + ',' + inputData.get("FirstName"));
            String workQueue = orderSearch.getWorkQueue(0);
            String problemMessage = orderSearch.getProblemMessage(0);
            Reporter.log("searchedpatient :" + (inputData.get("LastName") + ',' + inputData.get("FirstName")));
            Reporter.log("Work Queue:" + workQueue);
            Assert.assertEquals(workQueue,inputData.get("WORKQUEUE"),"WorkQueue doesnot match");
            Reporter.log("problemDescription: " + problemMessage);
            Reporter.logScreenShot(currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            if (problemMessage.equalsIgnoreCase(inputData.get("PROBLEMDESCRIPTION"))) {
                orderSearch.openRecordForETransfer(0);
                Reporter.log("Opened First patient");
            } else {
                Assert.fail("Problem description is not in Confirm eTransfer In");
            }

        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void acceptETransferRequest(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            eTransferRequestPage.selectAcceptCheckbox();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            eTransferRequestPage.clickAcceptBtn();
            Assert.assertEquals(eTransferRequestPage.getTextFromPopUp(),inputData.get("MessagePopup"),"PopUp Message not matching");

        } catch (Exception e) {
            isExceptionCaptured = true;
            Assert.fail("Etransfer Confirmation Page not displayed");
        }
    }

    public void validateRxWorkqueue(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(inputData.get("LastName") + ',' + inputData.get("FirstName"));
            String workQueue = orderSearch.getWorkQueue(0);
            Reporter.log("searchedpatient :" + (inputData.get("LastName") + ',' + inputData.get("FirstName")));
            Reporter.log("Work Queue:" + workQueue);
            Reporter.logScreenShot(currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail("WorkQueue is not in"+ inputData.get("Current_workqueue"));
        }
    }

    public void eTranferVericationQuery(Map<String, String> inputData) {
        try {
            rxIdAndResponseId = connexusAppUtils.getErxXferResponseByPatientName(inputData.get("LastName").toUpperCase(),inputData.get("FirstName").toUpperCase());
            Reporter.log("Rx ID:" +rxIdAndResponseId.get("rx_id"));
            Reporter.log("Response ID"+ rxIdAndResponseId.get("rx_response_id"));
            String codeType = connexusAppUtils.verifyRXTransfer(rxIdAndResponseId.get("rx_response_id"));
            Reporter.log("Actual Code type is:"+ codeType);
            Assert.assertEquals(codeType, inputData.get("ResponseCodeType"),"Rx Response Code doesn't match");
            responseMessage = connexusAppUtils.verifyLoggedRXTransfer(rxIdAndResponseId.get("rx_id"));
            Reporter.log("Received Message type:"+ responseMessage.get("erx_xfer_msg_type"));
            Assert.assertEquals(responseMessage.get("erx_xfer_msg_type"),inputData.get("RtransferMessage_type"),"Message Type Doesnot match");
            Reporter.log("Status code received from DB query is:"+ responseMessage.get("status_code"));
            Assert.assertEquals(responseMessage.get("status_code"),inputData.get("RtransferStatCode"),"Status code doesnot match");
            String responseQueue = connexusAppUtils.verifyRXOrderDetail(rxIdAndResponseId.get("rx_id"));
            Reporter.log("Received Workqueue code from DB query is:" + responseQueue);
            Assert.assertEquals(responseQueue,inputData.get("RtransferWorkqueue"),"Next Workqueue code doesnot Match");
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void posteTransferQueryValidation(Map<String, String> inputData) {
        try {
            rxIdAndRequestId = connexusAppUtils.getErxXferRequestByPatientName(inputData.get("LastName").toUpperCase(),inputData.get("FirstName").toUpperCase());
            Reporter.log("Rx ID:" +rxIdAndRequestId.get("rx_id"));
            Reporter.log("Response ID"+ rxIdAndRequestId.get("rx_request_id"));
            String responseCode = connexusAppUtils.verifyelthncRxrequest(rxIdAndRequestId.get("rx_request_id"));
            Reporter.log("Actual Code type is:" + responseCode);
            Assert.assertEquals(responseCode, inputData.get("RequestCodeType"), "Rx Request Code doesnot match");
            automationManager.performSleep(20);
            resMessageandStat = connexusAppUtils.verifyLoggedRXTransfer(rxIdAndRequestId.get("rx_id"));
            Reporter.log("Received Message type:"+ resMessageandStat.get("erx_xfer_msg_type"));
            Assert.assertEquals(resMessageandStat.get("erx_xfer_msg_type"),inputData.get("Message_Type"),"Message Type Doesnot match");
            Reporter.log("Status code received from DB query is:"+ resMessageandStat.get("status_code"));
            Assert.assertEquals(resMessageandStat.get("status_code"),inputData.get("Status_Code"),"Status code doesnot match");
            String rxOrderdetails = connexusAppUtils.verifyRXOrderDetails(rxIdAndRequestId.get("rx_id"));
            Reporter.log("Fetched Order_ID is:" + rxOrderdetails);
            orddtlPrblm = connexusAppUtils.verifyRXProblemCodeandStatus(rxOrderdetails);
            Reporter.log("Actual Problem Code type is:" + orddtlPrblm.get("phm_problem_code"));
            //   Assert.assertEquals(orddtlPrblm.get("phm_problem_code"), inputData.get("Phm_PrblmCode"), "Phm Problem Code doesnot match");
            //  Reporter.log("Actual Code type is:" + orddtlPrblm.get("problem_stat_code"));

        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }

    /**
     * Method to perform 4 point with OnHold checkbox clicked
     * Opens 4-Point screen, clicks OnHold, then completes normal 4-Point flow
     */
    public void perform4PointWithOnHold() {
        String currentStepMethodName = hwqe.baseframework.utilities.StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (rxNbr == null || rxNbr.isEmpty()) {
                rxNbr = getRxNbr(name[0], name[1], siteId);
                if (rxNbr == null || rxNbr.isEmpty()) {
                    Reporter.log("Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                    Assert.fail("Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                }
                Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
            }

            if(checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point " + rxNbr, "In progress", fileName, 40, io.strati.libs.joda.time.DateTime.now());
            } else {
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Reporter.log("RX is in Resolve Queue, Performing Resolve Queue");
                    performResolveQueue(rxNbr);
                }
            }

            if(checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                // Use the new WorkFlow method that handles OnHold
                automationManager.getConnexusWorkFlow().performFourPointWithOnHold(rxNbr);
                connexusAppUtils.writeTextToFile("4 point Completed with OnHold " + rxNbr, "In progress", fileName, 40, io.strati.libs.joda.time.DateTime.now());
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in 4 Point Queue to proceed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("4 point not Completed " + rxNbr, "Failed", fileName, 40, io.strati.libs.joda.time.DateTime.now());
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(com.aventstack.extentreports.Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyeTransferInRxLookUpScreen(Map<String, String> inputData) {
        String currentStepMethodName = hwqe.baseframework.utilities.StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            //opening rx lookup page and searching for the patient
            if (rxNbr == null || rxNbr.isEmpty()) {
                rxNbr = getRxNbr(name[0], name[1], siteId);
                if (rxNbr == null || rxNbr.isEmpty()) {
                    Reporter.log("Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                    Assert.fail("Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                }
                Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
            }
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(rxNbr);
            rxLookUp.clickSearch();
            softAssert.assertTrue(rxLookUp.getPatientNameFromRxLookUp().replaceAll(" ", "").equalsIgnoreCase(patientName));
            Reporter.log("Patient details displayed on clicking the patient search button from RX lookup Screen.");
            Reporter.log("Status on F7 Screen is " + rxLookUp.getText(rxLookUp.rxStatus));

        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to get Prescription History for Rx lookup screen " + e.getMessage());
            softAssert.fail();
        }
    }

    /**
     * Performs eTransfer Out request by checking eTransfer button enablement, clicking it,
     * selecting pharmacy, entering pharmacist details, and submitting the transfer request.
     *
     * @param inputData Map containing PHARMACIST_NAME
     */
    public void performETransferOutRequest(Map<String, String> inputData) {
        String currentStepMethodName = hwqe.baseframework.utilities.StackUtils.getCurrentMethodName();
        //check if eTransfer button is present and enabled
        Assert.assertTrue(rxLookUp.isElementDisplayed(rxLookUp.etransferBtn), "eTransfer button is NOT displayed in Rx Lookup screen");
        Reporter.log("eTransfer button is displayed in Rx Lookup screen");
        Assert.assertTrue(rxLookUp.isElementEnabled(rxLookUp.etransferBtn), "eTransfer button is NOT enabled in Rx Lookup screen");
        Reporter.log("eTransfer button is enabled in Rx Lookup screen");
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        //click eTransfer button
        rxLookUp.click(rxLookUp.etransferBtn);
        if (rxLookUp.isElementDisplayed(rxLookUp.pharmacyName)) {
            rxLookUp.clearText(rxLookUp.pharmacyName);
            rxLookUp.sendText(rxLookUp.pharmacyName, "FireFly LongTerm Care Pharmacy");
            rxLookUp.pressKeys(KeyEvent.VK_TAB);
            rxLookUp.click(rxLookUp.searchPharmacy);
        }
        rxLookUp.click(rxLookUp.searchPharmacy);
        rxLookUp.doubleClick(rxLookUp.pharmacyFirstRow);
        if (rxLookUp.isElementDisplayed(rxLookUp.pharmacist)) {
            rxLookUp.sendText(rxLookUp.pharmacist, inputData.get("PHARMACIST_NAME"));
            rxLookUp.pressKeys(KeyEvent.VK_TAB);
        }
        rxLookUp.click(rxLookUp.acceptTransfer);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        Assert.assertTrue(rxLookUp.isElementDisplayed(rxLookUp.connexusPopupMsg), "Failed to display Transfer Rx pop up");
        Assert.assertEquals(rxLookUp.getText(rxLookUp.connexusPopupMsg), "Your message has been sent successfully.");
        Reporter.log("Pop-up displayed with \"Your message has been sent successfully.\" message");
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        rxLookUp.click(rxLookUp.connexusOkButton);
        rxLookUp.click(rxLookUp.btnClose);
        rxLookUp.closeSearch();
        Reporter.log("eTransfer Out request Screen pop up closed");
    }

    public void verifyDetailsOnOrderSearchScreen(Map<String, String> inputData) {
        String currentStepMethodName = hwqe.baseframework.utilities.StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            //opening rx lookup page and searching for the patient
            if (rxNbr == null || rxNbr.isEmpty()) {
                rxNbr = getRxNbr(name[0], name[1], siteId);
                if (rxNbr == null || rxNbr.isEmpty()) {
                    Reporter.log("Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                    Assert.fail("Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                }
                Reporter.log("In " + currentStepMethodName + " Method, Rx number is " + rxNbr);
            }

            orderSearch.openSearch();
            orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);

            // Validate Work Queue, Status, and Problem
            String workQueue = orderSearch.getWorkQueue(0);
            String status = orderSearch.getText(io.appium.java_client.AppiumBy.name("Status Row 0"));
            String problem = orderSearch.getProblemMessage(0);

            Reporter.log("Work Queue: " + workQueue);
            Reporter.log("Status: " + status);
            Reporter.log("Problem: " + problem);

            Assert.assertEquals(workQueue, "Resolve", "Work Queue validation failed");
            Assert.assertEquals(status, "Waiting", "Status validation failed");
            Assert.assertEquals(problem, "Pending eTransfer Out", "Problem validation failed");

            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("All validations passed: Work Queue = Resolve, Status = Waiting, Problem = Pending eTransfer Out");

            orderSearch.closeSearch();

        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
        }
    }


    /**
     * Queries the DB for eTransfer request data and extracts the MessageID.
     * Returns the first valid MessageID found, which can be used as RelatesToMessageID
     * in sendTransferOutResponse.
     *
     * @return The extracted MessageID from the eTransfer request, or null if not found
     */
    public String eTransferVerificationQuery(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String extractedMessageId = null;
        try {
            // Wait for DB to sync after eTransfer request - ensures rx_request records are persisted before querying
            automationManager.performSleep(10);
            String lastname = name[0].toUpperCase();
            String firstname = name[1].toUpperCase();

            List<Integer> rxRequestIdlist = connexusAppUtils.getErxRxRequestIdsByPatientName(lastname, firstname);
            Reporter.log("Rx RequestID List :" + rxRequestIdlist);
            automationManager.performSleep(5);
            List<Map<String,Object>> rxRequestTexts=connexusAppUtils.getRxRequestTextByIds(rxRequestIdlist);
            for (Map<String,Object> row : rxRequestTexts){
                Integer rxRequestIds= (Integer) row.get("rx_request_id");
                Object  rxRequestTxt = row.get("rx_request_txt");
                String messageId = extractMessageIdFromBlob(rxRequestTxt);
                Reporter.log("Rx Request Id: " + rxRequestIds + ", MessageID: " + messageId);

                // Store the first valid MessageID found
                if (extractedMessageId == null && messageId != null
                        && !messageId.isEmpty()
                        && !"MessageId not found".equals(messageId)
                        && !messageId.startsWith("Error")) {
                    extractedMessageId = messageId;
                }
            }
        }catch (Exception e){
            Reporter.log("Execution is failed: " + e.getMessage());
        }

        Reporter.log("Extracted MessageID for RelatesToMessageID: " + extractedMessageId);
        return extractedMessageId;
    }

    /**
     * Verifies eTransfer request from DB, extracts MessageID, and sends the Transfer Out Response.
     * This method combines eTransferVerificationQuery and sendTransferOutResponse into a single flow.
     *
     * @param inputData Map containing patient address data (ADDRESS, CITY, STATE, COUNTRY, PRIMARY_NUMBER, ZIP_CODE)
     */
    public void verifyAndSendTransferOutResponse(Map<String, String> inputData, String xmlFilePropertyKey) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Get the MessageID from DB
            String messageId = eTransferVerificationQuery();

            if (StringUtils.isNotBlank(messageId)) {
                ServiceResponse transferOutResponse = sendTransferOutResponse(messageId, inputData, xmlFilePropertyKey);
                Assert.assertEquals(transferOutResponse.getStatusCode(), 200, "Transfer Out Response failed");
                Reporter.log("Transfer Out Response sent successfully using property key: " + xmlFilePropertyKey);
            } else {
                Reporter.log("No valid MessageID found, cannot send Transfer Out Response");
                Assert.fail("Failed to extract MessageID from eTransfer request");
            }

        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("verifyAndSendTransferOutResponse failed: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("verifyAndSendTransferOutResponse failed: " + e.getMessage());
        }
    }

    /**
     * Sends the Transfer Out Response (solicited response) to complete the eTransfer Out flow.
     * Dynamically replaces placeholders in the XML template.
     *
     * @param relatesToMessageId The MessageID extracted from the eTransfer request (from extractMessageIdWithRegex)
     * @param inputData Map containing patient address data (ADDRESS, CITY, STATE, COUNTRY, PRIMARY_NUMBER, ZIP_CODE)
     */
    public ServiceResponse sendTransferOutResponse(String relatesToMessageId, Map<String, String> inputData, String xmlFilePropertyKey) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            propertyReader.loadCustomProperties("config/prm/RXTransfer/");
            String xmlFilePath = propertyReader.getProperty(xmlFilePropertyKey);
            if (StringUtils.isBlank(xmlFilePath)) {
                Assert.fail("XML file path not configured for property: " + xmlFilePropertyKey);
            }
            File xmlData = new File(xmlFilePath);
            return sendTransferOutResponse(relatesToMessageId, inputData, xmlData);
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Failed to send Transfer Out Response (property key): " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("sendTransferOutResponse failed: " + e.getMessage());
            return null;
        }
    }
    public ServiceResponse sendTransferOutResponse(String relatesToMessageId, Map<String, String> inputData, File xmlData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (xmlData == null || !xmlData.exists()) {
                Assert.fail("Provided XML file not found: " + (xmlData == null ? "null" : xmlData.getAbsolutePath()));
            }

            String fileContext = FileUtils.readFileToString(xmlData, StandardCharsets.UTF_8);

            String formattedStoreNumber = String.format("%05d", siteId);
            String ncpdpid = "99" + formattedStoreNumber;
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String formattedDate = today.format(formatter);
            String currentTime = getCurrentTime();
            String randomMessageId = "RXTAUTO" + java.util.concurrent.ThreadLocalRandom.current().nextLong(1_000_000_000L, 10_000_000_000L);

            String[] name = connexusAppUtils.readPatientNameFromFile();
            String lastname = name[0].toUpperCase();
            String firstname = name[1].toUpperCase();

            fileContext = fileContext.replace("MESSAGEID", randomMessageId);
            fileContext = fileContext.replaceAll("SENTTIME", currentTime);
            fileContext = fileContext.replaceAll("WRITTENDATE", formattedDate);
            fileContext = fileContext.replaceAll("LASTFILL", formattedDate);
            fileContext = fileContext.replaceAll("RelatesToID", relatesToMessageId);
            fileContext = fileContext.replaceAll("LASTNAME", lastname);
            fileContext = fileContext.replaceAll("FIRSTNAME", firstname);
            fileContext = fileContext.replaceAll("GENDER", "M");
            fileContext = fileContext.replaceAll("DOB", "1999-10-10");
            fileContext = fileContext.replaceAll("ADDRESS", safeGet(inputData, "ADDRESS"));
            fileContext = fileContext.replaceAll("CITY", safeGet(inputData, "CITY"));
            fileContext = fileContext.replaceAll("STATE", safeGet(inputData, "STATE"));
            fileContext = fileContext.replaceAll("ZIPCODE", safeGet(inputData, "ZIP_CODE"));
            fileContext = fileContext.replaceAll("COUNTRY", safeGet(inputData, "COUNTRY"));
            fileContext = fileContext.replaceAll("PHONE", safeGet(inputData, "PRIMARY_NUMBER"));
            fileContext = fileContext.replaceAll("STORENUMBER", ncpdpid);
            fileContext = fileContext.replaceAll("NCPDID", ncpdpid);

            Reporter.log("Sending Transfer Out Response");
            Reporter.log("MessageID: " + randomMessageId);
            Reporter.log("RelatesToMessageID: " + relatesToMessageId);
            Reporter.log("NCPDPID: " + ncpdpid);
            Reporter.log("Patient: " + firstname + " " + lastname);
            Reporter.logXML("XML Request: \n", fileContext);

            ServiceRequest req = new ServiceRequest();
            req.setRequestPayload(fileContext);
            req.setHeaders(buildTransferOutResponseHeaders());
            req.setUrl(propertyReader.getProperty("prm.RxTransferInboundProcessor.URL"));

            ServiceResponse resp = automationManager.getRestContext().performPost(req);
            Reporter.log(String.valueOf(resp));
            Assert.assertEquals(resp.getStatusCode(), 200, "POST request returned error");
            Reporter.log("TRANSFERIN successful");

            Reporter.log("Response Status Code: " + resp.getStatusCode());
            Reporter.logXML("XML Response: \n", resp.getDataResponse());

            return resp;

        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Failed to send Transfer Out Response: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("sendTransferOutResponse failed: " + e.getMessage());
            return null;
        }
    }

    // helper to safely read values from map
    private String safeGet(Map<String, String> map, String key) {
        if (map == null) {
            return "";
        }
        String v = map.get(key);
        return v == null ? "" : v;
    }

    /**
     * Gets the current time in ISO format for XML SentTime field.
     */
    @Override
    public String getCurrentTime() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
        return now.format(formatter);
    }


    /**
     * Builds headers for the Transfer Out Response request
     */
    private HashMap<String, String> buildTransferOutResponseHeaders() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("accept", propertyReader.getProperty("prm.RxTransfer.content_type.xml"));
        headers.put("Content-Type", propertyReader.getProperty("prm.RxTransfer.content_type.xml"));
        headers.put("WM_CONSUMER.ID", propertyReader.getProperty("prm.RxTransferInboundProcessor.ConsumerId"));
        return headers;
    }

    private String extractMessageIdFromBlob(Object blobObject){
        try {
            String blobContent=convertBlobToString(blobObject);
            if (blobContent == null || blobContent.isEmpty()){
                return "MessageId not found";

            }
            if (blobContent.contains("MessageID") || blobContent.contains("messageId") || blobContent.contains("MessageId")){
                return extractMessageIdWithRegex(blobContent);
            }
        }catch (Exception e){
            Reporter.log("error extracting MessageId: " + e.getMessage());
            return "Error extracting MessageId";
        }

        return "";
    }

    private String convertBlobToString(Object blobObject){
        try {
            if (blobObject == null){
                return null;
            }
            if (blobObject instanceof String){
                return (String) blobObject;
            }
            if (blobObject instanceof byte[]){
                byte[] bytes=  (byte[]) blobObject;
                return new String(bytes, StandardCharsets.UTF_8);

            }
            if (blobObject instanceof java.sql.Blob){
                java.sql.Blob blob=(java.sql.Blob) blobObject;
                byte[] bytes=blob.getBytes(1,(int) blob.length());
                return new String(bytes, StandardCharsets.UTF_8);
            }
            return blobObject.toString();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private String extractMessageIdWithRegex(String blobContent) {
        // Case-insensitive search for MessageId or messageId, capturing the value in quotes or after = or :
        Pattern pattern = Pattern.compile("(?i)MessageId\\s*[:=]\\s*\"([^\"]+)\"|MessageId\\s*>\\s*([^<]+)<", Pattern.DOTALL);
        Matcher matcher = pattern.matcher(blobContent);
        if (matcher.find()) {
            // Prefer quoted value if present; otherwise fall back to XML-tag style group
            String value = matcher.group(1);
            if (value == null || value.trim().isEmpty()) {
                value = matcher.group(2);
            }
            if (value != null) {
                return value.trim();
            }
        }
        return "MessageId not found";
    }

    public void validateDBForETransferRequest() {
        // keep existing behavior by default
        validateDBForETransferRequest(true);
    }

    public void validateDBForETransferRequest(boolean includeRxOrderValidations) {
        String currentStepMethodName = hwqe.baseframework.utilities.StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String lastname = name[0].toUpperCase();
            String firstname = name[1].toUpperCase();

            // Get rx_request_ids using patient name
            List<Integer> rxRequestIds = connexusAppUtils.getErxRxRequestIdsByPatientName(lastname, firstname);
            if (rxRequestIds == null || rxRequestIds.isEmpty()) {
                Reporter.log("No rx_request_id found for patient: " + firstname + " " + lastname);
                Assert.fail("No rx_request_id found for patient: " + firstname + " " + lastname);
            }

            Reporter.log("Found rx_request_ids: " + rxRequestIds);

            // Validate for each rx_request_id (or just the first one)
            rx_request_Id = rxRequestIds.get(0);
            Reporter.log("Validating DB for rx_request_id: " + rx_request_Id);

            dbMessageId = validateEtncRxRequest(rx_request_Id);

            // Get MessageID from XML blob (reuse eTransferVerificationQuery)
            String extractedMessageId = eTransferVerificationQuery();

            // Compare the two MessageIDs
            validateXmlMessageId(extractedMessageId, dbMessageId);

            // Only run these when requested
            if (includeRxOrderValidations) {
                validateEtrxXferRequest(rx_request_Id);
                validateRxOrderDetail();
            }

        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }
    private String validateEtncRxRequest(int rxId) {
        Reporter.log("Validating etnc_rx_request table for rx_id=" + rxId);

        Map<String, Object> result = dbUtils.getEtncRxRequest(siteId, rxId);

        Assert.assertNotNull(result, "No record found in etrx_rx_request for rx_id=" + rxId);
        Object requestStatusCode = result.get("request_stat_code");
        Object requestMessageId = result.get("request_message_id");

        Reporter.log("etrx_rx_request.request_stat_code = " + requestStatusCode);
        Reporter.log("etrx_rx_request.request_message_id = " + requestMessageId);

        Assert.assertEquals(String.valueOf(requestStatusCode), "26005", "request_stat_code is not 26005");
        Assert.assertTrue(requestMessageId != null && !requestMessageId.toString().trim().isEmpty(),
                "request_message_id was not generated in etrx_rx_request");

        return requestMessageId.toString().trim();
    }

    /**
     * Validates that the MessageID extracted from XML blob matches the request_message_id from DB.
     * @param extractedMessageId MessageID extracted from XML blob (from eTransferVerificationQuery)
     * @param dbMessageId request_message_id from DB (from validateEtncRxRequest)
     */
    private void validateXmlMessageId(String extractedMessageId, String dbMessageId) {
        Reporter.log("Validating XML MessageID against DB request_message_id");
        Reporter.log("MessageID from XML blob: " + extractedMessageId);
        Reporter.log("request_message_id from DB: " + dbMessageId);

        Assert.assertTrue(extractedMessageId != null
                        && !"MessageId not found".equals(extractedMessageId)
                        && !extractedMessageId.startsWith("Error"),
                "Failed to extract valid MessageID from XML blob");

        Assert.assertEquals(extractedMessageId, dbMessageId,
                "MessageID from XML does not match request_message_id in DB");
        Reporter.log("XML validation PASSED: MessageID from XML matches request_message_id");
    }

    private void validateEtrxXferRequest(int rxId) {
        Reporter.log("Validating etrx_xfer_request table for rx_id=" + rxId);
        Map<String, Object> result = dbUtils.getEtrxXferRequest(siteId, rxId);

        Assert.assertNotNull(result, "No record found in etrx_xfer_request for rx_id=" + rxId);

        Object seqNbr = result.get("xfer_request_seq_nbr");
        Object msgType = result.get("erx_xfer_msg_type");
        Object statusCode = result.get("status_code");

        Reporter.log("etrx_xfer_request.xfer_request_seq_nbr = " + seqNbr);
        Reporter.log("etrx_xfer_request.req_xfer_msg_type = " + msgType);
        Reporter.log("etrx_xfer_request.status_code = " + statusCode);

        if ("2".equals(String.valueOf(seqNbr))) {
            Assert.assertEquals(String.valueOf(msgType), "11103", "erx_xfer_msg_type is not 11103 for xfer_request_seq_nbr=2");
            Assert.assertEquals(String.valueOf(statusCode), "20302", "status_code is not 20302 for xfer_request_seq_nbr=2");
        } else {
            Assert.assertEquals(String.valueOf(seqNbr), "1", "xfer_request_seq_nbr is not 1");
            Assert.assertEquals(String.valueOf(msgType), "11102", "req_xfer_msg_type is not 11102");
            Assert.assertEquals(String.valueOf(statusCode), "20304", "status_code is not 20304");
        }
    }

    private void validateRxOrderDetail() {
        Reporter.log("Validating rx_order_detail table for rxNbr=" + rxNbr);
        Map<String, Object> result = dbUtils.getRxOrderDetailForRxNbr(siteId, rxNbr);

        Assert.assertNotNull(result, "No record found in rx_order_detail for rxNbr=" + rxNbr);

        Object nextWorkQueueCode = result.get("next_work_que_code");
        Object requestTypeCode = result.get("request_type_code");

        Reporter.log("rx_order_detail.next_work_que_code = " + nextWorkQueueCode);
        Reporter.log("rx_order_detail.request_type_code = " + requestTypeCode);

        softAssert.assertEquals(String.valueOf(nextWorkQueueCode), "7", "next_work_que_code is not 7");
        softAssert.assertEquals(String.valueOf(requestTypeCode), "1613", "request_type_code is not 1613");
    }

    /**
     * Validates raw_eltnc_rx_resp table using the response MessageID.
     * Checks that rx_response_id is generated and response_stat_code = 26005.
     *
     * @param messageId The MessageID from the Transfer Out Response
     */
    private void validateRawEltncRxResp(String messageId) {
        Reporter.log("Validating raw_eltnc_rx_resp table for resp_message_id=" + messageId);

        Map<String, Object> result = dbUtils.getRawElectronicTransactionDetails(siteId, messageId);

        Assert.assertNotNull(result, "No record found in raw_eltnc_rx_resp for resp_message_id=" + messageId);

        Object rxResponseId = result.get("rx_response_id");
        Object responseStatCode = result.get("response_stat_code");

        Reporter.log("raw_eltnc_rx_resp.rx_response_id = " + rxResponseId);
        Reporter.log("raw_eltnc_rx_resp.response_stat_code = " + responseStatCode);

        Assert.assertTrue(rxResponseId != null && !rxResponseId.toString().trim().isEmpty(),
                "rx_response_id was not generated in raw_eltnc_rx_resp");
        Reporter.log("rx_response_id is generated: " + rxResponseId);

        Assert.assertEquals(String.valueOf(responseStatCode), "26005",
                "response_stat_code is not 26005 in raw_eltnc_rx_resp");
        Reporter.log("response_stat_code validation PASSED: " + responseStatCode);
    }

    public void rejectAndAcceptConfirmETransferIn() {
        try {
            eTransferRequestPage.selectRejectReasonAndConfirm(0);
            eTransferRequestPage.acceptTransfer(0, true);
            eTransferRequestPage.clickOk();
        } catch (Exception e) {
            isExceptionCaptured = true;
            throw new RuntimeException(e);
        }
    }

    public void validateWQAfterAcceptedConfirmETransferIn() {
        String currentStepMethodName = hwqe.baseframework.utilities.StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            //Added wait,since workQueue update is taking long time to reflect in order search result
            automationManager.performSleep(10);
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue())) {
                Reporter.log("RX is in :" + rxStatus);

            } else {
                Reporter.log("RX is not in Input queue");
                Assert.fail();
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            throw new RuntimeException(e);
        }
    }

    public void checkProblemMessage(String expectedPrblm1, String expectedPrblm2, boolean checkConfirmXfer, boolean acceptXfer,boolean sendAllToResolution) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + ',' + name[1]);
            automationManager.performSleep(5);
            orderSearch.clickSearch();
            String problemMessageRow0 = orderSearch.getProblemMessage(0);
            String problemMessageRow1 = orderSearch.getProblemMessage(1);
            if (problemMessageRow0.equalsIgnoreCase(expectedPrblm1) && problemMessageRow1.equalsIgnoreCase(expectedPrblm2)) {
                if (checkConfirmXfer) {
                    orderSearch.openRecordForETransfer(0);
                    if (acceptXfer) {
                        eTransferRequestPage.clickAcceptInConfirmTransferIn(0);
                        eTransferRequestPage.clickAcceptInConfirmTransferIn(1);
                        Reporter.logScreenShot("Confirm transferIn Screen", orderSearch.takeScreenShot(currentStepMethodName).getValue());
                        Reporter.log("transferIn confirmed");
                        eTransferRequestPage.clickAcceptBtn();
                        eTransferRequestPage.eTransferConfirmPopup();
                    }
                    if (sendAllToResolution) {
                        eTransferRequestPage.clickSendToResolutionBtn();
                        Reporter.log("Sent all rx to resolution");
                    }
                    else {
                        Reporter.logScreenShot("ConfirmEtransferScreen", orderSearch.takeScreenShot(currentStepMethodName).getValue());
                        Reporter.log("Two drugs are present in confirm eTransfer screen");
                        orderSearch.clickCancel();
                    }
                }
                else {
                    Reporter.logScreenShot(currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                    Reporter.log("Order Is pending for eTransferIn");
                    orderSearch.closeSearch();
                }
            } else {
                Assert.fail("Rx not pending for etransferIn");
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }
    public void checkProblemMessages(String expectedPrblm1, String expectedPrblm2, String expectedPrblm3, boolean checkConfirmXfer, boolean acceptXfer) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + ',' + name[1]);
            automationManager.performSleep(10);
            orderSearch.clickSearch();
            String problemMessageRow0 = orderSearch.getProblemMessage(0);
            String problemMessageRow1 = orderSearch.getProblemMessage(1);
            String problemMessageRow2 = orderSearch.getProblemMessage(2);
            if (problemMessageRow0.equalsIgnoreCase(expectedPrblm1) && problemMessageRow1.equalsIgnoreCase(expectedPrblm2) && problemMessageRow2.equalsIgnoreCase(expectedPrblm3)){
                if(checkConfirmXfer){
                    orderSearch.openRecordForETransfer(0);
                    if(acceptXfer){
                        eTransferRequestPage.clickAcceptInConfirmTransferIn(0);
                        eTransferRequestPage.clickAcceptInConfirmTransferIn(1);
                        eTransferRequestPage.scrollDown();
                        eTransferRequestPage.clickAcceptInConfirmTransferIn(2);
                        Reporter.logScreenShot("Confirm transferIn Screen", orderSearch.takeScreenShot(currentStepMethodName).getValue());
                        Reporter.log("transferIn confirmed");
                        eTransferRequestPage.clickAcceptBtn();
                        eTransferRequestPage.eTransferConfirmPopup();
                    }else {
                        Reporter.logScreenShot("ConfirmEtransferScreen", orderSearch.takeScreenShot(currentStepMethodName).getValue());
                        Reporter.log("Three drugs are present in confirm eTransfer screen");
                        orderSearch.clickCancel();
                    }
                }else {
                    Reporter.logScreenShot(currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                    Reporter.log("Order Is pending for eTransferIn");
                    orderSearch.closeSearch();
                }
            } else {
                Assert.fail("Rx not pending for etransferIn");
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateDBPendingTransFerInMultiRx() {
        String currentStepMethodName = hwqe.baseframework.utilities.StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String lastname = name[0].toUpperCase();
            String firstname = name[1].toUpperCase();
            List<Integer> rxOrder_Id = new ArrayList<>();

            // Get rx_request_ids using patient name
            rxRequestIds = connexusAppUtils.getErxRxRequestIdsByPatientName(lastname, firstname);
            if (StringUtils.isBlank(rxRequestIds.toString())) {
                Reporter.log("No rx_request_id found for patient: " + firstname + " " + lastname);
                Assert.fail("No rx_request_id found for patient: " + firstname + " " + lastname);
            }

            Reporter.log("Found rx_request_ids: " + rxRequestIds);

            for (int i = 0; i < rxRequestIds.size(); i++) {
                rx_request_Id = Integer.parseInt(String.valueOf(rxRequestIds.get(i)));
                Reporter.log("Validating DB for rx_request_id: " + rx_request_Id);

                //Valdiate erx_xfer_table
                Map<String, Object> result = dbUtils.getEtrxXferRequest(siteId, rx_request_Id);
                Assert.assertNotNull(result, "No record found in etrx_xfer_request for rx_request_Id=" + rx_request_Id);
                Object msgType = result.get("erx_xfer_msg_type");
                Object statusCode = result.get("status_code");
                Object rxId = result.get("rx_id");
                String rxIdStr = rxId.toString();
                rxIds.add(rxIdStr);

                Assert.assertEquals(String.valueOf(msgType), "11101", "erx_xfer_msg_type is not 11101");
                Reporter.log("etrx_xfer_request.req_xfer_msg_type = " + msgType);
                Assert.assertEquals(String.valueOf(statusCode), "20304", "status_code is not 20304");
                Reporter.log("etrx_xfer_request.status_code = " + statusCode);


                //orderDetailsTable
                Map<String, Object> orderDetails = dbUtils.getRxOrderDetailForRxId(siteId, Integer.parseInt(rxIdStr));
                Assert.assertNotNull(orderDetails, "No record found in rx_order_detail for rxId=" + rxId);
                Object nextWorkQueueCode = orderDetails.get("next_work_que_code");
                Object requestTypeCode = orderDetails.get("request_type_code");
                Object orderId = orderDetails.get("order_id");
                Object orderStatusCode = orderDetails.get("status_code");
                rxOrder_Id.add((Integer) orderId);

                softAssert.assertEquals(String.valueOf(nextWorkQueueCode), "7", "next_work_que_code is not 7");
                Reporter.log("rx_order_detail.next_work_que_code = " + nextWorkQueueCode);
                softAssert.assertEquals(String.valueOf(requestTypeCode), "1612", "request_type_code is not 1612");
                Reporter.log("rx_order_detail.request_type_code = " + requestTypeCode);
                softAssert.assertEquals(String.valueOf(orderStatusCode), "20501", "request_type_code is not 20501");
                Reporter.log("rx_order_detail.status_code= " + orderStatusCode);
                Reporter.log("Order Id: " + orderId);
            }

            //rx_order_dtl_problem
            List<Integer> problemCodes = connexusAppUtils.getRxOrderProblemCode(String.valueOf(rxOrder_Id.get(0)));
            Object problemCodeFirstRx = problemCodes.get(1);
            Object problemCodeSecondRx = problemCodes.get(3);
            Assert.assertEquals(String.valueOf(problemCodeFirstRx), "29280", "rxNot In eTransferIn pending");
            Assert.assertEquals(String.valueOf(problemCodeSecondRx), "29280", "rxNot In eTransferIn pending");

            List<String> problemComments = connexusAppUtils.getProblemComment(String.valueOf(rxOrder_Id.get(0)));
            Object problemCommentFirstRx = problemComments.get(1);
            Object problemCommentSecondRx = problemComments.get(3);
            Assert.assertTrue(((String) problemCommentFirstRx).contains("Pending eTransfer In"), "rxNot In eTransferIn pending");
            Assert.assertTrue(((String) problemCommentSecondRx).contains("Pending eTransfer In"), "rxNot In eTransferIn pending");

            if ("29280".equals(String.valueOf(problemCodeFirstRx)) && "29280".equals(String.valueOf(problemCodeSecondRx))) {
                Reporter.log("First Rx - Problem Code: " + problemCodeFirstRx + " and problem comment: " + problemCommentFirstRx);
                Reporter.log("Second Rx - Problem Code: " + problemCodeSecondRx + " and problem comment: " + problemCommentSecondRx);
            } else {
                Assert.fail("First Rx not pending for eTransferIn");
                Reporter.log("Problem Code: " + problemCodeFirstRx + " and problem comment: " + problemCommentFirstRx);
                Reporter.log("Problem Code: " + problemCodeSecondRx + " and problem comment: " + problemCommentSecondRx);
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }


    public void responseDBValidationTransferIn(int index, int Rx,boolean isInfoOnly) {
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String lastname = name[0].toUpperCase();
            String firstname = name[1].toUpperCase();

            // Get rx_request_ids using patient name
            List<Integer> rxResponseIds = connexusAppUtils.getResponseIdByName(lastname, firstname);
            if (StringUtils.isBlank(rxResponseIds.toString())) {
                Reporter.log("No rx_response_id found for patient: " + firstname + " " + lastname);
                Assert.fail("No rx_response_id found for patient: " + firstname + " " + lastname);
            }
            Reporter.log("Found rx_response_id: " + rxResponseIds);

            // Validate for each rx_request_id (or just the first one)
            rx_response_id = rxResponseIds.get(index);
            Reporter.log("Validating DB for rx_request_id: " + rx_response_id);

            //raw_eltn_rx_resp
            Map<String, Object> etlnRxResp = connexusAppUtils.getRawEtlnRxResp(siteId, rx_response_id);
            Assert.assertNotNull(etlnRxResp, "No record found in raw_eltnc_rx_resp for rx_response_id=" + rx_request_Id);
            Object respTypeCode = etlnRxResp.get("rx_resp_type_code");
            Object rspstatCode = etlnRxResp.get("response_stat_code");

            Assert.assertEquals(String.valueOf(respTypeCode), "26324", "rx_resp_type_code is not 26324");
            Reporter.log("raw_eltnc_rx_resp.req_xfer_msg_type = " + respTypeCode);
            Assert.assertEquals(String.valueOf(rspstatCode), "26005", "response_stat_code is not 26005");
            Reporter.log("raw_eltnc_rx_resp.status_code = " + rspstatCode);

            //erx_xfer_request
            String rx_Id = rxIds.get(Rx);
            List<Integer> msgTypes = connexusAppUtils.getErxXferReqMsgType(rx_Id);
            List<Integer> statusCodes = connexusAppUtils.getErxXferReqMStatusMsg(rx_Id);

            Assert.assertNotNull(msgTypes.get(0), "No record found in raw_eltnc_rx_resp for rx_response_id=" + rx_request_Id);
            Object msgTypeInitial = msgTypes.get(0);
            Assert.assertEquals(String.valueOf(msgTypeInitial), "11101", "Initial request not completed");
            Assert.assertNotNull(statusCodes.get(0), "No record found in raw_eltnc_rx_resp for rx_response_id=" + rx_request_Id);
            Object initialStatsCode = statusCodes.get(0);
            Assert.assertEquals(String.valueOf(initialStatsCode), "20302", "Request not completed");
            Reporter.log("Initial request msg type: " + msgTypeInitial + "and status_code =" + initialStatsCode + "- request Completed");
            if (isInfoOnly) {
                Object msgTypeRecent = msgTypes.get(1);
                Assert.assertEquals(String.valueOf(msgTypeRecent), "11106", "Latest request not pending pending");
                Object recentStatsCode = statusCodes.get(1);
                Assert.assertEquals(String.valueOf(recentStatsCode), "20302", "Latest request not pending pending");
                Reporter.log("Recent request msg type: " + msgTypeRecent + "and status_code =" + recentStatsCode + "- request Completed");

            } else {
                Object msgTypeRecent = msgTypes.get(1);
                Assert.assertEquals(String.valueOf(msgTypeRecent), "11102", "Latest request not pending pending");
                Object recentStatsCode = statusCodes.get(1);
                Assert.assertEquals(String.valueOf(recentStatsCode), "20304", "Latest request not pending pending");
                Reporter.log("Recent request msg type: " + msgTypeRecent + "and status_code =" + recentStatsCode + "- request pending");
            }
            //rx_Order_Details
            Map<String, Object> orderDetails = dbUtils.getRxOrderDetailForRxId(siteId, Integer.parseInt(String.valueOf(rx_Id)));
            Assert.assertNotNull(orderDetails, "No record found in rx_order_detail for rxId=" + rx_Id);
            Object nextWorkQueueCode = orderDetails.get("next_work_que_code");
            Object orderId = orderDetails.get("order_id");

            softAssert.assertEquals(String.valueOf(nextWorkQueueCode), "35", "next_work_que_code is not 35");
            Reporter.log("rx_order_detail.next_work_que_code = " + nextWorkQueueCode);

            //rx_order_dtl_problem
            List<Integer> problemCodes = connexusAppUtils.getRxOrderStatCode(String.valueOf(orderId));
            Object detailsPrblmStat = problemCodes.get(0);
            Assert.assertEquals(String.valueOf(detailsPrblmStat), "6301", "rxN In eTransferIn pending");
            Reporter.log("Problem Code: " + detailsPrblmStat + " - pending eTransferIn ");
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }


    public void validateDBPostConfirmTransFerInMultiRx() {
        try {
            //adding sleep for DB update
            automationManager.performSleep(10);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String lastname = name[0].toUpperCase();
            String firstname = name[1].toUpperCase();

            // Get rx_request_ids using patient name
            rxRequestIds = connexusAppUtils.getErxRxRequestIdsByPatientName(lastname, firstname);
            if (StringUtils.isBlank(rxRequestIds.toString())) {
                Reporter.log("No rx_request_id found for patient: " + firstname + " " + lastname);
                Assert.fail("No rx_request_id found for patient: " + firstname + " " + lastname);
            }

            Reporter.log("Found rx_request_ids: " + rxRequestIds);

            // Dynamic handling for 2 or 3 NDCs
            if (rxRequestIds.size() == 4) {
                // Handle 2 NDCs case
                int reqId1 = rxRequestIds.get(2);
                int reqId2 = rxRequestIds.get(3);
                reqIdList.add(reqId1);
                reqIdList.add(reqId2);
            }
            // Handle 3 NDCs case
            else if (rxRequestIds.size() == 6) {
                int reqId1 = rxRequestIds.get(3);
                int reqId2 = rxRequestIds.get(4);
                int reqId3 = rxRequestIds.get(5);
                reqIdList.add(reqId1);
                reqIdList.add(reqId2);
                reqIdList.add(reqId3);
            }
            else {
                Reporter.log("Unexpected rx_request_ids size: " + rxRequestIds.size() + ". Expected 4 or 6.");
                // try to get the last available indices
                if (rxRequestIds.size() >= 4) {
                    reqIdList.add(rxRequestIds.get(rxRequestIds.size() - 2));
                    reqIdList.add(rxRequestIds.get(rxRequestIds.size() - 1));
                } else {
                    Assert.fail("Insufficient rx_request_ids found. Expected at least 4, found " + rxRequestIds.size());
                }
            }
            for (int i = 0; i < reqIdList.size(); i++) {
                rx_request_Id = Integer.parseInt(String.valueOf(reqIdList.get(i)));

                Reporter.log("Validating DB for rx_request_id: " + rx_request_Id);

                //eltnc_rx_req
                Map<String, Object> eltncTypeCode = dbUtils.getEtncRxRequest(siteId, rx_request_Id);
                Assert.assertNotNull(eltncTypeCode, "No record found in eltnc_rx_request for rx_request_Id=" + rx_request_Id);
                Object typeCode = eltncTypeCode.get("rx_rqst_type_code");

                Assert.assertEquals(String.valueOf(typeCode), "8152", "rx_rqst_type_code is not 8152");
                Reporter.log("eltnc_rx_request.rx_rqst_type_code = " + typeCode);


                //Valdiate erx_xfer_table
                Map<String, Object> result = dbUtils.getEtrxXferRequest(siteId, rx_request_Id);
                Assert.assertNotNull(result, "No record found in etrx_xfer_request for rx_request_Id=" + rx_request_Id);
                Object msgType = result.get("erx_xfer_msg_type");
                Object statusCode = result.get("status_code");
                Object rxId = result.get("rx_id");
                String rxIdStr = rxId.toString();
                rxIds.add(rxIdStr);

                Assert.assertEquals(String.valueOf(msgType), "11103", "erx_xfer_msg_type is not 11103");
                Reporter.log("etrx_xfer_request.req_xfer_msg_type = " + msgType);
                Assert.assertEquals(String.valueOf(statusCode), "20302", "status_code is not 20302");
                Reporter.log("etrx_xfer_request.status_code = " + statusCode);


                //getOrder_Id
                Map<String, Object> orderDetails = dbUtils.getRxOrderDetailForRxId(siteId, Integer.parseInt(rxIdStr));
                Assert.assertNotNull(orderDetails, "No record found in rx_order_detail for rxId=" + rxId);
                Object orderId = orderDetails.get("order_id");

                //rx_order_details
                List<Integer> orderDetailStatCode = connexusAppUtils.orderDetailsStatMutliRx(String.valueOf(orderId));

                Assert.assertNotNull(orderDetailStatCode.get(0), "No record found in raw_eltnc_rx_resp for rx_response_id=" + rx_request_Id);
                Object StatCodeOld = orderDetailStatCode.get(0);
                Assert.assertEquals(String.valueOf(StatCodeOld), "20502", "Initial request not completed");

                // Dynamic index based on rx_request_ids size
                int recentStatCodeIndex = (rxRequestIds.size() == 4) ? 2 : 3;
                Assert.assertNotNull(orderDetailStatCode.get(recentStatCodeIndex), "No record found in raw_eltnc_rx_resp for rx_response_id=" + rx_request_Id);
                Object StatCodeRecent = orderDetailStatCode.get(recentStatCodeIndex);
                Assert.assertEquals(String.valueOf(StatCodeRecent), "20501", "Request not completed");
                Reporter.log("status_code of initial order = " + StatCodeOld + " - Cancel");
                Reporter.log("status_code new order = " + StatCodeRecent + " - Active");

                //rx_order_dtl_problem
                List<Integer> problemCodes = connexusAppUtils.getRxOrderProblemCode(String.valueOf(orderId));
                Object problemCode = problemCodes.get(1);
                Assert.assertEquals(String.valueOf(problemCode), "29280", "eTransferIn pending");
                Reporter.log("Problem Code: " + problemCode + " - pending eTransferIn ");

                List<Integer> StatCode = connexusAppUtils.getRxOrderStatCode(String.valueOf(orderId));
                Object detailsPrblmStat = StatCode.get(1);
                Assert.assertEquals(String.valueOf(detailsPrblmStat), "6301", "rxN In eTransferIn pending");
                Reporter.log("Problem Code: " + detailsPrblmStat + " - pending eTransferIn ");


            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performTransferIn(Map<String, String> inputData, String xmlPath, int Rx, String NDC, String DrugName) {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        File xmlData;
        try {
            String inputPayload;
            String Ndc = NDC;
            String drugName = DrugName;
            String lastname = name[0].toUpperCase();
            String firstname = name[1].toUpperCase();
            xmlData = new File(xmlPath);
            int requestId = rxRequestIds.get(Rx);

            inputPayload = updateXML(xmlData, inputData, firstname, lastname, requestId, Ndc, drugName);
            Log.info("inputPayload: " + inputPayload);
            dropXml(inputPayload);
        } catch (Exception e) {
            Assert.fail();
            e.printStackTrace();
        }
    }


    public String updateXML(File xmlData, Map<String, String> inputData, String firstname, String lastname, int requestId, String Ndc, String drugName) throws IOException {
        String fileContext = FileUtils.readFileToString(xmlData);
        String formattedStoreNumber = String.format("%05d", siteId);
        String relatesToMessageId = formattedStoreNumber + requestId;
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedDate = today.format(formatter);
        String currentTime = getCurrentTime();
        String randomMessageId = "RXTAUTO" + java.util.concurrent.ThreadLocalRandom.current().nextLong(1_000_000_000L, 10_000_000_000L);
        String ncpdpid = "99" + formattedStoreNumber;

        fileContext = fileContext.replace("MESSAGEID", randomMessageId);
        fileContext = fileContext.replaceAll("SENTTIME", currentTime);
        fileContext = fileContext.replaceAll("WRITTENDATE", formattedDate);
        fileContext = fileContext.replaceAll("LASTFILL", formattedDate);
        fileContext = fileContext.replaceAll("RelatesToID", relatesToMessageId);
        fileContext = fileContext.replaceAll("LASTNAME", lastname);
        fileContext = fileContext.replaceAll("FIRSTNAME", firstname);
        fileContext = fileContext.replaceAll("DrugName", drugName);
        fileContext = fileContext.replaceAll("NdcNumber", Ndc);
        fileContext = fileContext.replaceAll("STORENUMBER", ncpdpid);
        fileContext = fileContext.replaceAll("NCPDID", ncpdpid);
        return fileContext;
    }

    public void dropXml(String inputPayload) {
        req.setRequestPayload(inputPayload);
        Reporter.logXML("ReqPayload: ", req.getRequestPayload());
        headers.put("accept", propertyReader.getProperty("prm.RxTransfer.content_type.xml"));
        headers.put("Content-Type", propertyReader.getProperty("prm.RxTransfer.content_type.xml"));
        headers.put("WM_CONSUMER.ID", propertyReader.getProperty("prm.RxTransferInboundProcessor.ConsumerId"));
        req.setHeaders(headers);
        req.setUrl("https://hw-erx-inbound-processor.stg.walmart.net/api/v2023/erx");
        resp = automationManager.getRestContext().performPost(req);
        Reporter.logXML("Response: ", resp.getDataResponse());
        Assert.assertEquals(resp.getStatusCode(), 200, "POST request returned error");
        Reporter.log("TRNASFERIN successful");
    }

    public void verifyRxInEODForMultiRx() {
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                rxNbr = String.valueOf(multiRxNbr.get(i));
                verifyRxInEOD();
            }
        } catch (Exception e) {
            Reporter.log("Failed to while checking if rx is in EOD for multi Rx" + e.getMessage());
            Assert.fail();
        }
    }

    public void performMultiRxInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        // NDC list dynamically handles 2 or 3 NDCs
        ndcList = new ArrayList<>();
        String[] ndcKeys = {"NDC_NUMBER1", "NDC_NUMBER2", "NDC_NUMBER3"};
        for (String key : ndcKeys) {
            String ndc = inputData.get(key);
            if (ndc != null) {
                ndc = ndc.trim();
                if (!ndc.isEmpty() && !ndc.equalsIgnoreCase("null") && !ndc.equalsIgnoreCase("NA")) {
                    ndcList.add(ndc);
                }
            }
        }
        try {
            for (int i=0; i<ndcList.size(); i++) {
                String[] name = connexusAppUtils.readPatientNameFromFile();
                rxModel.setPatientLastName(name[0]);
                rxModel.setPatientFirstName(name[1]);
                System.out.println("iteration loop:" + i);
                rxModel.setNdc(ndcList.get(i));
                rxModel.setPrescribedQty(inputData.get("QUANTITY"));
                rxModel.setSigCode(inputData.get("SIG"));
                rxModel.setNoOfRefills(inputData.get("REFILLS"));
                rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
                String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], i);
                if (rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue())) {
                    automationManager.getConnexusWorkFlow().performMultiRxInput(rxModel, i);
                } else {
                    Reporter.log("RX is not in Input queue");
                    Assert.fail();
                }
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Input queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void validateRecentDbTable() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            List<Map<String, Object>> recentRecords = connexusAppUtils.getRecentCreateRecords();
            if (recentRecords == null && recentRecords.isEmpty()) {
                Reporter.log("No recent records found in rx transfer fill table ");
            } else {
                Reporter.log("Successfully retrieved " + recentRecords.size() + " recent records");
                for (int i = 0; i < recentRecords.size(); i++) {
                    Map<String, Object> record = recentRecords.get(i);
                    Object rxId = record.get("rx_id");
                    Object transferId = record.get("transfer_ts");
                    Object seqNbr = record.get("fill_date");
                    Reporter.log((i + 1) + ". rx_id: " + rxId + ", transfer_ts: " + transferId + ", seqNbr: " + seqNbr);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.log("Test failed while validating recent database record: " + e.getMessage());
        }
    }

    public void validatePastMonthReport() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        try {
            menuBar.selectNavigation(AppMenu.ETRANSFER_INCOMING_FILL_HISTORY_REPORT, AppMenuItemsIndex.RX_REPORTS, AppMenuSubItemsIndex.ETRANSFER_INCOMING_FILL_HISTORY_REPORT, null);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(5);
            //  menuBar.pressKeys(KeyEvent.VK_ENTER);
            java.time.LocalDate today = java.time.LocalDate.now();
            java.time.LocalDate oneMonthAgo = today.minusMonths(1);
            java.time.format.DateTimeFormatter formater = java.time.format.DateTimeFormatter.ofPattern("MM/dd/yyyy");
            String pastDate = oneMonthAgo.format(formater);
            rxLookUp.setFromDate(pastDate);
            rxLookUp.enterPatientDetails(name[0] + ',' + name[1]);
            //  menuBar.pressKeys(KeyEvent.VK_TAB);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.clickShowReports();
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickCancel();

        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed while validating Inventory Adjustment report");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
        }
    }
    public void checkProblemMessage(String expectedPrblm1, boolean checkConfirmXfer, boolean acceptXfer) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + ',' + name[1]);
            automationManager.performSleep(10);
            orderSearch.clickSearch();
            String problemMessageRow0 = orderSearch.getProblemMessage(0);

            if (problemMessageRow0.equalsIgnoreCase(expectedPrblm1)){
                if(checkConfirmXfer){
                    orderSearch.openRecordForETransfer(0);
                    if(acceptXfer){
                        eTransferRequestPage.clickAcceptInConfirmTransferIn(0);
                        Reporter.logScreenShot("Confirm transferIn Screen", orderSearch.takeScreenShot(currentStepMethodName).getValue());
                        Reporter.log("transferIn confirmed");
                        eTransferRequestPage.clickAcceptBtn();
                        eTransferRequestPage.eTransferConfirmPopup();
                    }else {
                        Reporter.logScreenShot("ConfirmETransferScreen", orderSearch.takeScreenShot(currentStepMethodName).getValue());
                        Reporter.log("Drug are present in confirm eTransfer screen");
                        orderSearch.clickCancel();
                    }
                }else {
                    Reporter.logScreenShot(currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
                    Reporter.log("Order Is pending for eTransferIn");
                    orderSearch.closeSearch();
                }
            } else {
                Assert.fail("Rx not pending for eTransferIn");
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

}
