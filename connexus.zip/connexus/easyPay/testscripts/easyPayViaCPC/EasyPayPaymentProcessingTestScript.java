package connexus.easyPay.testscripts.easyPayViaCPC;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.CreatePatientRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.InsuranceDetails;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import com.aventstack.extentreports.Status;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.awt.event.KeyEvent;
import java.util.*;


public class EasyPayPaymentProcessingTestScript {

    LoginPage loginPage;
    ConnexusStartPage connexusStartPage;
    PatientSearchPage patientSearchPage;
    PatientMaintenancePage patientMaintenancePage;
    ConnexusAppUtils connexusAppUtils;
    AutomationManager automationManager;
    PropertyReader prop = PropertyReader.getInstance();
    SoftAssert softAssert;
    PatientMedicalConditionModel patientMedicalConditionModel;
    ConnexusAPIManager connexusApiManager = new ConnexusAPIManager();
    ServiceResponse resp;
    InputResponse inputResp = new InputResponse();
    int siteId,patientId,numRefills,priorityId,requestTypeCode,dispenseType,clinicId;
    PatientProfileModel patient;
    ThirdPartyModel thirdPartyModel;
    DropRxModel dropRxModel;
    AddressModel addressModel;
    ContactModel contactModel;
    String ndc;
    DataRow prescriber;
    DataRow drugInfo;
    RxModel rxModel;
    RxLookUp rxLookUp;
    VisVerPage visVerPage;
    F6Search orderSearch;
    PickupPage pickupPage;
    String rxNbr = null;
    InputResponse inputVVResp = new InputResponse();
    List<InputResponse> multiRxVVCompleteResp = new ArrayList<>();
    List<String> multiRxNbr = new ArrayList<>();
    List<String> multiRxNbrList = new ArrayList<>();
    List<String> ndcList;
    Map<String, Object> values = new HashMap<>();
    List<Integer> multiRxNbrValues = new ArrayList<>();
    WrapperUtils wrapperUtils = new WrapperUtils();

    public EasyPayPaymentProcessingTestScript() {
        prop.loadCustomProperties("config/connexus/");
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        connexusAppUtils = new ConnexusAppUtils();
        connexusApiManager = new ConnexusAPIManager();
        automationManager = AutomationManager.getInstance();
    }

    public void loginConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        connexusStartPage = new ConnexusStartPage();
        patientSearchPage = new PatientSearchPage();
        patient = new PatientProfileModel();
        thirdPartyModel = new ThirdPartyModel();
        dropRxModel = new DropRxModel();
        orderSearch = new F6Search();
        rxModel = new RxModel();
        rxLookUp = new RxLookUp();
        visVerPage = new VisVerPage();
        softAssert = new SoftAssert();
        addressModel = new AddressModel();
        contactModel = new ContactModel();
        softAssert = new SoftAssert();
        pickupPage = new PickupPage();
        connexusAppUtils = new ConnexusAppUtils();
        automationManager = AutomationManager.getInstance();
        patientMaintenancePage = new PatientMaintenancePage();
        patientMaintenancePage = new PatientMaintenancePage();
        patientMedicalConditionModel = new PatientMedicalConditionModel();
        connexusApiManager = new ConnexusAPIManager();
        loginPage.loginConnexus(userType);
    }

    public int getPatientId(Map<String, String> inputData){
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        automationManager.performSleep(3);
        String firstName = name[0];
        String lastName = name[1];
        long homePhone, workPhone, cellPhone;
        homePhone = Long.parseLong(inputData.get("HOME_PHONE"));
        workPhone = Long.parseLong(inputData.get("WORK_PHONE"));
        cellPhone = Long.parseLong(inputData.get("CELL_PHONE"));
        resp = connexusApiManager.createPatient(lastName, firstName, inputData.get("DOB"), siteId, homePhone, workPhone, cellPhone);
        Assert.assertEquals(resp.getStatusCode(), 201, "Create Patient details" + resp.getDataResponse());
        inputResp = resp.getDataResponse(InputResponse.class);
        patientId = inputResp.getPatientId();
        Log.info("patientId = " + patientId);
        Reporter.log("Patient has been created.");
        return patientId;
    }

    public int addVisaCardToPatient(Map<String, String> inputData) {
        patientId = getPatientId(inputData);
        String strNbr = String.valueOf(siteId);
        resp= connexusApiManager.insertEasyPayCardDetails(strNbr,patientId);
        Assert.assertEquals(resp.getStatusCode(), 202, "Add Card details" + resp.getDataResponse());
        return patientId;
    }

    public void updateP2pTokenValue(){
        connexusAppUtils.updateP2PeTokenValueHasNull(patientId);
        Reporter.log("Removed P2PeToken value in visa card to Patient for getting unsuccessful transaction");
    }

    public String createOrderAndMoveToPickup(Map<String, String> inputData){
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        String ndc = inputData.get("DRUG_NAME1");
        inputVVResp = connexusApiManager.createNewOrderAndMoveToPickup(patientId,siteId,numRefills, ndc);
        rxNbr = String.valueOf(inputVVResp.getRxNbr());
        System.out.println("rxNbr:" + rxNbr);
        return rxNbr;
    }

    public void performDropOff() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.InStore);
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);
        } catch (Throwable e) {
            Reporter.log("Test failed at DropOff queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }
    public void performInput(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxModel.setNdc(inputData.get("DRUG_NAME1"));
            rxModel.setPrescribedQty(inputData.get("QUANTITY"));
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().performInput(rxModel);
            } else {
                Reporter.log("RX is not in Input queue");
                Assert.fail();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Input queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }
    public void perform4Point() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
            {
                automationManager.getConnexusWorkFlow().completeResolution(name[0] + "," + name[1]);
            }
            rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void checkAndPerformCheckDUR() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        ChkDur dur = new ChkDur();
        automationManager.performSleep(5);
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                if (!dur.clickClearConflictsBtn()) {
                    dur.selectCheckBoxes();
                }
                Reporter.logScreenShot(Status.INFO, "Screenshot of ChkDUR Page", dur.takeScreenShot("ChkDUR").getValue());
                dur.clickAccept();
                dur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            }
            else if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                Reporter.log("WorkQueue: " + rxStatus);
                Assert.assertEquals(rxStatus, "filling", "order is not in Filling queue");
            }
        }catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR or Filling queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void performFilling() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {

            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            System.out.println("Rx status" + rxStatus);
            automationManager.performSleep(50);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
                Reporter.log("RX is in Resolve queue");
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                Reporter.log("RX is in CASH queue");
                automationManager.performSleep(70);
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()))
                {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                automationManager.performSleep(5);
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Filling queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }
    public void performVisualVerify() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
            } else {
                Reporter.log("RX is not in Visual Verify queue");
                Assert.fail("RX is not in Visual Verify queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Visual Verify queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }
    public void performPickup(Map<String, String> inputData, int patientId, String workQueue, String rxNbr, String fillId) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String firstName, lastName;
        try {
            Reporter.log("patientId: " + patientId);
            resp = connexusApiManager.getPatientInformation(siteId,patientId,"");
            Gson gson = new Gson();
            JsonObject root = gson.fromJson(resp.getDataResponse(), JsonObject.class);

            JsonObject patient = root.getAsJsonObject("Patient");
            JsonObject generalInfo = patient.getAsJsonObject("PatGeneralInfo");
            JsonObject personalInfo = generalInfo.getAsJsonObject("PersonalInfo");
            firstName = personalInfo.get("FirstName").getAsString();
            lastName = personalInfo.get("LastName").getAsString();
            WorkQueueSettings queue = WorkQueueSettings.valueOf(workQueue);
            if (queue == WorkQueueSettings.Pickup) {
                automationManager.getConnexusWorkFlow().completePickupWithPaymentValidation(firstName.trim(), lastName.trim(), inputData.get("DOB"),
                        rxNbr, String.valueOf(siteId), fillId);
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at PickUp queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

        }
    }

    public List<String> createMultiRxAndMoveToPickup(Map<String, String> inputData){
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        ndcList = Arrays.asList(inputData.get("DRUG_NAME1"), inputData.get("DRUG_NAME2"));
        multiRxVVCompleteResp = connexusApiManager.createMultiRxAndMoveToPickup(patientId, siteId, numRefills, ndcList, connexusApiManager.PrescriberDetails());
        for(int i=0; i<=1; i++) {
            rxNbr = String.valueOf(multiRxVVCompleteResp.get(i).getRxNbr());
            multiRxNbr.add(rxNbr);
            Log.info("rxNbrValue:" + rxNbr);
        }
        return multiRxNbr;
    }

    public List<String> createMultiRxOrderTillPickup(Map<String, String> inputData){
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        ndcList = Arrays.asList(inputData.get("DRUG_NAME1"), inputData.get("DRUG_NAME2"));
        multiRxNbr = connexusApiManager.createNewMultiDrugOrderToReadyForPickUp(patientId, siteId,numRefills, ndcList, connexusApiManager.PrescriberDetails());
        return multiRxNbr;
    }

    public Prescriber PrescriberDetails(Map<String, String> inputData) {
        Prescriber prescriber = new Prescriber();
        int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        prescriber.setFullname(inputData.get("PRESCRIBER_FULLNAME"));
        prescriber.setFirstname(inputData.get("PRESCRIBER_FIRSTNAME"));
        prescriber.setLastname(inputData.get("PRESCRIBER_LASTNAME"));
        prescriber.setPhone(inputData.get("PRESCRIBER_PHONE"));
        prescriber.setState(inputData.get("PRESCRIBER_STATE"));
        prescriber.setPrescriberId(Integer.parseInt(inputData.get("PRESCRIBER_ID")));
        prescriber.setRxClinicId(Integer.parseInt(inputData.get("PRESCRIBER_RXCLINICID")));
        prescriber.setDea(inputData.get("PRESCRIBER_DEA"));
        prescriber.setNpi(inputData.get("PRESCRIBER_NPI"));
        return prescriber;
    }

   public int genericCreatePatientWithTP(Map<String, String> inputData) {
       CreatePatientRequest createPatientRequest = new CreatePatientRequest();
       InsuranceDetails insuranceDetails = new InsuranceDetails();
       connexusAppUtils.addRandomNamesInFile();
       String[] name = connexusAppUtils.readPatientNameFromFile();
       siteId = Integer.parseInt(prop.getProperty("cnx.store"));
       //Build input patient
       createPatientRequest.setFirstName(name[0]);
       createPatientRequest.setLastName(name[1]);
       //createPatientRequest.setDob(inputData.get("DOB_TIMESTAMP"));
       createPatientRequest.setSiteId(siteId);
       createPatientRequest.setHomePhone(inputData.get("HOME_PHONE"));
       createPatientRequest.setWorkPhone(inputData.get("WORK_PHONE"));
       createPatientRequest.setCellPhone(inputData.get("CELL_PHONE"));
       //With TP Details
       createPatientRequest.setPatientHasInsurance(Boolean.parseBoolean(inputData.get("patientHasInsurance")));
       insuranceDetails.setInsuranceCarrierPlanId(Integer.parseInt(inputData.get("carrierPlanId")));
       insuranceDetails.setInsuranceCarrierCompanyId(Integer.parseInt(inputData.get("carrierCompanyCode")));
       insuranceDetails.setBillingSeqNbr(Integer.parseInt(inputData.get("billSeqNbr")));
       insuranceDetails.setCardholderId(inputData.get("cardHolderId"));
       insuranceDetails.setCardholderFirstName(inputData.get("cardHolderFirstName"));
       insuranceDetails.setCardholderLastName(inputData.get("cardHolderLastName"));
       insuranceDetails.setRelationshipCode(Integer.parseInt(inputData.get("relationshipCode")));
       insuranceDetails.setCoverageInd(inputData.get("coverageIndicator"));
       insuranceDetails.setCoverageExpDate(inputData.get("covExpDate"));
       insuranceDetails.setSplitBillInd(inputData.get("splitBillInd"));
       insuranceDetails.setInsPlanTypeCode(Integer.parseInt(inputData.get("planTypeCode")));
       createPatientRequest.setInsurance(insuranceDetails);
       patientId = connexusApiManager.createPaientWithOrWithoutTP(createPatientRequest);
       return patientId;
   }

   public void createNewPatientWithTP(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);
            thirdPartyModel.setCarrierBin(inputData.get("TP_CARRIER_BIN"));
            thirdPartyModel.setPlan(inputData.get("TP_PLAN"));
            thirdPartyModel.setCardId(inputData.get("TP_CARD_ID"));
            patient.setPatientTp(thirdPartyModel);
            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            patientMaintenancePage.sendHotKeys(Keys.TAB);
            if (patientMaintenancePage.isOkDisplayed()) {
                patientMaintenancePage.clickOk();
            }
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);
            automationManager.getConnexusWorkFlow().createNewPatient(true, patient);
            Reporter.log("Patient has been created.");
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

   public void performMultiRxPickUp(Map<String, String> inputData, int patientId, List<String> rxNbrList, String workQueue) {
       String currentStepMethodName = new Object() {
       }.getClass().getEnclosingMethod().getName();
       String firstName, lastName;

           Reporter.log("patientId: " + patientId);
           resp = connexusApiManager.getPatientInformation(siteId, patientId, "");
           Gson gson = new Gson();
           JsonObject root = gson.fromJson(resp.getDataResponse(), JsonObject.class);

           JsonObject patient = root.getAsJsonObject("Patient");
           JsonObject generalInfo = patient.getAsJsonObject("PatGeneralInfo");
           JsonObject personalInfo = generalInfo.getAsJsonObject("PersonalInfo");
           firstName = personalInfo.get("FirstName").getAsString();
           lastName = personalInfo.get("LastName").getAsString();
           WorkQueueSettings queue = WorkQueueSettings.valueOf(workQueue);
       try{
       if (queue == WorkQueueSettings.Pickup) {
           automationManager.getConnexusWorkFlow().completeMultiRxPickupWithPaymentValidation(firstName.trim(), lastName.trim(), inputData.get("DOB"), rxNbrList, String.valueOf(siteId));
       }
           } catch (Throwable e) {
               Reporter.log("Test failed at PickUp queue");
               e.printStackTrace();
               Assert.fail(e.toString());
               Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
           }
       }

   public void addVisaCardToPatientForTP(Map<String, String> inputData) {
        String strNbr = String.valueOf(siteId);
        resp= connexusApiManager.insertEasyPayCardDetails(strNbr,patientId);
        Assert.assertEquals(resp.getStatusCode(), 202, "Add Card details" + resp.getDataResponse());
   }

   public int getPatientIdFromName(Map<String, String> inputData){
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String query = "select patient_id from patient where first_name= " + "'" + name[1].toUpperCase() + "'" + " and last_name = " + "'" + name[0].toUpperCase() + "';";
        patientId = automationManager.getConnexusDB(siteId).getScalar(query, Integer.class);
        return patientId;
   }

    public String createNewOrderAndMoveToPickup(Map<String, String> inputData,String ndc){
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        inputVVResp = connexusApiManager.createNewOrderAndMoveToPickup(patientId,siteId,numRefills, ndc);
        rxNbr = String.valueOf(inputVVResp.getRxNbr());
        return rxNbr;
    }

    public String createNewOrderTillPickup(Map<String, String> inputData, String ndc) {
        Reporter.log("Creating new order till pickup thorough API");
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        priorityId = Integer.parseInt(inputData.get("PriorityId"));
        requestTypeCode = Integer.parseInt(inputData.get("RequestTypeCode"));
        dispenseType = Integer.parseInt(inputData.get("DispenseType"));
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        clinicId = Integer.parseInt(inputData.get("ClinicId"));
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();
        drugInfo = connexusApiManager.getDrugInfo(cnx, ndc);
        DataRow prescriberId = connexusApiManager.getPrescriberInfo(cnx, Integer.parseInt(inputData.get("PRESCRIBER_ID")));
        resp = connexusApiManager.orderToPickup(siteId, patientId, priorityId, requestTypeCode, dispenseType, numRefills, inputPickupDate, clinicId, inputRxExpDate, drugInfo, prescriberId);
        Assert.assertEquals(resp.getStatusCode(), 201, "The order cannot be created and drop till pickup" + resp.getDataResponse());
        Gson gson = new Gson();
        JsonObject json = gson.fromJson(resp.getDataResponse(), JsonObject.class);
        rxNbr = json.get("rxNbr").getAsString();
        Log.info("rxNbr:" + rxNbr);
        Reporter.log("rxNbr:" + rxNbr);
        Reporter.log("New order has been created and moved to pickup");
        return rxNbr;
    }

    public void changeTPtoCashForSingleOrder(String rxNbr, String workQueue) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            WorkQueueSettings queue = WorkQueueSettings.valueOf(workQueue);
            if (queue == WorkQueueSettings.TroubleShooting){
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
        }
               Assert.assertTrue(workQueue.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue()));

                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                System.out.println("productName:" + productName);
                if(productName.contains("GLUCOSE")){
                    patientSearchPage.openFirstPatientRecord();
                    automationManager.performSleep(5);
                    pickupPage.selectInsurance(0);
                    pickupPage.clickAcceptBtn();
                    pickupPage.rxExpAndDrugDateSelection();
                    pickupPage.clickAcceptBtn();
                    pickupPage.selectReasonForSwitchToCash();
                    pickupPage.clickOKBtn();
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, pickupPage.takeScreenShot(currentStepMethodName).getValue());
                    Reporter.log("Changed Tp to Cash and Rx moved to 4 Point");
                    loginPage.pressKeys(KeyEvent.VK_ENTER);
                    automationManager.performSleep(5);
                    pickupPage.handleBottleLabelPopup();
            }
        }   catch(Throwable e){
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void perform4PointForMultiOrder(List<String> rxNbrList) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String rxStatus, rxNbr;
        try {

            for (int i=0; i< rxNbrList.size(); i++) {
                rxNbr = String.valueOf(rxNbrList.get(i));
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                    automationManager.performSleep(10);
                }
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr,0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.FOUR_POINT.getWorkQueue())) {
                    automationManager.getConnexusWorkFlow().performFourPoint(rxNbr);
                }
            }
            loginPage.pressKeys(KeyEvent.VK_ENTER);
            automationManager.performSleep(5);
            pickupPage.handleBottleLabelPopup();
            Reporter.log("Rx moved to Pickup after changed Tp to Cash");
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue and moved to Pickup");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void performMultiRxPickUpForTP(Map<String, String> inputData, List<String> rxNbrList) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String rxStatus, currentRxNbr, firstName, lastName;
        Reporter.log("patientId: " + patientId);
        // Fetch patient details from API
        resp = connexusApiManager.getPatientInformation(siteId, patientId, "");
        JsonObject root = JsonParser.parseString(resp.getDataResponse()).getAsJsonObject();
        JsonObject personalInfo = root
                .getAsJsonObject("Patient")
                .getAsJsonObject("PatGeneralInfo")
                .getAsJsonObject("PersonalInfo");
        firstName = personalInfo.get("FirstName").getAsString().trim();
        lastName = personalInfo.get("LastName").getAsString().trim();
        try {
            for (int i = 0; i < rxNbrList.size(); i++) {
                currentRxNbr = String.valueOf(rxNbrList.get(i));
                rxStatus = orderSearch.getRXStatusForPatientSelfHelp(currentRxNbr, 0, inputData);
                Assert.assertTrue(rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue()));
            }
            automationManager.getConnexusWorkFlow().completeMultiRxPickupWithIndividualRx(firstName.trim(), lastName.trim(), inputData.get("DOB"), rxNbrList, String.valueOf(siteId));
        }   catch(Throwable e){
            Reporter.log("Test failed at PickUp queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void performMultiRxDropOff() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[1]);
            dropRxModel.setPatientFirstName(name[0]);
            dropRxModel.setNoOfRx(2);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);
        } catch (Throwable e) {
            Reporter.log("Test failed at DropOff queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void performMultiRxInput(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        ndcList = Arrays.asList(inputData.get("DRUG_NAME1"), inputData.get("DRUG_NAME2"));
        try {
            for (int i=0; i<2; i++) {
                String[] name = connexusAppUtils.readPatientNameFromFile();
                rxModel.setPatientLastName(name[1]);
                rxModel.setPatientFirstName(name[0]);
                System.out.println("iteration loop:" + i);
                rxModel.setNdc(ndcList.get(i));
                rxModel.setPrescribedQty(inputData.get("QUANTITY"));
                rxModel.setSigCode(inputData.get("SIG"));
                rxModel.setNoOfRefills(inputData.get("REFILLS"));
                rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
                String rxStatus = orderSearch.getRXStatusForPatient(name[1] + "," + name[0], i);
                if (rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue())) {
                    automationManager.getConnexusWorkFlow().performMultiRxInput(rxModel, i);
                } else {
                    Reporter.log("RX is not in Input queue");
                    Assert.fail();
                }
            }
        }catch (Throwable e) {
            Reporter.log("Test failed at Input queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void addCardToPatientAccount(Map<String, String> inputData) {
        patientId = getPatientId(inputData);
        String strNbr = String.valueOf(siteId);
        String cardRefNbr,cardHolderName,expirYearNbr,expirMoNbr,p2peToken, startDate, phmPymtMethod;
        cardRefNbr   = inputData.get("CRD_REF_NUMBER");
        cardHolderName   = inputData.get("CARD_HOLDER_NAME");
        expirYearNbr   = inputData.get("EXPIRY_YEAR");
        expirMoNbr   = inputData.get("EXPIRY_MONTH");
        p2peToken   = inputData.get("P2P_TOKEN");
        startDate   = inputData.get("START_DATE");
        phmPymtMethod   = inputData.get("PAYMENT_METHOD");
        resp= connexusApiManager.addCardToPatientAccount(String.valueOf(patientId),strNbr,cardRefNbr,cardHolderName,expirYearNbr,expirMoNbr,p2peToken, startDate, phmPymtMethod);
        Assert.assertEquals(resp.getStatusCode(), 202, "Add Card details" + resp.getDataResponse());
    }

    public void fetchOrderDetails(){
        connexusAppUtils.updateP2PeTokenValueHasNull(patientId);
        Reporter.log("Removed P2PeToken value in visa card to Patient for getting unsuccessful transaction");
    }

}
