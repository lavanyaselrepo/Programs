package connexus.easyPay.testcases.easyPayViaCPC;

import connexus.ConnexusTestScripts;
import connexus.easyPay.testscripts.easyPayViaCPC.EasyPayPaymentProcessingTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import java.util.*;

public class EasyPayPaymentProcessingTestSet {

    EasyPayPaymentProcessingTestScript easyPayPaymentProcessingTestScript = new EasyPayPaymentProcessingTestScript();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    PropertyReader prop = PropertyReader.getInstance();
    String siteId = prop.getProperty("cnx.store");
    String stateCode = "";
    ConnexusTestScripts connexusTestScripts = new ConnexusTestScripts();
    int patientId;
    List<String> multiRxDetails = new ArrayList<>();
    Map<String, List<String>> workQueueToRxList = new HashMap<>();
    List<String> rxFillIdList = new ArrayList<>();
    String workQueue = null;
    AutomationManager automationManager = AutomationManager.getInstance();
    int isOrderIn4pointAndNotDURCount = 0;

    @BeforeClass
    public void performlogin(){
        connexusAppUtils.startAppiumServer();
        connexusAppUtils.readAndUpdateFlag("28750", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15068", "QA");
        connexusAPIManager.flushCache(siteId);

    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    @Test(description = "To Validate Easy Pay via CPC - Payment processing without P2PE token for single rx",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/easyPay/easyPay.json", sheetName = "EasyPayTestData")
    public void HWPHME2E_1607_Payment_Processing_Without_P2PE_token_for_SingleRx(Map<String, String> inputData) {
        System.out.println("<<<HWPHME2E_1607 Validate Payment processing without P2PE token for single rx>>>");

        //Add Visa cards to patient profile
        patientId = easyPayPaymentProcessingTestScript.addVisaCardToPatient(inputData);

        // perform drop off to pickup
        List<String> responseList = connexusTestScripts.createNewOrderTillPickup(inputData,inputData.get("DRUG_NAME1"),patientId);
        String rxNbr = responseList.get(0);
        String workQueue = responseList.get(1);
        String fillId = responseList.get(2);
        //Without P2PE token
        easyPayPaymentProcessingTestScript.updateP2pTokenValue();

        //perform pickup
        easyPayPaymentProcessingTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        easyPayPaymentProcessingTestScript.performPickup(inputData, patientId, workQueue, rxNbr,fillId);

        System.out.println("<<<HWPHME2E_1607 Validated Payment processing without P2PE token for single rx>>>");
    }

    @Test(description = "To Validate Easy Pay via CPC - Payment processing without P2PE token for multiple rx's",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/easyPay/easyPay.json", sheetName = "EasyPayTestData")
    public void HWPHME2E_1608_Payment_Processing_Without_P2PE_token_for_MultiRx(Map<String, String> inputData) {
        System.out.println("<<<HWPHME2E_1608 Validate Payment processing without P2PE token for multi rx's>>>");

        //Add Visa cards to patient profile
        patientId = easyPayPaymentProcessingTestScript.addVisaCardToPatient(inputData);
        List<String> ndcList = Arrays.asList(inputData.get("DRUG_NAME1"), inputData.get("DRUG_NAME2"));
        //perform drop off MultiRx ZeroPay and EasyPay to and move to pickup
        multiRxDetails = connexusTestScripts.dropMultiRxOrderTillPickup(inputData,ndcList, patientId);
        for (int i = 0; i < multiRxDetails.size(); i += 5) {

            String rxNbr = multiRxDetails.get(i);
            String workQueue = multiRxDetails.get(i + 1);
            String fillId = multiRxDetails.get(i + 2);

            // Group Rx numbers by work queue
            workQueueToRxList.computeIfAbsent(workQueue, k -> new ArrayList<>()).add(rxNbr);
            rxFillIdList.add(fillId);

        }

        // Loop over each WorkQueue and process pickup
        for (Map.Entry<String, List<String>> entry : workQueueToRxList.entrySet()) {
            String workQueue = entry.getKey();
            List<String> rxNbrList = entry.getValue();

        //Without P2PE token
        easyPayPaymentProcessingTestScript.updateP2pTokenValue();

        //perform multi rx pickup
        easyPayPaymentProcessingTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        easyPayPaymentProcessingTestScript.performMultiRxPickUp(inputData, patientId, rxNbrList, workQueue);

        System.out.println("<<<HWPHME2E_1608 Validated Payment processing without P2PE token for multi rx's>>>");
    }
    }

    @Test(description = "To Validate Easy Pay via CPC - Payment processing without P2PE token for multiple rx's (1 ZeroPay and 1 EasyPay)",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/easyPay/easyPay.json", sheetName = "EasyPayTestData")
    public void HWPHME2E_1609_Payment_Processing_Without_P2PE_token_for_MultiRx_for_1ZeroPay_And_1EasyPay(Map<String, String> inputData) {
        System.out.println("<<<HWPHME2E_1609 Validate Payment processing without P2PE token for multiple for 1ZeroPay And 1EasyPay>>>");

        // add insurance with no active card to Patient
        patientId = easyPayPaymentProcessingTestScript.genericCreatePatientWithTP(inputData);

        //perform drop off to and move to pickup
        List<String> responseDetails = connexusTestScripts.createNewOrderTillPickup(inputData, inputData.get("DRUG_NAME1"), patientId);
        String rxNbrWithZeroPay = responseDetails.get(0);
        String workQueue = responseDetails.get(1);
        // Select the same Patient and add new active Easy Pay card or activate existing easy pay card.
        easyPayPaymentProcessingTestScript.addVisaCardToPatientForTP(inputData);

        //perform drop off to and move to pickup
        List<String> responseList = connexusTestScripts.createNewOrderTillPickup(inputData, inputData.get("DRUG_NAME2"), patientId);
        String rxNbrWithEasyPay = responseList.get(0);
        workQueue = responseList.get(1);

        //Without P2PE token
        easyPayPaymentProcessingTestScript.updateP2pTokenValue();

        //change TP to cash for EasyPay Order
        easyPayPaymentProcessingTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);

        easyPayPaymentProcessingTestScript.changeTPtoCashForSingleOrder(rxNbrWithEasyPay, workQueue);

        // Polling till order moves from Cash queue
        for (int index = 0; index <= 6; index++) {
            automationManager.performSleep(10);
            isOrderIn4pointAndNotDURCount = connexusTestScripts.checkOrderIn4pointAndNotCash(rxNbrWithEasyPay);
            if (isOrderIn4pointAndNotDURCount > 0) {
                break;
            }
        }
        String rxFillId = connexusAppUtils.getOrderDetails(rxNbrWithEasyPay);
        connexusTestScripts.getOrderDetailsAndMoveToPickup(Integer.parseInt(rxFillId));
        //perform pickup
        List<String> rxNbrList = new ArrayList<>();
        rxNbrList.add(rxNbrWithZeroPay);
        rxNbrList.add(rxNbrWithEasyPay);
        easyPayPaymentProcessingTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        easyPayPaymentProcessingTestScript.performMultiRxPickUpForTP(inputData, rxNbrList);

        System.out.println("<<<HWPHME2E_1609 Validated Payment processing without P2PE token for multiple for 1ZeroPay And 1EasyPay>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Easy Pay via CPC-Payment processing using P2PE token for multiple rx's or single rx's and
     * the Tax amount is verified when the state is LA
     * Jira(testID = "HWPHME2E-2794")
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description ="EasyPay Payment processing using P2PE token for single rx and verify Tax amount when the state is LA",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/easyPay/easyPay.json", sheetName = "EasyPayTestData")
    public void HWPHME2E_2794_Payment_Processing_Using_P2PE_token_for_1Rx_And_verify_TaxAmount_For_LA_State(Map<String, String> inputData) {
        Reporter.log("EasyPay Payment processing using P2PE token for single rx and verify Tax amount when the state is LA");
        //Pre-condition
        connexusAppUtils.readAndUpdateFlag("28750", "TRUE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        connexusAPIManager.flushCache(String.valueOf(siteId));
        //steps
        //Add Visa cards to patient profile
        easyPayPaymentProcessingTestScript.addVisaCardToPatient(inputData);
        //perform drop off to and move to pickup
        easyPayPaymentProcessingTestScript.createNewOrderTillPickup(inputData, inputData.get("DRUG_NAME1"));
        // Partial automation — order processed up to the Pick WQ status
        Reporter.log(" Pickup payment processing will be validated once the CPC issue is resolved in the automation boxes");
        Reporter.log("EasyPay Payment processing using P2PE token for single rx and verify Tax amount when the state is LA");
    }

    /*----------------------------------------------------------------------------------------------------------
   * Test Description: Easy Pay via CPC - Payment processing using P2PE token for multiple rx's (1 ZeroPay and 1 EasyPay)..
   * Jira(testID = "HWPHME2E-1605")
   * Author: Lavanya Torrikonda(vn575up)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Easy Pay via CPC - Payment processing without P2PE token for multiple rx's (1 ZeroPay and 1 EasyPay)",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/easyPay/easyPay.json", sheetName = "EasyPayTestData")
    public void HWPHME2E_1605_Payment_Processing_Using_P2PE_token_for_MultiRx_for_1ZeroPay_And_1EasyPay(Map<String, String> inputData) {
        Reporter.log("Validate Payment processing using P2PE token for multiple for 1ZeroPay And 1EasyPay");
        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) TRUE to login to Home office
        connexusAppUtils.readAndUpdateFlag("28750", "TRUE");
        //steps
        // add insurance with no active card to Patient
        patientId = easyPayPaymentProcessingTestScript.genericCreatePatientWithTP(inputData);
        //perform drop off to and move to pickup
        List<String> responseDetails = connexusTestScripts.createNewOrderTillPickup(inputData,inputData.get("DRUG_NAME1"), patientId);
        String rxNbrWithZeroPay = responseDetails.get(0);
        
        // Select the same Patient and add new active Easy Pay card or activate existing easy pay card.
        easyPayPaymentProcessingTestScript.addVisaCardToPatientForTP(inputData);
        //perform drop off to and move to pickup
        List<String> responseList = connexusTestScripts.createNewOrderTillPickup(inputData, inputData.get("DRUG_NAME2"), patientId);
        String rxNbrWithEasyPay = responseList.get(0);
        workQueue = responseList.get(1);
        //change TP to cash
        easyPayPaymentProcessingTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);

        easyPayPaymentProcessingTestScript.changeTPtoCashForSingleOrder(rxNbrWithEasyPay, workQueue);

        // Polling till order moves from Cash queue
        for (int index = 0; index <= 6; index++) {
            automationManager.performSleep(10);
            isOrderIn4pointAndNotDURCount = connexusTestScripts.checkOrderIn4pointAndNotCash(rxNbrWithEasyPay);
            if (isOrderIn4pointAndNotDURCount > 0) {
                break;
            }
        }
        easyPayPaymentProcessingTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        List<String> rxNbrList = new ArrayList<>();
        rxNbrList.add(rxNbrWithZeroPay);
        rxNbrList.add(rxNbrWithEasyPay);
        easyPayPaymentProcessingTestScript.perform4PointForMultiOrder(rxNbrList);
        // Partial automation — order processed up to the Pick WQ status
        Reporter.log(" Pickup payment processing will be validated once the CPC issue is resolved in the automation boxes");
        Reporter.log("Validated Payment processing without P2PE token for multiple for 1ZeroPay And 1EasyPay");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Easy Pay via CPC - Payment processing using P2PE token for 1 rx.
    * Jira(testID = "HWPHME2E-1604")
    * Author: Lavanya Torrikonda(vn575up)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Easy Pay via CPC - Payment processing using P2PE token for 1 rx",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/easyPay/easyPay.json", sheetName = "EasyPayTestData")
    public void HWPHME2E_1604_Payment_Processing_using_P2PE_token_for_SingleRx(Map<String, String> inputData) {
        Reporter.log("Validate Payment processing using P2PE token for single rx");
        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) TRUE to login to Home office
        connexusAppUtils.readAndUpdateFlag("28750", "TRUE");
        //steps
        //Add Visa cards to patient profile
        patientId = easyPayPaymentProcessingTestScript.addVisaCardToPatient(inputData);
        //perform drop off to and move to pickup
        List<String> responseList = connexusTestScripts.createNewOrderTillPickup(inputData,inputData.get("DRUG_NAME1"),patientId);
        String rxNbr = responseList.get(0);
        String workQueue = responseList.get(1);
        String fillId = responseList.get(2);

        easyPayPaymentProcessingTestScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        //perform pickup
        easyPayPaymentProcessingTestScript.performPickup(inputData,patientId, workQueue, rxNbr,fillId);


        // Partial automation — order processed up to the Pick WQ status
        Reporter.log(" Pickup payment processing will be validated once the CPC issue is resolved in the automation boxes");
        Reporter.log("Validated Payment processing using P2PE token for single rx>>>");
    }

}
