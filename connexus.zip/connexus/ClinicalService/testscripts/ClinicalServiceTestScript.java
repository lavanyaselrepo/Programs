package connexus.ClinicalService.testscripts;

import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;

import java.util.Map;

public class ClinicalServiceTestScript extends ConnexusTestScripts {

    PropertyReader prop = PropertyReader.getInstance();
    int siteId = Integer.parseInt(prop.getProperty("cnx.store"));

    public ClinicalServiceTestScript(LoginAs.userType loginUserType) {
        super(loginUserType);
    }




    public void validateHealthServicePortalBrowserIsOpenedWithExpectedUrl(Map<String, String> inputData) {
        try {
            menuBar.clickHealthServicePortal();
            Reporter.log("Clicked on Health Service Portal shortcut from Tools Menu Bar");
            Assert.assertTrue(menuBar.getBrowserUrl(inputData.get("BROWSER_URL")));
            Reporter.log("Health Service Portal browser is opened successfully by clicking on Health Service Appointments shortcut from tools menu bar");
            Runtime.getRuntime().exec("TASKKILL /F /IM chrome.exe");
            Reporter.log("Browser Closed");
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.log("failed to validate the URL of the browser opened" + e.getMessage());
            Assert.fail("");
        }
    }
}