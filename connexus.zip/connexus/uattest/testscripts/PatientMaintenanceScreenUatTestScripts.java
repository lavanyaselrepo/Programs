package connexus.uattest.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuscontext.LeftBarWorkQueues;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.PatientMaintenancePage;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.appium.java_client.AppiumBy;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.SearchContext;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;


public class PatientMaintenanceScreenUatTestScripts extends ConnexusTestScripts {

    PatientIdentityModel patientIdentityModel = new PatientIdentityModel();

    public void searchAndCreatePatient() {
        //Search If Patient Exist
        if (!patientSearchPage.verifyPatientSearchScreen()) {
            patientSearchPage.launchPatientSearchScreen();
        }
        patientSearchPage.inputPatientName("AN,AM");
        patientSearchPage.inputPatientDob("09/09/1992");

        patientSearchPage.clickSearchNow();
        if (patientSearchPage.isPatientRecordDisplayed(0) &&
                patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(patient.getPatientLastName() + "," + patient.getPatientFirstName())) {
            patientSearchPage.openFirstPatientRecord();

        } else {
            patientSearchPage.hostSearchPatient();
        }
        patientSearchPage.clickNew();
    }

    public void verifyWeightFieldDisabled() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (!patientMaintenancePage.isWeightEnabled()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void createPatient(Map<String, String> inputData) {


        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();

        patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
        patient.setPatientFirstName(name[1]);
        patient.setPatientLastName(name[0]);
        patient.setPatientDob(inputData.get("DOB"));
        patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

        addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
        addressModel.setPatientCity(inputData.get("CITY"));
        addressModel.setPatientState(inputData.get("STATE"));
        addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
        addressModel.setPatientCountry(inputData.get("COUNTRY"));

        patient.setPatientAddress(addressModel);

        contactModel.setPatientPhoneNumber1(inputData.get("PHONE_NUMBER1"));
        contactModel.setPatientPhoneNumber2(inputData.get("PHONE_NUMBER2"));
        contactModel.setPatientPhoneNumber3(inputData.get("PHONE_NUMBER3"));
        contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
        contactModel.setPatientAlternateNumber(inputData.get("ALTERNATE_NUMBER"));
        contactModel.setPatientMessagingNumber(inputData.get("MESSAGING_NUMBER"));
        contactModel.setPreferredPhoneNumber(ContactModel.PreferredPhoneNumber.PHONE_NUMBER1);

        patient.setPatientContact(contactModel);

        patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
        patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
        patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));

        patient.setPatientIdentityModel(patientIdentityModel);
        patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
        patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);

        patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

        automationManager.getConnexusWorkFlow().searchAndCreatePatient(false, patient);
    }


    /*
     * Method to click the drop off icon and validate drop off screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void clickAndValidateDropOffScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.DROP_OFF_ICON);
            Assert.assertTrue(dropOffPage.isPatientRxTextBoxDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To enter the patient name in DOb/Rx/PatientName text box in drop off screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void inputPatientNameInDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.pressTabKey();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To click patient maintenance folder icon in drop off screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void clickPatientMaintenanceIconInDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickPatientMaintenanceIcon();
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To select state from drop down of patient maintenance page
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void selectStateInPTMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.selectState(inputData.get("NEW_STATE"));
            Assert.assertEquals(patientMaintenancePage.getStateText(), inputData.get("NEW_STATE"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To select country from drop down of patient maintenance page
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void selectCountryInPTMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.selectCountry(inputData.get("NEW_COUNTRY"));
            Assert.assertEquals(patientMaintenancePage.getCountryText(), inputData.get("NEW_COUNTRY"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To enter zip code in patient maintenance page
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void enterZipCodeInPTMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clearZipCode();
            patientMaintenancePage.ZipCode(inputData.get("NEW_ZIP_CODE"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To select state from drop down of patient maintenance page
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void clickSaveAndCloseInPTMS() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickSaveAndClose();
            Assert.assertTrue(dropOffPage.isDropOffIconDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To click cancel in drop off screen
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public void clickCancelInDropOff() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            dropOffPage.clickBtnCancel();
            dropOffPage.clickYesInPopUp();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To enter the patient name in DOb/Rx/PatientName text box in drop off screen
     *
     * Author: vn50jui(vn50jui)
     * */
    public void searchForPatientInDropOffScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.enterPatientNameInDropOffAndSearch(inputData.get("PATIENT_NAME"));
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To select the given Residence Type on PTMS
     *
     * Author: Srinivas(vn50jui)
     * */

    public void selectCountryStateTypeAddressTypePhysical() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            List<String> stateDropdownList = new ArrayList<>(patientMaintenancePage.selectResidenceTypeDropdownValues());
            List<String> stateDropdownValues = new ArrayList<>(stateDropdownList);
            Collections.sort(stateDropdownValues);
        } catch (Exception e) {

            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void selectCountryStateDropdown(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.log("US country is selected");
            patientMaintenancePage.selectCountry(inputData.get("COUNTRY"));
            List<String> usCountryStateDropdownList = new ArrayList<>(patientMaintenancePage.selectCountryStateDropdownValues());
            List<String> usCountryStateDropdownListValues = new ArrayList<>(usCountryStateDropdownList);
            Collections.sort(usCountryStateDropdownListValues);

            Reporter.log("PR country is selected");
            patientMaintenancePage.selectCountryOtherThanUS();
            List<String> prCountryStateDropdownList = new ArrayList<>(patientMaintenancePage.selectAnotherCountryStateDropdownValues());
            List<String> prCountryStateDropdownListValues = new ArrayList<>(prCountryStateDropdownList);
            Collections.sort(prCountryStateDropdownListValues);
            Reporter.log("MX country is selected");
            patientMaintenancePage.selectCountryOtherThanUS();
            List<String> mxCountryStateDropdownList = new ArrayList<>(patientMaintenancePage.selectAnotherCountryStateDropdownValues());
            List<String> mxCountryStateDropdownListValues = new ArrayList<>(mxCountryStateDropdownList);
            Collections.sort(mxCountryStateDropdownListValues);
            Reporter.log("CA country is selected");
            patientMaintenancePage.selectCountryOtherThanUS();
            List<String> caCountryStateDropdownList = new ArrayList<>(patientMaintenancePage.selectAnotherCountryStateDropdownValues());
            List<String> caCountryStateDropdownListValues = new ArrayList<>(caCountryStateDropdownList);
            Collections.sort(caCountryStateDropdownListValues);

        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void selectResidenceTypeAddressTypePhysical() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            List<String> residenceTypeDropdownList = new ArrayList<>(patientMaintenancePage.selectResidenceTypeDropdownValues());
            List<String> residenceTypeDropdownValues = new ArrayList<>(residenceTypeDropdownList);
            Collections.sort(residenceTypeDropdownValues);
        } catch (Throwable e) {

            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void selectResidenceTypeAddressTypeMailing() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            List<String> residenceTypeDropdownList = new ArrayList<>(patientMaintenancePage.selectResidenceTypeAddressTypeMailing());
            List<String> residenceTypeDropdownValues = new ArrayList<>(residenceTypeDropdownList);
            Collections.sort(residenceTypeDropdownValues);
        } catch (Throwable e) {

            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }

    public void selectResidenceTypeAddressTypeTemp() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            List<String> residenceTypeDropdownList = new ArrayList<>(patientMaintenancePage.selectResidenceTypeAddressTypeTemp());
            List<String> residenceTypeDropdownValues = new ArrayList<>(residenceTypeDropdownList);
            Collections.sort(residenceTypeDropdownValues);
        } catch (Throwable e) {

            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * method clicks on 'ok' or 'save entered' button present on auto populated address pop up
     *
     * Author: Lakshmi Priya (vn510nm)
     * */
    public void saveEnteredAddressForPatientMaintenance() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (patientMaintenancePage.isSaveAsEnteredDisplayed()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.clickSaveAsEntered();
                Reporter.log("The address is saved for validated zip code");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * The below method looks for the zipcode validation service downtime
     * other wise click on the state PR to validate address
     *
     * Author: Lakshmi Priya (vn510nm)
     * */
    public void validateZipCode(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.sendHotKeys(Keys.TAB);
            patientMaintenancePage.switchWindow();
            if (patientMaintenancePage.isOkDisplayed()) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.clickOk();
                Reporter.log("On Selecting Zip code City and State arent auto populated and validation service found to be down");
            } else {
                patientMaintenancePage.switchWindow();
                //The below method clicks the state drop down, and entered Zip code is validated for country 'PR'
                patientMaintenancePage.selectState(inputData.get("NEW_STATE"));
                Reporter.log("User is able to provide Zip code for the country MEXICO");
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To select patient type as Pet of patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void selectingPatientTypePetDropOffQueue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.selectPatientType(PatientProfileModel.PatientType.PET);
            Reporter.log("Patient Type is Selected as PET");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();
        } catch (Throwable e) {

            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To select patient type as Livestock of patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void selectingPatientTypeLivestockDropOffQueue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.selectPatientType(PatientProfileModel.PatientType.LIVESTOCK);
            Reporter.log("Patient Type is Selected as LIVESTOCK");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();
        } catch (Throwable e) {


            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To Select the patient gender as male in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void selectingPatientGenderMale() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            patientMaintenancePage.isMaleRadioButtonEnabled();
            Reporter.log("Patient Male Gender is Enabled ");
            patientMaintenancePage.selectGender(PatientProfileModel.PatientGender.MALE);
            Reporter.log("Patient Gender Male is Selected  ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To Select the patient gender as female in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void selectingPatientGenderFemale() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            patientMaintenancePage.isFemaleRadioButtonEnabled();
            Reporter.log("Patient Female Gender is Enabled ");
            patientMaintenancePage.selectGender(PatientProfileModel.PatientGender.FEMALE);
            Reporter.log("Patient Gender Female is Selected  ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {


            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To Select the patient Status from dropdown in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void verifyPatientActiveStatus(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            patientMaintenancePage.inputPatientStatus(inputData.get("STATUS"));
            Reporter.log("Patient Status is Enabled ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyPatientDeceasedStatus(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            patientMaintenancePage.inputPatientStatus(inputData.get("STATUS1"));
            Reporter.log("Patient Status is Enabled ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {


            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To change the patient first line address in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void editingPhysicalAddressFirstLine(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            patientMaintenancePage.isAddressDetailsEnabled();
            patientMaintenancePage.inputAddressLine1(inputData.get("ADDRESS"));
            Reporter.log("Patient Address details is Filled ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To select the patient country in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void editCountry(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            patientMaintenancePage.selectCountry(inputData.get("COUNTRY"));
            Reporter.log("Patient COUNTRY is Filled ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To select patient type as Human of patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void selectingPatientTypeHumanDropOffQueue(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickDropOffQueue();
            if (!orderSearch.isDropOffDisplayed()) {
                Reporter.logScreenShot(currentStepMethodName, "DropOff page - failed to load");
            }
            Reporter.log("Search for Patient");
            dropOffPage.switchWindow();
            dropOffPage.enterPatientName(inputData.get("PATIENT_NAME"));
            dropOffPage.clickPatientSearch();
            patientSearchPage.inputPatientDob(inputData.get("DOB"));
            patientSearchPage.inputPatientPhone(inputData.get("PHONE_NUMBER1"));
            patientSearchPage.inputPatientZip(inputData.get("ZIP_CODE"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickSearchNow();
            patientSearchPage.hostSearchPatient();
            patientSearchPage.clickNew();
            patientMaintenancePage.selectPatientType(PatientProfileModel.PatientType.HUMAN);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Patient Type is Selected as HUMAN");
            patientMaintenancePage.isFirstNameEnabled();
            Reporter.log("Patient Profile is Editable ");
        } catch (Throwable e) {

            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterPatientDetailsDropOffQueue(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickDropOffQueue();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Search for Patient");
            dropOffPage.switchWindow();
            dropOffPage.enterPatientName(inputData.get("PATIENT_NAME"));
            dropOffPage.clickPatientSearch();
            patientSearchPage.inputPatientDob(inputData.get("DOB"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickSearchNow();
            patientSearchPage.hostSearchPatient();
            patientSearchPage.clickNew();
            patientMaintenancePage.selectPatientType(PatientProfileModel.PatientType.HUMAN);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Patient Type is Selected as HUMAN");
            patientMaintenancePage.isFirstNameEnabled();
            Reporter.log("Patient Profile is Editable ");
        } catch (Throwable e) {

            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To change the last name of patient in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void editingLastName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.selectPatientType(PatientProfileModel.PatientType.HUMAN);
            Reporter.log("Patient Type is Selected as Human");
            patientMaintenancePage.isLastNameEnabled();
            Reporter.log("Patient Last Name is Enabled ");
            patientMaintenancePage.inputLastName(inputData.get("PATIENT_LAST_NAME"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Patient Last Name is Edited ");
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To change the First name of patient in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void editingFirstName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            patientMaintenancePage.isFirstNameEnabled();
            Reporter.log("Patient FIRST Name is Enabled ");
            patientMaintenancePage.inputFirstName(inputData.get("PATIENT_FIRST_NAME"));
            Reporter.log("Patient FIRST Name is Edited ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To change the middle name of patient in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void editingMiddleName(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            patientMaintenancePage.isMiddleNmaeEnabled();
            Reporter.log("Patient MIDDLE Name is Enabled ");
            patientMaintenancePage.inputPatientMiddleName(inputData.get("PATIENT_NAME"));
            Reporter.log("Patient MIDDLE Name is Edited ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {


            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To change the date of birth of patient in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void editingDOB() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {

            patientMaintenancePage.modifyBirthDateField(1);
            Reporter.log("Patient DOB is Edited ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To click on the twincheckbox in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void validateTwinCheckBox() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.isTwinCheckBoxEnabled();
            patientMaintenancePage.checkTwincheckbox();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To modify the date of birth for changing weight in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void editingWeightField() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            Date today = new Date();
            String formattedDate = sdf.format(today);
            patientMaintenancePage.clearDobField();
            patientMaintenancePage.inputDOB(formattedDate);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {


            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To click on the weight field and change weight in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void verifyWeightField(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.isWeightEnabled();
            patientMaintenancePage.inputWeight(inputData.get("WEIGHT"));
            patientMaintenancePage.clearWeight();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To select the patient city with country in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void editStateWithCountry(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            patientMaintenancePage.selectState(inputData.get("STATE"));
            Reporter.log("Patient State is Filled ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To select the patient city in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void editCity(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            patientMaintenancePage.inputCity(inputData.get("CITY"));
            Reporter.log("Patient City is Filled ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To change the patient second line address in patient maintenance page
     *
     * Author: Kandarbha Trivedi(vn51eqd)
     * */
    public void editingPhysicalAddressSecondLine(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            patientMaintenancePage.isAddressDetailsEnabled();
            patientMaintenancePage.inputAddressLine2(inputData.get("ADDRESS"));
            Reporter.log("Patient Address details is Filled ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To click on the temporary address tab patient maintenance page
     *
     * Author: Sugapriya S(vn510of)
     * */
    public void clickOnTemporaryAddressTab() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickTemporaryAddressTab();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {

            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickOnFacilityAddressTab() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickFacilityAddressTab();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {

            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To enter the address  on the temporary address tab  of patient maintenance page
     *
     * Author: Sugapriya S(vn510of)
     * */
    public void enterTemporaryAddressDetails(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.inputAddressLine1(inputData.get("ADDRESS"));
            patientMaintenancePage.inputCity(inputData.get("CITY"));
            patientMaintenancePage.ZipCode(inputData.get("ZIP_CODE"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * To select state from drop down of patient maintenance page according to the address type
     * Author: Srinivas(vn50jui)
     */
    public void selectStateInPTMSBasedOnAddressType(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickAddressTab(inputData.get("ADDRESS_TYPE"));
            //The below condition is to handle address validation popup for the state PR.
            if ("PR".equalsIgnoreCase(inputData.get("NEW_STATE"))) {
                patientMaintenancePage.sendHotKeys(Keys.TAB);
                if (patientMaintenancePage.isAsEnteredDisplayed()) {
                    patientMaintenancePage.selectAsEnteredRadioButtonAndClickOkOnAddressValidation();
                }
            }
            patientMaintenancePage.selectState(inputData.get("NEW_STATE"));
            Assert.assertEquals(patientMaintenancePage.getStateText(), inputData.get("NEW_STATE"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * To click on Save & Close button in PTMS screen and handle Address Validation popup
     * Author: Srinivas(vn50jui)
     */
    public void clickSaveAndCloseInPTMSAndHandleAddressValidation(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickSaveAndClose();
            automationManager.performSleep(2);
            if ("US".equalsIgnoreCase(inputData.get("COUNTRY"))) {
                if (patientMaintenancePage.isAsEnteredDisplayed()) {
                    patientMaintenancePage.selectAsEnteredRadioButtonAndClickOkOnAddressValidation();
                    automationManager.performSleep(4);
                }
                if (patientMaintenancePage.isSaveAsEnteredDisplayed()) {
                    patientMaintenancePage.clickSaveAsEntered();
                    automationManager.performSleep(4);
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To navigate to different address tab in patient maintenance page
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void navigateDifferentAddressTabInPTMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickAddressTab(inputData.get("ADDRESS_TAB"));
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To fill all the details in address tab in patient maintenance page
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void fillRequiredAddressFieldsInPTMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if ("Facility".equalsIgnoreCase(inputData.get("ADDRESS_TAB"))) {
                patientMaintenancePage.inputFacilityNameAndID(inputData.get("FACILITY_NAME"), inputData.get("FACILITY_ID"));
            }
            patientMaintenancePage.inputAddressLine1(inputData.get("ADDRESS"));
            patientMaintenancePage.clearZipCode();
            patientMaintenancePage.ZipCode(inputData.get("NEW_ZIP_CODE"));
            patientMaintenancePage.sendHotKeys(Keys.TAB);
            automationManager.performSleep(2);
            patientMaintenancePage.switchWindow();
            automationManager.performSleep(2);
            patientMaintenancePage.switchWindow();
            if (patientMaintenancePage.isOkDisplayed()) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.clickOk();
                Reporter.log("On Selecting Zip code City and State arent auto populated and validation service found to be down");
                patientMaintenancePage.inputCity(patient.getPatientAddress().getPatientCity());
                patientMaintenancePage.selectCountry(patient.getPatientAddress().getPatientCountry());
                patientMaintenancePage.selectState(patient.getPatientAddress().getPatientState());
            }
            Reporter.log("Updated required details in selected address tab");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To update city in patient maintenance page
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void updateCityInPTMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.inputCity(inputData.get("NEW_CITY"));
            Assert.assertEquals(patientMaintenancePage.getCityText(), inputData.get("NEW_CITY"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickOnMailingAddressTab() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickMailingAddressTab();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {

            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To navigate to Mailing address tab in patient maintenance page
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void validateAutoPopulateAddressInPTMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertEquals(patientMaintenancePage.getStateText(), inputData.get("NEW_STATE"));
            Assert.assertEquals(patientMaintenancePage.getCityText(), inputData.get("NEW_CITY"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To click CMS Part D Qualifier Facility in patient maintenance page
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void clickCMSPartDQualifierFacilityCheckbox() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickchkCMSPartDFacility();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To click Exit and cancel the changes in patient maintenance page
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void clickExitWithoutSavingChanges() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * To clear zip code in patient maintenance page
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void clearZipCodeinPTMS() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clearZipCode();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * to launch tasco Pseudophedrine screen
     *
     * Author: Nagarjuna Sankarasetty(vn575ve)
     * */
    public void launchTascoPseudophedrineScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            tascoPage.launchTascoScreen();
            Reporter.logScreenShot(Status.PASS, "Launched Tasco Screen", tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.launchTascoPseudophedrineScreen();
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_ENTER);
            robot.keyPress(KeyEvent.VK_DOWN);
            robot.keyRelease(KeyEvent.VK_ENTER);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Tasco Pseudophedrine screen launched");
            tascoPage.clickSubmitIDDetails();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Tasco PSE screen not launched");
        }
    }

    /*
     * Validated Age restriction pop up message.
     *
     * Author: Nagarjuna Sankarasetty(vn575ve)
     * */
    public void validateAgeRestrictionErrorText(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(inputData.get("VALIDATION_TEXT"), tascoPage.getAgeValidationText(), "Age restriction pop up message not matching");
            Reporter.log(tascoPage.getAgeValidationText());
            tascoPage.clickBtnOK();
            tascoPage.clickCancelPayCashPrice();
            tascoPage.clickExitInTasco();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Tasco PSE screen not launched");
        }
    }

    /*
     * Validated Age restriction pop up message.
     *
     * Author: Nagarjuna Sankarasetty(vn575ve)
     * */
    public void validateAgeRestrictionErrorTextInPMSScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickSaveAndClose();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(inputData.get("VALIDATION_TEXT"), patientMaintenancePage.getDOBErrorText(), "Age restriction pop up message not matching");
            Reporter.log(patientMaintenancePage.getDOBErrorText());
            patientSearchPage.clickasEnteredOK();
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();
            patientSearchPage.clickClose();
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail("PMS screen not launched");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Enter the patient details tasco Pseudophedrine screen and click on Accept button.
     *
     * Author: Nagarjuna Sankarasetty(vn575ve)
     * */
    public void enterPatientDetailsInPseudoephedrineScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            tascoPage.inputPatientLastName(inputData.get("PATIENT_LAST_NAME"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(inputData.get("PATIENT_FIRST_NAME"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientDobPseudoPherderine(inputData.get("DOB"));
            tascoPage.enterAddress(inputData.get("ADDRESS"));
            tascoPage.enterCity(inputData.get("CITY"));
            tascoPage.entryState(inputData.get("STATE"));
            tascoPage.enterZipCode(inputData.get("ZIP_CODE"));
            tascoPage.enterIdNumber(connexusAppUtils.randomName());
            tascoPage.clickNoExpiration();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.clickAccept();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Tasco PSE screen not launched");
        }
    }

    /*
     * Validate TP card details PTMS screen.
     *
     * */
    public void validateCardDetailsInPTMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            patientSearchPage.doubleClickOnSearchGridRow(0);
            Assert.assertEquals(patientMaintenancePage.getCardIDInPTMSScreen(), inputData.get("TP_CARD_ID"), "Card details are not matching in PMS screen");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(patientMaintenancePage.getCardDetailsFromThirdPartyEdit(), inputData.get("TP_CARD_ID"), "Card details are not matching in TP Edit screen");
            Reporter.logScreenShot(Status.PASS, "ValidateCardIDInTPEditPage", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickbtnAcceptOnThirdPartyEdit();
            connexusStartPage.pressEscapeKey();
            connexusStartPage.pressEscapeKey();
        } catch (Throwable e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Card details are missing");
        }
    }

    /**
     * Validating check eligibility button in PTMS screen.
     */
    public void validateCheckEligibilityButtonInPTMSScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(inputData.get("PATIENT_LAST_NAME") + "," + inputData.get("PATIENT_FIRST_NAME"));
            patientSearchPage.clickSearchNow();
            Reporter.logScreenShot(Status.PASS, "Searching Patient Details", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.doubleClickOnSearchGridRow(0);
            Assert.assertTrue(patientMaintenancePage.isElementDisplayed(patientMaintenancePage.chk_Eligible_Button, 30));
            Reporter.log("Check Eligibility button Displayed");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            Assert.fail("Check Eligibility Button is  missing");
        }
    }


    /*-----------------------------------------------
     * This Method will get and validate the Card details from Drop Off page
     * ----------------------------------------------------------------------*/
    public void validateCardDetailsFromDropoffPage(Map<String, String> inputdata) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            Assert.assertEquals(dropOffPage.getCardDetails(), inputdata.get("TP_CARD_ID"), "Card details are not matching in Drop off page");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            connexusStartPage.pressEscapeKey();
            connexusStartPage.pressEscapeKey();
            dropOffPage.clickYesInPopUp();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Card details are not matching in Drop off page");
        }
    }

    /**
     * Validating TP card details in Claim detail page.
     */
    public void validateCardDetailsInClaimPage(Map<String, String> inputdata) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            claimPage.launchClaimPage();
            claimPage.performClaimSearch(name[0] + "," + name[1]);
            patientSearchPage.openFirstPatientRecord();
            Assert.assertEquals(claimPage.getCardDetails(), inputdata.get("TP_CARD_ID"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.clickCancel();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Claim details page not opened");
        }
    }

    /*
     * Validating Plan details in Eligibilty Check pop up.
     *
     * */
    public void validatePlanDetailsByClickingOnCheckEligibilityButton(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickEligibilityButton();
            if (patientMaintenancePage.isElementDisplayed(patientMaintenancePage.eligibility_Plan_Dropdown, 30)) {
                String expctedPlanDropdownList = inputData.get("PLAN_VALUES");
                List<String> planValues = new ArrayList<>(Arrays.asList(expctedPlanDropdownList.split(",")));
                List<String> ExpectedPlanValues = patientMaintenancePage.getPlanDropdownValues();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Plan Values" + planValues);
                ExpectedPlanValues.contains(planValues);
                patientMaintenancePage.clickExit();
            } else {
                Assert.fail("Eligibility plan dropdown not displayed.");
            }
        } catch (Throwable e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
    }

    /*
     * Validating TP Response view by selecting Medicare D eligibility plan.
     *
     * */
    public void validateTpResponseViewBySelectingMedicareD() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickEligibilityButton();
            patientMaintenancePage.clickYes();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSubmitButtonEligibilityCheckPopUp();
            if (patientMaintenancePage.isElementDisplayed(patientMaintenancePage.btnAddMedication, 30)) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("TP response view displayed with TP data");
                Assert.assertTrue(true, "TP response details displayed");
            } else {
                Assert.fail("TP response details not displayed");
            }
        } catch (Throwable e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * Validate TP details added to the patient profile.
     */
    public void validateAddedTPDetailsINPatientProfile(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickAddMedicationButton();
            patientMaintenancePage.isElementDisplayed(patientMaintenancePage.cmbPlan, 30);
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_DOWN);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_DOWN);
            robot.keyRelease(KeyEvent.VK_ENTER);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickbtnAcceptOnThirdPartyEdit();
            Assert.assertEquals(patientMaintenancePage.getTextFromTPEligibilityResponseAdditionPopUup(), inputData.get("TP_VALIDATION_MESSAGE"), "TP Eligibility response addition pop up message not matching");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickOk();
            connexusStartPage.pressEscapeKey();
            patientMaintenancePage.clickYes();
            connexusStartPage.pressEscapeKey();
        } catch (Throwable e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            Assert.fail("Third Party Response window not opening");
        }
    }


    /**
     * Validating TP Response view by selecting commercial check eligibility plan.
     */
    public void validateTpResponseViewBySelectingCommercialPlan() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickEligibilityButton();
            patientMaintenancePage.clickYes();
            patientMaintenancePage.click(patientMaintenancePage.eligibility_Plan_Dropdown);
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_DOWN);
            robot.keyRelease(KeyEvent.VK_DOWN);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSubmitButtonEligibilityCheckPopUp();
            if (patientMaintenancePage.isElementDisplayed(patientMaintenancePage.btnAddMedication, 30)) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("TP response view displayed with TP data");
                Assert.assertTrue(true, "TP response details displayed");
            } else {
                Assert.fail("TP response details not displayed");
            }
        } catch (Throwable e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * Launch and validate Check Eligibility button in PTMS screen
     */
    public void launchAndValidateCheckEligibilityButtonInPTMSScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.clickSearchNow();
            Reporter.logScreenShot(Status.PASS, "Searching Patient Details", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientSearchPage.doubleClickOnSearchGridRow(0);
            Assert.assertTrue(patientMaintenancePage.isElementDisplayed(patientMaintenancePage.chk_Eligible_Button, 30));
            Reporter.log("Check Eligibility button Displayed");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Check Eligibility Button is  missing");
        }
    }

    /**
     * Validate Invalid SSN message in Eligibility plan pop up.
     *
     * @param inputData
     */
    public void validateInvalidSSNMessageByProvidingInvalidSSNDetailsForMedicareBCheckElegibilityPlan(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickEligibilityButton();
            patientMaintenancePage.clickYes();
            Robot robot = new Robot();
            for (int i = 0; i < 3; i++) {
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSubmitButtonEligibilityCheckPopUp();
            patientMaintenancePage.EnterLast4DigitSSNNumber(inputData.get("SSN"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickbtnAcceptOnThirdPartyEdit();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(patientMaintenancePage.getInvalidSsnPopupText(), inputData.get("VALIDATION_TEXT"), "SSN validation message is not matching.");
            patientMaintenancePage.clickOk();
            connexusStartPage.pressEscapeKey();
            connexusStartPage.pressEscapeKey();
            patientMaintenancePage.clickExit();
        } catch (Throwable e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * Validate invalid SSN message in PTMS screen by providing SSN as 0000
     *
     * @param inputData
     */
    public void validateInvalidSSNfromPTMSscreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.enterSsnInPTMS(inputData.get("SSN"));
            patientMaintenancePage.clickEligibilityButton();
            patientMaintenancePage.clickYes();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(patientMaintenancePage.getInvalidSsnPopupText(), inputData.get("VALIDATE_SSN_MESSAGE"), "SSN validation message is not matching");
            patientMaintenancePage.clickOk();
            patientMaintenancePage.clearSsnText();
        } catch (Throwable e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * Validating Patient Eligibilty error message by providing invalid ssn number in PTMS screen.
     *
     * @param inputData
     */
    public void validatePatientEligibilityErrorMessageByProvidingInvalidSsnNumber(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.enterSsnInPTMS(inputData.get("SSN_2"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickEligibilityButton();
            patientMaintenancePage.clickYes();
            Robot robot = new Robot();
            for (int i = 0; i < 3; i++) {
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            patientMaintenancePage.clickSubmitButtonEligibilityCheckPopUp();
            patientMaintenancePage.clickPopUpTextMessage();
            Assert.assertEquals(patientMaintenancePage.getInvalidSsnPopupText(), inputData.get("PATIENT_ELIGIBILITY_ERROR"), "SSN validation message is not matching.");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickOk();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * Validate TP response view screen by Providing Valid SSN number for Medicare B check eligibility plan
     *
     * @param inputData
     */
    public void
    ValidateTpResponseViewByProvidingValidSsnNumberinPTMSScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clearSsnText();
            patientMaintenancePage.enterSsnInPTMS(inputData.get("SSN_3"));
            patientMaintenancePage.clickEligibilityButton();
            patientMaintenancePage.clickYes();
            Robot robot = new Robot();
            for (int i = 0; i < 3; i++) {
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSubmitButtonEligibilityCheckPopUp();
            if (patientMaintenancePage.isElementDisplayed(patientMaintenancePage.btnAddMedication, 30)) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("TP response view displayed with TP data");
                Assert.assertTrue(true, "TP response details displayed");
            } else {
                Assert.fail("TP response details not displayed");
            }
        } catch (Throwable e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * Validate TP details added to the patient profile.
     */
    public void validateAddedTPDetailsInPatientProfileForMedicareB(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientMaintenancePage.clickAddMedicationButton();
            patientMaintenancePage.isElementDisplayed(patientMaintenancePage.cmbPlan, 30);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickbtnAcceptOnThirdPartyEdit();
            Assert.assertEquals(patientMaintenancePage.getTextFromTPEligibilityResponseAdditionPopUup(), inputData.get("TP_VALIDATION_MESSAGE"), "TP Eligibility response addition pop up message not matching");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickOk();
            connexusStartPage.pressEscapeKey();
            patientMaintenancePage.clickYes();
            connexusStartPage.pressEscapeKey();
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();
        } catch (Throwable e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Third Party Response window not opening");
        }
    }


    /**
     * Checking TP plan details in modify details screen.
     *
     * @param workQueueName
     */
    public void checkTpDetails(WorkQueue workQueueName, Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            boolean isInWorkQueue = false;
            for (int k = 0; k < 4; k++) {
                String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
                if (rxStatus.equalsIgnoreCase(workQueueName.getWorkQueue())) {
                    isInWorkQueue = true;
                    Assert.assertTrue(true);
                    Reporter.log("RX is in " + workQueueName + " queue");
                    orderSearch.launchOrderSearchScreen();
                    orderSearch.performSearch(name[0] + "," + name[1]);
                    orderSearch.openFirstPatientRecord();
                    if (!orderSearch.isCancelDisplayed()) {
                        Reporter.logScreenShot(currentStepMethodName, "Page Displayed");
                    }
                    modifyDetails.getTheTPDetails(Integer.parseInt(inputData.get("TP_COUNT")));
                    patientSearchPage.clickCancel();
                    patientSearchPage.clickYes();
                    break;
                } else if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                    super.performChkDUR();
                }
            }
            if (!isInWorkQueue) {
                Reporter.log("WorkQueue didn't moved to  " + workQueueName);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("TP details are missing and rx number number not in desired work queue" + workQueueName);
        }
    }

    /**
     * This Method will enter the group id and then will close the PTMS
     */
    public void enterInsuranceGroupIdInPTMSScreen(String groupId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            launchPatientMaintenancePage();
            patientMaintenancePage.sendTextInGroupIdField(groupId);
            patientMaintenancePage.clickSaveAndClose();
            Reporter.log("Group Id " + groupId + "Entered");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * This Method will remove the group id and then will close the PTMS
     */
    public void removeInsuranceGroupIdInPTMSScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            launchPatientMaintenancePage();
            patientMaintenancePage.clearTextInGroupIdField();
            Reporter.log("Group Id cleared");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * This Method will get the Catagory Name and assert it with expected value
     *
     * @param catagoryName
     */
    public void validateCatagoryNameInPTMSScreen(String catagoryName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            launchPatientMaintenancePage();
            Assert.assertEquals(patientMaintenancePage.getTextFromTpCatagory().trim(), catagoryName.trim());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickbtnTPOnThirdPartyInformation();
            Assert.assertEquals(patientMaintenancePage.getTextFromTpCatagoryFromTpEditScreen().trim(), catagoryName.trim());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickbtnEditTP();
            Assert.assertEquals(patientMaintenancePage.getTextFromTpCatagory().trim(), catagoryName.trim());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickbtnAcceptOnThirdPartyEdit();
            connexusStartPage.pressEscapeKey();
            connexusStartPage.pressEscapeKey();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Assertion failed");
        }
    }

    /**
     * This Method willValidate the category name in Four Point Screen
     *
     * @param catagoryName
     */
    public void validateCatagoryNameInFourPoint(String catagoryName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            for (int i = 0; i < 4; i++) {
                String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.FOUR_POINT.getWorkQueue())) {
                    Reporter.log("RX is in 4 Point queue");
                    patientSearchPage.launchOrderSearchScreen();
                    patientSearchPage.performSearch(name[0] + "," + name[1]);
                    patientSearchPage.openFirstPatientRecord();
                    fourPoint.launchModifyDetailScreenInFourPoint();
                    fourPoint.clickbtnThirdParty();
                    Assert.assertEquals(patientMaintenancePage.getTextFromTpCatagory().trim(), catagoryName.trim());
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
                    patientMaintenancePage.clickbtnAcceptOnThirdPartyEdit();
                    connexusStartPage.pressEscapeKey();
                    patientMaintenancePage.clickYes();
                    connexusStartPage.pressEscapeKey();
                    break;
                } else if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                    super.performChkDUR();
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Assertion failed");
        }

    }

    /**
     * This method will get plan code from DB and validate it against the given PlanCode
     *
     * @param inputData
     */
    public void ValidateInsurancePlanCodeInDB(Map<String, String> inputData) {
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            int planCode = connexusAppUtils.getInsurancePlanTypeCodeFromName(name[0].toUpperCase() + ", " + name[1].toUpperCase());
            Assert.assertEquals(planCode, Integer.parseInt(inputData.get("PLAN_CODE").trim()), "Record is Missing");
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Record is Missing");

        }
    }

    /**
     * This Method will remove the Group id in TP EDit Screen
     */
    public void removeGroupIdFromTpEditScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            launchPatientMaintenancePage();
            patientMaintenancePage.clickbtnTPOnThirdPartyInformation();
            patientMaintenancePage.clickbtnEditTP();
            patientMaintenancePage.clearTextInGroupIdField();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickbtnAcceptOnThirdPartyEdit();
            connexusStartPage.pressEscapeKey();
            connexusStartPage.pressEscapeKey();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Assertion failed");
        }
    }
//**     * This Method will select the category in Third Party Information

    public void CategorySelectinThirdyPartyInformation(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        SoftAssert softAssert = new SoftAssert();
        try {
            launchPatientMaintenancePage();
            String carrierBin = inputData.getOrDefault("TP_CARRIER_BIN_2", inputData.get("TP_CARRIER_BIN"));
            String plan = inputData.getOrDefault("TP_PLAN_2", inputData.get("TP_PLAN"));
            String cardId = inputData.getOrDefault("TP_CARD_ID_2", inputData.get("TP_CARD_ID"));

            if (patientMaintenancePage.isElementDisplayed(patientMaintenancePage.btnTPOnThirdPartyInformation)) {
                patientMaintenancePage.clickOnTPInfoBtn();
                patientMaintenancePage.isElementDisplayed(patientMaintenancePage.btnEditTP, 10);
                patientMaintenancePage.click(patientMaintenancePage.btnEditTP);
                patientMaintenancePage.isElementDisplayed(patientMaintenancePage.cmbCategoryOnThirdPartyEdit, 10);
                patientMaintenancePage.selectCategoryInThirdPartyEdit("Commercial");
                patientMaintenancePage.clickbtnAcceptOnThirdPartyEdit();
                patientMaintenancePage.isElementDisplayed(patientMaintenancePage.btnEditTP, 10);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + "CategorySelect", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
}




