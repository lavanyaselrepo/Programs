package connexus.uattest.testscripts;

import com.aventstack.extentreports.Status;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;


public class InputScreenUatTestScripts {

    SoftAssert softAssert = new SoftAssert();
    AutomationManager automationManager;
    LoginPage loginPage;
    InputPage inputPage;
    F6Search f6Search;
    ProductSearchPage productSearchPage;
    ProductMaintenancePage productMaintenancePage;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;
    ResolutionPage resolutionPage;
    private boolean dawCodeValueSetFlag;

    public void launchConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        inputPage = new InputPage();
        f6Search = new F6Search();
        productSearchPage = new ProductSearchPage();
        productMaintenancePage = new ProductMaintenancePage();
        automationManager = AutomationManager.getInstance();
        connexusAppUtils = new ConnexusAppUtils();
        connexusStartPage = new ConnexusStartPage();
        resolutionPage = new ResolutionPage();
    }

    public void loginConnexus(LoginAs.userType userType) {
        loginPage.loginConnexus(userType);
    }

    /*----------------------------------------------------------------------------------------------------------
     * The below method creates a new patient in the store
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void createPatient(Map<String, String> inputData) {
        PatientProfileModel patient = new PatientProfileModel();
        AddressModel addressModel = new AddressModel();
        ContactModel contactModel = new ContactModel();
        PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
        PatientIdentityModel patientIdentityModel = new PatientIdentityModel();

        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();

        patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
        patient.setPatientFirstName(name[1]);
        patient.setPatientLastName(name[0]);
        patient.setPatientDob(inputData.get("DOB"));
        patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

        addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
        addressModel.setPatientCity(inputData.get("CITY"));
        addressModel.setPatientState(inputData.get("STATE"));
        addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
        addressModel.setPatientCountry(inputData.get("COUNTRY"));

        patient.setPatientAddress(addressModel);

        contactModel.setPatientPhoneNumber1(inputData.get("PHONE_NUMBER1"));
        contactModel.setPatientPhoneNumber2(inputData.get("PHONE_NUMBER2"));
        contactModel.setPatientPhoneNumber3(inputData.get("PHONE_NUMBER3"));
        contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
        contactModel.setPreferredPhoneNumber(ContactModel.PreferredPhoneNumber.PHONE_NUMBER1);

        patient.setPatientContact(contactModel);

        patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
        patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
        patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));

        patient.setPatientIdentityModel(patientIdentityModel);

        patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
        patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);

        patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

        automationManager.getConnexusWorkFlow().searchAndCreatePatient(false, patient);
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method drops off rx in Connexus Application
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void dropAnRxInStore() {
        DropRxModel dropRxModel = new DropRxModel();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);
    }

    /*----------------------------------------------------------------------------------------------------------
     * This launches the first workqueue in order search
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void launchRxInWorkQueue() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            f6Search.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            f6Search.selectRowFromSearch(0);
            automationManager.performSleep(3);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on the prescribed product text box
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickOnPrescribedProductTextBox() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickOnPrescribedProductTextBox();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method enters the drug name in product text box and if product is present in product search page
     * it double click the product
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void enterDrugNameAndSearchProductScreen(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            if (productSearchPage.isProductSearchDisplayed()) {
                productSearchPage.doubleClickOnSearchGridRow(0);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clears the product name from prescribed product text box
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clearDrugNameInPrescribedProduct() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clearPrescribedProduct();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method enters the ndc number in prescribed product and press enter in enterNdc()
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void enterNdcNumberAndPressEnterInPrescribedProduct(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method enters the ndc number in prescribed product
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void enterNdcNumberInPrescribedProduct(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.inputPrescribedProduct(inputData.get("DRUG_NAME"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on product maintenance icon near prescribed product
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickOnProductMaintenanceIcon() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickProductMaintenanceIcon();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates the ndc number in db
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateNdcNumberFromDb(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Map<String, Object> drugNameFromDb = automationManager.getConnexusDB().executeQuery("select ndc_nbr, short_name from pharmacy_offering: pharmacy_product pp, pharmacy_offering: pharmacy_item pi \n" +
                    "where pp.product_mds_fam_id=pi.product_mds_fam_id and ndc_nbr=\"" + inputData.get("DRUG_NAME") + "\" ");
            String drugName = drugNameFromDb.get("short_name").toString().trim();
            Assert.assertEquals(drugName, inputPage.getTextPrescibedProduct());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on the 3 dots near the prescribed product text box
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void click3DotsButtonForPrescribedProduct() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickProductSearch3Dots();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method closes the product search window
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void closeProductSearch() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            productSearchPage.clickClose();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method verifies if the product maintenance page is appeared
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void verifyProductMaintenanceScreen() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            if (productMaintenancePage.isProductDescriptionDisplayed()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
            productMaintenancePage.clickAccept();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on the prescription bottle icon below the prescribed product
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickAndValidatePrescriptionBottleIcon() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            if (inputPage.isPrescriptionBottleIconEnabled()) {
                inputPage.clickPrescriptionBottleIcon();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.log("The prescription icon bottle below the prescribed product is disabled. Drug selection screen is not diplayed as the icon is not clickable");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates the prescribed quantity of drug accepts only 5 digit and not letters
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validatePrescribedDrugQuantity(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickPrescribedProductQty();
            if (Pattern.matches("\\d{1,5}", inputData.get("PRESCRIBED_QUANTITY"))) {
                inputPage.enterPrescribedQty(inputData.get("PRESCRIBED_QUANTITY"));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.log("Prescribed Drug Quantity does not allow any invalid characters(letters) other than numbers");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates the dispensed quantity of drug accepts only 5 digit and not letters
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateDispensedDrugQuantity(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickDispensedProductQty();
            // When prescribed qty is provided and on clicking dispensed qty, the prescribed qty is auto populated in 'dispensed qty' text box
            // clearing dispensed qty to validate step 4 in tc_136_Input_edit_dispQtyField
            inputPage.clearDispensedProductQty();
            if (Pattern.matches("\\d{1,5}", inputData.get("DISPENSE_QUANTITY"))) {
                inputPage.enterDispensedProductQty(inputData.get("DISPENSE_QUANTITY"));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.log("Dispensed Drug Quantity does not allow any invalid characters(letters) other than numbers");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates the no of supply days of drug accepts only 4 digit and not letters
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateNoOfDaysOfProductSupply(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickProductDaysSupply();
            // When prescribed qty is provided and on clicking No of days text box, the no of days is auto populated in 'days' text box
            // clearing value in 'days' text box to validate step 4 in tc_137_Input_edit_daysField
            inputPage.clearProductSupplyDays();
            if (Pattern.matches("\\d{1,3}", inputData.get("DAYS"))) {
                inputPage.enterProductSupplyDays(inputData.get("DAYS"));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.log("No of Days Text box does not allow any invalid characters(letters) other than numbers");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates the short sig given in (ex. 1QD, 1BID or 1TID) across db
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateSIGField(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickOnSigTextBox();
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.clickExpandedSigTextBox();
            String expandedSigDescription = inputPage.getExtendedSigDescription();
            Map<String, Object> sigExpansionDetailsFromDB = automationManager.getConnexusDB().executeQuery("select sig_compnt_desc from sig_component_txt where sig_compnt_abbr=\"" + inputData.get("SIG").substring(1) + "\" and language_code=101");
            String sigCodeExpansion = sigExpansionDetailsFromDB.get("sig_compnt_desc").toString().trim();
            if (expandedSigDescription.contains(sigCodeExpansion)) {
                Reporter.log("The expanded SIG description for the given short SIG 1QD is: " + expandedSigDescription);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates if the short sig given (ex. 1QD, 1BID or 1TID) in expanded sig changes to FF in input sig
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateExpandedSIGField(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String validSigValue = inputPage.getSigValueFromSigTextBox();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickExpandedSigTextBox();
            inputPage.inputExpandedSig(inputData.get("SIG"));
            String modifiedSigValue = inputPage.getSigValueFromSigTextBox();
            Assert.assertNotEquals(validSigValue, modifiedSigValue);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates if the refill allows only 2 digit values and not letters
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateProductRefill(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickProductRefillTextBox();
            if (Pattern.matches("\\d{1,2}", inputData.get("REFILLS"))) {
                inputPage.enterRefillQty(inputData.get("REFILLS"));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.log("Refill Quantity does not allow any invalid characters(letters) other than numbers");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method selects the daw code passed for the index 0 from 'DAW_CODE'
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void selectDawCodeDropDown(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.selectDAW(Integer.parseInt(inputData.get("DAW_CODE")));
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method select the daw code on input screen using down arrow
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void selectDawCodeUsingDownArrow() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.selectDawUsingDownArrow();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates the daw code drop down is having valid values given as in sheet for column "DAW_CODE"
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateDawOnInputScreen(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.getValueFromDAWDropDown().forEach(u -> {
                if (u.getText().contains(inputData.get("DAW_CODE"))) {
                    dawCodeValueSetFlag = true;
                }
            });
            if (dawCodeValueSetFlag) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method closes the input screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void closeInputScreen() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.exitInputScreen();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method gets the attending physician prescribers name from db and prescriber type should be nurse practitioner
     * and belong to state -IL. attendingPhysicianDetails list holds attending physicians first name, last name, DEA, NPI
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public List<String> getAttendingPhysicianDetails() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            //The below query gets the prescriber details (last name, first name and NPI) with nurse practitioner for the state IL
            Map<String, Object> attendingPhysicianPrescriberDetailsFromDb = automationManager.getConnexusDB().executeQuery("select p.prescriber_id, first_name, last_name, license_nbr from prescriber p, prescriber_degree pd, prescriber_license pl where p.prescriber_id=pd.prescriber_id \n" +
                    "and p.prescriber_id=pl.prescriber_id and pd.degree_code=403 and pl.license_type_code = 827 order by 1 desc limit 1");
            //The below query gets the prescriber details (dea license number) with nurse practitioner for the state IL
            Map<String, Object> attendingPhysicianPrescriberDeaFromDb = automationManager.getConnexusDB().executeQuery("select p.prescriber_id, first_name, last_name, license_nbr from prescriber p, prescriber_degree pd, prescriber_license pl where p.prescriber_id=pd.prescriber_id \n" +
                    "and p.prescriber_id=pl.prescriber_id and pd.degree_code=403 and pl.license_type_code = 800 order by 1 desc limit 1");
            String attendingPhysicianLastName = attendingPhysicianPrescriberDetailsFromDb.get("last_name").toString().trim();
            String attendingPhysicianFirstName = attendingPhysicianPrescriberDetailsFromDb.get("first_name").toString().trim();
            String attendingPhysicianNpiNumber = attendingPhysicianPrescriberDetailsFromDb.get("license_nbr").toString().trim();
            String attendingPhysicianDeaNumber = attendingPhysicianPrescriberDeaFromDb.get("license_nbr").toString().trim();
            //adding all the prescriber details to attendingPhysicianDetails list
            List<String> attendingPhysicianDetails = new ArrayList<>();
            attendingPhysicianDetails.add(attendingPhysicianLastName);
            attendingPhysicianDetails.add(attendingPhysicianFirstName);
            attendingPhysicianDetails.add(attendingPhysicianNpiNumber);
            attendingPhysicianDetails.add(attendingPhysicianDeaNumber);
            return attendingPhysicianDetails;
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return null;
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method enters the prescriber details(name/NPI/DEA) on the input screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void enterPrescriberDetails(Map<String, String> inputData, int action) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
            inputPage.clickPrescriberNameTextBox();
            switch (action) {
                //case 0 - Enters prescribers name as {First_name} space {last_name}
                case 0:
                    inputPage.inputPrescriberNameAndEnterTab(prescriberModel.getPrescriberFirstName() + " " + prescriberModel.getPrescriberLastName());
                    break;
                //case 1 - Enters prescribers name as {last_name} , {first_name}
                case 1:
                    inputPage.enterPrescriber(prescriberModel.getPrescriberLastName() + "," + prescriberModel.getPrescriberFirstName());
                    break;
                //case 2 - Enters prescribers NPI license value
                case 2:
                    inputPage.enterPrescriber(inputData.get("NPI"));
                    break;
                //case 3 - Enters prescribers DEA license value
                case 3:
                    inputPage.inputPrescriberNameAndEnterTab(inputData.get("DEA"));
                    break;
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates the prescriber details(name/NPI/DEA) over 'prescriber' tab on input screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validatePrescriberDetails(Map<String, String> inputData, int action) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
            switch (action) {
                //case 0 - validates prescribers name on input page
                case 0:
                    inputPage.getPrescriberName().contains(prescriberModel.getPrescriberLastName() + "," + prescriberModel.getPrescriberFirstName());
                    break;
                //case 1 - validates prescribers NPI license on input page
                case 1:
                    Assert.assertEquals(inputData.get("NPI"), inputPage.getPrescriberNPINumber());
                    break;
                //case 2 - validates prescribers DEA license on input page
                case 2:
                    Assert.assertEquals(inputData.get("DEA"), inputPage.getPrescriberDEANumber());
                    break;
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method enters the attending physician details in 'prescriber' tab and validates if 'attending physician' tab on input screen is enabled
     * Note: Prescriber type given on 'prescriber' tab on input screen should be only nurse practitioner and belong to state -IL.
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void enterPrescriberDetailsAndValidateAttendingPhysicianTab(List prescriberDetails) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.enterPrescriber(prescriberDetails.get(1).toString() + " " + prescriberDetails.get(0).toString());
            Assert.assertTrue(inputPage.isAttendingPhysicianTabEnabled());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method enters the attending physician prescribers name/NPI/DEA from prescriberDetails list into 'Attending Physician' tab
     * Note: Prescriber type should be nurse practitioner and belong to state -IL.
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void enterAttendingPhysicianDetails(List prescriberDetails, int action) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickAttendingPhysicianNameTextBox();
            switch (action) {
                //case 0 - Enters Attending Physician name as {First_name} space {last_name}
                case 0:
                    inputPage.enterAttendingPhysicianName(prescriberDetails.get(1).toString() + " " + prescriberDetails.get(0).toString());
                    break;
                //case 1 - Enters Attending Physician name as {last_name} , {first_name}
                case 1:
                    inputPage.enterAttendingPhysicianName(prescriberDetails.get(0).toString() + "," + prescriberDetails.get(1).toString());
                    break;
                //case 2 - Enters Attending Physician NPI license value
                case 2:
                    inputPage.enterAttendingPhysicianName(prescriberDetails.get(2).toString());
                    break;
                //case 3 - Enters Attending Physician DEA license
                case 3:
                    inputPage.enterAttendingPhysicianName(prescriberDetails.get(3).toString());
                    break;
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates attending physician prescribers name/NPI/DEA over 'attending physician' tab on input screen
     * Note: Prescriber type should be nurse practitioner and belong to state -IL.
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateAttendingPhysicianDetails(List prescriberDetails, int action) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            switch (action) {
                //case 0 - validates Attending Physician name on input screen
                case 0:
                    inputPage.getAttendingPhysicianName().contains(prescriberDetails.get(0) + "," + prescriberDetails.get(1));
                    break;
                //case 1 - validates attending physician NPI license value on input screen
                case 1:
                    Assert.assertEquals(prescriberDetails.get(2).toString(), inputPage.getAttendingPhysicianNpiValue());
                    break;
                //case 2 - validates attending physician DEA license value on input screen
                case 2:
                    //DEA number carries suffix '0' as the prescriber is permanent resident and stores in db with suffix excluding '-' in format 'BL98706220'.
                    //DEA in input page has '-' separating DEA and suffix value in format 'BL9870622-0'. Hence during validation, appending '-' for the parameter 1 in below line
                    Assert.assertEquals(prescriberDetails.get(3).toString().substring(0, 9) + "-" + prescriberDetails.get(3).toString().substring(9), inputPage.getAttendingPhysicianDeaValue());
                    break;
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clears prescribers name in input screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clearPrescriberNameOnInputScreen() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clearPrescriberName();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clears the prescriber details in attending physician tab and prescriber tab
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clearPrescriberAndAttendingPhysician() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clearAttendingPhysicianName();
            inputPage.clickPrescriberTab();
            inputPage.clearPrescriberName();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method enters the comments in Order comment and validates if the same comments is passed for all prescription
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateOrderCommentTextBox(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.inputTextInOrderCommentTextBox(inputData.get("ORDER_COMMENT"));
            inputPage.clickOnAddNewRxButton();
            // Validates if the order comments given in first rx is present in second rx
            Assert.assertEquals(inputData.get("ORDER_COMMENT"), inputPage.getTextFromOrderCommentTextBox());
            Reporter.log("The order comment is applied to all the prescriptions in the order");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method double clicks on the Rx image box in input screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void doubleClickOnRxImage() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            int counter = 0;
            do {
                inputPage.doubleClickOnRxImage();
                counter++;
            } while (inputPage.isMaximizeRxImageButtonEnabled() && counter <= 3);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method verifies if rx is in full screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateRxMaximizedToFullScreen() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertTrue(inputPage.isMinimizeRxImageButtonEnabled());
            Assert.assertFalse(inputPage.isMaximizeRxImageButtonEnabled());
            Reporter.log("The Rx Image on double clicking is maximized. On maximizing rx image to full screen, the maximize rx button is disabled and minimize rx button is enabled");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method exits from full screen rx scanned image in input page
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void exitFromFullScreenRxImage() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickOnMinimizeRxImageButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks and drags the rx image to enlarge the image
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickAndDragRxImageOnInputScreen() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickAndDragRxImage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates if the rx image is enlarged
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateRxImageBoxIsZoomedIn() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertTrue(inputPage.zoomRxImage());
            Reporter.log("The rx information on the rx image box is Zoomed IN");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on show order button on input page
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickShowOrderButton() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickShowOrderButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates the no of rx in show order pop up is same order
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public String validateRxCountOnShowOrderPopUp() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (connexusStartPage.getTextFromAppTitleBar(1).contains("Show Order")) {
                // The below query gets the no of rx and order id created  for the patient and validates across show order pop up in input screen
                Map<String, Object> rxOrderDetailsFromDb = automationManager.getConnexusDB().executeQuery("select count(order_id) as order_id_count, order_id from rx_order_detail where rx_id in(select rx_id from rx where patient_id=\n" +
                        "(select patient_id from patient where last_name=\"" + name[0] + "\" and first_name=\"" + name[1] + "\") \n" +
                        "and rx_written_date = today) group by order_id");
                String rxCountOfOrderFromDb = rxOrderDetailsFromDb.get("order_id_count").toString();
                String rxCountOfOrder = String.valueOf(inputPage.getRxCountFromShowOrderPopUp());
                Reporter.log("The no of rx in Show order pop up is " + rxCountOfOrder);
                Assert.assertEquals(rxCountOfOrderFromDb, rxCountOfOrder);
                String orderId = rxOrderDetailsFromDb.get("order_id").toString();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                return orderId;
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return null;
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates the current status of rx in show order pop up and datebase
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateRxStatusOnShowOrderPopUp(String orderId) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Reporter.log("All prescriptions are displayed in same order ID " + orderId);
            // The below query gets the current rx status and validates across show order pop up in input screem
            String currentRxStatus = inputPage.getRxStatusFromShowOrderPopUp(1);
            Map<String, Object> currentRxStatusDetailsFromDb = automationManager.getConnexusDB().executeQuery("select * from verif_rqst_stat_tx rs, rx_order_detail od \n" +
                    "where rs.rqst_stat_code=od.work_que_stat_code and order_id=" + orderId + " limit 1");
            String currentRxStatusFromDb = currentRxStatusDetailsFromDb.get("rqst_stat_desc").toString().trim();
            Assert.assertEquals(currentRxStatusFromDb, currentRxStatus);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method closes show order pop up on input screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void closeShowOrderPopUp() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickShowOrderCloseButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates if the rx count in 'no of rx' in input page is increased by 1 on clicking add rx button
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public int validateIncreasedPrescriptionCount() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String oldRxCountInorder = inputPage.getTextNoOfRxField();
            inputPage.clickAddRxButton();
            int calculatedRxCountInOrder = Integer.parseInt(oldRxCountInorder) + 1;
            int newRxCountInOrder = Integer.parseInt(inputPage.getTextNoOfRxField());
            Assert.assertEquals(calculatedRxCountInOrder, newRxCountInOrder);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            return newRxCountInOrder;
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return 0;
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on maximize rx image button on input page
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickOnMaximizeButton() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickMaximizeRxImageButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method if the rx image is maximized to full screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateRxImageIsMaximized() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertTrue(inputPage.isMinimizeRxImageButtonEnabled());
            Assert.assertFalse(inputPage.isMaximizeRxImageButtonEnabled());
            Reporter.log("The Rx Image on double clicking is maximized. On maximizing rx image to full screen, the maximize rx button is disabled and minimize rx button is enabled");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on rotate button on input page
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickOnRotateRxImageButton() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickRotateRxImage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to mark non automated scenarios
     *
     * Author: Lakshmi Priya (vn510nm)
     * */
    public void validateRxImageIsRotated() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        Reporter.log("The Rx image rotation could not be validated as the 'Rotation' attribute of the Rx Image element is not supported");
        Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on zoom in icon image on input screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickOnZoomInRxImageIcon() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickZoomInRxImage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on zoom out icon image on input screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickOnZoomOutRxImageIcon() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickZoomOutRxImage();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on Resolution Type (Illegible Image or Manual Resolution) and send the rx to resolution
     * screen for Contact Prescriber, Contact Customer, Manual Resolution Options
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickSendToResolutionButton(Map<String, String> inputData, int action) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            switch (action) {
                // sends rx to Illegible Resolution
                case 0:
                    inputPage.clickSendToResolution(inputData.get("RESOLUTION_TYPE"));
                    break;
                case 1:
                    inputPage.sendRxToManualResolution(inputData.get("RESOLUTION_TYPE"), InputPage.ManualResolutionType.CONTACT_PRESCRIBER);
                    break;
                case 2:
                    inputPage.sendRxToManualResolution(inputData.get("RESOLUTION_TYPE"), InputPage.ManualResolutionType.CONTACT_CUSTOMER);
                    break;
                case 3:
                    inputPage.sendRxToManualResolution(inputData.get("RESOLUTION_TYPE"), InputPage.ManualResolutionType.MANUAL_RESOLUTION);
                    break;
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates the zoom aspect ratio of the rx image; Formula: aspect ratio = (length/width)
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateZoomAspectOfRxImage() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            double rxImageWidth = Double.parseDouble(inputPage.getHorizontalAspectValueOfRxImage());
            double rxImageHeight = Double.parseDouble(inputPage.getVerticalAspectValueOfRxImage());
            double rxImageAspectRatio = rxImageWidth / rxImageHeight;
            int approximateAspectRatio = (int) Math.round(rxImageAspectRatio);
            Reporter.log("The zoom on the prescription image is increased or decreased by a factor " + rxImageAspectRatio + " approximately equals" + approximateAspectRatio);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates if the screen is on Resolution Page
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public boolean validateRxInResolutionPage(int action) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        boolean returnFlag = false;
        try {
            automationManager.performSleep(3);
            switch (action) {
                // validates if the screen is on Illegible Image Resolution Page
                case 0:
                    returnFlag = connexusStartPage.getTextFromTitleBar().contains(AppScreenTitles.ILLEGIBLE_IMAGE.getScreenTitle());
                    break;
                // validates if the screen is on Contact Prescriber Resolution Page
                case 1:
                    connexusStartPage.getTextFromTitleBar().contains(AppScreenTitles.CONTACT_PRESCRIBER_RESOLUTION.getScreenTitle());
                    break;
                // validates if the screen is on Contact Customer Resolution Page
                case 2:
                    connexusStartPage.getTextFromTitleBar().contains(AppScreenTitles.CONTACT_CUSTOMER_RESOLUTION.getScreenTitle());
                    break;
                // validates if the screen is on Manual Resolution Page
                case 3:
                    connexusStartPage.getTextFromTitleBar().contains(AppScreenTitles.MANUAL_RESOLUTION.getScreenTitle());
                    break;
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return returnFlag;
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method return the rx from Resolution page to input page for Illegible and Manual Resolution
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void returnRxToInputPage(boolean returnRxFlag) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            if (returnRxFlag) {
                resolutionPage.clickReadyToInput();
            } else {
                resolutionPage.clickProblemResolved();
            }
            automationManager.performSleep(3);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method validates if the screen has Rx Resolution Pop up
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void validateManualResolutionPopUp() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.switchWindow();
            //Rx Resolution Pop Up is has Manual Resolution
            if (connexusStartPage.getTextFromAppTitleBar(1).contains("RX Resolution")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
            inputPage.clickCancel();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method enters the drug details of the rx (drug name, prescribed quantity, sig, refill of rx)
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void enterDrugDetailsInRx(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("PRESCRIBED_QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.selectDAW(1);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method accept the input screen once all the drug and prescriber details are given
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void acceptInputForRx() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickAccept();
            automationManager.performSleep(3);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method clicks on cancel button on Input screen
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public void clickCancelButton() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickCancel();
            inputPage.clickYes();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
}
