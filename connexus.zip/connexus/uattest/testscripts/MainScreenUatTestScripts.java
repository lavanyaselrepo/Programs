package connexus.uattest.testscripts;

import com.aventstack.extentreports.Status;
import connexus.uattest.testcases.mainscreen.MainScreenUatTestSet15;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.Map;

import static connexus.e2e.testcases.E2E_TestCases.loginUser_Type;

/**
 * this class provides test case logics to the respective calling test steps
 *
 * @author Ashok(vn50h3h)
 */
public class MainScreenUatTestScripts {
    SoftAssert softAssert = new SoftAssert();
    ConnexusStartPage connexusStartPage;
    MenuBar menuBar;
    AutomationManager automationManager;
    F6Search orderSearch;
    PatientSearchPage patientSearchPage;
    LoginPage loginPage;
    TascoPage tascoPage;
    PropertyReader prop = PropertyReader.getInstance();
    Robot robot;
    int siteId;

    public MainScreenUatTestScripts() {
        prop.loadCustomProperties("config/connexus/");
    }

    /**
     * this method instantiate page objects and app session
     *
     * @param userType (HO, RPH, TECH)
     * @author Ashok(vn50h3h)
     */
    public void launchConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        tascoPage = new TascoPage();
        patientSearchPage= new PatientSearchPage();
        orderSearch = new F6Search();
        automationManager = AutomationManager.getInstance();
    }


    /**
     * this method completes app login
     *
     * @param userType (HO, RPH, TECH)
     * @author Ashok(vn50h3h)
     */
    public void loginConnexus(LoginAs.userType userType) {
        loginPage.loginConnexus(userType);
    }

    /**
     * a method click on drop off left bar icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickDropOffFromLeftBar() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.DROP_OFF_ICON);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.DROP_OFF_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Title not matching");
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on input left bar icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickInputFromLeftBar() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.INPUT_ICON);
            connexusStartPage.isAddressValidationViewPopupDisplayed();
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.INPUT_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.INPUT_ICON);
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Title not matching");
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickYes();
        } catch (Exception e) {
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method key presses for drop off and check respective screen launched or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void pressKeyboardShortCutToOpenDropOffScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.launchDropOfScreenUsingShortcut();
            Assert.assertTrue(orderSearch.isDropOffDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method navigates to drop off menu option
     *
     * @author Ashok(vn50h3h)
     */
    public void menuNavigationToOpenDropOffScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.DROP_OFF, AppMenuItemsIndex.WORKQUEUE_DROP_OFF,null,null);
            automationManager.performSleep(4);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.DROP_OFF_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Title not matching");
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * method to perform keyboard shortcut to open input screen
     *
     * @author Ashok(vn50h3h)
     */
    public void pressKeyboardShortCutToOpenInputScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.launchInputScreenUsingShortcut();
            connexusStartPage.isAddressValidationViewPopupDisplayed();
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.INPUT_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.INPUT_ICON);
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Title not matching");
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickYes();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on input quick access icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickQuickIconCheckForInput() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickQuickAccessIcon(ConnexusConstants.APP_CONSTANT_INPUT_QUICK_ACCESS_ICON);
            connexusStartPage.isAddressValidationViewPopupDisplayed();
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.INPUT_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.INPUT_ICON);
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Title not matching");
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickYes();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method navigates to input menu option
     *
     * @author Ashok(vn50h3h)
     */
    public void menuNavigationToOpenInputScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.INPUT, AppMenuItemsIndex.WORKQUEUE_INPUT,null,null);
            connexusStartPage.isAddressValidationViewPopupDisplayed();
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.INPUT_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.INPUT_ICON);
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Title not matching");
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickYes();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * method to perform keyboard shortcut to open resolution screen
     *
     * @author Ashok(vn50h3h)
     */
    public void pressKeyboardShortCutToOpenResolutionScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.launchResolutionScreenUsingShortcut();
            if (orderSearch.isResolutionPageDisplayed()) {
                Reporter.log("Screen title is :  "+connexusStartPage.getTextFromMainScreenTitleBar());
                Reporter.log("Expected string in screen title : "+LeftBarWorkQueues.RESOLUTION_ICON.getLeftBarWorkQueues());
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.launchResolutionScreenUsingShortcut();
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Title not matching");
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on resolution left bar icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickResolutionFromLeftBar() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.RESOLUTION_ICON);

            if (orderSearch.isResolutionPageDisplayed()) {
                Reporter.log("Screen title is :  "+connexusStartPage.getTextFromMainScreenTitleBar());
                Reporter.log("Expected string in screen title : "+LeftBarWorkQueues.RESOLUTION_ICON.getLeftBarWorkQueues());
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.RESOLUTION_ICON);
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Title not matching");
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on resolution quick access icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickQuickIconCheckForResolution() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickQuickAccessIcon(ConnexusConstants.APP_CONSTANT_RESOLUTION_QUICK_ACCESS_ICON);
            Reporter.log("Screen title is :  "+connexusStartPage.getTextFromMainScreenTitleBar());
            Reporter.log("Expected string in screen title : "+LeftBarWorkQueues.RESOLUTION_ICON.getLeftBarWorkQueues());
            if (orderSearch.isResolutionPageDisplayed()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Screen title is :  "+connexusStartPage.getTextFromMainScreenTitleBar());
                Reporter.log("Expected string in screen title : "+LeftBarWorkQueues.RESOLUTION_ICON.getLeftBarWorkQueues());
                connexusStartPage.clickQuickAccessIcon(ConnexusConstants.APP_CONSTANT_RESOLUTION_QUICK_ACCESS_ICON);
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method navigates to resolution menu option
     *
     * @author Ashok(vn50h3h)
     */
    public void menuNavigationToOpenResolutionScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.RESOLUTION,AppMenuItemsIndex.WORKQUEUE_RESOLUTION,null,null);

            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (orderSearch.isResolutionPageDisplayed()) {
                Reporter.log("Screen title is :  "+connexusStartPage.getTextFromMainScreenTitleBar());
                Reporter.log("Expected string in screen title : "+LeftBarWorkQueues.RESOLUTION_ICON.getLeftBarWorkQueues());
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.RESOLUTION_ICON);
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Title not matching");
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickYes();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method to mark the test as non automated one
     *
     * @author Ashok(vn50h3h)
     */
    public void nonAutomateScenario() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
    }

    /**
     * a method click on fax inbox left bar icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickActionItemFromLeftBarThenFaxInbox() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.ACTION_ITEM_ICON);
            connexusStartPage.selectActionItemMenu(AppMenu.FAX_INBOX);
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromAppTitleBar(0).contains("Incoming Fax")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on fax outbox left bar icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickActionItemFromLeftBarThenFaxOutbox() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.ACTION_ITEM_ICON);
            connexusStartPage.selectActionItemMenu(AppMenu.FAX_ERRORS);
            if (connexusStartPage.getTextFromAppTitleBar(0).contains("Outgoing Fax")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.clickOk();
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on tasks left bar icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickActionItemFromLeftBarThenTasks() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.ACTION_ITEM_ICON);
            connexusStartPage.selectActionItemMenu(AppMenu.TASKS);
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromAppTitleBar(0).contains("Tasks")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method navigates to fax inbox menu option
     *
     * @author Ashok(vn50h3h)
     */
    public void menuNavigationToOpenActionItemFaxInboxScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.navigateToMenu(AppMenu.FAX_INBOX);
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromAppTitleBar(0).contains("Incoming Fax")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * this method navigates to fax outbox menu option
     *
     * @author Ashok(vn50h3h)
     */
    public void menuNavigationToOpenActionItemFaxOutboxScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.navigateToMenu(AppMenu.FAX_OUTBOX);
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromAppTitleBar(0).contains("Outgoing Fax")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.clickOk();
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method navigates to tasks menu option
     *
     * @author Ashok(vn50h3h)
     */
    public void menuNavigationToOpenActionItemTasksScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.navigateToMenu(AppMenu.TASKS);
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromAppTitleBar(0).contains("Tasks")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * method to perform keyboard shortcut to open fax inbox screen
     *
     * @author Ashok(vn50h3h)
     */
    public void pressKeyboardShortCutToOpenActionItemFaxInboxScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.inputShortcutKeys(AppShortcuts.FAX_INBOX.getAppShortcuts());
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromAppTitleBar(0).contains("Incoming Fax")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * method to perform keyboard shortcut to open fax outbox screen
     *
     * @author Ashok(vn50h3h)
     */
    public void pressKeyboardShortCutToOpenActionItemFaxOutboxScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.inputShortcutKeys(AppShortcuts.FAX_OUTBOX.getAppShortcuts());
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromAppTitleBar(0).contains("Outgoing Fax")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.clickOk();
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * method to perform keyboard shortcut to open item task screen
     *
     * @author Ashok(vn50h3h)
     */
    public void pressKeyboardShortCutToOpenActionItemTasksScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.inputShortcutKeys(AppShortcuts.TASKS.getAppShortcuts());
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromAppTitleBar(0).contains("Tasks")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on 4 point left bar icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void click4PointFromLeftBarAsRph() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.FOUR_POINT_ICON);
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.FOUR_POINT_ICON.getLeftBarWorkQueues()) ||
                    connexusStartPage.getTextFromTitleBar().contains("Check DUR")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on counseling left bar icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickCounselingFromLeftBarAsRph() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.COUNSELING_ICON);
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.COUNSELING_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on 4 point quick access icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickQuickIconCheckFor4PointAsRph() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickQuickAccessIcon(ConnexusConstants.APP_CONSTANT_4POINT_QUICK_ACCESS_ICON);
            automationManager.performSleep(4);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.FOUR_POINT_ICON.getLeftBarWorkQueues()) ||
                    connexusStartPage.getTextFromTitleBar().contains("Check DUR")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on visual verify quick access icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickQuickIconCheckForVisualVerifyAsRph() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickQuickAccessIcon(ConnexusConstants.APP_CONSTANT_VISUALLYVERIFY_QUICK_ACCESS_ICON);
            automationManager.performSleep(4);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                if (connexusStartPage.getTextFromAppTitleBar(1).contains("Visual Verify")) {
                    Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.clickOk();
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on visual verify left bar icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickVisualVerifyFromLeftBarAsRph() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.VISUAL_VERIFY_ICON);
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                if (connexusStartPage.getTextFromAppTitleBar(1).contains("Visual Verify")) {
                    Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.clickOk();
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method navigates to 4 point menu option
     *
     * @author Ashok(vn50h3h)
     */
    public void menuNavigationToOpen4PointScreenAsRph() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.navigateToMenu(AppMenu.FOUR_POINT);
            automationManager.performSleep(4);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.FOUR_POINT_ICON.getLeftBarWorkQueues()) ||
                    connexusStartPage.getTextFromTitleBar().contains("Check DUR")) {
                automationManager.performSleep(3);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickYes();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method navigates to counseling menu option
     *
     * @author Ashok(vn50h3h)
     */
    public void menuNavigationToOpenCounselingScreenAsRph() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.navigateToMenu(AppMenu.COUNSELING);
            automationManager.performSleep(4);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                automationManager.performSleep(3);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.clickOk();
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method navigates to visual verify menu option
     *
     * @author Ashok(vn50h3h)
     */
    public void menuNavigationToOpenVisualVerifyScreenAsRph() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.navigateToMenu(AppMenu.VISUAL_VERIFY);
            automationManager.performSleep(4);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                automationManager.performSleep(3);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                if (connexusStartPage.getTextFromAppTitleBar(1).contains("Visual Verify")) {
                    Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.clickOk();
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * method to perform keyboard shortcut to open 4 point screen
     *
     * @author Ashok(vn50h3h)
     */
    public void pressKeyboardShortCutToOpen4PointScreenAsRph() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.inputShortcutKeys(AppShortcuts.FOUR_POINT.getAppShortcuts());
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.FOUR_POINT_ICON.getLeftBarWorkQueues()) ||
                    connexusStartPage.getTextFromTitleBar().contains("Check DUR")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * method to perform keyboard shortcut to open counseling screen
     *
     * @author Ashok(vn50h3h)
     */
    public void pressKeyboardShortCutToOpenCounselingScreenAsRph() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.inputShortcutKeys(AppShortcuts.COUNSELING.getAppShortcuts());
            automationManager.performSleep(4);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * method to perform keyboard shortcut to open visual verify screen
     *
     * @author Ashok(vn50h3h)
     */
    public void pressKeyboardShortCutToVisualVerifyScreenAsRph() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.inputShortcutKeys(AppShortcuts.VISUAL_VERIFY.getAppShortcuts());
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                if (connexusStartPage.getTextFromAppTitleBar(1).contains("Visual Verify")) {
                    Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.clickOk();
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on 4 point left bar icon as tech and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void click4PointFromLeftBarAsTech() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.FOUR_POINT_ICON);
            automationManager.performSleep(3);
            if (!(connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.FOUR_POINT_ICON.getLeftBarWorkQueues()) ||
                    connexusStartPage.getTextFromTitleBar().contains("Check DUR"))) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on counseling left bar icon as tech and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickCounselingFromLeftBarAsTech() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.COUNSELING_ICON);
            automationManager.performSleep(3);
            if (!connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.COUNSELING_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on 4 point quick access icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickQuickIconCheckFor4PointAsTech() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickQuickAccessIcon(ConnexusConstants.APP_CONSTANT_4POINT_QUICK_ACCESS_ICON);
            automationManager.performSleep(4);
            if (!(connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.FOUR_POINT_ICON.getLeftBarWorkQueues()) ||
                    connexusStartPage.getTextFromTitleBar().contains("Check DUR"))) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on visual verify quick access icon and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickQuickIconCheckForVisualVerifyAsTech() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickQuickAccessIcon(ConnexusConstants.APP_CONSTANT_VISUALLYVERIFY_QUICK_ACCESS_ICON);
            automationManager.performSleep(4);
            if (!connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                if (connexusStartPage.getTextFromAppTitleBar(1).contains("Visual Verify")) {
                    Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.clickOk();
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on visual verify left bar icon as tech and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickVisualVerifyFromLeftBarAsTech() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.VISUAL_VERIFY_ICON);
            automationManager.performSleep(3);
            if (!connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                if (connexusStartPage.getTextFromAppTitleBar(1).contains("Visual Verify")) {
                    Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.clickOk();
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method navigates to 4 point menu option as tech
     *
     * @author Ashok(vn50h3h)
     */
    public void menuNavigationToOpen4PointScreenAsTech() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.navigateToMenu(AppMenu.FOUR_POINT);
            automationManager.performSleep(4);
            if (!(connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.FOUR_POINT_ICON.getLeftBarWorkQueues()) ||
                    connexusStartPage.getTextFromTitleBar().contains("Check DUR"))) {
                automationManager.performSleep(3);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickYes();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method navigates to counseling menu option
     *
     * @author Ashok(vn50h3h)
     */
    public void menuNavigationToOpenCounselingScreenAsTech() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.navigateToMenu(AppMenu.COUNSELING);
            automationManager.performSleep(4);
            if (!connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                automationManager.performSleep(3);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.clickOk();
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method navigates to visual verify menu option
     *
     * @author Ashok(vn50h3h)
     */
    public void menuNavigationToOpenVisualVerifyScreenAsTech() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.navigateToMenu(AppMenu.VISUAL_VERIFY);
            automationManager.performSleep(4);
            if (!connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                automationManager.performSleep(3);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                if (connexusStartPage.getTextFromAppTitleBar(1).contains("Visual Verify")) {
                    Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.clickOk();
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * method to perform keyboard shortcut to open 4 point screen as tech and check if no screen appeared
     *
     * @author Ashok(vn50h3h)
     */
    public void pressKeyboardShortCutToOpen4PointScreenAsTech() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.inputShortcutKeys(AppShortcuts.FOUR_POINT.getAppShortcuts());
            automationManager.performSleep(3);
            if (!(connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.FOUR_POINT_ICON.getLeftBarWorkQueues()) ||
                    connexusStartPage.getTextFromTitleBar().contains("Check DUR"))) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * method to perform keyboard shortcut to open counseling screen and check if no screen appeared
     *
     * @author Ashok(vn50h3h)
     */
    public void pressKeyboardShortCutToOpenCounselingScreenAsTech() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.inputShortcutKeys(AppShortcuts.COUNSELING.getAppShortcuts());
            automationManager.performSleep(4);
            if (!connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * method to perform keyboard shortcut to open visual verify  screen and check if no screen appeared
     *
     * @author Ashok(vn50h3h)
     */
    public void pressKeyboardShortCutToVisualVerifyScreenAsTech() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.inputShortcutKeys(AppShortcuts.VISUAL_VERIFY.getAppShortcuts());
            automationManager.performSleep(3);
            if (!connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                if (connexusStartPage.getTextFromAppTitleBar(1).contains("Visual Verify")) {
                    Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.clickOk();
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method navigates to search type menu option next to search for filed in the tool strip
     *
     * @param searchFor (PATIENT, PRESCRIBER, PRODUCT, COMPOUND, PHARMACY, RX, ORDER, PLAN, CLAIM, PATIENT_ELIGIBILITY, IMZ_EVENT)
     * @param inputData
     * @author Ashok(vn50h3h)
     */
    public void selectMenuItemInDropDownNextToSearchBar(SearchItem searchFor, Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        int arrowDownCount = Integer.parseInt(SearchItem.getSearchItem(searchFor, inputData).get(ActionName.ARROW_DOWN_COUNT).getText());
        try {
            connexusStartPage.clickSearchForTextField();
            connexusStartPage.pressTabKey();
            for (int i = 1; i <= arrowDownCount; i++) {
                connexusStartPage.pressArrowDownKey();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusStartPage.pressEnterKey();
            automationManager.performSleep(3);
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * method input search text in the search for field
     *
     * @author Ashok(vn50h3h)
     */
    public void enterSearchTextIntoSearchBar(SearchItem searchFor, Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String searchText = SearchItem.getSearchItem(searchFor, inputData).get(ActionName.SEARCH_TEXT).getText();
        try {
            connexusStartPage.clickSearchForTextField();
            connexusStartPage.inputSearchText(searchText);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method check the entered text in the search is present in the respective screen once the screen is launched
     *
     * @author Ashok(vn50h3h)
     */
    public void validateSearchBarTextPresentInSearchScreen(SearchItem searchFor, Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String searchText = SearchItem.getSearchItem(searchFor, inputData).get(ActionName.SEARCH_TEXT).getText();
        try {
            automationManager.performSleep(2);
            if (connexusStartPage.isSearchScreenDisplayed(searchFor) && connexusStartPage.getTextFromSearchScreenTextField(searchFor).contains(searchText)) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {

            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        if (connexusStartPage.isCloseDisplayed()) {
            connexusStartPage.clickClose();
        } else {
            connexusStartPage.clickCancel();
        }
    }

    /**
     * this method navigates to order menu option
     *
     * @author Ashok(vn50h3h)
     */
    public void menuNavigationToOpenOrderSearchScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.navigateToMenu(AppMenu.ORDER);
            automationManager.performSleep(4);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method checks for the functional screen appeared or failed once the script completes launching the screen
     *
     * @param searchFor (PATIENT, PRESCRIBER, PRODUCT, COMPOUND, PHARMACY, RX, ORDER, PLAN, CLAIM, PATIENT_ELIGIBILITY, IMZ_EVENT)
     * @author Ashok(vn50h3h)
     */
    public void validateFunctionalScreenFor(SearchItem searchFor) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(10);
            if (connexusStartPage.getTextFromAppTitleBar(1).equalsIgnoreCase(searchFor.getSearchItem())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                if (connexusStartPage.isCloseDisplayed()) {
                    connexusStartPage.clickClose();
                } else {
                    if (connexusStartPage.isCloseButtonDisplayed()) {
                        connexusStartPage.clickCloseButton();
                    } else {
                        connexusStartPage.clickCancel();
                    }
                }
                if (connexusStartPage.isFloatingYesDisplayed()) {
                    connexusStartPage.clickYes();
                }
            }
            else
            {
                connexusStartPage.clickClose();
                Assert.fail("Title does not matching");
            }
        }
        catch (Throwable e) {
            e.printStackTrace();
            patientSearchPage.closeIfAnyPopUpOpened();
            Assert.fail("Title not matching");

        }
    }

    public void ValidatefunctionalreportforHippaReport(SearchItem searchFor) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
                Reporter.log("Validate selected Patient details");
                menuBar.selectPatient();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                menuBar.clickShowReport();
            if (menuBar.isElementDisplayed(menuBar.btnPrint, 30)) {
                Assert.assertTrue(true);
                Reporter.log("Validate detailed report " + currentStepMethodName + "for HIPPA");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }else{
                Assert.fail("Report not opened");
            }
        }
        catch (Throwable e) {
            e.printStackTrace();
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            Assert.fail("Title not matching");
        }
    }

    public void ValidateHippaRecordsRequestReport(SearchItem searchFor) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
                Reporter.log("Validate selected Patient details");
                siteId = Integer.parseInt(prop.getProperty("cnx.store"));
                IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
                DataRow patientInfo = getPatientInfo(cnx);
                String lastname=patientInfo.getValue("last_name").toString().trim();
                String firstname=patientInfo.getValue("first_name").toString().trim();
                String patientName=lastname+","+firstname;
                String dob=patientInfo.getValue("birth_date").toString();
                String DOB=dob.substring(5);
                menuBar.enterPatientDetails(patientName,DOB);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                menuBar.clickShowReport();
                Reporter.log("Validate a detailed report "+currentStepMethodName+"for HIPPA");
            if (menuBar.isElementDisplayed(menuBar.btnPrint, 30)) {
                Assert.assertTrue(true);
                Reporter.log("Validate detailed report " + currentStepMethodName + "for HIPPA");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                //patientSearchPage.closeIfAnyPopUpOpened();
            }else{
                Assert.fail("Report not opened");
            }
        }
        catch (Throwable e) {
            e.printStackTrace();
            Assert.fail("Title not matching");
        }
    }

    public void ValidateHippaInspectionLogReport(SearchItem searchFor) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
                Reporter.log("Validate Inspection log report");
                menuBar.enterRequiredDetailsInInspectionLog();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                menuBar.click(menuBar.okButton);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertEquals("Investigation Information has been Logged Successfully".trim(),menuBar.getValidationPopText().trim());
                menuBar.click(menuBar.okButton);
        }
        catch (Throwable e) {
            e.printStackTrace();
            Assert.fail("Title does not matching");
        }
    }

    public void validatePharmacistActivityReport(SearchItem searchFor) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if(menuBar.isElementDisplayed(menuBar.selectUser)){
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertTrue(menuBar.isElementDisplayed(menuBar.selectUser));
                menuBar.selectUserName();
                Assert.assertTrue(menuBar.isElementDisplayed(menuBar.showReport));
                menuBar.clickShowReport();
                Reporter.log("Pharmacy Activity Report after providing user name");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                if (connexusStartPage.isCloseDisplayed()) {
                    connexusStartPage.clickClose();
                } else {
                    if (connexusStartPage.isCloseButtonDisplayed()) {
                        connexusStartPage.clickCloseButton();
                    } else {
                        connexusStartPage.clickCancel();
                    }
                }
                if (connexusStartPage.isFloatingYesDisplayed()) {
                    connexusStartPage.clickYes();
                }
            }
            else
            {
                connexusStartPage.clickClose();
                Assert.fail("Title does not matching");
            }
        }
        catch (Exception e) {
            connexusStartPage.clickTitleBar();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (connexusStartPage.isFloatingOkDisplayed()) {
                connexusStartPage.clickOk();
            }
            softAssert.fail(e.toString());
        }
    }

    public void validateDailyReportForPharmacyBusinessSummary(SearchItem searchFor) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (connexusStartPage.getTextFromAppTitleBar(1).equalsIgnoreCase(searchFor.getSearchItem())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                menuBar.clickShowReport();
                Reporter.log("Daily Report for Pharmacy Business report");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                if (connexusStartPage.isCloseDisplayed()) {
                    connexusStartPage.clickClose();
                } else {
                    if (connexusStartPage.isCloseButtonDisplayed()) {
                        connexusStartPage.clickCloseButton();
                    } else {
                        connexusStartPage.clickCancel();
                    }
                }
                if (connexusStartPage.isFloatingYesDisplayed()) {
                    connexusStartPage.clickYes();
                }
            }
            else
            {
                connexusStartPage.clickClose();
                Assert.fail("Title does not matching");
            }
        }
        catch (Throwable e) {
            connexusStartPage.clickTitleBar();
            if (connexusStartPage.isFloatingOkDisplayed()) {
                connexusStartPage.clickOk();
            }
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());

        }
    }

    public void validateMonthlyReportForPharmacyBusinessSummary(SearchItem searchFor) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (connexusStartPage.getTextFromAppTitleBar(1).equalsIgnoreCase(searchFor.getSearchItem())) {
                menuBar.clickMonthlyReportRadioButton();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                menuBar.clickShowReport();
                Reporter.log("Monthly Report for Pharmacy Business report");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                if (connexusStartPage.isCloseDisplayed()) {
                    connexusStartPage.clickClose();
                } else {
                    if (connexusStartPage.isCloseButtonDisplayed()) {
                        connexusStartPage.clickCloseButton();
                    } else {
                        connexusStartPage.clickCancel();
                    }
                }
                if (connexusStartPage.isFloatingYesDisplayed()) {
                    connexusStartPage.clickYes();
                }
            }
            else
            {
                connexusStartPage.clickClose();
                Assert.fail("Title does not matching");
            }
        }
        catch (Exception e) {
            connexusStartPage.clickTitleBar();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (connexusStartPage.isFloatingOkDisplayed()) {
                connexusStartPage.clickOk();
            }
            softAssert.fail(e.toString());
        }
    }

    /**
     * this method check if no screen displayed upon trying to launching the respective screen in previous steps
     *
     * @author Ashok(vn50h3h)
     */
    public void validateNoScreenDisplayed(SearchItem searchFor) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (connexusStartPage.getTextFromAppTitleBar(1).contains(searchFor.getSearchItem())) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.clickCancel();
                automationManager.performSleep(1);
                if (connexusStartPage.isFloatingYesDisplayed()) {
                    connexusStartPage.clickYes();
                }
            }
            if (connexusStartPage.isFloatingOkDisplayed()) {
                connexusStartPage.clickOk();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            if (connexusStartPage.isFloatingOkDisplayed()) {
                connexusStartPage.clickOk();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * a method click quick access icon for given functional screen and check for respective screen appeared or failed
     *
     * @param searchFor (PRESCRIBER, PHARMACY, COMPOUND, IMZ EVENT)
     * @author Ashok(vn50h3h)
     */
    public void clickQuickAccessIcon(SearchItem searchFor) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.mouseHoverOnToolStrip();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusStartPage.clickToolStripDropDownButton();
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromAppTitleBar(1).contains(searchFor.getSearchItem())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click quick access icon for given functional screen and check for respective screen appeared or failed
     *
     * @param searchFor (NEW_IMZ_EVENT, NEW_PHARMACY, NEW_COMPOUND, NEW_PRESCRIBER)
     * @author Ashok(vn50h3h)
     */
    public void selectItemFromQuickAccessDropDownArrow(SearchItem searchFor, Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        int tabCount = Integer.parseInt(SearchItem.getSearchItem(searchFor, inputData).get(ActionName.TAB_COUNT).getText());
        int arrowDownCount = Integer.parseInt(SearchItem.getSearchItem(searchFor, inputData).get(ActionName.ARROW_DOWN_COUNT).getText());
        try {
            connexusStartPage.clickSearchForTextField();
            for (int i = 1; i <= tabCount; i++) {
                connexusStartPage.pressTabKey();
            }
            for (int i = 1; i <= arrowDownCount; i++) {
                connexusStartPage.pressArrowDownKey();
            }
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusStartPage.pressEnterKey();
            automationManager.performSleep(1);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method checks for imz is enabled for tech user
     *
     * @author Ashok(vn50h3h)
     */
    public void checkImzEventForTechUser() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        if (menuBar.navigateToMenu(AppMenu.NEW_IMZ_EVENT)) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } else {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * this method check for print option is disabled
     *
     * @author Ashok(vn50h3h)
     */
    public void validatePrintMenuDisabled() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (menuBar.navigateToMenu(AppMenu.PRINT) && connexusStartPage.getTextFromAppTitleBar(1).contains(SearchItem.PRINT.getSearchItem())) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * this method checks for launching print by its shortcut
     *
     * @author Ashok(vn50h3h)
     */
    public void validatePrintShortcutDoNothing() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.inputShortcutKeys(AppShortcuts.PRINT.getAppShortcuts());
            automationManager.performSleep(3);
            if (!connexusStartPage.getTextFromAppTitleBar(1).contains(SearchItem.PRINT.getSearchItem())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.pressEscapeKey();
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /**
     * this method check for print set up dialog box
     *
     * @author Ashok(vn50h3h)
     */
    public void validatePrintSetupMenu() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (menuBar.navigateToMenu(AppMenu.PRINT_SETUP)) {
                validateFunctionalScreenFor(SearchItem.PRINT_SETUP);
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click quick access icon for given functional screen and check for respective screen appeared or failed
     *
     * @param searchFor (CHECK_WORK_QUEUE)
     * @author Ashok(vn50h3h)
     */
    public void clickQuickAccessIconFor(SearchItem searchFor, Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickQuickAccessIcon(SearchItem.getSearchItem(searchFor, inputData).get(ActionName.TAB_COUNT).getText());
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * this method validates test from tasco screen
     *
     * @author Ashok(vn50h3h)
     */
    public void validateTascoScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if ("Required: Last Name and First Name with DOB or Phone Number".equals(tascoPage.getTextFromTascoSearchRequirementsMessage())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            tascoPage.clickExitInTasco();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method right click on left menu bar item
     *
     * @author Ashok(vn50h3h)
     */
    public void rightClickOnLeftMenuBar() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.mouseHoverOnLeftBar();
            connexusStartPage.rightClickOnLeftBar();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (connexusStartPage.isCustomizeDisplayed()) {
                connexusStartPage.mouseHoverOnCustomize();
                Reporter.logScreenShot(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                connexusStartPage.clickCustomize();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEnterKey();
            automationManager.performSleep(3);
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * a method click on urgent messages left bar icon as tech and check for respective screen appeared or failed
     *
     * @author Ashok(vn50h3h)
     */
    public void clickUrgentMessageFromLeftBar() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.URGENT_MESSAGES_ICON);
            automationManager.performSleep(3);
            if (connexusStartPage.getTextFromAppTitleBar(1).contains("Pharmacy Immediate Action  Messages")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * this method checks for the report screen launched or failed once the script completes launching the screen
     *
     * @param searchFor (DRUG_MOVEMENT_BY_DRUG_SCHEDULE, REPLENISHMENT_UNAVAILABLE_REPORT, REPLENISHMENT_AVAILABLE_REPORT, DRUG_MOVEMENT_TOP_BOTTOM_DRUG...)
     * @author Ashok(vn50h3h)
     */
    public void validateReportScreenFor(SearchItem searchFor) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (connexusStartPage.getTextFromReportTitle().equalsIgnoreCase(searchFor.getSearchItem())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName + " " + searchFor.getSearchItem(), connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                if (connexusStartPage.isCloseDisplayed()) {
                    connexusStartPage.clickClose();
                } else {
                    if (connexusStartPage.isCloseButtonDisplayed()) {
                        connexusStartPage.clickCloseButton();
                    } else {
                        connexusStartPage.clickCancel();
                    }
                }
                if (connexusStartPage.isFloatingYesDisplayed()) {
                    connexusStartPage.clickYes();
                }
            } else {
                connexusStartPage.clickClose();
                Assert.fail("Title does not matching");
            }
        } catch (Exception e) {
            connexusStartPage.clickTitleBar();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            if (connexusStartPage.isFloatingOkDisplayed()) {
                connexusStartPage.clickOk();
            }
            softAssert.fail(e.toString());
                    }
    }

    public DataRow getPatientInfo(IDatabaseContext cnx) {
        String getPatientInfo = "select last_name, first_name, birth_date from rx21c:informix.patient \n" +
                "limit 1";
        DataTable dt = cnx.getDataTable(getPatientInfo);
        Assert.assertEquals(dt.getRowCount(), 1);
        DataRow row = dt.getDataRows().get(0);
        return row;
    }



    public void tempUserValidation() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
           menuBar.validateTempUserSetUphOptionNotAvailableForTechnicianLogin(AppMenu.TEMP_USER_SETUP,  SearchItem.TEMP_USER_SETUP);
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


    public void validateIncorrectEntriesAndFourPtRphOptionNotAvailableForTechnicianLogin(AppMenu menu,AppMenuItemsIndex menuNavigation, SearchItem searchFor) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            for (int i = 0; i < 5; i++){
                if(i!=1 && i!=2)
                {
                    String[] menuItems = menu.getAppMenu().split("->");
                    menuBar.selectMenuItem(menuItems[0]);

                    robot = new Robot();
                    for (int j = 0; j < menuNavigation.getAppMenu(); j++) {
                        automationManager.performSleep(3);
                        robot.keyPress(KeyEvent.VK_DOWN);
                        robot.keyRelease(KeyEvent.VK_DOWN);
                    }
                    robot.keyPress(KeyEvent.VK_ENTER);
                    robot.keyRelease(KeyEvent.VK_ENTER);

                    robot.keyPress(KeyEvent.VK_TAB);
                    robot.keyRelease(KeyEvent.VK_TAB);
                    robot.keyPress(KeyEvent.VK_UP);
                    robot.keyRelease(KeyEvent.VK_UP);
                    for(int k=0;k<=i;k++)
                    {
                        automationManager.performSleep(3);
                        robot.keyPress(KeyEvent.VK_TAB);
                        robot.keyRelease(KeyEvent.VK_TAB);
                    }
                    robot.keyPress(KeyEvent.VK_ENTER);
                    robot.keyRelease(KeyEvent.VK_ENTER);
                    if(menuBar.getTextFromAppTitleBar(1).equalsIgnoreCase(searchFor.getSearchItem()))
                    {
                        Reporter.logScreenShot(Status.FAIL, menu.getAppMenu(), menuBar.takeScreenShot(currentStepMethodName).getValue());
                        Assert.fail("Title matching");
                    }else {
                        Reporter.logScreenShot(Status.PASS, menu.getAppMenu()+" title should not match with open window as technician not having this page", menuBar.takeScreenShot(currentStepMethodName).getValue());
                        menuBar.click(menuBar.closeButton);
                    }
                }
            }
        } catch (Exception exception) {
            int count = 0;
            while (count < 3) {
                robot.keyPress(KeyEvent.VK_ESCAPE);
                //pressKeys(KeyEvent.VK_ESCAPE);
                count++;
            }
        }
    }


    public void selectNavigation(AppMenu menu,AppMenuItemsIndex menuNavigation, AppMenuSubItemsIndex subMenuNavigation) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(menu,menuNavigation,subMenuNavigation,null);
        } catch (Exception e) {
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


}