package connexus.uattest.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.asserts.SoftAssert;

/*----------------------------------------------------------------------------------------------------------
 * Author: Ashok(Vn50h3h)
 ----------------------------------------------------------------------------------------------------------*/
public class LoginScreenUatTestSet1Scripts extends ConnexusTestScripts {

    public void loginConnexusHO(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
    }

    public void launchConnexusWithAdFlagTrue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            loginConnexusHO(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            clickUserNameTextFieldOnLoginScreen();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured=true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickUserNameTextFieldOnLoginScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            loginPage.clickloginScreenUserNameTextField();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured=true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterUserNameInLoginScreenUserNameTextField() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            loginPage.inputHoUserName();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured=true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void pressTabKeyToMoveToPasswordField() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            loginPage.pressTabKey();
            if (loginPage.hasKeyboardFocusOnPasswordField()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            isExceptionCaptured=true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterPasswordInLoginScreenPasswordField() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (loginPage.hasKeyboardFocusOnPasswordField()
                    && loginPage.isPasswordFieldMasked()) {
                loginPage.inputHoPassword();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            isExceptionCaptured=true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validatePasswordFieldIsHidden() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (loginPage.hasKeyboardFocusOnPasswordField()
                    && loginPage.isPasswordFieldMasked()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            isExceptionCaptured=true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void pressTabKeyThreeTimesAndPressEnterKey() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            loginPage.pressTabKey();
            loginPage.pressTabKey();
            loginPage.pressSpaceBar();
            loginPage.pressTabKey();
            loginPage.pressEnterKey();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            isExceptionCaptured=true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateSecurityWarningPromptIsDisplayed() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (loginPage.isSecurityWarningMessageDisplayed()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            isExceptionCaptured=true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void pressEscapeKeyToCloseLoginScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            loginPage.pressEscapeKey();
            System.gc();
        } catch (Exception e) {
            isExceptionCaptured=true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void pressEscapeKeyToCloseSecurityWarningPrompt() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            loginPage.pressEscapeKey();
            loginPage.switchWindow();
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    //All the methods below are from obsoleted test cases


    public void clickAcceptInLoginScreen() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.clickOldScreenAccept();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickAcceptInSecurityWarningPrompt() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.clickSecurityWarningAccept();
            Reporter.logScreenShot(Status.PASS,
                    currentStepMethodName,
                    loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickAcceptInNewLoginScreen() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.clickAccept();
            Reporter.logScreenShot(Status.PASS,
                    currentStepMethodName,
                    loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickChangeStoreCheckBoxInLoginScreen() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.clickChangeStoreCheckBox();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickDeclineInSecurityWarningPrompt() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.clickSecurityWarningCancel();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickHomeOfficeCheckBoxInLoginScreen() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.clickHomeOfficeCheckBox();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickPasswordTextFieldOnLoginScreen() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.clickloginScreenPasswordField();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickUserNameTextFieldOnOldLoginScreen() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.clickOldloginScreenUserNameTextField();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterHomeOfficeInOldLoginScreenStoreNumberTextField() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.clickChangeStoreCheckBoxOldScreen();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterRphPasswordInLoginScreenPasswordField() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.inputRPHPassword();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterRphUserNameInLoginScreenUserNameTextField() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.inputRPHUserName();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void enterStoreNumberInOldLoginScreenStoreNumberTextField() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.clickChangeStoreTextFieldOldScreen();
            loginPage.inputStoreId();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void launchConnexusWithAdFlagFalse() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginConnexusHO(LoginAs.userType.HOMEOFFICE_ADFlagOff);
            clickUserNameTextFieldOnOldLoginScreen();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    public void pressAltF4KeyToCloseApplication() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            loginPage.closeAppKeyCombo();
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void pressEnterKeyToBeginLogin() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.pressEnterKey();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateLoginRejection() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            if (loginPage.isPasswordFieldDisplayed()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void validateMainScreenIsDisplayed() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            loginPage.handelInitialLoginPopUps();
            loginPage.switchWindow();
            if (loginPage.isLeftBarWorkQueueDisplayed()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
}