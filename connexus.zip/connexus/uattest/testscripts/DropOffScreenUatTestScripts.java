package connexus.uattest.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.appium.java_client.AppiumBy;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import java.util.Map;

/**
 * this class provides test case logics to the respective calling test steps
 *
 * @author Ashok(vn50h3h)
 */
public class DropOffScreenUatTestScripts extends ConnexusTestScripts {

    String rxNumber = "";
    Map<String, Object> patientResultSet;

    public DropOffScreenUatTestScripts(LoginAs.userType loginUserType){
        super(loginUserType);
    }

    public void inputRxNumberInPtSearchBox() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickDropOffQueue();
            if ("".equals(rxNumber)) {
                rxNumber = connexusAppUtils.getRandomRxFromStoreDb();
            }
            dropOffPage.enterPatientName(rxNumber);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public void validateRxFromRightSideRxQueue() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            dropOffPage.clickYesInPopUp();
            dropOffPage.clickOutOFFStock();
            if (dropOffPage.isGridShowsRxRecord(0)) {
                Reporter.log("Validating Rx number in drop off page "+rxNumber);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            connexusStartPage.pressEscapeKey();
            dropOffPage.clickYesInPopUp();
            dropOffPage.partialpopup();
            dropOffPage.clickOkButton();
        } catch (Throwable e) {
            isExceptionCaptured= true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public void selectAndValidatePatientFromSearchWindow() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            if (connexusStartPage.isSearchScreenDisplayed(SearchItem.PATIENT)) {
                if(dropOffPage.isElementDisplayed(AppiumBy.name("Name Row " + 0))) {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    String patientNameFromPatientSearchScreen = patientSearchPage.getPatientNameFromSearchGrid(0);
                    patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
                    if (!connexusStartPage.isSearchScreenDisplayed(SearchItem.PATIENT))
                    {
                        dropOffPage.handleAnnualValidatePatInfoPopUp();
                        String patientNameFromDropOffScreen = dropOffPage.getEnteredPatientName().replace(" ", "");
                        if (patientNameFromPatientSearchScreen.contains(patientNameFromDropOffScreen)) {
                            Reporter.log("Validate patient name displayed " + patientNameFromDropOffScreen);
                            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                        }
                    }else {
                        Reporter.log("Patient search results window not closed");
                        Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                        patientSearchPage.closeIfAnyPopUpOpened();
                        Assert.fail("Patient search results window not closed");
                    }
                }else {
                    Reporter.log("Patient search results are not available");
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    patientSearchPage.closeIfAnyPopUpOpened();
                    Assert.fail("Patient search results are not available");

                }
            } else {
                String patientNameFromDropOffScreen = dropOffPage.getEnteredPatientName().replace(" ", "");
                if ((patientResultSet.get("last_name").toString().trim() + "," + patientResultSet.get("first_name").toString().trim()).equals(patientNameFromDropOffScreen)) {
                    Reporter.log("Validate patient name displayed"+patientNameFromDropOffScreen);
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                } else {
                    Assert.fail("Patient search results are not available");
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }
            }
            connexusStartPage.pressEscapeKey();
            dropOffPage.clickYesInPopUp();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail("Patient details not available");
        }
    }

    public void inputPtNameAndDobInPtSearchBox(NameFormatEnum patientName, DateFormatEnum dateFormat) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickDropOffQueue();
            String patientNameTxt;
            String patientDobTxt;

            if (patientResultSet == null) {
                patientResultSet = connexusAppUtils.getRandomPatientFromStoreDb();
            }

            switch (patientName) {
                case FNLN:
                    patientNameTxt = patientResultSet.get("first_name").toString().trim() + " " + patientResultSet.get("last_name").toString().trim();
                    break;
                case LNFN:
                    patientNameTxt = patientResultSet.get("last_name").toString().trim() + ", " + patientResultSet.get("first_name").toString().trim();
                    break;
                default:
                    patientNameTxt = "";
                    break;
            }

            switch (dateFormat) {
                case MMDDYY:
                    patientDobTxt = patientResultSet.get("birth_date").toString().trim().split("-")[2] + "/" + patientResultSet.get("birth_date").toString().trim().split("-")[1] + "/" + patientResultSet.get("birth_date").toString().trim().split("-")[0].substring(2);
                    break;
                case MMDDYYYY:
                    patientDobTxt = patientResultSet.get("birth_date").toString().trim().split("-")[2] + "/" + patientResultSet.get("birth_date").toString().trim().split("-")[1] + "/" + patientResultSet.get("birth_date").toString().trim().split("-")[0];
                    break;
                default:
                    patientDobTxt = "";
                    break;
            }
            dropOffPage.enterPatientName("".equals(patientNameTxt) || "".equals(patientDobTxt) ?
                    patientNameTxt + patientDobTxt :
                    patientNameTxt + " " + patientDobTxt);
            Reporter.log("Entering" +patientNameTxt+ patientDobTxt+"in drop off page ");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
        * The below method performs DropOff entering number of Rx as 2 and providing Priority and Pickup type according to the input provided.
        * Author: Tarun(vn510o1)
        ----------------------------------------------------------------------------------------------------------*/
    public void addMultiplePrescriptionsAndValidate(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
            DropOffPage dropOffPage = new DropOffPage();
            AutomationManager automationManager = AutomationManager.getInstance();
            ConnexusStartPage connexusStartPage = new ConnexusStartPage();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(name[0] + "," + name[1]);
            dropOffPage.sendHotKeys(Keys.ENTER);
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickScanNewRx();
            String barCode = dropOffPage.generateRxBarCode();
            dropOffPage.enterBarCode(barCode);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickBtnAccept();
            dropOffPage.clickVerifyBarCode();
            dropOffPage.selectRxOrigin();
            dropOffPage.clickBtnAccept();
            dropOffPage.addNoOfRx(barCode, Integer.parseInt(inputData.get("COUNT")));
            Reporter.log("Number of Rx added during Drop-Off: " + inputData.get("COUNT") + " | Priority: " + inputData.get("PRIORITY"));
            Assert.assertEquals(Integer.parseInt(inputData.get("COUNT")), dropOffPage.validateRxCount(0));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(2);
            dropOffPage.selectPriority(inputData.get("PRIORITY"));
            if (inputData.get("PRIORITY").equalsIgnoreCase(Priority.Future.getPriority()) || inputData.get("PRIORITY").equalsIgnoreCase(Priority.Today.getPriority())) {
                dropOffPage.selectReadyByTimeNew();
            }
            dropOffPage.clickBtnAccept();
            dropOffPage.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed");
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    /*----------------------------------------------------------------------------------------------------------
        * The below method validates the count of the prescriptions dropped by fetching the records found from the F6 search screen
        * Author: Tarun (vn510o1)
        ----------------------------------------------------------------------------------------------------------*/
    public int validateRxRecordCount(int input, String expectedPriority, int priorityCount) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        int count = 0;
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(patientName);
            automationManager.performSleep(3);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            String text = orderSearch.getWorkQueue(0);
            Reporter.log("WorkQueue Validation - Expected: Input | Actual: " + text);
            Assert.assertTrue("Input".equalsIgnoreCase(text), "Expected WorkQueue: Input | Actual: " + text);
            if (expectedPriority != null) {
                String actualPriority = orderSearch.getPriority(0);
                Reporter.log("Priority Validation - Expected Priority: " + expectedPriority + " | Actual Priority: " + actualPriority);
                Assert.assertTrue(actualPriority.replace(".", "").equalsIgnoreCase(expectedPriority.replace(".", "")),
                        "Expected Priority: " + expectedPriority + " | Actual: " + actualPriority);
            }
            count = orderSearch.getRecordCount();
            Reporter.log("Total Record Count Validation - Total Expected: " + input + " | Total Actual: " + count);
            if (expectedPriority != null && count > 0) {
                int actualPriorityCount = 0;
                for (int i = 0; i < count; i++) {
                    if (orderSearch.getPriority(i).replace(".", "").equalsIgnoreCase(expectedPriority.replace(".", ""))) {
                        actualPriorityCount++;
                    }
                }
                Reporter.log("Priority '" + expectedPriority + "' Record Count - Expected: " + priorityCount + " | Actual: " + actualPriorityCount);
                Assert.assertEquals(priorityCount, actualPriorityCount, "Priority '" + expectedPriority + "' Record Count mismatch - Expected: " + priorityCount + " | Actual: " + actualPriorityCount);
            }
            Assert.assertEquals(input, count);
            orderSearch.closeSearch();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }
        return count;
    }

    public enum DateFormatEnum {
        MMDDYY,
        MMDDYYYY,

        NA
    }

    public enum NameFormatEnum {
        FNLN,
        LNFN,
        NA
    }

}