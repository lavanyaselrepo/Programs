package connexus.uattest.testscripts;

import com.aventstack.extentreports.Status;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class TempUserTestScripts {

    LoginPage loginPage;
    AutomationManager automationManager;
    ConnexusStartPage connexusStartPage;
    SoftAssert softAssert = new SoftAssert();

    public void loginConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        loginPage = new LoginPage();
        connexusStartPage = new ConnexusStartPage();
        loginPage.loginConnexusTempPharmacistWithStateLA(userType);
        automationManager = AutomationManager.getInstance();

    }

    public void validateLoginOverridePopWithWarningMessageAndOverrideAndCancelButtonsIsDisplayed() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(10);
            loginPage.switchWindow();
            if (loginPage.isElementDisplayed(loginPage.overrideButton)) {
                Assert.assertEquals("Pharmacist Action Required: License exception discovered. Please have a pharmacist verify and complete attestation. Pharmacist, if you cannot attest, select ‘cancel’ and partner with your Market leader.", loginPage.getOverRidePopUpText());
                Reporter.log("Login override pop up displayed with Authentication message and Override, Cancel buttons");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
                loginPage.clickCancelButton();
                 Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Assert.fail("Login Override pop up not displayed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void validateLoginOverridePopWithWarningMessageAndOverrideButtonsIsDisplayed() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(10);
            loginPage.switchWindow();
            if (loginPage.isElementDisplayed(loginPage.overrideButton)) {
                Assert.assertEquals("Pharmacist Action Required: License exception discovered. Please have a pharmacist verify and complete attestation. Pharmacist, if you cannot attest, select ‘cancel’ and partner with your Market leader.", loginPage.getOverRidePopUpText());
                Reporter.log("Login override pop up displayed with Authentication message and Override, Cancel buttons");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
                loginPage.clickOverrideButton();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());

            } else {
                Assert.fail("Login Override pop up not displayed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {

            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

}
