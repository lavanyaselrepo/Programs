package connexus.uattest.testcases.loginscreen;

import connexus.uattest.testscripts.LoginScreenUatTestSet1Scripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import io.strati.libs.joda.time.DateTime;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LoginScreenUatTestSet1 {
    LoginScreenUatTestSet1Scripts loginScreenUatTestSet1Scripts = new LoginScreenUatTestSet1Scripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();

    @BeforeClass
    public void loginToConnexus(){
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        connexusAppUtils.stopAppiumServer();
    }


    /*----------------------------------------------------------------------------------------------------------
   * Test Description: To validate a homestore user using tab and enter to
   * accept login
   *
   * Pre-Conditions: Homestore/local Username and password
   *
   * Author: Ashok(Vn50h3h)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 5, description = "To validate a homestore user using tab and enter to accept login")
    public void HWPHME2E_530_Local_user_tabbing_to_login() {
        System.out.println(">>>HWPHME2E_530_Local_user_tabbing_to_login<<<");
        connexusAppUtils.getStoreId();

        // Step 1 Launch the connexus application from the connexus desktop |
        // Connexus launches and opens log in screen
        loginScreenUatTestSet1Scripts.launchConnexusWithAdFlagTrue();

        // Step 2 Click into username field | Cursor blinks in the username
        // field awaiting user input
        loginScreenUatTestSet1Scripts.clickUserNameTextFieldOnLoginScreen();

        // Step 3 Enter username | Username appears as typed in the username
        // field
        loginScreenUatTestSet1Scripts.enterUserNameInLoginScreenUserNameTextField();

        // Step 4 Press Tab on the keyboard to move to password field | Password
        // field should activate
        loginScreenUatTestSet1Scripts.pressTabKeyToMoveToPasswordField();

        // Step 5 Enter password for user account into the field | The entered
        // password should be hidden
        loginScreenUatTestSet1Scripts.enterPasswordInLoginScreenPasswordField();
        loginScreenUatTestSet1Scripts.validatePasswordFieldIsHidden();

        // Step 6 Press tab on the keyboard 3 times and then press enter |
        // Connexus should begin the process and bring up the security warning
        // prompt
        loginScreenUatTestSet1Scripts.pressTabKeyThreeTimesAndPressEnterKey();
        loginScreenUatTestSet1Scripts.validateSecurityWarningPromptIsDisplayed();

        // Additional step to close the login screen so that next test will
        // continue
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseSecurityWarningPrompt();
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseLoginScreen();

        System.out.println("<<<HWPHME2E_530_Local_user_tabbing_to_login>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: To validate user ability to use TAB to enter the
     * password field
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    /*@Test(priority = 1, description = "To validate user ability to use TAB to enter the password field")
    public void HWPHME2E_526_Tabbing_into_password_field() {
        System.out.println(">>>HWPHME2E_526_Tabbing_into_password_field<<<");
        connexusAppUtils.getStoreId();

        // Step 1 Launch the connexus application from the connexus desktop |
        // Connexus launches and opens log in screen
        loginScreenUatTestSet1Scripts.launchConnexusWithAdFlagTrue();

        // Step 2 Click into username field | Cursor blinks in the username
        // field awaiting user input
        loginScreenUatTestSet1Scripts.clickUserNameTextFieldOnLoginScreen();

        // Step 3 Enter username | Username appears as typed in the username
        // field
        loginScreenUatTestSet1Scripts.enterUserNameInLoginScreenUserNameTextField();

        // Step 4 Press Tab on the keyboard to move to password field | Password
        // field should activate
        loginScreenUatTestSet1Scripts.pressTabKeyToMoveToPasswordField();

        // Step 5 Enter password for user account into the field | The entered
        // password should be hidden
        loginScreenUatTestSet1Scripts.enterPasswordInLoginScreenPasswordField();
        loginScreenUatTestSet1Scripts.validatePasswordFieldIsHidden();

        // Additional step to close the login screen so that next test will
        // continue
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseLoginScreen();

        System.out.println("<<<HWPHME2E_526_Tabbing_into_password_field>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: To validate user ability to click into the password
     * field and enter their password
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(priority = 2, description = "To validate user ability to click into the password field and enter their password")
    public void HWPHME2E_527_Clicking_into_the_password_field() {
        System.out.println(">>>HWPHME2E_527_Clicking_into_the_password_field<<<");

        connexusAppUtils.getStoreId();

        // Step 1 Launch the connexus application from the connexus desktop |
        // Connexus launches and opens log in screen
        loginScreenUatTestSet1Scripts.launchConnexusWithAdFlagTrue();

        // Step 2 Click into username field | Cursor blinks in the username
        // field awaiting user input
        loginScreenUatTestSet1Scripts.clickUserNameTextFieldOnLoginScreen();

        // Step 3 Enter username | Username appears as typed in the username
        // field
        loginScreenUatTestSet1Scripts.enterUserNameInLoginScreenUserNameTextField();

        // Step 4 Left click with the mouse in the password field | Password
        // field should activate
        loginScreenUatTestSet1Scripts.clickPasswordTextFieldOnLoginScreen();

        // Step 5 Enter password for user account into the field | The entered
        // password should be hidden
        loginScreenUatTestSet1Scripts.enterPasswordInLoginScreenPasswordField();
        loginScreenUatTestSet1Scripts.validatePasswordFieldIsHidden();

        // Additional step to close the login screen so that next test will
        // continue
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseLoginScreen();

        System.out.println("<<<HWPHME2E_527_Clicking_into_the_password_field>>>");
    }

    *//*----------------------------------------------------------------------------------------------------------
     * Test Description: To validate homestore user using enter to accept login
     *
     * Pre-Conditions: Homestore/local Username and password
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*//*
    @Test(priority = 3, description = "To validate homestore user using enter to accept login")
    public void HWPHME2E_528_Local_User_using_enter_at_login() {
        System.out.println(">>>HWPHME2E_528_Local_User_using_enter_at_login<<<");
        connexusAppUtils.getStoreId();

        // Step 1 Launch the connexus application from the connexus desktop |
        // Connexus launches and opens log in screen
        loginScreenUatTestSet1Scripts.launchConnexusWithAdFlagTrue();

        // Step 2 Click into username field | Cursor blinks in the username
        // field awaiting user input
        loginScreenUatTestSet1Scripts.clickUserNameTextFieldOnLoginScreen();

        // Step 3 Enter username | Username appears as typed in the username
        // field
        loginScreenUatTestSet1Scripts.enterUserNameInLoginScreenUserNameTextField();

        // Step 4 Press Tab on the keyboard to move to password field | Password
        // field should activate
        loginScreenUatTestSet1Scripts.pressTabKeyToMoveToPasswordField();

        // Step 5 Enter password for user account into the field | The entered
        // password should be hidden
        loginScreenUatTestSet1Scripts.enterPasswordInLoginScreenPasswordField();
        loginScreenUatTestSet1Scripts.validatePasswordFieldIsHidden();

        // Additional step to select home office check box in hte login screen
        loginScreenUatTestSet1Scripts.clickHomeOfficeCheckBoxInLoginScreen();

        // Step 6 Press enter on the keyboard | Connexus should begin the
        // process and bring up the security warning prompt
        loginScreenUatTestSet1Scripts.pressEnterKeyToBeginLogin();
        loginScreenUatTestSet1Scripts.validateSecurityWarningPromptIsDisplayed();

        // Additional step to close the login screen so that next test will
        // continue
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseSecurityWarningPrompt();
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseLoginScreen();

        System.out.println("<<<HWPHME2E_528_Local_User_using_enter_at_login>>>");
    }

    *//*----------------------------------------------------------------------------------------------------------
     * Test Description: To validate homestore user clicking accept to log in
     *
     * Pre-Conditions: Homestore/local Username and password
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*//*
    @Test(priority = 4, description = "To validate homestore user clicking accept to log in")
    public void HWPHME2E_529_Local_user_clicking_to_login() {
        System.out.println(">>>HWPHME2E_529_Local_user_clicking_to_login<<<");
        connexusAppUtils.getStoreId();

        // Step 1 Launch the connexus application from the connexus desktop |
        // Connexus launches and opens log in screen
        loginScreenUatTestSet1Scripts.launchConnexusWithAdFlagTrue();

        // Step 2 Click into username field | Cursor blinks in the username
        // field awaiting user input
        loginScreenUatTestSet1Scripts.clickUserNameTextFieldOnLoginScreen();

        // Step 3 Enter username | Username appears as typed in the username
        // field
        loginScreenUatTestSet1Scripts.enterUserNameInLoginScreenUserNameTextField();

        // Step 4 Press Tab on the keyboard to move to password field | Password
        // field should activate
        loginScreenUatTestSet1Scripts.pressTabKeyToMoveToPasswordField();

        // Step 5 Enter password for user account into the field | The entered
        // password should be hidden
        loginScreenUatTestSet1Scripts.enterPasswordInLoginScreenPasswordField();
        loginScreenUatTestSet1Scripts.validatePasswordFieldIsHidden();

        // Additional step to select home office check box in hte login screen
        loginScreenUatTestSet1Scripts.clickHomeOfficeCheckBoxInLoginScreen();

        // Step 6 Click accept using the mouse | Connexus should begin the
        // process and bring up the security warning prompt
        loginScreenUatTestSet1Scripts.clickAcceptInNewLoginScreen();
        loginScreenUatTestSet1Scripts.validateSecurityWarningPromptIsDisplayed();

        // Additional step to close the login screen so that next test will
        // continue
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseSecurityWarningPrompt();
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseLoginScreen();

        System.out.println("<<<HWPHME2E_529_Local_user_clicking_to_login>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: To validate Floating Associate/user using enter to
     * accept login
     *
     * Pre-Conditions: Floating Associate Username and password
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    /*@Test(priority = 6, description = "To validate Floating Associate/user using enter to accept login")
    public void tc_6_Guest_associate_logging_in_using_enter() {
        System.out.println(">>>tc_6_Guest_associate_logging_in_using_enter<<<");

        // Step 1 Launch the connexus application from the connexus desktop |
        // Connexus launches and opens log in screen
        loginScreenUatTestSet1Scripts.launchConnexusWithAdFlagFalse();

        // Step 2 Click into username field | Cursor blinks in the username
        // field awaiting user input
        loginScreenUatTestSet1Scripts.clickUserNameTextFieldOnOldLoginScreen();

        // Step 3 Enter username | Username appears as typed in the username
        // field
        loginScreenUatTestSet1Scripts.enterRphUserNameInLoginScreenUserNameTextField();

        // Step 4 Press Tab on the keyboard to move to password field | Password
        // field should activate
        loginScreenUatTestSet1Scripts.pressTabKeyToMoveToPasswordField();

        // Step 5 Enter password for user account into the field | The entered
        // password should be hidden
        loginScreenUatTestSet1Scripts.enterRphPasswordInLoginScreenPasswordField();
        loginScreenUatTestSet1Scripts.validatePasswordFieldIsHidden();

        // Step 6 Click the Checkbox for change store number and enter the users
        // home store number | Connexus should allow the user to type their home
        // store number in the box
        loginScreenUatTestSet1Scripts.clickChangeStoreCheckBoxInLoginScreen();
        loginScreenUatTestSet1Scripts.enterStoreNumberInOldLoginScreenStoreNumberTextField();

        // Step 6 Press enter on the keyboard | Connexus should begin the
        // process and bring up the security warning prompt
        loginScreenUatTestSet1Scripts.pressEnterKeyToBeginLogin();
        loginScreenUatTestSet1Scripts.validateSecurityWarningPromptIsDisplayed();

        // Additional step to close the login screen so that next test will
        // continue
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseSecurityWarningPrompt();
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseLoginScreen();

        System.out.println("<<<tc_6_Guest_associate_logging_in_using_enter>>>");
    }

    *//*----------------------------------------------------------------------------------------------------------
     * Test Description: To validate Floating Associate/user clicking accept to
     * log in
     *
     * Pre-Conditions: Floating Associate Username and password
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*//*
    @Test(priority = 7, description = "To validate Floating Associate/user clicking accept to log in")
    public void tc_7_Guest_Associate_clicking_to_login() {
        System.out.println(">>>tc_7_Guest_Associate_clicking_to_login<<<");

        // Step 1 Launch the connexus application from the connexus desktop |
        // Connexus launches and opens log in screen
        loginScreenUatTestSet1Scripts.launchConnexusWithAdFlagFalse();

        // Step 2 Click into username field | Cursor blinks in the username
        // field awaiting user input
        loginScreenUatTestSet1Scripts.clickUserNameTextFieldOnOldLoginScreen();

        // Step 3 Enter username | Username appears as typed in the username
        // field
        loginScreenUatTestSet1Scripts.enterRphUserNameInLoginScreenUserNameTextField();

        // Step 4 Press Tab on the keyboard to move to password field | Password
        // field should activate
        loginScreenUatTestSet1Scripts.pressTabKeyToMoveToPasswordField();

        // Step 5 Enter password for user account into the field | The entered
        // password should be hidden
        loginScreenUatTestSet1Scripts.enterRphPasswordInLoginScreenPasswordField();
        loginScreenUatTestSet1Scripts.validatePasswordFieldIsHidden();

        // Step 6 Click the Checkbox for change store number and enter the users
        // home store number | Connexus should allow the user to type their home
        // store number in the box
        loginScreenUatTestSet1Scripts.clickChangeStoreCheckBoxInLoginScreen();
        loginScreenUatTestSet1Scripts.enterStoreNumberInOldLoginScreenStoreNumberTextField();

        // Step 6 Press enter on the keyboard | Connexus should begin the
        // process and bring up the security warning prompt
        loginScreenUatTestSet1Scripts.clickAcceptInLoginScreen();
        loginScreenUatTestSet1Scripts.validateSecurityWarningPromptIsDisplayed();

        // Additional step to close the login screen so that next test will
        // continue
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseSecurityWarningPrompt();
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseLoginScreen();

        System.out.println("<<<tc_7_Guest_Associate_clicking_to_login>>>");
    }
*/
    /*----------------------------------------------------------------------------------------------------------
     * Test Description: To validate a Homeoffice associate/user using enter to
     * accept login
     *
     * Pre-Conditions: Homeoffice username and password
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    /*@Test(priority = 8, description = "To validate a Homeoffice associate/user using enter to accept login")
    public void HWPHME2E_1243_Homeoffice_associate_using_enter_to_login() {
        System.out.println(">>>HWPHME2E_1243_Homeoffice_associate_using_enter_to_login<<<");
        connexusAppUtils.getStoreId();

        // Step 1 Launch the connexus application from the connexus desktop |
        // Connexus launches and opens log in screen
        loginScreenUatTestSet1Scripts.launchConnexusWithAdFlagFalse();

        // Step 2 Click into username field | Cursor blinks in the username
        // field awaiting user input
        loginScreenUatTestSet1Scripts.clickUserNameTextFieldOnOldLoginScreen();

        // Step 3 Enter username | Username appears as typed in the username
        // field
        loginScreenUatTestSet1Scripts.enterUserNameInOldLoginScreenUserNameTextField();

        // Step 4 Press Tab on the keyboard to move to password field | Password
        // field should activate
        loginScreenUatTestSet1Scripts.pressTabKeyToMoveToPasswordField();

        // Step 5 Enter password for user account into the field | The entered
        // password should be hidden
        loginScreenUatTestSet1Scripts.enterPasswordInLoginScreenPasswordField();

        // Step 6 Click the Checkbox for HOMEOFFICE and enter the users home
        // store number | Connexus should select HOMEOFFICE in the dropdown menu
        loginScreenUatTestSet1Scripts.clickChangeStoreCheckBoxInLoginScreen();
        loginScreenUatTestSet1Scripts.enterHomeOfficeInOldLoginScreenStoreNumberTextField();

        // Step 7 Press enter on the keyboard | Connexus should begin the
        // process and bring up the security warning prompt
        loginScreenUatTestSet1Scripts.pressEnterKeyToBeginLogin();
        loginScreenUatTestSet1Scripts.validateSecurityWarningPromptIsDisplayed();

        // Additional step to close the login screen so that next test will
        // continue
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseSecurityWarningPrompt();
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseLoginScreen();

        System.out.println("<<<HWPHME2E_1243_Homeoffice_associate_using_enter_to_login>>>");
    }

    *//*----------------------------------------------------------------------------------------------------------
     * Test Description: To validate a Homeoffice associate/user clicking to
     * accept login
     *
     * Pre-Conditions: Homeoffice username and password
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*//*
    @Test(priority = 9, description = "To validate a Homeoffice associate/user clicking to accept login")
    public void HWPHME2E_1244_Homeoffice_user_clicking_to_login() {
        System.out.println(">>>HWPHME2E_1244_Homeoffice_user_clicking_to_login<<<");
        connexusAppUtils.getStoreId();

        // Step 1 Launch the connexus application from the connexus desktop |
        // Connexus launches and opens log in screen
        loginScreenUatTestSet1Scripts.launchConnexusWithAdFlagFalse();

        // Step 2 Click into username field | Cursor blinks in the username
        // field awaiting user input
        loginScreenUatTestSet1Scripts.clickUserNameTextFieldOnOldLoginScreen();

        // Step 3 Enter username | Username appears as typed in the username
        // field
        loginScreenUatTestSet1Scripts.enterUserNameInOldLoginScreenUserNameTextField();

        // Step 4 Press Tab on the keyboard to move to password field | Password
        // field should activate
        loginScreenUatTestSet1Scripts.pressTabKeyToMoveToPasswordField();

        // Step 5 Enter password for user account into the field | The entered
        // password should be hidden
        loginScreenUatTestSet1Scripts.enterPasswordInLoginScreenPasswordField();

        // Step 6 Click the Checkbox for HOMEOFFICE and enter the users home
        // store number | Connexus should select HOMEOFFICE in the dropdown menu
        loginScreenUatTestSet1Scripts.clickChangeStoreCheckBoxInLoginScreen();
        loginScreenUatTestSet1Scripts.enterHomeOfficeInOldLoginScreenStoreNumberTextField();

        // Step 7 Click accept | Connexus should begin the process and bring up
        // the security warning prompt
        loginScreenUatTestSet1Scripts.clickAcceptInLoginScreen();
        loginScreenUatTestSet1Scripts.validateSecurityWarningPromptIsDisplayed();

        // Additional step to close the login screen so that next test will
        // continue
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseSecurityWarningPrompt();
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseLoginScreen();

        System.out.println("<<<HWPHME2E_1244_Homeoffice_user_clicking_to_login>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: To validate a user declining the security prompt
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
   /* @Test(priority = 10, description = "To validate a user declining the security prompt")
    public void tc_10_User_declines_security_prompt_at_login() {
        System.out.println(">>>tc_10_User_declines_security_prompt_at_login<<<");

        // Step 1 Fill in the login details and click accept | Security Prompt
        // should appear
        loginScreenUatTestSet1Scripts.launchConnexusWithAdFlagFalse();
        loginScreenUatTestSet1Scripts.clickUserNameTextFieldOnOldLoginScreen();
        loginScreenUatTestSet1Scripts.enterUserNameInLoginScreenUserNameTextField();
        loginScreenUatTestSet1Scripts.pressTabKeyToMoveToPasswordField();
        loginScreenUatTestSet1Scripts.enterPasswordInLoginScreenPasswordField();
        loginScreenUatTestSet1Scripts.clickChangeStoreCheckBoxInLoginScreen();
        loginScreenUatTestSet1Scripts.enterHomeOfficeInOldLoginScreenStoreNumberTextField();
        loginScreenUatTestSet1Scripts.clickAcceptInLoginScreen();
        loginScreenUatTestSet1Scripts.validateSecurityWarningPromptIsDisplayed();

        // Step 2 Click Decline | Connexus should reject the log in
        loginScreenUatTestSet1Scripts.clickDeclineInSecurityWarningPrompt();
        loginScreenUatTestSet1Scripts.validateLoginRejection();

        // Additional step to close the login screen so that next test will
        // continue
        loginScreenUatTestSet1Scripts.pressEscapeKeyToCloseLoginScreen();

        System.out.println("<<<tc_10_User_declines_security_prompt_at_login>>>");
    }

    *//*----------------------------------------------------------------------------------------------------------
     * Test Description: To validate a user accepting the security prompt
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*//*
    @Test(priority = 11, description = "To validate a user accepting the security prompt")
    public void tc_11_User_accepts_security_prompt_at_login() {
        System.out.println(">>>tc_11_User_accepts_security_prompt_at_login<<<");

        // Step 1 Fill in the login details and click accept | Security prompt
        // should appear
        loginScreenUatTestSet1Scripts.launchConnexusWithAdFlagFalse();
        loginScreenUatTestSet1Scripts.clickUserNameTextFieldOnOldLoginScreen();
        loginScreenUatTestSet1Scripts.enterUserNameInLoginScreenUserNameTextField();
        loginScreenUatTestSet1Scripts.pressTabKeyToMoveToPasswordField();
        loginScreenUatTestSet1Scripts.enterPasswordInLoginScreenPasswordField();
        loginScreenUatTestSet1Scripts.clickChangeStoreCheckBoxInLoginScreen();
        loginScreenUatTestSet1Scripts.enterHomeOfficeInOldLoginScreenStoreNumberTextField();
        loginScreenUatTestSet1Scripts.clickAcceptInLoginScreen();
        loginScreenUatTestSet1Scripts.validateSecurityWarningPromptIsDisplayed();

        // Step 2 Click accept | Connexus should continue the log in and bring
        // up the main connexus screen
        loginScreenUatTestSet1Scripts.clickAcceptInSecurityWarningPrompt();
        loginScreenUatTestSet1Scripts.validateMainScreenIsDisplayed();

        // Additional step to close the login screen so that next test will
        // continue
        loginScreenUatTestSet1Scripts.pressAltF4KeyToCloseApplication();

        System.out.println("<<<tc_11_User_accepts_security_prompt_at_login>>>");
    }*/
}