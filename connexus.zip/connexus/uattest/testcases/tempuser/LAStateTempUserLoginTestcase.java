package connexus.uattest.testcases.tempuser;

import connexus.uattest.testscripts.TempUserTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LAStateTempUserLoginTestcase {
    TempUserTestScripts tempusertestscripts = new TempUserTestScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    PropertyReader propertyReader = PropertyReader.getInstance();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();

    @BeforeClass
    public void loginToConnexus() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }
  /*----------------------------------------------------------------------------------------------------------
          * Validate Login override pop up displayed with Authentication message and Override, Cancel buttons
          * Author: Vignesh Rajendran
          * Prerequisite:
           1. State of the test box should be set to LA
           2. Credentials available for an temp pharmacist with valid license
           3. Run the query : SELECT restrict_type_val FROM agency_rqmt_parm where restrict_type_code =31651 and issue_agency_code =218; - It should be set to Y
          ----------------------------------------------------------------------------------------------------------*/

    @Test(priority = 1, description = "Validate_Authentication_message_For_Temp_Pharmacist_trying_login_Connexus_With_State_LA")
    public void HWPHME2E_559_Validate_Authentication_message_For_Temp_Pharmacist_trying_login_Connexus_With_State_LA() {
        connexusAppUtils.getStoreId();
        Reporter.log("HWPHME2E-559: Validate Login override pop up displayed with Authentication message and Override, Cancel buttons");
        connexusAppUtils.updateStoreState("LA");
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "31651", "218");
        String siteId = propertyReader.getProperty("cnx.store");
        connexusAppUtils.callFlushCacheAPI(siteId);
        connexusAPIManager.restartConnexusService(siteId);
        tempusertestscripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        tempusertestscripts.validateLoginOverridePopWithWarningMessageAndOverrideAndCancelButtonsIsDisplayed();
        Reporter.log("Login override pop up displayed with Authentication message and Override, Cancel buttons");
        tearDown();


    }
     /*----------------------------------------------------------------------------------------------------------
          * Validate Login override pop up displayed with Authentication message and Override, Cancel buttons
          * Author: Vignesh Rajendndran
          * Prerequisite:
                           1. State of the test box should be set to LA
                           2. Credentials available for an temp technician with valid license
                           3. Run the query : SELECT restrict_type_val FROM agency_rqmt_parm where restrict_type_code =31651 and issue_agency_code =218; - It should be set to Y
                           4. Flag-28750 - TRUE -update bu_phm_parm set phm_parm_value='TRUE' where phm_parm_code = 28750;
          ----------------------------------------------------------------------------------------------------------*/

    @Test(priority = 2, description = "Validate_Authentication_message_For_Temp_Technician_trying_login_Connexus_With_State_LA")
    public void HWPHME2E_560_Validate_Authentication_message_For_Temp_Technician_trying_login_Connexus_With_State_LA() {
        connexusAppUtils.getStoreId();
        Reporter.log("HWPHME2E-560: Validate Login override pop up displayed with Authentication message and Override, Cancel buttons");
        connexusAppUtils.updateStoreState("LA");
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "31651", "218");
        connexusAppUtils.readAndUpdateFlag("28750", "TRUE");
        String siteId1 = propertyReader.getProperty("cnx.store");
        connexusAppUtils.callFlushCacheAPI(siteId1);
        connexusAPIManager.restartConnexusService(siteId1);
        tempusertestscripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        tempusertestscripts.validateLoginOverridePopWithWarningMessageAndOverrideButtonsIsDisplayed();
        Reporter.log("Login override pop up displayed with Authentication message and Override, Cancel buttons");

    }

}
