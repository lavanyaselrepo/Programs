package connexus.uattest.testcases.dropoffscreen;

import connexus.uattest.testscripts.DropOffScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LeftBarWorkQueues;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.DropOffPage;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class DropOffScreenUatTestSet21 {
    DropOffScreenUatTestScripts dropOffScreenUatTestScripts = new DropOffScreenUatTestScripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusStartPage connexusStartPage;
    DropOffPage dropOffPage;
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();


    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils.startAppiumServer();
        connexusStartPage = new ConnexusStartPage();
        dropOffPage = new DropOffPage();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Using an RX number in the drop off patient search box and pressing enter to look up a patient        
     *              
     * Pre-Conditions:Patient in local DB      
     *              
     * Author: Ashok(Vn50h3h)                
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-506")
    @Test(priority = 1)
    public void HWPHME2E_506_Search_patient_by_Using_Rx_number_and_press_enter_in_dropoff_page() {
        Reporter.log("Search patient by entering Rx number and press enter keyword in Drop off Page");
        connexusAppUtils.getStoreId();

        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear

        // Step 3 Click in the Patient search box and type the RX Number |
        // Patient Seach box should accept input
        dropOffScreenUatTestScripts.inputRxNumberInPtSearchBox();

        // Step 4 Press Enter | Connexus should begin searching for the RX
        // number and bring up the patient profile if the RX number exists and
        // place the rx in the order queue on the right side of the screen
        connexusStartPage.pressEnterKey();

        dropOffScreenUatTestScripts.validateRxFromRightSideRxQueue();

        Reporter.log("Validate Patient details should be displayed with RX number in drop off page");
    }


    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using an RX number in the drop off patient search box and clicking on the three dot icon to look up a patient
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-507")
   /* @Test(priority = 277)
    public void HWPHME2E_507_Search_patient_by_Using_Rx_number_and_click_three_dot_icon_dropoff_page() {
        Reporter.log("Search patient by entering Rx number and click on 3 dots in Drop off Page");

        connexusAppUtils.getStoreId();

        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.DROP_OFF_ICON);

        // Step 3 Click in the Patient search box and type the RX Number |
        // Patient Seach box should accept input
        dropOffScreenUatTestScripts.inputRxNumberInPtSearchBox();

        // Step 4 Click on the three dots next to the patient search box |
        // Connexus should begin searching for the RX number and bring up the
        // patient profile if the RX number exists and place the rx in the order
        // queue on the right side of the screen
        dropOffPage.clickPatientSearch();
        dropOffScreenUatTestScripts.validateRxFromRightSideRxQueue();

        Reporter.log("Validate Patient details should be displayed with RX number in drop off page");
    }*/


    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using a date of birth (mm/dd/yyyy) in the drop off patient search box and pressing enter then selecting the patient if they exist
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-508")
    @Test(priority = 2)
    public void HWPHME2E_508_Search_patient_by_entering_date_of_birth_in_mm_dd_yyyy_format_and_enter() {
        Reporter.log("Search patient by entering DOB (mm/dd/yyyy) and press enter in Drop off Page");
        connexusAppUtils.getStoreId();
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear

        // Step 3 Click in the Patient search box and type the DOB (mm/dd/yyyy)
        // | Patient Seach box should accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.NA, DropOffScreenUatTestScripts.DateFormatEnum.MMDDYYYY);

        // Step 4 Press enter | Connexus should begin searching for the patient
        // by DOB and bring up the patient profile if the that is the only
        // patient with that date of birth. Otherwiase it will bring up a list
        // of patients with a matching DOB
        connexusStartPage.pressEnterKey();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Using a date of birth (mm/dd/yy) in the drop off patient search box and pressing enter then selecting the patient if they exist
    *
    * Pre-Conditions:Patient in local DB
    *
    * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-509")
    @Test(priority = 3)
    public void HWPHME2E_509_Search_patient_by_entering_date_of_birth_in_mm_dd_yy_format_and_enter() {
        Reporter.log("Search patient by entering DOB (mm/dd/yy) and press enter in Drop off Page");
        connexusAppUtils.getStoreId();

        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 3 Click in the Patient search box and type the DOB (mm/dd/yy
        // | Patient Seach box should accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.NA, DropOffScreenUatTestScripts.DateFormatEnum.MMDDYY);

        // Step 4 Press enter | Connexus should begin searching for the patient
        // by DOB and bring up the patient profile if the that is the only
        // patient with that date of birth. Otherwiase it will bring up a list
        // of patients with a matching DOB
        connexusStartPage.pressEnterKey();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }


    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using a date of birth (mm/dd/yyyy) in the drop off patient search box and clicking the 3 dot icon then selecting the patient if they exist
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-510")
    @Test(priority = 4)
    public void HWPHME2E_510_Search_patient_by_entering_date_of_birth_in_mm_dd_yyyy_format_and_click_button_with_three_dots() {
        Reporter.log("Search patient by entering DOB (mm/dd/yyyy) and click on three dot button in Drop off Page");
        connexusAppUtils.getStoreId();
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        // Step 3 Click in the Patient search box and type the DOB (mm/dd/yyyy)
        // | Patient Seach box should accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.NA, DropOffScreenUatTestScripts.DateFormatEnum.MMDDYYYY);

        // Step 4 Click on the three dots next to the patient search box |
        // Connexus should begin searching for the patient by DOB and bring up
        // the patient profile if the that is the only patient with that date of
        // birth. Otherwiase it will bring up a list of patients with a matching
        // DOB
        dropOffPage.clickPatientSearch();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using a date of birth (mm/dd/yy) in the drop off patient search box and clicking the 3 dot icon then selecting the patient if they exist
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-511")
    @Test(priority = 5)
    public void HWPHME2E_511_Search_patient_by_entering_date_of_birth_in_mm_dd_yy_format_and_click_button_with_three_dots() {
        Reporter.log("Search patient by entering DOB (mm/dd/yy) and click on three dot button in Drop off Page");
        connexusAppUtils.getStoreId();
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        // Step 3 Click in the Patient search box and type the DOB (mm/dd/yy)
        // | Patient Seach box should accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.NA, DropOffScreenUatTestScripts.DateFormatEnum.MMDDYY);

        // Step 4 Click on the three dots next to the patient search box |
        // Connexus should begin searching for the patient by DOB and bring up
        // the patient profile if the that is the only patient with that date of
        // birth. Otherwiase it will bring up a list of patients with a matching
        // DOB
        dropOffPage.clickPatientSearch();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using the patients name (Last NameFirst Name) in the patient search box and pressing enter
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
   /* //@Jira(testID = "HWPHME2E-512") //obsoleted
    //@Test(priority = 282)
    public void HWPHME2E_512_Search_patient_by_name_LN_FN_and_press_enter() {
        Reporter.log("Search patient by entering Lastname, Firstname and press enter in Drop off Page");
        connexusAppUtils.getStoreId();

        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.DROP_OFF_ICON);

        // Step 3 Click in the Patient Search box and type patient name(Last
        // NameFirst name) | Patient Seach box should accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.LNFN, DropOffScreenUatTestScripts.DateFormatEnum.NA);

        // Step 4 Press Enter | Connexus should begin searching for the
        // patient
        // by name and bring up the patient profile if the that is the only
        // patient with that exact name. Otherwiase it will bring up a list of
        // patients with matching names
        connexusStartPage.pressEnterKey();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using the patients name (First name {space} Last name) in the patient search box and pressing enter
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-513")
    @Test(priority = 6)
    public void HWPHME2E_513_Search_patient_by_name_FN_LN_and_press_enter() {
        Reporter.log("Search patient by entering Firstname, Lastname and press enter in Drop off Page");
        connexusAppUtils.getStoreId();
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen Should appear

        // Step 3 Click in the Patient Search box and type the patient name
        // (First name Last Name) | Patient Seach box should accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.FNLN, DropOffScreenUatTestScripts.DateFormatEnum.NA);

        // Step 4 Press Enter | Connexus should begin searching for the patient
        // by name and bring up the patient profile if the that is the only
        // patient with that exact name. Otherwiase it will bring up a list of
        // patients with matching names
        connexusStartPage.pressEnterKey();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using the patients name (Last NameFirst Name) in the patient search box and clicking the three dot icon/button
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-514")
    /*@Test(priority = 284)
    public void HWPHME2E_514_Search_patient_by_name_LN_FN_and_click_button_with_three_dots() {
        Reporter.log("Search patient by entering Lastname, Firstname and click on search button in Drop off Page");
        connexusAppUtils.getStoreId();

        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.DROP_OFF_ICON);

        // Step 3 Click in the Patient Search box and type the patient name
        // (Last NameFirst Name) | Patient Seach box should accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.LNFN, DropOffScreenUatTestScripts.DateFormatEnum.NA);

        // Step 4 Click on the three dots next to the patient search box |
        // Connexus should begin searching for the patient by name and bring up
        // the patient profile if the that is the only patient with that exact
        // name. Otherwiase it will bring up a list of patients with matching
        // names
        dropOffPage.clickPatientSearch();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }*/

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using the patients name (First Name Last Name) in the patient search box and clicking the three dot icon/button
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-515")
    @Test(priority = 7)
    public void HWPHME2E_515_Search_patient_by_name_FN_LN_and_click_button_with_three_dots() {
        Reporter.log("Search patient by entering Firstname, Lastname and click on search button in Drop off Page");
        connexusAppUtils.getStoreId();
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        // Step 3 Click in the Patient Search box and type the patient name
        // () | Patient Seach box should accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.FNLN, DropOffScreenUatTestScripts.DateFormatEnum.NA);

        // Step 4 Click on the three dots next to the patient search box |
        // Connexus should begin searching for the patient by name and bring up
        // the patient profile if the that is the only patient with that exact
        // name. Otherwiase it will bring up a list of patients with matching
        // names
        dropOffPage.clickPatientSearch();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using the patients name (Last NameFirst Name) and the date of birth (MM/DD/YY) in the patient search box and pressing enter
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-516")
    @Test(priority = 8)
    public void HWPHME2E_516_search_patient_by_using_LN_FN_and_dob_MM_DD_YY_in_pt_search_box_and_press_enter() {
        Reporter.log("Search patient by entering Lastname, Firstname with DOB in MM_DD_YY format and press enter keyword in Drop off Page");
        connexusAppUtils.getStoreId();
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        // Step 3 Click in the Patient Search box and type the patient name
        // (Last NameFirst Name) and DOB MM/DD/YYYY | Patient Seach box should
        // accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.LNFN, DropOffScreenUatTestScripts.DateFormatEnum.MMDDYY);

        // Step 4 Press Enter | Connexus should begin searching for the patient
        // by name and bring up the patient profile if the that is the only
        // patient with that exact name. Otherwiase it will bring up a list of
        // patients with matching names
        connexusStartPage.pressEnterKey();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using the patients name (First Name {Space} Last Name) and dob (MM/DD/YY) in the patient search box and pressing enter
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-517")
    @Test(priority = 9)
    public void HWPHME2E_517_search_patient_by_using_FN_LN_and_dob_MM_DD_YY_in_pt_search_box_and_press_enter() {
        Reporter.log("Search patient by entering Firstname, Lastname with DOB in MM_DD_YY format and press enter keyword in Drop off Page");
        connexusAppUtils.getStoreId();
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        // Step 3 Click in the Patient Search box and type the patient name
        // (First Name {Space} Last Name) and DOB MM/DD/YYYY | Patient Seach box
        // should
        // accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.FNLN, DropOffScreenUatTestScripts.DateFormatEnum.MMDDYY);

        // Step 4 Press Enter | Connexus should begin searching for the patient
        // by name and bring up the patient profile if the that is the only
        // patient with that exact name. Otherwiase it will bring up a list of
        // patients with matching names
        connexusStartPage.pressEnterKey();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using the patients name (Last NameFirst Name) and the date of birth (MM/DD/YYYY) in the patient search box and pressing enter
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-518")
    @Test(priority = 10)
    public void HWPHME2E_518_search_patient_by_using_LN_FN_and_dob_MM_DD_YYYY_in_pt_search_box_and_press_enter() {
        Reporter.log("Search patient by entering Lastname, Firstname with DOB in MM_DD_YYYY format and press enter keyword in Drop off Page");
        connexusAppUtils.getStoreId();
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        // Step 3 Click in the Patient Search box and type the patient name
        // (Last NameFirst Name) and DOB MM/DD/YYYY | Patient Seach box should
        // accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.LNFN, DropOffScreenUatTestScripts.DateFormatEnum.MMDDYYYY);

        // Step 4 Press Enter | Connexus should begin searching for the patient
        // by name and bring up the patient profile if the that is the only
        // patient with that exact name. Otherwiase it will bring up a list of
        // patients with matching names
        connexusStartPage.pressEnterKey();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using the patients name (First Name {Space} Last Name) and dob (MM/DD/YYYY) in the patient search box and pressing enter
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-519")
    @Test(priority = 11)
    public void HWPHME2E_519_search_patient_by_using_FN_LN_and_dob_MM_DD_YYYY_in_pt_search_box_and_press_enter() {
        Reporter.log("Search patient by entering Firstname, Lastname with DOB in MM_DD_YYYY format and press enter keyword in Drop off Page");
        connexusAppUtils.getStoreId();
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        // Step 3 Click in the Patient Search box and type the patient name
        // (First Name {Space} Last Name) and DOB MM/DD/YYYY | Patient Seach box
        // should accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.FNLN, DropOffScreenUatTestScripts.DateFormatEnum.MMDDYYYY);

        // Step 4 Press Enter | Connexus should begin searching for the patient
        // by name and bring up the patient profile if the that is the only
        // patient with that exact name. Otherwiase it will bring up a list of
        // patients with matching names
        connexusStartPage.pressEnterKey();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using the patients name (Last NameFirst Name) and the date of birth (MM/DD/YY) in the patient search box and clicking the three dot icon
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-520")
    @Test(priority = 12)
    public void HWPHME2E_520_search_patient_by_using_LN_FN_and_dob_MM_DD_YY_in_pt_search_box_and_click_3dot_button() {
        Reporter.log("Search patient by entering Lastname, Firstname with DOB in MM_DD_YY format and click search button in Drop off Page");
        connexusAppUtils.getStoreId();
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        // Step 3 Click in the Patient Search box and type the patient name
        // (Last NameFirst Name) and DOB MM/DD/YYYY | Patient Seach box should
        // accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.LNFN, DropOffScreenUatTestScripts.DateFormatEnum.MMDDYY);

        // Step 4 Click on 3dot button | Connexus should begin searching for the
        // patient
        // by name and bring up the patient profile if the that is the only
        // patient with that exact name. Otherwiase it will bring up a list of
        // patients with matching names
        dropOffPage.clickPatientSearch();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using the patients name (First Name {Space} Last Name) and dob (MM/DD/YY) in the patient search box and click on 3dot button
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-521")
    @Test(priority = 13)
    public void HWPHME2E_521_search_patient_by_using_FN_LN_and_dob_MM_DD_YY_in_pt_search_box_and_click_3dot_button() {
        Reporter.log("Search patient by entering Firstname, Lastname with DOB in MM_DD_YY format and click search button in Drop off Page");
        connexusAppUtils.getStoreId();
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        // Step 3 Click in the Patient Search box and type the patient name
        // (First Name {Space} Last Name) and DOB MM/DD/YYYY | Patient Seach box
        // should accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.FNLN, DropOffScreenUatTestScripts.DateFormatEnum.MMDDYY);

        // Step 4 click 3dot button | Connexus should begin searching for the
        // patient
        // by name and bring up the patient profile if the that is the only
        // patient with that exact name. Otherwiase it will bring up a list of
        // patients with matching names
        dropOffPage.clickPatientSearch();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using the patients name (Last NameFirst Name) and the date of birth (MM/DD/YYYY) in the patient search box and click 3dot button
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-522")
    @Test(priority = 14)
    public void HWPHME2E_522_search_patient_by_using_LN_FN_and_dob_MM_DD_YYYY_in_pt_search_box_and_click_3dot_button() {
        Reporter.log("Search patient by entering Lastname, Firstname with DOB in MM_DD_YYYY format and click search button in Drop off Page");
        connexusAppUtils.getStoreId();
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        // Step 3 Click in the Patient Search box and type the patient name
        // (Last NameFirst Name) and DOB MM/DD/YYYY | Patient Seach box should
        // accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.LNFN, DropOffScreenUatTestScripts.DateFormatEnum.MMDDYYYY);


        // Step 4 click 3dot button | Connexus should begin searching for the
        // patient
        // by name and bring up the patient profile if the that is the only
        // patient with that exact name. Otherwiase it will bring up a list of
        // patients with matching names
        dropOffPage.clickPatientSearch();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Using the patients name (First Name {Space} Last Name) and dob (MM/DD/YYYY) in the patient search box and pressing enter
     *
     * Pre-Conditions:Patient in local DB
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-523")
    @Test(priority = 15)
    public void HWPHME2E_523_search_patient_by_using_FN_LN_and_dob_MM_DD_YYYY_in_pt_search_box_and_click_3dot_button() {
        Reporter.log("Search patient by entering Firstname, Lastname with DOB in MM_DD_YYYY format and click search button in Drop off Page");
        connexusAppUtils.getStoreId();
        dropOffScreenUatTestScripts.initializeTestCase(false);
        // Step 1 Log In to Connexus | Connexus should bring up the main screen
        // Step 2 Click Drop-off | Drop-off Screen should appear
        // Step 3 Click in the Patient Search box and type the patient name
        // (First Name {Space} Last Name) and DOB MM/DD/YYYY | Patient Seach box
        // should accept input
        dropOffScreenUatTestScripts.inputPtNameAndDobInPtSearchBox(DropOffScreenUatTestScripts.NameFormatEnum.FNLN, DropOffScreenUatTestScripts.DateFormatEnum.MMDDYYYY);

        // Step 4 click 3dot button | Connexus should begin searching for the
        // patient
        // by name and bring up the patient profile if the that is the only
        // patient with that exact name. Otherwiase it will bring up a list of
        // patients with matching names
        dropOffPage.clickPatientSearch();

        // Step 5 Select Patient by double clicking | Patient Profile should
        // load on screen
        dropOffScreenUatTestScripts.selectAndValidatePatientFromSearchWindow();

        Reporter.log("Validate Patient details should be displayed in drop off page");
    }
}
