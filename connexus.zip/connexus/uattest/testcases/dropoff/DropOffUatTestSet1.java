package connexus.uattest.testcases.dropoff;

import connexus.coretest.testscripts.UserExperienceTestSetScript;
import connexus.uattest.testscripts.DropOffScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import hwqe.baseframework.utilities.Reporter;

import java.util.Map;

public class DropOffUatTestSet1 {

    public static int totalCount = 0;
    ConnexusAppUtils connexusAppUtils;
    DropOffScreenUatTestScripts dropOffScreenUatTestScripts = new DropOffScreenUatTestScripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    boolean flagUpdated = false;

    @BeforeClass
    public void performlogin() {
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
          * Test Description: Drop Multiple prescriptions in DropOff page
          * PreCondition
          * 1. Update Flag 9325 to TRUE
          * Author: Tarun Upputuri(vn510o1)
        ----------------------------------------------------------------------------------------------------------*/
    //Duplicate covered in other Test Case.
  /*  @Test(description = "Drop Multiple prescriptions in DropOff page.",
            enabled = false ,priority = 76, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DropOffscreen/DropOffUatTestSet1DataBook.json", sheetName = "DropOffUat")
    public void tc_76_dropOff_Multiple_Prescriptions(Map<String, String> inputData) {
        System.out.println(">>>tc_76_dropOff_Multiple_Prescriptions<<<");

        //PreCondition
        //1. Update Flag 9325 to TRUE[

        //1. Log in to Connexus | Connexus should bring up the main screen
        //2. Click Drop-off | Drop-off Screen should appear
        //3. Select a Patient | Patient information and Prescription history should appear
        //4. Add multiple prescriptions to the order from the patients prescription history | The prescriptions selected should appear in the order on the right side of the screen.
        tearDown();
        connexusAppUtils.readAndUpdateFlag("9325", "TRUE");
        dropOffScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        dropOffScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        userExperienceTestSetScript.createPatient(inputData);
        dropOffScreenUatTestScripts.addMultiplePrescriptionsAndValidate(inputData);
        int input = DropOffUatTestSet1.totalCount + Integer.parseInt(inputData.get("COUNT"));
        int count = dropOffScreenUatTestScripts.validateRxRecordCount(input);
        DropOffUatTestSet1.totalCount = input + count;

        System.out.println("<<<tc_76_dropOff_Multiple_Prescriptions>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
          * Test Description: Drop Multiple prescriptions with Priority as InStore and Dispense Type as Counter Pickup.
          * PreCondition
          * 1. Update Flag 9325 to TRUE
          * Author: Tarun Upputuri(vn510o1)
          ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Drop Multiple prescriptions with Priority as InStore and Dispense Type as Counter Pickup.",
            enabled = true, priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DropOffscreen/DropOffUatTestSet1DataBook.json", sheetName = "DropOffUat")
    public void HWPHME2E_497_Drop_Multiple_Prescriptions_with_Priority_as_InStore(Map<String, String> inputData) {

        //PreCondition
        // 1. Update Flag 9325 to TRUE

        //1. Log in to Connexus | Connexus should bring up the main screen
        //2. Click Drop-off | Drop-off Screen should appear
        //3. Select a Patient | Patient information and Prescription history should appear
        //4. Add multiple prescriptions to the order from the patients prescription history | The prescriptions selected should appear in the order on the right side of the screen.
        flagUpdated = connexusAppUtils.readAndUpdateFlag("9325", "TRUE");
        dropOffScreenUatTestScripts.initializeTestCase(flagUpdated);
        dropOffScreenUatTestScripts.createNewPatient(inputData);
        dropOffScreenUatTestScripts.addMultiplePrescriptionsAndValidate(inputData);
        // Calculate total expected records: cumulative count from prior tests + new Rx added in this test
        int input = DropOffUatTestSet1.totalCount + Integer.parseInt(inputData.get("COUNT"));
        // Validate total record count, priority, and priority-specific count in Order Search; returns actual record count
        int count = dropOffScreenUatTestScripts.validateRxRecordCount(input, inputData.get("PRIORITY"), Integer.parseInt(inputData.get("COUNT")));
        // Update cumulative total for subsequent tests: expected + actual (accounts for pre-existing records in Order Search)
        DropOffUatTestSet1.totalCount = input + count;

    }



    /*----------------------------------------------------------------------------------------------------------
          * Test Description: Drop Multiple prescriptions with Priority as Today and Dispense Type as Counter Pickup
          * PreCondition
          * 1. Update Flag 9325 to TRUE
          * Author: Tarun Upputuri(vn510o1)
          ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Drop Multiple prescriptions with Priority as Today and Dispense Type as Counter Pickup.",
            enabled = true , priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DropOffscreen/DropOffUatTestSet1DataBook.json", sheetName = "DropOffUat")
    public void HWPHME2E_498_Drop_Multiple_Prescriptions_with_Priority_as_Today(Map<String, String> inputData) {

        //PreCondition
        //1. Update Flag 9325 to TRUE

        //1. Log in to Connexus | Connexus should bring up the main screen
        //2. Click Drop-off | Drop-off Screen should appear
        //3. Select a Patient | Patient information and Prescription history should appear
        //4. Add multiple prescriptions to the order from the patients prescription history | The prescriptions selected should appear in the order on the right side of the screen.
        dropOffScreenUatTestScripts.addMultiplePrescriptionsAndValidate(inputData);
        dropOffScreenUatTestScripts.validateRxRecordCount(DropOffUatTestSet1.totalCount, inputData.get("PRIORITY"), Integer.parseInt(inputData.get("COUNT")));
        DropOffUatTestSet1.totalCount = DropOffUatTestSet1.totalCount + Integer.parseInt(inputData.get("COUNT"));

    }

    /*----------------------------------------------------------------------------------------------------------
          * Test Description: Drop Multiple prescriptions with Priority as DrCallIn and Dispense Type as Counter Pickup
          * PreCondition
          * 1. Update Flag 9325 to TRUE
          * Author: Tarun Upputuri(vn510o1)
          ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Drop Multiple prescriptions with Priority as DrCallIn and Dispense Type as Counter Pickup",
            enabled = true , priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DropOffscreen/DropOffUatTestSet1DataBook.json", sheetName = "DropOffUat")
    public void HWPHME2E_499_Drop_Multiple_Prescriptions_with_Priority_as_DrCallIn(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_499_dropOff_Counter_Pickup_DrCallIn_Multiple_Prescription<<<");

        //PreCondition
        //1. Update Flag 9325 to TRUE

        //1. Log in to Connexus | Connexus should bring up the main screen
        //2. Click Drop-off | Drop-off Screen should appear
        //3. Select a Patient | Patient information and Prescription history should appear
        //4. Add multiple prescriptions to the order from the patients prescription history | The prescriptions selected should appear in the order on the right side of the screen.
        dropOffScreenUatTestScripts.addMultiplePrescriptionsAndValidate(inputData);
        dropOffScreenUatTestScripts.validateRxRecordCount(DropOffUatTestSet1.totalCount, inputData.get("PRIORITY"), Integer.parseInt(inputData.get("COUNT")));
        DropOffUatTestSet1.totalCount = DropOffUatTestSet1.totalCount + Integer.parseInt(inputData.get("COUNT"));

    }

    /*----------------------------------------------------------------------------------------------------------
          * Test Description: Drop Multiple prescriptions with Priority as driveThru and Dispense Type as Counter Pickup
          * PreCondition
          * 1. Update Flag 9325 to TRUE
          * Author: Tarun Upputuri(vn510o1)
          ----------------------------------------------------------------------------------------------------------*/
    //Marked as obsolete
   /* @Test(description = "Drop Multiple prescriptions with Priority as DriveThru and Dispense Type as Counter Pickup",
            enabled = false , priority = 80, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DropOffscreen/DropOffUatTestSet1DataBook.json", sheetName = "DropOffUat")
    public void tc_80_dropOff_Counter_Pickup_DriveThru_Multiple_Prescription(Map<String, String> inputData) {
        System.out.println(">>>tc_80_dropOff_Counter_Pickup_DriveThru_Multiple_Prescription<<<");

        //PreCondition
        //1. Update Flag 9325 to TRUE

        //1. Log in to Connexus | Connexus should bring up the main screen
        //2. Click Drop-off | Drop-off Screen should appear
        //3. Select a Patient | Patient information and Prescription history should appear
        //4. Add multiple prescriptions to the order from the patients prescription history | The prescriptions selected should appear in the order on the right side of the screen.
        dropOffScreenUatTestScripts.addMultiplePrescriptionsAndValidate(inputData);
        int count = dropOffScreenUatTestScripts.validateRxRecordCount(DropOffUatTestSet1.totalCount);
        DropOffUatTestSet1.totalCount = DropOffUatTestSet1.totalCount + Integer.parseInt(inputData.get("COUNT"));

        System.out.println("<<<tc_80_dropOff_Counter_Pickup_DriveThru_Multiple_Prescription>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
          * Test Description: Drop Multiple prescriptions with Priority as Future and Dispense Type as Counter Pickup
          * PreCondition
          * 1. Update Flag 9325 to TRUE
          * Author: Tarun Upputuri(vn510o1)
          ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Drop Multiple prescriptions with Priority as Future and Dispense Type as Counter Pickup",
            enabled = true , priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DropOffscreen/DropOffUatTestSet1DataBook.json", sheetName = "DropOffUat")
    public void HWPHME2E_501_Drop_Multiple_Prescriptions_with_Priority_as_Future(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_501_dropOff_Counter_Pickup_Future_Multiple_Prescription<<<");

        //PreCondition
        //1. Update Flag 9325 to TRUE

        //1. Log in to Connexus | Connexus should bring up the main screen
        //2. Click Drop-off | Drop-off Screen should appear
        //3. Select a Patient | Patient information and Prescription history should appear
        //4. Add multiple prescriptions to the order from the patients prescription history | The prescriptions selected should appear in the order on the right side of the screen.
        dropOffScreenUatTestScripts.addMultiplePrescriptionsAndValidate(inputData);
        dropOffScreenUatTestScripts.validateRxRecordCount(DropOffUatTestSet1.totalCount, inputData.get("PRIORITY"), Integer.parseInt(inputData.get("COUNT")));
        DropOffUatTestSet1.totalCount = DropOffUatTestSet1.totalCount + Integer.parseInt(inputData.get("COUNT"));

    }

    /*----------------------------------------------------------------------------------------------------------
          * Test Description: Drop Multiple prescriptions with Priority as Critical and Dispense Type as Counter Pickup
          * PreCondition
          * 1. Update Flag 9325 to TRUE
          * Author: Tarun Upputuri(vn510o1)
          ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Drop Multiple prescriptions with Priority as Critical and Dispense Type as Counter Pickup.",
            enabled = true ,priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DropOffscreen/DropOffUatTestSet1DataBook.json", sheetName = "DropOffUat")
    public void HWPHME2E_502_Drop_Multiple_Prescriptions_with_Priority_as_Critical(Map<String, String> inputData) {
        System.out.println(">>>HWPHME2E_502_dropOff_Counter_Pickup_Critical_Multiple_Prescription<<<");

        //PreCondition
        //1. Update Flag 9325 to TRUE

        //1. Log in to Connexus | Connexus should bring up the main screen
        //2. Click Drop-off | Drop-off Screen should appear
        //3. Select a Patient | Patient information and Prescription history should appear
        //4. Add multiple prescriptions to the order from the patients prescription history | The prescriptions selected should appear in the order on the right side of the screen.
        dropOffScreenUatTestScripts.addMultiplePrescriptionsAndValidate(inputData);
        dropOffScreenUatTestScripts.validateRxRecordCount(DropOffUatTestSet1.totalCount, inputData.get("PRIORITY"), Integer.parseInt(inputData.get("COUNT")));
        DropOffUatTestSet1.totalCount = DropOffUatTestSet1.totalCount + Integer.parseInt(inputData.get("COUNT"));

    }

    /*----------------------------------------------------------------------------------------------------------
          * Test Description: Drop Multiple prescriptions with Priority as InStore In and Dispense Type as Curbside Pickup.
          * PreCondition
          * 1. Update Flag 9325 to TRUE
          * Author: Tarun Upputuri(vn510o1)
          ----------------------------------------------------------------------------------------------------------*/
    //Deprecated in 24.10
  /*  @Test(description = "Drop Multiple prescriptions with Priority as InStore In and Dispense Type as Curbside Pickup.",
            enabled = false , priority = 83, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DropOffscreen/DropOffUatTestSet1DataBook.json", sheetName = "DropOffUat")
    public void tc_83_dropOff_Curbside_Pickup_Instore_Multiple_Prescription(Map<String, String> inputData) {
        System.out.println(">>>tc_83_dropOff_Curbside_Pickup_Instore_Multiple_Prescription<<<");

        //PreCondition
        //1. Update Flag 9325 to TRUE

        //1. Log in to Connexus | Connexus should bring up the main screen
        //2. Click Drop-off | Drop-off Screen should appear
        //3. Select a Patient | Patient information and Prescription history should appear
        //4. Add multiple prescriptions to the order from the patients prescription history | The prescriptions selected should appear in the order on the right side of the screen.
        dropOffScreenUatTestScripts.addMultiplePrescriptionsAndValidate(inputData);
        int count = dropOffScreenUatTestScripts.validateRxRecordCount(DropOffUatTestSet1.totalCount);
        DropOffUatTestSet1.totalCount = DropOffUatTestSet1.totalCount + Integer.parseInt(inputData.get("COUNT"));

        System.out.println("<<<tc_83_dropOff_Curbside_Pickup_Instore_Multiple_Prescription>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
          * Test Description: Drop Multiple prescriptions with Priority as Today and Dispense Type as Curbside Pickup.
          * PreCondition
          * 1. Update Flag 9325 to TRUE
          * Author: Tarun Upputuri(vn510o1)
          ----------------------------------------------------------------------------------------------------------*/
    //Deprecated in 24.10
   /* @Test(description = "Drop Multiple prescriptions with Priority as Today and Dispense Type as Curbside Pickup.",
            enabled = false ,priority = 84, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DropOffscreen/DropOffUatTestSet1DataBook.json", sheetName = "DropOffUat")
    public void tc_84_dropOff_Curbside_Pickup_Today_Multiple_Prescription(Map<String, String> inputData) {
        System.out.println(">>>tc_84_dropOff_Curbside_Pickup_Today_Multiple_Prescription<<<");

        //PreCondition
        //1. Update Flag 9325 to TRUE

        //1. Log in to Connexus | Connexus should bring up the main screen
        //2. Click Drop-off | Drop-off Screen should appear
        //3. Select a Patient | Patient information and Prescription history should appear
        //4. Add multiple prescriptions to the order from the patients prescription history | The prescriptions selected should appear in the order on the right side of the screen.
        dropOffScreenUatTestScripts.addMultiplePrescriptionsAndValidate(inputData);
        int count = dropOffScreenUatTestScripts.validateRxRecordCount(DropOffUatTestSet1.totalCount);
        DropOffUatTestSet1.totalCount = DropOffUatTestSet1.totalCount + Integer.parseInt(inputData.get("COUNT"));

        System.out.println("<<<tc_84_dropOff_Curbside_Pickup_Today_Multiple_Prescription>>>");
    }*/

    /*----------------------------------------------------------------------------------------------------------
       * Test Description: Drop Multiple prescriptions with Priority as Dr Call In and Dispense Type as Curbside Pickup.
       * PreCondition
       * 1. Update Flag 9325 to TRUE
       * Author: Tarun Upputuri(vn510o1)
       ----------------------------------------------------------------------------------------------------------*/
    //Deprecated in 24.10
  /*  @Test(description = "Drop Multiple prescriptions with Priority as Dr Call In and Dispense Type as Curbside Pickup.",
            enabled = false ,priority = 85, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DropOffscreen/DropOffUatTestSet1DataBook.json", sheetName = "DropOffUat")
    public void tc_85_dropOff_Curbside_Pickup_DrCallIn_Multiple_Prescription(Map<String, String> inputData) {
        System.out.println(">>>tc_85_dropOff_Curbside_Pickup_DrCallIn_Multiple_Prescription<<<");

        //PreCondition
        //1. Update Flag 9325 to TRUE

        //1. Log in to Connexus | Connexus should bring up the main screen
        //2. Click Drop-off | Drop-off Screen should appear
        //3. Select a Patient | Patient information and Prescription history should appear
        //4. Add multiple prescriptions to the order from the patients prescription history | The prescriptions selected should appear in the order on the right side of the screen.
        dropOffScreenUatTestScripts.addMultiplePrescriptionsAndValidate(inputData);
        int count = dropOffScreenUatTestScripts.validateRxRecordCount(DropOffUatTestSet1.totalCount);

        System.out.println("<<<tc_85_dropOff_Curbside_Pickup_DrCallIn_Multiple_Prescription>>>");
    }*/

}
