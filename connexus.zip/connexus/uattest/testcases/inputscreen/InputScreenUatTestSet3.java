package connexus.uattest.testcases.inputscreen;

import connexus.uattest.testscripts.InputScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

public class InputScreenUatTestSet3 {
    InputScreenUatTestScripts inputScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        inputScreenUatTestScripts = new InputScreenUatTestScripts();
        inputScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        inputScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:selecting/editing the prescriber by first name and last name
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 149, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_149_Input_edit_prescriberByFirstNameLastName(Map<String, String> inputData) {
        System.out.println(">>>tc_149_Input_edit_prescriberByFirstNameLastName<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        if (connexusAppUtils.readAndUpdateFlag("26849", "TRUE")) {
            tearDown();
            inputScreenUatTestScripts = new InputScreenUatTestScripts();
            inputScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        inputScreenUatTestScripts.createPatient(inputData);

        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        inputScreenUatTestScripts.dropAnRxInStore();

        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.launchRxInWorkQueue();

        //4. Click in the box and type in the prescribers name {FirstName}{SPACE}{LastName} and press tab | Connexus should allow user input into the prescriber field and bring up the prescriber data or prescriber search screen (searching by prescriber name)
        inputScreenUatTestScripts.enterPrescriberDetails(inputData, 0);
        inputScreenUatTestScripts.validatePrescriberDetails(inputData, 0);

        //to continue the flow
        inputScreenUatTestScripts.clearPrescriberNameOnInputScreen();

        System.out.println("<<<tc_149_Input_edit_prescriberByFirstNameLastName>>>");
    }


    /*----------------------------------------------------------------------------------------------------------
     * Test Description:selecting/editing the prescriber by the last name, first name
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 150, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_150_Input_edit_prescriberByLastNameFirstName(Map<String, String> inputData) {
        System.out.println(">>>tc_150_Input_edit_prescriberByLastNameFirstName<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click in the box and type in the prescribers name {LastName} , {FirstName} and press enter | Connexus should allow user input into the prescriber field and bring up the prescriber data or prescriber search screen (searching by prescriber name)
        inputScreenUatTestScripts.enterPrescriberDetails(inputData, 1);
        inputScreenUatTestScripts.validatePrescriberDetails(inputData, 0);

        //to continue the flow
        inputScreenUatTestScripts.clearPrescriberNameOnInputScreen();

        System.out.println("<<<tc_150_Input_edit_prescriberByLastNameFirstName>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:selecting/editing the prescriber by NPI
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 151, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_151_Input_edit_prescriberByNPI(Map<String, String> inputData) {
        System.out.println(">>>tc_151_Input_edit_prescriberByNPI<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click in the box and type in the prescribers NPI and press enter or tab | Connexus should allow user input into the prescriber field and bring up the prescriber data or prescriber search screen (searching by prescriber NPI)
        inputScreenUatTestScripts.enterPrescriberDetails(inputData, 2);
        inputScreenUatTestScripts.validatePrescriberDetails(inputData, 1);

        //to continue the flow
        inputScreenUatTestScripts.clearPrescriberNameOnInputScreen();

        System.out.println("<<<tc_151_Input_edit_prescriberByNPI>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:selecting/editing a prescriber by DEA
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 152, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_152_Input_edit_prescriberByDEA(Map<String, String> inputData) {
        System.out.println(">>>tc_152_Input_edit_prescriberByDEA<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click in the box and type in the prescribers DEA and press enter or tab | Connexus should allow user input into the prescriber field and bring up the prescriber data or prescriber search screen (searching by prescriber DEA)
        inputScreenUatTestScripts.enterPrescriberDetails(inputData, 3);
        inputScreenUatTestScripts.validatePrescriberDetails(inputData, 2);

        //to continue the flow
        inputScreenUatTestScripts.clearPrescriberNameOnInputScreen();
        inputScreenUatTestScripts.closeInputScreen();

        System.out.println("<<<tc_152_Input_edit_prescriberByDEA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:selecting/editing a prescriber's supervisor by first name and last name
     *
     * Pre-Conditions:
     * 1. Box in a state that requires an attending physician
     * 2. A  prescriber that requires an attending physician
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 153, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_153_Input_edit_supervisorByFirstNameLastName(Map<String, String> inputData) {
        System.out.println(">>>tc_153_Input_edit_supervisorByFirstNameLastName<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        boolean contactInfoFlag = connexusAppUtils.readAndUpdateFlag("26849", "TRUE");
        boolean stateFlag = connexusAppUtils.updateStateValue(inputData.get("STORE_STATE"));
        if (contactInfoFlag || stateFlag) {
            tearDown();
            connexusAppUtils.restartServices();
            inputScreenUatTestScripts = new InputScreenUatTestScripts();
            inputScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            inputScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }

        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.launchRxInWorkQueue();

        //4. Enter prescribers information in the prescriber field |  Prescriber information should be accepted and bring up the attending physician tab
        //5. Click in the attending Physician field and enter the attending physicians name {FirstName}{SPACE}{LastName} and press tab | Connexus should allow user input into the attending physican field and bring up the prescriber data or prescriber search screen (searching by prescriber name)
        List physicianDetails = inputScreenUatTestScripts.getAttendingPhysicianDetails();
        inputScreenUatTestScripts.enterPrescriberDetailsAndValidateAttendingPhysicianTab(physicianDetails);
        inputScreenUatTestScripts.enterAttendingPhysicianDetails(physicianDetails, 0);
        inputScreenUatTestScripts.validateAttendingPhysicianDetails(physicianDetails, 0);

        //to continue the flow
        inputScreenUatTestScripts.clearPrescriberAndAttendingPhysician();

        System.out.println("<<<tc_153_Input_edit_supervisorByFirstNameLastName>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: selecting/editing a prescriber's supervisor by last name, first name
     *
     * Pre-Conditions:
     * 1. Box in a state that requires an attending physician
     * 2. A  prescriber that requires an attending physician
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 154, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_154_Input_edit_supervisorByLastNameFirstName(Map<String, String> inputData) {
        System.out.println(">>>tc_154_Input_edit_supervisorByLastNameFirstName<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Enter prescribers information in the prescriber field |  Prescriber information should be accepted and bring up the attending physician tab
        //5. Click in the attending Physician field and enter the attending physicians name {LastName},{FirstName} and press enter | Connexus should allow user input into the attending physican field and bring up the prescriber data or prescriber search screen (searching by prescriber name)
        List physicianDetails = inputScreenUatTestScripts.getAttendingPhysicianDetails();
        inputScreenUatTestScripts.enterPrescriberDetailsAndValidateAttendingPhysicianTab(physicianDetails);
        inputScreenUatTestScripts.enterAttendingPhysicianDetails(physicianDetails, 1);
        inputScreenUatTestScripts.validateAttendingPhysicianDetails(physicianDetails, 0);

        //to continue the flow
        inputScreenUatTestScripts.clearPrescriberAndAttendingPhysician();

        System.out.println("<<<tc_154_Input_edit_supervisorByLastNameFirstName>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: selecting/editing a prescribers supervisor name by NPI
     *
     * Pre-Conditions:
     * 1. Box in a state that requires an attending physician
     * 2. A  prescriber that requires an attending physician
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 155, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_155_Input_edit_supervisorByNPI(Map<String, String> inputData) {
        System.out.println(">>>tc_155_Input_edit_supervisorByNPI<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Enter prescribers information in the prescriber field |  Prescriber information should be accepted and bring up the attending physician tab
        //5. Click in the attending Physician field and enter the attending physicians NPI | Connexus should allow user input into the attending physican field and bring up the prescriber data or prescriber search screen (searching by prescriber NPI)
        List physicianDetails = inputScreenUatTestScripts.getAttendingPhysicianDetails();
        inputScreenUatTestScripts.enterPrescriberDetailsAndValidateAttendingPhysicianTab(physicianDetails);
        inputScreenUatTestScripts.enterAttendingPhysicianDetails(physicianDetails, 2);
        inputScreenUatTestScripts.validateAttendingPhysicianDetails(physicianDetails, 1);

        //to continue the flow
        inputScreenUatTestScripts.clearPrescriberAndAttendingPhysician();

        System.out.println("<<<tc_155_Input_edit_supervisorByNPI>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:selecting/editing a prescriber by DEA
     *
     * Pre-Conditions:
     * 1. Box in a state that requires an attending physician
     * 2. A  prescriber that requires an attending physician
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 156, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_156_Input_edit_supervisorByDEA(Map<String, String> inputData) {
        System.out.println(">>>tc_156_Input_edit_supervisorByDEA<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Enter prescribers information in the prescriber field |  Prescriber information should be accepted and bring up the attending physician tab
        //5. Click in the attending Physician field and enter the attending physicians DEA | Connexus should allow user input into the attending physican field and bring up the prescriber data or prescriber search screen (searching by prescriber DEA)
        List physicianDetails = inputScreenUatTestScripts.getAttendingPhysicianDetails();
        inputScreenUatTestScripts.enterPrescriberDetailsAndValidateAttendingPhysicianTab(physicianDetails);
        inputScreenUatTestScripts.enterAttendingPhysicianDetails(physicianDetails, 3);
        inputScreenUatTestScripts.validateAttendingPhysicianDetails(physicianDetails, 2);

        System.out.println("<<<tc_156_Input_edit_supervisorByDEA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Editing the order comment at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 157, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_157_Input_edit_orderComment(Map<String, String> inputData) {
        System.out.println(">>>tc_157_Input_edit_orderComment<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click in the order comment field and type out a comment and then complete input | Connexus should allow the user to type in the Order Comment field and then apply the comment to all prescriptions in the order
        inputScreenUatTestScripts.validateOrderCommentTextBox(inputData);

        System.out.println("<<<tc_157_Input_edit_orderComment>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:clicking on the prescription image to enlarge the image at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 158, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_158_Input_click_imageDoubleClick(Map<String, String> inputData) {
        System.out.println(">>>tc_158_Input_click_imageDoubleClick");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Double click on the prescription image | The prescription image should become full screen
        inputScreenUatTestScripts.doubleClickOnRxImage();
        inputScreenUatTestScripts.validateRxMaximizedToFullScreen();

        //to continue the flow
        inputScreenUatTestScripts.exitFromFullScreenRxImage();

        System.out.println("<<<tc_158_Input_click_imageDoubleClick>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:using click and drag to enlarge the prescription image at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 159, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_159_Input_edit_imageClickAndDrag(Map<String, String> inputData) {
        System.out.println(">>>tc_159_Input_edit_imageClickAndDrag");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click and drag a rectangle around part of the information on the prescription image | The prescription image window should Zoom in to the selection made with the click and drag
        inputScreenUatTestScripts.clickAndDragRxImageOnInputScreen();
        inputScreenUatTestScripts.validateRxImageBoxIsZoomedIn();

        //to continue the flow
        inputScreenUatTestScripts.closeInputScreen();

        System.out.println("<<<tc_159_Input_edit_imageClickAndDrag>>>");
    }
}
