package connexus.uattest.testcases.inputscreen;

import connexus.uattest.testscripts.InputScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class InputScreenUatTestSet4 {
    InputScreenUatTestScripts inputScreenUatTestScripts = new InputScreenUatTestScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();

    @BeforeClass
    public void beforeTestMethods() {
        inputScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        inputScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        if(connexusAppUtils.readAndUpdateFlag("26849", "TRUE")) {
            tearDown();
            inputScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            inputScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:clicking the add rx button to add to the total prescription on the paper
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 160, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_160_Input_click_addRxButton(Map<String, String> inputData) {
        System.out.println(">>>tc_160_Input_click_addRxButton");

        //1. Log In to Connexus | Connexus should allow the user to log in
        inputScreenUatTestScripts.createPatient(inputData);

        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        inputScreenUatTestScripts.dropAnRxInStore();

        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.launchRxInWorkQueue();

        //4. Click the Add Rx button below the prescription image | The counter under the prescription Image should increase by 1 and the number of prescriptions in the order should increase by 1
        // No of rx in order is validated before adding rx
        inputScreenUatTestScripts.clickShowOrderButton();
        inputScreenUatTestScripts.validateRxCountOnShowOrderPopUp();
        inputScreenUatTestScripts.closeShowOrderPopUp();

        // The counter under prescription image is validated
        inputScreenUatTestScripts.validateIncreasedPrescriptionCount();

        // No of rx in order is validated after adding rx
        inputScreenUatTestScripts.clickShowOrderButton();
        inputScreenUatTestScripts.validateRxCountOnShowOrderPopUp();
        inputScreenUatTestScripts.closeShowOrderPopUp();

        System.out.println("<<<tc_160_Input_click_addRxButton>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Clicking max button to view a full screen image of the prescription at input
    *
    * Pre-Conditions: None
    *
    * Author: Lakshmi Priya (vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 161, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_161_Input_click_imageMaxButton(Map<String, String> inputData) {
        System.out.println(">>>tc_161_Input_click_imageMaxButton");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the button labeled Max below the prescription image | The prescription image should be opened in  a larger format on the screen
        inputScreenUatTestScripts.clickOnMaximizeButton();
        inputScreenUatTestScripts.validateRxImageIsMaximized();

        //to continue the flow
        inputScreenUatTestScripts.exitFromFullScreenRxImage();

        System.out.println("<<<tc_161_Input_click_imageMaxButton>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:clicking the rotate image button to rotate the image 1 step clockwise
    *
    * Pre-Conditions: None
    *
    * Author: Lakshmi Priya (vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 162, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_162_Input_click_imageRotateButton(Map<String, String> inputData) {
        System.out.println(">>>tc_162_Input_click_imageRotateButton");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the rotate button below the prescription image | The prescription image should rotate 90 degrees clockwise
        inputScreenUatTestScripts.clickOnRotateRxImageButton();

        // The Rx image rotation is to be marked as non-automated
        inputScreenUatTestScripts.validateRxImageIsRotated();

        System.out.println("<<<tc_162_Input_click_imageRotateButton>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:clicking on the zoom in button to enlarge the prescription image slightly at input
    *
    * Pre-Conditions: None
    *
    * Author: Lakshmi Priya (vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 163, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_163_Input_click_imageZoomInButton(Map<String, String> inputData) {
        System.out.println(">>>tc_163_Input_click_imageZoomInButton");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the Zoom in button below the prescription image | The zoom on the prescription image should increase by a factor of 1
        inputScreenUatTestScripts.clickOnZoomInRxImageIcon();

        //Zoomed in twice to validate zoom factor for tc_164_Input_click_imageZoomOutButton
        inputScreenUatTestScripts.clickOnZoomInRxImageIcon();
        inputScreenUatTestScripts.validateZoomAspectOfRxImage();

        System.out.println("<<<tc_163_Input_click_imageZoomInButton>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:clicking on the zoom out button to shrink the prescription image slightly at input
    *
    * Pre-Conditions: None
    *
    * Author: Lakshmi Priya (vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 164, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_164_Input_click_imageZoomOutButton(Map<String, String> inputData) {
        System.out.println(">>>tc_164_Input_click_imageZoomOutButton");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the Zoom out button below the prescription image | The zoom on the prescription image should decrease by a factor of 1
        inputScreenUatTestScripts.clickOnZoomOutRxImageIcon();
        inputScreenUatTestScripts.validateZoomAspectOfRxImage();

        System.out.println("<<<tc_164_Input_click_imageZoomOutButton>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:clicking on the show order button at input to bring up a view of all prescriptions in an order
    *
    * Pre-Conditions: None
    *
    * Author: Lakshmi Priya (vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 165, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_165_Input_click_showOrderButton(Map<String, String> inputData) {
        System.out.println(">>>tc_165_Input_click_showOrderButton");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the show order button on the Input screen | A new window should pop- up and display all prescriptions in the same order and their current status
        inputScreenUatTestScripts.clickShowOrderButton();
        String orderId = inputScreenUatTestScripts.validateRxCountOnShowOrderPopUp();
        inputScreenUatTestScripts.validateRxStatusOnShowOrderPopUp(orderId);
        inputScreenUatTestScripts.closeShowOrderPopUp();

        //to continue the flow
        inputScreenUatTestScripts.closeInputScreen();

        System.out.println("<<<tc_165_Input_click_showOrderButton>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:sending a prescription to illegible image from input
    *
    * Pre-Conditions: None
    *
    * Author: Lakshmi Priya (vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 166, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_166_Input_click_sendToResolutionButton_illegibleImage(Map<String, String> inputData) {
        System.out.println(">>>tc_166_Input_click_sendToResolutionButton_illegibleImage");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        inputScreenUatTestScripts.dropAnRxInStore();

        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.launchRxInWorkQueue();

        //4. Click on the Send To Resolution button on the input screen. | A submenu with options should appear next to the mouse
        inputScreenUatTestScripts.clickSendToResolutionButton(inputData,0);

        //5. Select Illegible Image from the Send to Resolution submenu | Prescription should be sent to the illegible image resolution queue
        inputScreenUatTestScripts.launchRxInWorkQueue();
        boolean returnRxToInputFlag=inputScreenUatTestScripts.validateRxInResolutionPage(0);

        //to continue the flow
        inputScreenUatTestScripts.returnRxToInputPage(returnRxToInputFlag);

        System.out.println("<<<tc_166_Input_click_sendToResolutionButton_illegibleImage>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:sending a prescription to manual resolution from input
    *
    * Pre-Conditions: None
    *
    * Author: Lakshmi Priya (vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 167, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_167_Input_click_sendToResolutionButton_manualResolution(Map<String, String> inputData) {
        System.out.println(">>>tc_167_Input_click_sendToResolutionButton_manualResolution");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the Send To Resolution button on the input screen. | A submenu with options should appear next to the mouse
        inputScreenUatTestScripts.clickSendToResolutionButton(inputData,0);

        //5. Select Manual Resolution from Send to Resolution submenu | Manual resolution type pop up should appear
        inputScreenUatTestScripts.validateManualResolutionPopUp();

        System.out.println("<<<tc_167_Input_click_sendToResolutionButton_manualResolution>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Clicking the accept button at input
    *
    * Pre-Conditions: None
    *
    * Author: Lakshmi Priya (vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 168, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_168_Input_click_acceptButton(Map<String, String> inputData) {
        System.out.println(">>>tc_168_Input_click_acceptButton");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.enterDrugDetailsInRx(inputData);
        inputScreenUatTestScripts.enterPrescriberDetails(inputData,0);

        //4. Fill in all required fields and click the accept button on the input screen | If all required fields are filled in and contain valid information Connexus should accept the prescription
        inputScreenUatTestScripts.acceptInputForRx();

        System.out.println("<<<tc_168_Input_click_acceptButton>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:clicking the cancel button at input
    *
    * Pre-Conditions: None
    *
    * Author: Lakshmi Priya (vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 169, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_169_Input_click_cancelButton(Map<String, String> inputData) {
        System.out.println(">>>tc_169_Input_click_cancelButton");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        inputScreenUatTestScripts.dropAnRxInStore();

        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.launchRxInWorkQueue();

        //4. Click on the cancel button on the input screen | The input should be dismissed from the screen with no changes saved
        inputScreenUatTestScripts.clickCancelButton();

        System.out.println("<<<tc_169_Input_click_cancelButton>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:sending a prescription to manual resolution from the manual resolution pop up at input
    *
    * Pre-Conditions: None
    *
    * Author: Lakshmi Priya (vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 170, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_170_Input_sendToResolutionButton_option_manualResolution(Map<String, String> inputData) {
        System.out.println(">>>tc_170_Input_sendToResolutionButton_option_manualResolution");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.launchRxInWorkQueue();

        //4. Click on the Send To Resolution button on the input screen. | A submenu with options should appear next to the mouse
        //5. Select Manual Resolution from Send to Resolution submenu | Manual resolution type pop up should appear
        inputScreenUatTestScripts.clickSendToResolutionButton(inputData,3);

        //6. Click the manual resolution selection and add a reason into the input box then click accept | Connexus should send the prescription to resolution under the manual resolution category
        inputScreenUatTestScripts.launchRxInWorkQueue();
        boolean returnRxFlag=inputScreenUatTestScripts.validateRxInResolutionPage(3);

        //to continue the flow
        inputScreenUatTestScripts.returnRxToInputPage(returnRxFlag);

        System.out.println("<<<tc_170_Input_sendToResolutionButton_option_manualResolution>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:sending a prescription to contact customer resolution from the manual resolution pop up at input
    *
    * Pre-Conditions: None
    *
    * Author: Lakshmi Priya (vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 171, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_171_Input_sendToResolutionButton_option_contactCustomer(Map<String, String> inputData) {
        System.out.println(">>>tc_171_Input_sendToResolutionButton_option_contactCustomer");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.launchRxInWorkQueue();

        //4. Click on the Send To Resolution button on the input screen. | A submenu with options should appear next to the mouse
        //5. Select Manual Resolution from Send to Resolution submenu | Manual resolution type pop up should appear
        inputScreenUatTestScripts.clickSendToResolutionButton(inputData,2);

        //6. Click the contact customer selection and add a reason into the input box then click accept | Connexus should send the prescription to resolution under the contact customer category
        inputScreenUatTestScripts.launchRxInWorkQueue();
        boolean returnRxFlag = inputScreenUatTestScripts.validateRxInResolutionPage(2);

        //to continue the flow
        inputScreenUatTestScripts.returnRxToInputPage(returnRxFlag);

        System.out.println("<<<tc_171_Input_sendToResolutionButton_option_contactCustomer>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:sending a prescription to contact prescriber from the manual resolution pop up at input
    *
    * Pre-Conditions: None
    *
    * Author: Lakshmi Priya (vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 172, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_172_Input_sendToResolutionButton_option_contactPrescriber(Map<String, String> inputData) {
        System.out.println(">>>tc_172_Input_sendToResolutionButton_option_contactPrescriber");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.launchRxInWorkQueue();

        //4. Click on the Send To Resolution button on the input screen. | A submenu with options should appear next to the mouse
        //5. Select Manual Resolution from Send to Resolution submenu | Manual resolution type pop up should appear
        inputScreenUatTestScripts.clickSendToResolutionButton(inputData,1);

        //6. Click the contact prescriber (rph only) selection and add a reason into the input box then click accept | Connexus should send the prescription to resolution under the contact prescriber category
        inputScreenUatTestScripts.launchRxInWorkQueue();
        boolean returnRxFlag = inputScreenUatTestScripts.validateRxInResolutionPage(1);

        //to continue the flow
        inputScreenUatTestScripts.returnRxToInputPage(returnRxFlag);

        System.out.println("<<<tc_172_Input_sendToResolutionButton_option_contactPrescriber>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:cancel sending a prescription to a manual resolution from the manual resolution pop up at input
    *
    * Pre-Conditions: None
    *
    * Author: Lakshmi Priya (vn510nm)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 173, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_173_Input_sendToResolutionButton_option_cancel(Map<String, String> inputData) {
        System.out.println(">>>tc_173_Input_sendToResolutionButton_option_cancel");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.launchRxInWorkQueue();

        //4. Click on the Send To Resolution button on the input screen. | A submenu with options should appear next to the mouse
        inputScreenUatTestScripts.clickSendToResolutionButton(inputData,0);

        //5. Select Manual Resolution from Send to Resolution submenu | Manual resolution type pop up should appear
        //6. Click the cancel button | the pop up should be dismissed
        inputScreenUatTestScripts.clickCancelButton();

        // to continue the flow
        inputScreenUatTestScripts.closeInputScreen();

        System.out.println("<<<tc_173_Input_sendToResolutionButton_option_cancel>>>");
    }
}
