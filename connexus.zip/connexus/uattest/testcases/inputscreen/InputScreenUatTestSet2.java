package connexus.uattest.testcases.inputscreen;

import connexus.uattest.testscripts.InputScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class InputScreenUatTestSet2 {
    InputScreenUatTestScripts inputScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        inputScreenUatTestScripts = new InputScreenUatTestScripts();
        inputScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        inputScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Searching for a product by name or name and strength at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 130,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_130_Input_edit_prescribedProductByName(Map<String, String> inputData) {
        System.out.println(">>>tc_130_Input_edit_prescribedProductByName<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        if(connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            inputScreenUatTestScripts = new InputScreenUatTestScripts();
            inputScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        inputScreenUatTestScripts.createPatient(inputData);

        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        inputScreenUatTestScripts.dropAnRxInStore();

        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.launchRxInWorkQueue();

        //4. Click in the prescribed product field and type in a drug name or a partial drug name and strength
        // (ex. Lisin 20mg) then press tab or enter | Connexus should accept the user input and search for the drug name typed in.
        inputScreenUatTestScripts.clickOnPrescribedProductTextBox();
        inputScreenUatTestScripts.enterDrugNameAndSearchProductScreen(inputData);

        System.out.println("<<<tc_130_Input_edit_prescribedProductByName>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:searching for a product by NDC number at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 131,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_131_Input_edit_prescribedProductByNDC(Map<String, String> inputData) {
        System.out.println(">>>tc_131_Input_edit_prescribedProductByNDC<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.clearDrugNameInPrescribedProduct();

        //4. Click in the prescribed product field and type in the NDC for a drug then press tab or enter | Connexus should accept the user input and pull up the drug that matches the NDC
        inputScreenUatTestScripts.clickOnPrescribedProductTextBox();
        inputScreenUatTestScripts.enterNdcNumberAndPressEnterInPrescribedProduct(inputData);
        inputScreenUatTestScripts.validateNdcNumberFromDb(inputData);

        System.out.println("<<<tc_131_Input_edit_prescribedProductByNDC>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:opening the product information screen using the folder icon at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 132,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_132_Input_edit_prescribedProduct_threeDotButton(Map<String, String> inputData) {
        System.out.println(">>>tc_132_Input_edit_prescribedProduct_threeDotButton<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.clearDrugNameInPrescribedProduct();

        //4. Click in the prescribed product field and type in an NDC or drug name then click on the 3 dot button next to the prescribed product field | Connexus should accept the users input and then search for the drug when the button is pressed
        inputScreenUatTestScripts.clickOnPrescribedProductTextBox();
        inputScreenUatTestScripts.enterNdcNumberInPrescribedProduct(inputData);
        inputScreenUatTestScripts.click3DotsButtonForPrescribedProduct();
        inputScreenUatTestScripts.closeProductSearch();
        inputScreenUatTestScripts.validateNdcNumberFromDb(inputData);

        System.out.println("<<<tc_132_Input_edit_prescribedProduct_threeDotButton>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:opening the product information screen using the folder icon at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 133,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_133_Input_edit_prescribedProduct_folderButton(Map<String, String> inputData) {
        System.out.println(">>>tc_133_Input_edit_prescribedProduct_folderButton<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.clearDrugNameInPrescribedProduct();

        //4. Select a prescribed product by either NDC or Drug Name | Connexus should either search or select the drug based on the entry.
        inputScreenUatTestScripts.enterNdcNumberAndPressEnterInPrescribedProduct(inputData);
        inputScreenUatTestScripts.validateNdcNumberFromDb(inputData);

        //5. Click on the folder icon next to the prescribed product field | Connexus should open the product screen for the drug selected in prescribed product
        inputScreenUatTestScripts.clickOnProductMaintenanceIcon();
        inputScreenUatTestScripts.verifyProductMaintenanceScreen();

        System.out.println("<<<tc_133_Input_edit_prescribedProduct_folderButton>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:opening the Explain drug substitution screen at input using the prescription bottle icon
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 134,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_134_Input_edit_drugSubButton(Map<String, String> inputData) {
        System.out.println(">>>tc_134_Input_edit_drugSubButton<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        inputScreenUatTestScripts.clearDrugNameInPrescribedProduct();

        //4. Select a prescribed product by either NDC or Drug Name | Connexus should either search or select the drug based on the entry.
        inputScreenUatTestScripts.enterNdcNumberAndPressEnterInPrescribedProduct(inputData);
        inputScreenUatTestScripts.validateNdcNumberFromDb(inputData);

        //5. Click on the Icon that looks like a prescription bottle | ConnexUs should bring up the drug selection screen and show data explaining why a specific NDC/Generic was chosen
        inputScreenUatTestScripts.clickAndValidatePrescriptionBottleIcon();

        System.out.println("<<<tc_134_Input_edit_drugSubButton>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:editing the QTY field at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 135,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_135_Input_edit_qtyField(Map<String, String> inputData) {
        System.out.println(">>>tc_135_Input_edit_qtyField<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click in the QTY field and type in a number | Connexus should accept the user input as long as the user inputs numbers. This field should not allow letters
        inputScreenUatTestScripts.validatePrescribedDrugQuantity(inputData);

        System.out.println("<<<tc_135_Input_edit_qtyField>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:editing the Dispense Qty field at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 136,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_136_Input_edit_dispQtyField(Map<String, String> inputData) {
        System.out.println(">>>tc_136_Input_edit_dispQtyField<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click in the Disp QTY field and type in a number | Connexus should accept the user input as long as the user inputs numbers. This field should not allow letters
        inputScreenUatTestScripts.validateDispensedDrugQuantity(inputData);

        System.out.println("<<<tc_136_Input_edit_dispQtyField>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:editing the days supply field at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 137,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_137_Input_edit_daysField(Map<String, String> inputData) {
        System.out.println(">>>tc_137_Input_edit_daysField<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click in the Days field and type in a number | Connexus should accept the user input as long as the user inputs numbers. This field should not allow letters
        inputScreenUatTestScripts.validateNoOfDaysOfProductSupply(inputData);

        System.out.println("<<<tc_137_Input_edit_daysField>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:adding/editing the sig at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 138,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_138_Input_edit_sigField(Map<String, String> inputData) {
        System.out.println(">>>tc_138_Input_edit_sigField<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click in the sig field and enter a valid short sig (ex. 1QD, 1BID or 1TID) | Connexus should accept the user input and then translate the short sig input by the user to the expanded sig field
        inputScreenUatTestScripts.validateSIGField(inputData);

        System.out.println("<<<tc_138_Input_edit_sigField>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:adding to/editing the expanded sig at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 139,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_139_Input_edit_expandedSigField(Map<String, String> inputData) {
        System.out.println(">>>tc_139_Input_edit_expandedSigField<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click in the sig field and enter a valid short sig (ex. 1QD, 1BID or 1TID) | Connexus should accept the user input and then translate the short sig input by the user to the expanded sig field
        //5. Click in the expanded sig filed and add to the short sig translation | Connexus should accept the user input and then change the short sig to FF
        inputScreenUatTestScripts.validateExpandedSIGField(inputData);

        System.out.println("<<<tc_139_Input_edit_expandedSigField>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:editing refills at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 140,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_140_Input_edit_refillsField(Map<String, String> inputData) {
        System.out.println(">>>tc_140_Input_edit_refillsField<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click in the Refills field and type in a number | Connexus should accept the user input as long as the user inputs numbers. This field should not allow letters
        inputScreenUatTestScripts.validateProductRefill(inputData);

        System.out.println("<<<tc_140_Input_edit_refillsField>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:changing the DAW to 0 at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 141,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_141_Input_edit_DAW_0_DropDown(Map<String, String> inputData) {
        System.out.println(">>>tc_141_Input_edit_DAW_0_DropDown<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the down arrow for the DAW field and select DAW-0 | Connexus should allow the user to access the drop down and select DAW0
        inputScreenUatTestScripts.selectDawCodeDropDown(inputData);
        inputScreenUatTestScripts.validateDawOnInputScreen(inputData);

        System.out.println("<<<tc_141_Input_edit_DAW_0_DropDown>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:changing the DAW to 1 at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 142,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_142_Input_edit_DAW_1_DropDown(Map<String, String> inputData) {
        System.out.println(">>>tc_142_Input_edit_DAW_1_DropDown<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the down arrow for the DAW field and select DAW-1 | Connexus should allow the user to access the drop down and select DAW1
        inputScreenUatTestScripts.selectDawCodeUsingDownArrow();
        inputScreenUatTestScripts.validateDawOnInputScreen(inputData);

        System.out.println("<<<tc_142_Input_edit_DAW_1_DropDown>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:changing the DAW to 2 at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 143,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_143_Input_edit_DAW_2_DropDown(Map<String, String> inputData) {
        System.out.println(">>>tc_143_Input_edit_DAW_2_DropDown<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the down arrow for the DAW field and select DAW-2 | Connexus should allow the user to access the drop down and select DAW2
        inputScreenUatTestScripts.selectDawCodeUsingDownArrow();
        inputScreenUatTestScripts.validateDawOnInputScreen(inputData);

        System.out.println("<<<tc_143_Input_edit_DAW_2_DropDown>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:changing the DAW to 5 at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 144,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_144_Input_edit_DAW_5_DropDown(Map<String, String> inputData) {
        System.out.println(">>>tc_144_Input_edit_DAW_5_DropDown<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the down arrow for the DAW field and select DAW-5 | Connexus should allow the user to access the drop down and select DAW5
        inputScreenUatTestScripts.selectDawCodeUsingDownArrow();
        inputScreenUatTestScripts.validateDawOnInputScreen(inputData);

        System.out.println("<<<tc_144_Input_edit_DAW_5_DropDown>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:changing the DAW to 6 at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 145,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_145_Input_edit_DAW_6_DropDown(Map<String, String> inputData) {
        System.out.println(">>>tc_145_Input_edit_DAW_6_DropDown<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the down arrow for the DAW field and select DAW-6 | Connexus should allow the user to access the drop down and select DAW6
        inputScreenUatTestScripts.selectDawCodeUsingDownArrow();
        inputScreenUatTestScripts.validateDawOnInputScreen(inputData);

        System.out.println("<<<tc_145_Input_edit_DAW_6_DropDown>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:changing the DAW to 7 at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 146,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_146_Input_edit_DAW_7_DropDown(Map<String, String> inputData) {
        System.out.println(">>>tc_146_Input_edit_DAW_7_DropDown<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the down arrow for the DAW field and select DAW-7 | Connexus should allow the user to access the drop down and select DAW7
        inputScreenUatTestScripts.selectDawCodeUsingDownArrow();
        inputScreenUatTestScripts.validateDawOnInputScreen(inputData);

        System.out.println("<<<tc_146_Input_edit_DAW_7_DropDown>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:changing the DAW to 8 at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 147,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_147_Input_edit_DAW_8_DropDown(Map<String, String> inputData) {
        System.out.println(">>>tc_147_Input_edit_DAW_8_DropDown<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the down arrow for the DAW field and select DAW-8 | Connexus should allow the user to access the drop down and select DAW6
        inputScreenUatTestScripts.selectDawCodeUsingDownArrow();
        inputScreenUatTestScripts.validateDawOnInputScreen(inputData);

        System.out.println("<<<tc_147_Input_edit_DAW_8_DropDown>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:changing the DAW to 9 at input
     *
     * Pre-Conditions: None
     *
     * Author: Lakshmi Priya (vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 148,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/InputScreen/InputDataBook.json", sheetName = "inputDataSheet")
    public void tc_148_Input_edit_DAW_9_DropDown(Map<String, String> inputData) {
        System.out.println(">>>tc_148_Input_edit_DAW_9_DropDown<<<");

        //1. Log In to Connexus | Connexus should allow the user to log in
        //2. Drop a new prescription | Drop-off of a prescription should be successful.
        //3. Open Input and allow the prescription to load | Connexus should bring up the prescription for the User to Input
        //4. Click on the down arrow for the DAW field and select DAW-9 | Connexus should allow the user to access the drop down and select DAW9
        inputScreenUatTestScripts.selectDawCodeUsingDownArrow();
        inputScreenUatTestScripts.validateDawOnInputScreen(inputData);

        // closes the input screen to continues the flow
        inputScreenUatTestScripts.closeInputScreen();

        System.out.println("<<<tc_148_Input_edit_DAW_9_DropDown>>>");
    }
}
