package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSet20 {

    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();

    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as GU while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority =301,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU(Map<String, String> inputData) {
        System.out.println(">>>tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US
        if(connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
            patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        patientMaintenanceScreenUatTestScripts.createPatient(inputData);

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        patientMaintenanceScreenUatTestScripts.clickAndValidateDropOffScreen();

        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.inputPatientNameInDropOff();
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();
        patientMaintenanceScreenUatTestScripts.enterTemporaryAddressDetails(inputData);

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select GU as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as HI while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 302,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_302_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_HI(Map<String, String> inputData) {
        System.out.println(">>>tc_302_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_HI<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select HI as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_302_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_HI>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as IA while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 303,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_303_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_IA(Map<String, String> inputData) {
        System.out.println(">>>tc_303_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_IA<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select IA as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_303_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_IA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as ID while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 304,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_304_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_ID(Map<String, String> inputData) {
        System.out.println(">>>tc_304_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_ID<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select ID as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_304_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_ID>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as IL while Country is set to US
     *
     * Pre-Conditions4
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 305,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_305_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_IL(Map<String, String> inputData) {
        System.out.println(">>>tc_305_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_IL<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select IL as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_305_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_IL>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as IN while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 306,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_306_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_IN(Map<String, String> inputData) {
        System.out.println(">>>tc_306_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_IN<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select IN as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_306_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_IN>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as KS while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 307,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_307_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_KS(Map<String, String> inputData) {
        System.out.println(">>>tc_307_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_KS<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select KS as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_307_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_KS>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as KY while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 308,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_308_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_KY(Map<String, String> inputData) {
        System.out.println(">>>tc_308_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_KY<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select KY as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_308_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_KY>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as LA while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 309,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_309_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_LA(Map<String, String> inputData) {
        System.out.println(">>>tc_309_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_LA<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select LA as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_309_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_LA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as MA while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 310,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_310_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MA(Map<String, String> inputData) {
        System.out.println(">>>tc_302_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MA<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select MA as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_310_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as MD while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 311,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_311_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MD(Map<String, String> inputData) {
        System.out.println(">>>tc_311_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MD<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select MD as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_311_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MD>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as ME while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 312,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_312_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_ME(Map<String, String> inputData) {
        System.out.println(">>>tc_312_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_ME<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select ME as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_312_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_ME>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as MH while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 313,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_313_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MH(Map<String, String> inputData) {
        System.out.println(">>>tc_313_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MH<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select MH as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_313_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MH>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as MI while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 314,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_314_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MI(Map<String, String> inputData) {
        System.out.println(">>>tc_314_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MI<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select MI as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_314_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MI>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as MN while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 315,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_315_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MN(Map<String, String> inputData) {
        System.out.println(">>>tc_315_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MN<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select MN as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_315_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MN>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as MO while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 316,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_316_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MO(Map<String, String> inputData) {
        System.out.println(">>>tc_316_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MO<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select MO as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_316_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MO>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as MP while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 317,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_317_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_mp(Map<String, String> inputData) {
        System.out.println(">>>tc_317_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MP<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select MP as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_317_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MP>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as MS while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 318,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_318_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MS(Map<String, String> inputData) {
        System.out.println(">>>tc_318_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MS<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select MS as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_318_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MS>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as MT while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 319,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_319_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MT(Map<String, String> inputData) {
        System.out.println(">>>tc_319_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MT<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select MT as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        System.out.println("<<<tc_319_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_MT>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as NC while Country is set to US
     *
     * Pre-Conditions:
     * 1. Temporary Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 320,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_301_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_GU"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet20.json", sheetName = "patientMaintenanceDataSheet")
    public void tc_320_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_NC(Map<String, String> inputData) {
        System.out.println(">>>tc_320_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_NC<<<");

        //Pre-Conditions:
        //1. Temporary Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select NC as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
        patientMaintenanceScreenUatTestScripts.clickCancelInDropOff();

        System.out.println("<<<tc_320_PTMS_generalInformationTab_adderessTemporaryTab_choice_state_NC>>>");
    }
}
