package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSet8 {
    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as NB while Country is set to CA
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to CA
     *
     * Author: Shreyaas M (vn516sa)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 84,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceTestSet8.json", sheetName = "patientSearchDataSheet")
    public void tc_84_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NB(Map<String, String> inputData) {
        System.out.println(">>>tc_84_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NB<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to CA
        if(connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
            patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        patientMaintenanceScreenUatTestScripts.createPatient(inputData);

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        patientMaintenanceScreenUatTestScripts.clickAndValidateDropOffScreen();

        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.inputPatientNameInDropOff();
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select NB as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectCountryInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.enterZipCodeInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_84_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NB>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as NL while Country is set to CA
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to CA
     *
     * Author: Shreyaas M (vn516sa)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 85,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_84_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NB"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceTestSet8.json", sheetName = "patientSearchDataSheet")
    public void tc_85_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NL(Map<String, String> inputData) {
        System.out.println(">>>tc_85_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NL<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to CA

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select NL as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_85_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NL>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as NS while Country is set to CA
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to CA
     *
     * Author: Shreyaas M (vn516sa)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 86,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_84_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NB"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceTestSet8.json", sheetName = "patientSearchDataSheet")
    public void tc_86_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NS(Map<String, String> inputData) {
        System.out.println(">>>tc_86_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NS<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to CA

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select NS as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_86_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NS>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as NT while Country is set to CA
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to CA
     *
     * Author: Shreyaas M (vn516sa)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 87,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_84_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NB"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceTestSet8.json", sheetName = "patientSearchDataSheet")
    public void tc_87_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NT(Map<String, String> inputData) {
        System.out.println(">>>tc_87_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NT<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to CA

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select NT as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_87_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NT>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as NU while Country is set to CA
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to CA
     *
     * Author: Shreyaas M (vn516sa)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 88,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_84_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NB"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceTestSet8.json", sheetName = "patientSearchDataSheet")
    public void tc_88_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NU(Map<String, String> inputData) {
        System.out.println(">>>tc_88_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NU<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to CA

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select NU as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        //To continue the flow of next test cases
        patientMaintenanceScreenUatTestScripts.clickCancelInDropOff();

        System.out.println("<<<tc_88_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NU>>>");
    }
}
