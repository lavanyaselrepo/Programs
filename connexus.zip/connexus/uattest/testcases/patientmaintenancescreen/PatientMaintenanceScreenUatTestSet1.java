package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.pageobjectmodels.connexus.DropOffPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.PatientMaintenancePage;
import hwqe.baseframework.models.pageobjectmodels.connexus.PatientSearchPage;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSet1 {
    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();

    @BeforeClass
    public void performlogin(){
        connexusAppUtils.startAppiumServer();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Selecting Patient Type of Human
     * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true,description = "Patient Maintenance Screen Test Cases", priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void HWPHME2E_624_tc_PTMS_Test_Cases(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        patientMaintenanceScreenUatTestScripts.selectingPatientTypeHumanDropOffQueue(inputData);
        patientMaintenanceScreenUatTestScripts.selectingPatientTypePetDropOffQueue();
        patientMaintenanceScreenUatTestScripts.selectingPatientTypeLivestockDropOffQueue();
        patientMaintenanceScreenUatTestScripts.editingLastName(inputData);
        patientMaintenanceScreenUatTestScripts.editingFirstName(inputData);
        patientMaintenanceScreenUatTestScripts.editingMiddleName(inputData);
        patientMaintenanceScreenUatTestScripts.validateTwinCheckBox();
        patientMaintenanceScreenUatTestScripts.editingDOB();
        patientMaintenanceScreenUatTestScripts.verifyWeightFieldDisabled();
        patientMaintenanceScreenUatTestScripts.editingWeightField();
        patientMaintenanceScreenUatTestScripts.verifyWeightField(inputData);
        patientMaintenanceScreenUatTestScripts.selectingPatientGenderMale();
        patientMaintenanceScreenUatTestScripts.selectingPatientGenderFemale();
        patientMaintenanceScreenUatTestScripts.verifyPatientActiveStatus(inputData);
        patientMaintenanceScreenUatTestScripts.verifyPatientDeceasedStatus(inputData);
        patientMaintenanceScreenUatTestScripts.editingPhysicalAddressFirstLine(inputData);
        patientMaintenanceScreenUatTestScripts.editingPhysicalAddressSecondLine(inputData);
        patientMaintenanceScreenUatTestScripts.editCity(inputData);
        patientMaintenanceScreenUatTestScripts.selectCountryInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.enterZipCodeInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.validateAutoPopulateAddressInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickCMSPartDQualifierFacilityCheckbox();
        patientMaintenanceScreenUatTestScripts.clickOnMailingAddressTab();
        patientMaintenanceScreenUatTestScripts.clearZipCodeinPTMS();
        patientMaintenanceScreenUatTestScripts.enterZipCodeInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.editingPhysicalAddressFirstLine(inputData);
        patientMaintenanceScreenUatTestScripts.editingPhysicalAddressSecondLine(inputData);
        patientMaintenanceScreenUatTestScripts.updateCityInPTMS(inputData);
        PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
        patientMaintenancePage.clickExit();
        patientMaintenancePage.clickYes();
        PatientSearchPage patientSearchPage = new PatientSearchPage();
        patientSearchPage.clickClose();
        DropOffPage dropOffPage = new DropOffPage();
        dropOffPage.clickBtnCancel();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verifying Age restriction error message for DOB greater than 150 years old in Tasco PSE screen.
     * Author:  Nagarjuna Sankarasetty(vn575ve)
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-3067")
    @Test(enabled = true,description = "Verify the functionality when the user tries to drop a PSE order for a patient who is 150 years or older", priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void HWPHME2E_3067_Verify_Error_Message_When_User_Tries_To_Drop_PSE_Order_For_Patient_Who_Is_150_Years_Or_Older(Map<String, String> inputData) {
        Reporter.log("Verify the functionality when the user tries to drop a PSE order for a patient who is 150 years or older");

        connexusAppUtils.getStoreId();
        patientMaintenanceScreenUatTestScripts.launchTascoPseudophedrineScreen();
        patientMaintenanceScreenUatTestScripts.enterPatientDetailsInPseudoephedrineScreen(inputData);
        patientMaintenanceScreenUatTestScripts.validateAgeRestrictionErrorText(inputData);

        Reporter.log("Verified the Age Restriction pop message in Tasco PSE screen");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verifying Age restriction error message for DOB greater than 150 years old in PMS screen.
     * Author:  Naveenraj(vn58o0j)
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-3069")
    @Test(enabled = true,description = "Verify the functionality when the user tries to add a patient profile who is 150 years or older in PMS screen", priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void HWPHME2E_3069_Verify_Error_Message_When_User_Tries_To_Add_Patient_Profile_Who_Is_150_Years_Or_Older(Map<String, String> inputData) {
        Reporter.log("Verify the functionality when the user tries to add a patient profile who is 150 years or older in PMS screen");

        connexusAppUtils.getStoreId();
        patientMaintenanceScreenUatTestScripts.createNewPatient(inputData);
        patientMaintenanceScreenUatTestScripts.validateAgeRestrictionErrorTextInPMSScreen(inputData);

        Reporter.log("Verified the Age Restriction pop message in PMS screen");
    }

    /*----------------------------------------------------------------------------------------------------------
         * Test Description: Validate the Special Characters entry in Card ID field in PTMS
         * and it's Value in TP Edit View, Dropoff View and claim details page.  .
         * Author:  Priyam Raj(vn58p0t)
        ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-3066")
    @Test(enabled = true,description = "Validate_the_Special_Characters_entry_in_Card_ID_field_in_PTMS", priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void HWPHME2E_3066_Validate_the_Special_Characters_entry_in_Card_ID_field_in_PTMS(Map<String, String> inputData){
        Reporter.log("Validate the Special Characters entry in Card ID field in PTMS and it's Value in TP Edit View, Dropoff View and Claim details page.");

        connexusAppUtils.getStoreId();
        patientMaintenanceScreenUatTestScripts.createNewPatient(inputData,1);
        patientMaintenanceScreenUatTestScripts.validateCardDetailsInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.validateCardDetailsFromDropoffPage( inputData);
        patientMaintenanceScreenUatTestScripts.performDropOff(Priority.Critical);
        patientMaintenanceScreenUatTestScripts.performInput(inputData);
        patientMaintenanceScreenUatTestScripts.perform4PointForTPPatient(false);
        patientMaintenanceScreenUatTestScripts.performFilling();
        patientMaintenanceScreenUatTestScripts.validateCardDetailsInClaimPage(inputData);

        Reporter.log("Verified the Special Characters entry in Card ID field in PTMS and it's Value in TP Edit View, Dropoff View and Claim details page.");
    }

    /*----------------------------------------------------------------------------------------------------------
             * Validate the Check Eligibility Functionality for a MEDICARE D Check Eligibility Plan
             *
             * Author:  Nagarjuna Sankarasetty (vn575ve)
            ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-3156")
    @Test(enabled = true,description = "Validate the Check Eligibility Functionality for a MEDICARE D Check Eligibility Plan", priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void HWPHME2E_3156_Verify_Check_Eligibility_Functionality_Medicare_D(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        patientMaintenanceScreenUatTestScripts.validateCheckEligibilityButtonInPTMSScreen(inputData);
        patientMaintenanceScreenUatTestScripts.validatePlanDetailsByClickingOnCheckEligibilityButton(inputData);
        patientMaintenanceScreenUatTestScripts.validateTpResponseViewBySelectingMedicareD();
        patientMaintenanceScreenUatTestScripts.validateAddedTPDetailsINPatientProfile(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
             * Validate the Check Eligibility Functionality for a Commercial Check Eligibility Plan
             *
             * Author:  Nagarjuna Sankarasetty (vn575ve)
            ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-3157")
    @Test(enabled = true,description = "Validate the Check Eligibility Functionality for a Commercial Check Eligibility Plan", priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void HWPHME2E_3157_Verify_Check_Eligibility_Functionality_Commercial(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        patientMaintenanceScreenUatTestScripts.validateCheckEligibilityButtonInPTMSScreen(inputData);
        patientMaintenanceScreenUatTestScripts.validatePlanDetailsByClickingOnCheckEligibilityButton(inputData);
        patientMaintenanceScreenUatTestScripts.validateTpResponseViewBySelectingCommercialPlan();
        patientMaintenanceScreenUatTestScripts.validateAddedTPDetailsINPatientProfile(inputData);
    }


    /*----------------------------------------------------------------------------------------------------------
                 * Validate the Check Eligibility Functionality for a Medicare B Check Eligibility Plan
                 *
                 * Author:  Nagarjuna Sankarasetty (vn575ve)
                ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-3155")
    @Test(enabled = true, description = "patient maintenancescreen check eligibility", priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void HWPHME2E_3155_Verify_Check_Eligibility_Functionality_Medicare_B_SSN_POPUP(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        patientMaintenanceScreenUatTestScripts.createNewPatient(inputData);
        patientMaintenanceScreenUatTestScripts.launchAndValidateCheckEligibilityButtonInPTMSScreen();
        patientMaintenanceScreenUatTestScripts.validateInvalidSSNMessageByProvidingInvalidSSNDetailsForMedicareBCheckElegibilityPlan(inputData);
        patientMaintenanceScreenUatTestScripts.validateInvalidSSNfromPTMSscreen(inputData);
        patientMaintenanceScreenUatTestScripts.validatePatientEligibilityErrorMessageByProvidingInvalidSsnNumber(inputData);
        patientMaintenanceScreenUatTestScripts.ValidateTpResponseViewByProvidingValidSsnNumberinPTMSScreen(inputData);
        patientMaintenanceScreenUatTestScripts.validateAddedTPDetailsInPatientProfileForMedicareB(inputData);
    }

    /**
     * Validate Split Bills between 2 TP Plans
     * @param inputData
     */
    @Test(enabled = true,description = "Validate Split Bills between 2 TP Plans", priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void HWPHME2E_2245_ValidateSplitBillBetweenTPPlans(Map<String,String>inputData){

        connexusAppUtils.getStoreId();
        patientMaintenanceScreenUatTestScripts.createNewPatient(inputData,2);
        patientMaintenanceScreenUatTestScripts.clickonSplitBoxCheck();
        patientMaintenanceScreenUatTestScripts.performDropOff(Priority.Critical);
        patientMaintenanceScreenUatTestScripts.performInput(inputData);
        patientMaintenanceScreenUatTestScripts.checkTpDetails(WorkQueue.FOUR_POINT,inputData);
        patientMaintenanceScreenUatTestScripts.perform4PointForTPPatient(false);
        patientMaintenanceScreenUatTestScripts.checkTpDetails(WorkQueue.FILLING,inputData);
        patientMaintenanceScreenUatTestScripts.performFilling();
        patientMaintenanceScreenUatTestScripts.performVisualVerify();
        patientMaintenanceScreenUatTestScripts.performPickUp(inputData);
        patientMaintenanceScreenUatTestScripts.performCounselling();
        patientMaintenanceScreenUatTestScripts.performPOS();
        patientMaintenanceScreenUatTestScripts.checkTpDetails(WorkQueue.EOD,inputData);
    }
    /**
     * Validate the Category of TP when Parent Plan is MEDICIAD and Child Plan is COMMERCIAL when 10925 is TRUE
     */
    //@Jira(testID = "HWPHME2E-2458")
    @Test(enabled = true,description = "Validate the Category of TP when Parent Plan is MEDICIAD and Child Plan is COMMERCIAL when 10925 is TRUE", priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void HWPHME2E_2548_Validate_the_Category_of_TP_when_Parent_Plan_is_MEDICIAD_and_Child_Plan_is_COMMERCIAL_when_10925_is_TRUE(Map<String,String>inputData){
        connexusAppUtils.getStoreId();
        connexusAppUtils.readAndUpdateFlag("10925", "TRUE");
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        patientMaintenanceScreenUatTestScripts.createNewPatient(inputData,1);
        patientMaintenanceScreenUatTestScripts.validateCatagoryNameInPTMSScreen(inputData.get("EXPECTED_CATAGORY_BEFORE"));
        patientMaintenanceScreenUatTestScripts.enterInsuranceGroupIdInPTMSScreen(inputData.get("GROUP_ID"));
        patientMaintenanceScreenUatTestScripts.validateCatagoryNameInPTMSScreen(inputData.get("EXPECTED_CATAGORY_AFTER"));
        patientMaintenanceScreenUatTestScripts.performDropOff(Priority.Critical);
        patientMaintenanceScreenUatTestScripts.performInput(inputData);
        patientMaintenanceScreenUatTestScripts.validateCatagoryNameInFourPoint(inputData.get("EXPECTED_CATAGORY_AFTER"));
        patientMaintenanceScreenUatTestScripts.ValidateInsurancePlanCodeInDB(inputData);
    }

//    *Verify_TP_category_remain_same_as_chosen_by_the_user_when_multiple_discount_cards_on_TP_profile
    //@Jira(testID = "HWPHME2E-4429")
    @Test(enabled = true, description = "Verify TP category remain same as chosen by the user when multiple discount cards on TP profile", priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen(1).json", sheetName = "UAT_PTMS")
    public void HWPHME2E_4429_Verify_TP_category_remain_same_as_chosen_by_the_user_when_multiple_discount_cards_on_TP_profile(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        patientMaintenanceScreenUatTestScripts.createNewPatient(inputData, 2);
        patientMaintenanceScreenUatTestScripts.CategorySelectinThirdyPartyInformation(inputData);

    }}
