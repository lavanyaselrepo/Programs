package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSet11 {
    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Selecting State as CL while Country is set to MX
     *              
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *              
     * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 100,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL(Map<String, String> inputData) {
        System.out.println(">>>tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX
        if(connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
            patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        patientMaintenanceScreenUatTestScripts.createPatient(inputData);

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        patientMaintenanceScreenUatTestScripts.clickAndValidateDropOffScreen();

        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.inputPatientNameInDropOff();
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select CL as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectCountryInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.enterZipCodeInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as CP while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 101,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_101_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CP(Map<String, String> inputData) {
        System.out.println(">>>tc_101_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CP<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select CP as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_101_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CP>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as CL while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 102,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_102_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CU(Map<String, String> inputData) {
        System.out.println(">>>tc_102_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CU<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select CU as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_102_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CU>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as DF while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 103,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_103_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_DF(Map<String, String> inputData) {
        System.out.println(">>>tc_103_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_DF<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select DF as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_103_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_DF>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as DG while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 104,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_104_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_DG(Map<String, String> inputData) {
        System.out.println(">>>tc_104_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_DG<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select DG as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_104_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_DG>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as EM while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 105,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_105_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_EM(Map<String, String> inputData) {
        System.out.println(">>>tc_105_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_EM<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select EM as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_105_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_EM>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as GJ while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 106,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_106_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_GJ(Map<String, String> inputData) {
        System.out.println(">>>tc_101_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CP<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select GJ as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_106_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_GJ>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as GR while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 107,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_107_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_GR(Map<String, String> inputData) {
        System.out.println(">>>tc_107_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_GR<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        patientMaintenanceScreenUatTestScripts.clickAndValidateDropOffScreen();

        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select GR as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_107_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_GR>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as HG while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 108,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_108_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_HG(Map<String, String> inputData) {
        System.out.println(">>>tc_108_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_HG<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX
        tearDown();
        patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        patientMaintenanceScreenUatTestScripts.clickAndValidateDropOffScreen();

        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.inputPatientNameInDropOff();
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select HG as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_108_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_HG>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as JA while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 109,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_109_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_JA(Map<String, String> inputData) {
        System.out.println(">>>tc_109_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_JA<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select JA as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_109_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_JA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as MH while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 110,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_110_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MH(Map<String, String> inputData) {
        System.out.println(">>>tc_110_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MH<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select MH as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_110_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MH>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as MR while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 111,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_111_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MR(Map<String, String> inputData) {
        System.out.println(">>>tc_111_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MR<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select MR as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_111_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MR>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as NA while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Keerthana Jayaraman(vn82865)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 112,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_112_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NA(Map<String, String> inputData) {
        System.out.println(">>>tc_112_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NA<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select NA as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_112_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Selecting State as NL while Country is set to MX
    *
    * Pre-Conditions:
    * 1. Physical Address Tab Selected
    * 2. Country drop down list selection set to MX
    *
    * Author: Keerthana Jayaraman(vn82865)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 113,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_100_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CL"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_113_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NL(Map<String, String> inputData) {
        System.out.println(">>>tc_113_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NL<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select NA as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        //To continue the flow of next test cases
        patientMaintenanceScreenUatTestScripts.clickCancelInDropOff();

        System.out.println("<<<tc_113_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NL>>>");
    }


}
