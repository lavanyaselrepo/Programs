package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSet13 {
    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
        connexusAppUtils = new ConnexusAppUtils();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Selecting residence type
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     * 2. An existing patient with the given test data must exist in the store
     *
     * Author: Srinivas(vn50jui)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = false, description = "Selecting residence type",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceResidenceTypeDataBook.json", sheetName = "PatientSearchDataSheet")
    public void tc_PTMS_generalInformationTab_Address_PhysicalTab_Choice_ResidenceType(Map<String, String> inputData) {
        System.out.println(">>>tc_PTMS_generalInformationTab_Address_PhysicalTab_Choice_ResidenceType<<<");

        //1. Open  Drop-Off screen by clicking on Drop-Off icon on left side menu bar.
        patientMaintenanceScreenUatTestScripts.clickAndValidateDropOffScreen();

        //3. Search for an existing patient on Drop-Off
        patientMaintenanceScreenUatTestScripts.searchForPatientInDropOffScreen(inputData);
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4. Select Residence Type in Residence Type dropdown and verify if the selected value is displayed in Residence Type dropdown.
        patientMaintenanceScreenUatTestScripts.selectResidenceTypeAddressTypePhysical();

        //5. Click on Save & Close button on PTMS screen.
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        //6. Close Drop-Off screen.
        patientMaintenanceScreenUatTestScripts.clickCancelInDropOff();

        System.out.println("<<<tc_PTMS_generalInformationTab_Address_PhysicalTab_Choice_ResidenceType>>>");
    }

}
