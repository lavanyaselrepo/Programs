package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSet15 {
    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        patientMaintenanceScreenUatTestScripts.clickExitWithoutSavingChanges();
        patientMaintenanceScreenUatTestScripts.clickCancelInDropOff();
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Editing Zip Code in Patient Maintenance Screen_AddressPhysical Tab
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     *
     * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 144,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet15.json", sheetName = "patientSearchDataSheet")
    public void tc_144_PTMS_generalInformationTab_addressPhysicalTab_edit_zip(Map<String, String> inputData) {
        System.out.println(">>>tc_144_PTMS_generalInformationTab_addressPhysicalTab_edit_zip<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        if(connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
            patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        patientMaintenanceScreenUatTestScripts.createPatient(inputData);

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        patientMaintenanceScreenUatTestScripts.clickAndValidateDropOffScreen();

        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.inputPatientNameInDropOff();
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Edit the Zip Code | Connexus should allow access to edit the zip code
        //5.Save the changes done | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectCountryInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.enterZipCodeInPTMS(inputData);

        System.out.println("<<<tc_144_PTMS_generalInformationTab_addressPhysicalTab_edit_zip>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Validate whether State and City got auto populated after entering the zip code
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     *
     * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 145,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_144_PTMS_generalInformationTab_addressPhysicalTab_edit_zip"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet15.json", sheetName = "patientSearchDataSheet")
    public void tc_145_PTMS_generalInformationTab_addressPhysicalTab_edit_validZipAutofillCityState(Map<String, String> inputData) {
        System.out.println(">>>tc_145_PTMS_generalInformationTab_addressPhysicalTab_edit_validZipAutofillCityState<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        //4.Select Country from the dropdown | Connexus should allow access to the drop down menu
        //5.Enter Zip Code | State and City should get auto populated
        patientMaintenanceScreenUatTestScripts.validateAutoPopulateAddressInPTMS(inputData);

        System.out.println("<<<tc_145_PTMS_generalInformationTab_addressPhysicalTab_edit_validZipAutofillCityState>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Validate whether the user is able to click on Check CMS Part D Qualifier Facility Checkbox
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     *
     * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 146,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_144_PTMS_generalInformationTab_addressPhysicalTab_edit_zip"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet15.json", sheetName = "patientSearchDataSheet")
    public void tc_146_PTMS_generalInformationTab_adderessPhysicalTab_cmsPartDQualifierFacilityCheckbox(Map<String, String> inputData) {
        System.out.println(">>>tc_146_PTMS_generalInformationTab_adderessPhysicalTab_cmsPartDQualifierFacilityCheckbox<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        //4.Click CMS Part D Qualifier Facility Checkbox | Connexus should allow user to check the 'CMS part D Qualifier Facility' checkbox
        patientMaintenanceScreenUatTestScripts.clickCMSPartDQualifierFacilityCheckbox();

        System.out.println("<<<tc_146_PTMS_generalInformationTab_adderessPhysicalTab_cmsPartDQualifierFacilityCheckbox>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Filling the required address fields in Mailing Address Tab
     *
     * Pre-Conditions:
     * 1. Mailing Address Tab Selected
     *
     * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 147,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_144_PTMS_generalInformationTab_addressPhysicalTab_edit_zip"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet15.json", sheetName = "patientSearchDataSheet")
    public void tc_PTMS_generalInformationTab_address_click_differentAddressTab(Map<String, String> inputData) {
        System.out.println(">>>tc_PTMS_generalInformationTab_address_click_differentAddressTab<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        //4.Navigate to Mailing address tab | Connexus should allow user to navigate into Mailing Address tab
        //5.Fill required address details | Connexus should allow user to fill required address details and save the changes
        patientMaintenanceScreenUatTestScripts.navigateDifferentAddressTabInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.fillRequiredAddressFieldsInPTMS(inputData);

        System.out.println("<<<tc_PTMS_generalInformationTab_address_click_differentAddressTab>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Editing the Address line 1 Text box in Mailing Address Tab
     *
     * Pre-Conditions:
     * 1. Mailing Address Tab Selected
     *
     * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 151,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_144_PTMS_generalInformationTab_addressPhysicalTab_edit_zip"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet15.json", sheetName = "patientSearchDataSheet")
    public void tc_151_PTMS_generalInformationTab_addressMailingTab_edit_addressLine1(Map<String, String> inputData) {
        System.out.println(">>>tc_151_PTMS_generalInformationTab_addressMailingTab_edit_addressLine1<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
         //4.Navigate to Mailing address tab | Connexus should allow user to navigate into Mailing Address tab
        //5.Edit Address Line 1 | Connexus should allow user to edit Address Line 1
        patientMaintenanceScreenUatTestScripts.navigateDifferentAddressTabInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clearZipCodeinPTMS();
        patientMaintenanceScreenUatTestScripts.editingPhysicalAddressFirstLine(inputData);

        System.out.println("<<<tc_151_PTMS_generalInformationTab_addressMailingTab_edit_addressLine1>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Editing the Address Line 2 text box in Mailing Address Tab
     *
     * Pre-Conditions:
     * 1. Mailing Address Tab Selected
     *
     * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 152,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_144_PTMS_generalInformationTab_addressPhysicalTab_edit_zip"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet15.json", sheetName = "patientSearchDataSheet")
    public void tc_152_PTMS_generalInformationTab_addressMailingTab_edit_addressLine2(Map<String, String> inputData) {
        System.out.println(">>>tc_152_PTMS_generalInformationTab_addressMailingTab_edit_addressLine2<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        //4.Navigate to Mailing address tab | Connexus should allow user to navigate into Mailing Address tab
        //5.Edit Address Line 2 | Connexus should allow user to edit Address Line 2
        patientMaintenanceScreenUatTestScripts.editingPhysicalAddressSecondLine(inputData);

        System.out.println("<<<tc_152_PTMS_generalInformationTab_addressMailingTab_edit_addressLine2>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Editing the City field in Mailing Address Tab
     *
     * Pre-Conditions:
     * 1. Mailing Address Tab Selected
     *
     * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 153,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_144_PTMS_generalInformationTab_addressPhysicalTab_edit_zip"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet15.json", sheetName = "patientSearchDataSheet")
    public void tc_153_PTMS_generalInformationTab_addressMailingTab_edit_city(Map<String, String> inputData) {
        System.out.println(">>>tc_153_PTMS_generalInformationTab_addressMailingTab_edit_city<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        //4.Navigate to Mailing address tab | Connexus should allow user to navigate into Mailing Address tab
        //5.Edit City Field | Connexus should allow user to edit City Field
        patientMaintenanceScreenUatTestScripts.updateCityInPTMS(inputData);

        System.out.println("<<<tc_153_PTMS_generalInformationTab_addressMailingTab_edit_city>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Selecting the Country as US in Mailing Address Tab
     *
     * Pre-Conditions:
     * 1. Mailing Address Tab Selected
     *
     * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 154,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_144_PTMS_generalInformationTab_addressPhysicalTab_edit_zip"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet15.json", sheetName = "patientSearchDataSheet")
    public void tc_PTMS_generalInformationTab_addressMailingTab_choice_Country(Map<String, String> inputData) {
        System.out.println(">>>tc_PTMS_generalInformationTab_addressMailingTab_choice_Country<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        //4.Navigate to Mailing address tab | Connexus should allow user to navigate into Mailing Address tab
        //5.Select US/CA/MX/PR from country dropdown | Connexus should allow user to select US/CA/MX/PR  from Country Dropdown
        patientMaintenanceScreenUatTestScripts.selectCountryInPTMS(inputData);

        System.out.println("<<<tc_PTMS_generalInformationTab_addressMailingTab_choice_Country>>>");
    }

}
