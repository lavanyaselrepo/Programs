package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.Map;

public class PatientMaintenanceScreenUatTestSet4 {
    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Selecting State as MD while Country is set to US
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created.
     * 3.Physical Address Tab Selected and Country drop down list selection set to US.
     *
     * Author: Janani Co(vn50stx)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as MD while Country is set to US",priority =1,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreenTestSet4Data.json", sheetName = "PTMSTestSet4")
    public void tc_45_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MD(Map<String, String> inputData){
        System.out.println(">>>tc_45_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MD<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US
        if(connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
            patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        patientMaintenanceScreenUatTestScripts.createPatient(inputData);

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        patientMaintenanceScreenUatTestScripts.clickAndValidateDropOffScreen();

        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.inputPatientNameInDropOff();
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select MD as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectCountryInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println(">>>tc_45_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MD<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as ME while Country is set to US
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.A valid patient profile is already created.
    * 3.Physical Address Tab Selected and Country drop down list selection set to US
    *
    * Author: Janani Co(vn50stx)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as ME while Country is set to US",priority =2,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_45_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MD"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreenTestSet4Data.json", sheetName = "PTMSTestSet4")
    public void tc_46_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_ME(Map<String, String> inputData){
        System.out.println(">>>tc_46_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_ME<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select ME as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println(">>>tc_46_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_ME<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as MH while Country is set to US
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.A valid patient profile is already created.
    * 3.Physical Address Tab Selected and Country drop down list selection set to US
    *
    * Author: Janani Co(vn50stx)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as MH while Country is set to US",priority =3,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_45_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MD"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreenTestSet4Data.json", sheetName = "PTMSTestSet4")
    public void tc_47_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MH(Map<String, String> inputData){
        System.out.println(">>>tc_47_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MH<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select MH as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println(">>>tc_47_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MH<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as MI while Country is set to US
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.A valid patient profile is already created.
    * 3.Physical Address Tab Selected and Country drop down list selection set to US
    *
    * Author: Janani Co(vn50stx)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as MI while Country is set to US",priority =4,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_45_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MD"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreenTestSet4Data.json", sheetName = "PTMSTestSet4")
    public void tc_48_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MI(Map<String, String> inputData){
        System.out.println(">>>tc_48_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MI<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select MI as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println(">>>tc_48_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MI<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as MN while Country is set to US
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.A valid patient profile is already created.
    * 3.Physical Address Tab Selected and Country drop down list selection set to US
    *
    * Author: Janani Co(vn50stx)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as MN while Country is set to US",priority =5,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_45_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MD"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreenTestSet4Data.json", sheetName = "PTMSTestSet4")

    public void tc_49_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MN(Map<String, String> inputData){
        System.out.println(">>>tc_49_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MN<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select MN as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println(">>>tc_49_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MN<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as MO while Country is set to US
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.A valid patient profile is already created.
    * 3.Physical Address Tab Selected and Country drop down list selection set to US
    *
    * Author: Janani Co(vn50stx)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as MO while Country is set to US",priority =6,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_45_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MD"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreenTestSet4Data.json", sheetName = "PTMSTestSet4")
    public void tc_50_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MO(Map<String, String> inputData){
        System.out.println(">>>tc_50_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MO<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select MO as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println(">>>tc_50_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MO<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as MP while Country is set to US
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.A valid patient profile is already created.
    * 3.Physical Address Tab Selected and Country drop down list selection set to US
    *
    * Author: Janani Co(vn50stx)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as MP while Country is set to US",priority =7,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_45_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MD"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreenTestSet4Data.json", sheetName = "PTMSTestSet4")
    public void tc_51_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MP(Map<String, String> inputData){
        System.out.println(">>>tc_51_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MP<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select MP as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println(">>>tc_51_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MP<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as MS while Country is set to US
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.A valid patient profile is already created.
    * 3.Physical Address Tab Selected and Country drop down list selection set to US
    *
    * Author: Janani Co(vn50stx)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as MS while Country is set to US",priority =8,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_45_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MD"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreenTestSet4Data.json", sheetName = "PTMSTestSet4")
    public void tc_52_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MS(Map<String, String> inputData){
        System.out.println(">>>tc_52_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MS<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select MS as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println(">>>tc_52_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MS<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as MT while Country is set to US
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.A valid patient profile is already created.
    * 3.Physical Address Tab Selected and Country drop down list selection set to US
    *
    * Author: Janani Co(vn50stx)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as MT while Country is set to US",priority =9,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_45_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MD"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreenTestSet4Data.json", sheetName = "PTMSTestSet4")
    public void tc_53_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MT(Map<String, String> inputData){
        System.out.println(">>>tc_53_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MT<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select MT as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println(">>>tc_53_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MT<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as NC while Country is set to US
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.A valid patient profile is already created.
    * 3.Physical Address Tab Selected and Country drop down list selection set to US
    *
    * Author: Janani Co(vn50stx)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as NC while Country is set to US",priority =10,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_45_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MD"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreenTestSet4Data.json", sheetName = "PTMSTestSet4")
    public void tc_54_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NC(Map<String, String> inputData){
        System.out.println(">>>tc_54_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NC<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select NC as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        //To continue the flow of next test cases
        patientMaintenanceScreenUatTestScripts.clickCancelInDropOff();

        System.out.println(">>>tc_54_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_NC<<<");
    }
    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }
}

