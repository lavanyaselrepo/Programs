package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSet7 {
    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as SC while Country is set to US
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Achyut Awasthi(vn50v7w)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 69,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US
        if(connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
            patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        patientMaintenanceScreenUatTestScripts.createPatient(inputData);

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        patientMaintenanceScreenUatTestScripts.clickAndValidateDropOffScreen();

        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.inputPatientNameInDropOff();
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the Country drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select US as Country | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectCountryInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.enterZipCodeInPTMS(inputData);

        //6.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //7.Select SC as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as SD while Country is set to US
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Achyut Awasthi(vn50v7w)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 70,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_70_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SD(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select SD as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as TN while Country is set to US
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Achyut Awasthi(vn50v7w)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 71,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_71_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_TN(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select TN as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as TX while Country is set to US
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to US
     *
     * Author: Achyut Awasthi(vn50v7w)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 72,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_72_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_TX(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select TX as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Selecting State as UT while Country is set to US
    *
    * Pre-Conditions:
    * 1. Physical Address Tab Selected
    * 2. Country drop down list selection set to US
    *
    * Author: Achyut Awasthi(vn50v7w)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 73,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_73_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_UT(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select UT as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Selecting State as VA while Country is set to US
    *
    * Pre-Conditions:
    * 1. Physical Address Tab Selected
    * 2. Country drop down list selection set to US
    *
    * Author: Achyut Awasthi(vn50v7w)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 74,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_74_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_VA(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select VA as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Selecting State as VI while Country is set to US
    *
    * Pre-Conditions:
    * 1. Physical Address Tab Selected
    * 2. Country drop down list selection set to US
    *
    * Author: Achyut Awasthi(vn50v7w)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 75,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_75_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_VI(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select VI as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
   * Test Description:Selecting State as VT while Country is set to US
   *
   * Pre-Conditions:
   * 1. Physical Address Tab Selected
   * 2. Country drop down list selection set to US
   *
   * Author: Achyut Awasthi(vn50v7w)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 76,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_76_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_VT(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select VT as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Selecting State as WA while Country is set to US
    *
    * Pre-Conditions:
    * 1. Physical Address Tab Selected
    * 2. Country drop down list selection set to US
    *
    * Author: Achyut Awasthi(vn50v7w)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 77,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_77_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_WA(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select WA as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Selecting State as WI while Country is set to US
    *
    * Pre-Conditions:
    * 1. Physical Address Tab Selected
    * 2. Country drop down list selection set to US
    *
    * Author: Achyut Awasthi(vn50v7w)
    --`--------------------------------------------------------------------------------------------------------*/
    @Test(priority = 78,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_78_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_WI(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select WI as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Selecting State as WV while Country is set to US
    *
    * Pre-Conditions:
    * 1. Physical Address Tab Selected
    * 2. Country drop down list selection set to US
    *
    * Author: Achyut Awasthi(vn50v7w)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 79,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_79_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_WV(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select WV as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Selecting State as WY while Country is set to US
    *
    * Pre-Conditions:
    * 1. Physical Address Tab Selected
    * 2. Country drop down list selection set to US
    *
    * Author: Achyut Awasthi(vn50v7w)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 80,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_80_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_WY(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to US

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select WY as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Selecting State as AB while Country is set to CA
    *
    * Pre-Conditions:
    * 1. Physical Address Tab Selected
    * 2. Country drop down list selection set to CA
    *
    * Author: Achyut Awasthi(vn50v7w)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 81,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_81_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AB(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to CA

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the Country drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select CA as Country | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectCountryInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.enterZipCodeInPTMS(inputData);

        //6.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //7.Select AB as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Selecting State as BC while Country is set to CA
    *
    * Pre-Conditions:
    * 1. Physical Address Tab Selected
    * 2. Country drop down list selection set to CA
    *
    * Author: Achyut Awasthi(vn50v7w)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 82,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_82_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_BC(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to CA

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select BC as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Selecting State as MB while Country is set to CA
    *
    * Pre-Conditions:
    * 1. Physical Address Tab Selected
    * 2. Country drop down list selection set to CA
    *
    * Author: Achyut Awasthi(vn50v7w)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 83,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_69_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_SC"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet7")
    public void tc_83_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MB(Map<String, String> inputData) {

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to CA

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select MB as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
    }
}

