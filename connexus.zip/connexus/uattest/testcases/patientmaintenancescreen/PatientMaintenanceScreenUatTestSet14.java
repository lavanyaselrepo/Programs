package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.*;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSet14 {
    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.readAndUpdateFlag("700","FALSE");
        connexusAppUtils.readAndUpdateFlag("784","FALSE");
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    @AfterClass
    public void tearDown() {
        connexusAppUtils.readAndUpdateFlag("700","TRUE");
        connexusAppUtils.readAndUpdateFlag("784","TRUE");
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /**----------------------------------------------------------------------------------------------------------
     * Test Description: Selecting State
     *
     * Pre-Conditions:
     * 1. User is logged into Connexus
     * 2. An existing patient with the given test data must exist in the store
     *
     * Author: Srinivas(vn50jui)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceStateDataBook.json", sheetName = "State")
    public void tc_PTMS_generalInformationTab_addressMailingTab_Choice_State(Map<String, String> inputData) {
        System.out.println(">>>tc_PTMS_generalInformationTab_addressMailingTab_Choice_State<<<");

        //1. Open  Drop-Off screen by clicking on Drop-Off icon on left side menu bar.
        patientMaintenanceScreenUatTestScripts.clickAndValidateDropOffScreen();

        //3. Search for an existing patient on Drop-Off
        patientMaintenanceScreenUatTestScripts.searchForPatientInDropOffScreen(inputData);
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4. Select given State in State dropdown and verify if the selected value is displayed in State dropdown.
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);

        //5. Click on Save & Close button on PTMS screen.
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        //6. Close Drop-Off screen.
        patientMaintenanceScreenUatTestScripts.clickCancelInDropOff();

        System.out.println("<<<tc_PTMS_generalInformationTab_addressMailingTab_Choice_State>>>");
    }

}
