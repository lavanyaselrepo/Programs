package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSet9 {
    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as ON while Country is set to CA
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to CA
     *
     * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 89,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet9.json", sheetName = "patientSearchDataSheet")
    public void tc_89_PTMS_generalInformationTab_addressPhysicalTab_choice_state_ON(Map<String, String> inputData) {
        System.out.println(">>>tc_89_PTMS_generalInformationTab_addressPhysicalTab_choice_state_ON<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to CA
        if(connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
            patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        patientMaintenanceScreenUatTestScripts.createPatient(inputData);

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        patientMaintenanceScreenUatTestScripts.clickAndValidateDropOffScreen();

        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.inputPatientNameInDropOff();
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select ON as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectCountryInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.enterZipCodeInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_89_PTMS_generalInformationTab_addressPhysicalTab_choice_state_ON>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as PE while Country is set to CA
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to CA
     *
     * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 90,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_89_PTMS_generalInformationTab_addressPhysicalTab_choice_state_ON"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet9.json", sheetName = "patientSearchDataSheet")
    public void tc_90_PTMS_generalInformationTab_addressPhysicalTab_choice_state_PE(Map<String, String> inputData) {
        System.out.println(">>>tc_90_PTMS_generalInformationTab_addressPhysicalTab_choice_state_PE<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to CA

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select PE as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_90_PTMS_generalInformationTab_addressPhysicalTab_choice_state_PE>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as PQ while Country is set to CA
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to CA
     *
     * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 91,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_89_PTMS_generalInformationTab_addressPhysicalTab_choice_state_ON"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet9.json", sheetName = "patientSearchDataSheet")
    public void tc_91_PTMS_generalInformationTab_addressPhysicalTab_choice_state_PQ(Map<String, String> inputData) {
        System.out.println(">>>tc_91_PTMS_generalInformationTab_addressPhysicalTab_choice_state_PQ<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to CA

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select PQ as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_91_PTMS_generalInformationTab_addressPhysicalTab_choice_state_PQ>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as QC while Country is set to CA
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to CA
     *
     * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 92,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_89_PTMS_generalInformationTab_addressPhysicalTab_choice_state_ON"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet9.json", sheetName = "patientSearchDataSheet")
    public void tc_92_PTMS_generalInformationTab_addressPhysicalTab_choice_state_QC(Map<String, String> inputData) {
        System.out.println(">>>tc_92_PTMS_generalInformationTab_addressPhysicalTab_choice_state_QC<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to CA

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select QC as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_92_PTMS_generalInformationTab_addressPhysicalTab_choice_state_QC>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Selecting State as SK while Country is set to CA
    *
    * Pre-Conditions:
    * 1. Physical Address Tab Selected
    * 2. Country drop down list selection set to CA
    *
    * Author: Dharani Ranganathan(vn50qid)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 93,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_89_PTMS_generalInformationTab_addressPhysicalTab_choice_state_ON"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBookSet9.json", sheetName = "patientSearchDataSheet")
    public void tc_93_PTMS_generalInformationTab_addressPhysicalTab_choice_state_SK(Map<String, String> inputData) {
        System.out.println(">>>tc_93_PTMS_generalInformationTab_addressPhysicalTab_choice_state_SK<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to CA

        //1.Log in to Connexus | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | Connexus should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | Connexus should allow access to the drop down menu
        //5.Select SK as State | Connexus should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        //To continue the flow of next test cases
        patientMaintenanceScreenUatTestScripts.clickCancelInDropOff();

        System.out.println("<<<tc_93_PTMS_generalInformationTab_addressPhysicalTab_choice_state_SK>>>");
    }

}
