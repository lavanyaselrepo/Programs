package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSet2 {

    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void performlogin() {
        patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
        connexusAppUtils = new ConnexusAppUtils();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Editing the second address line
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Editing the second address line", priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_16_PTMS_generalInformationTab_addressPhysicalTab_edit_addressLine2(Map<String, String> inputData) {
        System.out.println(">>>tc_16_PTMS_generalInformationTab_addressPhysicalTab_edit_addressLine2<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click in the second text field for address |Connexus should allow the user to access this text field and allow the user to add or change data */
        patientMaintenanceScreenUatTestScripts.selectingPatientTypeHumanDropOffQueue(inputData);
        patientMaintenanceScreenUatTestScripts.editingPhysicalAddressSecondLine(inputData);

        System.out.println("<<<tc_16_PTMS_generalInformationTab_addressPhysicalTab_edit_addressLine2>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Editing the city text field for a patient physical address
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Editing the city text field for a patient physical address", priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_17_PTMS_generalInformationTab_addressPhysicalTab_edit_city(Map<String, String> inputData) {
        System.out.println(">>>tc_17_PTMS_generalInformationTab_addressPhysicalTab_edit_city<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click in the city text field  | ConnexUs should allow the user to access this text field and make add data or make changes to existing data*/
        patientMaintenanceScreenUatTestScripts.editCity(inputData);

        System.out.println("<<<tc_17_PTMS_generalInformationTab_addressPhysicalTab_edit_city>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting the Country of residence as US
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting the Country of residence as US", priority = 18, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_18_PTMS_generalInformationTab_addressPhysicalTab_choice_Country_US(Map<String, String> inputData) {
        System.out.println(">>>tc_18_PTMS_generalInformationTab_addressPhysicalTab_choice_Country_US<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click the Country Drop Down Menu  | ConnexUs should allow access to the drop down menu and provide 4 options
        Step 5	Select US as Country  | ConnexUs should accept and save the user selection */
        patientMaintenanceScreenUatTestScripts.editCountry(inputData);

        System.out.println("<<<tc_18_PTMS_generalInformationTab_addressPhysicalTab_choice_Country_US>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting the Country of residence as CA
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting the Country of residence as CA", priority = 19, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_19_PTMS_generalInformationTab_addressPhysicalTab_choice_Country_CA(Map<String, String> inputData) {
        System.out.println(">>>tc_19_PTMS_generalInformationTab_addressPhysicalTab_choice_Country_CA<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click the Country Drop Down Menu  | ConnexUs should allow access to the drop down menu and provide 4 options
        Step 5	Select CA as Country  | ConnexUs should accept and save the user selection */
        patientMaintenanceScreenUatTestScripts.editCountry(inputData);

        System.out.println("<<<tc_19_PTMS_generalInformationTab_addressPhysicalTab_choice_Country_CA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting the Country of residence as MX
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting the Country of residence as MX", priority = 20, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_20_PTMS_generalInformationTab_addressPhysicalTab_choice_Country_MX(Map<String, String> inputData) {
        System.out.println(">>>tc_20_PTMS_generalInformationTab_addressPhysicalTab_choice_Country_MX<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click the Country Drop Down Menu  | ConnexUs should allow access to the drop down menu and provide 4 options
        Step 5	Select MX as Country  | ConnexUs should accept and save the user selection */
        patientMaintenanceScreenUatTestScripts.editCountry(inputData);

        System.out.println("<<<tc_20_PTMS_generalInformationTab_addressPhysicalTab_choice_Country_MX>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting the Country of residence as PR
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting the Country of residence as PR", priority = 21, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_21_PTMS_generalInformationTab_addressPhysicalTab_choice_Country_PR(Map<String, String> inputData) {
        System.out.println(">>>tc_21_PTMS_generalInformationTab_addressPhysicalTab_choice_Country_PR<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click the Country Drop Down Menu  | ConnexUs should allow access to the drop down menu and provide 4 options
        Step 5	Select PR as Country  | ConnexUs should accept and save the user selection */
        patientMaintenanceScreenUatTestScripts.editCountry(inputData);

        System.out.println("<<<tc_21_PTMS_generalInformationTab_addressPhysicalTab_choice_Country_PR>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as AK while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as AK while Country is set to US", priority = 22, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_22_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AK(Map<String, String> inputData) {
        System.out.println(">>>tc_22_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AK<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu |ConnexUs should allow access to the drop down menu
        Step 5	Select AK as State | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editCountry(inputData);
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_22_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AK>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as AL while Country is set to US
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as AL while Country is set to US", priority = 23, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_23_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AL(Map<String, String> inputData) {
        System.out.println(">>>tc_23_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AL<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu |ConnexUs should allow access to the drop down menu
        Step 5	Select AL as State  | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_23_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AL>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as AR while Country is set to US
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as AR while Country is set to US", priority = 24, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_24_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AR(Map<String, String> inputData) {
        System.out.println(">>>tc_24_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AR<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu |ConnexUs should allow access to the drop down menu
        Step 5	Select AR as State | ConnexUs should accept and save the user selection */
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_24_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AR>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as AS while Country is set to US
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as AS while Country is set to US", priority = 25, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_25_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AS(Map<String, String> inputData) {
        System.out.println(">>>tc_25_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AS<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu |ConnexUs should allow access to the drop down menu
        Step 5	Select AS as State | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_25_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AS>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as AZ while Country is set to US
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as AZ while Country is set to US", priority = 26, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_26_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AZ(Map<String, String> inputData) {
        System.out.println(">>>tc_26_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AZ<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu |ConnexUs should allow access to the drop down menu
        Step 5	Select AZ as State | ConnexUs should accept and save the user selection */
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_26_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_AZ>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as CA while Country is set to US
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as CA while Country is set to US", priority = 27, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_27_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CA(Map<String, String> inputData) {
        System.out.println(">>>tc_27_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CA<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu |ConnexUs should allow access to the drop down menu
        Step 5	Select CA as State | ConnexUs should accept and save the user selection */
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_27_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as CO while Country is set to US
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as CO while Country is set to US", priority = 28, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_28_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CO(Map<String, String> inputData) {
        System.out.println(">>>tc_28_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CO<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu |ConnexUs should allow access to the drop down menu
        Step 5	Select CO as State | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_28_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CO>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as CT while Country is set to US
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as CT while Country is set to US", priority = 29, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_29_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CT(Map<String, String> inputData) {
        System.out.println(">>>tc_29_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CT<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu |ConnexUs should allow access to the drop down menu
        Step 5	Select CT as State | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_29_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_CT>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Selecting State as DC while Country is set to US
    * Author:  Kandarbha Trivedi(vn51eqd)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as DC while Country is set to US", priority = 30, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_30_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_DC(Map<String, String> inputData) {
        System.out.println(">>>tc_30_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_DC<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu |ConnexUs should allow access to the drop down menu
        Step 5	Select DC as State | ConnexUs should accept and save the user selection */
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_30_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_DC>>>");
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

}