package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSet12 {
    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
   * Test Description:Selecting State as OA while Country is set to MX
   *
   * Pre-Conditions:
   * 1. Physical Address Tab Selected
   * 2. Country drop down list selection set to MX
   *
   * Author: Lakshmi Priya(vn510nm)
  ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 114, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA(Map<String, String> inputData) {
        System.out.println(">>>tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX
        if (connexusAppUtils.readAndUpdateFlag("26849", "TRUE")) {
            tearDown();
            patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
            patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        patientMaintenanceScreenUatTestScripts.createPatient(inputData);

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        patientMaintenanceScreenUatTestScripts.clickAndValidateDropOffScreen();

        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.inputPatientNameInDropOff();
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select OA as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectCountryInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.enterZipCodeInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as PU while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 115, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_115_PTMS_generalInformationTab_addressPhysicalTab_choice_state_PU(Map<String, String> inputData) {
        System.out.println(">>>tc_115_PTMS_generalInformationTab_addressPhysicalTab_choice_state_PU<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select PU as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_115_PTMS_generalInformationTab_addressPhysicalTab_choice_state_PU>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as QA while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 116, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_116_PTMS_generalInformationTab_addressPhysicalTab_choice_state_QA(Map<String, String> inputData) {
        System.out.println(">>>tc_116_PTMS_generalInformationTab_addressPhysicalTab_choice_state_QA<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select QA as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_116_PTMS_generalInformationTab_addressPhysicalTab_choice_state_QA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as QR while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 117, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_117_PTMS_generalInformationTab_addressPhysicalTab_choice_state_QA(Map<String, String> inputData) {
        System.out.println(">>>tc_117_PTMS_generalInformationTab_addressPhysicalTab_choice_state_QR<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select QR as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_117_PTMS_generalInformationTab_addressPhysicalTab_choice_state_QR>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as SI while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 118, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_118_PTMS_generalInformationTab_addressPhysicalTab_choice_state_SI(Map<String, String> inputData) {
        System.out.println(">>>tc_118_PTMS_generalInformationTab_addressPhysicalTab_choice_state_SI<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select SI as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_118_PTMS_generalInformationTab_addressPhysicalTab_choice_state_SI>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as SL while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 119, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_119_PTMS_generalInformationTab_addressPhysicalTab_choice_state_SL(Map<String, String> inputData) {
        System.out.println(">>>tc_119_PTMS_generalInformationTab_addressPhysicalTab_choice_state_SL<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select SL as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_119_PTMS_generalInformationTab_addressPhysicalTab_choice_state_SL>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as SO while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 120, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_120_PTMS_generalInformationTab_addressPhysicalTab_choice_state_SO(Map<String, String> inputData) {
        System.out.println(">>>tc_120_PTMS_generalInformationTab_addressPhysicalTab_choice_state_SO<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select SO as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_120_PTMS_generalInformationTab_addressPhysicalTab_choice_state_SO>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as TA while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 121, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_121_PTMS_generalInformationTab_addressPhysicalTab_choice_state_TA(Map<String, String> inputData) {
        System.out.println(">>>tc_121_PTMS_generalInformationTab_addressPhysicalTab_choice_state_TA<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select TA as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_121_PTMS_generalInformationTab_addressPhysicalTab_choice_state_TA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as TL while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 122, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_122_PTMS_generalInformationTab_addressPhysicalTab_choice_state_TL(Map<String, String> inputData) {
        System.out.println(">>>tc_122_PTMS_generalInformationTab_addressPhysicalTab_choice_state_TL<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select TL as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_122_PTMS_generalInformationTab_addressPhysicalTab_choice_state_TL>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as TM while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 123, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_123_PTMS_generalInformationTab_addressPhysicalTab_choice_state_TM(Map<String, String> inputData) {
        System.out.println(">>>tc_123_PTMS_generalInformationTab_addressPhysicalTab_choice_state_TM<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select TM as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_123_PTMS_generalInformationTab_addressPhysicalTab_choice_state_TM>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as VL while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 124, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_124_PTMS_generalInformationTab_addressPhysicalTab_choice_state_VL(Map<String, String> inputData) {
        System.out.println(">>>tc_124_PTMS_generalInformationTab_addressPhysicalTab_choice_state_VL<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select VL as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_124_PTMS_generalInformationTab_addressPhysicalTab_choice_state_VL>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as YC while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 125, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_125_PTMS_generalInformationTab_addressPhysicalTab_choice_state_YC(Map<String, String> inputData) {
        System.out.println(">>>tc_125_PTMS_generalInformationTab_addressPhysicalTab_choice_state_YC<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select YC as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_125_PTMS_generalInformationTab_addressPhysicalTab_choice_state_YC>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as ZT while Country is set to MX
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to MX
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 126, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_126_PTMS_generalInformationTab_addressPhysicalTab_choice_state_ZT(Map<String, String> inputData) {
        System.out.println(">>>tc_126_PTMS_generalInformationTab_addressPhysicalTab_choice_state_ZT<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to MX

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select ZT as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();

        System.out.println("<<<tc_126_PTMS_generalInformationTab_addressPhysicalTab_choice_state_ZT>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Selecting State as PR while Country is set to PR
     *
     * Pre-Conditions:
     * 1. Physical Address Tab Selected
     * 2. Country drop down list selection set to PR
     *
     * Author: Lakshmi Priya(vn510nm)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 127, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
    dependsOnMethods = {"tc_114_PTMS_generalInformationTab_addressPhysicalTab_choice_state_OA"})
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceDataBook.json", sheetName = "patientSearchDataSheet")
    public void tc_127_PTMS_generalInformationTab_addressPhysicalTab_choice_state_PR(Map<String, String> inputData) {
        System.out.println(">>>tc_127_PTMS_generalInformationTab_addressPhysicalTab_choice_state_PR<<<");

        //Pre-Conditions:
        //1. Physical Address Tab Selected
        //2. Country drop down list selection set to PR

        //1.Log in to ConnexUs | Connexus should allow the user to log in
        //2.Open Drop Off | Drop off should open successfully
        //3.Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        patientMaintenanceScreenUatTestScripts.clickPatientMaintenanceIconInDropOff();

        //4.Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        //5.Select PR as State | ConnexUs should accept and save the user selection
        patientMaintenanceScreenUatTestScripts.selectCountryInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.enterZipCodeInPTMS(inputData);
        // The below method looks for the zipcode validation for Country 'PR'
        patientMaintenanceScreenUatTestScripts.validateZipCode(inputData);
        // The address is saved for validated zip code
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();
        // The below method selects the state 'PR' from the state drop down on ptms screen
        patientMaintenanceScreenUatTestScripts.selectStateInPTMS(inputData);
        patientMaintenanceScreenUatTestScripts.clickSaveAndCloseInPTMS();
        // Address is revalidated and is saved for the patient on ptms screen for the given state 'PR'
        patientMaintenanceScreenUatTestScripts.saveEnteredAddressForPatientMaintenance();

        //To continue the flow of next test cases
        patientMaintenanceScreenUatTestScripts.clickCancelInDropOff();

        System.out.println("<<<tc_127_PTMS_generalInformationTab_addressPhysicalTab_choice_state_PR>>>");
    }
}
