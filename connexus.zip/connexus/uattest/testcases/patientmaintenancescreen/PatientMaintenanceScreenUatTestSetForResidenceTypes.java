package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.coretest.testscripts.PatientMaintenanceScreenScript;
import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.pageobjectmodels.connexus.DropOffPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.PatientMaintenancePage;
import hwqe.baseframework.models.pageobjectmodels.connexus.PatientSearchPage;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.utilities.PropertyReader;
import rdm.centralpatient.datamodels.response.patientsearchcentral.Patient;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSetForResidenceTypes {
    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();


    @BeforeClass
    public void performlogin(){
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();

    }


    @Test(enabled = true, description = "To verify if the user is able to select the residence type dropdown options for different address tabs",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceResidenceTypeDataBook.json", sheetName = "PatientSearchDataSheet")
    public void HWPHME2E_551_tc_PTMS_generalInformationTab_Choice_ResidenceType(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        patientMaintenanceScreenUatTestScripts.selectingPatientTypeHumanDropOffQueue(inputData);
        Reporter.log("Physical Address Tab is opened");
        patientMaintenanceScreenUatTestScripts.selectResidenceTypeAddressTypePhysical();
        Reporter.log("Residence Type dropdowns are selected for Physical Address Tab");
        Reporter.log("Mailing Address Tab is clicked");
        patientMaintenanceScreenUatTestScripts.clickOnMailingAddressTab();
        patientMaintenanceScreenUatTestScripts.selectResidenceTypeAddressTypeMailing();
        Reporter.log("Residence Type dropdowns are selected for Mailing Address Tab");
        Reporter.log("Temporary Address Tab is clicked");
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();
        patientMaintenanceScreenUatTestScripts.selectResidenceTypeAddressTypeTemp();
        Reporter.log("Residence Type dropdowns are selected for Temporary Address Tab");
        PatientMaintenancePage patientMaintenancePage =  new PatientMaintenancePage();
        patientMaintenancePage.clickExit();
        patientMaintenancePage.clickYes();
        PatientSearchPage patientSearchPage = new PatientSearchPage();
        patientSearchPage.clickClose();
        DropOffPage dropOffPage = new DropOffPage();
        dropOffPage.clickBtnCancel();
    }

}

