package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
//import connexus.uattest.testscripts.PatientMaintenanceTestSetScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSet3 {

    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtlis;

    @BeforeClass
    public void performlogin() {
        patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
        connexusAppUtlis = new ConnexusAppUtils();
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as DE while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as DE while Country is set to US", priority = 31, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_31_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_DE(Map<String, String> inputData) {
        System.out.println(">>>tc_31_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_DE<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select DE as State | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.selectingPatientTypeHumanDropOffQueue(inputData);
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_31_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_DE>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as FL while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as FL while Country is set to US", priority = 32, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_32_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_FL(Map<String, String> inputData) {
        System.out.println(">>>tc_32_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_FL<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select FL as State | ConnexUs should accept and save the user selection */
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_32_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_FL>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as FM while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as FM while Country is set to US", priority = 33, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_33_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_FM(Map<String, String> inputData) {
        System.out.println(">>>tc_33_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_FM<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select FM as State | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_33_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_FM>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as GA while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as GA while Country is set to US", priority = 34, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_34_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_GA(Map<String, String> inputData) {
        System.out.println(">>>tc_34_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_GA<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select GA as State| ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_34_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_GA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as GU while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as GU while Country is set to US", priority = 35, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_35_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_GU(Map<String, String> inputData) {
        System.out.println(">>>tc_35_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_GU<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select GU as State | ConnexUs should accept and save the user selection */
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_35_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_GU>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as HI while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as HI while Country is set to US", priority = 36, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_36_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_HI(Map<String, String> inputData) {
        System.out.println(">>>tc_36_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_HI<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select HI as State | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_36_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_HI>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as IA while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as IA while Country is set to US", priority = 37, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_37_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_IA(Map<String, String> inputData) {
        System.out.println(">>>tc_37_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_IA<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select IA as State | ConnexUs should accept and save the user selection */
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_37_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_IA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as ID while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as ID while Country is set to US", priority = 38, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_38_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_ID(Map<String, String> inputData) {
        System.out.println(">>>tc_38_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_ID<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select ID as State | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_38_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_ID>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as IL while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as IL while Country is set to US", priority = 39, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_39_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_IL(Map<String, String> inputData) {
        System.out.println(">>>tc_39_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_IL<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select IL as State | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_39_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_IL>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as IN while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as IN while Country is set to US", priority = 40, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_40_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_IN(Map<String, String> inputData) {
        System.out.println(">>>tc_40_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_IN<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select IN as State | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_40_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_IN>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as KS while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as KS while Country is set to US", priority = 41, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_41_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_KS(Map<String, String> inputData) {
        System.out.println(">>>tc_41_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_KS<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select KS as State | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_41_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_KS>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as KY while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as KY while Country is set to US", priority = 42, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_42_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_KY(Map<String, String> inputData) {
        System.out.println(">>>tc_42_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_KY<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select KY as State| ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_42_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_KY>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as LA while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as LA while Country is set to US", priority = 43, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_43_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_LA(Map<String, String> inputData) {
        System.out.println(">>>tc_43_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_LA<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select LA as State | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_43_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_LA>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
* Test Description: Selecting State as MA while Country is set to US
* Author:  Kandarbha Trivedi(vn51eqd)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Selecting State as MA while Country is set to US", priority = 44, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceScreen.json", sheetName = "UAT_PTMS")
    public void tc_44_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MA(Map<String, String> inputData) {
        System.out.println(">>>tc_44_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MA<<<");

        /* Steps :
        Step 1	Log in to ConnexUs | Connexus should allow the user to log in
        Step 2	Open Drop Off | Drop off should open successfully
        Step 3	Look up an existing patient or look up a non-existing patient | ConnexUs should either find the patient or allow the user to create a new patient
        Step 4	Click on the State drop down menu | ConnexUs should allow access to the drop down menu
        Step 5	Select MA as State | ConnexUs should accept and save the user selection*/
        patientMaintenanceScreenUatTestScripts.editStateWithCountry(inputData);

        System.out.println("<<<tc_44_PTMS_generalInformationTab_adderessPhysicalTab_choice_state_MA>>>");
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

}