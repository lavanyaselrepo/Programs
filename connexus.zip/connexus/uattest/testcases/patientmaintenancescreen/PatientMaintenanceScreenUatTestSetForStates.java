package connexus.uattest.testcases.patientmaintenancescreen;

import connexus.coretest.testscripts.PatientMaintenanceScreenScript;
import connexus.uattest.testscripts.PatientMaintenanceScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.pageobjectmodels.connexus.DropOffPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.PatientMaintenancePage;
import hwqe.baseframework.models.pageobjectmodels.connexus.PatientSearchPage;
import hwqe.baseframework.utilities.Reporter;
import opticaltests.patienttests.datamodels.api.Patient;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.utilities.PropertyReader;

import java.util.Map;

public class PatientMaintenanceScreenUatTestSetForStates {
    PatientMaintenanceScreenUatTestScripts patientMaintenanceScreenUatTestScripts = new PatientMaintenanceScreenUatTestScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();

    @BeforeClass
    public void performlogin(){
        patientMaintenanceScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    @AfterClass
    public void closeConnexus() {
        connexusAppUtils.stopAppiumServer();
    }


    @Test(enabled = true, description = "To verify if the user is able to select the country and corresponding states for different address tabs",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/PatientMaintenanceScreen/PatientMaintenanceResidenceTypeDataBook.json", sheetName = "PatientSearchDataSheet")
    public void HWPHME2E_550_tc_PTMS_generalInformationTab_Choice_State(Map<String, String> inputData) {
        connexusAppUtils.getStoreId();
        Reporter.log("Physical Address Tab is opened");
        patientMaintenanceScreenUatTestScripts.enterPatientDetailsDropOffQueue(inputData);
        patientMaintenanceScreenUatTestScripts.selectCountryStateDropdown(inputData);
        Reporter.log("Mailing Address Tab is clicked");
        patientMaintenanceScreenUatTestScripts.clickOnMailingAddressTab();
        patientMaintenanceScreenUatTestScripts.selectCountryStateDropdown(inputData);
        Reporter.log("Residence Type dropdowns are selected for Mailing Address Tab");
        Reporter.log("Temporary Address Tab is clicked");
        patientMaintenanceScreenUatTestScripts.clickOnTemporaryAddressTab();
        patientMaintenanceScreenUatTestScripts.selectCountryStateDropdown(inputData);
        Reporter.log("Facility Address Tab is clicked");
        patientMaintenanceScreenUatTestScripts.clickOnFacilityAddressTab();
        patientMaintenanceScreenUatTestScripts.selectCountryStateDropdown(inputData);
        PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();
        patientMaintenancePage.clickExit();
        patientMaintenancePage.clickYes();
        PatientSearchPage patientSearchPage = new PatientSearchPage();
        patientSearchPage.clickClose();
        DropOffPage dropOffPage = new DropOffPage();
        dropOffPage.clickBtnCancel();
        AutomationManager.getInstance().getConnexus().closeConnexus();

    }

}

