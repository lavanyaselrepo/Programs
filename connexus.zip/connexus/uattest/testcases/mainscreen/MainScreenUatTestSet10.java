package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class MainScreenUatTestSet10 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;
    MenuBar menuBar;
    AutomationManager automationManager;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        AutomationManager.getInstance().performSleep(10);
        connexusAppUtils.startAppiumServer();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        automationManager = AutomationManager.getInstance();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------          
     * Test Description:Check for access to printing when the main screen is empty        
     *        
     * Pre-Conditions:Main screen must be empty     
     *        
     * Author: Ashok(Vn50h3h)          
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 115, description = "Check for access to printing when the main screen is empty", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_115_Main_Screen_file_print_access_check(Map<String, String> inputData) {
        System.out.println(">>>tc_115_Main_Screen_file_print_access_check<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select File -> Print from the top menu | Print Should be
        // grayed out
        mainScreenUatTestScripts.validatePrintMenuDisabled();
        connexusStartPage.pressEscapeKey();

        System.out.println("<<<tc_115_Main_Screen_file_print_access_check>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Shortcut check for printing when the main screen is empty
     *
     * Pre-Conditions:Main screen must be empty
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 116, description = "Shortcut check for printing when the main screen is empty", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_116_Main_Screen_print_shortcut(Map<String, String> inputData) {
        System.out.println(">>>tc_116_Main_Screen_print_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + P | Nothing should happen
        mainScreenUatTestScripts.validatePrintShortcutDoNothing();

        System.out.println("<<<tc_116_Main_Screen_print_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Check for access to the print steup/print options
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 117, description = "Check for access to the print steup/print options", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_117_Main_Screen_file_print_setup_access_check(Map<String, String> inputData) {
        System.out.println(">>>tc_117_Main_Screen_file_print_setup_access_check<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select File - > Print Setup from the top menu | Print
        // steup/Print options screen should appear
        mainScreenUatTestScripts.validatePrintSetupMenu();

        System.out.println("<<<tc_117_Main_Screen_file_print_setup_access_check>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Option check for logging out of Connexus
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
     *
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 118, description = "Option check for logging out of Connexus", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_118_Main_Screen_file_log_off_and_sign_on_as_another_user_option_check(Map<String, String> inputData) {
        System.out.println(">>>tc_118_Main_Screen_file_log_off_and_sign_on_as_another_user_option_check<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select File - > Log off and sign on as another user from the
        // top menu | Connexus should close and log the user off and bring up
        // the log in screen
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_118_Main_Screen_file_log_off_and_sign_on_as_another_user_option_check>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Shortcut check for logging out of connexus
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
     *
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 119, description = "Shortcut check for logging out of connexus", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_119_Main_Screen_log_off_and_sign_on_as_another_user_shortcut_check_f12(Map<String, String> inputData) {
        System.out.println(">>>tc_119_Main_Screen_log_off_and_sign_on_as_another_user_shortcut_check_f12<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press F12 | Connexus should close and log the user off and
        // bring up the log in screen
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_119_Main_Screen_log_off_and_sign_on_as_another_user_shortcut_check_f12>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Option check for closing connexus
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-543")
    @Test(priority = 120, description = "Option check for closing connexus", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void HWPHME2E_543_Tc_120_Main_Screen_file_exit_option_check(Map<String, String> inputData) {
        Reporter.log("Validating Exit option from file menu");
        connexusAppUtils.getStoreId();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select File -> exit from the top menu | Connexus should close
        // and return the user to the Connexus Desktop
        mainScreenUatTestScripts.selectNavigation(AppMenu.EXIT, AppMenuItemsIndex.FILE_EXIT,null);

        Reporter.log("Connexus application closed");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Shortcut Check for closing connexus
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 121, description = "Shortcut Check for closing connexus", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_121_Main_Screen_exit_close_shortcut_for_connexus(Map<String, String> inputData) {
        System.out.println(">>>tc_121_Main_Screen_exit_close_shortcut_for_connexus<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press ALT + F4 | Connexus should close and return the user to
        // the Connexus Desktop
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        automationManager = AutomationManager.getInstance();
        menuBar = new MenuBar();
        connexusStartPage.inputShortcutKeys(AppShortcuts.EXIT.getAppShortcuts());

        System.out.println("<<<tc_121_Main_Screen_exit_close_shortcut_for_connexus>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Shortcut check for get work when screen is empty
     *
     * Pre-Conditions:No queues highlighted
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 122, description = "Shortcut check for get work when screen is empty", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_122_Main_Screen_shortcut_check_for_get_work(Map<String, String> inputData) {
        System.out.println(">>>tc_122_Main_Screen_shortcut_check_for_get_work<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press F5 | No work should feed
        connexusStartPage.inputShortcutKeys(AppShortcuts.CHECK_WORK_QUEUE.getAppShortcuts());
        mainScreenUatTestScripts.validateNoScreenDisplayed(SearchItem.CHECK_WORK_QUEUE);
        connexusStartPage.pressEscapeKey();

        System.out.println("<<<tc_122_Main_Screen_shortcut_check_for_get_work>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Get work Icon check from main screen
     *
     * Pre-Conditions:No queues highlighted
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 123, description = "Get work Icon check from main screen", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_123_Main_Screen_icon_check_for_get_work(Map<String, String> inputData) {
        System.out.println(">>>tc_123_Main_Screen_icon_check_for_get_work<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click the get work icon | No work should feed
        mainScreenUatTestScripts.clickQuickAccessIconFor(SearchItem.CHECK_WORK_QUEUE, inputData);
        mainScreenUatTestScripts.validateNoScreenDisplayed(SearchItem.CHECK_WORK_QUEUE);
        connexusStartPage.pressEscapeKey();

        System.out.println("<<<tc_123_Main_Screen_icon_check_for_get_work>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Access check for get work from the Work Queue Menu
     *
     * Pre-Conditions:No queues highlighted
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 124, description = "Access check for get work from the Work Queue Menu", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_124_Main_Screen_get_work_from_work_queue_menu(Map<String, String> inputData) {
        System.out.println(">>>tc_124_Main_Screen_get_work_from_work_queue_menu<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Work Queue -> Check for Work | No work should feed
        menuBar.navigateToMenu(AppMenu.CHECK_WORK_QUEUE);
        mainScreenUatTestScripts.validateNoScreenDisplayed(SearchItem.CHECK_WORK_QUEUE);
        connexusStartPage.pressEscapeKey();

        System.out.println("<<<tc_124_Main_Screen_get_work_from_work_queue_menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Shortcut check for opening TASCO
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 125, description = "Shortcut check for opening TASCO", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_125_Main_Screen_shortcut_check_for_pickup_tasco(Map<String, String> inputData) {
        System.out.println(">>>tc_125_Main_Screen_shortcut_check_for_pickup_tasco<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press F11 | TASCO Should open
        connexusStartPage.inputShortcutKeys(AppShortcuts.PICKUP.getAppShortcuts());
        mainScreenUatTestScripts.validateTascoScreen();

        System.out.println("<<<tc_125_Main_Screen_shortcut_check_for_pickup_tasco>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Access check for Explain Drug Sub from main screen
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 126, description = "Access check for Explain Drug Sub from main screen", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_126_Main_Screen_tools_explain_drug_sub(Map<String, String> inputData) {
        System.out.println(">>>tc_126_Main_Screen_tools_explain_drug_sub<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Explain Drug Sub from top menu | Drug
        // Selection screen should appear
        menuBar.navigateToMenu(AppMenu.EXPLAIN_DRUG_SUB);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.EXPLAIN_DRUG_SUB);

        System.out.println("<<<tc_126_Main_Screen_tools_explain_drug_sub>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Access check for Quick Quote from main screen
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 127, description = "Access check for Quick Quote from main screen", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_127_Main_Screen_tools_quick_quote(Map<String, String> inputData) {
        System.out.println(">>>tc_127_Main_Screen_tools_quick_quote<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Quick Quote from the top menu | Quick Quote
        // Screen should appear
        menuBar.navigateToMenu(AppMenu.QUICK_QUOTE);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.QUICK_QUOTE);

        System.out.println("<<<tc_127_Main_Screen_tools_quick_quote>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Shortcut Check for quick quote from main screen
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 128, description = "Shortcut Check for quick quote from main screen", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_128_Main_Screen_shortcut_check_for_quick_quote(Map<String, String> inputData) {
        System.out.println(">>>tc_128_Main_Screen_shortcut_check_for_quick_quote<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press F8 | Quick Quote screen should appear
        connexusStartPage.inputShortcutKeys(AppShortcuts.QUICK_QUOTE.getAppShortcuts());
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.QUICK_QUOTE);

        System.out.println("<<<tc_128_Main_Screen_shortcut_check_for_quick_quote>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Access check for New Prescription Request from main screen
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 129, description = "Access check for New Prescription Request from main screen", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_129_Main_Screen_tools_prescription_request_new_prescription(Map<String, String> inputData) {
        System.out.println(">>>tc_129_Main_Screen_tools_prescription_request_new_prescription<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Prescription Request -> New Prescription from
        // top menu | New Prescription Screen should appear
        menuBar.navigateToMenu(AppMenu.NEW_PRESCRIPTION);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.NEW_PRESCRIPTION);

        System.out.println("<<<tc_129_Main_Screen_tools_prescription_request_new_prescription>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Access check for Transfer Request from main screen
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 130, description = "Access check for Transfer Request from main screen", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet10")
    public void tc_130_Main_Screen_tools_prescription_request_transfer_request(Map<String, String> inputData) {
        System.out.println(">>>tc_130_Main_Screen_tools_prescription_request_transfer_request<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Prescription Request -> Transfer Request from
        // top menu | Transfer Request Screen Should appear
        menuBar.navigateToMenu(AppMenu.TRANSFER_REQUEST);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.TRANSFER_REQUEST);

        System.out.println("<<<tc_130_Main_Screen_tools_prescription_request_transfer_request>>>");
    }
}
