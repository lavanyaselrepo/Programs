package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.AppMenu;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.SearchItem;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainScreenUatTestSet11 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;
    MenuBar menuBar;
    AutomationManager automationManager;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        automationManager = AutomationManager.getInstance();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for store settings from main screen          
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h)                
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 131, description = "Access check for store settings from main screen")
    public void tc_131_Main_Screen_Tools_Store_Settings() {
        System.out.println(">>>tc_131_Main_Screen_Tools_Store_Settings<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Store Settings from top menu | Store Setting
        // screen should appear
        menuBar.navigateToMenu(AppMenu.STORE_SETTINGS);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.STORE_SETTINGS);

        System.out.println("<<<tc_131_Main_Screen_Tools_Store_Settings<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for immunization settings from main screen         
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h)                
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 132, description = "Access check for immunization settings from main screen")
    public void tc_132_Main_Screen_Tools_Immunization_settings() {
        System.out.println(">>>tc_132_Main_Screen_Tools_Immunization_settings<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Immunization Settings from top menu |
        // Immunization Settings screen Should Appear
        menuBar.navigateToMenu(AppMenu.IMMUNIZATION_SETTINGS);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.IMMUNIZATION_SETTINGS);

        System.out.println("<<<tc_132_Main_Screen_Tools_Immunization_settings<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for naloxone settings from main screen         
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h)                
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 133, description = "Access check for naloxone settings from main screen")
    public void tc_133_Main_Screen_Tools_Naloxone_Settings() {
        System.out.println(">>>tc_133_Main_Screen_Tools_Naloxone_Settings<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Naloxone Settings from top menu | Naloxone
        // Settings screen should appear
        menuBar.navigateToMenu(AppMenu.NALOXONE_SETTINGS);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.NALOXONE_SETTINGS);

        System.out.println("<<<tc_133_Main_Screen_Tools_Naloxone_Settings<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for resolution settings from main screen          
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h)                
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 134, description = "Access check for resolution settings from main screen ")
    public void tc_134_Main_Screen_Tools_Resolution_Settings() {
        System.out.println(">>>tc_134_Main_Screen_Tools_Resolution_Settings<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Resolution settings | Resolution Options
        // Screen Should appear
        menuBar.navigateToMenu(AppMenu.RESOLUTION_SETTINGS);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.RESOLUTION_SETTINGS);

        System.out.println("<<<tc_134_Main_Screen_Tools_Resolution_Settings<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Alternate Access check for resolution settings from main screen.        
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h)                
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 135, description = "Access check for resolution settings from main screen")
    public void tc_135_Main_Screen_Alternate_Resolution_setttings_method() {
        System.out.println(">>>tc_135_Main_Screen_Alternate_Resolution_setttings_method<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Right click resolution in the left menu bar | Submenu should
        // appear at cursor with the word customize
        mainScreenUatTestScripts.rightClickOnLeftMenuBar();

        // Step 3 Click Customize from the submenu | Resolution Options Screen
        // Should appear
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.RESOLUTION_SETTINGS);

        System.out.println("<<<tc_135_Main_Screen_Alternate_Resolution_setttings_method<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for Beeper Maintenance from main screen          
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h)                
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 136, description = "Access check for Beeper Maintenance from main screen")
    public void tc_136_Main_screen_Tools_Beeper_Maintanence() {
        System.out.println(">>>tc_136_Main_screen_Tools_Beeper_Maintanence<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Beeper Maintenance from top menu | Assign
        // Beeper Number screen should appear
        menuBar.navigateToMenu(AppMenu.BEEPER_MAINTENANCE);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.BEEPER_MAINTENANCE);

        System.out.println("<<<tc_136_Main_screen_Tools_Beeper_Maintanence<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for Drug interaction check from main screen          
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h)                
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 137, description = "Access check for Drug interaction check from main screen ")
    public void tc_137_Main_Screen_Tools_Drug_interaction() {
        System.out.println(">>>tc_137_Main_Screen_Tools_Drug_interaction<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Drug Interaction | Drug Interaction screen
        // should appear
        menuBar.navigateToMenu(AppMenu.DRUG_INTERACTION);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.DRUG_INTERACTION);

        System.out.println("<<<tc_137_Main_Screen_Tools_Drug_interaction<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for Quick Keys access from the main screen         
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h)                
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 138, description = "Access check for Quick Keys access from the main screen")
    public void tc_138_Main_Screen_Tools_Quick_Keys() {
        System.out.println(">>>tc_138_Main_Screen_Tools_Quick_Keys<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Quick Keys | Quick Key Setup screen should
        // appear
        menuBar.navigateToMenu(AppMenu.QUICK_KEYS);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.QUICK_KEYS);

        System.out.println("<<<tc_138_Main_Screen_Tools_Quick_Keys<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for opening Inmar Returns from the main screen         
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h) 
     * 
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 139, description = "Access check for opening Inmar Returns from the main screen ")
    public void tc_139_Main_Screen_Tools_Order_and_Distribution_Inmar_Returns() {
        System.out.println(">>>tc_139_Main_Screen_Tools_Order_and_Distribution_Inmar_Returns<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Order and Distribution -> Inmar Returns |
        // Connexus should open the Inmar Returns webpage in Chrome
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_139_Main_Screen_Tools_Order_and_Distribution_Inmar_Returns<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for opening McKesson Connect from the main screen   
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h)
     * 
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 140, description = "Access check for opening McKesson Connect from the main screen ")
    public void tc_140_Main_Screen_Tools_Order_and_Distribution_McKesson_Online() {
        System.out.println(">>>tc_140_Main_Screen_Tools_Order_and_Distribution_McKesson_Online<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Order and Distribution -> Mckesson Online |
        // Connexus should open the McKesson Connect webpage in Chrome
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_140_Main_Screen_Tools_Order_and_Distribution_McKesson_Online<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for opening Supplylogix from the main screen          
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h)   
     * 
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 141, description = "Access check for opening Supplylogix from the main screen ")
    public void tc_141_Main_Screen_Tools_Order_and_Distribution_Supplylogix() {
        System.out.println(">>>tc_141_Main_Screen_Tools_Order_and_Distribution_Supplylogix<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Order and Distribution -> Supplylogix |
        // Connexus should open the Supplylogix webpage in Chrome
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_141_Main_Screen_Tools_Order_and_Distribution_Supplylogix<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for opening WMDC On-Hands from the main screen         
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h)  
     * 
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 142, description = "Access check for opening WMDC On-Hands from the main screen ")
    public void tc_142_Main_Screen_Tools_Order_and_Distribution_WM_DC_On_Hand() {
        System.out.println(">>>tc_142_Main_Screen_Tools_Order_and_Distribution_WM_DC_On_Hand-Hand<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Order and Distribution -> WM DC On-Hands |
        // Connexus should open the WMDC On-Hands webpage in Chrome
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_142_Main_Screen_Tools_Order_and_Distribution_WM_DC_On_Hand-Hand<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for opening the wire/one.walmart.com from the main screen         
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h)   
     * 
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 143, description = "Access check for opening the wire/one.walmart.com from the main screen ")
    public void tc_143_Main_Screen_Tools_Desktop_Wire() {
        System.out.println(">>>tc_143_Main_Screen_Tools_Desktop_Wire<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Desktop -> Wire | Connexu should open the
        // Wire/one.walmart.com webpage in Chrome
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_143_Main_Screen_Tools_Desktop_Wire<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for opening the Internet explorer browser          
     *              
     * Pre-Conditions:None      
     *              
     * Author: Ashok(Vn50h3h)
     * 
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 144, description = "Access check for opening the Internet explorer browser ")
    public void tc_144_Main_Screen_Tools_Desktop_IE() {
        System.out.println(">>>tc_144_Main_Screen_Tools_Desktop_IE<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Desktop -> Wire | Connexu should open the
        // Wire/one.walmart.com webpage in Chrome
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_144_Main_Screen_Tools_Desktop_IE<<<");
    }
}
