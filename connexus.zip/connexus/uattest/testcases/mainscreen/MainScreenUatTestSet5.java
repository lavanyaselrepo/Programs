package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.LoginAs;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainScreenUatTestSet5 {
    MainScreenUatTestScripts mainScreenUatTestScripts;

    @BeforeClass
    public void beforeTestMethods() {
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button Check for TECH access to 4-Point
     *
     * Pre-Conditions: TECH Login
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 49, description = "Button Check for TECH access to 4-Point")
    public void tc_49_Main_screen_4_Point_access_from_left_bar_as_tech() {
        System.out.println(">>>tc_49_Main_screen_4_Point_access_from_left_bar<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on 4 - Point | 4-Point button should be grayed out and
        // no work from this queue should feed
        mainScreenUatTestScripts.click4PointFromLeftBarAsTech();

        System.out.println("<<<tc_49_Main_screen_4_Point_access_from_left_bar>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shortcut check for TECH access to 4-Point
     *
     * Pre-Conditions: TECH Login
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 50, description = "Shortcut check for TECH access to 4-Point")
    public void tc_50_Main_screen_4_Point_access_from_keyboard_shortcut_as_tech() {
        System.out.println(">>>tc_50_Main_screen_4_Point_access_from_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + 4 | 4-Point button should be grayed out and no
        // work from this queue should feed
        mainScreenUatTestScripts.pressKeyboardShortCutToOpen4PointScreenAsTech();

        System.out.println("<<<tc_50_Main_screen_4_Point_access_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Quick Icon check for TECH access to 4-Point
     *
     * Pre-Conditions: TECH Login
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 51, description = "Quick Icon check for TECH access to 4-Point")
    public void tc_51_Main_screen_4_point_access_from_Icon_as_tech() {
        System.out.println(">>>tc_51_Main_screen_4_point_access_from_Icon<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on the 4P icon | 4-Point button should be grayed out and
        // no work from this queue should feed
        mainScreenUatTestScripts.clickQuickIconCheckFor4PointAsTech();

        System.out.println("<<<tc_51_Main_screen_4_point_access_from_Icon>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu check for TECH access to 4-Point
     *
     * Pre-Conditions: TECH Login
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 52, description = "Menu check for TECH access to 4-Point")
    public void tc_52_Main_screen_4_Point_access_from_top_menu_as_tech() {
        System.out.println(">>>tc_52_Main_screen_4_Point_access_from_top_menu<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 click on the Work Queue menu and select 4-point | 4-Point
        // button should be grayed out and no work from this queue should feed
        mainScreenUatTestScripts.menuNavigationToOpen4PointScreenAsTech();

        System.out.println("<<<tc_52_Main_screen_4_Point_access_from_top_menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button Check for TECH access to Visual Verify
     *
     * Pre-Conditions: TECH Login
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 53, description = "Button Check for TECH access to Visual Verify")
    public void tc_53_Main_screen_Visual_Verify_access_from_left_bar_as_tech() {
        System.out.println(">>>tc_53_Main_screen_Visual_Verify_access_from_left_bar<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on Visual Verify | Visual Verify should be grayed out
        // and no work from this queue should feed
        mainScreenUatTestScripts.clickVisualVerifyFromLeftBarAsTech();

        System.out.println("<<<tc_53_Main_screen_Visual_Verify_access_from_left_bar>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shortcut check for TECH access to Visual Verify
     *
     * Pre-Conditions: TECH Login
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 54, description = "Shortcut check for TECH access to Visual Verify")
    public void tc_54_Main_screen_Visual_Verify_access_from_keyboard_shortcut_as_tech() {
        System.out.println(">>>tc_54_Main_screen_Visual_Verify_access_from_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + Y | Visual Verify should be grayed out and no
        // work from this queue should feed
        mainScreenUatTestScripts.pressKeyboardShortCutToVisualVerifyScreenAsTech();

        System.out.println("<<<tc_54_Main_screen_Visual_Verify_access_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Quick Icon check for TECH access to Visual Verify
     *
     * Pre-Conditions: TECH Login
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 55, description = "Quick Icon check for TECH access to Visual Verify")
    public void tc_55_Main_Screen_Visual_Verify_access_from_Icon_as_tech() {
        System.out.println(">>>tc_55_Main_Screen_Visual_Verify_access_from_Icon<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on the VV icon | Visual Verify should be grayed out and
        // no work from this queue should feed
        mainScreenUatTestScripts.clickQuickIconCheckForVisualVerifyAsTech();

        System.out.println("<<<tc_55_Main_Screen_Visual_Verify_access_from_Icon>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu check for TECH access to Visual Verify
     *
     * Pre-Conditions: TECH Login
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 56, description = "Menu check for TECH access to Visual Verify")
    public void tc_56_Main_screen_Visual_Verify_access_from_top_menu_as_tech() {
        System.out.println(">>>tc_56_Main_screen_Visual_Verify_access_from_top_menu<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 click on the Work Queue menu and select Visual Verify | Visual
        // Verify should be grayed out and no work from this queue should feed
        mainScreenUatTestScripts.menuNavigationToOpenVisualVerifyScreenAsTech();

        System.out.println("<<<tc_56_Main_screen_Visual_Verify_access_from_top_menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button check for TECH access to Counseling
     *
     * Pre-Conditions: TECH Login
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 57, description = "Button check for TECH access to Counseling")
    public void tc_57_Main_Screen_Counseling_access_from_left_bar_as_tech() {
        System.out.println(">>>tc_57_Main_Screen_Counseling_access_from_left_bar<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on Counseling | Counseling button should be grayed out
        // and no work from this queue should feed
        mainScreenUatTestScripts.clickCounselingFromLeftBarAsTech();

        System.out.println("<<<tc_57_Main_Screen_Counseling_access_from_left_bar>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shortcut check for TECH access to Counseling
     *
     * Pre-Conditions: TECH Login
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 58, description = "Shortcut check for TECH access to Counseling")
    public void tc_58_Main_Screen_Counseling_access_from_keyboard_shortcut_as_tech() {
        System.out.println(">>>tc_58_Main_Screen_Counseling_access_from_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + G | Counseling button should be grayed out and no
        // work from this queue should feed
        mainScreenUatTestScripts.pressKeyboardShortCutToOpenCounselingScreenAsTech();

        System.out.println("<<<tc_58_Main_Screen_Counseling_access_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu check for TECH access to Counseling
     *
     * Pre-Conditions: TECH Login
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 59, description = "Menu check for TECH access to Counseling")
    public void tc_59_Main_Screen_Counseling_access_from_top_menu_as_tech() {
        System.out.println(">>>tc_59_Main_Screen_Counseling_access_from_top_menu<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on the Work Queue menu and select counseling |
        // Counseling
        // button should be grayed out and no work from this queue should feed
        mainScreenUatTestScripts.menuNavigationToOpenCounselingScreenAsTech();

        System.out.println("<<<tc_59_Main_Screen_Counseling_access_from_top_menu>>>");
    }

}
