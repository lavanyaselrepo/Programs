package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.AppShortcuts;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.SearchItem;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class MainScreenUatTestSet8 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Searchbar check for searching using Plan Search with Plan search preselected  
     * 
     * Pre-Conditions:Plan Search Preselected
     * 
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 84, description = "Searchbar check for searching using Plan Search with Plan search preselected  ", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet8")
    public void tc_84_Main_Screen_plan_search_by_top_bar_with_plan_search_preselected(Map<String, String> inputData) {
        System.out.println(">>>tc_84_Main_Screen_plan_search_by_top_bar_with_plan_search_preselected<<<");

        //Pre-Conditions:Plan Search Preselected
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PLAN, inputData);
        connexusStartPage.pressEscapeKey();


        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type in plan name/carrier into search bar | Search Bar should
        // accept user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PLAN, inputData);

        // Step 3 Press Enter | Plan search screen should appear with the data
        // entered in the search bar
        connexusStartPage.pressEnterKey();
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PLAN, inputData);

        System.out.println("<<<tc_84_Main_Screen_plan_search_by_top_bar_with_plan_search_preselected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Searchbar check for searching using plan search with  plan serach not selected  
     * 
     * Pre-Conditions:Plan Search not selected
     * 
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 85, description = "Searchbar check for searching using plan search with  plan serach not selected", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet8")
    public void tc_85_Main_Screen_plan_search_by_top_bar_with_plan_search_not_selected(Map<String, String> inputData) {
        System.out.println(">>>tc_85_Main_Screen_plan_search_by_top_bar_with_plan_search_not_selected<<<");

        //Pre-Conditions:Plan Search not selected
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PRESCRIBER, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type in plan name/carrier into search bar | Search Bar should
        // accept user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PLAN, inputData);

        // Step 3 Select Plan search from the menu next to the search bar | Plan
        // search screen should appear with the data entered in the search bar
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PLAN, inputData);
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PLAN, inputData);

        System.out.println("<<<tc_85_Main_Screen_plan_search_by_top_bar_with_plan_search_not_selected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Shortcut check for using plan search   
     * 
     * Pre-Conditions:None
     * 
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 86, description = "Shortcut check for using plan search", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet8")
    public void tc_86_Main_Screen_plan_search_by_keyboard_shortcut(Map<String, String> inputData) {
        System.out.println(">>>tc_86_Main_Screen_plan_search_by_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 CTRL + SHIFT +N | Plan search screen should appear
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PLAN, inputData);
        connexusStartPage.inputShortcutKeys(AppShortcuts.PLAN.getAppShortcuts());
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PLAN, inputData);

        System.out.println("<<<tc_86_Main_Screen_plan_search_by_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:   Searchbar check for Claim searches with cliam search preselected
     * 
     * Pre-Conditions:Claim Search preselected
     * 
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 87, description = "Searchbar check for Claim searches with cliam search preselected", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet8")
    public void tc_87_Main_Screen_claim_search_by_top_bar_with_claim_search_preselected(Map<String, String> inputData) {
        System.out.println(">>>tc_87_Main_Screen_claim_search_by_top_bar_with_claim_search_preselected<<<");

        // Pre-Conditions:Claim Search preselected
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.CLAIM, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type in patient name in search bar | Search Bar should accept
        // user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.CLAIM, inputData);

        // Step 3 Press enter | Claim Search screen should appear with data
        // entereted into the search bar
        connexusStartPage.pressEnterKey();
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.CLAIM, inputData);

        System.out.println("<<<tc_87_Main_Screen_claim_search_by_top_bar_with_claim_search_preselected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Searchbar check for claim searches with claim search not selected  
     * 
     * Pre-Conditions:Claim search not selected
     * 
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 88, description = "Searchbar check for claim searches with claim search not selected", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet8")
    public void tc_88_Main_Screen_claim_search_by_top_bar_with_claim_search_not_selected(Map<String, String> inputData) {
        System.out.println(">>>tc_88_Main_Screen_claim_search_by_top_bar_with_claim_search_not_selected<<<");

        //* Pre-Conditions:Claim search not selected
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PRESCRIBER, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type in patient name in search bar | Search Bar should accept
        // user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.CLAIM, inputData);

        // Step 3 Select Claim search from the menu next to the search bar |
        // Claim Search screen should appear with data entereted into the search
        // bar
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.CLAIM, inputData);
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.CLAIM, inputData);

        System.out.println("<<<tc_88_Main_Screen_claim_search_by_top_bar_with_claim_search_not_selected  >>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shortcut check for claim searches  
     * 
     * Pre-Conditions:None
     * 
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 89, description = "Shortcut check for claim searches", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet8")
    public void tc_89_Main_Screen_claim_search_by_keyboard_shortcut(Map<String, String> inputData) {
        System.out.println(">>>tc_89_Main_Screen_claim_search_by_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + Shift + L | Claim search screen should appear
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.CLAIM, inputData);
        connexusStartPage.inputShortcutKeys(AppShortcuts.CLAIM.getAppShortcuts());
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.CLAIM, inputData);

        System.out.println("<<<tc_89_Main_Screen_claim_search_by_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Searchbar check for Patient eligibility searches with Patient eligibility preselected  
     * 
     * Pre-Conditions:Patient Eligibiility preselcted
     * 
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 90, description = "Searchbar check for Patient eligibility searches with Patient eligibility preselected", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet8")
    public void tc_90_Main_Screen_patient_eligibility_search_top_bar_patient_eligibility_search_preselected(Map<String, String> inputData) {
        System.out.println(">>>tc_90_Main_Screen_patient_eligibility_search_by_top_bar_with_patient_eligibility_search_preselected<<<");

        // Pre-Conditions:Patient Eligibiility preselcted
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PATIENT_ELIGIBILITY, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type in patient name in search bar | Search Bar should accept
        // user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PATIENT_ELIGIBILITY, inputData);

        // Step 3 Press enter | Patient eligibility seach should appear with
        // data entered into the search bar
        connexusStartPage.pressEnterKey();
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PATIENT_ELIGIBILITY, inputData);

        System.out.println("<<<tc_90_Main_Screen_patient_eligibility_search_by_top_bar_with_patient_eligibility_search_preselected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:  Search bar check for Patient eligibility searchs with patient eligibility not selected 
     * 
     * Pre-Conditions:Patient Eligibiility not selcted
     * 
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 91, description = "Search bar check for Patient eligibility searchs with patient eligibility not selected", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet8")
    public void tc_91_Main_Screen_patient_eligibility_search_top_bar_patient_eligibility_not_selected(Map<String, String> inputData) {
        System.out.println(">>>tc_91_Main_Screen_patient_eligibility_search_by_top_bar_with_patient_eligibility_search_not_selected<<<");

        //Pre-Conditions:Patient Eligibiility not selcted
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PATIENT, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type in patient name in search bar | Search Bar should accept
        // user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PATIENT_ELIGIBILITY, inputData);

        // Step 3 Select Patient eligibility search from the menu next to the
        // search bar | Patient eligibility seach should appear with data
        // entered into the search bar
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PATIENT_ELIGIBILITY, inputData);
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PATIENT_ELIGIBILITY, inputData);

        System.out.println("<<<tc_91_Main_Screen_patient_eligibility_search_by_top_bar_with_patient_eligibility_search_not_selected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shorcut check for Patienti eligibility searches  
     * 
     * Pre-Conditions:None
     * 
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 92, description = "Shorcut check for Patienti eligibility searches", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet8")
    public void tc_92_Main_Screen_patient_eligibility_search_by_keyboard_shortcut(Map<String, String> inputData) {
        System.out.println(">>>tc_92_Main_Screen_patient_eligibility_search_by_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + Shift + E | Patient eligibility seach should
        // appear
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PATIENT_ELIGIBILITY, inputData);
        connexusStartPage.inputShortcutKeys(AppShortcuts.PATIENT_ELIGIBILITY.getAppShortcuts());
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PATIENT_ELIGIBILITY, inputData);

        System.out.println("<<<tc_92_Main_Screen_patient_eligibility_search_by_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Searchbar check for IMZ Event searches with IMZ event preselected   
     * 
     * Pre-Conditions:IMZ Event Search Preselected
     * 
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 93, description = "Searchbar check for IMZ Event searches with IMZ event preselected", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet8")
    public void tc_93_Main_Screen_IMZ_event_search_by_top_bar_with_IMZ_search_preselected(Map<String, String> inputData) {
        System.out.println(">>>tc_93_Main_Screen_IMZ_event_search_by_top_bar_with_IMZ_search_preselected<<<");

        //Pre-Conditions:IMZ Event Search Preselected
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.IMZ_EVENT, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type IMZ Event name in search bar | Search Bar should accept
        // user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.IMZ_EVENT, inputData);

        // Step 3 Press Enter | IMZ Event Search should appear with data entered
        // into the search bar
        connexusStartPage.pressEnterKey();
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.IMZ_EVENT, inputData);

        System.out.println("<<<tc_93_Main_Screen_IMZ_event_search_by_top_bar_with_IMZ_search_preselected >>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Searchbar check for IMZ Event searches with IMZ event not selected   
     * 
     * Pre-Conditions:IMZ Event Search not selected
     * 
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 94, description = "Searchbar check for IMZ Event searches with IMZ event not selected", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet8")
    public void tc_94_Main_Screen_IMZ_event_search_by_top_bar_with_IMZ_search_not_selected(Map<String, String> inputData) {
        System.out.println(">>>tc_94_Main_Screen_IMZ_event_search_by_top_bar_with_IMZ_search_not_selected<<<");

        //Pre-Conditions:IMZ Event Search not selected
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PRESCRIBER, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type IMZ Event name in search bar | Search Bar should accept
        // user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.IMZ_EVENT, inputData);

        // Step 3 Select IMZ Event from menu next to the search bar | IMZ Event
        // Search should appear with data entered into the search bar
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.IMZ_EVENT, inputData);
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.IMZ_EVENT, inputData);

        System.out.println("<<<tc_94_Main_Screen_IMZ_event_search_by_top_bar_with_IMZ_search_not_selected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Shortcut check for  IMZ event searches   
     * 
     * Pre-Conditions:None
     * 
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 95, description = "Shortcut check for  IMZ event searches", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet8")
    public void tc_95_Main_Screen_IMZ_event_search_by_keyboard_shortcut(Map<String, String> inputData) {
        System.out.println(">>>tc_95_Main_Screen_IMZ_event_search_by_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + Shift + I | IMZ Event Search should appear
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.IMZ_EVENT, inputData);
        connexusStartPage.inputShortcutKeys(AppShortcuts.IMZ_EVENT.getAppShortcuts());
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.IMZ_EVENT, inputData);

        System.out.println("<<<tc_95_Main_Screen_IMZ_event_search_by_keyboard_shortcut>>>");
    }
}
