package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.AppMenu;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.SearchItem;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainScreenUatTestSet20 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;
    MenuBar menuBar;
    AutomationManager automationManager;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        automationManager = AutomationManager.getInstance();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }


    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Paper Bill Exception Report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 267)
    public void tc_267_Main_Screen_Reports_Paper_Bill_Exception_Report() {
        System.out.println(">>>tc_267_Main_Screen_Reports_Paper_Bill_Exception_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Paper Bill Exception Report | the Paper Bill
        // Exception Report pop up should appear
        menuBar.navigateToMenu(AppMenu.PAPER_BILL_EXCEPTON_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.PAPER_BILL_EXCEPTON_REPORT);

        System.out.println("<<<tc_267_Main_Screen_Reports_Paper_Bill_Exception_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for External Order Reports"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 268)
    public void tc_268_Main_Screen_Reports_Remote_Order_Review_ROR_External_Report() {
        System.out.println(">>>tc_268_Main_Screen_Reports_Remote_Order_Review_ROR_External_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Remote Order Review -> ROR External Report |
        // the ROR External Report date selection pop up should appear
        menuBar.navigateToMenu(AppMenu.ROR_EXTERNAL_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.ROR_EXTERNAL_REPORT);

        System.out.println("<<<tc_268_Main_Screen_Reports_Remote_Order_Review_ROR_External_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Internal Order Reports"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 269)
    public void tc_269_Main_Screen_Reports_Remote_Order_Review_ROR_Internal_Report() {
        System.out.println(">>>tc_269_Main_Screen_Reports_Remote_Order_Review_ROR_Internal_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Remote Order Review -> Internal Order Report
        // | the ROR Internal Report date selection pop up should appear
        menuBar.navigateToMenu(AppMenu.INTERNAL_ORDER_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.INTERNAL_ORDER_REPORT);

        System.out.println("<<<tc_269_Main_Screen_Reports_Remote_Order_Review_ROR_Internal_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Failed login attempt report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 270)
    public void tc_270_Main_Screen_Reports_Audit_Reports_Failed_Login_Attempts() {
        System.out.println(">>>tc_270_Main_Screen_Reports_Audit_Reports_Failed_Login_Attempts<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Audit Reports -> Controlled Substance Erx |
        // the Failed Login Attempt Report date selection pop up should appear
        menuBar.navigateToMenu(AppMenu.CONTROLLED_SUBSTANCE_ERX);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.CONTROLLED_SUBSTANCE_ERX);

        System.out.println("<<<tc_270_Main_Screen_Reports_Audit_Reports_Failed_Login_Attempts>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for the Temp User Log"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 271)
    public void tc_271_Main_Screen_Reports_Audit_Reports_Temp_User_Log() {
        System.out.println(">>>tc_271_Main_Screen_Reports_Audit_Reports_Temp_User_Log<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Audit Reports -> Temp User Log | the Temp
        // User Log date selection pop up should appear
        menuBar.navigateToMenu(AppMenu.TEMP_USER_LOG);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.TEMP_USER_LOG);

        System.out.println("<<<tc_271_Main_Screen_Reports_Audit_Reports_Temp_User_Log>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for the Controlled Substance RX Details report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 272)
    public void tc_272_Main_Screen_Reports_Audit_Reports_Controlled_Substance_RX_Details() {
        System.out.println(">>>tc_272_Main_Screen_Reports_Audit_Reports_Controlled_Substance_RX_Details<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Audit Reports -> Controlled Substance RX
        // Details | the Controlled Substance RX Details report date selection
        // pop up should appear
        menuBar.navigateToMenu(AppMenu.CONTROLLED_SEBSTANCE_RX_DETAILS);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.CONTROLLED_SEBSTANCE_RX_DETAILS);

        System.out.println("<<<tc_272_Main_Screen_Reports_Audit_Reports_Controlled_Substance_RX_Details>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for the RX Modification Log"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 273)
    public void tc_273_Main_Screen_Reports_Audit_Reports_RX_Modification_Log() {
        System.out.println(">>>tc_273_Main_Screen_Reports_Audit_Reports_RX_Modification_Log<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Audit Reports -> RX Modification Log | the
        // RX Modification Log date selection pop up should appear
        menuBar.navigateToMenu(AppMenu.RX_MODIFICATION_LOG);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.RX_MODIFICATION_LOG);

        System.out.println("<<<tc_273_Main_Screen_Reports_Audit_Reports_RX_Modification_Log>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for the Audit Interference Log"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 274)
    public void tc_274_Main_Screen_Reports_Audit_Reports_Audit_Interference_Log() {
        System.out.println(">>>tc_274_Main_Screen_Reports_Audit_Reports_Audit_Interference_Log<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Audit Reports -> Audit Interference Log |
        // the Audit Interference Logt date selection pop up should appear
        menuBar.navigateToMenu(AppMenu.ADUIT_INTERFERENCE_LOG);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.ADUIT_INTERFERENCE_LOG);

        System.out.println("<<<tc_274_Main_Screen_Reports_Audit_Reports_Audit_Interference_Log>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for the Controlled Substance Erx Landing Time Report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 275)
    public void tc_275_Main_Screen_Reports_Audit_Reports_Controlled_Substance_Erx_Landing_Time_Report() {
        System.out.println(">>>tc_275_Main_Screen_Reports_Audit_Reports_Controlled_Substance_Erx_Landing_Time_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Audit Reports -> Controlled Substance Erx
        // Landing Time Report | the Controlled Substance Erx Landing Time
        // Report date selection pop up should appear
        menuBar.navigateToMenu(AppMenu.CONTROLLED_SUBSTANCE_ERX_LANDING_TIME_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.CONTROLLED_SUBSTANCE_ERX_LANDING_TIME_REPORT);

        System.out.println("<<<tc_275_Main_Screen_Reports_Audit_Reports_Controlled_Substance_Erx_Landing_Time_Report>>>");
    }


}
