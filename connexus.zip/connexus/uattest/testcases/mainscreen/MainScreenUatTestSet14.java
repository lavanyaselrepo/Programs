package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.AppMenu;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.SearchItem;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainScreenUatTestSet14 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;
    MenuBar menuBar;
    AutomationManager automationManager;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        automationManager = AutomationManager.getInstance();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access Check for Drug movement by NDC/Names report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 177)
    public void tc_177_Main_Screen_Inventroy_Reports_Drug_Movement_By_NDC_Names() {
        System.out.println(">>>tc_177_Main_Screen_Inventroy_Reports_Drug_Movement_By_NDC_Names<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Drug Movement -> By
        // NDC/Names | Drug Movement by NDC/Names report screen should appear"
        menuBar.navigateToMenu(AppMenu.DRUG_MOVEMENT_BY_NDC_NAME);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.DRUG_MOVEMENT_BY_NDC_NAME);

        System.out.println("<<<tc_177_Main_Screen_Inventroy_Reports_Drug_Movement_By_NDC_Names>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access Check for Drug movement by GPI"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 178)
    public void tc_178_Main_Screen_Inventroy_Reports_Drug_Movement_By_GPI() {
        System.out.println(">>>tc_178_Main_Screen_Inventroy_Reports_Drug_Movement_By_GPI<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Drug Movement -> By GPI
        // | Drug Movement by GPI report screen should appear"
        menuBar.navigateToMenu(AppMenu.DRUG_MOVEMENT_BY_GPI);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.DRUG_MOVEMENT_BY_GPI);

        System.out.println("<<<tc_178_Main_Screen_Inventroy_Reports_Drug_Movement_By_GPI>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access Check for Competitive Drug movement report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 179)
    public void tc_179_Main_Screen_Inventroy_Reports_Drug_Movement_Comp_Drug_Movement() {
        System.out.println(">>>tc_179_Main_Screen_Inventroy_Reports_Drug_Movement_Comp_Drug_Movement<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Drug Movement -> Comp
        // Drug Movement | Competitive Drug Movement pop up for date selection
        // should appear"
        // | Drug Movement by GPI report screen should appear"
        menuBar.navigateToMenu(AppMenu.DRUG_MOVEMENT_COMP_DRUG);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.DRUG_MOVEMENT_COMP_DRUG);

        System.out.println("<<<tc_179_Main_Screen_Inventroy_Reports_Drug_Movement_Comp_Drug_Movement>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access Check for Top/Bottom drug report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 180)
    public void tc_180_Main_Screen_Inventroy_Reports_Drug_Movement_Top_Bottom_Drug() {
        System.out.println(">>>tc_180_Main_Screen_Inventroy_Reports_Drug_Movement_Top/Bottom_Drug<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Drug Movement ->
        // Top/Bottom Drug report | Top/Bottom Drug report screen should
        // appear"
        menuBar.navigateToMenu(AppMenu.DRUG_MOVEMENT_TOP_BOTTOM_DRUG);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.DRUG_MOVEMENT_TOP_BOTTOM_DRUG);

        System.out.println("<<<tc_180_Main_Screen_Inventroy_Reports_Drug_Movement_Top/Bottom_Drug>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Replenishment available report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 181)
    public void tc_181_Main_Screen_Inventory_Reports_Replenishment_Reports_Replenishment_Available_Report() {
        System.out.println(">>>tc_181_Main_Screen_Inventory_Reports_Replenishment_Reports_Replenishment_Available_Report<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Replenishment Reports
        // -> Replenishment Available report | Replenishment Available Report
        // pop up for date selection should appear"
        menuBar.navigateToMenu(AppMenu.REPLENISHMENT_AVAILABLE_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.REPLENISHMENT_AVAILABLE_REPORT);

        System.out.println("<<<tc_181_Main_Screen_Inventory_Reports_Replenishment_Reports_Replenishment_Available_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Replenishment unavailable report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 182)
    public void tc_182_Main_Screen_Inventory_Reports_Replenishment_Reports_Replenishment_Unavailable_Report() {
        System.out.println(">>>tc_182_Main_Screen_Inventory_Reports_Replenishment_Reports_Replenishment_Unavailable_Report<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Replenishment Reports
        // -> Replenishment unavailable report | Replenishment unavailable
        // Report pop up for date selection should appear"
        menuBar.navigateToMenu(AppMenu.REPLENISHMENT_UNAVAILABLE_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.REPLENISHMENT_UNAVAILABLE_REPORT);

        System.out.println("<<<tc_182_Main_Screen_Inventory_Reports_Replenishment_Reports_Replenishment_Unavailable_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Amber Vial inventory report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 183)
    public void tc_183_Main_Screen_Inventory_Reports_Return_to_Stock_Reports_Amber_Vial_Inventory() {
        System.out.println(">>>tc_183_Main_Screen_Inventory_Reports_Return_to_Stock_Reports_Amber_Vial_Inventory<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Return to Stock Reports
        // -> Ambier Vial Inventory | Amber Vial inventory screen should
        // appear."
        menuBar.navigateToMenu(AppMenu.AMBER_VIAL_INVENTORY);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.AMBER_VIAL_INVENTORY);

        System.out.println("<<<tc_183_Main_Screen_Inventory_Reports_Return_to_Stock_Reports_Amber_Vial_Inventory>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Active Amber Vial inventory report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 184)
    public void tc_184_Main_Screen_Inventory_Reports_Return_to_Stock_Reports_Amber_Vial_Active_Inventory() {
        System.out.println(">>>tc_184_Main_Screen_Inventory_Reports_Return_to_Stock_Reports_Amber_Vial_Active_Inventory<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Return to Stock Reports
        // -> Ambier Vial Active Inventory | Amber Vial Active Inventory screen
        // should appear."
        menuBar.navigateToMenu(AppMenu.AMBER_VIAL_ACTIVE_INVENTORY);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.AMBER_VIAL_ACTIVE_INVENTORY);

        System.out.println("<<<tc_184_Main_Screen_Inventory_Reports_Return_to_Stock_Reports_Amber_Vial_Active_Inventory>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Expired Amber Vial inventory report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 185)
    public void tc_185_Main_Screen_Inventory_Reports_Return_to_Stock_Reports_Amber_Vial_Expired_Inventory() {
        System.out.println(">>>tc_185_Main_Screen_Inventory_Reports_Return_to_Stock_Reports_Amber_Vial_Expired_Inventory<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Return to Stock Reports
        // -> Ambier Vial Expired Inventory | Amber Vial Expired Inventory date
        // selection pop up should appear."
        menuBar.navigateToMenu(AppMenu.AMBER_VIAL_EXPIRED_INVENTORY);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.AMBER_VIAL_EXPIRED_INVENTORY);

        System.out.println("<<<tc_185_Main_Screen_Inventory_Reports_Return_to_Stock_Reports_Amber_Vial_Expired_Inventory>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for the Deactivated Amber Vial report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 186)
    public void tc_186_Main_Screen_Inventory_Reports_Return_to_Stock_Reports_Amber_Vial_Deactivated_Vials() {
        System.out.println(">>>tc_186_Main_Screen_Inventory_Reports_Return_to_Stock_Reports_Amber_Vial_Deactivated_Vials<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Return to Stock Reports
        // -> Ambier Vial Deactivated Vials | Amber Vial Deactivated Vials date
        // selection pop up should appear."
        menuBar.navigateToMenu(AppMenu.AMBER_VIAL_DEACTIVATED_INVENTORY);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.AMBER_VIAL_DEACTIVATED_INVENTORY);

        System.out.println("<<<tc_186_Main_Screen_Inventory_Reports_Return_to_Stock_Reports_Amber_Vial_Deactivated_Vials>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for the report showing drugs not used in the past 100 days"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 187)
    public void tc_187_Main_Screen_Inventory_Reports_100_day_drugs_not_used() {
        System.out.println(">>>tc_187_Main_Screen_Inventory_Reports_100_day_drugs_not_used<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> 100 Day Drugs not used
        // | The 100 day drugs not used report screen should appear"
//        menuBar.navigateToMenu(AppMenu.HUNDRED_DAY_DRUG_NOT_USED);
//        automationManager.performSleep(20);
//        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.HUNDRED_DAY_DRUG_NOT_USED);
        mainScreenUatTestScripts.nonAutomateScenario();//Application is taking more time to load the report screen
        System.out.println("<<<tc_187_Main_Screen_Inventory_Reports_100_day_drugs_not_used>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for the Competitive drug pricing report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 188)
    public void tc_188_Main_Screen_Inventory_Reports_Comp_drug_Pricing() {
        System.out.println(">>>tc_188_Main_Screen_Inventory_Reports_Comp_drug_Pricing<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Comp Drug Pricing | the
        // Competitive Drug Pricing report screen should appear"
        menuBar.navigateToMenu(AppMenu.COMP_DRUG_PRICING);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.COMP_DRUG_PRICING);

        System.out.println("<<<tc_188_Main_Screen_Inventory_Reports_Comp_drug_Pricing>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for current drug on-hand report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 189)
    public void tc_189_Main_Screen_Inventory_Reports_Current_Onhand_Inventory() {
        System.out.println(">>>tc_189_Main_Screen_Inventory_Reports_Current_Onhand_Inventory<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Current Onhand
        // inventory | Current onhand inventory report screen should appear"
        menuBar.navigateToMenu(AppMenu.CURRENT_ONHAND_INVENTORY);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.CURRENT_ONHAND_INVENTORY);

        System.out.println("<<<tc_189_Main_Screen_Inventory_Reports_Current_Onhand_Inventory>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for list of drugs priced over $1k"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 190)
    public void tc_190_Main_Screen_Inventory_Reports_Drugs_Greater_than_$1000() {
        System.out.println(">>>tc_190_Main_Screen_Inventory_Reports_Drugs_Greater_than_$1000<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Drugs Greater than
        // $1000 | Report showing on hand drugs worrth more thatn $1000 should
        // appear"
        menuBar.navigateToMenu(AppMenu.DRUGS_GREATERTHAN_$1000);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.DRUGS_GREATERTHAN_$1000);

        System.out.println("<<<tc_190_Main_Screen_Inventory_Reports_Drugs_Greater_than_$1000>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for the current/recent drug recall report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 191)
    public void tc_191_Main_Screen_Inventory_Reports_Drug_Recall() {
        System.out.println(">>>tc_191_Main_Screen_Inventory_Reports_Drug_Recall<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports ->Drug Rrecall | Drug
        // Recall report shoyuld appear"
        menuBar.navigateToMenu(AppMenu.DRUG_RECALL);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.DRUG_RECALL);

        System.out.println("<<<tc_191_Main_Screen_Inventory_Reports_Drug_Recall>>>");
    }


}
