package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.AppMenu;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.SearchItem;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainScreenUatTestSet13 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;
    MenuBar menuBar;
    AutomationManager automationManager;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        automationManager = AutomationManager.getInstance();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for urgent messages from the main screen"
     *
     * Pre-Conditions:"Urgent message pending"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 162)
    public void tc_162_Main_Screen_Tools_Urgent_Messages() {
        System.out.println(">>>tc_162_Main_Screen_Tools_Urgent_Messages<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Urgent Messages | Pharmacy Messages screen
        // should appear with urgent messages displayed.
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_162_Main_Screen_Tools_Urgent_Messages<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for urgent messages from the left bar"
     *
     * Pre-Conditions:"Urgent message pending"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 163)
    public void tc_163_Main_Screen_Left_Bar_Urgent_messages() {
        System.out.println(">>>tc_163_Main_Screen_Left_Bar_Urgent_messages<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on urgent messages tile in the left bar | Pharmacy
        // Messages screen should appear with urgent messages displayed.
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_163_Main_Screen_Left_Bar_Urgent_messages<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for cycle counts from the main screen"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 164)
    public void tc_164_Main_Screen_Cycle_counts_Access() {
        System.out.println(">>>tc_164_Main_Screen_Cycle_counts_Access<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Double click on the numbers in the lower right hand corner of
        // the screen | Cycle count screen should appear
        connexusStartPage.doubleClickOnCycleCountStatusBar();
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.CYCLE_COUNT);

        System.out.println("<<<tc_164_Main_Screen_Cycle_counts_Access<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for cycle counts from reports menu"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 165)
    public void tc_165_Main_Screen_cycle_count_access_from_reports_menu() {
        System.out.println(">>>tc_165_Main_Screen_cycle_count_access_from_reports_menu<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Cycle count report |
        // Cycle counts screen should appear
        menuBar.navigateToMenu(AppMenu.CYCLE_COUNT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.CYCLE_COUNT);

        System.out.println("<<<tc_165_Main_Screen_cycle_count_access_from_reports_menu<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for print Icon from main screen"
     *
     * Pre-Conditions:"Main screen must be empty"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 166)
    public void tc_166_Main_Screen_Print_Icon() {
        System.out.println(">>>tc_166_Main_Screen_Print_Icon<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on the print Icon | Print Icon should be grayed out and
        // nothing should happen
        connexusStartPage.clickPrintIcon();
        mainScreenUatTestScripts.validateNoScreenDisplayed(SearchItem.PRINT);

        System.out.println("<<<tc_166_Main_Screen_Print_Icon<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Contents in the help menu from the main screen"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     *
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 167)
    public void tc_167_Main_screen_Help_Contents() {
        System.out.println(">>>tc_167_Main_screen_Help_Contents<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Help -> Contents | Connexus should open the wire
        // webpage in Chrome
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_167_Main_screen_Help_Contents<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Pharmacy messages in Help Menu from the main screen"
     *
     * Pre-Conditions:"No urgent Messages"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 168)
    public void tc_168_Main_Screen_Help_Pharmacy_Messages() {
        System.out.println(">>>tc_168_Main_Screen_Help_Pharmacy_Messages<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Help -> Pharmacy Messages | A pop up stating
        // "No Pharmacy Action Messages Found" should appear
        menuBar.navigateToMenu(AppMenu.PHARMACY_MESSAGES);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.PHARMACY_MESSAGES);

        System.out.println("<<<tc_168_Main_Screen_Help_Pharmacy_Messages<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Pharmacy messages in Help Menu from the main screen"
     *
     * Pre-Conditions:"Urgent Message Pending"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 169)
    public void tc_169_Main_Screen_Help_Pharmacy_Messages() {
        System.out.println(">>>tc_169_Main_Screen_Help_Pharmacy_Messages<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Help -> Pharmacy Messages | Pharmacy Messages screen
        // should appear with urgent messages displayed.
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_169_Main_Screen_Help_Pharmacy_Messages<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check forAbout in the help menu from the main screen"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 170)
    public void tc_170_Main_Screen_Help_About() {
        System.out.println(">>>tc_170_Main_Screen_Help_About<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Help -> About | The about screen should appear
        menuBar.navigateToMenu(AppMenu.ABOUT);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.ABOUT);

        System.out.println("<<<tc_170_Main_Screen_Help_About<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for C2 logbook from reports menu"
     *
     * Pre-Conditions:"none"
     *
     * Author: Ashok(Vn50h3h)
     *
     * ***Step 2 has different navigation path*** Reports -> Inventory Reports -> Controlled substances Inventory Report -> CII(Radio Button)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 171)
    public void tc_171_Main_Screen_Reports_Inventory_Reports_C2_Reports_CII_Digital_Logbook() {
        System.out.println(">>>tc_171_Main_Screen_Reports_Inventory_Reports_C2_Reports_CII_Digital_Logbook<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> C2 Reports -> CII
        // Digital Logbook | CII Digital logbook screen should appear
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_171_Main_Screen_Reports_Inventory_Reports_C2_Reports_CII_Digital_Logbook<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for C2 drug summary from reports menu"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 172)
    public void tc_172_Main_Screen_Reports_Inventory_Reports_C2_Reports_CII_Drug_Summary() {
        System.out.println(">>>tc_172_Main_Screen_Reports_Inventory_Reports_C2_Reports_CII_Drug_Summary<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> C2 Reports -> CII Drug
        // Summary | CII Drug Summary report screen should appear
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_172_Main_Screen_Reports_Inventory_Reports_C2_Reports_CII_Drug_Summary<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for C2 Monthly Audit from reports menu"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 173)
    public void tc_173_Main_Screen_Reports_Inventory_Reports_C2_Reports_CII_Monthly_Audit() {
        System.out.println(">>>tc_173_Main_Screen_Reports_Inventory_Reports_C2_Reports_CII_Monthly_Audit<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> C2 Reports -> CII
        // Monthly Audit | CII Monthly Audit report should appear
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_173_Main_Screen_Reports_Inventory_Reports_C2_Reports_CII_Monthly_Audit<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for C2 returns report from reports menu"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 174)
    public void tc_174_Main_Screen_Reports_Inventory_Reports_C2_Reports_Return_to_Inmar_MCK() {
        System.out.println(">>>tc_174_Main_Screen_Reports_Inventory_Reports_C2_Reports_Return_to_Inmar_MCK<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> C2 Reports -> Return
        // Inmar/MCK | Return to Inmar/MCK form should appear
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_174_Main_Screen_Reports_Inventory_Reports_C2_Reports_Return_to_Inmar_MCK<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for C2 adjustments report from reports menu"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 175)
    public void tc_175_Main_Screen_Reports_Inventory_Reports_C2_Reports_CII_Adjustments() {
        System.out.println(">>>tc_175_Main_Screen_Reports_Inventory_Reports_C2_Reports_CII_Adjustments<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> C2 Reports -> CII
        // Adjustment | C2 Adjustment report should appear
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_175_Main_Screen_Reports_Inventory_Reports_C2_Reports_CII_Adjustments<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access Check for Drug movement by schedule report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 176)
    public void tc_176_Main_screen_Inventroy_Reports_Drug_Movement_By_Drug_Schedule() {
        System.out.println(">>>tc_176_Main_screen_Inventroy_Reports_Drug_Movement_By_Drug_Schedule<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Drug Movement -> By
        // Drug Schedule | Drug Movement Schedule report screen should appear
        menuBar.navigateToMenu(AppMenu.DRUG_MOVEMENT_BY_DRUG_SCHEDULE);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.DRUG_MOVEMENT_BY_DRUG_SCHEDULE);

        System.out.println("<<<tc_176_Main_screen_Inventroy_Reports_Drug_Movement_By_Drug_Schedule<<<");
    }


}
