package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;

public class MainScreenUatTestSet12 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;
    MenuBar menuBar;
    AutomationManager automationManager;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        AutomationManager.getInstance().performSleep(10);
        connexusAppUtils.startAppiumServer();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        automationManager = AutomationManager.getInstance();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for opening the Facts & Comparisons drug reference from the main screen
     *              
     * Pre-Conditions:  None
     *              
     * Author: Ashok(Vn50h3h)  
     *               
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 145, description = "Access check for opening the Facts & Comparisons drug reference from the main screen")
    public void tc_145_Main_Screen_Tools_Desktop_Drug_Reference() {
        System.out.println(">>>tc_145_Main_Screen_Tools_Desktop_Drug_Reference<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Desktop -> Drug Reference | Connexus should
        // open the Facts & Comparisions webpage in Chrome
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_145_Main_Screen_Tools_Desktop_Drug_Reference<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for opening the Electronic Time clock from the main screen
     *              
     * Pre-Conditions:  None
     *              
     * Author: Ashok(Vn50h3h)                
     *               
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 146, description = "Access check for opening the Electronic Time clock from the main screen")
    public void tc_146_Main_Screen_Tools_Desktop_ETC() {
        System.out.println(">>>tc_146_Main_Screen_Tools_Desktop_ETC<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Desktop -> Drug Reference | Connexus should
        // open the Electronic Time Clock webpage in Chrome.
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_146_Main_Screen_Tools_Desktop_ETC<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for opening FixIt from the main screen
     *              
     * Pre-Conditions:  None
     *              
     * Author: Ashok(Vn50h3h)                
     *               
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 147, description = "Access check for opening FixIt from the main screen")
    public void tc_147_Main_Screen_Tools_Desktop_Ticket_Status() {
        System.out.println(">>>tc_147_Main_Screen_Tools_Desktop_Ticket_Status<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Desktop -> Ticket Status | Connexus should
        // open the FixIt webpage in Chrome
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_147_Main_Screen_Tools_Desktop_Ticket_Status<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for opening Outcomes MTM from the main screen
     *              
     * Pre-Conditions:  None
     *              
     * Author: Ashok(Vn50h3h)                
     *               
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 148, description = "Access check for opening Outcomes MTM from the main screen")
    public void tc_148_Main_Screen_Tools_Desktop_Outcomes_MTM() {
        System.out.println(">>>tc_148_Main_Screen_Tools_Desktop_Outcomes_MTM<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Desktop -> OutcomesMTM | Connexus should open
        // the OutcomesMTM webpage in Chrome
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_148_Main_Screen_Tools_Desktop_Outcomes_MTM<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for opening RxCompanion from the main screen
     *              
     * Pre-Conditions:  None
     *              
     * Author: Ashok(Vn50h3h)                
     *               
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 149, description = "Access check for opening RxCompanion from the main screen")
    public void tc_149_Main_Screen_Tools_Desktop_RxCompanion() {
        System.out.println(">>>tc_149_Main_Screen_Tools_Desktop_RxCompanion<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Desktop -> RxCompanion | Connexus should open
        // the RxCompanion webpage in Chrome
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_149_Main_Screen_Tools_Desktop_RxCompanion<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for opening the Scanner Check program from the main screen
     *              
     * Pre-Conditions:  None
     *              
     * Author: Ashok(Vn50h3h)                
     *               
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 150, description = "Access check for opening the Scanner Check program from the main screen")
    public void tc_150_Main_Screen_Tools_Desktop_Scanner_Check() {
        System.out.println(">>>tc_150_Main_Screen_Tools_Desktop_Scanner_Check<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Desktop -> Scanner Check | Connexus should
        // open the Scanner Check program
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_150_Main_Screen_Tools_Desktop_Scanner_Check<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for opening STCImmslink from the main page
     *              
     * Pre-Conditions:  None
     *              
     * Author: Ashok(Vn50h3h)                
     *               
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 151, description = "Access check for opening STCImmslink from the main page")
    public void tc_151_Main_Screen_Tools_Desktop_STC() {
        System.out.println(">>>tc_151_Main_Screen_Tools_Desktop_STC<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Desktop -> STC | Connexus should open the
        // STCImmslink webpage in Chrome
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_151_Main_Screen_Tools_Desktop_STC<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for viewing/scanning signature images into Connexus from the main page
     *              
     * Pre-Conditions:  None
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 152, description = "Access check for viewing/scanning signature images into Connexus from the main page")
    public void tc_152_Main_Screen_Tools_Signature_Image() {
        System.out.println(">>>tc_152_Main_Screen_Tools_Signature_Image<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Desktop -> Signature Image | Connexus should
        // open the Scan Signature image screen
        menuBar.navigateToMenu(AppMenu.SIGNATURE_IMAGE);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.SIGNATURE_IMAGE);

        System.out.println("<<<tc_152_Main_Screen_Tools_Signature_Image<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for POS Orders Screen from the main screen
     *              
     * Pre-Conditions:  None
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 153, description = "Access check for POS Orders Screen from the main screen")
    public void tc_153_Main_Screen_Tools_Replenishment_POS_Orders() {
        System.out.println(">>>tc_153_Main_Screen_Tools_Replenishment_POS_Orders<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Replenishment -> POS Orders | Connexus should
        // bring up the POS Orders screen
        menuBar.navigateToMenu(AppMenu.POS_ORDERS);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.POS_ORDERS);

        System.out.println("<<<tc_153_Main_Screen_Tools_Replenishment_POS_Orders<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access Check for Replenishment Review screen from the main screen
     *              
     * Pre-Conditions:  None
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 154, description = "Access Check for Replenishment Review screen from the main screen")
    public void tc_154_Main_Screen_Tools_Replenishment_Replenishment_Review() {
        System.out.println(">>>tc_154_Main_Screen_Tools_Replenishment_Replenishment_Review<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Replenishment -> Replenishment Review | The
        // replenishment review screen should appear
        menuBar.navigateToMenu(AppMenu.REPLENISHMENT_REVIEW);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.REPLENISHMENT_REVIEW);

        System.out.println("<<<tc_154_Main_Screen_Tools_Replenishment_Replenishment_Review<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for C2 Drug order apply from main screen
     *              
     * Pre-Conditions:  None
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 155, description = "Access check for C2 Drug order apply from main screen")
    public void tc_155_Main_Screen_Tools_Replenishment_C2_drug_order_apply() {
        System.out.println(">>>tc_155_Main_Screen_Tools_Replenishment_C2_drug_order_apply<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Replenishment -> C2 Drug Order Apply | The
        // unapplied C2 Orders screen should appear
        menuBar.navigateToMenu(AppMenu.C2_DRUG_ORDER_APPLY);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.C2_DRUG_ORDER_APPLY);

        System.out.println("<<<tc_155_Main_Screen_Tools_Replenishment_C2_drug_order_apply<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for printing the payroll worksheet from the main screen
     *              
     * Pre-Conditions:  None
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 156, description = "Access check for printing the payroll worksheet from the main screen")
    public void tc_156_Main_Screen_Tools_Print_Payroll_Worksheet() {
        System.out.println(">>>tc_156_Main_Screen_Tools_Print_Payroll_Worksheet<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Replenishment -> Print Payroll Worksheet |
        // Pop-up should appear stating the Payroll worksheet was successfully
        // sent to the printer
        menuBar.navigateToMenu(AppMenu.PRINT_PAYROLL_WORKSHEET);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.PRINT_PAYROLL_WORKSHEET);

        System.out.println("<<<tc_156_Main_Screen_Tools_Print_Payroll_Worksheet<<<");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:Access check for RPH to create a temp user from the main screen
     *              
     * Pre-Conditions:  RPH Login (not homeoffice)
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 157, description = "Access check for RPH to create a temp user from the main screen")
    public void tc_157_Main_Screen_Tools_Temp_User_Setup_rph() {
        System.out.println(">>>tc_157_Main_Screen_Tools_Temp_User_Setup_rph<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Temp User Setup | Temp user setup screen
        // should appear
        menuBar.navigateToMenu(AppMenu.TEMP_USER_SETUP);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.TEMP_USER_SETUP);

        System.out.println("<<<tc_157_Main_Screen_Tools_Temp_User_Setup_rph<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Validating Temp User Set up option should not be available for technician login by opening all menu options under Tools menu
     *
     * Pre-Conditions:  Tech Login (not homeoffice)
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 158, description = "Validating Temp User Set up option should not be available for technician login by opening all menu options under Tools menu")
    public void HWPHME2E_1245_Validate_Temp_User_Setup_Option_should_Not_Available_For_Technician() {
        Reporter.log("HWPHME2E_1245 Validating Temp User Set up option should not be available for technician login by opening all menu options under Tools menu");
        connexusAppUtils.getStoreId();
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Temp User Setup | Temp User setup should be
        // grayed out and not avilable to a technician.
        AutomationManager.getInstance().getConnexus().closeConnexus();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        mainScreenUatTestScripts.tempUserValidation();

        Reporter.log("HWPHME2E_1245 Validating Temp User Set up option should not be available for technician login by opening all menu options under Tools menu");


    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Access check for opening the calculator from the main screen.
     *
     * Pre-Conditions:  None
     *
     * Author: Ashok(Vn50h3h)
     *
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 159, description = "Access check for opening the calculator from the main screen")
    public void tc_159_Main_Screen_Tools_Calculator() {
        System.out.println(">>>tc_159_Main_Screen_Tools_Calculator<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Calculator | The Windows Calculator should
        // appear
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_159_Main_Screen_Tools_Calculator<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Access check for urgent messages from the main screen
     *
     * Pre-Conditions:  No urgent messages
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 160, description = "Access check for urgent messages from the main screen")
    public void tc_160_Main_Screen_Tools_Urgent_Messages() {
        System.out.println(">>>tc_160_Main_Screen_Tools_Urgent_Messages<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Tools -> Urgent Messages | A pop up stating
        // "No Pharmacy Action Messages Found" should appear
        tearDown();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();

        menuBar.navigateToMenu(AppMenu.URGENT_MESSAGES);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.URGENT_MESSAGES);

        System.out.println("<<<tc_160_Main_Screen_Tools_Urgent_Messages<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Access check for urgent messages from the left bar
     *
     * Pre-Conditions:  No urgent messages
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 161, description = " Access check for urgent messages from the left bar")
    public void tc_161_Main_Screen_Left_Bar_Urgent_messages() {
        System.out.println(">>>tc_161_Main_Screen_Left_Bar_Urgent_messages<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on urgent messages tile in the left bar | A pop up
        // stating "No Pharmacy Action Messages Found" should appear
        mainScreenUatTestScripts.clickUrgentMessageFromLeftBar();
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.URGENT_MESSAGES);

        System.out.println("<<<tc_161_Main_Screen_Left_Bar_Urgent_messages<<<");
    }

}
