package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.AppMenu;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.SearchItem;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainScreenUatTestSet19 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;
    MenuBar menuBar;
    AutomationManager automationManager;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        automationManager = AutomationManager.getInstance();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }


    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access Check for Printing HIPPA Signature Images"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 252)
    public void tc_252_Main_Screen_Reports_Print_Images_HIPPA_Signature() {
        System.out.println(">>>tc_252_Main_Screen_Reports_Print_Images_HIPPA_Signature<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Print Images -> HIPPA Signature | Print
        // Images - HIPPA Signatures popup should appear"
        menuBar.navigateToMenu(AppMenu.HIPAA_SIGNATURE);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.HIPAA_SIGNATURE);

        System.out.println("<<<tc_252_Main_Screen_Reports_Print_Images_HIPPA_Signature>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access Check for Printing Third Party Signature Images"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 253)
    public void tc_253_Main_Screen_Reports_Print_Images_Third_Party_Signature() {
        System.out.println(">>>tc_253_Main_Screen_Reports_Print_Images_Third_Party_Signature<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Print Images -> Third Party Signature |
        // Print Images - Third Party Signatures popup should appear"
        menuBar.navigateToMenu(AppMenu.THIRD_PARTY_SIGNATURE);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.THIRD_PARTY_SIGNATURE);

        System.out.println("<<<tc_253_Main_Screen_Reports_Print_Images_Third_Party_Signature>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access Check for Printing Easy Pay Signature"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 254)
    public void tc_254_Main_Screen_Reports_Print_Images_Easy_Pay_Signature() {
        System.out.println(">>>tc_254_Main_Screen_Reports_Print_Images_Easy_Pay_Signature<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Print Images -> Easy Pay Signature | Print
        // Images - Easy Pay Signature popup should appear"
        menuBar.navigateToMenu(AppMenu.EASY_PAY_SIGNATURE);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.EASY_PAY_SIGNATURE);

        System.out.println("<<<tc_254_Main_Screen_Reports_Print_Images_Easy_Pay_Signature>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access Check for Printing Pseudoephedrine Signature"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 255)
    public void tc_255_Main_Screen_Reports_Print_Images_Pseudoephedrine_Signature() {
        System.out.println(">>>tc_255_Main_Screen_Reports_Print_Images_Pseudoephedrine_Signature<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Print Images -> Pseudoephedrine Signature |
        // Print Images - Pseudoephedrine Signature popup should appear"
        menuBar.navigateToMenu(AppMenu.PSEUDOEPHEDRINE_SIGNATURE);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.PSEUDOEPHEDRINE_SIGNATURE);

        System.out.println("<<<tc_255_Main_Screen_Reports_Print_Images_Pseudoephedrine_Signature>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access Check for Printing Medicare AOB Signature"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 256)
    public void tc_256_Main_Screen_Reports_Print_Images_Medicare_AOB_Signature() {
        System.out.println(">>>tc_256_Main_Screen_Reports_Print_Images_Medicare_AOB_Signature<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Print Images -> Medicare AOB Signature |
        // Print Images - Medicare AOB Signature popup should appear"
        menuBar.navigateToMenu(AppMenu.MEDICARE_AOB_SIGNATURE);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.MEDICARE_AOB_SIGNATURE);

        System.out.println("<<<tc_256_Main_Screen_Reports_Print_Images_Medicare_AOB_Signature>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access Check for Printing Cash Payment Signatures"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 257)
    public void tc_257_Main_Screen_Reports_Print_Images_Cash_Payment_Signatures() {
        System.out.println(">>>tc_257_Main_Screen_Reports_Print_Images_Cash_Payment_Signatures<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Print Images -> Cash Payment Signatures |
        // Print Images - Cash Payment Signatures popup should appear"
        menuBar.navigateToMenu(AppMenu.CASH_PAYMENT_SIGNATURE);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.CASH_PAYMENT_SIGNATURE);

        System.out.println("<<<tc_257_Main_Screen_Reports_Print_Images_Cash_Payment_Signatures>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access Check for Printing Controlled Substance Pickup Signatures"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 258)
    public void tc_258_Main_Screen_Reports_Print_Images_Controlled_Substance_Pickup_Signatures() {
        System.out.println(">>>tc_258_Main_Screen_Reports_Print_Images_Controlled_Substance_Pickup_Signatures<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Print Images -> Controlled Substance Pickup
        // Signatures | Print Images - Controlled Substance Pickup Signatures
        // popup should appear"
        menuBar.navigateToMenu(AppMenu.CONTROLLED_SUBSTANCE_PICKUP__SIGNATURE);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.CONTROLLED_SUBSTANCE_PICKUP__SIGNATURE);

        System.out.println("<<<tc_258_Main_Screen_Reports_Print_Images_Controlled_Substance_Pickup_Signatures>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access Check for Printing ABN Signatures"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 259)
    public void tc_259_Main_Screen_Reports_Print_Images_ABN_Signatures() {
        System.out.println(">>>tc_259_Main_Screen_Reports_Print_Images_ABN_Signatures<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Print Images -> ABN Signatures | Print
        // Images - ABN Signatures popup should appear"
        menuBar.navigateToMenu(AppMenu.ANB_SIGNATURE);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.ANB_SIGNATURE);

        System.out.println("<<<tc_259_Main_Screen_Reports_Print_Images_ABN_Signatures>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for patient pseudoephedrine summary"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 260)
    public void tc_260_Main_Screen_Reports_Pseudoephedrine_Patient_Summary() {
        System.out.println(">>>tc_260_Main_Screen_Reports_Pseudoephedrine_Patient_Summary<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pseudoephedrine -> Patient Summary |
        // Pseudoephedrine Report - Patient Summary selection pop up should
        // appear"
        menuBar.navigateToMenu(AppMenu.PATIENT_SUMMARY);
//        connexusStartPage.mouseHoverOnElement(MobileBy.name("Patient Summary"), 1);
//        connexusStartPage.pressEnterKey();
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.PATIENT_SUMMARY);

        System.out.println("<<<tc_260_Main_Screen_Reports_Pseudoephedrine_Patient_Summary>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for store pseudoephedrine summary"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 261)
    public void tc_261_Main_Screen_Reports_Pseudoephedrine_Store_Summary() {
        System.out.println(">>>tc_261_Main_Screen_Reports_Pseudoephedrine_Store_Summary<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pseudoephedrine -> Store Summary |
        // Pseudoephedrine Report - Store Summary date selection pop up should
        // appear"
        menuBar.navigateToMenu(AppMenu.STORE_SUMMARY);
//        connexusStartPage.mouseHoverOnElement(MobileBy.name("Store Summary"), 1);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.STORE_SUMMARY);

        System.out.println("<<<tc_261_Main_Screen_Reports_Pseudoephedrine_Store_Summary>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for pseudoephedrine product summary"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 262)
    public void tc_262_Main_Screen_Reports_Pseudoephedrine_Product_Summary() {
        System.out.println(">>>tc_262_Main_Screen_Reports_Pseudoephedrine_Product_Summary<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pseudoephedrine -> Product Summary |
        // Pseudoephedrine Report - Summary date selection pop up should appear"
        menuBar.navigateToMenu(AppMenu.PRODUCT_SUMMARY);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.PRODUCT_SUMMAR);

        System.out.println("<<<tc_262_Main_Screen_Reports_Pseudoephedrine_Product_Summary>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for the MedicareB Audit Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 263)
    public void tc_263_Main_Screen_Reports_Third_Party_Reports_MedicareB_Audit_Report() {
        System.out.println(">>>tc_263_Main_Screen_Reports_Third_Party_Reports_MedicareB_Audit_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Third Party Reports -> MedicareB Audit
        // Report | MedicareB Audit Report selection pop up should appear"
        menuBar.navigateToMenu(AppMenu.MEDICARE_B_AUDIT_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.MEDICARE_B_AUDIT_REPORT);

        System.out.println("<<<tc_263_Main_Screen_Reports_Third_Party_Reports_MedicareB_Audit_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for the Offline Reversal Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 264)
    public void tc_264_Main_Screen_Reports_Third_Party_Reports_Offline_Reversal_Report() {
        System.out.println(">>>tc_264_Main_Screen_Reports_Third_Party_Reports_Offline_Reversal_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Third Party Reports -> Offline Reversal
        // Report | Offline Reversal Report date selection pop up should appear"
        menuBar.navigateToMenu(AppMenu.OFFLINE_REVERSAL_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.OFLILNE_REVERSAL_REPORT);

        System.out.println("<<<tc_264_Main_Screen_Reports_Third_Party_Reports_Offline_Reversal_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for the Third Party Sales analysis"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 265)
    public void tc_265_Main_Screen_Reports_Third_Party_Reports_Third_Party_Sales_analysis() {
        System.out.println(">>>tc_265_Main_Screen_Reports_Third_Party_Reports_Third_Party_Sales_analysis<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Third Party Reports ->Third Party Sales
        // analysis | Third Party Sales analysis selection pop up should appear"
        menuBar.navigateToMenu(AppMenu.THIRD_PARTY_SALES_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.TIRD_PARTY_SALSE_REPORT);

        System.out.println("<<<tc_265_Main_Screen_Reports_Third_Party_Reports_Third_Party_Sales_analysis>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for US paperbill reports"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 266)
    public void tc_266_Main_Screen_Reports_US_Paperbill_Reports() {
        System.out.println(">>>tc_266_Main_Screen_Reports_US_Paperbill_Reports<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> US Paperbill Reports | the US Paper Reports
        // Main Menu pop up should appear"
        menuBar.navigateToMenu(AppMenu.US_PAPER_BILL_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.US_PAPERBILL_REPORT);

        System.out.println("<<<tc_266_Main_Screen_Reports_US_Paperbill_Reports>>>");
    }


}
