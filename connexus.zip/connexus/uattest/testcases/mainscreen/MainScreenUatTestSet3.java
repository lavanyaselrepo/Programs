package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.LoginAs;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainScreenUatTestSet3 {
    MainScreenUatTestScripts mainScreenUatTestScripts;

    @BeforeClass
    public void beforeTestMethods() {
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button check for Filling Queue
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     *
     * ***NON AUTOMATE SCENARIO*** keeping the test for reporting purpose
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 23, description = "Button check for Filling Queue")
    public void tc_23_Main_Screen_Filling_access_from_left_bar() {
        System.out.println(">>>tc_23_Main_Screen_Filling_access_from_left_bar<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on Filling | Filling window should appear and log user
        // into filling
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_23_Main_Screen_Filling_access_from_left_bar>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shortcut check for Filling
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     *
     * ***NON AUTOMATE SCENARIO*** keeping the test for reporting purpose
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 24, description = "Shortcut check for Filling")
    public void tc_24_Main_Screen_Filling_access_from_keyboard_shortcut() {
        System.out.println(">>>tc_24_Main_Screen_Filling_access_from_keyboard_shortcut<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL+F | Filling window should appear and log user into
        // filling
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_24_Main_Screen_Filling_access_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu Check for accessing filling
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     *
     * ***NON AUTOMATE SCENARIO*** keeping the test for reporting purpose
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 25, description = "Menu Check for accessing filling")
    public void tc_25_Main_Screen_Filling_access_from_top_menu() {
        System.out.println(">>>tc_25_Main_Screen_Filling_access_from_top_menu<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on the Work Queue menu and select filling | Filling
        // window should appear and log user into filling
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_25_Main_Screen_Filling_access_from_top_menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button check for bagging
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     *
     * ***NON AUTOMATE SCENARIO*** keeping the test for reporting purpose
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 26, description = "Button check for bagging")
    public void tc_26_Main_Screen_Bagging_access_from_left_bar() {
        System.out.println(">>>tc_26_Main_Screen_Bagging_access_from_left_bar<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on bagging | Bagging window should appear and log user
        // into bagging
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_26_Main_Screen_Bagging_access_from_left_bar>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shortcut check for bagging
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     *
     * ***NON AUTOMATE SCENARIO*** keeping the test for reporting purpose
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 27, description = "Shortcut check for bagging")
    public void tc_27_Main_Screen_Bagging_access_from_keyboard_shortcut() {
        System.out.println(">>>tc_27_Main_Screen_Bagging_access_from_keyboard_shortcut<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + B | Bagging window should appear and log user
        // into bagging
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_27_Main_Screen_Bagging_access_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu check for accessing bagging
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     *
     * ***NON AUTOMATE SCENARIO*** keeping the test for reporting purpose
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 28, description = "Menu check for accessing bagging")
    public void tc_28_Main_screen_bagging_access_from_top_menu() {
        System.out.println(">>>tc_28_Main_screen_bagging_access_from_top_menu<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 click on the work queue menu and select filling | Bagging
        // window should appear and log user into bagging
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<tc_28_Main_screen_bagging_access_from_top_menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button check for Tasks
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 29, description = "Button check for Tasks")
    public void tc_29_Main_Screen_Tasks_access_from_left_bar() {
        System.out.println(">>>tc_29_Main_Screen_Tasks_access_from_left_bar<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click Action Items then Tasks | Tasks screen should appear
        mainScreenUatTestScripts.clickActionItemFromLeftBarThenTasks();

        System.out.println("<<<tc_29_Main_Screen_Tasks_access_from_left_bar>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Keyboard shortcut check for Tasks
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 30, description = "Keyboard shortcut check for Tasks")
    public void tc_30_Main_Screen_Tasks_access_from_keyboard_shortcut() {
        System.out.println(">>>tc_30_Main_Screen_Tasks_access_from_keyboard_shortcut<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + T | Tasks screen should appear
        mainScreenUatTestScripts.pressKeyboardShortCutToOpenActionItemTasksScreen();

        System.out.println("<<<tc_30_Main_Screen_Tasks_access_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu Check for accessing Tasks
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 31, description = "Menu Check for accessing Tasks")
    public void tc_31_Main_Screen_Tasks_access_from__top_menu() {
        System.out.println(">>>tc_31_Main_Screen_Tasks_access_from__top_menu<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 click on the tools menu and select tasks | Tasks screen should
        // appear
        mainScreenUatTestScripts.menuNavigationToOpenActionItemTasksScreen();

        System.out.println("<<<tc_31_Main_Screen_Tasks_access_from__top_menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button check for fax inbox
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 32, description = "Button check for fax inbox")
    public void tc_32_Main_Screen_Fax_inbox_access_from_left_bar() {
        System.out.println(">>>tc_32_Main_Screen_Fax_inbox_access_from_left_bar<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on Action Items then Fax Inbox | Fax Inbox Screen should
        // appear
        mainScreenUatTestScripts.clickActionItemFromLeftBarThenFaxInbox();

        System.out.println("<<<tc_32_Main_Screen_Fax_inbox_access_from_left_bar>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shortcut check for Fax Inbox
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 33, description = "Shortcut check for Fax Inbox")
    public void tc_33_Main_Screen_Fax_inbox_access_from_keyboard_shortcut() {
        System.out.println(">>>tc_33_Main_Screen_Fax_inbox_access_from_keyboard_shortcut<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + X | Fax Inbox Screen should appear
        mainScreenUatTestScripts.pressKeyboardShortCutToOpenActionItemFaxInboxScreen();

        System.out.println("<<<tc_33_Main_Screen_Fax_inbox_access_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu check for accessing Fax Inbox
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 34, description = "Menu check for accessing Fax Inbox")
    public void tc_34_Main_Screen_Fax_inbox_access_from_top_menu() {
        System.out.println(">>>tc_34_Main_Screen_Fax_inbox_access_from_top_menu<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 click on the tools menu and select Fax Inbox | Fax Inbox
        // Screen should appear
        mainScreenUatTestScripts.menuNavigationToOpenActionItemFaxInboxScreen();

        System.out.println("<<<tc_34_Main_Screen_Fax_inbox_access_from_top_menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button check for Fax Outbox
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 35, description = "Button check for Fax Outbox")
    public void tc_35_Main_Screen_Fax_outbox_access_from_left_bar() {
        System.out.println(">>>tc_35_Main_Screen_Fax_outbox_access_from_left_bar<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on Action Items then Fax outbox | Fax outbox Screen
        // should appear
        mainScreenUatTestScripts.clickActionItemFromLeftBarThenFaxOutbox();

        System.out.println("<<<tc_35_Main_Screen_Fax_outbox_access_from_left_bar>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shortcut check for Fax Outbox
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 36, description = "Shortcut check for Fax Outbox")
    public void tc_36_Main_Screen_Fax_outbox_access_from_keyboard_shortcut() {
        System.out.println(">>>tc_36_Main_Screen_Fax_outbox_access_from_keyboard_shortcut<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + O | Fax outbox Screen should appear
        mainScreenUatTestScripts.pressKeyboardShortCutToOpenActionItemFaxOutboxScreen();

        System.out.println("<<<tc_36_Main_Screen_Fax_outbox_access_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu check for accessing Fax Outbox
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 37, description = "Quick Icon check for Resolution")
    public void tc_37_Main_screen_fax_outbox_access_from_top_menu() {
        System.out.println(">>>tc_37_Main_screen_fax_outbox_access_from_top_menu<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on the tools menu and select fax outbox | Fax outbox
        // Screen should appear
        mainScreenUatTestScripts.menuNavigationToOpenActionItemFaxOutboxScreen();

        System.out.println("<<<tc_37_Main_screen_fax_outbox_access_from_top_menu>>>");
    }
}
