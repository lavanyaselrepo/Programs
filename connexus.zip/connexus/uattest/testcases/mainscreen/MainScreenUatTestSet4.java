package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.LoginAs;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainScreenUatTestSet4 {
    MainScreenUatTestScripts mainScreenUatTestScripts;

    @BeforeClass
    public void beforeTestMethods() {
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button Check for RPH access to 4-Point
     *
     * Pre-Conditions: RPH Login (not Homeoffice)
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 38, description = "Button Check for RPH access to 4-Point")
    public void tc_38_Main_screen_4_Point_access_from_left_bar() {
        System.out.println(">>>tc_38_Main_screen_4_Point_access_from_left_bar<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on 4 - Point | 4-Point button should become highlighted
        // and start feeding work if available
        mainScreenUatTestScripts.click4PointFromLeftBarAsRph();

        System.out.println("<<<tc_38_Main_screen_4_Point_access_from_left_bar>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shortcut check for RPH access to 4-Point
     *
     * Pre-Conditions: RPH Login (not Homeoffice)
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 39, description = "Shortcut check for RPH access to 4-Point")
    public void tc_39_Main_screen_4_Point_access_from_keyboard_shortcut() {
        System.out.println(">>>tc_39_Main_screen_4_Point_access_from_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + 4 | 4-Point button should become highlighted and
        // start feeding work if available
        mainScreenUatTestScripts.pressKeyboardShortCutToOpen4PointScreenAsRph();

        System.out.println("<<<tc_39_Main_screen_4_Point_access_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Quick Icon check for RPH access to 4-Point
     *
     * Pre-Conditions: RPH Login (not Homeoffice)
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 40, description = "Quick Icon check for RPH access to 4-Point")
    public void tc_40_Main_screen_4_point_access_from_Icon() {
        System.out.println(">>>tc_40_Main_screen_4_point_access_from_Icon<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on the 4P icon | 4-Point button should become
        // highlighted and start feeding work if available
        mainScreenUatTestScripts.clickQuickIconCheckFor4PointAsRph();

        System.out.println("<<<tc_40_Main_screen_4_point_access_from_Icon>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu check for RPH access to 4-Point
     *
     * Pre-Conditions: RPH Login (not Homeoffice)
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 41, description = "Menu check for RPH access to 4-Point")
    public void tc_41_Main_screen_4_Point_access_from_top_menu() {
        System.out.println(">>>tc_41_Main_screen_4_Point_access_from_top_menu<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 click on the Work Queue menu and select 4-point | 4-Point
        // button should become highlighted and start feeding work if available
        mainScreenUatTestScripts.menuNavigationToOpen4PointScreenAsRph();

        System.out.println("<<<tc_41_Main_screen_4_Point_access_from_top_menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button Check for RPH access to Visual Verify
     *
     * Pre-Conditions: RPH Login (not Homeoffice) and VV rack 1 or 2 assigned to station
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 42, description = "Button Check for RPH access to Visual Verify")
    public void tc_42_Main_screen_Visual_Verify_access_from_left_bar() {
        System.out.println(">>>tc_42_Main_screen_Visual_Verify_access_from_left_bar<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on Visual Verify | Visual Verify should become
        // highlighted and start feeding work if available
        mainScreenUatTestScripts.clickVisualVerifyFromLeftBarAsRph();

        System.out.println("<<<tc_42_Main_screen_Visual_Verify_access_from_left_bar>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shortcut check for RPH access to Visual Verify
     *
     * Pre-Conditions: RPH Login (not Homeoffice) and VV rack 1 or 2 assigned to station
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 43, description = "Shortcut check for RPH access to Visual Verify")
    public void tc_43_Main_screen_Visual_Verify_access_from_keyboard_shortcut() {
        System.out.println(">>>tc_43_Main_screen_Visual_Verify_access_from_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + Y | Visual Verify should become highlighted and
        // start feeding work if available
        mainScreenUatTestScripts.pressKeyboardShortCutToVisualVerifyScreenAsRph();

        System.out.println("<<<tc_43_Main_screen_Visual_Verify_access_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Quick Icon check for RPH access to Visual Verify
     *
     * Pre-Conditions: RPH Login (not Homeoffice) and VV rack 1 or 2 assigned to station
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 44, description = "Quick Icon check for RPH access to Visual Verify")
    public void tc_44_Main_Screen_Visual_Verify_access_from_Icon() {
        System.out.println(">>>tc_44_Main_Screen_Visual_Verify_access_from_Icon<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on the VV icon | Visual Verify should become highlighted
        // and start feeding work if available
        mainScreenUatTestScripts.clickQuickIconCheckForVisualVerifyAsRph();

        System.out.println("<<<tc_44_Main_Screen_Visual_Verify_access_from_Icon>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu check for RPH access to Visual Verify
     *
     * Pre-Conditions: RPH Login (not Homeoffice) and VV rack 1 or 2 assigned to station
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 45, description = "Menu check for RPH access to Visual Verify")
    public void tc_45_Main_screen_Visual_Verify_access_from_top_menu() {
        System.out.println(">>>tc_45_Main_screen_Visual_Verify_access_from_top_menu<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 click on the Work Queue menu and select Visual Verify | Visual
        // Verify should become highlighted and start feeding work if available
        mainScreenUatTestScripts.menuNavigationToOpenVisualVerifyScreenAsRph();

        System.out.println("<<<tc_45_Main_screen_Visual_Verify_access_from_top_menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button check for RPH access to Counseling
     *
     * Pre-Conditions: RPH Login (not Homeoffice)
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 46, description = "Button check for RPH access to Counseling")
    public void tc_46_Main_Screen_Counseling_access_from_left_bar() {
        System.out.println(">>>tc_46_Main_Screen_Counseling_access_from_left_bar<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on Counseling | Counseling button should highlight and
        // begin feeding work if available
        mainScreenUatTestScripts.clickCounselingFromLeftBarAsRph();

        System.out.println("<<<tc_46_Main_Screen_Counseling_access_from_left_bar>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shortcut check for RPH access to Counseling
     *
     * Pre-Conditions: RPH Login (not Homeoffice)
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 47, description = "Shortcut check for RPH access to Counseling")
    public void tc_47_Main_Screen_Counseling_access_from_keyboard_shortcut() {
        System.out.println(">>>tc_47_Main_Screen_Counseling_access_from_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + G | Counseling button should highlight and begin
        // feeding work if available
        mainScreenUatTestScripts.pressKeyboardShortCutToOpenCounselingScreenAsRph();

        System.out.println("<<<tc_47_Main_Screen_Counseling_access_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu check for RPH access to Counseling
     *
     * Pre-Conditions: RPH Login (not Homeoffice)
     *
     * Author: Ashok(Vn50h3h)
       ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 48, description = "Menu check for RPH access to Counseling")
    public void tc_48_Main_Screen_Counseling_access_from_top_menu() {
        System.out.println(">>>tc_48_Main_Screen_Counseling_access_from_top_menu<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on the Work Queue menu and select counseling |
        // Counseling button should highlight and begin feeding work if
        // available
        mainScreenUatTestScripts.menuNavigationToOpenCounselingScreenAsRph();

        System.out.println("<<<tc_48_Main_Screen_Counseling_access_from_top_menu>>>");
    }

}
