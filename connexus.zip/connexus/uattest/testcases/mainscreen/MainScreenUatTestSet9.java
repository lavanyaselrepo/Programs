package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class MainScreenUatTestSet9 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;
    MenuBar menuBar;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen opening the wire using F1
     * 
     * Pre-Conditions:None
     * 
     * Author: Ashok(Vn50h3h)
     * 
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 96, description = "Main Screen opening the wire using F1", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_96_Main_Screen_opening_the_wire_using_f1(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_opening_the_wire_using_f1<<<");

        // Step 1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Press F1 | The wire should launch"
        mainScreenUatTestScripts.nonAutomateScenario();

        System.out.println("<<<_Main_Screen_opening_the_wire_using_f1>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen File -> New option access check for adding a new prescriber
     * 
     * Pre-Conditions:None
     * 
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 97, description = "Main Screen File -> New option access check for adding a new prescriber", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_97_Main_Screen_file_new_option_access_check_for_adding_a_new_prescriber(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_file_new_option_access_check_for_adding_a_new_prescriber<<<");

        // Step1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Select File -> New -> Prescriber from the top menu | The
        // prescriber_Maintanence window should appear for createing a new
        // prescriber"
        menuBar.navigateToMenu(AppMenu.NEW_PRESCRIBER);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.PRESCRIBER);

        System.out.println("<<<_Main_Screen_file_new_option_access_check_for_adding_a_new_prescriber>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen New Prescriber shortcut check
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 98, description = "Main Screen New Prescriber shortcut check", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_98_Main_Screen_new_prescriber_shortcut_check(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_new_prescriber_shortcut_check<<<");

        // Step 1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Press ALT + Shift + B | The prescriber_Maintanence window
        // should appear for createing a new prescriber"
        connexusStartPage.inputShortcutKeys(AppShortcuts.NEW_PRESCRIBER.getAppShortcuts());
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.PRESCRIBER);

        System.out.println("<<<_Main_Screen_new_prescriber_shortcut_check>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen add Prescriber Icon Check with add/new prescriber selected by default
     *
     * Pre-Conditions:Add prescriber preselected by default
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 99, description = "Main Screen add Prescriber Icon Check with add/new prescriber selected by default", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_99_Main_Screen_add_prescriber_icon_check_with_add_new_prescriber_selected_by_default(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_add_prescriber_icon_check_with_add_new_prescriber_selected_by_default<<<");

        // Step 1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Click the icon for New prescriber | The prescriber_Maintanence
        // window should appear for createing a new prescriber"
        mainScreenUatTestScripts.clickQuickAccessIcon(SearchItem.PRESCRIBER);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.PRESCRIBER);

        System.out.println("<<<_Main_Screen_add_prescriber_icon_check_with_add_new_prescriber_selected_by_default>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen Add Prescriber Icon check from the icon menu
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 100, description = "Main Screen Add Prescriber Icon check from the icon menu", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_100_Main_Screen_add_prescriber_icon_check_from_the_icon_menu(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_add_prescriber_icon_check_from_the_icon_menu<<<");

        // Step 1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Click the menu arrow next to the quick icon | Menu for adding
        // should appear
        // Step 3 Select Add Prescriber | The prescriber_Maintanence window
        // should appear for createing a new prescriber"
        mainScreenUatTestScripts.selectItemFromQuickAccessDropDownArrow(SearchItem.NEW_PRESCRIBER, inputData);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.PRESCRIBER);

        System.out.println("<<<_Main_Screen_add_prescriber_icon_check_from_the_icon_menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen File -> New option access check for adding a new compound
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 101, description = "Main Screen File -> New option access check for adding a new compound", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_101_Main_Screen_file_new_option_access_check_for_adding_a_new_compound(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_file_new_option_access_check_for_adding_a_new_compound<<<");

        // Step 1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Select File -> New -> Compound from the top menu | Compound
        // Wizard should appear at step1"
        menuBar.navigateToMenu(AppMenu.NEW_COMPOUND);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.COMPOUND);

        System.out.println("<<<Main_Screen_file_new_option_access_check_for_adding_a_new_compound>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen New Compound shortcut check
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 102, description = "Main Screen New Compound shortcut check", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_102_Main_Screen_new_compound_shortcut_check(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_new_compound_shortcut_check<<<");

        // Step 1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Press ALT + Shift + C | Compound Wizard should appear at
        // step1"
        connexusStartPage.inputShortcutKeys(AppShortcuts.NEW_COMPOUND.getAppShortcuts());
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.COMPOUND);

        System.out.println("<<<Main_Screen_new_compound_shortcut_check>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main screen New compound icon check
     *
     * Pre-Conditions:Add Compound preselected by default
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 103, description = "Main screen New compound icon check", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_103_Main_Screen_new_compound_icon_check(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_new_compound_icon_check<<<");

        // Step 1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Click on the New Compound Icon | New compound wizard should
        // appear"
        mainScreenUatTestScripts.clickQuickAccessIcon(SearchItem.COMPOUND);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.COMPOUND);

        System.out.println("<<<_Main_Screen_new_compound_icon_check>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen New compound from Quick Icon menu
     *
     * Pre-Conditions:Add compound not selected
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 104, description = "Main Screen New compound from Quick Icon menu", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_104_Main_Screen_new_compound_from_quick_icon_menu(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_new_compound_from_quick_icon_menu<<<");

        // Step 1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Click the menu arrow next to the quick icon | Menu for adding
        // should appear
        // Step 3 Selected Add Compound | New Compound wizard should appear"
        mainScreenUatTestScripts.selectItemFromQuickAccessDropDownArrow(SearchItem.NEW_COMPOUND, inputData);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.COMPOUND);

        System.out.println("<<<_Main_Screen_new_compound_from_quick_icon_menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen File -> New option access check for adding a new pharmacy
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 105, description = "Main Screen File -> New option access check for adding a new pharmacy", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_105_Main_Screen_file_new_option_access_check_for_adding_a_new_pharmacy(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_file_new_option_access_check_for_adding_a_new_pharmacy<<<");

        // Step1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Select File -> new -> Pharmacy from the top menu | Add
        // Pharmacy/Pharmacy Lookup screen should appear"
        menuBar.navigateToMenu(AppMenu.NEW_PHARMACY);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.PHARMACY);

        System.out.println("<<<_Main_Screen_file_new_option_access_check_for_adding_a_new_pharmacy  >>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main screen new Pharmacy shortcut check
     *
     * Pre-Conditions:None
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 106, description = "Main screen new Pharmacy shortcut check", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_106_Main_Screen_new_pharmacy_shortcut_check(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_new_pharmacy_shortcut_check<<<");

        // Step 1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Press ALT + Shift + H | Add Pharmacy/Pharmacy Lookup screen
        // should appear"
        connexusStartPage.inputShortcutKeys(AppShortcuts.NEW_PHARMACY.getAppShortcuts());
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.PHARMACY);

        System.out.println("<<<_Main_Screen_new_pharmacy_shortcut_check >>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Main Screen New Pharmacy Quick Icon
     *
     * Pre-Conditions:New Pharmacy preselected
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 107, description = "Main Screen New Pharmacy Quick Icon", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_107_Main_Screen_new_pharmacy_quick_icon(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_new_pharmacy_quick_icon<<<");

        // Step 1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Click on the New Pharmacy Icon | Add Pharmacy/Pharmacy lo
        // okup
        // screen should appear"
        mainScreenUatTestScripts.clickQuickAccessIcon(SearchItem.PHARMACY);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.PHARMACY);

        System.out.println("<<<_Main_Screen_new_pharmacy_quick_icon>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Main screen New Pharmacy from Quick Icon Menu
     *
     * Pre-Conditions:New Pharmacy not selected
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 108, description = "Main screen New Pharmacy from Quick Icon Menu", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_108_Main_Screen_new_pharmacy_from_quick_icon_menu(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_new_pharmacy_from_quick_icon_menu<<<");

        // Step 1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Click the menu arrow next to the quick icon | Menu for adding
        // should appear
        // Step 3 Select Pharmacy | Add Pharmacy/Pharmacy lookup screen should
        // appear
        mainScreenUatTestScripts.selectItemFromQuickAccessDropDownArrow(SearchItem.NEW_PHARMACY, inputData);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.PHARMACY);

        System.out.println("<<<_Main_Screen_new_pharmacy_from_quick_icon_menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen File -> New option access check for adding  a new IMZ Event
     *
     * Pre-Conditions:RPH Login (no Homeoffice login)
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 109, description = "Main Screen File -> New option access check for adding  a new IMZ Event", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_109_Main_Screen_file_new_option_access_check_for_adding_a_new_imz_event_as_rph(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_file_new_option_access_check_for_adding_a_new_imz_event<<<");

        // Step 1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Select File -> new - IMZ Event from the top menu | IMZ event
        // search should appear"
        tearDown();
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        connexusStartPage.pressEscapeKey();
        menuBar.navigateToMenu(AppMenu.NEW_IMZ_EVENT);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.IMZ_EVENT);

        System.out.println("<<<_Main_Screen_file_new_option_access_check_for_adding__a_new_imz_event>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen IMZ Event creation shortcut check
     *
     * Pre-Conditions:RPH Login (no Homeoffice login)
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 110, description = "Main Screen IMZ Event creation shortcut check", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_110_Main_Screen_imz_event_creation_shortcut_check_as_rph(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_file_new_option_access_check_for_adding_a_new_imz_event<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press ALT + Shift + I | IMZ event search should appear
        connexusStartPage.pressEscapeKey();
        connexusStartPage.inputShortcutKeys(AppShortcuts.NEW_IMZ_EVENT.getAppShortcuts());
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.IMZ_EVENT);

        System.out.println("<<<_Main_Screen_file_new_option_access_check_for_adding__a_new_imz_event>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Main Screen IMZ Event quick icon
     *
     * Pre-Condition1:RPH Login (no Homeoffice login)
     *
     * Pre-Conditions2:New IMZ Event preselected
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 111, description = "Main Screen IMZ Event quick icon", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_111_Main_Screen_imz_event_quick_icon_as_rph(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_file_new_option_access_check_for_adding_a_new_imz_event<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click the New IMZ Evenet Quick Icon | IMZ Event search screen
        // should appear
        connexusStartPage.pressEscapeKey();
        mainScreenUatTestScripts.clickQuickAccessIcon(SearchItem.NEW_IMZ_EVENT);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.IMZ_EVENT);

        System.out.println("<<<_Main_Screen_file_new_option_access_check_for_adding__a_new_imz_event>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen new IMZ Event from quick icon menu
     *
     * Pre-Condition1:RPH Login (no Homeoffice login)
     *
     * Pre-Condition2:New IMZ Event not selected
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 112, description = "Main Screen new IMZ Event from quick icon menu", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_112_Main_Screen_new_imz_event_from_quick_icon_menu_as_rph(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_file_new_option_access_check_for_adding_a_new_imz_event<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click the menu arrow next to the quick icon | Menu for adding
        // should appear
        // Step 3 Select New IMZ event | IMZ Event search screen should appear
        connexusStartPage.pressEscapeKey();
        mainScreenUatTestScripts.selectItemFromQuickAccessDropDownArrow(SearchItem.NEW_IMZ_EVENT, inputData);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.IMZ_EVENT);

        System.out.println("<<<_Main_Screen_file_new_option_access_check_for_adding__a_new_imz_event>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen File -> New option access check for adding  a new IMZ Event
     *
     * Pre-Conditions:TECH Login (no Homeoffice login)
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 113, description = "Main Screen File -> New option access check for adding  a new IMZ Event", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_113_Main_Screen_file_new_option_access_check_for_adding_a_new_imz_event_as_tech(Map<String, String> inputData) {
        System.out.println(">>>tc_113_Main_Screen_file_new_option_access_check_for_adding_a_new_imz_event_as_tech<<<");

        // Step 1 Log in to Connexus | Connexus should bring up_Main screen
        // Step 2 Select File -> new - IMZ Event from the top menu | IMZ event
        // search should not appear"
        tearDown();
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        connexusStartPage.pressEscapeKey();
        mainScreenUatTestScripts.checkImzEventForTechUser();
        mainScreenUatTestScripts.validateNoScreenDisplayed(SearchItem.IMZ_EVENT);

        System.out.println("<<<tc_113_Main_Screen_file_new_option_access_check_for_adding_a_new_imz_event_as_tech>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Main Screen IMZ Event creation shortcut check
     *
     * Pre-Conditions: TECH Login (no Homeoffice login)
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 114, description = "Main Screen IMZ Event creation shortcut check", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet9")
    public void tc_114_Main_Screen_imz_event_creation_shortcut_check_as_tech(Map<String, String> inputData) {
        System.out.println(">>>tc_114_Main_Screen_imz_event_creation_shortcut_check_as_tech<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press ALT + Shift + I | IMZ event search should not appear
        connexusStartPage.pressEscapeKey();
        connexusStartPage.inputShortcutKeys(AppShortcuts.NEW_IMZ_EVENT.getAppShortcuts());
        mainScreenUatTestScripts.validateNoScreenDisplayed(SearchItem.IMZ_EVENT);

        System.out.println("<<<tc_114_Main_Screen_imz_event_creation_shortcut_check_as_tech>>>");
    }
}
