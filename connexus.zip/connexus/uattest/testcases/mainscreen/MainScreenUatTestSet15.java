package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainScreenUatTestSet15 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;
    MenuBar menuBar;
    AutomationManager automationManager;
    public static LoginAs.userType loginUser_Type=LoginAs.userType.HOMEOFFICE_ADFlagOn;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        AutomationManager.getInstance().performSleep(10);
        connexusAppUtils.startAppiumServer();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(loginUser_Type);
        mainScreenUatTestScripts.loginConnexus(loginUser_Type);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        automationManager = AutomationManager.getInstance();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Inventory adjustment report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 192)
    public void tc_192_Main_Screen_Inventory_Reports_Inventory_Adjustments() {
        System.out.println(">>>tc_192_Main_Screen_Inventory_Reports_Inventory_Adjustments<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Inventory Adjustment |
        // Inventory Adjustment report should appear"
        menuBar.selectNavigation(AppMenu.INVENTORY_ADJUSTMENT, AppMenuItemsIndex.INVENTORY_REPORTS,AppMenuSubItemsIndex.INVENTORY_ADJUSTMENTS,null);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.INVENTORY_ADJUSTMENT);

        System.out.println("<<<tc_192_Main_Screen_Inventory_Reports_Inventory_Adjustments>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Viewing drug orders in connexus"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 193)
    public void tc_193_Main_Screen_Inventory_Reports_View_Drug_orders() {
        System.out.println(">>>tc_193_Main_Screen_Inventory_Reports_View_Drug_orders<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> View Drug Orders | View
        // Drug Order selection pop up should appear"
        menuBar.selectNavigation(AppMenu.VIEW_DRUG_ORDER, AppMenuItemsIndex.INVENTORY_REPORTS,AppMenuSubItemsIndex.VIEW_DRUG_OFFER,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.VIEW_DRUG_ORDER);

        System.out.println("<<<tc_193_Main_Screen_Inventory_Reports_View_Drug_orders>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for the NIOSH report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 194)
    public void tc_194_Main_Screen_Inventory_Reports_NIOSH() {
        System.out.println(">>>tc_194_Main_Screen_Inventory_Reports_NIOSH<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> NIOSH Report | NIOSH
        // report selection pop up should appear"
        // menuBar.navigateToMenu(AppMenu.NIOSH_REPORT,
        // );
        // mainScreenUatTestScripts.validateReportScreenFor(SearchItem.NIOSH_REPORT,
        // );

        System.out.println("<<<tc_194_Main_Screen_Inventory_Reports_NIOSH>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for the Controlled substance inventory report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1440")
    @Test(priority = 195)
    public void HWPHME2E_1440_Main_Screen_Inventory_Reports_Controlled_Substance_Inventory_Report() {
        Reporter.log("Validating Controlled substance inventory report under Inventory report");
        connexusAppUtils.getStoreId();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> Controlled Substance
        // Inventory Report | the Controlled Substance Inventory report should
        // appear"
        mainScreenUatTestScripts.selectNavigation(AppMenu.CONTROLLED_SUBSTANCE_INVENTORY, AppMenuItemsIndex.INVENTORY_REPORTS,AppMenuSubItemsIndex.CONTROLLED_SUBSTANCE_INVENTORY_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.CONTROLLED_SUBSTANCE_INVENTORY);
        Reporter.log("Controlled substance inventory report page should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for the MTR report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 196)
    public void tc_196_Main_Screen_Inventory_Reports_MTR_Report() {
        System.out.println(">>>tc_196_Main_Screen_Inventory_Reports_MTR_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Inventory Reports -> MTR Report | the MTR
        // report should appear"
        mainScreenUatTestScripts.nonAutomateScenario();// MTR menu option is not available

        System.out.println("<<<tc_196_Main_Screen_Inventory_Reports_MTR_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Easy Pay Patient report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 197)
    public void tc_197_Main_Screen_Easy_Pay_Reports_Patient_Summary() {
        System.out.println(">>>tc_197_Main_Screen_Easy_Pay_Reports_Patient_Summary<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Easy Pay Reports -> Patient Summary | Easy
        // Pay report pop up should appear"
        menuBar.selectNavigation(AppMenu.EASY_PAY_PATIENT_SUMMARY, AppMenuItemsIndex.EASYPAY_REPORTS,AppMenuSubItemsIndex.PATIENT_SUMMARY,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.EASY_PAY_PATIENT_SUMMARY);

        System.out.println("<<<tc_197_Main_Screen_Easy_Pay_Reports_Patient_Summary>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for Easy Pay store report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 198)
    public void tc_198_Main_Screen_Easy_Pay_Reports_Store_Summary() {
        System.out.println(">>>tc_198_Main_Screen_Easy_Pay_Reports_Store_Summary<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Easy Pay Reports -> Store Summary | Easy Pay
        // report date selection pop up should appear"
        menuBar.selectNavigation(AppMenu.EASY_PAY_STORE_SUMMARY, AppMenuItemsIndex.EASYPAY_REPORTS,AppMenuSubItemsIndex.EASYPAY_STORE_SUMMARY,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.EASY_PAY_STORE_SUMMARY);

        System.out.println("<<<tc_198_Main_Screen_Easy_Pay_Reports_Store_Summary>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access Check for daily audit listing/report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 199)
    public void tc_199_Main_Screen_Reports_Daily_Reports_Daily_Audit_Listing() {
        System.out.println(">>>tc_199_Main_Screen_Reports_Daily_Reports_Daily_Audit_Listing<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Daily Reports -> Daily Audit Listing | Daily
        // Audit Listing pop-up should appear"
        menuBar.selectNavigation(AppMenu.DAILY_AUDIT_LISTING, AppMenuItemsIndex.DAILY_REPORTS,AppMenuSubItemsIndex.DAILY_AUDIT_LISTING,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.DAILY_AUDIT_LISTING);

        System.out.println("<<<tc_199_Main_Screen_Reports_Daily_Reports_Daily_Audit_Listing>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access Check for daily audit listing/report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 200)
    public void tc_200_Main_Screen_Reports_Daily_Reports_Missed_Opportunities_Report() {
        System.out.println(">>>tc_200_Main_Screen_Reports_Daily_Reports_Missed_Opportunities_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Daily Reports -> Missed Opportunities Report
        // | Missed opportunities date selection pop-up should appear"
        menuBar.selectNavigation(AppMenu.MISSED_OPPORTUNITIES_REPORT, AppMenuItemsIndex.DAILY_REPORTS,AppMenuSubItemsIndex.MISSED_OPPORTUNITIES_REPORTS,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.MISSED_OPPORTUNITIES_REPORT);

        System.out.println("<<<tc_200_Main_Screen_Reports_Daily_Reports_Missed_Opportunities_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access Check for the Pharmacy Business Summary"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1823")
    @Test(priority = 201)
    public void HWPHME2E_1823_Main_Screen_Reports_Daily_Reports_Pharmacy_Business_Summary() {
        Reporter.log("Validating Daily and monthly pharmacy business summary report under Daily report");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        connexusAppUtils.getStoreId();

        // Step 2 Select Reports -> Daily Reports -> Pharmacy sbusiness summary
        // | Pharmacy business summary date selection pop-up should appear"
        mainScreenUatTestScripts.selectNavigation(AppMenu.PHARMACY_BUSINESS_SUMMARY, AppMenuItemsIndex.DAILY_REPORTS,AppMenuSubItemsIndex.PHARMACY_BUSINESS_SUMMARY);
        mainScreenUatTestScripts.validateDailyReportForPharmacyBusinessSummary(SearchItem.PHARMACY_BUSINESS_SUMMARY);
        mainScreenUatTestScripts.selectNavigation(AppMenu.PHARMACY_BUSINESS_SUMMARY, AppMenuItemsIndex.DAILY_REPORTS,AppMenuSubItemsIndex.PHARMACY_BUSINESS_SUMMARY);
        mainScreenUatTestScripts.validateMonthlyReportForPharmacyBusinessSummary(SearchItem.PHARMACY_BUSINESS_SUMMARY);
        Reporter.log("Daily and Monthly pharmacy business summary report page should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access Check for the Order Completion Preformance"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 202)
    public void tc_202_Main_Screen_Reports_Daily_Reports_Order_Completion_Preformance() {
        System.out.println(">>>tc_202_Main_Screen_Reports_Daily_Reports_Order_Completion_Preformance<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Daily Reports -> Order Completion
        // Preformance | Order Completion Performance pop-up should appear"
        menuBar.selectNavigation(AppMenu.ORDER_COMPLETION_PERFORMANCE, AppMenuItemsIndex.DAILY_REPORTS,AppMenuSubItemsIndex.ORDER_COMPLETION_PERFORMANCE,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.ORDER_COMPLETION_PERFORMANCE);

        System.out.println("<<<tc_202_Main_Screen_Reports_Daily_Reports_Order_Completion_Preformance>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access Check for the Log Copy Label activity report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 203)
    public void tc_203_Main_Screen_Reports_Daily_Reports_Log_Copy_Label_activity() {
        System.out.println(">>>tc_203_Main_Screen_Reports_Daily_Reports_Log_Copy_Label_activity<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Daily Reports -> Log Copy Label activity |
        // Log Copy Label activity pop-up should appear"
        menuBar.selectNavigation(AppMenu.LOG_COPY_LABEL_ACTIVITY, AppMenuItemsIndex.DAILY_REPORTS,AppMenuSubItemsIndex.LOG_COPY_LABEL_ACTIVITY,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.LOG_COPY_LABEL_ACTIVITY);

        System.out.println("<<<tc_203_Main_Screen_Reports_Daily_Reports_Log_Copy_Label_activity>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access Check for the Log Copy Label Status report"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 204)
    public void tc_204_Main_Screen_Reports_Daily_Reports_Log_Copy_Label_Status() {
        System.out.println(">>>tc_204_Main_Screen_Reports_Daily_Reports_Log_Copy_Label_Status<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Daily Reports -> Log Copy Label activity |
        // Log Copy Label Status report pop-up should appear"
        menuBar.selectNavigation(AppMenu.LOG_COPY_LABEL_STATUS, AppMenuItemsIndex.DAILY_REPORTS,AppMenuSubItemsIndex.LOG_COPY_LABEL_STATUS,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.LOG_COPY_LABEL_STATUS);

        System.out.println("<<<tc_204_Main_Screen_Reports_Daily_Reports_Log_Copy_Label_Status>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access Check for the Log Copy Print Program"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
     *
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 205)
    public void tc_205_Main_Screen_Reports_Daily_Reports_Log_Copy_Print_Program() {
        System.out.println(">>>tc_205_Main_Screen_Reports_Daily_Reports_Log_Copy_Print_Program<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Daily Reports -> Log Copy Print Program |
        // Log Copy Print Program should appear"
        mainScreenUatTestScripts.nonAutomateScenario();//the menu option is opening up putty screen

        System.out.println("<<<tc_205_Main_Screen_Reports_Daily_Reports_Log_Copy_Print_Program>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access Check for Reprinting a log copy file Label"
     *
     * Pre-Conditions:"None"
     *
     * Author: Ashok(Vn50h3h)
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 206)
    public void tc_206_Main_Screen_Reports_Daily_Reports_Reprint_file_Label() {
        System.out.println(">>>tc_206_Main_Screen_Reports_Daily_Reports_Reprint_file_Label<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Daily Reports -> Reprint file Label |
        // Reprint file Label pop up should appear"
        menuBar.selectNavigation(AppMenu.REPRINT_FILE_LABEL, AppMenuItemsIndex.DAILY_REPORTS,AppMenuSubItemsIndex.REPRINT_FILE_LABEL,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.REPRINT_FILE_LABEL);

        System.out.println("<<<tc_206_Main_Screen_Reports_Daily_Reports_Reprint_file_Label>>>");
    }
}
