package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainScreenUatTestSet2 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();

    @BeforeClass
    public void beforeTestMethods() {
        AutomationManager.getInstance().performSleep(10);
        connexusAppUtils.startAppiumServer();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button check for drop off 
     * 
     * Pre-Conditions: None
     *  
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 12, description = "Button check for drop off ")
    public void tc_12_Main_Screen_DropOff_access_from_left_bar() {
        Reporter.log(">>>tc_12_Main_Screen_DropOff_access_from_left_bar<<<");
        connexusAppUtils.getStoreId();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click Drop off | Drop off window should come up
        mainScreenUatTestScripts.clickDropOffFromLeftBar();

        Reporter.log("<<<tc_12_Main_Screen_DropOff_access_from_left_bar>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shortcut check for drop off
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 13, description = "Shortcut check for drop off")
    public void HWPHME2E_533_Main_Screen_DropOff_access_from_keyboard_shortcut() {
        Reporter.log("<<<Validating drop off screen by using keyboard short cut Ctrl+D>>>");
        connexusAppUtils.getStoreId();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + D | Drop off window should come up
        mainScreenUatTestScripts.pressKeyboardShortCutToOpenDropOffScreen();

        Reporter.log("<<<Drop off screen should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu check for accessing drop off
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 14, description = "Menu check for accessing drop off")
    public void HWPHME2E_535_Main_screen_DropOff_access_from_top_menu() {
        Reporter.log("<<<Validating drop off screen by selecting Drop off option under Work queue menu options>>>");
        connexusAppUtils.getStoreId();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on Work Queue top menu and select Drop off | Drop off
        // window should come up
        mainScreenUatTestScripts.menuNavigationToOpenDropOffScreen();

        Reporter.log("Drop off screen should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button check for input
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 15, description = "Button check for input")
    public void HWPHME2E_536_Main_Screen_Input_access_from_left_bar() {
        Reporter.log("Validating input screen by clicking on input option from left bar");
        connexusAppUtils.getStoreId();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on Input | Input Should highlight and begin feeding work
        mainScreenUatTestScripts.clickInputFromLeftBar();

        Reporter.log("Drop off screen should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shortcut check for drop off
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 16, description = "Shortcut check for drop off")
    public void HWPHME2E_537_Main_Screen_Input_access_from_Keyboard_Shortcut() {
        Reporter.log("Validating input screen by using keyboard short cut Ctrl+I");
        connexusAppUtils.getStoreId();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + I | Input Should highlight and begin feeding work
        mainScreenUatTestScripts.pressKeyboardShortCutToOpenInputScreen();

        Reporter.log("Input screen should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Quick Icon check for Input
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 17, description = "Quick Icon check for Input")
    public void HWPHME2E_2928_Main_Screen_Input_access_from_Icon() {

        Reporter.log("Validating input screen by clicking on I icon below to menu bar");
        connexusAppUtils.getStoreId();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click the I icon below the top menus | Input Should highlight
        // and begin feeding work
        mainScreenUatTestScripts.clickQuickIconCheckForInput();

        Reporter.log("Input screen should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu check for accessing input
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 18, description = "Menu check for accessing input")
        public void HWPHME2E_538_Main_Screen_Input_access_from_top_menu() {
        Reporter.log("Validating Input screen by selecting Input option under Work queue menu options");
        connexusAppUtils.getStoreId();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click the Work Queue top menu and select input | Input Should
        // highlight and begin feeding work
        mainScreenUatTestScripts.menuNavigationToOpenInputScreen();

        Reporter.log("Input screen should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Button Check for Resolution
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 19, description = "Button Check for Resolution")
    public void HWPHME2E_539_Main_Screen_Resolution_access_from_left_bar() {
        Reporter.log("Validating Resolution screen by clicking on Resolution option from left bar");
        connexusAppUtils.getStoreId();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on resolution | Resolution should highlight and begin
        // feeding work
        mainScreenUatTestScripts.clickResolutionFromLeftBar();

        Reporter.log("Resolution screen should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Shotcut Check for Resolution
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 20, description = "Shotcut Check for Resolution")
    public void HWPHME2E_540_Main_Screen_Resolution_access_from_keyboard_shortcut() {
        Reporter.log("Validating Resolution screen by using keyboard short cut Ctrl+R");
        connexusAppUtils.getStoreId();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL+R | Resolution should highlight and begin feeding
        // work
        mainScreenUatTestScripts.pressKeyboardShortCutToOpenResolutionScreen();

        Reporter.log("Resolution screen should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Quick Icon check for Resolution
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 21, description = "Quick Icon check for Resolution")
    public void HWPHME2E_541_Main_Screen_Resolution_access_from_Icon() {
        Reporter.log("Validating Resolution screen by clicking on R icon below to menu bar");
        connexusAppUtils.getStoreId();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on the R icon below the top menus | Resolution should
        // highlight and begin feeding work
        mainScreenUatTestScripts.clickQuickIconCheckForResolution();

        Reporter.log("Resolution screen should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Menu check for accessing Resolution
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 22, description = "Validating Resolution screen by selecting Resolution option under Work queue menu options")
    public void HWPHME2E_542_Main_Screen_Resolution_access_from_top_menu() {
        Reporter.log("Validating Resolution screen by selecting Resolution option under Work queue menu options");
        connexusAppUtils.getStoreId();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click on the Work Queue menu and select resolution |
        // Resolution should highlight and begin feeding work
        mainScreenUatTestScripts.menuNavigationToOpenResolutionScreen();

        Reporter.log("Resolution screen should be displayed");
    }
}
