package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.AppShortcuts;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.SearchItem;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class MainScreenUatTestSet6 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.readAndUpdateFlag("32686", "FALSE");
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Searchbar check for patient searches from the main screen
     *
     * Pre-Conditions: New PSS Flag OFF Patient Search preselected next to search bar
     *
     * Author: Ashok(Vn50h3h)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 60, description = "Searchbar check for patient searches from the main screen", dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet6")
    public void tc_60_Main_Screen_patient_search_from_top_bar_patient_search_preselected(Map<String, String> inputData) {
        System.out.println(">>>tc_60_Main_Screen_patient_search_from_top_bar_patient_search_preselected<<<");

        //Pre-Condition
        //New PSS Flag OFF - implemented part of before class
        // Patient Search preselected next to search bar
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PATIENT, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type Patient name into the search bar. Lastname, Firstname or
        // Firstname Lastname | Search Bar should accept user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PATIENT, inputData);

        // Step 3 press enter | Patient search screen should appear with data
        // from search bar
        connexusStartPage.pressEnterKey();
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PATIENT, inputData);

        System.out.println("<<<tc_60_Main_Screen_patient_search_from_top_bar_patient_search_preselected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Searchbar check for patient searches from the main screen
     *
     * Pre-Conditions: New PSS Flag OFF Patient Search not selected next to search bar
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 61, description = "Searchbar check for patient searches from the main screen", dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet6")
    public void tc_61_Main_Screen_patient_search_from_top_bar_patient_search_not_preselected(Map<String, String> inputData) {
        System.out.println(">>>tc_61_Main_Screen_patient_search_from_top_bar_patient_search_not_preselected<<<");

        // Pre-Conditions: New PSS Flag OFF
        // Patient Search not selected next to search bar
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PRESCRIBER, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type Patient name into the search bar. Lastname, Firstname or
        // Firstname Lastname | Search Bar should accept user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PATIENT, inputData);
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PATIENT, inputData);

        // Step 3 Choose Patient search from the menu next to the search box |
        // Patient search screen should appear with data from search bar
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PATIENT, inputData);

        System.out.println("<<<tc_61_Main_Screen_patient_search_from_top_bar_patient_search_not_preselected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Shortcut check for searching for a patient
     *
     * Pre-Conditions: New PSS Flag OFF
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 62, description = "Shortcut check for searching for a patient", dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet6")
    public void tc_62_Main_Screen_patient_search_from_keyboard_shortcut(Map<String, String> inputData) {
        System.out.println(">>>tc_62_Main_Screen_patient_search_from_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + Shift + P | Patient Search Screen should appear
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PATIENT, inputData);
        connexusStartPage.inputShortcutKeys(AppShortcuts.PATIENT_SEARCH.getAppShortcuts());
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PATIENT, inputData);

        System.out.println("<<<tc_62_Main_Screen_patient_search_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Searchbar check for prescriber searches from the main screen (prescriber search preselected)
     *
     * Pre-Conditions: Prescriber search preselected next to search bar
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 63, description = "Searchbar check for prescriber searches from the main screen (prescriber search preselected)", dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet6")
    public void tc_63_Main_Screen_prescriber_search_from_top_bar_with_prescriber_search_preselected(Map<String, String> inputData) {
        System.out.println(">>>tc_63_Main_Screen_prescriber_search_from_top_bar_with_prescriber_search_preselected<<<");

        //Pre-Conditions:
        // Prescriber search preselected next to search bar
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PRESCRIBER, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type Prescriber name into the search bar. Lastname, Firstname
        // or Firstname Lastname | Search Bar should accept user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PRESCRIBER, inputData);

        // Step 3 press enter | Prescriber Search screen should appear with data
        // from entered in the search bar
        connexusStartPage.pressEnterKey();
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PRESCRIBER, inputData);

        System.out.println("<<<tc_63_Main_Screen_prescriber_search_from_top_bar_with_prescriber_search_preselected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Searchbar check for prescriber searches from the main screen (prescriber search not selected)
     *
     * Pre-Conditions: Prescriber search not selected next to search bar
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 64, description = "Searchbar check for prescriber searches from the main screen (prescriber search not selected)", dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet6")
    public void tc_64_Main_Screen_prescriber_search_from_top_bar_with_prescriber_search_not_selected(Map<String, String> inputData) {
        System.out.println(">>>tc_64_Main_Screen_prescriber_search_from_top_bar_with_prescriber_search_not_selected<<<");

        //Pre-Conditions:
        //Prescriber search not selected next to search bar
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PATIENT, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus|Connexus should bring up main screen
        // Step 2 Type Prescriber name into the search bar. Lastname, Firstname
        // or Firstname Lastname | Search Bar should accept user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PRESCRIBER, inputData);

        // Step 3 Choose Prescriber search from the menu next to the search box
        // | Prescriber Search screen should appear with data from entered in
        // the search bar
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PRESCRIBER, inputData);
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PRESCRIBER, inputData);

        System.out.println("<<<tc_64_Main_Screen_prescriber_search_from_top_bar_with_prescriber_search_not_selected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Shortcut check for searching for a prescriber
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 65, description = "Shortcut check for searching for a prescriber", dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet6")
    public void tc_65_Main_Screen_prescriber_search_from_keyboard_shortcut(Map<String, String> inputData) {
        System.out.println(">>>tc_65_Main_Screen_prescriber_search_from_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + Shift + B | Prescriber Search screen should
        // appear
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PRESCRIBER, inputData);
        connexusStartPage.inputShortcutKeys(AppShortcuts.PRESCRIBER.getAppShortcuts());
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PRESCRIBER, inputData);

        System.out.println("<<<tc_65_Main_Screen_prescriber_search_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Searchbar check for product searches from the main screen(Product search preselected)
     *
     * Pre-Conditions: Product Search preselected
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 66, description = "Searchbar check for product searches from the main screen(Product search preselected)", dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet6")
    public void tc_66_Main_Screen_product_search_from_top_bar_with_product_search_preselected(Map<String, String> inputData) {
        System.out.println(">>>tc_66_Main_Screen_product_search_from_top_bar_with_product_search_preselected<<<");

        //Pre-Conditions:
        //Product Search preselected
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PRODUCT, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type product name into the search bar. Productname
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PRODUCT, inputData);

        // Productstrength or Productname | Search Bar should accept user input
        // Step 3 Press enter | Product Search screen should appear with data
        // from entered in the search bar
        connexusStartPage.pressEnterKey();
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PRODUCT, inputData);

        System.out.println("<<<tc_66_Main_Screen_product_search_from_top_bar_with_product_search_preselected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Searchbar check for product Searches
     *
     * Pre-Conditions: Product Search not selected
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 67, description = "Searchbar check for product Searches", dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet6")
    public void tc_67_Main_Screen_product_search_from_top_bar_with_product_search_not_selected(Map<String, String> inputData) {
        System.out.println(">>>tc_67_Main_Screen_product_search_from_top_bar_with_product_search_not_selected<<<");

        //Pre-Conditions:
        // Product Search not selected
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PATIENT, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type product name into the search bar. Productname
        // Productstrength or Productname | Search Bar should accept user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PRODUCT, inputData);

        // Step 3 Choose Product Search from the menu next to the search box |
        // Product Search screen should appear with data from entered in the
        // search bar
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PRODUCT, inputData);
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PRODUCT, inputData);

        System.out.println("<<<tc_67_Main_Screen_product_search_from_top_bar_with_product_search_not_selected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Shortcut check for product searches
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 68, description = "Shortcut check for product searches", dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet6")
    public void tc_68_Main_Screen_product_search_from_keyboard_shortcut(Map<String, String> inputData) {
        System.out.println(">>>tc_68_Main_Screen_product_search_from_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + Shift+ D | Search screen should appear
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PRODUCT, inputData);
        connexusStartPage.inputShortcutKeys(AppShortcuts.PRODUCT.getAppShortcuts());
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PRODUCT, inputData);

        System.out.println("<<<tc_68_Main_Screen_product_search_from_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Searchbar check for compound searches with compound search preselected
     *
     * Pre-Conditions: compound search preselected
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 69, description = "Searchbar check for compound searches with compound search preselected", dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet6")
    public void tc_69_Main_Screen_compound_search_from_top_bar_with_compound_search_preselected(Map<String, String> inputData) {
        System.out.println(">>>tc_69_Main_Screen_compound_search_from_top_bar_with_compound_search_not_selected<<<");

        //Pre-Conditions: 
        // compound search preselected
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.COMPOUND, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type Compound name into search bar | Search Bar should accept
        // user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.COMPOUND, inputData);

        // Step 3 Press enter | Compound Search screen should appear with data
        // entered in the search bar
        connexusStartPage.pressEnterKey();
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.COMPOUND, inputData);


        System.out.println("<<<tc_69_Main_Screen_compound_search_from_top_bar_with_compound_search_not_selected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Searchbar check for compound searches with compound search not selected
     *
     * Pre-Conditions: Compound search not selected
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 70, description = "Shortcut", dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet6")
    public void tc_70_Main_Screen_compound_search_from_top_bar_with_compound_search_not_selected(Map<String, String> inputData) {
        System.out.println(">>>tc_70_Main_Screen_compound_search_from_top_bar_with_compound_search_not_selected<<<");

        //Pre-Conditions:
        //Compound search not selected
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PATIENT, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type Compound name into search bar | Search Bar should accept
        // user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.COMPOUND, inputData);

        // Step 3 Choose Compound search from the menu next to the search box |
        // Compound Search screen should appear with data entered in the search
        // bar
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.COMPOUND, inputData);
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.COMPOUND, inputData);

        System.out.println("<<<tc_70_Main_Screen_compound_search_from_top_bar_with_compound_search_not_selected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Shortcut check for compound searches
     *
     * Pre-Conditions: None
     *
     * Author: Ashok(Vn50h3h)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 71, description = "Shortcut check for compound searches", dataProviderClass = DataProvider.class,
            dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet6")
    public void tc_71_Main_Screen_compound_search_from_keyboard_shortcut(Map<String, String> inputData) {
        System.out.println(">>>tc_71_Main_Screen_compound_search_from_keyboard_shortcut<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + Shift + C | Compound Search screen should appear
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.COMPOUND, inputData);
        connexusStartPage.inputShortcutKeys(AppShortcuts.COMPOUND.getAppShortcuts());
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.COMPOUND, inputData);

        System.out.println("<<<tc_71_Main_Screen_compound_search_from_keyboard_shortcut>>>");
    }

}
