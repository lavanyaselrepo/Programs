package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.AppMenu;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.SearchItem;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainScreenUatTestSet18 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;
    MenuBar menuBar;
    AutomationManager automationManager;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        automationManager = AutomationManager.getInstance();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }


    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Wait for Drug Order Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 237)
    public void TC_237_Main_Screen_Reports_RX_Reports_Wait_for_Drug_Order_Report() {
        System.out.println(">>>TC_237_Main_Screen_Reports_RX_Reports_Wait_for_Drug_Order_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Wait for Drug Order Report |
        // Wait for Drug Order Report date selection pop up should appear"
        menuBar.navigateToMenu(AppMenu.WAIT_FOR_DRUG_ORDER_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.WAIT_FOR_DRUG_ORDER_REPORT);

        System.out.println("<<<TC_237_Main_Screen_Reports_RX_Reports_Wait_for_Drug_Order_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Partial Fill Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 238)
    public void TC_238_Main_Screen_Reports_RX_Reports_Partial_Fill_Report() {
        System.out.println(">>>TC_238_Main_Screen_Reports_RX_Reports_Partial_Fill_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Partial Fill Report | Partial
        // Fill Report date selection pop up should appear"
        menuBar.navigateToMenu(AppMenu.PARTIAL_FILL_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.PARTIAL_FILL_REPORT);

        System.out.println("<<<TC_238_Main_Screen_Reports_RX_Reports_Partial_Fill_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Transfer Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 239)
    public void TC_239_Main_Screen_Reports_RX_Reports_Transfer_Reports_Transfer_Report() {
        System.out.println(">>>TC_239_Main_Screen_Reports_RX_Reports_Transfer_Reports_Transfer_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Transfer Reports -> Transfer
        // Report | Transfer Report date selection pop up should appear"
        menuBar.navigateToMenu(AppMenu.TRANSFER_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.TRANSFER_REPORT);

        System.out.println("<<<TC_239_Main_Screen_Reports_RX_Reports_Transfer_Reports_Transfer_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Transfer History Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 240)
    public void TC_240_Main_Screen_Reports_RX_Reports_Transfer_Reports_Transfer_History_Report() {
        System.out.println(">>>TC_240_Main_Screen_Reports_RX_Reports_Transfer_Reports_Transfer_History_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Transfer Reports -> Transfer
        // History Report | Transfer History Report pop up should appear"
        menuBar.navigateToMenu(AppMenu.TRANSFER_HISTORY_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.TRANSFER_HISTORY_REPORT);

        System.out.println("<<<TC_240_Main_Screen_Reports_RX_Reports_Transfer_Reports_Transfer_History_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for  Override Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 241)
    public void TC_241_Main_Screen_Reports_RX_Reports_Override_Report() {
        System.out.println(">>>TC_241_Main_Screen_Reports_RX_Reports_Override_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Override Report | Override
        // Report date selection pop up should appear"
        menuBar.navigateToMenu(AppMenu.OVERRIDE_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.OVERRIDE_REPORT);

        System.out.println("<<<TC_241_Main_Screen_Reports_RX_Reports_Override_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Price Below Cost Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 242)
    public void TC_242_Main_Screen_Reports_RX_Reports_Price_Below_Cost_Report() {
        System.out.println(">>>TC_242_Main_Screen_Reports_RX_Reports_Price_Below_Cost_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Price Below Cost Report |
        // Price Below Cost Report date selection pop up should appear"
        menuBar.navigateToMenu(AppMenu.PRICE_BELOW_COST_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.PRICE_BELOW_COST_REPORT);

        System.out.println("<<<TC_242_Main_Screen_Reports_RX_Reports_Price_Below_Cost_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Rx Activity Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 243)
    public void TC_243_Main_Screen_Reports_RX_Reports_Rx_Activity_Report() {
        System.out.println(">>>TC_243_Main_Screen_Reports_RX_Reports_Rx_Activity_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Rx Activity Report | Rx
        // Activity Report pop up should appear"
        menuBar.navigateToMenu(AppMenu.RX_ACTIVITY_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.RX_ACTIVITY_REPORT);

        System.out.println("<<<TC_243_Main_Screen_Reports_RX_Reports_Rx_Activity_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Controlled Substance Pickup Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 244)
    public void TC_244_Main_Screen_Reports_RX_Reports_Controlled_Substance_Pickup_Report() {
        System.out.println(">>>TC_244_Main_Screen_Reports_RX_Reports_Controlled_Substance_Pickup_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Controlled Substance Pickup
        // Report | Controlled Substance Pickup Report pop up should appear"
        menuBar.navigateToMenu(AppMenu.CONTROLLED_SUBSTANCE_PICKUP_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.CONTROLLED_SUBSTANCE_PICKUP_REPORT);

        System.out.println("<<<TC_244_Main_Screen_Reports_RX_Reports_Controlled_Substance_Pickup_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Patient Language Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 245)
    public void TC_245_Main_Screen_Reports_RX_Reports_Patient_Language_Report() {
        System.out.println(">>>TC_245_Main_Screen_Reports_RX_Reports_Patient_Language_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Patient Language Report |
        // Patient Language Report should appear"
        menuBar.navigateToMenu(AppMenu.PATIENT_LANGUAGE_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.PATIENT_LANGUAGE_REPORT);

        System.out.println("<<<TC_245_Main_Screen_Reports_RX_Reports_Patient_Language_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Leaflet Cover Sheet Printed by Language"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 246)
    public void TC_246_Main_Screen_Reports_RX_Reports_Leaflet_Cover_Sheet_Printed_by_Language() {
        System.out.println(">>>TC_246_Main_Screen_Reports_RX_Reports_Leaflet_Cover_Sheet_Printed_by_Language<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Leaflet Cover Sheet Printed by
        // Language | Leaflet Cover Sheet Printed by Language pop up should
        // appear"
        menuBar.navigateToMenu(AppMenu.LEAFLET_COVER_SHEET_PRINTED_BY_LANGUAGE);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.LEAFLET_COVER_SHEET_PRINTED_BY_LANGUAGE);

        System.out.println("<<<TC_246_Main_Screen_Reports_RX_Reports_Leaflet_Cover_Sheet_Printed_by_Language>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Emergency C2 Fills Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 247)
    public void TC_247_Main_Screen_Reports_RX_Reports_Emergency_C2_Fills_Report() {
        System.out.println(">>>TC_247_Main_Screen_Reports_RX_Reports_Emergency_C2_Fills_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Emergency C2 Fills Report |
        // Emergency C2 Fills Report pop up should appear"
        menuBar.navigateToMenu(AppMenu.EMERGENCY_C2_FILLS_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.EMERGENCY_C2_FILLS_REPORT);

        System.out.println("<<<TC_247_Main_Screen_Reports_RX_Reports_Emergency_C2_Fills_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Early Refill for Controlled Drugs Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 248)
    public void TC_248_Main_Screen_Reports_RX_Reports_Early_Refill_for_Controlled_Drugs_Report() {
        System.out.println(">>>TC_248_Main_Screen_Reports_RX_Reports_Early_Refill_for_Controlled_Drugs_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Early Refill for Controlled
        // Drugs Report | Early Refill for Controlled Drugs Report pop up should
        // appear"
        menuBar.navigateToMenu(AppMenu.EARLY_REFILL_FOR_CONTROLLED_DRUG_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.EARLY_REFILL_FOR_CONTROLLED_DRUG_REPORT);

        System.out.println("<<<TC_248_Main_Screen_Reports_RX_Reports_Early_Refill_for_Controlled_Drugs_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for the  Emergency Fill Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 249)
    public void TC_249_Main_Screen_Reports_RX_Reports_Emergency_Fill_Report() {
        System.out.println(">>>TC_249_Main_Screen_Reports_RX_Reports_Emergency_Fill_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Emergency Fill Report |
        // Emergency Fill Report pop up should appear"
        menuBar.navigateToMenu(AppMenu.EMERGENCY_FILL_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.EMERGENCY_FILL_REPORT);

        System.out.println("<<<TC_249_Main_Screen_Reports_RX_Reports_Emergency_Fill_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for the XDEA Number Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 250)
    public void TC_250_Main_Screen_Reports_RX_Reports_XDEA_Number_Report() {
        System.out.println(">>>TC_250_Main_Screen_Reports_RX_Reports_XDEA_Number_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> XDEA Number Report | XDEA
        // Number Report pop up should appear"
        menuBar.navigateToMenu(AppMenu.XDEA_NUMBER_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.XDEA_NUMBER_REPORT);

        System.out.println("<<<TC_250_Main_Screen_Reports_RX_Reports_XDEA_Number_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access Check for Printing Prescription Images"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 251)
    public void TC_251_Main_Screen_Reports_Print_Images_Prescription_Image() {
        System.out.println(">>>TC_251_Main_Screen_Reports_Print_Images_Prescription_Image<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Print Images -> Prescription Image | Print
        // Images - Rx Images popup should appear"
        menuBar.navigateToMenu(AppMenu.PRESCRIPTION_IMAGE);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.PRESCRIPTION_IMAGE);

        System.out.println("<<<TC_251_Main_Screen_Reports_Print_Images_Prescription_Image>>>");
    }


}
