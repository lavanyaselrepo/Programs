package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.AppShortcuts;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.SearchItem;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class MainScreenUatTestSet7 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description: Searchbar check for Pharmacies with Pharmacy search preselecfed             
     *              
     * Pre-Conditions: Pharmacy search preselected          
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 72, description = "Searchbar check for Pharmacies with Pharmacy search preselecfed", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet7")
    public void tc_72_Main_Screen_pharmacy_search_by_top_bar_pharmacy_search_preselected(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_pharmacy_search_by_top_bar_pharmacy_search_preselected<<<");

        //Pre-Conditions: Pharmacy search preselected
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PHARMACY, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type Pharmacy Name into search bar | Search Bar should accept
        // user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PHARMACY, inputData);

        // Step 3 Press Enter | Pharmacy seach should appear with data entered
        // into search bar
        connexusStartPage.pressEnterKey();
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PHARMACY, inputData);

        System.out.println("<<<Main_Screen_pharmacy_search_by_top_bar_pharmacy_search_preselected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description: Searchbar check for Pharmacies with Pharmacy Not selected               
     *              
     * Pre-Conditions: Pharmacy search not selected             
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 73, description = "Searchbar check for Pharmacies with Pharmacy Not selected", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet7")
    public void tc_73_Main_Screen_pharmacy_search_by_top_bar_pharmacy_search_not_selected(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_pharmacy_search_by_top_bar_pharmacy_search_not_selected<<<");

        //Pre-Conditions: Pharmacy search not selected        
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PRESCRIBER, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type Pharmacy Name into search bar | Search Bar should accept
        // user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PHARMACY, inputData);

        // Step 3 Select Pharmacy Search from the menu next to the search bar |
        // Pharmacy Search screen should appear with data entered
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PHARMACY, inputData);
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PHARMACY, inputData);

        System.out.println("<<<Main_Screen_pharmacy_search_by_top_bar_pharmacy_search_not_selected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description: Shortcut check for Pharmacy Search               
     *              
     * Pre-Conditions: None           
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 74, description = "Shortcut check for Pharmacy Search", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet7")
    public void tc_74_Main_Screen_pharmacy_search_by_keyboard_shortcut(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_pharmacy_search_by_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL+Shirft+H | Pharmacy Search screen should appear
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.PHARMACY, inputData);
        connexusStartPage.inputShortcutKeys(AppShortcuts.PHARMACY.getAppShortcuts());
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.PHARMACY, inputData);

        System.out.println("<<<Main_Screen_pharmacy_search_by_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:   Searchbar check for searching by Rx number with Rx Search preselected             
     *              
     * Pre-Conditions: Rx Search Preselected            
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 75, description = "Searchbar check for searching by Rx number with Rx Search preselected", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet7")
    public void tc_75_Main_Screen_rx_search_by_top_bar_rx_search_preselected(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_rx_search_by_top_bar_rx_search_preselected<<<");

        //Pre-Conditions: Rx Search Preselected  
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.RX, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type Rx number into search bar | Search bar should accept user
        // input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.RX, inputData);

        // Step 3 Press enter | Rx Search screen should appear with the data
        // entered
        connexusStartPage.pressEnterKey();
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.RX, inputData);

        System.out.println("<<<Main_Screen_rx_search_by_top_bar_rx_search_preselected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description: Searchbar check for searching by Rx number with Rx Search not selected                
     *              
     * Pre-Conditions: Rx Search not selected             
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 76, description = "Searchbar check for searching by Rx number with Rx Search not selected", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet7")
    public void tc_76_Main_Screen_rx_search_by_top_bar_rx_search_not_selected(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_rx_search_by_top_bar_rx_search_not_selected<<<");

        //Pre-Conditions: Rx Search not selected             
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PRESCRIBER, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type Rx number into search bar | Search bar should accept user
        // input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.RX, inputData);

        // Step 3 Select Rx Search from the menu next to the search bar | Rx
        // Search screen should appear with the data entered
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.RX, inputData);
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.RX, inputData);

        System.out.println("<<<Main_Screen_rx_search_by_top_bar_rx_search_not_selected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description: Shortcut check for searching by RX number               
     *              
     * Pre-Conditions: None            
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 77, description = "Shortcut check for searching by RX number", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet7")
    public void tc_77_Main_screen_rx_search_by_1st_keyboard_shortcut(Map<String, String> inputData) {
        System.out.println(">>>Main_screen_rx_search_by_1st_keyboard_shorcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press F7 | Rx Search Screen should appear
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.RX, inputData);
        connexusStartPage.inputShortcutKeys(AppShortcuts.RX.getPrimaryAppShortcuts());
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.RX, inputData);

        System.out.println("<<<Main_screen_rx_search_by_1st_keyboard_shorcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description: Shortcut check for searching by RX number               
     *              
     * Pre-Conditions:None              
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 78, description = "Shortcut check for searching by RX number", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet7")
    public void tc_78_Main_Screen_rx_Seach_by_2nd_keyboard_shortcut(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_rx_Seach_by_2nd_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + Shift + R | Rx Search Screen should appear
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.RX, inputData);
        connexusStartPage.inputShortcutKeys(AppShortcuts.RX.getAppShortcuts());
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.RX, inputData);

        System.out.println("<<<Main_Screen_rx_Seach_by_2nd_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description: Searchbar check for searching using Order Search with order search preselected                
     *              
     * Pre-Conditions:Order Search Preselected              
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 79, description = "Searchbar check for searching using Order Search with order search preselected", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet7")
    public void tc_79_Main_Screen_order_search_by_top_bar_order_search_preselected(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_order_search_by_top_bar_order_search_preselected<<<");

        //Pre-Conditions:Order Search Preselected
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.ORDER, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type Paitent info or RX number into search bar | Search Bar
        // should accept user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.ORDER, inputData);
        // Step 3 Press enter | Rx Search screen should appear with the data
        // entered
        connexusStartPage.pressEnterKey();
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.ORDER, inputData);

        System.out.println("<<<Main_Screen_order_search_by_top_bar_order_search_preselected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description: Searchbar check for searching using Order Search with order search not selected                
     *              
     * Pre-Conditions: Order search not selected             
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 80, description = "Searchbar check for searching using Order Search with order search not selected", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet7")
    public void tc_80_Main_Screen_order_search_by_top_bar_order_search_not_selected(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_order_search_by_top_bar_order_search_not_selected<<<");

        //Pre-Conditions: Order search not selected         
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PRESCRIBER, inputData);
        connexusStartPage.pressEscapeKey();

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Type Paitent info or RX number into search bar | Search Bar
        // should accept user input
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.ORDER, inputData);
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.ORDER, inputData);

        // Step 3 Select Rx Search from the menu next to the search bar | Rx
        // Search screen should appear with the data entered
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.ORDER, inputData);

        System.out.println("<<<Main_Screen_order_search_by_top_bar_order_search_not_selected>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description: Shortcut check for searching using Order Search               
     *              
     * Pre-Conditions: None             
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 81, description = "Shortcut check for searching using Order Search", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet7")
    public void tc_81_Main_Screen_order_search_by_1st_keyboard_shortcut(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_order_search_by_1st_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press F6 | Order search sceen should appear
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.ORDER, inputData);
        connexusStartPage.inputShortcutKeys(AppShortcuts.ORDER.getPrimaryAppShortcuts());
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.ORDER, inputData);

        System.out.println("<<<Main_Screen_order_search_by_1st_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description: Shortcut check for searching using Order Search             
     *              
     * Pre-Conditions: None             
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 82, description = "Shortcut check for searching using Order Search", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet7")
    public void tc_82_Main_Screen_order_search_by_2nd_keyboard_shortcut(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_order_search_by_2nd_keyboard_shortcut<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Press CTRL + Shift + O | Order search sceen should appear
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.ORDER, inputData);
        connexusStartPage.inputShortcutKeys(AppShortcuts.ORDER.getAppShortcuts());
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.ORDER, inputData);

        System.out.println("<<<Main_Screen_order_search_by_2nd_keyboard_shortcut>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description: Menu check for Order searches               
     *              
     * Pre-Conditions: None             
     *              
     * Author: Ashok(Vn50h3h)                
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 83, description = "Menu check for Order searches", dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/UatTest/DataSheet.json", sheetName = "MainScreenUatTestSet7")
    public void tc_83_Main_Screen_order_search_by_menu(Map<String, String> inputData) {
        System.out.println(">>>Main_Screen_order_search_by_menu<<<");

        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Click the search menu at the top of the sceen then click Order
        // | Order search sceen should appear
        mainScreenUatTestScripts.selectMenuItemInDropDownNextToSearchBar(SearchItem.PRESCRIBER, inputData);
        connexusStartPage.pressEscapeKey();
        mainScreenUatTestScripts.enterSearchTextIntoSearchBar(SearchItem.ORDER, inputData);
        mainScreenUatTestScripts.menuNavigationToOpenOrderSearchScreen();
        mainScreenUatTestScripts.validateSearchBarTextPresentInSearchScreen(SearchItem.ORDER, inputData);

        System.out.println("<<<Main_Screen_order_search_by_menu>>>");
    }


}
