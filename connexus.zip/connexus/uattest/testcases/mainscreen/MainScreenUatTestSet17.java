package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainScreenUatTestSet17 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;
    MenuBar menuBar;
    AutomationManager automationManager;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        AutomationManager.getInstance().performSleep(10);
        connexusAppUtils.startAppiumServer();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        automationManager = AutomationManager.getInstance();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }


    /*----------------------------------------------------------------------------------------------------------
     * Test Description:"Access check for the Regulatory Patient Profile Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 222)
    public void tc_222_Main_Screen_Reports_Pharmacist_Reports_Regulatory_Patient_Profile_Report() {
        System.out.println(">>>tc_222_Main_Screen_Reports_Pharmacist_Reports_Regulatory_Patient_Profile_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pharmacist Reports -> Regulatory Patient
        // Profile Report | Regulatory Patient Profile Report screen should
        // appear"
        menuBar.selectNavigation(AppMenu.REGULATORY_PATIENT_PROFILE_REPORT, AppMenuItemsIndex.PHARMACIST_REPORTS,AppMenuSubItemsIndex.REGULATORY_PATIENT_PROFILE_REPORT,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.REGULATORY_PATIENT_PROFILE_REPORT);

        System.out.println("<<<tc_222_Main_Screen_Reports_Pharmacist_Reports_Regulatory_Patient_Profile_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for the Pharmacist Activity Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1822")
    @Test(priority = 223)
    public void HWPHME2E_1822_Main_Screen_Reports_Pharmacist_Reports_Pharmacist_Activity_Report() {
        Reporter.log("Validating pharmacist activity report under pharmacist report");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pharmacist Reports -> Pharmacist Activity
        // Report | Pharmacist Activity Report screen should appear"
        connexusAppUtils.getStoreId();
        menuBar.selectNavigation(AppMenu.PHARMACIST_ACTIVITY_REPORT, AppMenuItemsIndex.PHARMACIST_REPORTS,AppMenuSubItemsIndex.PHARMACIST_ACTIVITY_REPORT,null);
        mainScreenUatTestScripts.validatePharmacistActivityReport(SearchItem.PHARMACIST_ACTIVITY_REPORT);

        Reporter.log("Pharmacist activity report should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Auto Capture - Auto Counsel report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 224)
    public void tc_224_Main_Screen_Reports_Pickup_POS_Reports_Auto_Capture_Auto_Cancel() {
        System.out.println(">>>tc_224_Main_Screen_Reports_Pickup_POS_Reports_Auto_Capture_Auto_Cancel<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pickup/POS Reports -> Auto Capture - Auto
        // Cancel | Auto Capture - Auto Counsel report selection pop up should
        // appear"
        menuBar.selectNavigation(AppMenu.AUTO_CAPTURE_AUTO_CANCEL, AppMenuItemsIndex.PICKUP_POS_REPORTS,AppMenuSubItemsIndex.AUTO_CAPTURE_AUTO_CANCEL,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.AUTO_CAPTURE_AUTO_CANCEL);

        System.out.println("<<<tc_224_Main_Screen_Reports_Pickup_POS_Reports_Auto_Capture_Auto_Cancel>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Will Call Bin Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 225)
    public void tc_225_Main_Screen_Reports_Pickup_POS_Reports_Will_Call_Bin_Report() {
        System.out.println(">>>tc_225_Main_Screen_Reports_Pickup_POS_Reports_Will_Call_Bin_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pickup/POS Reports -> Will Call Bin Report |
        // Will Call Bin Report screen should appear"
        menuBar.navigateToMenu(AppMenu.WILL_CALL_BIN_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.WILL_CALL_BIN_REPORT);

        System.out.println("<<<tc_225_Main_Screen_Reports_Pickup_POS_Reports_Will_Call_Bin_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Bagging Detail Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 226)
    public void tc_226_Main_Screen_Reports_Pickup_POS_Reports_Bagging_Detail_Report() {
        System.out.println(">>>tc_226_Main_Screen_Reports_Pickup_POS_Reports_Bagging_Detail_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pickup/POS Reports -> Bagging Detail Report
        // | Bagging Detail Report screen should appear"
        menuBar.navigateToMenu(AppMenu.BAGGING_DETAILS_REPORT);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.BAGGING_DETAILS_REPORT);

        System.out.println("<<<tc_226_Main_Screen_Reports_Pickup_POS_Reports_Bagging_Detail_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for POS Pending Action Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 227)
    public void tc_227_Main_Screen_Reports_Pickup_POS_Reports_POS_Pending_Action_Report() {
        System.out.println(">>>tc_227_Main_Screen_Reports_Pickup_POS_Reports_POS_Pending_Action_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pickup/POS Reports -> POS Pending Action
        // Report | POS Pending Action Report should appear"
        menuBar.selectNavigation(AppMenu.POS_PENDING_ACTION_REPORT, AppMenuItemsIndex.PICKUP_POS_REPORTS,AppMenuSubItemsIndex.POS_PENDING_ACTION_REQUIRED,null);
        mainScreenUatTestScripts.validateReportScreenFor(SearchItem.POS_PENDING_ACTION_REPORT);

        System.out.println("<<<tc_227_Main_Screen_Reports_Pickup_POS_Reports_POS_Pending_Action_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for  POS Discrepancy Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 228)
    public void tc_228_Main_Screen_Reports_Pickup_POS_Reports_POS_Discrepancy() {
        System.out.println(">>>tc_228_Main_Screen_Reports_Pickup_POS_Reports_POS_Discrepancy<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pickup/POS Reports -> POS Discrepancy | POS
        // Discrepancy Report date selection popup should appear"
        menuBar.selectNavigation(AppMenu.POS_DISCREPANCY, AppMenuItemsIndex.PICKUP_POS_REPORTS,AppMenuSubItemsIndex.POS_DISCREPANCY,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.POS_DISCREPANCY);

        System.out.println("<<<tc_228_Main_Screen_Reports_Pickup_POS_Reports_POS_Discrepancy>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for  Local T/P and Charge by reg acct. xxx report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 229)
    public void tc_229_Main_Screen_Reports_Pickup_POS_Reports_Daily_Register_Reports_Local_TP_and_Charge_by_reg_acct_xxx() {
        System.out.println(">>>tc_229_Main_Screen_Reports_Pickup_POS_Reports_Daily_Register_Reports_Local_TP_and_Charge_by_reg_acct_xxx<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pickup/POS Reports -> Daily Register Reports
        // -> Local T/P and Charge by reg acct. xxx | Local T/P and Charge by
        // reg acct. xxx report date selection popup should appear"
        menuBar.selectNavigation(AppMenu.LOCAL_TP_AND_CHARGE_BY_REG_ACCT_XXX, AppMenuItemsIndex.PICKUP_POS_REPORTS,AppMenuSubItemsIndex.DAILY_REGISTER_REPORTS,AppMenuSuperSubItemsIndex.LOCAL_TP_AND_CHARGE_BY_REG_ACCT);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.LOCAL_TP_AND_CHARGE_BY_REG_ACCT_XXX);

        System.out.println("<<<tc_229_Main_Screen_Reports_Pickup_POS_Reports_Daily_Register_Reports_Local_TP_and_Charge_by_reg_acct_xxx>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for   T/P Recievables by Reg. Acct. xxx report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 230)
    public void tc_230_Main_Screen_Reports_Pickup_POS_Reports_Daily_Register_Reports_TP_Recievables_by_Reg_Acct_xxx() {
        System.out.println(">>>tc_230_Main_Screen_Reports_Pickup_POS_Reports_Daily_Register_Reports_TP_Recievables_by_Reg_Acct_xxx<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pickup/POS Reports -> Daily Register Reports
        // -> T/P Recievables by Reg. Acct. xxx | T/P Recievables by Reg. Acct.
        // xxx report date selection popup should appear"
        menuBar.selectNavigation(AppMenu.TP_RECEIVABLE_BY_REG_ACCT_XXX, AppMenuItemsIndex.PICKUP_POS_REPORTS,AppMenuSubItemsIndex.DAILY_REGISTER_REPORTS,AppMenuSuperSubItemsIndex.TP_RECEIVABLES_BYREG_ACCT);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.TP_RECEIVABLE_BY_REG_ACCT_XXX);

        System.out.println("<<<tc_230_Main_Screen_Reports_Pickup_POS_Reports_Daily_Register_Reports_TP_Recievables_by_Reg_Acct_xxx>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Cancel Fill Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 231)
    public void tc_231_Main_Screen_Reports_RX_Reports_Cancel_Fill_Report() {
        System.out.println(">>>tc_231_Main_Screen_Reports_RX_Reports_Cancel_Fill_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Cancel Fill Report | Cancel
        // Fill report date selection pop-up should appear"
        menuBar.selectNavigation(AppMenu.CANCEL_FILL_REPORT, AppMenuItemsIndex.RX_REPORTS,AppMenuSubItemsIndex.CANCEL_FILL_REPORT,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.CANCEL_FILL_REPORT);

        System.out.println("<<<tc_231_Main_Screen_Reports_RX_Reports_Cancel_Fill_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Rx Shipment Tracking report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 232)
    public void tc_232_Main_Screen_Reports_RX_Reports_Rx_Shipment_Tracking() {
        System.out.println(">>>tc_232_Main_Screen_Reports_RX_Reports_Rx_Shipment_Tracking<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Rx Shipment Tracking | Rx
        // Shipment Tracking screen should appear"
        menuBar.navigateToMenu(AppMenu.RX_SHIPMENT_TRACKING);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.RX_SHIPMENT_TRACKING);

        System.out.println("<<<tc_232_Main_Screen_Reports_RX_Reports_Rx_Shipment_Tracking>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Auto-Fill Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 233)
    public void tc_233_Main_Screen_Reports_RX_Reports_Auto_Fill_Report() {
        System.out.println(">>>tc_233_Main_Screen_Reports_RX_Reports_Auto_Fill_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Auto-Fill Report | Auto-Fill
        // Report screen should appear"
        menuBar.selectNavigation(AppMenu.AUTO_FILL_REPORT, AppMenuItemsIndex.RX_REPORTS,AppMenuSubItemsIndex.AUTO_REFILL_REPORT,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.AUTO_FILL_REPORT);

        System.out.println("<<<tc_233_Main_Screen_Reports_RX_Reports_Auto_Fill_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Compliance Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 234)
    public void tc_234_Main_Screen_Reports_RX_Reports_Compliance_Report() {
        System.out.println(">>>tc_234_Main_Screen_Reports_RX_Reports_Compliance_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> Compliance Report | Compliance
        // Report date selection pop up should appear"
        menuBar.selectNavigation(AppMenu.COMPLIANCE_REPORT, AppMenuItemsIndex.RX_REPORTS,AppMenuSubItemsIndex.COMPLIANCE_REPORT,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.COMPLIANCE_REPORT);

        System.out.println("<<<tc_234_Main_Screen_Reports_RX_Reports_Compliance_Report>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for DUR Override Summary"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 235)
    public void tc_235_Main_Screen_Reports_RX_Reports_DUR_Override_Summary() {
        System.out.println(">>>tc_235_Main_Screen_Reports_RX_Reports_DUR_Override_Summary<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> DUR Override Summary | DUR
        // Override Summary date selection pop up should appear"
        menuBar.selectNavigation(AppMenu.DUR_OVERRIDE_SUMMARY, AppMenuItemsIndex.RX_REPORTS,AppMenuSubItemsIndex.DUR_OVERRIDE_SUMMARY,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.DUR_OVERRIDE_SUMMARY);

        System.out.println("<<<tc_235_Main_Screen_Reports_RX_Reports_DUR_Override_Summary>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for On Hold Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 236)
    public void tc_236_Main_Screen_Reports_RX_Reports_On_Hold_Report() {
        System.out.println(">>>tc_236_Main_Screen_Reports_RX_Reports_On_Hold_Report<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> RX Reports -> On Hold Report | On Hold
        // Report date selection pop up should appear"
        menuBar.selectNavigation(AppMenu.ON_HOLD_REPORT, AppMenuItemsIndex.RX_REPORTS,AppMenuSubItemsIndex.ON_HOLE_REPORT,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.ON_HOLD_REPORT);

        System.out.println("<<<tc_236_Main_Screen_Reports_RX_Reports_On_Hold_Report>>>");
    }
}
