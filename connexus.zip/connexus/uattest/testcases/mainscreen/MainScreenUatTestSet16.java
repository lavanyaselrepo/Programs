package connexus.uattest.testcases.mainscreen;

import connexus.uattest.testscripts.MainScreenUatTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.ConnexusStartPage;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainScreenUatTestSet16 {
    MainScreenUatTestScripts mainScreenUatTestScripts;
    ConnexusAppUtils connexusAppUtils;
    ConnexusStartPage connexusStartPage;
    MenuBar menuBar;
    AutomationManager automationManager;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        AutomationManager.getInstance().performSleep(10);
        connexusAppUtils.startAppiumServer();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        automationManager = AutomationManager.getInstance();
    }

    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Accounding of Disclosure"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1824")
    @Test(priority = 207)
    public void HWPHME2E_1824_Main_Screen_Reports_HIPPA_Accounting_of_Disclosure() {
        Reporter.log("Validating Accounting of disclosure report page under HIPPA");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> HIPPA -> Accounting of Disclosure | The
        // HIPPA - accounting of disclosure screen should appear"
        connexusAppUtils.getStoreId();
        mainScreenUatTestScripts.selectNavigation(AppMenu.HIPAA_ACCOUNTING_OF_DISCLOSURE, AppMenuItemsIndex.HIPPA,AppMenuSubItemsIndex.ACCOUNTING_OF_DISCLOSURE);
        mainScreenUatTestScripts.ValidatefunctionalreportforHippaReport(SearchItem.HIPAA_ACCOUNTING_OF_DISCLOSURE);
        Reporter.log("Accounting of disclosure report page should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Designated Recordset Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1825")
    @Test(priority = 208)
    public void HWPHME2E_1825_Main_Screen_Reports_HIPPA_Designated_Recordset_Report() {
        Reporter.log("Validating designated recordset report page under HIPPA");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> HIPPA -> Designated Recordset Report | The
        // HIPPA - Designated Recordset Report screen should appear"
        connexusAppUtils.getStoreId();
        mainScreenUatTestScripts.selectNavigation(AppMenu.HIPAA_DESIGNATED_RECORDSET_REPORT, AppMenuItemsIndex.HIPPA,AppMenuSubItemsIndex.DESIGNATED_RECORDSET_REPORT);
        mainScreenUatTestScripts.ValidatefunctionalreportforHippaReport(SearchItem.HIPAA_DESIGNATED_RECORDSET_REPORT);
        Reporter.log("Designated recordset report page should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for HIPPA Inspection Log"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
      ----------------------------------
      * ------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1826")
    @Test(priority = 212)
    public void HWPHME2E_1826_Main_Screen_Reports_HIPPA_HIPPA_Inspection_Log() {
        Reporter.log("Validating HIPPA inspection log report page under HIPPA");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> HIPPA -> HIPPA Inspection Log | The HIPPA -
        // HIPPA Inspection Log screen should appear"
        connexusAppUtils.getStoreId();
        mainScreenUatTestScripts.selectNavigation(AppMenu.HIPAA_INSPECTION_LOG, AppMenuItemsIndex.HIPPA,AppMenuSubItemsIndex.HIPPA_INSPECTION_LOG);
        mainScreenUatTestScripts.ValidateHippaInspectionLogReport(SearchItem.HIPAA_INSPECTION_LOG);

        Reporter.log("HIPPA inspection log report page should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Insurance Auditing"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 210)
    public void tc_210_Main_Screen_Reports_HIPPA_Insurance_Auditing() {
        System.out.println(">>>tc_210_Main_Screen_Reports_HIPPA_Insurance_Auditing<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> HIPPA -> Insurance Auditing | The Insurance
        // Auditing screen should appear"
        menuBar.selectNavigation(AppMenu.HIPAA_INSURANCE_AUDITING, AppMenuItemsIndex.HIPPA,AppMenuSubItemsIndex.INSURANCE_AUDITING,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.HIPAA_INSURANCE_AUDITING);

        System.out.println("<<<tc_210_Main_Screen_Reports_HIPPA_Insurance_Auditing>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Medical Expense Summarys"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1827")
    @Test(priority = 211)
    public void HWPHME2E_1827_Main_Screen_Reports_HIPPA_Medical_Expense_Summary() {
        Reporter.log("validating medical expense summary report page under HIPPA");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> HIPPA -> Medical Expense Summary | Medical
        // Expense screen should appear"
        connexusAppUtils.getStoreId();
        mainScreenUatTestScripts.selectNavigation(AppMenu.HIPAA_MEDICAL_EXPENSE_SUMMARY, AppMenuItemsIndex.HIPPA,AppMenuSubItemsIndex.MEDICAL_EXPENSE_SUMMARY);
        mainScreenUatTestScripts.ValidatefunctionalreportforHippaReport(SearchItem.HIPAA_MEDICAL_EXPENSE_SUMMARY);

        Reporter.log("Medical expense summary report page should be displayed");
    }


    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for HIPPA Records Request"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
      ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1828")
    @Test(priority = 209)
    public void HWPHME2E_1828_Main_Screen_Reports_HIPPA_HIPPA_Records_Request() {
        Reporter.log("Validating HIPPA record request report page under HIPPA");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> HIPPA -> HIPPA Records Request | HIPPA
        // Records Request screen should appear"
        connexusAppUtils.getStoreId();
        mainScreenUatTestScripts.selectNavigation(AppMenu.HIPAA_RECORDS_REQUEST, AppMenuItemsIndex.HIPPA,AppMenuSubItemsIndex.HIPPA_RECORDS_REQUEST);
        mainScreenUatTestScripts.ValidateHippaRecordsRequestReport(SearchItem.HIPAA_RECORDS_REQUEST);

        Reporter.log("HIPPA record request report page should be displayed");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for  Daily 4Point Check"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 213)
    public void tc_213_Main_Screen_Reports_Pharmacist_Reports_Daily_4Point_Check() {
        System.out.println(">>>tc_213_Main_Screen_Reports_Pharmacist_Reports_Daily_4Point_Check<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pharmacist Reports -> Daily 4Point Check |
        // Daily 4point check report screen should appear"
        menuBar.selectNavigation(AppMenu.DAILY_4POINT_CHECK, AppMenuItemsIndex.PHARMACIST_REPORTS,AppMenuSubItemsIndex.DAILY_FOUR_POINT_CHECK,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.DAILY_4POINT_CHECK);

        System.out.println("<<<tc_213_Main_Screen_Reports_Pharmacist_Reports_Daily_4Point_Check>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for  Daily VisualVerify Check"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 214)
    public void tc_214_Main_Screen_Reports_Pharmacist_Reports_Daily_VisualVerify_Check() {
        System.out.println(">>>tc_214_Main_Screen_Reports_Pharmacist_Reports_Daily_VisualVerify_Check<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pharmacist Reports -> Daily VisualVerify
        // Check | Daily VisualVerify Check report screen should appear"
        menuBar.selectNavigation(AppMenu.DAILY_4POINT_CHECK, AppMenuItemsIndex.PHARMACIST_REPORTS,AppMenuSubItemsIndex.DAILY_VISUAL_VERIFY_CHECK,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.DAILY_VISUALVERIFY_CHECK);

        System.out.println("<<<tc_214_Main_Screen_Reports_Pharmacist_Reports_Daily_VisualVerify_Check>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Online Incident Reporting"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
     *               
     * ***NON AUTOMATABLE SCENARIO*** keeping the test for reporting purpose 
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 215)
    public void tc_215_Main_Screen_Reports_Pharmacist_Reports_Online_Incident_Reporting() {
        System.out.println(">>>tc_215_Main_Screen_Reports_Pharmacist_Reports_Online_Incident_Reporting<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pharmacist Reports -> Online Incident
        // Reporting | Connexus should open the Online Incident Reporting
        // webpage in Chrome"
        mainScreenUatTestScripts.nonAutomateScenario();// browser launch by application

        System.out.println("<<<tc_215_Main_Screen_Reports_Pharmacist_Reports_Online_Incident_Reporting>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for Patient Counsel Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 216)
    public void tc_216_Main_Screen_Reports_Pharmacist_Reports_Counseling() {
        System.out.println(">>>tc_216_Main_Screen_Reports_Pharmacist_Reports_Counseling<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pharmacist Reports -> Counseling | Patient
        // Counsel report screen should appear"
        menuBar.selectNavigation(AppMenu.PHARMACIST_REPORTS_COUNSELING, AppMenuItemsIndex.PHARMACIST_REPORTS,AppMenuSubItemsIndex.COUNSELLING,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.PHARMACIST_REPORTS_COUNSELING);

        System.out.println("<<<tc_216_Main_Screen_Reports_Pharmacist_Reports_Counseling>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for the incorrect input entries Report"
     *              
     * Pre-Conditions:"RPH Login (not homeoffice)"
     *              
     * Author: Ashok(Vn50h3h)  
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 217)
    public void tc_217_Main_Screen_Reports_Pharmacist_Reports_Input_Incorrect_Entries() {
        System.out.println(">>>tc_217_Main_Screen_Reports_Pharmacist_Reports_Input_Incorrect_Entries<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pharmacist Reports -> Input - Incorrect
        // Entries | Input - Incorrect Entries report screen should appear"
        tearDown();
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        menuBar.selectNavigation(AppMenu.INPUT_INCORRECT_ENTRIES, AppMenuItemsIndex.PHARMACIST_REPORTS,AppMenuSubItemsIndex.INPUT_INCORRECT_ENTRIES,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.INPUT_INCORRECT_ENTRIES);

        System.out.println("<<<tc_217_Main_Screen_Reports_Pharmacist_Reports_Input_Incorrect_Entries>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for the incorrect input entries Report"
     *              
     * Pre-Conditions:"Tech Login (not homeoffice)"
     *              
     * Author: Ashok(Vn50h3h)  
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 218)
    public void HWPHME2E_1249_Validate_Input_Incorrect_Entries_Option_Should_Not_Available_For_Technician() {
        Reporter.log("Validating Incorrect entries option should not be available for technician login by opening all sub menu options for Pharmacist reports under Reports menu");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pharmacist Reports -> Input - Incorrect
        // Entries | Input - Incorrect Entries report screen should be grayed
        // out/not show"
       // tearDown();
        connexusAppUtils.getStoreId();
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();

        mainScreenUatTestScripts.validateIncorrectEntriesAndFourPtRphOptionNotAvailableForTechnicianLogin(AppMenu.INPUT_INCORRECT_ENTRIES, AppMenuItemsIndex.PHARMACIST_REPORTS, SearchItem.INPUT_INCORRECT_ENTRIES);

        Reporter.log("<<<Validating Incorrect entries option should not be available for technician login by opening all sub menu options for Pharmacist reports under Reports menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for the input entries corrected by the RPH at 4PT Report"
     *              
     * Pre-Conditions:"RPH Login (not homeoffice)"
     *              
     * Author: Ashok(Vn50h3h)  
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 219)
    public void tc_219_Main_Screen_Reports_Pharmacist_Reports_4PT_RPH_Corrections() {
        System.out.println(">>>tc_219_Main_Screen_Reports_Pharmacist_Reports_4PT_RPH_Corrections<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pharmacist Reports -> 4PT - RPH Corrections
        // | 4PT - RPH Corrections report screen should appear"
        tearDown();
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        menuBar.selectNavigation(AppMenu.FOURPOINT_RPH_CORRECTIONS, AppMenuItemsIndex.PHARMACIST_REPORTS,AppMenuSubItemsIndex.FOUR_PT_RPH_CORRECTIONS,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.FOURPOINT_RPH_CORRECTIONS);

        System.out.println("<<<tc_219_Main_Screen_Reports_Pharmacist_Reports_4PT_RPH_Corrections>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for the input entries corrected by the RPH at 4PT Report"
     *              
     * Pre-Conditions:"Tech Login (not homeoffice)"
     *              
     * Author: Ashok(Vn50h3h)  
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 220)
    public void HWPHME2E_1250_Validate_4PT_RPH_Corrections_Option_Should_Not_Available_For_Technician() {
        Reporter.log("Validating 4PT RPH Corrections option should not be available for technician login by opening all sub menu options for Pharmacist reports under Reports menu");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pharmacist Reports -> 4PT - RPH Corrections
        // | 4PT - RPH Corrections report screen should be grayed out/not
        // show"
       // tearDown();
        connexusAppUtils.getStoreId();
        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();

        mainScreenUatTestScripts.validateIncorrectEntriesAndFourPtRphOptionNotAvailableForTechnicianLogin(AppMenu.FOURPOINT_RPH_CORRECTIONS, AppMenuItemsIndex.PHARMACIST_REPORTS, SearchItem.FOURPOINT_RPH_CORRECTIONS);

        Reporter.log("<<<Validating 4PT RPH Corrections option should not be available for technician login by opening all sub menu options for Pharmacist reports under Reports menu>>>");
    }

    /*----------------------------------------------------------------------------------------------------------                
     * Test Description:"Access check for the User Name and ID Report"
     *              
     * Pre-Conditions:"None"
     *              
     * Author: Ashok(Vn50h3h)  
      ----------------------------------------------------------------------------------------------------------*/
    @Test(priority = 221)
    public void tc_221_Main_Screen_Reports_Pharmacist_Reports_User_Name_and_ID() {
        System.out.println(">>>tc_221_Main_Screen_Reports_Pharmacist_Reports_User_Name_and_ID<<<");
        // Step 1 Log in to Connexus | Connexus should bring up main screen
        // Step 2 Select Reports -> Pharmacist Reports -> User Name and ID |
        // User Name and ID report screen should appear"
        tearDown();

        connexusAppUtils = new ConnexusAppUtils();
        mainScreenUatTestScripts = new MainScreenUatTestScripts();
        mainScreenUatTestScripts.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        mainScreenUatTestScripts.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusStartPage = new ConnexusStartPage();
        menuBar = new MenuBar();
        menuBar.selectNavigation(AppMenu.USER_NAME_AND_ID, AppMenuItemsIndex.PHARMACIST_REPORTS,AppMenuSubItemsIndex.USER_NAMES_AND_ID,null);
        mainScreenUatTestScripts.validateFunctionalScreenFor(SearchItem.USER_NAME_AND_ID);

        System.out.println("<<<tc_221_Main_Screen_Reports_Pharmacist_Reports_User_Name_and_ID>>>");
    }
}
