package connexus.CommonTools.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.joda.time.DateTime;
import org.testng.Assert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.sql.Timestamp;
import java.util.*;
import java.util.List;

public class CommonToolsTestScripts  extends ConnexusTestScripts {

    ReportPage reportPage;
    String totalPatPay;
    int patientId;
    Timestamp inputTimestamp;
    Timestamp actualTimeStamp;
    String initialDispenseType;
    String initialPriority;
    int numRefills;
    InputResponse inputResp = new InputResponse();

    PropertyReader prop = PropertyReader.getInstance();
    int siteId = Integer.parseInt(prop.getProperty("cnx.store"));

    public CommonToolsTestScripts(LoginAs.userType loginUserType) {
        super(loginUserType);
    }

    public void validate4pointForPaymentRequired(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1],0);

            if(checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(),ConnexusConstants.WAIT_TIMEOUT_60)) {
                connexusAppUtils.writeTextToFile("RX is in 4 point "+rxNbr,"In progress",fileName,40, DateTime.now());
            } else {
                connexusAppUtils.writeTextToFile("RX is not in 4 point "+rxNbr,"In progress",fileName,40, DateTime.now());
                Reporter.log("RX is not in 4 Point, Performing Resolve Queue");
                performResolveQueue(name[0] + "," + name[1]);
            }

            if(checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(),ConnexusConstants.WAIT_TIMEOUT_60)) {
                rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1], inputData, false,true);
                connexusAppUtils.writeTextToFile("4 point Completed " + rxNbr, "In progress", fileName, 40, DateTime.now());
            }
            else {
                connexusAppUtils.writeTextToFile("4 point not Completed "+rxNbr,"Failed",fileName,40, DateTime.now());
                Assert.fail("Rx failed to reach 4 point");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("4 point not Completed "+rxNbr,"Failed",fileName,40, DateTime.now());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to complete 4point check");
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void chkdurCmtsValidations(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())){
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                if (chkDur.clickRedFlagsBtn()) {
                    chkDur.selectResolvedCheckBoxes();
                    chkDur.clickDurBtn();
                }
                if (!chkDur.clickClearConflictsBtn()) {
                    chkDur.selectAllCheckBoxes();
                }
                Reporter.logScreenShot(Status.INFO, "Screenshot of ChkDUR Page", chkDur.takeScreenShot("ChkDUR").getValue());
                //Validating comments present in chkdur screen
                List<String> chkDurMessages = chkDur.getDurMessagesText();
                Reporter.log("Captured DUR Conflict Descriptions:\n" + String.join("\n⬤ ", chkDurMessages).replaceFirst("^", "⬤"));
                chkDur.clickAccept();
                chkDur.clickConnexusOk();
                Reporter.log("ChkDUR completed");
            } else {
                Reporter.log("rx is not in Dur queue");
                Assert.fail("rx is not in Dur queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed without validating chkdur messages");
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, counselPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyDetailsINConflictTable() {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);

        String query = "SELECT rod.rx_id FROM rx_order_detail rod,rx rx where rod.rx_id=rx.rx_id and rx.rx_nbr = '" + rxNbr + "' order by order_id desc limit 1 ";
        List<Map<String, Object>> order = automationManager.getConnexusDB(siteId).executeQueryForList(query);
        int rxId = (Integer) order.get(0).get("rx_id");
        System.out.println("rxId : " + rxId);

        String query1 = "Select resolution_userid,conflict_ts FROM rx21c:informix.rx_conflict where rx_id = " + rxId;
        List<Map<String, Object>> results = automationManager.getConnexusDB(siteId).executeQueryForList(query1);
        String resolution_userid = (String) results.get(0).get("resolution_userid");
        Timestamp timestamp = (Timestamp) results.get(0).get("conflict_ts");
        String conflict_ts = timestamp.toString();
        Reporter.log(" Resolution user id is :" + resolution_userid);
        Reporter.log("Conflict Time Stamp is :" + conflict_ts);
    }

    public void performTascoPickUpValidation(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Pickup.getValue())) {
                automationManager.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("DOB"), rxNbr , false, true);
            } else {
                performResolveQueue(rxNbr);
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Pickup.getValue())) {
                    automationManager.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("DOB"), rxNbr , false,true);
                }else {
                    Reporter.log("RX is not in PickUp queue");
                    takeScreenShotRXStatus(rxNbr,null,currentStepMethodName + ", review the Work Queue status",Status.FAIL);
                    Assert.fail("RX is not in PickUp queue");
                }
            }
            connexusAppUtils.writeTextToFile("Pickup Completed "+rxNbr,"In progress",fileName,80, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Pickup not Completed "+rxNbr,"Failed",fileName,80, DateTime.now());
            Reporter.log("Test failed at PickUp queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void validatingChkdurCmtsInCounselQueue(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.Counseling.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                List<String> CounselDurMsg = counselPage.getCounselDurMsg(); //Missing validation
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, counselPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("DUR Messages are : " + CounselDurMsg);
                orderSearch.clickCancel();
            }

        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Counselling validation Not Completed "+rxNbr,"Failed",fileName,90, DateTime.now());
            Reporter.log("Test failed at Counselling queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, counselPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void getDurOverrideSummaryReport() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try{
            reportPage = new ReportPage();
            menuBar.selectNavigation(AppMenu.DUR_OVERRIDE_SUMMARY, AppMenuItemsIndex.RX_REPORTS,AppMenuSubItemsIndex.DUR_OVERRIDE_SUMMARY,null);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            reportPage.setDateAndClickShowReport(rxNbr);
            Assert.assertTrue(reportPage.waitForReportToLoad(),"DUR Override Report did not load successfully.");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(reportPage.validateDURMessageInReport(),"DUR Message is not displayed/Matching in the report.");
            reportPage.clickCancel();

        } catch (Exception e) {
            isExceptionCaptured = true;
            throw new RuntimeException(e);
        }
    }
    public void openProductSearchWindow(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            productSearchPage.launchProductSearchScreen();
            productSearchPage.enterProductName(inputData.get("DRUG_NAME"));
            productSearchPage.clickSearchNow();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.doubleClickOnSearchGridRow(0);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateProductMaintenanceData(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Map<String, Boolean> elementConditions = productMaintenancePage.checkforAllFields();
            for (Map.Entry<String, Boolean> entry : elementConditions.entrySet()) {
                if (entry.getValue()) {
                    Reporter.log(entry.getKey() + " is displayed.");
                } else {
                    Reporter.log(entry.getKey() + " is NOT displayed.");
                    Assert.fail(entry.getKey() + " is NOT displayed.");
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void updateProductMaintenanceData(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String UOM = inputData.get("MEASUREMENT");
            Reporter.log("UOM to be selected: " + UOM);
            productMaintenancePage.selectUOMFromDropdown(UOM);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            String form = inputData.get("FORM");
            Reporter.log("Form to be selected: " + form);
            productMaintenancePage.selectFormFromDropdown(form);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productMaintenancePage.clickAccept();
            Reporter.log("Product Maintenance data updated successfully.");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void checkProductMaintenanceNoteButtons(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            productMaintenancePage.clickNotesButton();
            String comments = inputData.get("COMMENTS");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productMaintenancePage.validateAndEnterNoteComment(comments);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productMaintenancePage.clickAccept();
            productMaintenancePage.clickNotesButton();
            productMaintenancePage.validateAndAssertNoteHistory(comments);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productMaintenancePage.clickAccept();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void checkPatientEducationButtonsandLeaflets(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            productMaintenancePage.clickPatientEducationButton();
            productMaintenancePage.checkForPatientEducationDetails();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productMaintenancePage.validatePatientMedicationLeaflets(ConnexusConstants.PATIENTEDUCATIONTEXTDETAILS);
            productMaintenancePage.clickCancelBtn();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void validateProductMaintenanceDataAfterUpdate(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            this.openProductSearchWindow(inputData);
            Reporter.log("Product Search window opened successfully for validating updated data.");
            String UOM = inputData.get("MEASUREMENT");
            String form= inputData.get("FORM");
            String UOMValue=productMaintenancePage.getUOMText();
            String formValue=productMaintenancePage.getFormText();
            Assert.assertEquals(UOMValue, UOM, "UOM value is not updated correctly");
            Assert.assertEquals(formValue, form, "Form value is not updated correctly");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Product Maintenance data validated successfully after update.");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateValueofDEA() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String DEAValue = productMaintenancePage.getDEAValue();
            Reporter.log("DEA Value is: " + DEAValue);
            Assert.assertTrue(DEAValue != null && !DEAValue.isEmpty(), "DEA Class is not displayed or is empty.");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            String isEnabled = productMaintenancePage.isDEAEnabled();
            Reporter.log("DEA Class field is enabled: " + isEnabled);
            if ("False".equals(isEnabled)) {
                Reporter.log("DEA Class field is read-only as expected.");
            } else {
                Reporter.log("DEA Class field is editable, which is not expected.");
                Assert.fail("DEA Class field should be read-only.");
            }
            productMaintenancePage.clickCancelBtn();

        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void inputAddressDetailsToOtherAddressTabInPMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] patientNameArr = connexusAppUtils.readPatientNameFromFile();
            String patientName = patientNameArr[0] + "," + patientNameArr[1];
            String patientDOB = inputData.get("DOB");

            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            inputAddressLine1ForAllTabs(() -> patientMaintenancePage.clickMailingAddressTab(), inputData);
            inputAddressLine1ForAllTabs(() -> patientMaintenancePage.clickTemporaryAddressTab(), inputData);
            inputAddressLine1ForAllTabs(() -> patientMaintenancePage.inputFacilityNameAndId(ConnexusConstants.FACILITY_NAME,ConnexusConstants.FACILITY_ID),inputData);
            patientMaintenancePage.clickSaveAndClose();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Input address details to each Tab is failed: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Exception in verifyAddressLine1ValidationPopUpInPMS1: " + e.getMessage());
        }
    }

    public void verifyAddressLine1ValidationPopUpInPMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] patientNameArr = connexusAppUtils.readPatientNameFromFile();
            String patientName = patientNameArr[0] + "," + patientNameArr[1];
            String patientDOB = inputData.get("DOB");
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            //Remove address line 1 for All tabs
            Reporter.log("Remove AddressLine1 for All the Tabs to validate error message ");
            patientMaintenancePage.clearAddressLine1forPatient();
            clearAddressLine1FromAllTabs(() -> patientMaintenancePage.clickMailingAddressTab());
            clearAddressLine1FromAllTabs(() -> patientMaintenancePage.clickTemporaryAddressTab());
            clearAddressLine1FromAllTabs(() -> patientMaintenancePage.clickFacilityAddressTab());
            patientMaintenancePage.clickSaveAndClose();
            String popupMsg = patientMaintenancePage.requiredFieldsPopUpMessage();
            Assert.assertEquals(popupMsg, "The following fields are missing/invalid");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.isAddressLine1ValidationPopupDisplayed();
            // Re-enter address line 1 for All tabs
            Reporter.log("Re-Enter AddressLine1 for All the Tabs and save the details ");
            inputAddressLine1ForAllTabs(() -> patientMaintenancePage.clickPhysicalAddressTab(), inputData);
            inputAddressLine1ForAllTabs(() -> patientMaintenancePage.clickMailingAddressTab(), inputData);
            inputAddressLine1ForAllTabs(() -> patientMaintenancePage.clickTemporaryAddressTab(), inputData);
            inputAddressLine1ForAllTabs(() -> patientMaintenancePage.clickFacilityAddressTab(), inputData);
            patientMaintenancePage.clickSaveAndClose();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Address Validation PopUp is not displayed: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Exception in verifyAddressLine1ValidationPopUpInPMS1: " + e.getMessage());
        }
    }
    private void clearAddressLine1FromAllTabs(Runnable clickTab) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        clickTab.run();
        patientMaintenancePage.clearAddressLine1forPatient();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
    }

    private void inputAddressLine1ForAllTabs(Runnable clickTab, Map<String, String> inputData) {
        clickTab.run();
        patientMaintenancePage.inputAddressLine1(inputData.get("PAT_ADDRESS_LINE1"));
        patientMaintenancePage.ZipCode(inputData.get("ZIP_CODE"));
    }
    public void SearchAnOrderAndVerifyPatPayCalculation(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(inputData.get("LAST_NAME") + "," + inputData.get("FIRST_NAME"));
            orderSearch.unSelectOrder(5);
            totalPatPay= orderSearch.getPatPay();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Total patpay after unselected few orders "+totalPatPay);
            orderSearch.unSelectOrder(5);
            totalPatPay= orderSearch.getPatPay();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Total patpay for all selected orders "+totalPatPay);
            orderSearch.closeSearch();
        }
        catch (Throwable e) {
            e.printStackTrace();
            isExceptionCaptured = true;
            Assert.fail("");
        }
    }

    /**
     * Method to retrieve the timestamp of a specific comment text from the database.
     * @param expectedCommentText
     * Author: Naveen(vn58o0j)
     */
    public void getTimeStamp(String expectedCommentText){
        List<Map<String, Object>> resultSet = connexusAppUtils.getCommentTypeCodeAndCommentText();
        for (Map<String, Object> result : resultSet) {
            String actualCommentTexts = result.get("comment_text").toString();
            if (actualCommentTexts.equals(expectedCommentText)) {
                Reporter.log("Comment Text found: " + expectedCommentText);
                actualTimeStamp = (Timestamp) result.get("create_ts");
                Reporter.log("Timestamp: " + actualTimeStamp);
            }
        }
    }

    /**
     * Method to verify the comment type code and comment text for a specific Rx ID.
     * Parameters called in test set.
     * Author: Naveen (vn58o0j)
     * @param
     */
    public void verifyCommentTypeCodeAndCommentText(String expectedCommentTypeCode ,String expectedCommentText, String userName,boolean timeStamp) {
        List<Map<String, Object>> resultSet = connexusAppUtils.getCommentTypeCodeAndCommentText();
        if (resultSet.isEmpty()) {
            Reporter.log("No comments found in the database for the given criteria.");
            Assert.fail("No comments found in the database for the given criteria.");
        }
        for (Map<String, Object> result : resultSet) {
            String actualCommentTexts = result.get("comment_text").toString();
            if (actualCommentTexts.equals(expectedCommentText)){
                Reporter.log("Comment Text found: " + expectedCommentText);
                String actualCommentTypeCodes = result.get("comment_type_code").toString();
                String actualCreateUserIds = result.get("create_userid").toString();
                inputTimestamp = (Timestamp) result.get("create_ts");
                Assert.assertEquals(actualCommentTypeCodes, expectedCommentTypeCode, "Comment Type Code does not match expected value");
                Assert.assertEquals(actualCreateUserIds.trim().toLowerCase(), userName.toLowerCase(), "Create User ID does not match");
                if (timeStamp){
                    Assert.assertEquals(inputTimestamp, actualTimeStamp, "Timestamp does not match expected value");
                }
                Reporter.log("Comment Type Code: " + actualCommentTypeCodes + " || Comment Text: " + actualCommentTexts +
                        " || Create User ID: " + actualCreateUserIds +" || Timestamp: " + inputTimestamp);
            }
        }
    }

    /**
     * Method to open the input screen, apply a comment, and switch to a new user.
     * @param inputData
     * Author: Naveen(vn58o0j)
     */
    public void applyCommentInInputScreenAndClickSendToResolutionButton(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        InputPage inputPage = new InputPage();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxModel.setRxComment(inputData.get("COMMENT"));
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName());
            orderSearch.openFirstPatientRecord();
            inputPage.enterRxComment(rxModel.getRxComment());
            inputPage.clickSendToResolution();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Comment applied in input screen and clicked send to resolution");
        }catch (Throwable e){
            e.printStackTrace();
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Exception in openInputAndApplyComment: " + e.getMessage());
        }
    }

    /**
     * This method switches the user to a new user type and opens the Order Search screen.
     * We're handling a connexus pop up after opening the patient record.
     * Author: Naveen(vn58o0j)
     */
    public void switchingUserAndOpeningOrdersearch(){
        try {
            loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
            Reporter.log("Logged in as new user: " + prop.getProperty("cnx.rph.userName"));
            String[] enterName = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(enterName[0]);
            rxModel.setPatientFirstName(enterName[1]);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName());
            orderSearch.openFirstPatientRecord();
            chkDur.isPopupDisplayed();
        } catch (Throwable e) {
            e.printStackTrace();
            isExceptionCaptured = true;
            Reporter.log("Failed to switch user and open Order Search");
            Assert.fail("Failed to switch user and open Order Search");
        }
    }
    public void clickQuickIconCheckFor4Point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickQuickAccessIcon(ConnexusConstants.APP_CONSTANT_4POINT_QUICK_ACCESS_ICON);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.FOUR_POINT_ICON.getLeftBarWorkQueues()) ||
                    connexusStartPage.getTextFromTitleBar().contains("Check DUR")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("4Point access done through Quick Icon click");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Not an expected Screen");
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.FOUR_POINT_ICON);
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void menuNavigationToOpen4PointScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.FOUR_POINT, AppMenuItemsIndex.WORKQUEUE_FOUR_POINT,null,null);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.FOUR_POINT_ICON.getLeftBarWorkQueues()) ||
                    connexusStartPage.getTextFromTitleBar().contains("Check DUR")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("4Point access done through menuNavigation");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Not an expected Screen");
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.FOUR_POINT_ICON);
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void click4PointFromLeftBar() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.FOUR_POINT_ICON);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.FOUR_POINT_ICON.getLeftBarWorkQueues()) ||
                    connexusStartPage.getTextFromTitleBar().contains("Check DUR")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("4Point access done through LeftBar");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Not an expected Screen");
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.FOUR_POINT_ICON);
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void pressKeyboardShortCutToOpen4PointScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            this.pressShortcutKeys(KeyEvent.VK_CONTROL, KeyEvent.VK_4);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.FOUR_POINT_ICON.getLeftBarWorkQueues()) ||
                    connexusStartPage.getTextFromTitleBar().contains("Check DUR")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("4Point access done through KeyBoard shortcut ");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Not an expected Screen");
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.FOUR_POINT_ICON);
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickQuickIconCheckForVisualVerify() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickQuickAccessIcon(ConnexusConstants.APP_CONSTANT_VISUALLYVERIFY_QUICK_ACCESS_ICON);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Visual Verify access done through Quick Icon click");
            } else {
                if (connexusStartPage.getTextFromAppTitleBar(1).contains("Visual Verify")) {
                    Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.clickOk();
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Assert.fail("Not an expected Screen");
                }
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.VISUAL_VERIFY_ICON);
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void menuNavigationToOpenVisualVerifyScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.VISUAL_VERIFY, AppMenuItemsIndex.WORKQUEUE_VISUAL_VERIFY,null,null);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Visual verify access done through menuNavigation");
            } else {
                if (connexusStartPage.getTextFromAppTitleBar(1).contains("Visual Verify")) {
                    Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.clickOk();
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Assert.fail("Not an expected Screen");
                }
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.VISUAL_VERIFY_ICON);
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickVisualVerifyFromLeftBar() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.VISUAL_VERIFY_ICON);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Visual verify access done through LeftBar");
            } else {
                if (connexusStartPage.getTextFromAppTitleBar(1).contains("Visual Verify")) {
                    Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.clickOk();
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Assert.fail("Not an expected Screen");
                }
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.VISUAL_VERIFY_ICON);
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void pressKeyboardShortCutToVisualVerifyScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            this.pressShortcutKeys(KeyEvent.VK_CONTROL, KeyEvent.VK_Y);
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.VISUAL_VERIFY_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Visual verify access done through KeyBoard shortcut ");
            } else {
                if (connexusStartPage.getTextFromAppTitleBar(1).contains("Visual Verify")) {
                    Reporter.logScreenShot(Status.SKIP, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    connexusStartPage.clickOk();
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    Assert.fail("Not an expected Screen");
                }
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.VISUAL_VERIFY_ICON);
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void clickCounselingFromLeftBar() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.COUNSELING_ICON);
            orderSearch.openFirstPatientRecord();
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.COUNSELING_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Counseling access done through LeftBar");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Not an expected Screen");
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.COUNSELING_ICON);
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void menuNavigationToOpenCounselingScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.COUNSELING, AppMenuItemsIndex.WORKQUEUE_COUNSELLING,null,null);
            orderSearch.openFirstPatientRecord();
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.COUNSELING_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Counseling access done through menuNavigation");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Not an expected Screen");
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.COUNSELING_ICON);
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void pressShortcutKeys(int... keyEvents) {
        try {
            Robot robot = new Robot();
            for (int keyEvent : keyEvents) {
                robot.keyPress(keyEvent);
            }
            for (int keyEvent : keyEvents) {
                robot.keyRelease(keyEvent);
            }
        } catch (AWTException e) {
            System.out.println("Error while pressing shortcut keys: " + e.getMessage());
        }
    }
    public void pressKeyboardShortCutToOpenCounselingScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            this.pressShortcutKeys(KeyEvent.VK_CONTROL, KeyEvent.VK_G);
            orderSearch.openFirstPatientRecord();
            if (connexusStartPage.getTextFromTitleBar().contains(LeftBarWorkQueues.COUNSELING_ICON.getLeftBarWorkQueues())) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Counseling access done through KeyBoard shortcut ");
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Not an expected Screen");
            }
            connexusStartPage.pressEscapeKey();
            connexusStartPage.clickWorkQueueFromLeftBar(LeftBarWorkQueues.COUNSELING_ICON);
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    public void validateSCRTBrowserIsOpenedWithExpectedUrl(Map<String, String> inputData) {
        final String expectedUrl = inputData.get("BROWSER_URL");
        try {
            menuBar.clickOnSCRT();
            Reporter.log("Clicked on SCRT shortcut from Tools Menu Bar");

            Assert.assertTrue(
                    menuBar.getBrowserUrl(expectedUrl),
                    "SCRT browser did not open with expected URL (or it took too long). Expected to contain: " + expectedUrl
            );

            Reporter.log("SCRT browser is opened successfully by clicking on SCRT shortcut from tools menu bar");
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.log("Failed to validate the URL of the browser opened: " + e.getMessage());
            Assert.fail("Failed to validate SCRT browser URL. Expected to contain: " + expectedUrl, e);
        }finally {
            try {
                Runtime.getRuntime().exec("TASKKILL /F /IM chrome.exe");
                Reporter.log("Browser Closed");

            } catch (Exception closeEx) {
                Reporter.log("Failed to close browser: " + closeEx.getMessage());

            }
        }
    }

    public void validateHealthServiceAppointmentsBrowserIsOpenedWithExpectedUrl(Map<String, String> inputData) {
        try {
            menuBar.clickHealthServiceAppointments();
            Reporter.log("Clicked on Health Service Appointments shortcut from Tools Menu Bar");
            Assert.assertTrue(menuBar.getBrowserUrl(inputData.get("BROWSER_URL")));
            Reporter.log("Health Service Appointments browser is opened successfully by clicking on Health Service Appointments shortcut from tools menu bar");
            Runtime.getRuntime().exec("TASKKILL /F /IM chrome.exe");
            Reporter.log("Browser Closed");
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.log("failed to validate the URL of the browser opened" + e.getMessage());
            Assert.fail("");
        }
    }
    //To change the initial Priority for an existing order
    public void updatePriorityOfAnOrder(int index) {
        final String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Launch and search for the order
            orderSearch.searchOrderByWorkQueue();
            initialPriority = orderSearch.getPriority(0);
            Reporter.log("Initial order priority: " + initialPriority);
            initialDispenseType = orderSearch.getDispenseType(0);
            Reporter.log("Initial order DispenseType: " + initialDispenseType);

            // Initiate priority update
            orderSearch.clickUpdatePUButton();

            // Build list of all priorities except current one, Dr Call In, and Drive Thru
            // (excluded: DRCallIn and DriveThru is not available in updatePriority options in box 32053, it can cause ambiguity)
            List<Priority> availablePriorities = new ArrayList<>();
            for (Priority p : Priority.values()) {
                if (!initialPriority.contains(p.getPriority())
                        && p != Priority.DRCallIn
                        && p != Priority.DriveThru) {
                    availablePriorities.add(p);
                }
            }

            // Pick randomly
            Priority newPriority = availablePriorities.get(
                    new Random().nextInt(availablePriorities.size()));
            Reporter.log("Randomly selected new priority: " + newPriority.getPriority());

            // Set new priority — Future and Today require an extra ready-by time step
            orderSearch.updatePriority(newPriority.getPriority());
            Reporter.logScreenShot(Status.INFO, currentStepMethodName,
                    orderSearch.takeScreenShot(currentStepMethodName).getValue());
            if (newPriority == Priority.Future || newPriority == Priority.Today) {
                orderSearch.selectReadyByTimeupdate();
            }
            if(initialDispenseType.contains("Mail Delivery")) {
                orderSearch.selectDispenseType(DispenseType.CounterPickup.getDispenseType());
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    orderSearch.takeScreenShot(currentStepMethodName).getValue());
            orderSearch.clickAccept();
            orderSearch.clickYes();

            // Re-fetch and log new priority
            String changedPriority = orderSearch.getPriority(0);
            // Screenshot for reporting
            Reporter.logScreenShot(
                    Status.PASS,
                    currentStepMethodName,
                    orderSearch.takeScreenShot(currentStepMethodName).getValue()
            );
            Reporter.log("Order priority changed to: " + changedPriority);
            orderSearch.closeSearch();

            // verify that priority actually changed
            if (initialPriority.equals(changedPriority)) {
                Assert.fail("Priority update failed: priority did not change.");
            }
        } catch (Exception e) {
            Reporter.log("Exception during priority update: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("Priority update failed due to exception: " + e.getMessage());
        }
    }
    //To change the initial Dispense type for an existing order
    public void updateDispenseTypeOfAnOrder(int index) {
        final String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Launch and search for the order
            orderSearch.searchOrderByWorkQueue();
            initialDispenseType = orderSearch.getDispenseType(0);
            Reporter.logScreenShot(Status.INFO, currentStepMethodName,
                    orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Initial order DispenseType: " + initialDispenseType);

            // Initiate dispense type update
            orderSearch.clickUpdatePUButton();

            // Toggle: Counter Pickup → Mail Delivery, or vice versa
            if (initialDispenseType.contains(DispenseType.CounterPickup.getDispenseType())) {
                Reporter.log("Current type is Counter Pickup — switching to Mail Delivery");
                orderSearch.selectDispenseType(DispenseType.MailDelivery.getDispenseType());
                orderSearch.validateMailDeliveryAddress();
            } else {
                Reporter.log("Current type is Mail Delivery — switching to Counter Pickup");
                orderSearch.selectDispenseType(DispenseType.CounterPickup.getDispenseType());
            }
            orderSearch.clickAccept();
            orderSearch.clickYes();

            // Re-fetch and log new priority
            String changedDispenseType = orderSearch.getDispenseType(0);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Order dispense type changed to: " + changedDispenseType);
            orderSearch.closeSearch();

            // verify that dispense actually changed
            if (initialDispenseType.equals(changedDispenseType)) {
                Assert.fail("Dispense Method update failed: Dispense Method did not change.");
            }
        } catch (Exception e) {
            Reporter.log("Exception during dispenseType update: " + e.getMessage());
            e.printStackTrace();
            Assert.fail("dispenseType update failed due to exception.");
        }
    }

    public void addHighestAllergyAndMedicalCode(Map<String, String> inputData) {
        try {
            patientMaintenancePage.fetchandAddHighestAllergyCodeToPatientProfile(inputData, "allergy_generic_name","med_condition_desc");
            Reporter.log("Allergy and Medical Condition with highest code value added successfully");
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.log("failed to add Allergy and Medical Condition" + e.getMessage());
            Assert.fail("");
        }

    }

    /*
    * Method to check prescription history is displayed in Rx look screen while selecting host show profile check box
    * */
    public void verifyPrescriptionHistoryInRxLookUpScreen(Map<String, String>inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            //opening rx lookup page and searching for the patient
            ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(inputData.get("FIRST_NAME") + "," + inputData.get("LAST_NAME"));
            rxLookUp.clickSearch();
            rxLookUp.isElementDisplayed(rxLookUp.hostProfileChkBox);
            Reporter.logScreenShot(Status.PASS, "Rx lookUp Page", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            //opening show host profile
            rxLookUp.openinghostPatientProfile();
            Reporter.logScreenShot(Status.PASS, "Host Patient Profile", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            //check if No response received from Central Data Popup displayed
            if(rxLookUp.noResponseFromCentralDb()){
                Reporter.log("No response recieved from the central data for the given patient");
                Assert.fail();
            }
            //close rxlookup page
            rxLookUp.closeSearch();
            Reporter.log("Verified prescription history in Rx lookup screen when Show Host Profile is selected");
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to get Prescription History for Rx lookup screen " + e.getMessage());
            softAssert.fail();
        }
    }

    /**
     * Opening Rx notes from current Rx and checking Acute and Non-Acute in the Notes based on the boolean condition
     */
    public void validateAcuteAndNonAcuteInRxNotes(boolean Acute){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.launchRxNotesScreen();
            String notes = consolidatedNotesPage.getTxtNotes().trim();
            Reporter.logScreenShot("Rx Note", fourPoint.takeScreenShot());
            Reporter.log("RxNote: " + notes);
            if(Acute){
                Assert.assertTrue(notes.contains("INITIAL ACUTE"));
            }else{
                Assert.assertTrue(notes.contains("NON ACUTE"));
            }
            //close RxNotes
            orderSearch.clickCancel();
            //Close Chkdur screen
            fourPoint.clickButtonCancel();
        }catch (Exception e){
            Reporter.log("Failed to open and get Rx notes");
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

}
