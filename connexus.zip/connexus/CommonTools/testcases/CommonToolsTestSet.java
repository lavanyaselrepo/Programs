package connexus.CommonTools.testcases;

import connexus.CommonTools.testscripts.CommonToolsTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.datamodels.connexus.PatientProfileModel;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.awt.*;
import java.util.Map;

public class CommonToolsTestSet {

    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    CommonToolsTestScripts commonToolsTestScripts = new CommonToolsTestScripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    PropertyReader prop = PropertyReader.getInstance();
    String siteId = prop.getProperty("cnx.store");
    boolean flagUpdated = false;

    @BeforeClass
    public void performlogin() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    @Test(enabled = true, description = "Verify the patient address, insurance information for a Cash PET patient in 4pT screen and corresponding insurance information in TASCO screen", priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")

    public void HWPHME2E_4362_Verify_patient_address_insurance_information_for_Cash_PET_patient(Map<String, String> inputData) {

        Reporter.log("Verify the patient address, insurance information for a Cash PET patient in 4pT and TASCO Screen");
        // Pre-checks
        Reporter.log("Logged in store:" + siteId);
        flagUpdated = connexusAppUtils.updateFlagValueBasedOnCode("19240", "TRUE");
        Reporter.log("Updated parm value for 19240 (Flag To enable pet/livestock DUR check) as TRUE");
        commonToolsTestScripts.initializeTestCase(flagUpdated);
        commonToolsTestScripts.createNewPatient(inputData, 0, PatientProfileModel.PatientType.PET);
        commonToolsTestScripts.performDropOff(1, Priority.Critical);
        commonToolsTestScripts.performInput(inputData,"Regular");
        commonToolsTestScripts.validate4pointForPaymentRequired(inputData);
        //Check comments in present in chkdur
        commonToolsTestScripts.chkdurCmtsValidations();
        commonToolsTestScripts.verifyDetailsINConflictTable();
        commonToolsTestScripts.performFilling();
        commonToolsTestScripts.performVisualVerify();
        commonToolsTestScripts.performTascoPickUpValidation(inputData);
        commonToolsTestScripts.validatingChkdurCmtsInCounselQueue();
        commonToolsTestScripts.getDurOverrideSummaryReport();

    }

    @Test(enabled = true, description = "Verify the patient address, insurance information for a TP Insurance PET patient in 4pT screen and corresponding insurance information in TASCO screen", priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")

    public void HWPHME2E_4361_Verify_patient_address_insurance_information_for_TP_Insurance_PET_patient(Map<String, String> inputData) {

        Reporter.log("Verify the patient address, insurance information for a Insurance PET patient in 4pT and TASCO Screen");
        // Pre-checks
        Reporter.log("Logged in store:" + siteId);
        flagUpdated = connexusAppUtils.updateFlagValueBasedOnCode("19240", "TRUE");
        Reporter.log("Updated parm value for 19240 (Flag To enable pet/livestock DUR check) as TRUE");
        commonToolsTestScripts.initializeTestCase(flagUpdated);
        commonToolsTestScripts.createNewPatient(inputData, 1, PatientProfileModel.PatientType.PET);
        commonToolsTestScripts.performDropOff(1, Priority.Critical);
        commonToolsTestScripts.performInput(inputData,"Regular");
        commonToolsTestScripts.validate4pointForPaymentRequired(inputData);
        //Check comments in present in chkdur
        commonToolsTestScripts.chkdurCmtsValidations();
        commonToolsTestScripts.verifyDetailsINConflictTable();
        commonToolsTestScripts.performFilling();
        commonToolsTestScripts.performVisualVerify();
        commonToolsTestScripts.performPickUp(inputData);
        commonToolsTestScripts.validatingChkdurCmtsInCounselQueue();
        commonToolsTestScripts.getDurOverrideSummaryReport();
    }

    @Test(enabled = true, description = "Verify Problem Resolved Functionality when Rx# is sent to Manual Resolution from ChkDUR Queue by HO User", priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")
    public void HWPHME2E_3003_Verify_Problem_Resolved_Functionality_when_Rx_is_sent_to_Manual_Resolution_from_ChkDUR_Queue_by_HO_User(Map<String, String> inputData) {

        Reporter.log("Verify Problem Resolved Functionality when Rx# is sent to Manual Resolution from ChkDUR Queue by HO User");
        Reporter.log("Logged in store:" + siteId);
        commonToolsTestScripts.initializeTestCase(false);
        commonToolsTestScripts.createNewPatient(inputData);
        commonToolsTestScripts.performDropOff(1, Priority.Critical);
        commonToolsTestScripts.performInput(inputData,"Regular");
        commonToolsTestScripts.perform4Point(false,false,inputData,false);
        commonToolsTestScripts.validateResolutionOnDUR(inputData);
        commonToolsTestScripts.verifyRXInInputQueue();
    }
    @Test(enabled = true, description = "Validate Product Maintenance Data to Update and get the Data",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")
    public void HWPHME2E_2409_validate_product_screen_data_update(Map<String, String> inputData) {
        Reporter.log("Validate Product Maintenance Data to Update and get the Data");
        Reporter.log("Logged in store:" + siteId);
        commonToolsTestScripts.initializeTestCase(false);
        commonToolsTestScripts.openProductSearchWindow(inputData);
        commonToolsTestScripts.validateProductMaintenanceData(inputData);
        commonToolsTestScripts.updateProductMaintenanceData(inputData);
        commonToolsTestScripts.validateProductMaintenanceDataAfterUpdate(inputData);
        commonToolsTestScripts.checkProductMaintenanceNoteButtons(inputData);
        commonToolsTestScripts.checkPatientEducationButtonsandLeaflets(inputData);
    }
    @Test(enabled = true, description = "Validate When user changing the DEA class to a more restrictive DEA class, CNX does not allow the user to change it back or not",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")
    public void HWPHME2E_1328_validate_product_screen_DEAClass_Restriction(Map<String, String> inputData) {
        Reporter.log("Validate When user changing the DEA class to a more restrictive DEA class, CNX does not allow the user to change it back or not");
        Reporter.log("Logged in store:" + siteId);
        commonToolsTestScripts.initializeTestCase(false);
        commonToolsTestScripts.openProductSearchWindow(inputData);
        //check for DEA class restriction, it should be read only
        commonToolsTestScripts.validateValueofDEA();
    }

    @Test(enabled = true, description = "Verify that address line 1 is mandatory for a profile in Patient maintenance screen", priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")

    public void HWPHME2E_4730_Verify_that_address_line1_is_mandatory_for_a_profile_in_Patientmaintenance_screen(Map<String, String> inputData) throws AWTException {

        Reporter.log("Verify that address line 1 is mandatory for a profile in Patient maintenance screen");
        Reporter.log("Logged in store:" + siteId);
        commonToolsTestScripts.initializeTestCase(false);
        commonToolsTestScripts.createNewPatient(inputData);
        commonToolsTestScripts.inputAddressDetailsToOtherAddressTabInPMS(inputData);
        commonToolsTestScripts.verifyAddressLine1ValidationPopUpInPMS(inputData);
    }
    @Test(enabled = true, description = "Verify the pat pay calculation in order search screen when searched by patient name or rx number", priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")

    public void HWPHME2E_4708_Verify_the_pat_pay_calculation_in_order_search_screen_when_searched_by_patient_name_or_rx_number(Map<String, String> inputData) throws AWTException {

        Reporter.log("Verify the pat pay calculation in order search screen when searched by patient name or rx number");
        Reporter.log("Logged in store:" + siteId);
        commonToolsTestScripts.initializeTestCase(false);
        commonToolsTestScripts.SearchAnOrderAndVerifyPatPayCalculation(inputData);
    }


    @Test(enabled = true, description = "Validate Patient Deceased Resolution Screen for a Deceased Patient with InComplete Input Queue", priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")
    public void HWPHME2E_3008_Verify_Patient_Deceased_Resolution_Screen_for_a_Deceased_Patient_with_InComplete_Input_Queue (Map<String, String> inputData){

        Reporter.log("Validate Patient Deceased Resolution Screen for a Deceased Patient with InComplete Input Queue");
        Reporter.log("Logged in store:" + siteId);
        commonToolsTestScripts.initializeTestCase(false);
        commonToolsTestScripts.createNewPatient(inputData,0, PatientProfileModel.PatientType.HUMAN);
        commonToolsTestScripts.performDropOff(1, Priority.Critical);
        commonToolsTestScripts.verifyRXInInputQueue();
        commonToolsTestScripts.makePatientStatusAsDeceased();
        commonToolsTestScripts.verifyModifyDetailsScreenNotAccessible(inputData);
        commonToolsTestScripts.verifyPatientDeceasedPopUpAppearsForDropOffRefill();
    }

    /*----------------------------------------------------------------------------------------------------------
     * HWPHME2E_4364 Test Description: Validate RX comment in input and delete the same in fourpoint
     * Give the home office & pharmacist username as capital letters in DEV properties.
     * Author: Naveen(vn58o0j)
---------------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-4364")
    @Test(enabled = true, description = "Validate the functionality when rx comment is deleted and 4PT is completed",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")

    public void HWPHME2E_4364_Validate_Rx_Comment_In_Input_And_Delete_In_Fourpoint(Map<String, String> inputData) {
        commonToolsTestScripts.initializeTestCase(false);
        commonToolsTestScripts.createNewPatient(inputData);
        commonToolsTestScripts.performDropOff(Priority.Critical);
        int patientId = commonToolsTestScripts.getPatientId();
        connexusAppUtils.getRxIdByUsingPatientId(patientId);
        commonToolsTestScripts.performInput(inputData, "Regular");
        commonToolsTestScripts.getTimeStamp(inputData.get("RX_COMMENT"));
        commonToolsTestScripts.verifyCommentTypeCodeAndCommentText(inputData.get("COMMENT_CODE"), inputData.get("RX_COMMENT"), prop.getProperty("cnx.ho.userName"),false);
        commonToolsTestScripts.perform4Point(false, false, inputData,false);
        commonToolsTestScripts.verifyCommentTypeCodeAndCommentText(inputData.get("COMMENT_CODE_201"),inputData.get("RX_COMMENT"), prop.getProperty("cnx.ho.userName"),true);
    }

    /*----------------------------------------------------------------------------------------------------------
     * HWPHME2E_4363 Test Description: Validate the functionality when multiple Rx comment added by different users for a Rx
     * Give the home office & pharmacist username as capital letters in DEV properties.
     * Author: Naveen(vn58o0j)
---------------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-4363")
    @Test(enabled = true, description = "Validate the functionality when multiple Rx comment added by different users for an Rx",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")

    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")

    public void HWPHME2E_4363_Multiple_Rx_Comment_Added_By_Different_Users_For_An_Rx(Map<String, String> inputData) {
        commonToolsTestScripts.initializeTestCase(false);
        commonToolsTestScripts.createNewPatient(inputData);
        commonToolsTestScripts.performDropOff(Priority.Critical);
        int patientId = commonToolsTestScripts.getPatientId();
        connexusAppUtils.getRxIdByUsingPatientId(patientId);
        commonToolsTestScripts.applyCommentInInputScreenAndClickSendToResolutionButton(inputData);
        commonToolsTestScripts.getTimeStamp(inputData.get("COMMENT"));
        commonToolsTestScripts.verifyCommentTypeCodeAndCommentText(inputData.get("COMMENT_CODE"),inputData.get("COMMENT"),prop.getProperty("cnx.ho.userName"),false);
        commonToolsTestScripts.switchingUserAndOpeningOrdersearch();
        commonToolsTestScripts.performInput(inputData, "Regular");
        commonToolsTestScripts.verifyCommentTypeCodeAndCommentText(inputData.get("COMMENT_CODE_201"),inputData.get("COMMENT"),prop.getProperty("cnx.ho.userName"),true);
        commonToolsTestScripts.verifyCommentTypeCodeAndCommentText(inputData.get("COMMENT_CODE"),inputData.get("COMBINED_COMMENT"),prop.getProperty("cnx.rph.userName"),false);
    }

    @Test(enabled = true, description = "Verify the access of 4PT, VV and Counsel screen for a pharmacist user",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")
    public void HWPHME2E_1268_Verify_access_of_4PT_VV_Counsel_Screen_for_Pharmacist(Map<String, String> inputData) {
        Reporter.log("Verify the access of 4PT, VV and Counsel screen for a pharmacist user");
        Reporter.log("Logged in store:" + siteId);
        commonToolsTestScripts.initializeTestCase(false);
       //4Point access
        commonToolsTestScripts.pressKeyboardShortCutToOpen4PointScreen();
        commonToolsTestScripts.click4PointFromLeftBar();
        commonToolsTestScripts.clickQuickIconCheckFor4Point();
        commonToolsTestScripts.menuNavigationToOpen4PointScreen();
       //Visual verify access
        commonToolsTestScripts.menuNavigationToOpenVisualVerifyScreen();
        commonToolsTestScripts.clickQuickIconCheckForVisualVerify();
        commonToolsTestScripts.clickVisualVerifyFromLeftBar();
        commonToolsTestScripts.pressKeyboardShortCutToVisualVerifyScreen();
       //Counseling access
        commonToolsTestScripts.clickCounselingFromLeftBar();
        commonToolsTestScripts.menuNavigationToOpenCounselingScreen();
        commonToolsTestScripts.pressKeyboardShortCutToOpenCounselingScreen();
        Reporter.log("The access of 4PT, VV and Counsel screen for a pharmacist user has been verified");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: HWPHME2E_3071 Validate the SCRT shortcut in connexus
    *
    * Pre-Conditions:  Login to Connexus as Home Office User Creds
    *
    * Author: Diya(vn58o0i)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate the SCRT Shortcut in Connexus", priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")
    public void HWPHME2E_3071_Validate_The_SCRT_Shortcut_In_Connexus(Map<String, String>inputData){
        Reporter.log("Validate the SCRT Shortcut in Connexus");
        Reporter.log("Logged in store:" + siteId);
        commonToolsTestScripts.initializeTestCase(false);
        commonToolsTestScripts.validateSCRTBrowserIsOpenedWithExpectedUrl(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: HWPHME2E_3007 Validate accessing Health Service Appointments in tools menu
    *
    * Pre-Conditions:  User is logged into Connexus
    *
    * Author: Diya(vn58o0i)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate accessing Health Service Appointments in Tools menu", priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")
    public void HWPHME2E_3007_Validate_Accessing_Health_Service_Appointments_In_Tools_Menu(Map<String, String>inputData){
        Reporter.log("Validate accessing Health Service Appointments in Tools menu");
        Reporter.log("Logged in store:" + siteId);
        commonToolsTestScripts.initializeTestCase(false);
        commonToolsTestScripts.validateHealthServiceAppointmentsBrowserIsOpenedWithExpectedUrl(inputData);
    }
    @Test(enabled = true, description = "Verify the functionality of modifying Dispense Type and the priority of an order", priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")
    public void HWPHME2E_1452_Verify_the_functionality_of_modifying_Dispense_Type_and_the_priority_of_an_order(Map<String, String> inputData) {
        Reporter.log("Verify the functionality of modifying Dispense Type and the priority of an order");
        Reporter.log("Logged in store:" + siteId);
        commonToolsTestScripts.initializeTestCase(false);
        commonToolsTestScripts.updatePriorityOfAnOrder(0);
        commonToolsTestScripts.updateDispenseTypeOfAnOrder(0);
    }
    @Test(enabled = true, description = "Verify an Rx taken to EOD for a patient with the allergy with the highest allergy class code value and MC with highest med condition code value", priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")
    public void HWPHME2E_250_Verify_Rx_taken_to_EOD_for_a_patient_with_highest_allerg_class_code_value_and_highest_med_condition_code_value (Map<String, String> inputData){

        Reporter.log("Logged in store:" + siteId);
        connexusAppUtils.readAndUpdateFlag("27249", "TRUE");
        commonToolsTestScripts.initializeTestCase(false);
        commonToolsTestScripts.createNewPatient(inputData);
        commonToolsTestScripts.addHighestAllergyAndMedicalCode(inputData);
        commonToolsTestScripts.performDropOff(1, Priority.Critical);
        commonToolsTestScripts.performInput(inputData);
        commonToolsTestScripts.perform4Point(false,false,inputData,false);
        commonToolsTestScripts.performFilling();
        commonToolsTestScripts.performVisualVerify();
        commonToolsTestScripts.performPickUp(inputData);
        commonToolsTestScripts.performCounselling();
        Reporter.log("Allergy is displaying in counselling screen");
        commonToolsTestScripts.performPOS();
    }

    /*---------------------------------------------------------------------------------------------------------------------------
    * Test Description: HWPHME2E_5257 Verify the prescription history for a patient in rx look up screen when Show Host Profile is selected
    *
    * Pre-Conditions:  User is logged into Connexus
    *
    * Author: Diya(vn58o0i)
    ----------------------------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify the prescription history for a patient in rx look up screen when Show Host Profile is selected", priority = 11,
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/CommonTools/CommonTools.json", sheetName = "CommonTools")
    public void HWPHME2E_5257_verify_the_prescription_history_in_rxLookUp(Map<String, String> inputData){
        int storeNbr = connexusAppUtils.getStoreId();
        commonToolsTestScripts.initializeTestCase(false);
        commonToolsTestScripts.verifyPrescriptionHistoryInRxLookUpScreen(inputData);
    }

    /*---------------------------------------------------------------------------------------------------------------------------
  * Test Description: HWPHME2E_5444 Verify Rxnotes For Acute And NonAcute Condition
  *
  * Pre-Conditions:  User is logged into Connexus
  *
  * Author: Diya(vn58o0i)
  ----------------------------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Verify Rxnotes for Acute and NonAcute condition", priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath ="TestData/Connexus/CommonTools/CommonTools.json", sheetName ="CommonTools")
    public void HWPHME2E_5444_Verify_Rxnotes_For_Acute_And_NonAcute_Condition(Map<String, String>inputData){
        commonToolsTestScripts.initializeTestCase(false);
        //NonAcute
        commonToolsTestScripts.createPatientAPI(inputData);
        commonToolsTestScripts.performCompleteDropOffAPI(inputData);
        commonToolsTestScripts.performInput(inputData);
        commonToolsTestScripts.performFourPointForAcuteConditionYes();
        commonToolsTestScripts.validateAcuteAndNonAcuteInRxNotes(true);

        //Acute
        commonToolsTestScripts.createPatientAPI(inputData);
        commonToolsTestScripts.performCompleteDropOffAPI(inputData);
        commonToolsTestScripts.performInput(inputData);
        commonToolsTestScripts.perform4Point(true);
        commonToolsTestScripts.validateAcuteAndNonAcuteInRxNotes(false);
    }
}
