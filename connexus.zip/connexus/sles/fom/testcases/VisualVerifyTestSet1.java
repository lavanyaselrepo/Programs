package connexus.sles.fom.testcases;

import connexus.sles.fom.testscripts.VisualVerifyTestScript1;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class VisualVerifyTestSet1 {

    VisualVerifyTestScript1 visualVerifyTestScript1 =new VisualVerifyTestScript1();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();

    @BeforeClass
    public void launchAndLogin() {
        connexusAppUtils.readAndUpdateFlag("27450","FALSE");
        visualVerifyTestScript1.launchConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    /*----------------------------------------------------------------------------------------------------------
     * JIRA ID- HWCNXCLD-14490
     *
     * Test Description:Validate whether the RX reaches Visual Verify Status after the filling is done for OTC Drug.
     *
     * Pre-Conditions:
     * 1. Drop and Rx and process till Visual Verify queue.
     * 2. Prescribed drug should be OTC type.
     *
     * Author: Achyut Awasthi(vn50v7w)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate whether the RX reaches Visual Verify Status after the filling is done for OTC Drug",
            priority = 1,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/fom/VisualVerifyE2E.json", sheetName = "VisualVerifyE2ETestData")
    public void tc_1_Validation_of_RX_in_VisualVerify_OTC(Map<String, String> inputData)  {

        //Drop an Rx and process till Visual Verify queue
        visualVerifyTestScript1.dropAnRxTillFilling(inputData);

        //Get the Rx number of the dropped Rx
        String rxNbr= visualVerifyTestScript1.getRxNumber(inputData);

        //Verification of Rx in Visual Verify work queue
        visualVerifyTestScript1.verifyRxSearch(rxNbr);
    }

    /*----------------------------------------------------------------------------------------------------------
     * JIRA ID- HWCNXCLD-14491
     *
     * Test Description:Validate whether the RX reaches Visual Verify Status after the filling is done for PSE Drug.
     *
     * Pre-Conditions:
     * 1. Drop and Rx and process till Visual Verify queue.
     * 2. Prescribed drug should be PSE type.
     *
     * Author: Achyut Awasthi(vn50v7w)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate whether the RX reaches Visual Verify Status after the filling is done for PSE Drug",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/fom/VisualVerifyE2E.json", sheetName = "VisualVerifyE2ETestData")
    public void tc_2_Validation_of_RX_in_VisualVerify_PSE(Map<String, String> inputData)  {
        //Drop an Rx and process till Visual Verify queue
        visualVerifyTestScript1.dropAnRxTillFilling(inputData);

        //Get the Rx number of the dropped Rx
        String rxNbr= visualVerifyTestScript1.getRxNumber(inputData);

        //Verification of Rx in Visual Verify work queue
        visualVerifyTestScript1.verifyRxSearch(rxNbr);
    }

    /*----------------------------------------------------------------------------------------------------------
     * JIRA ID- HWCNXCLD-14492
     *
     * Test Description:Validate whether the RX reaches Visual Verify Status after the filling is done for Normal Drug.
     *
     * Pre-Conditions:
     * 1. Drop an Rx and process till Visual Verify queue.
     * 2. Prescribed drug should be Normal type.
     *
     * Author: Achyut Awasthi (vn50v7w)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(priority=3, description = "Validate whether the RX reaches Visual Verify Status after the filling is done for Normal Drug",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/fom/VisualVerifyE2E.json", sheetName = "VisualVerifyE2ETestData")
    public void tc_3_Validation_of_RX_in_VisualVerify_Normal(Map<String, String> inputData)  {
        //Drop an Rx and process till Visual Verify queue
        visualVerifyTestScript1.dropAnRxTillFilling(inputData);

        //Get the Rx number of the dropped Rx
        String rxNbr= visualVerifyTestScript1.getRxNumber(inputData);

        //Verification of Rx in Visual Verify work queue
        visualVerifyTestScript1.verifyRxSearch(rxNbr);
    }

    @AfterClass
    public void tearDown(){
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

}

