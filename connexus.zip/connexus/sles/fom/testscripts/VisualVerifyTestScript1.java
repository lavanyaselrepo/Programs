package connexus.sles.fom.testscripts;

import com.aventstack.extentreports.Status;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuscontext.SearchType;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.models.datamodels.connexus.DropRxModel;
import hwqe.baseframework.models.datamodels.connexus.RxModel;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.Map;

public class VisualVerifyTestScript1 {
    AutomationManager automationManager;
    SoftAssert softAssert = new SoftAssert();
    ConnexusStartPage connexusStartPage;
    F6Search rxSearch;
    VisVerPage VVPage;
    FourPoint fourPoint;
    ChkDur chkDur;
    DropOffPage dropOffPage;
    InputPage inputPage;
    LoginPage loginPage;
    DropRxModel dropRxModel;
    RxModel rxModel;

    public void launchConnexus(LoginAs.userType loginUserType) {
        loginPage = new LoginPage(loginUserType);
        loginPage.loginConnexus(loginUserType);
        automationManager = AutomationManager.getInstance();
        rxSearch=new F6Search();
        VVPage=new VisVerPage();
        dropOffPage=new DropOffPage();
        inputPage=new InputPage();
        chkDur=new ChkDur();
        fourPoint=new FourPoint();
        dropRxModel=new DropRxModel();
        rxModel=new RxModel();
    }

    /*
    Method to perform dropoff to filling for an Rx
    Author: Achyut(vn50v7w)
     */
    public void dropAnRxTillFilling(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            int counter=0;
            dropRxModel.setPatientFirstName(inputData.get("PATIENT_FIRST_NAME"));
            dropRxModel.setPatientLastName(inputData.get("PATIENT_LAST_NAME"));
            dropRxModel.setPriority(Priority.Critical);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setOrderComment(inputData.get("ORDER_COMMENT"));
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);
            rxModel.setPatientFirstName(inputData.get("PATIENT_FIRST_NAME"));
            rxModel.setPatientLastName(inputData.get("PATIENT_LAST_NAME"));
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNdc(inputData.get("DRUG_NAME"));
            rxModel.setPrescribedQty(inputData.get("PRESCRIBED_QTY"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            automationManager.getConnexusWorkFlow().performInput(rxModel);
            String rxNbr=automationManager.getConnexusWorkFlow().performFourPoint(inputData.get("PATIENT_LAST_NAME")+","+inputData.get("PATIENT_FIRST_NAME"));
            automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            automationManager.performSleep(3);
            rxSearch.openSearch();
            rxSearch.performSearch(rxNbr, SearchType.PatientRx);
            while (rxSearch.getWorkQueue(0).equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                counter++;
                rxSearch.sendHotKeys(Keys.F6);
                if (counter >= 10) {
                    break;
                }
            }
            rxSearch.closeSearch();
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        }catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
    Method to get Rx number from Rx search
    Author: Achyut(vn50v7w)
     */
    public String getRxNumber(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String rxNbr=null;
        try {
            rxSearch.performSearch(inputData.get("PATIENT_LAST_NAME")+","+inputData.get("PATIENT_FIRST_NAME"), SearchType.PatientRx);
            rxNbr = rxSearch.getRxNbr(0);
            rxSearch.closeSearch();
        }catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return rxNbr;
    }

    /*
   Method for  VV Page validation
   Author: Achyut(vn50v7w)
    */
    public void verifyRxSearch(String rxNbr){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String actualWorkQue;
            rxSearch.openSearch();
            rxSearch.performSearch(rxNbr,SearchType.PatientRx);
            actualWorkQue = rxSearch.getWorkQueue(0);
            String expectedWorkQue = WorkQueue.VISUAL_VERIFY.getWorkQueue();
            Assert.assertEquals(expectedWorkQue, actualWorkQue.toLowerCase());
            Reporter.logScreenShot(Status.PASS, "Search screenshot ", rxSearch.takeScreenShot("SearchScreenShot").getValue());
            rxSearch.selectRowFromSearch(0);
            automationManager.performSleep(2);
            automationManager.getConnexus().switchWindow();
            if (VVPage.isElementDisplayed(VVPage.ok)) {
                VVPage.click(VVPage.ok);
                automationManager.getConnexus().switchWindow();
            }
            Reporter.logScreenShot(Status.PASS, "VV screenshot ", VVPage.takeScreenShot("RxVisualVerifyScreen").getValue());
            VVPage.click(VVPage.btnAccept);
            rxSearch.openSearch();
            rxSearch.performSearch(rxNbr, SearchType.PatientRx);
            Assert.assertEquals(rxSearch.getWorkQueue(0).toLowerCase(),WorkQueue.BAGGING.getWorkQueue());
            Reporter.logScreenShot(Status.PASS, "Search screenshot ", rxSearch.takeScreenShot("searchScreen").getValue());
            rxSearch.closeSearch();
            automationManager.performSleep(3);
        }catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
}

