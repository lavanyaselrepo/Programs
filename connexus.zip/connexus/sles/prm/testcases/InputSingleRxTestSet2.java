package connexus.sles.prm.testcases;

import connexus.sles.prm.testscripts.InputSingleRxTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.Map;

public class InputSingleRxTestSet2 {
    InputSingleRxTestSetScript inputSingleRxTestSetScript;
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        inputSingleRxTestSetScript = new InputSingleRxTestSetScript();
        inputSingleRxTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() { AutomationManager.getInstance().getConnexus().closeConnexus(); }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: "Verify whether user is able to cancel the Rx by clicking on 'Cancel' button.Once we click on cancel
     * a popup should be displayed with the message "Any changes will be lost.Are you sure you want to cancel?""
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Dharani Ranganathan(vn50qid)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validation of Cancel button in input screen",priority = 1,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_01_CancelButtonValidation(Map<String, String> inputData) {
        System.out.println(">>>tc_01_CancelButtonValidation<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1. Update Flag value to false if not updated and restarting connexus | Flag value 26849 should get updated to false if it is not false before
        if(connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            inputSingleRxTestSetScript = new InputSingleRxTestSetScript();
            inputSingleRxTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }

        //2. Create new patient in Connexus | Connexus should allow user to create new patient
        inputSingleRxTestSetScript.createPatientWithTP(inputData);

        //3.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        inputSingleRxTestSetScript.dropOffRx();

        //4.Search for the rx which is in input queue and enter all the required details. | Connexus should allow user to search and the rx and should be able to enter all the required details successfully
        inputSingleRxTestSetScript.enterInputDetails(inputData);

        //5. After entering all the required details click on Cancel button | Abandon Changes popup should get displayed
        inputSingleRxTestSetScript.clickCancel();

        //6. Get the text in the popup and validate whether the text is as expected | The text displayed after clicking on Cancel button should match with the given text
        inputSingleRxTestSetScript.cancelButtonValidation(inputData);

        //7. Clicking on No button in the cancel popup | Abandon Changes popup should get closed and Rx should remain in input screen
        inputSingleRxTestSetScript.clickNoCancel();

        System.out.println("<<<tc_01_CancelButtonValidation>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: "To validate if user is able to see the Patient's preferred language in Language text in Input screen."
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.A valid patient profile is already created
    *
    * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validation of Language text in Input screen",priority = 2,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_02_LanguageValidation(Map<String, String> inputData) {
        System.out.println(">>>tc_02_LanguageValidation<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        //2.Search for the rx which is in input queue and enter all the required details. | Connexus should allow user to search and the rx and should be able to enter all the required details successfully
        //3. Validating the language in Input screen with Patient maintenance screen| Language in input screen should match with Patient Maintenance screen
        inputSingleRxTestSetScript.languageValidation(inputData);

        System.out.println("<<<tc_02_LanguageValidation>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: "Create a patient profile and drop a prescription with 1 rx and verify when the patient profile moves to Input screen ,
    * user could see the value in the "No of Rx's" filed as 1."
    *
    * Pre-Conditions:
    * 1.User is logged into Connexus
    * 2.A valid patient profile is already created
    *
    * Author: Dharani Ranganathan(vn50qid)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validation of No of RX's field for single RX",priority = 3,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_03_SingleRxValidation(Map<String, String> inputData) {
        System.out.println(">>>tc_03_SingleRxValidation<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        //2.Search for the rx which is in input queue and enter all the required details. | Connexus should allow user to search and the rx and should be able to enter all the required details successfully
        //3. Validating No of RX's field for single RX | No of Rx should contain the value 1 for Single Rx
        inputSingleRxTestSetScript.noOfRxValidationForSingleRx();

        System.out.println("<<<tc_03_SingleRxValidation>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: "Verify whether the user is able to see Pack size of the product in the product/Item grid
     * after entering product name in the 'Prescribed Product' field and QTY."
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Dharani Ranganathan(vn50qid)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validation of Pack Size after entering Product and Qty",priority = 4,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_04_PackSizeValidation(Map<String, String> inputData){
        System.out.println(">>>tc_04_PackSizeValidation<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        //2.Search for the rx which is in input queue and enter all the required details. | Connexus should allow user to search and the rx and should be able to enter all the required details successfully
        //3.Validate whether pack size is getting displayed after entering product and qty | Pack size should get displayed in input screen after entering product and qty and should match with the product screen
        inputSingleRxTestSetScript.packSizeValidation();

        System.out.println("<<<tc_04_PackSizeValidation>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: "Verify whether user is able to select Non schedule Drug from Input screen.
     * Rx expiry date should be calculated as 12 months from written date."
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Dharani Ranganathan(vn50qid)
     ----------------------------------------------------------------------------------------------------------*/    @Test(description = "Validation of expiry Date for Non Controlled drugs",priority = 5,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_05_RxExpiryDateValidationNonControlledDrugs(Map<String, String> inputData) {
        System.out.println(">>>tc_05_RxExpiryDateValidationNonControlledDrugs<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        //2.Search for the rx which is in input queue and enter all the required details. | Connexus should allow user to search and the rx and should be able to enter all the required details successfully
        //3. Validating whether the expiry Date is calculated for 12 months for Non Controlled Drugs | Expiry date should get calculated for 12 months for non controlled drugs
        inputSingleRxTestSetScript.expiryDateValidation_Months(inputData);

        System.out.println("<<<tc_05_RxExpiryDateValidationNonControlledDrugs>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: "VVerify whether user is able to enter Non Controlled drug in product details field and
     * User should be able to verify the Rx expiry date that is calculated based on the controlled drug"
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Dharani Ranganathan(vn50qid)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Adding Non Controlled drugs in Input screen",priority = 6,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_06_AddingNonControlledDrugsInInputScreen(Map<String, String> inputData) {
        System.out.println(">>>tc_06_AddingNonControlledDrugsInInputScreen<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        //2.Search for the rx which is in input queue and enter all the required details. | Connexus should allow user to search and the rx and should be able to enter all the required details successfully
        //3. Validating whether the user is able to add non controlled drugs in the product field in input screen | Connexus should allow user to add non controlled drug in the product field in input screen
        inputSingleRxTestSetScript.expiryDateValidation_Months(inputData);

        //4. Click Cancel and close this order from Input screen | Rx should be closed from Input screen
        inputSingleRxTestSetScript.inputScreenCancelButtonPopupValidation(inputData);

        System.out.println("<<<tc_06_AddingNonControlledDrugsInInputScreen>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: "Verify whether  user is able to enter more than two digit numeric number in the refill field in input screen.
     * User should not be able to enter value greater than 99.If we enter more than two digit it will take the first 2-digit as refills."
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Dharani Ranganathan(vn50qid)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validation of length of Refill field",priority = 7,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_07_RefillLengthValidation(Map<String, String> inputData) {
        System.out.println(">>>tc_07_RefillLengthValidation<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        //2.Search for the rx which is in input queue and enter all the required details. | Connexus should allow user to search and the rx and should be able to enter all the required details successfully
        inputSingleRxTestSetScript.enterInputDetails(inputData);

        //3. Validating whether the refill field is accepting max 2 digits even if we provide more than 3 digits as an input | Refill field in Input screen should accept max 2 digits
        inputSingleRxTestSetScript.refillLengthValidation();

        //4. Click Cancel and close this order from Input screen | Rx should be closed from Input screen
        inputSingleRxTestSetScript.inputScreenCancelButtonPopupValidation(inputData);

        System.out.println("<<<tc_07_RefillLengthValidation>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
 * Test Description: "Verify whether user is able to enter P#  where #-value is between 1 and 6.User should be able to enter the value from 1 to 6.
 * Expiry date should be calculated based on value # from the written date."
 *
 * Pre-Conditions:
 * 1.User is logged into Connexus
 * 2.A valid patient profile is already created
 *
 * Author: Dharani Ranganathan(vn50qid)
 ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validation of Expiry Date for Refills from P1 to P6",priority = 8,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_08_ValidationOfExpiryDateForP1TO6(Map<String, String> inputData) {
        System.out.println(">>>tc_08_ValidationOfExpiryDateForP1TO6<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        //2. Validating expiry date for refill as Pl to P6 | Expiry date should be calculated as 1 - 6 months for Refill as P1 to P6
        inputSingleRxTestSetScript.expiryDateP1ToP6(inputData);

        //3. Click Cancel and close this order from Input screen | Rx should be closed from Input screen
        inputSingleRxTestSetScript.inputScreenCancelButtonPopupValidation(inputData);

        System.out.println("<<<tc_08_ValidationOfExpiryDateForP1TO6>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: "Verify if Rx expire date is calculated for 21 days for C2 drugs when state is set as TX.
     * User should be able to verify the Rx expiry date that is calculated as 21 days for C2 drug"
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Dharani Ranganathan(vn50qid)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validation of expiry date for C2 drug_TX",priority = 9,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_09_ValidationOfC2DrugTX(Map<String, String> inputData) {
        System.out.println(">>>tc_09_ValidationOfC2DrugTX<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        //2. Updating state in bus_unit_addr table | State should be updated to TX in bus_unit_addr table
        inputSingleRxTestSetScript.checkCurrentStateAndupdateStoreState(inputData);

        //3. Closing Connexus | Connexus should be closed
        tearDown();

        //4. Relaunching connexus | Connexus should allow user to relaunch and login connexus
        inputSingleRxTestSetScript = new InputSingleRxTestSetScript();
        inputSingleRxTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);

        //5. Validating the expiry date after updating the state | Expiry Date should be 21 days for C2 drug when state is TX
        inputSingleRxTestSetScript.validateExpiryDate_C2(inputData);

        //6. Click Cancel and close this order from Input screen | Rx should be closed from Input screen
        inputSingleRxTestSetScript.inputScreenCancelButtonPopupValidation(inputData);

        System.out.println("<<<tc_09_ValidationOfC2DrugTX>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: "Verify if Rx expire date is calculated for 180 days for C3-C5 drugs when state is set as TX.
     * User should be able to verify the Rx expiry date that is calculated as 365 days for C3-C5 drug"
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Dharani Ranganathan(vn50qid)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validation of expiry date for C3 to C5 drug_TX",priority = 10,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation","tc_09_ValidationOfC2DrugTX"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_10_ValidationOfC3ToC5DrugTX(Map<String, String> inputData) {
        System.out.println(">>>tc_10_ValidationOfC3ToC5DrugTX<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        //2. Updating state in bus_unit_addr table | State should be updated to TX in bus_unit_addr table
        //3. Closing Connexus | Connexus should be closed
        //4. Relaunching connexus | Connexus should allow user to relaunch and login connexus
        //5. Validating the expiry date after updating the state | Expiry Date should be 180 days for C3 to C5 drug when state is TX
        inputSingleRxTestSetScript.validateExpiryDate_C3ToC5(inputData);

        //6. Click Cancel and close this order from Input screen | Rx should be closed from Input screen
        inputSingleRxTestSetScript.inputScreenCancelButtonPopupValidation(inputData);

        System.out.println("<<<tc_10_ValidationOfC3ToC5DrugTX>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: "Verify whether user is able to select schedule III, IV, V Drug. Rx expiry date should be calculated as 6 months from written date."
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Dharani Ranganathan(vn50qid)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validation of expiry Date for Schedule 3 to 5 drugs ",priority = 11,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_11_RxExpiryDateForSchedule3TO5(Map<String, String> inputData) {
        System.out.println(">>>tc_11_RxExpiryDateForSchedule3TO5<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        //2. Validating whether the expiry date is calculated as 6 months for C3 to C5 drugs | Expiry Date should be calculated for 6 months for C3 to C5 drug
        inputSingleRxTestSetScript.validateExpiryDate_In_Months_C3ToC5(inputData);

        //3. Click Cancel and close this order from Input screen | Rx should be closed from Input screen
        inputSingleRxTestSetScript.inputScreenCancelButtonPopupValidation(inputData);

        System.out.println("<<<tc_11_RxExpiryDateForSchedule3TO5>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: "Verify whether user is able to enter Schedule III, IV, V drug in product details field and
     * User should be able to verify the Rx expiry date that is calculated based on the controlled drug"
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Dharani Ranganathan(vn50qid)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Adding Schedule 3 to 5 drugs in Input screen",priority = 12,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_12_AddingSchedule3TO5InInputScreen(Map<String, String> inputData) {
        System.out.println(">>>tc_12_AddingSchedule3TO5InInputScreen<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        //2. Validating whether the user is able to add C3 to C5 drugs in the product field in input screen | Connexus should allow user to add C3 to C5 drug in the product field in input screen
        inputSingleRxTestSetScript.validateExpiryDate_In_Months_C3ToC5(inputData);

        //3. Click Cancel and close this order from Input screen | Rx should be closed from Input screen
        inputSingleRxTestSetScript.inputScreenCancelButtonPopupValidation(inputData);

        System.out.println("<<<tc_12_AddingSchedule3TO5InInputScreen>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: "Verify whether we can select an option from the dropdown of DAW field.
     * Once we select the DAW field the product details should be displayed according to the DAW we selected."
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Dharani Ranganathan(vn50qid)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validation of DAW field in Input screen",priority = 13,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_13_DAWValidation(Map<String, String> inputData){
        System.out.println(">>>tc_13_DAWValidation<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        //2.Search for the rx which is in input queue and enter all the required details. | Connexus should allow user to search and the rx and should be able to enter all the required details successfully
        inputSingleRxTestSetScript.enterInputDetails(inputData);

        //3. Validating whether the user is able to select different DAW values in Input screen | Connexus should allow user to select DAW values in Input screen
        inputSingleRxTestSetScript.validate_DAW();

        //4. Click Cancel and close this order from Input screen | Rx should be closed from Input screen
        inputSingleRxTestSetScript.inputScreenCancelButtonPopupValidation(inputData);

        System.out.println("<<<tc_13_DAWValidation>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: "Verify if user is able to enter P (can be filled as many times needed) in Input screen."
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Dharani Ranganathan(vn50qid)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validation of Refill as P",priority = 14,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_14_ValidationOfRefillAsP(Map<String, String> inputData) {
        System.out.println(">>>tc_14_ValidationOfRefillAsP<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        //2.Search for the rx which is in input queue and enter all the required details. | Connexus should allow user to search and the rx and should be able to enter all the required details successfully
        inputSingleRxTestSetScript.enterInputDetails(inputData);

        //3. Verify whether the user is able to click on accept button when refill is filled as P | Connexus should allow user to Accept the Input while passing refill as P
        inputSingleRxTestSetScript.inputScreenAccept();

        System.out.println("<<<tc_14_ValidationOfRefillAsP>>>");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: "Verify if user is able to enter PRN (can be filled as many times needed) in Input screen."
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Dharani Ranganathan(vn50qid)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validation of Refill as PRN",priority = 15,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelButtonValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet2")
    public void tc_15_ValidationOfRefillAsPRN(Map<String, String> inputData) {
        System.out.println(">>>tc_15_ValidationOfRefillAsPRN<<<");

        //Pre-Conditions
        //1.User is logged into Connexus
        //2.A valid patient profile is already created

        //1.Drop an Rx from dropoff screen | Connexus should allow the user to drop an Rx from dropoff screen
        inputSingleRxTestSetScript.dropOffRx();

        //2.Search for the rx which is in input queue and enter all the required details. | Connexus should allow user to search and the rx and should be able to enter all the required details successfully
        inputSingleRxTestSetScript.enterInputDetails(inputData);

        //3. Verify whether the user is able to click on accept button when refill is filled as PRN | Connexus should allow user to Accept the Input while passing refill as PRN
        inputSingleRxTestSetScript.inputScreenAccept();

        System.out.println("<<<tc_15_ValidationOfRefillAsPRN>>>");
    }
    
}