package connexus.sles.prm.testcases;

import connexus.sles.prm.testscripts.InputSingleRxTestSetScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.Map;

public class InputSingleRxTestSet1 {
    InputSingleRxTestSetScript inputSingleRxTestSetScript =new InputSingleRxTestSetScript();
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeTestMethods() {
        connexusAppUtils = new ConnexusAppUtils();
        inputSingleRxTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: To verify whether 'Abandon changes?' popup is displayed if we click on cancel button in input screen.It should show the prompt message with 'yes' or 'no' buttons." +
            "Once we click on NO the rx should return back to input screen if click on  YES the Rx changes should be deleted
     *
     * JIRA ID : HWQEAUTO-8907
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Janani Co(vn50stx)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "To verify whether 'Abandon changes?' popup is displayed if we click on cancel button in input screen." +
            "It should show the prompt message with 'yes' or 'no' buttons." +
            "Once we click on NO the rx should return back to input screen if click on  YES the Rx changes should be deleted",
            priority =1,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet1")
    public void tc_01_CancelPopupValidation(Map<String, String> inputData){
        System.out.println(">>>tc_01_CancelPopupValidation<<<");

        //Pre-Conditions
        //1.User is logged into Connexus | Connexus should allow the user to log in
        //2.A valid patient profile is already created | ConnexUs should either find the patient or allow the user to create a new patient
        //Update flag value 26849 to false | If the Flag 26849 value is true connexus should change it to false.
        if(connexusAppUtils.readAndUpdateFlag("26849","TRUE")){
            tearDown();
            inputSingleRxTestSetScript = new InputSingleRxTestSetScript();
            inputSingleRxTestSetScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        }
        inputSingleRxTestSetScript.createPatientWithTP(inputData);

        //1.Drop an Rx from dropoff screen | User should able to drop an Rx from dropoff screen
        inputSingleRxTestSetScript.dropOffRx();

        //2.Search for the rx which is in input queue and enter all the required details. | User should able to enter all the required details in input screen
        inputSingleRxTestSetScript.enterInputDetails(inputData);

        //3. After entering all the required details click on Cancel button | User should able to click on Cancel Button
        //4.Click on Yes in the popup displayed. | A popup should be displayed and user should able to cancel and close the input screen by clicking on 'Yes'
        inputSingleRxTestSetScript.inputScreenCancelButtonPopupValidation(inputData);

        System.out.println(">>>tc_01_CancelPopupValidation<<<");
    }
     /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify whether user could able to enter C2 drug when the prescriber's DEA authority has been expired.
       User should able to see a "Invalid Prescriber Authority -popup" while clicking on Accept.The message 'Prescriber does not have authority to prescribe schedule (2) drug.
        1.Validate prescriber
        2.Update from host
        If not changed,Rx will be sent to Resolution for validation" should be displayed.After clicking on 'Ok' Rx should move to resolution screen."
     *
     * JIRA ID : HWQEAUTO-8998
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Janani Co(vn50stx)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description ="Verify whether user could able to enter C2 drug when the prescriber's DEA authority has been expired."+
            "User should able to see a Invalid Prescriber Authority -popup while clicking on Accept.The message 'Prescriber does not have authority to prescribe schedule (2) drug.'"+
            "1.Validate prescriber"+
            "2.Update from host"+
            "If not changed,Rx will be sent to Resolution for valildation should be displayed.After clicking on 'Ok' Rx should move to resolution screen."
            ,priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",dependsOnMethods = {"tc_01_CancelPopupValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet1")
    public  void tc_02_ExpiredDEAPrescriberValidation(Map<String, String> inputData){
        System.out.println(">>>tc_02_ExpiredDEAPrescriberValidation<<<");

        //Pre-Conditions
        //1.User is logged into Connexus | Connexus should allow the user to log in
        //2.A valid patient profile is already created | ConnexUs should either find the patient or allow the user to create a new patient
        //3.Drop an Rx from dropoff screen | User should able to drop an Rx from dropoff screen

        //1.Search for the rx which is in input queue and enter all the required details along with DEA expired prescriber name | User should able to enter all the required details in input screen
        inputSingleRxTestSetScript.enterInputDetails(inputData);

        //2.Change the drug name to C2 drug.| Connexus should allow the user to change the C2 drug
        //3.Validate whether user could able to see a "Invalid Prescriber Authority -popup" while clicking on Accept.
        // The message 'Prescriber does not have authority to prescribe schedule (2) drug.
        //        1.Validate prescriber
        //        2.Update from host
        // If not changed,Rx will be sent to Resolution for validation" should be displayed. | User should able to validate the popup message.
        inputSingleRxTestSetScript.expiredDEAPrescriberPopUpValidation(inputData);

        //4.Click on cancel from input screen for the newly added rx.| User should able to click on Cancel Button and close the input screen
        inputSingleRxTestSetScript.inputScreenCancelButtonPopupValidation(inputData);

        System.out.println(">>>tc_02_ExpiredDEAPrescriberValidation<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify whether user is able to 'Add Rx' if the prescription has more than one product.
     * Once we click on add Rx button, the number has to be populated in the No of Rx's field and a new Rx has
     * to be created in the input screen.when you click rx will be added and the 0 of rx field value increases
     * and also in the top of the screen Input x of x also changes.
     *
     * JIRA ID : HWQEAUTO-8727
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created

     * Author: Janani Co(vn50stx)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description ="Verify whether user is able to 'Add Rx' if the prescription has more than one product."+
            " Once we click on add Rx button, the number has to be populated in the No of Rx's field and a new Rx has"+
            " to be created in the input screen.when you click rx will be added and the 0 of rx field value increases"+
            " and also in the top of the screen Input x of x also changes.",priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",dependsOnMethods = {"tc_01_CancelPopupValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet1")
    public  void tc_03_AddRxButtonValidation(Map<String, String> inputData){
        System.out.println(">>>tc_03_AddRxButtonValidation<<<");

        //Pre-Conditions
        //1.User is logged into Connexus | Connexus should allow the user to log in
        //2.A valid patient profile is already created | ConnexUs should either find the patient or allow the user to create a new patient
        //3.Drop an Rx from dropoff screen | User should able to drop an Rx from dropoff screen

        //1.Search for the rx which is in input queue and enter all the required details. | User should able to enter all the required details in input screen
        inputSingleRxTestSetScript.enterInputDetails(inputData);

        //2.Click on Add Rx button. | Connexus should allow user to click on Add Rx button
        //3.Validate the new rx will be added and the 0 of rx field value increases and also in the top of the screen Input x of x also changes. | User should validate the no of rx get increased.
        inputSingleRxTestSetScript.addRxButtonValidation();

        //4.Click on Input Accept button.| Connexus should allow user to click on Accept button from input screen
        inputSingleRxTestSetScript.inputScreenAccept();

        //5.Click on cancel from input screen for the newly added rx.| User should able to click on Cancel Button and close the input screen
        inputSingleRxTestSetScript.inputScreenCancelButtonPopupValidation(inputData);

        System.out.println(">>>tc_03_AddRxButtonValidation<<<");
    }

     /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify if user is able to enter
     * any positive numeric value including 0 in Input screen.
     *
     * JIRA ID : HWQEAUTO-8802
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Janani Co(vn50stx)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify if user is able to enter any positive numeric value including 0 in Input screen.",priority =4,
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",dependsOnMethods = {"tc_01_CancelPopupValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet1")
    public void tc_04_Refill_As_PositiveNumber(Map<String, String> inputData){
        System.out.println(">>>tc_04_Refill_As_PositiveNumber<<<");

        //Pre-Conditions
        //1.User is logged into Connexus | Connexus should allow the user to log in
        //2.A valid patient profile is already created | ConnexUs should either find the patient or allow the user to create a new patient

        //1.Drop an Rx from dropoff screen | User should able to drop an Rx from dropoff screen
        inputSingleRxTestSetScript.dropOffRx();

        //2.Search for the rx which is in input queue and enter all the required details. | User should able to enter all the required details in input screen
        inputSingleRxTestSetScript.enterInputDetails(inputData);

        //3.Enter Alphabetical characters in the refill field | Connexus should not accept Alphabetical characters in the refill field
        inputSingleRxTestSetScript.validateRefillAsAlphabeticalCharacter(inputData);

        //4.Enter Special characters in the refill field | Connexus should not accept Special characters in the refill field
        inputSingleRxTestSetScript.validateRefillAsSpecialCharacter(inputData);

        //5.Enter 0 or any positive numeric value in the refill field| Connexus should  accept 0 or any positive numeric value in the refill field
        inputSingleRxTestSetScript.validateRefillAsPositiveNumericValue(inputData);

        System.out.println(">>>tc_04_Refill_As_PositiveNumber<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify whether user is not allowed to enter P#  where #-value is greater than 6.
     * User should not be able to enter the value greater than 6,since #can take values from 1-6.
     *
     * JIRA ID : HWQEAUTO-8914
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Janani Co(vn50stx)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify whether user is not allowed to enter P#  where #-value is greater than 6." +
            "User should not be able to enter the value greater than 6,since #can take values from 1-6.",
            priority =5,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",dependsOnMethods = {"tc_01_CancelPopupValidation","tc_04_Refill_As_PositiveNumber"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet1")
    public void tc_05_Refill_As_P(Map<String, String> inputData){
        System.out.println(">>>tc_05_Refill_As_P<<<");

        //Pre-Conditions
        //1.User is logged into Connexus | Connexus should allow the user to log in
        //2.A valid patient profile is already created | ConnexUs should either find the patient or allow the user to create a new patient
        //3.Drop an Rx from dropoff screen | User should able to drop an Rx from dropoff screen
        //4.Search for the rx which is in input queue and enter all the required details. | User should able to enter all the required details in input screen

        //1.Enter P#  where #-value is greater than 6. | User should not be able to enter the value greater than 6,since #can take values from 1-6.
        //2.Enter P in refill field along with the month where # less than or equal to 6.| User should able to enter P (can be filled as many times needed) in Input screen where # less than or equal to 6..
        inputSingleRxTestSetScript.validateRefillAsP1toP6Value(inputData);

        System.out.println(">>>tc_05_Refill_As_P<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
     * Verify whether user can view the details of all Rx for an order.Once we click on 'Show Order' button
     * Show order grid should be displayed with the Rx work queues,Status,Product information,Wrokstation,Store no.#
     *
     * JIRA ID : HWQEAUTO-8951
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Janani Co(vn50stx)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify whether user can view the details of all Rx for an order.Once we click on 'Show Order' button" +
            " Show order grid should be displayed with the Rx work queues,Status,Product information,Workstation,Store no.#",
            priority =6,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",dependsOnMethods = {"tc_01_CancelPopupValidation","tc_04_Refill_As_PositiveNumber"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet1")
    public void tc_06_validateShowOrderButton(Map<String, String> inputData){
        System.out.println(">>>tc_06_validateShowOrderButton<<<");

        //Pre-Conditions
        //1.User is logged into Connexus | Connexus should allow the user to log in
        //2.A valid patient profile is already created | ConnexUs should either find the patient or allow the user to create a new patient
        //3.Drop an Rx from dropoff screen | User should able to drop an Rx from dropoff screen
        //4.Search for the rx which is in input queue and enter all the required details. | User should able to enter all the required details in input screen

        //1.Click on Show order button | Show order grid should be displayed with the Rx work queues,Status,Product information,Wrokstation,Store no.#
        inputSingleRxTestSetScript.showOrderButtonValidation(inputData);

        System.out.println(">>>tc_06_validateShowOrderButton<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify whether user is able to send the Prescription to trouble shoot.Once we click
     * the 'Send to Resolution' button the dropdown has to populate with several options and by selecting an option
     * the rx should move to the resolution screen.
     *
     * JIRA ID : HWQEAUTO-8888
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Janani Co(vn50stx)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify whether user is able to send the Prescription to trouble shoot.Once we click " +
            "the 'Send to Resolution' button the dropdown has to populate with several options and by selecting an option" +
            "the rx should move to the resolution screen.",priority =7,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",
            dependsOnMethods = {"tc_01_CancelPopupValidation","tc_04_Refill_As_PositiveNumber"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet1")
    public void tc_07_validateSendToResolutionButton(Map<String, String> inputData){
        System.out.println(">>>tc_07_validateSendToResolutionButton<<<");

        //Pre-Conditions
        //1.User is logged into Connexus | Connexus should allow the user to log in
        //2.A valid patient profile is already created | ConnexUs should either find the patient or allow the user to create a new patient
        //3.Drop an Rx from dropoff screen | User should able to drop an Rx from dropoff screen
        //4.Search for the rx which is in input queue and enter all the required details. | User should able to enter all the required details in input screen

        //1.Click on Send to resolution Button | User should able to click on Send to resolution button
        inputSingleRxTestSetScript.sendToResolutionButton(inputData);

        //2.Click on'Illegible image' from the dropdown.| Rx should move to Resolution queue.
        inputSingleRxTestSetScript.validateRxMoveToResolution(inputData);

        System.out.println(">>>tc_07_validateSendToResolutionButton<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify whether the patient details are displayed in the patient grid in input screen after
     * entering the patient name in the Name field and click on 'Enter'.
     * User should able to verify the patient details.
     *
     * JIRA ID : HWQEAUTO-8975
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Janani Co(vn50stx)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify whether the patient details are displayed in the patient grid in input screen after" +
            " entering the patient name in the Name field and click on 'Enter'." +
            " User should able to verify the patient details.",priority =8,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",dependsOnMethods = {"tc_01_CancelPopupValidation"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet1")
    public void tc_08_validate_patient_details(Map<String, String> inputData){
        System.out.println(">>>tc_08_validate_patient_details<<<");

        //Pre-Conditions
        //1.User is logged into Connexus | Connexus should allow the user to log in
        //2.A valid patient profile is already created | ConnexUs should either find the patient or allow the user to create a new patient

        //1.Drop an Rx from dropoff screen | User should able to drop an Rx from dropoff screen
        inputSingleRxTestSetScript.dropOffRx();

        //2.Search for the rx which is in input queue and enter all the required details. | User should able to enter all the required details in input screen
        inputSingleRxTestSetScript.enterInputDetails(inputData);

        //3.Validate the patient details displayed in input screen.| User should able to validate the patient details in input screen
        inputSingleRxTestSetScript.patientDetailsValidation(inputData);

        System.out.println(">>>tc_08_validate_patient_details<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify whether user is able to search and select the prescriber by entering the name of
     * prescriber in the Name/DEA/NPI field.
     * User should be able to see prescriber details such as Prescriber's Name, Address, DEA, NPI,
     * Phone on selecting prescriber in Input screen.
     *
     * JIRA ID : HWQEAUTO-8937
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Janani Co(vn50stx)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify whether user is able to search and select the prescriber by entering the name of" +
            " prescriber in the Name/DEA/NPI field." +
            " User should be able to see prescriber details such as Prescriber's Name, Address, DEA, NPI,Phone on selecting prescriber in Input screen.",
            priority =9,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",dependsOnMethods = {"tc_01_CancelPopupValidation","tc_08_validate_patient_details"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet1")
    public void tc_09_validate_prescriber_details(Map<String, String> inputData){
        System.out.println(">>>tc_09_validate_prescriber_details<<<");

        //Pre-Conditions
        //1.User is logged into Connexus | Connexus should allow the user to log in
        //2.A valid patient profile is already created | ConnexUs should either find the patient or allow the user to create a new patient
        //3.Drop an Rx from dropoff screen | User should able to drop an Rx from dropoff screen
        //4.Search for the rx which is in input queue and enter all the required details. | User should able to enter all the required details in input screen

        //1.Validate the prescriber details in input| User should able to validate the prescriber details in input screen
        inputSingleRxTestSetScript.prescriberDetailsValidation(inputData);

        System.out.println(">>>tc_09_validate_prescriber_details<<<");
    }
    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Verify the product details displayed in the product/Item grid after entering product name
     * in the 'Prescribed Product' field.
     * User should able to enter the prescribed product and select the product from product search screen.
     *
     * JIRA ID : HWQEAUTO-8934
     *
     * Pre-Conditions:
     * 1.User is logged into Connexus
     * 2.A valid patient profile is already created
     *
     * Author: Janani Co(vn50stx)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify the product details displayed in the product/Item grid after entering product name" +
            " in the 'Prescribed Product' field." +
            " User should able to enter the prescribed product and select the product from product search screen."
            ,priority =10,dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap",dependsOnMethods = {"tc_01_CancelPopupValidation","tc_08_validate_patient_details"})
    @DataProviderArguments(filePath = "TestData/Connexus/sles/prm/InputSingleRxTestData.json", sheetName = "InputSingleRxTestSet1")
    public void tc_10_validate_product_details(Map<String, String> inputData){
        System.out.println(">>>tc_10_validate_product_details<<<");

        //Pre-Conditions
        //1.User is logged into Connexus | Connexus should allow the user to log in
        //2.A valid patient profile is already created | ConnexUs should either find the patient or allow the user to create a new patient
        //3.Drop an Rx from dropoff screen | User should able to drop an Rx from dropoff screen
        //4.Search for the rx which is in input queue and enter all the required details. | User should able to enter all the required details in input screen

        //1.Validate the product details in input | User should able to validate the product details in input screen
        inputSingleRxTestSetScript.productDetailsValidation(inputData);

        //2.Click on Input Accept button.| Connexus should allow user to click on Accept button from input screen
        inputSingleRxTestSetScript.inputScreenAccept();

        System.out.println(">>>tc_10_validate_product_details<<<");
    }
    @AfterClass
    public void tearDown() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }
}