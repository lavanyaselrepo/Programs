package connexus.sles.prm.testscripts;

import com.aventstack.extentreports.Status;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuscontext.SearchType;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import org.junit.Assert;
import org.testng.asserts.SoftAssert;

import java.text.SimpleDateFormat;
import java.util.*;

public class InputSingleRxTestSetScript {

    SoftAssert softAssert = new SoftAssert();
    ConnexusStartPage connexusStartPage;
    InputPage inputPage;
    PatientMaintenancePage patientMaintenancePage;
    AutomationManager automationManager;
    LoginPage loginPage;
    DropOffPage dropOff;
    F6Search rxSearch;
    ProductMaintenancePage productMaintenancePage;
    ConnexusAppUtils connexusAppUtils;
    DropRxModel dropRxModel;

    public void loginConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        dropOff = new DropOffPage();
        inputPage = new InputPage();
        patientMaintenancePage = new PatientMaintenancePage();
        connexusStartPage = new ConnexusStartPage();
        rxSearch = new F6Search();
        productMaintenancePage = new ProductMaintenancePage();
        connexusAppUtils = new ConnexusAppUtils();
        dropRxModel = new DropRxModel();
        automationManager = AutomationManager.getInstance();
        loginPage.loginConnexus(userType);
    }

    public void createPatientWithTP(Map<String, String> inputData) {
        PatientProfileModel patient = new PatientProfileModel();
        AddressModel addressModel = new AddressModel();
        ContactModel contactModel = new ContactModel();
        PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
        PatientIdentityModel patientIdentityModel = new PatientIdentityModel();
        ThirdPartyModel thirdPartyModel=new ThirdPartyModel();

        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();

        patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
        patient.setPatientFirstName(name[1]);
        patient.setPatientLastName(name[0]);
        patient.setPatientDob(inputData.get("PAT_DOB"));
        patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

        addressModel.setPatientAddressLine1(inputData.get("PAT_ADDRESS_LINE1"));
        addressModel.setPatientCity(inputData.get("CITY"));
        addressModel.setPatientState(inputData.get("STATE"));
        addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
        addressModel.setPatientCountry(inputData.get("COUNTRY"));

        patient.setPatientAddress(addressModel);

        contactModel.setPatientPhoneNumber1(inputData.get("PHONE_NUMBER1"));
        contactModel.setPatientPhoneNumber2(inputData.get("PHONE_NUMBER2"));
        contactModel.setPatientPhoneNumber3(inputData.get("PHONE_NUMBER3"));
        contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
        contactModel.setPreferredPhoneNumber(ContactModel.PreferredPhoneNumber.PHONE_NUMBER1);

        patient.setPatientContact(contactModel);

        thirdPartyModel.setCarrierBin(inputData.get("PAT_CARRIER"));
        thirdPartyModel.setPlan(inputData.get("PAT_PLAN"));
        thirdPartyModel.setCardId(inputData.get("PAT_CARD_ID"));

        patient.setPatientTp(thirdPartyModel);

        patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
        patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
        patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));

        patient.setPatientIdentityModel(patientIdentityModel);

        patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
        patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);

        patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

        automationManager.getConnexusWorkFlow().searchAndCreatePatient(true, patient);
    }

    public void dropOffRx(){
        DropRxModel dropRxModel = new DropRxModel();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);
    }

    /*
     * Method to enter required details in Input screen.
     *
     * Author: Janani C(vn50stx)
     * */
    public void enterInputDetails(Map<String, String> inputData) {
        rxSearch.openSearch();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        rxSearch.performSearch(name[0]+","+name[1], SearchType.PatientRx);
        rxSearch.selectRowFromSearch(0);
        automationManager.performSleep(1);
        inputPage.enterProductNameInPrescribedProduct(inputData.get("DRUG_NAME"));
        inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
        inputPage.enterSigCode(inputData.get("SIG"));
        inputPage.enterRefillQty(inputData.get("REFILLS"));
        inputPage.selectDAW(1);
        inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
        automationManager.performSleep(1);
    }

    /*
     * Method to click on Cancel button from Input screen and to validate the popup message on clicking of cancel button.
     *
     * Author: Janani C(vn50stx)
     * */
    public void inputScreenCancelButtonPopupValidation(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickCancel();
            inputPage.switchWindow();
            if(inputPage.getInputScreenPopupMessage().contains(inputData.get("MESSAGE"))){
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                inputPage.clickInputCancelYesButton();
            }else{
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to click on Accept button from input screen.
     *
     * Author: Janani C(vn50stx)
     * */
    public void inputScreenAccept() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickAccept();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to validate the DEA Expired Prescriber popup message.
     *
     * Author: Janani C(vn50stx)
     * */
    public void expiredDEAPrescriberPopUpValidation(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clearPrescribedProduct();
            inputPage.enterNdc(inputData.get("C2_DRUG"));
            inputPage.switchWindow();
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            if (inputPage.getInputScreenPopupMessage().contains(inputData.get("POPUP"))){
                inputPage.clickOKButtonDEAPopup();
            }
            else{
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to click on Add Rx button and validation of Rx added in No. of Rx's field in input screen.
     *
     * Author: Janani C(vn50stx)
     * */
    public void addRxButtonValidation(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Integer noOfRxBefore = Integer.parseInt(inputPage.getTextnoOfRxField());
            inputPage.clickAddRxButton();
            Integer noOfRxAfter = Integer.parseInt(inputPage.getTextnoOfRxField());
            if (noOfRxBefore < noOfRxAfter) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
            else{
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to validate Refill field not accepting Alphabetical Character.
     *
     * Author: Janani C(vn50stx)
     * */
    public void validateRefillAsAlphabeticalCharacter(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clearRefillField();
            inputPage.enterRefillQty(inputData.get("REFILL_AS_TEXT"));
            if (inputPage.getRefillSize() == 0) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
            else{
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to validate Refill field not accepting Special Character
     *
     * Author: Janani C(vn50stx)
     * */
    public void validateRefillAsSpecialCharacter(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clearRefillField();
            inputPage.enterRefillQty(inputData.get("REFILL_AS_SPECIALCHAR"));
            if (inputPage.getRefillSize() == 0) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
            else{
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to validate Refill field accepting Numeric value.
     *
     * Author: Janani C(vn50stx)
     * */
    public void validateRefillAsPositiveNumericValue(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clearRefillField();
            inputPage.enterRefillQty(inputPage.generateRefill(Integer.parseInt(inputData.get("REFILL_AS_POSITIVENUMBER"))));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to validate Refill field not accepting Value greater than P6
     *
     * Author: Janani C(vn50stx)
     * */
    public void validateRefillAsP1toP6Value(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clearRefillField();
            inputPage.enterRefillQty(inputData.get("REFILL_AS_P7"));
            if (inputPage.getRefillSize() == 1) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                inputPage.enterRefillQty(inputPage.generateRefill(Integer.parseInt(inputData.get("REFILL_AS_POSITIVENUMBER"))));
                automationManager.performSleep(1);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
            else{
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to validate Patient details displayed in input screen is valid
     *
     * Author: Janani C(vn50stx)
     * */
    public void patientDetailsValidation(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String planName= inputPage.getPlanNameText().substring(0, inputPage.getPlanNameText().length()-3);
            Assert.assertTrue(inputData.get("PAT_ADDRESS_LINE1").equals(inputPage.getPatientAddress()));
            Assert.assertTrue(inputData.get("PAT_AGE").equals(inputPage.getPatientAge()));
            Assert.assertTrue(inputData.get("PAT_DOB").equals(inputPage.getPatientDOB()));
            Assert.assertTrue(inputData.get("PAT_PLAN").contains(planName));
            Assert.assertTrue(inputData.get("PAT_CARRIER").equals(inputPage.getPatientCarrier()));
            Assert.assertTrue(inputData.get("PHONE_NUMBER1").equals(inputPage.getPatientPhone()));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to validate Show order button
     *
     * Author: Janani C(vn50stx)
     * */
    public void showOrderButtonValidation(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.clickShowOrderButton();
            automationManager.performSleep(1);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickShowOrderCloseButton();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to click and validate Send to resolution button
     *
     * Author: Janani C(vn50stx)
     * */
    public void sendToResolutionButton(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            inputPage.sendRxToManualResolution(inputData.get("RESOLUTION_TEXT"), InputPage.ManualResolutionType.CONTACT_PRESCRIBER);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to validate Rx move to resolution screen from Patient search screen.
     *
     * Author: Janani C(vn50stx)
     * */
    public void validateRxMoveToResolution(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            rxSearch.openSearch();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxSearch.performSearch(name[0]+","+name[1], SearchType.PatientRx);
            automationManager.performSleep(1);
            if(rxSearch.getProblemMessage(0).contains(inputData.get("RESOLUTION_TEXT"))){
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                rxSearch.closeSearch();
            }
            else{
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to validate Prescriber details displayed in input screen is valid
     *
     * Author: Janani C(vn50stx)
     * */
    public void prescriberDetailsValidation(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertTrue(inputData.get("PRESCRIBER_NAME").equals(inputPage.getTextPrescriberName()));
            Assert.assertTrue(inputData.get("PRESCRIBER_ADDRESS").equals(inputPage.getPrescriberAddress()));
            Assert.assertTrue(inputData.get("PRESCRIBER_DEA").equals(inputPage.getPrescriberDEANumber()));
            Assert.assertTrue(inputData.get("PRESCRIBER_NPI").equals(inputPage.getPrescriberNPINumber()));
            Assert.assertTrue(inputData.get("PRESCRIBER_PHONENUMBER").equals(inputPage.getPrescriberPhone()));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to validate Product details displayed in input screen is valid
     *
     * Author: Janani C(vn50stx)
     * */
    public void productDetailsValidation(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Assert.assertTrue(inputData.get("PRODUCT_NAME").equals(inputPage.getTextPrescibedProduct()));
            Assert.assertTrue(inputData.get("PRODUCT_PACKSIZE").equals(inputPage.getProductPackSize()));
            Assert.assertTrue(inputData.get("PRODUCT_SMALL_PACKSIZE").equals(inputPage.getProductSmallPackSize()));
            Assert.assertTrue(inputData.get("PRODUCT_NDC").equals(inputPage.getProductNDCNumber()));
            Assert.assertTrue(inputData.get("DISPENSED_PRODUCT_NAME").equals(inputPage.getDispensedProductName()));
            Assert.assertTrue(inputData.get("PRODUCT_MFG").equals(inputPage.getProductMFG()));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /*
     * Method to click cancel button in Input screen
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void clickCancel() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            inputPage.clickCancel();
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate the text displayed in popup while clicking on cancel button
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void cancelButtonValidation(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            String popupMessage=inputPage.getInputScreenPopupMessage();
            Assert.assertEquals(popupMessage,inputData.get("MESSAGE"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to click No button from the cancel popup
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void clickNoCancel() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            inputPage.clickNoButtonInCancelPopup();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate the Language text of Patient in Input screen
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void languageValidation(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            String language = inputPage.patientLanguageTextValidation();
            Assert.assertEquals(language,"Language: "+inputData.get("EXPECTED_LANGUAGE").toUpperCase().substring(0,3));
            Reporter.logScreenShot(Status.PASS,  currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to Validate whether No Of Rx is 1 for Single Rx in Input screen
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void noOfRxValidationForSingleRx(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            Integer noOfRx= Integer.valueOf(inputPage.getTextnoOfRxField());
            Assert.assertEquals(noOfRx,Integer.valueOf(1));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate whether Length of Refill text box is accepting maximum 2 digits in Input screen
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void refillLengthValidation(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            int refills=inputPage.getRefillSize();
            Assert.assertTrue(refills==1 || refills==2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate pack size of the product entered in Input screen with Product Maintenance screen
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void packSizeValidation(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickProductMaintenanceIcon();
            automationManager.performSleep(2);
            String ProductPackSize = productMaintenancePage.getPackSize(0);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            productMaintenancePage.closeProductScreen();
            Assert.assertEquals(inputPage.productPackSizeTextValidation(),ProductPackSize);
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate expiry date when the refills entered as P1 to P6
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void expiryDateP1ToP6(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            rxSearch.openSearch();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            rxSearch.selectRowFromSearch(0);
            automationManager.performSleep(3);
            inputPage.enterProductNameInPrescribedProduct(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            for(int i=1;i<7;i++){
                String refills=inputData.get("REFILLS")+i;
                inputPage.enterRefillQty(refills);
                inputPage.selectDAW(1);
                Reporter.logScreenShot(Status.PASS, "P" + i + "_" + currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                int diff = monthCalculation();
                inputPage.clearRefillField();
                Assert.assertEquals(diff,i);
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to return month difference between written date and expiry date
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public int monthCalculation() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        int monthDifference = 0;
        try{
            SimpleDateFormat sdformat = new SimpleDateFormat("MM/dd/yyyy");
            Date date1 = sdformat.parse(inputPage.getProductWrittenDate());
            Date date2 = sdformat.parse(inputPage.getExpirationDate());
            Calendar m_calendar=Calendar.getInstance();
            m_calendar.setTime(date1);
            int nMonth1=12*m_calendar.get(Calendar.YEAR)+m_calendar.get(Calendar.MONTH);
            m_calendar.setTime(date2);
            int nMonth2=12*m_calendar.get(Calendar.YEAR)+m_calendar.get(Calendar.MONTH);
            monthDifference = java.lang.Math.abs(nMonth2-nMonth1);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return monthDifference;
    }

    /*
     * Method to validate the month difference between written date and expiry date
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void expiryDateValidation_Months(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            Assert.assertEquals(String.valueOf(monthCalculation()),inputData.get("EXPECTED_MONTHS"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to update the state of the store
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void checkCurrentStateAndupdateStoreState(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            connexusAppUtils.checkCurrentStateAndupdateStoreState(inputData.get("NEW_STATE"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to get the days difference between written date and expiry date in Input screen
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public String getDays() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        long daysDifference = 0;
        try{
            SimpleDateFormat sdformat = new SimpleDateFormat("MM/dd/yyyy");
            daysDifference = ((sdformat.parse(inputPage.getExpirationDate()).getTime() - sdformat.parse(inputPage.getProductWrittenDate()).getTime()) / (1000 * 60 * 60 * 24)) % 365;
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
        return String.valueOf(daysDifference);
    }

    /*
     * Method to validate the days difference between written and expiry date for C2 drug in Input screen
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void validateExpiryDate_C2(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            rxSearch.openSearch();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            rxSearch.selectRowFromSearch(0);
            automationManager.performSleep(3);
            inputPage.enterProductNameInPrescribedProduct(inputData.get("C2_DRUG"));
            automationManager.performSleep(3);
            Assert.assertEquals(getDays(),inputData.get("EXPECTED_DAYS"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate the days difference between written and expiry date for C3 to C5 drug in Input screen
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void validateExpiryDate_C3ToC5(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            rxSearch.openSearch();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            rxSearch.selectRowFromSearch(0);
            automationManager.performSleep(3);
            List<String> productName = Arrays.asList("C3_DRUG","C4_DRUG","C5_DRUG");
            List<String> drugType = Arrays.asList("C3 Drug","C4 Drug","C5 Drug");
            for(int i = 0 ; i < productName.size() ; i++){
                inputPage.enterProductNameInPrescribedProduct(inputData.get(productName.get(i)));
                automationManager.performSleep(3);
                Assert.assertEquals(getDays(),inputData.get("EXPECTED_DAYS"));
                Reporter.logScreenShot(Status.PASS, drugType.get(i) + currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate the month difference between written and expiry date for C3 to C5 drug in Input screen
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void validateExpiryDate_In_Months_C3ToC5(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            rxSearch.openSearch();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            rxSearch.selectRowFromSearch(0);
            automationManager.performSleep(3);
            List<String> productName = Arrays.asList("C3_DRUG","C4_DRUG","C5_DRUG");
            List<String> drugType = Arrays.asList("C3 Drug","C4 Drug","C5 Drug");
            for(int i = 0 ; i < productName.size() ; i++){
                inputPage.enterProductNameInPrescribedProduct(inputData.get(productName.get(i)));
                automationManager.performSleep(3);
                Assert.assertEquals(String.valueOf(monthCalculation()),inputData.get("EXPECTED_MONTHS"));
                Reporter.logScreenShot(Status.PASS, drugType.get(i) + currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*
     * Method to validate all the 8 options in DAW dropdown in Input screen
     *
     * Author: Dharani Ranganathan(vn50qid)
     * */
    public void validate_DAW(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            List<String> DAW = Arrays.asList("0-May Substitute", "1-Doctor DAW", "2-Patient DAW", "5-Brand Used as Generic",
                    "6-Override", "7-Brand Required by Law", "8-Generic Not Available", "9-Patient's Plan Requested brand Product to be dispensed");
            for(int i = 0 ; i < DAW.size() ; i++){
                inputPage.selectDAWByValue(DAW.get(i));
                Reporter.logScreenShot(Status.PASS, inputPage.getDAWDropdownValue(i) + "_" + currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertEquals(inputPage.getDAWDropdownValue(i),DAW.get(i));
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    
}