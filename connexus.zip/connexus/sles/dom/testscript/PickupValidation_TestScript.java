package connexus.sles.dom.testscript;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import hwqe.baseframework.utilities.StackUtils;
import io.appium.java_client.AppiumBy;
import io.strati.libs.joda.time.DateTime;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Map;

public class PickupValidation_TestScript extends ConnexusTestScripts {

    AutomationManager automationManager;
    SoftAssert softAssert = new SoftAssert();
    LoginPage loginPage;
    TascoPage tascoPage;
    ConnexusAppUtils connexusAppUtils;
    protected int patientId;
    protected String rxNbr;
    protected int fillid;

    /*Helper method to safely take screenshots and handle null returns
     *Author: System Generated*/
    private String safeScreenShot(String methodName) {
        try {
            javafx.util.Pair<String, String> screenshot = tascoPage.takeScreenShot(methodName);
            return screenshot != null ? screenshot.getValue() : null;
        } catch (Exception e) {
            Reporter.log("Failed to capture screenshot for " + methodName + ": " + e.getMessage());
            return null;
        }
    }

    /*Connexus Login
     *Author: M. Eswara Visakan (vn50ym2)*/
    @Override
    public void loginConnexus(LoginAs.userType userType) {
        loginPage = new LoginPage(userType);
        automationManager = AutomationManager.getInstance();
        tascoPage = new TascoPage();
        loginPage.loginConnexus(userType);
        connexusAppUtils = new ConnexusAppUtils();
    }

    /*TaSCO SignOff
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void signOff() {
        automationManager.performSleep(2);
        tascoPage.clickSignOffButton();
        automationManager.performSleep(2);
    }

    /*Launch TaSCO
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void navigateToTaSCO () {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            automationManager.performSleep(2);
            tascoPage.launchTascoScreen();
            automationManager.performSleep(2);
            //        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch(Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Navigate to HIPAA screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void navigateToHipaa(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.launchTascoHippaScreen();
        } catch(Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate HIPAA Page title
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateHipaaTitle() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(3);
            softAssert.assertEquals(tascoPage.getTextFromHIPAAScreen(), "PATIENT PRIVACY INFORMATION");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Enter Insufficient Patient Details
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void enterInsufficientPatientDetails(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.inputPatientLastName(inputData.get("PATIENT_LASTNAME"));
            tascoPage.pressTabKey();
            tascoPage.pressTabKey();
            tascoPage.inputPatientDob(inputData.get("PATIENT_DOB"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientPhone(inputData.get("PATIENT_PHONE"));
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Search button disabled
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void isSearchButtonDisabled(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertFalse(tascoPage.validateSearchButton());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Clear button click
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void clickClearButton(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.clickClearButton();
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Enter Patient Details
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void enterPatientDetails(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.inputPatientLastName(inputData.get("PATIENT_LASTNAME"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(inputData.get("PATIENT_FIRSTNAME"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientDob(inputData.get("PATIENT_DOB"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientPhone(inputData.get("PATIENT_PHONE"));
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate Name is complete checkbox
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void isNameCheckboxEnabled(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.validateCheckBoxField());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Click Name is complete checkbox
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void clickLnFnCheckBox(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.inputPatientLastName(inputData.get("PATIENT_LASTNAME"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(inputData.get("PATIENT_FIRSTNAME"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientDob(inputData.get("PATIENT_DOB"));
            tascoPage.clickLnFnCheckbox();
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Enter Patient Details and click on Search button
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void orderOrPatientSearch(Map<String, String> inputData){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.inputPatientLastName(inputData.get("PATIENT_LASTNAME"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(inputData.get("PATIENT_FIRSTNAME"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientDob(inputData.get("PATIENT_DOB"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientPhone(inputData.get("PATIENT_PHONE"));
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.inputPatientLastName(inputData.get("PATIENT_LASTNAME"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientFirstName(inputData.get("PATIENT_FIRSTNAME"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientDob(inputData.get("PATIENT_DOB"));
            tascoPage.pressTabKey();
            tascoPage.inputPatientPhone(inputData.get("PATIENT_PHONE"));
            automationManager.performSleep(2);
            if(tascoPage.validateSearchButton()){
                clickSearchButton();
            }
            else{
                int LnCount = inputData.get("PATIENT_LASTNAME").length();
                int FnCount = inputData.get("PATIENT_FIRSTNAME").length();
                if(LnCount == 1){
                    tascoPage.clickLnFnCheckbox();
                    automationManager.performSleep(2);
                    clickSearchButton();
                }
                else if(FnCount == 1){
                    tascoPage.clickLnFnCheckbox();
                    automationManager.performSleep(2);
                    clickSearchButton();
                }
                else if (inputData.get("PATIENT_LASTNAME").length() == 1 && inputData.get("PATIENT_FIRSTNAME").length()==1){
                    tascoPage.clickLnFnCheckbox();
                    automationManager.performSleep(2);
                    clickSearchButton();
                }
                automationManager.performSleep(2);
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate "Search Returned No Results!" Popup
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateSearchResultsNotFoundPopup() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertEquals(tascoPage.getTextlblInformation(), "Search Returned No Results!");
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Click on OK Button in popup windows
     *Author: */
    public void clickOkPopUp(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.clickOk();
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate text in "Invalid Date Format" popup
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateInvalidDobPopup(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertEquals(tascoPage.getTextlblInformation(),"Invalid Date Format.");
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate text in "Invalid Phone Number" popup
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateInvalidPhPopup() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            softAssert.assertEquals(tascoPage.getTextlblInformation(), "Phone number is too short.");
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Search button click
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void clickSearchButton(){
        tascoPage.clickSearch();
    }

    /*Exit button click
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void clickExitButton() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(2);
            tascoPage.clickExit();
            automationManager.performSleep(2);
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Patient Search button click
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void clickHipaaPatientSearchButton(){
        tascoPage.clickHipaaPatientSearch();
    }

    /*Validate TaSCO Order Search screen is enabled
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void isTascoOrderSearchDisplayed(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            automationManager.performSleep(2);
            softAssert.assertTrue(tascoPage.validateTascoOrderSearchScreen());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate Clear button is enabled
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void isClearButtonEnabled(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.validateClearButton());
            automationManager.performSleep(2);
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate Patient Search button is enabled
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void isHipaaPatientSearchEnabled(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.validateHipaaPatientSearch());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate HIPAA Search Results page
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateHipaaSearchResult(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.validateHipaaSearchListView());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate HIPAA Patient Search screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void isHipaaPatientSearchDisplayed(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.validateHipaaPatientSearchScreen());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate HIPAA Fields are clear
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void allFieldsBlank(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertEquals(tascoPage.getTextFromLastName(), "");
            softAssert.assertEquals(tascoPage.getTextFromFirstName(), "");
            softAssert.assertEquals(tascoPage.getTextFromDOB(), "");
            softAssert.assertEquals(tascoPage.getTextFromPhoneNumber(), "");
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate HIPAA Exit icon is enabled
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateExitButton(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.validateHipaaExitIcon());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate Previous Results icon is enabled
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validatePreviousResults(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.validatePreviousResultsIcon());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Navigate to Previous Results screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void navigateToPreviousResults(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.launchPreviousResultsScreen();
            automationManager.performSleep(3);
        } catch(Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate Order Search Result screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateSearchResults(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.validateOrderSearchResultsScreen());
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Navigate to Order Search screen from top pane of TaSCO
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void navigateSearchTopPane(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            automationManager.performSleep(2);
            tascoPage.launchTopOrderSearch();
        } catch(Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate Return to Pickup icon is enabled
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateReturnPickup(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.validateReturnPickupIcon());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Navigate to Return to Pickup screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void navigateToReturnToPickup(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.launchReturnPickupScreen();
        } catch(Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate Return to Pickup screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateReturnToPickup(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.validateReturnPickupScreen());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate Order Search button in Order Search screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateSearchTopPane(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.validateSearchTopPaneIcon());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate Order Comments button in Order Search screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateOrderComments(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            automationManager.performSleep(5);
            softAssert.assertTrue(tascoPage.validateOrderCommentsIcon());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Click on Search icon from top pane and validate the Order Search screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void clickSearchTopPaneAndStay(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.clickSearchTopPane();
            softAssert.assertTrue(tascoPage.validateTascoOrderSearchScreen());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Click on Order Comments icon from top pane and validate the Order Search screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void clickOrderCommentsAndStay(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.clickOrderCommentsIcon();
            softAssert.assertTrue(tascoPage.validateTascoOrderSearchScreen());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate "Search Returned No Results!" Popup
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateMultiplePatientFoundPopup() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertEquals(tascoPage.getTextlblInformation(), "Orders of multiple patients are found with the given search criteria.");
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate the intermediary Multiple Patient screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateMultiplePatientScreen(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.validateMultiPatientScreen());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Selecting a single RX order
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void selectSingleRxOrder(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            automationManager.performSleep(5);
            tascoPage.clickRow(0);
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate the checkout button
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateCheckoutButton(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.isCheckoutEnabled());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Clicking on checkout button
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void clickCheckOutButton(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.clickCheckout();
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate the Signature Validation screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateSignatureValidation(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.isSignValidScreen());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate the Accept button before RX scan
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void disabledAcceptDispense(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertFalse(tascoPage.isAcceptButtonEnabled());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Click on NO Button in popup windows for multi order selection
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void selectMultiOrderNo(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.setMultiOrderNo();
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Selecting a single patient from multi patient screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void selectSinglePatient(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.clickRow(0);
            automationManager.performSleep(10);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate orders of multiple patients found popup
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateBatchedOrdersFoundPopup() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertEquals(tascoPage.getTextlblInformation(), "Orders of multiple patients are found with the given search criteria.");
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate Technical Issues popup
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateTechnicalIssuesPopup() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertEquals(tascoPage.getTextlblInformation(), "Sorry, we're having technical issues completing this action.");
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Click on Order Comments icon from top pane of the Search Results screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void navigateToOrderComments(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.clickOrderCommentsIcon();
            automationManager.performSleep(2);
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate the Order Comments screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateOrderCommentsScreen(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            automationManager.performSleep(2);
            softAssert.assertTrue(tascoPage.isOrderCommentsDisplayed());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate the Next Page button
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateNextButton(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.isNextButtonEnabled());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Click on Next button of the Search Results screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void navigateToNextPage(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.clickNext();
            automationManager.performSleep(3);
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate the Previous Page button
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validatePreviousButton(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.isPreviousButtonEnabled());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Click on Previous button of the Search Results screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void navigateToPreviousPage(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.clickPrevious();
            automationManager.performSleep(3);
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate the Priority button
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validatePickupPriority(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertFalse(tascoPage.isPriorityEnabled());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate the Cancel button in Order Search Results screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void cancelBottomPane(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.isCancelSearchResultsEnabled());
            automationManager.performSleep(3);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Click on Cancel button of the Search Results screen
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void clickCancelBottomPane(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            tascoPage.clickCancelSearchResults();
            automationManager.performSleep(3);
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate Page value
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validatePageNumber(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            softAssert.assertTrue(tascoPage.isPageValueEnabled());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Selecting a single RX order
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void selectNotReadyOrder(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            automationManager.performSleep(5);
            tascoPage.clickRow(0);
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Validate Check Out Basket
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void validateCheckOutBasket() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            automationManager.performSleep(2);
            softAssert.assertTrue(tascoPage.validateCheckoutBkt());
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /*Selecting a multi RX order
     *Author: M. Eswara Visakan (vn50ym2)*/
    public void selectMultiRxOrder(){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            automationManager.performSleep(5);
            tascoPage.clickRow(0);
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void dropAnRxTillPickUp(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        performDropOff(Priority.Critical);
        performInput(inputData);
        perform4Point(false,false);
        performChkDUR();
        performFilling();
        performVisualVerify();

    }
    public void createPatientAndMoveToPickup(Map<String, String> inputData, int storeId) {
        patientId = super.performCreatePatientThroughAPI(inputData, storeId);
        IDatabaseContext cnx = automationManager.getConnexusDB(storeId);
        DataRow drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("NDC_NUMBER"));
        rxNbr = connexusAPIManager.createNewOrderAndMoveToPickup(patientId, storeId, new SimpleDateFormat("MMM dd yyyy").format(Date.from(Instant.now().plus(720, ChronoUnit.DAYS))), new SimpleDateFormat("MMM dd yyyy").format(Date.from(Instant.now().plus(15, ChronoUnit.DAYS))) + " 08:00:00.000 UTC", 25, drugInfo, inputData.get("NDC_NUMBER")).get(0);
    }
    public void dropoffToTillPickUp(Map<String, String> inputData, int storeId) {
        IDatabaseContext cnx = automationManager.getConnexusDB(storeId);
        DataRow drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("NDC_NUMBER"));
        rxNbr = connexusAPIManager.createNewOrderAndMoveToPickup(patientId, storeId, new SimpleDateFormat("MMM dd yyyy").format(Date.from(Instant.now().plus(720, ChronoUnit.DAYS))), new SimpleDateFormat("MMM dd yyyy").format(Date.from(Instant.now().plus(15, ChronoUnit.DAYS))) + " 08:00:00.000 UTC", 25, drugInfo, inputData.get("NDC_NUMBER")).get(0);
    }

    public void clickSearchOnTascoPage() {
        try {
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public void clickRow(int index) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            automationManager.performSleep(2);
            tascoPage.clickRow(index);
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }

    /*Set Specialty Store Parameter (PHM_PARM_CODE 5361)
     *Author:kruthika (vn59ehu)*/
    public void setSpecialtyStoreParameter(int storeNbr){
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try{
            IDatabaseContext cnx = automationManager.getConnexusDB(storeNbr);
            String updateQuery = "UPDATE phm_parm SET phm_parm_value = 'True' " +
                    "WHERE phm_parm_code = 5361 AND str_nbr = " + storeNbr;
            cnx.executeQuery(updateQuery);
            Reporter.log("Set PHM_PARM_CODE 5361 to 'True' for store " + storeNbr + " (Specialty store behavior enabled)");
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.log("Failed to set PHM_PARM_CODE 5361: " + e.getMessage());
            softAssert.assertAll();
        }
    }

    ///kruthika(vn59ehu)
    public void performRXscan(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            //  String[] name={"Nannette","Trantow"};
            if (checkOrderQueueDB(rxNbr, hwqe.baseframework.models.datamodels.enums.WorkQueueSettings.Pickup.getValue())) {
                // Get wrong RX values from test data//
                String wrongRxNbr = inputData.get("WRONG_RX_NBR");
                int wrongFillId = Integer.parseInt(inputData.get("WRONG_FILL_ID"));

                Reporter.log("Correct Patient RX: " + rxNbr + ", Fill ID: " + fillid);
                Reporter.log("Wrong RX to scan: " + wrongRxNbr + ", Wrong Fill ID: " + wrongFillId);

                automationManager.getConnexusWorkFlow().performpickupforWrongScanRX(name[1], name[0], inputData.get("DOB"), wrongRxNbr, wrongFillId);
            } else {
                performResolveQueue(rxNbr);
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Pickup.getValue())) {
                    automationManager.getConnexusWorkFlow().completePickup(name[0], name[1], inputData.get("DOB"), rxNbr);
                } else {
                    captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in PickUp queue");
                }
            }
            connexusAppUtils.writeTextToFile("Pickup Completed " + rxNbr, "In progress", fileName, 80, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("Pickup not Completed " + rxNbr, "Failed", fileName, 80, DateTime.now());
            Reporter.log("Test failed at PickUp queue");
//           Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


    public void partialPickup(String firstName, String lastName, String dob, String rxNbr,Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        PickupPage pickupPage = new PickupPage();
        try {
            tascoPage.launchTascoScreen();
            automationManager.performSleep(3);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, safeScreenShot(currentStepMethodName));
            boolean result = tascoPage.isPatientFirstNameDisplayed();
            if (result) {
                tascoPage.inputPatientLastName(lastName);
                tascoPage.pressTabKey();
                tascoPage.inputPatientFirstName(firstName);
                tascoPage.pressTabKey();
                tascoPage.inputPatientDob(dob);
                tascoPage.pressTabKey();
                tascoPage.pressTabKey();
            } else {
                tascoPage.inputPatientRxnumber(rxNbr);
            }
            tascoPage.clickSearchOnTascoPage();
            automationManager.performSleep(2);
            tascoPage.clickRow(0);
            tascoPage.continueCheckout();
            tascoPage.handleOtherOrdersAvailablePopUp();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, safeScreenShot(currentStepMethodName));
            tascoPage.clickCheckout();
            automationManager.performSleep(2);
            tascoPage.handleConnexusCheckoutCashPayPopup();
            tascoPage.handleConnexusCheckoutEasyPayPopup();
            tascoPage.handlePatientCentralDataUpdatePayPopup();
            tascoPage.clickBtnOK();
            automationManager.performSleep(2);
        }catch (Exception e){
            Assert.fail();
        }}


}