package connexus.sles.dom.testcases.theme2;

import connexus.sles.dom.testscript.PickupValidation_TestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.Map;

public class PickupValidationTestSet1_HIPAA {

    PickupValidation_TestScript pickupValidation_testScript = new PickupValidation_TestScript();
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeClass() {
        //User logs into Connexus.
        pickupValidation_testScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        //Close All.
        pickupValidation_testScript.signOff();
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 1st Test Description: Verify that the user is able to navigate to PATIENT PRIVACY INFORMATION window
     * JIRA ID: HWQEAUTO-17683
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 1, description = "Verify that the user is able to navigate to PATIENT PRIVACY INFORMATION window")
    public void tc01_navigateToHipaaScreen() {

        Reporter.log(">>>tc01_navigateToHipaaScreen<<<");

        //Step-1.User navigates to TaSCO screen.
        pickupValidation_testScript.navigateToTaSCO();

        //Step-2.Click on HIPAA icon on TaSCO Search screen.
        pickupValidation_testScript.navigateToHipaa();

        //Step-3.Loaded page should be the HIPAA screen.
        pickupValidation_testScript.validateHipaaTitle();

        Reporter.log(">>>tc01_navigateToHipaaScreen [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 2nd Test Description: Verify that user is unable to search for Order with mandatory fields left blank
     * JIRA ID: HWQEAUTO-17685
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 2, description = "Verify that user is unable to search for Order with mandatory fields left blank",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme2/HIPAATestData.json", sheetName = "TestData")
    public void tc02_hipaaBlankFields(Map<String, String> inputData) {

        Reporter.log(">>>tc02_hipaaBlankFields<<<");

        //Pre-Conditions:
        //1.User logged into Connexus.
        //2.User has navigated to TaSCO screens and opened the Patient Privacy Information window.

        //Step-1.Enter Patient Last Name, Patient DOB and Patient Phone Number of a Patient, leaving the mandatory Patient First Name field blank.
        pickupValidation_testScript.enterInsufficientPatientDetails(inputData);

        //Step-2.Search button should be disabled.
        pickupValidation_testScript.isSearchButtonDisabled();

        //Step-3.To continue the flow of next test case, click on Clear button.
        pickupValidation_testScript.clickClearButton();

        Reporter.log(">>>tc02_hipaaBlankFields [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 3rd Test Description: Verify if the user is able to select the Name is Complete checkbox in case of single letter in Patient name
     * JIRA ID: HWQEAUTO-17686
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 3, description = "Verify if the user is able to select the Name is Complete checkbox in case of single letter in Patient name",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme2/HIPAATestData.json", sheetName = "TestData")
    public void tc03_hipaaNameCheckbox(Map<String, String> inputData) {

        Reporter.log(">>>tc03_hipaaNameCheckbox<<<");

        //Pre-Conditions:
        //1.User logged into Connexus.
        //2.User has navigated to TaSCO screens and opened the Patient Privacy Information window.

        //Step-1.Enter Patient Last Name with single letter, Patient First Name and Patient DOB of a Patient.
        pickupValidation_testScript.enterPatientDetails(inputData);

        //Step-2.Name is complete checkbox should be enabled.
        pickupValidation_testScript.isNameCheckboxEnabled();

        //Step-3.Check the Name is Complete checkbox.
        pickupValidation_testScript.clickLnFnCheckBox(inputData);

        //Step-4.To continue the flow of next test case, click on Clear button.
        pickupValidation_testScript.clickClearButton();

        Reporter.log(">>>tc03_hipaaNameCheckbox [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 4th Test Description: Verify that "Search Returned No Results!" pop-up window is shown when user enters invalid patient details.
     * JIRA ID: HWQEAUTO-17687
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 4, description = "Verify that Search Returned No Results! pop-up window is shown when user enters invalid patient details.",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme2/HIPAATestData.json", sheetName = "TestData")
    public void tc04_hipaaSearchNone(Map<String, String> inputData) {

        Reporter.log(">>>tc04_hipaaSearchNone<<<");

        //Pre-Conditions:
        //1.User logged into Connexus.
        //2.User has navigated to TaSCO screens and opened the Patient Privacy Information window.

        //Step-1.Enter Patient Last Name, Patient First Name and Patient DOB of a Patient not existing in DB.
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.Search Returned No Results popup is displayed.
        pickupValidation_testScript.validateSearchResultsNotFoundPopup();

        //Step-4.Click on OK button of the popup.
        pickupValidation_testScript.clickOkPopUp();

        Reporter.log(">>>tc04_hipaaSearchNone [Executed Successfully]<<<\n");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 5th Test Description: Verify if user is getting appropriate error message on invalid date input (non-leap year / date and months are interchanged).
     * JIRA ID: HWQEAUTO-17690
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 5, description = "Verify if user is getting appropriate error message on invalid date input (non-leap year / date and months are interchanged).",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme2/HIPAATestData.json", sheetName = "TestData")
    public void tc05_hipaaInvalidDate(Map<String, String> inputData) {

        Reporter.log(">>>tc05_hipaaInvalidDate<<<");

        //Pre-Conditions:
        //1.User logged into Connexus.
        //2.User has navigated to TaSCO screens and opened the Patient Privacy Information window.

        //Step-1.Enter Patient Last Name, Patient First Name and invalid Patient DOB of a Patient.
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.Invalid Date Format popup is displayed.
        pickupValidation_testScript.validateInvalidDobPopup();

        //Step-4.Click on OK button of the popup.
        pickupValidation_testScript.clickOkPopUp();

        //Step-5.To continue the flow of next test case, click on Clear button.
        pickupValidation_testScript.clickClearButton();

        Reporter.log(">>>tc05_hipaaInvalidDate [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 6th Test Description: Verify the Clear button functionality.
     * JIRA ID: HWQEAUTO-17691
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 6, description = "Verify the Clear button functionality.",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme2/HIPAATestData.json", sheetName = "TestData")
    public void tc06_hipaaClearButton(Map<String, String> inputData) {

        Reporter.log(">>>tc06_hipaaClearButton<<<");

        //Pre-Conditions:
        //1.User logged into Connexus.
        //2.User has navigated to TaSCO screens and opened the Patient Privacy Information window.

        //Step-1.Enter Patient Last Name, Patient First Name and Patient DOB of a Patient.
        pickupValidation_testScript.enterPatientDetails(inputData);

        //Step-2.Clear button should be enabled.
        pickupValidation_testScript.isClearButtonEnabled();

        //Step-2.Click on the Clear button.
        pickupValidation_testScript.clickClearButton();

        //Step-3.Input fields should become blank.
        pickupValidation_testScript.allFieldsBlank();

        Reporter.log(">>>tc06_hipaaClearButton [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 7th Test Description: Verify that the user is able to search a single Patient as per the search criteria.
     * JIRA ID: HWQEAUTO-17692
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 7, description = "Verify that the user is able to search a single Patient as per the search criteria.",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme2/HIPAATestData.json", sheetName = "TestData")
    public void tc07_hipaaSingleSearch(Map<String, String> inputData) {

        Reporter.log(">>>tc07_hipaaSingleSearch<<<");

        //Pre-Conditions:
        //1.User logged into Connexus.
        //2.User has navigated to TaSCO screens and opened the Patient Privacy Information window.

        //Step-1.Enter Patient Last Name, Patient First Name and Patient DOB of a Patient.
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.Loaded page should be the HIPAA Search Results screen.
        pickupValidation_testScript.validateHipaaSearchResult();

        Reporter.log(">>>tc07_hipaaSingleSearch [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 8th Test Description: Verify that the user can navigate back to HIPAA Patient Search screen.
     * JIRA ID: HWQEAUTO-17696
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 8, description = "Verify that the user can navigate back to HIPAA Patient Search screen.")
    public void tc08_hipaaPatientSearchButton() {

        Reporter.log(">>>tc08_hipaaPatientSearchButton<<<");

        //Pre-Conditions:
        //1.User logged into Connexus.
        //2.User has navigated to TaSCO screens and opened the Patient Privacy Information window.
        //3.Enter Patient details.
        //4.Search for the relevant Patient.
        //5.Navigate to Patient Search Results screen for the respective Patient.

        //STep-1.HIPAA Patient Search button should be enabled.
        pickupValidation_testScript.isHipaaPatientSearchEnabled();

        //Step-2.Click on the Patient Search button on the top pane.
        pickupValidation_testScript.clickHipaaPatientSearchButton();

        //Step-3.Loaded page should be the HIPAA Patient Search screen.
        pickupValidation_testScript.isHipaaPatientSearchDisplayed();

        Reporter.log(">>>tc08_hipaaPatientSearchButton [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 9th Test Description: Verify that the user is able to search a multiple Patient as per the search criteria.
     * JIRA ID: HWQEAUTO-17694
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 9, description = "Verify that the user is able to search a multiple Patient as per the search criteria.",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme2/HIPAATestData.json", sheetName = "TestData")
    public void tc09_hipaaMultipleSearch(Map<String, String> inputData) {

        Reporter.log(">>>tc09_hipaaMultipleSearch<<<");

        //Pre-Conditions:
        //1.User logged into Connexus.
        //2.User has navigated to TaSCO screens and opened the Patient Privacy Information window.

        //Step-1.Enter Patient Last Name, Patient First Name and Patient DOB of a Patient.
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.Loaded page should be the HIPAA Search Results screen with similar Patients.
        pickupValidation_testScript.validateHipaaSearchResult();

        Reporter.log(">>>tc09_hipaaMultipleSearch [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 10th Test Description: Verify that the User is able to Exit the Patient Privacy Information window and navigate back to TaSCO Order Search screen.
     * JIRA ID: HWQEAUTO-17696
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 10, description = "Verify that the User is able to Exit the Patient Privacy Information window and navigate back to TaSCO Order Search screen.")
    public void tc10_hipaaExitIcon() {

        Reporter.log(">>>tc10_hipaaExitIcon<<<");

        //Pre-Conditions:
        //1.User logged into ConnexUs.
        //2.User has navigated to TaSCO screens and opened the Patient Privacy Information window.
        //3.Enter Patient details.
        //4.Search for the relevant Patient.
        //5.Navigate to Patient Search Results screen for the respective Patient.

        //Step-1.Exit icon should be enabled.
        pickupValidation_testScript.validateExitButton();

        //Step-2.Click on the Exit icon from the top pane.
        pickupValidation_testScript.clickExitButton();

        //Step-3.Loaded page should be TaSCO Order Search screen.
        pickupValidation_testScript.isTascoOrderSearchDisplayed();

        Reporter.log(">>>tc10_hipaaExitIcon [Executed Successfully]<<<");
    }
}