package connexus.sles.dom.testcases.theme1;

import connexus.sles.dom.testscript.PickupValidation_TestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.Map;

public class PickupValidationTestSet_OrderSelect {

    PickupValidation_TestScript pickupValidation_testScript = new PickupValidation_TestScript();
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeClass() {
        //User logs into Connexus.
        pickupValidation_testScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        //Close All.
        pickupValidation_testScript.signOff();
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 1st Test Description: Verify the functionality of the enabled Order Comments icon.
     * JIRA ID: HWQEAUTO-7086
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 1, description = "Verify the functionality of the enabled Order Comments icon",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSelectTestData.json", sheetName = "TestData")
    public void tc01_orderCommentsScreen(Map<String, String> inputData) {

        Reporter.log(">>>tc01_orderCommentsScreen<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.
        pickupValidation_testScript.navigateToTaSCO();
        //3.User has searched for the required Order and navigated to Order Search Result screen.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-1.Validate the Order Comments icon.
        pickupValidation_testScript.validateOrderComments();

        //Step-2.Click on Order Comments icon.
        pickupValidation_testScript.navigateToOrderComments();

        //Step-3.User should be navigated to Order Comments screen.
        pickupValidation_testScript.validateOrderCommentsScreen();

        //Step-4.To continue the flow of next test case, click on previous Results icon in top pane.
        pickupValidation_testScript.navigateToPreviousResults();

        Reporter.log(">>>tc01_orderCommentsScreen [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 2nd Test Description: Verify the functionality of the Next button in the bottom pane.
     * JIRA ID: HWQEAUTO-6980
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 2, description = "Verify the functionality of the Next button in the bottom pane")
    public void tc02_nextButtonFunctionality() {

        Reporter.log(">>>tc02_nextButtonFunctionality<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.
        //3.User has searched for the required Order and navigated to Order Search Result screen.

        //Step-1.Validate the Next button at the bottom pane.
        pickupValidation_testScript.validateNextButton();

        //Step-2.Click on Next button.
        pickupValidation_testScript.navigateToNextPage();

        //Step-3.User should be navigated to the next page.
        pickupValidation_testScript.validatePageNumber();

        Reporter.log(">>>tc02_nextButtonFunctionality [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 3rd Test Description: Verify the functionality of the Previous button in the bottom pane.
     * JIRA ID: HWQEAUTO-6980
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 3, description = "Verify the functionality of the Previous button in the bottom pane")
    public void tc03_previousButtonFunctionality() {

        Reporter.log(">>>tc03_previousButtonFunctionality<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.
        //3.User has searched for the required Order and navigated to Order Search Result screen.
        //4.User must be at least at the second page.

        //Step-1.Validate the Previous button at the bottom pane.
        pickupValidation_testScript.validatePreviousButton();

        //Step-2.Click on Previous button.
        pickupValidation_testScript.navigateToPreviousPage();

        //Step-3.User should be navigated to the previous page.
        pickupValidation_testScript.validatePageNumber();

        Reporter.log(">>>tc03_previousButtonFunctionality [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 4th Test Description: Verify the functionality of the Cancel button (when the Check Out Basket is empty).
     * JIRA ID: HWQEAUTO-7021
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 4, description = "Verify the functionality of the Cancel button (when the Check Out Basket is empty)")
    public void tc04_cancelEmptyBasket() {

        Reporter.log(">>>tc04_cancelEmptyBasket<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.
        //3.User has searched for the required Order and navigated to Order Search Result screen.

        //Step-1.Validate the Cancel button.
        pickupValidation_testScript.cancelBottomPane();

        //Step-2.Click on the Cancel button of the Search Results screen
        pickupValidation_testScript.clickCancelBottomPane();

        //Step-3.User should be navigated to the Order Search screen.
        pickupValidation_testScript.isTascoOrderSearchDisplayed();

        Reporter.log(">>>tc04_cancelEmptyBasket [Executed Successfully]<<<\n");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 5th Test Description: Verify that the Pickup Priority icon is disabled in the bottom pane.
     * JIRA ID: HWQEAUTO-7063
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 5, description = "Verify that the Pickup Priority icon is disabled in the bottom pane",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSelectTestData.json", sheetName = "TestData")
    public void tc05_disabledPickupPriority(Map<String, String> inputData) {

        Reporter.log(">>>tc05_disabledPickupPriority<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.
        //3.User has searched for the required Order and navigated to Order Search Result screen.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-1.User should see that the Pickup Priority icon is disabled.
        pickupValidation_testScript.validatePickupPriority();

        //Step-2.Click on the Cancel button of the Search Results screen for the flow to continue
        pickupValidation_testScript.clickCancelBottomPane();

        Reporter.log(">>>tc05_disabledPickupPriority [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 6th Test Description: Verify that the user is unable to select a Not Ready Order / Picked Up Order.
     * JIRA ID: HWQEAUTO-7064
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 6, description = "Verify that the user is unable to select a Not Ready Order / Picked Up Order",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSelectTestData.json", sheetName = "TestData")
    public void tc06_selectNonReady(Map<String, String> inputData) {

        Reporter.log(">>>tc06_selectNonReady<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.
        //3.User has searched for the required Order and navigated to Order Search Result screen.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-1.Select a Not Ready Order.
        pickupValidation_testScript.selectNotReadyOrder();

        //Step-2.User should see that the Order details are shown but Order is not added to the Check Out Basket.
        pickupValidation_testScript.validateCheckOutBasket();

        //Step-3.To continue the flow of next test case, click on Cancel button in bottom pane.
        pickupValidation_testScript.clickCancelBottomPane();

        Reporter.log(">>>tc06_selectNonReady [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 7th Test Description: Verify that the user is able to select a single RX Order.
     * JIRA ID: HWQEAUTO-7052
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 7, description = "Verify that the user is able to select a single RX Order",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSelectTestData.json", sheetName = "TestData")
    public void tc07_selectSingleRx(Map<String, String> inputData) {

        Reporter.log(">>>tc07_selectSingleRx<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.
        //3.User has searched for the required Order and navigated to Order Search Result screen.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-1.Select a single RX Ready Order.
        pickupValidation_testScript.selectSingleRxOrder();

        //Step-3.User should see that the Order details are shown and the Order is added to the Check Out Basket.
        pickupValidation_testScript.validateCheckOutBasket();

        Reporter.log(">>>tc07_selectSingleRx [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 8th Test Description: Verify that the user is able to search and select a multi RX Batched Order after multi Patient screen.
     * JIRA ID: HWQEAUTO-7052, 7149, 6897, 1337
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 8, description = "Verify that the user is able to search and select a multi RX Batched Order after multi Patient screen",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSelectTestData.json", sheetName = "TestData")
    public void tc08_tascoMultipleFlow(Map<String, String> inputData) {

        Reporter.log(">>>tc08_tascoMultipleFlow<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus application.
        //2.User has navigated back to TaSCO Order Search screen.
        pickupValidation_testScript.navigateToTaSCO();

        //Step-1.Enter Patient Last Name, Patient First Name and Patient DOB of a Patient.
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.Validate the Multiple Patients found popup.
        pickupValidation_testScript.validateMultiplePatientFoundPopup();

        //Step-4.Click on OK button to close that popup.
        pickupValidation_testScript.clickOkPopUp();

        //Step-5.Validate the Multiple Patient screen.
        pickupValidation_testScript.validateMultiplePatientScreen();

        //Step-6.Select one of the multiple Patients shown.
        pickupValidation_testScript.selectSinglePatient();

        //Step-7.Verify whether the Batched Orders Found popup is displayed or not.
        pickupValidation_testScript.validateBatchedOrdersFoundPopup();

        //Step-8.Click on OK button of that popup.
        pickupValidation_testScript.clickOkPopUp();

        //Step-9.Verify that the Order Search Results screen is displayed.
        pickupValidation_testScript.validateSearchResults();

        //Step-10.Select the desired multi RX Order from the orders displayed.
        pickupValidation_testScript.selectMultiRxOrder();

        //Step-11.Click on No for the multi order select popup.
        pickupValidation_testScript.selectMultiOrderNo();

        //Step-12.User should see that the Order details are shown and the Order is added to the Check Out Basket.
        pickupValidation_testScript.validateCheckOutBasket();

        //Step-13.Verify whether the Check Out button is enabled or not.
        pickupValidation_testScript.validateCheckoutButton();

        //Step-14.Click on the Check Out button.
        pickupValidation_testScript.clickCheckOutButton();

        //Step-15.Verify whether the Signature Validation screen is loaded or not with proper details.
        pickupValidation_testScript.validateSignatureValidation();

        //Step-16.Verify whether the Accept button is enabled or not before keying in the RX Number.
        pickupValidation_testScript.disabledAcceptDispense();

        Reporter.log(">>>tc08_tascoMultipleFlow [Executed Successfully]<<<");
    }
}
