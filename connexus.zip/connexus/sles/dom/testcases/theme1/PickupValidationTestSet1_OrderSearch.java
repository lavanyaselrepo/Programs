package connexus.sles.dom.testcases.theme1;

import connexus.sles.dom.testscript.PickupValidation_TestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.Map;

public class PickupValidationTestSet1_OrderSearch {

    PickupValidation_TestScript pickupValidation_testScript = new PickupValidation_TestScript();
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeClass() {
        //User logs into Connexus.
        pickupValidation_testScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        //Close All.
        pickupValidation_testScript.signOff();
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 1st Test Description: Verify that the user is able to navigate to TaSCO Order Search screen.
     * JIRA ID: HWQEAUTO-7170
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 1, description = "Verify that the user is able to navigate to TaSCO Order Search screen")
    public void tc01_navigateToTascoScreen() {

        Reporter.log(">>>tc01_navigateToTascoScreen<<<");

        //Step-1.User navigates to TaSCO screen.
        pickupValidation_testScript.navigateToTaSCO();

        //Step-2.Loaded page should be the TaSCO Order Search screen.
        pickupValidation_testScript.isTascoOrderSearchDisplayed();

        Reporter.log(">>>tc01_navigateToTascoScreen [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 2nd Test Description: Verify that user is unable to search for Order with mandatory fields left blank.
     * JIRA ID: HWQEAUTO-7142
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 2, description = "Verify that user is unable to search for Order with mandatory fields left blank",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSearchTestData1.json", sheetName = "TestData")
    public void tc02_orderSearchBlankFields(Map<String, String> inputData){

        Reporter.log(">>>tc02_orderSearchBlankFields<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Enter Patient Last Name, Patient DOB and Patient Phone Number of a Patient, leaving the mandatory Patient First Name field blank.
        pickupValidation_testScript.enterInsufficientPatientDetails(inputData);

        //Step-2.Search button should be disabled.
        pickupValidation_testScript.isSearchButtonDisabled();

        //Step-3.To continue the flow of next test case, click on Clear button.
        pickupValidation_testScript.clickClearButton();

        Reporter.log(">>>tc02_orderSearchBlankFields [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 3rd Test Description: Verify if the user is able to select the Name is Complete checkbox in case of single letter in Patient name.
     * JIRA ID: HWQEAUTO-7058
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 3, description = "Verify if the user is able to select the Name is Complete checkbox in case of single letter in Patient name",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSearchTestData1.json", sheetName = "TestData")
    public void tc03_orderSearchNameCheckbox(Map<String, String> inputData) {

        Reporter.log(">>>tc03_orderSearchNameCheckbox<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Enter Patient Last Name, Patient First Name with single letter and Patient DOB of a Patient.
        pickupValidation_testScript.enterPatientDetails(inputData);

        //Step-2.Name is complete checkbox should be enabled.
        pickupValidation_testScript.isNameCheckboxEnabled();

        //Step-3.Check the Name is Complete checkbox.
        pickupValidation_testScript.clickLnFnCheckBox(inputData);

        //Step-4.To continue the flow of next test case, click on Clear button.
        pickupValidation_testScript.clickClearButton();

        Reporter.log(">>>tc03_orderSearchNameCheckbox [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 4th Test Description: Verify that "Search Returned No Results!" pop-up window is shown when user enters invalid patient details.
     * JIRA ID: HWQEAUTO-6981
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 4, description = "Verify that Search Returned No Results! pop-up window is shown when user enters invalid patient details.",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSearchTestData1.json", sheetName = "TestData")
    public void tc04_orderSearchNone(Map<String, String> inputData) {

        Reporter.log(">>>tc04_orderSearchNone<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Enter Patient Last Name, Patient First Name and Patient DOB of a Patient not existing in DB.
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.Search Returned No Results popup is displayed.
        pickupValidation_testScript.validateSearchResultsNotFoundPopup();

        //Step-4.Click on OK button of the popup.
        pickupValidation_testScript.clickOkPopUp();

        Reporter.log(">>>tc04_orderSearchNone [Executed Successfully]<<<\n");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 5th Test Description: Verify if user is getting appropriate error message on invalid date input (non-leap year / date and months are interchanged).
     * JIRA ID: HWQEAUTO-7050
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 5, description = "Verify if user is getting appropriate error message on invalid date input (non-leap year / date and months are interchanged).",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSearchTestData1.json", sheetName = "TestData")
    public void tc05_orderSearchInvalidDate(Map<String, String> inputData) {

        Reporter.log(">>>tc05_orderSearchInvalidDate<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Enter Patient Last Name, Patient First Name and invalid Patient DOB of a Patient.
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.Invalid Date Format popup is displayed.
        pickupValidation_testScript.validateInvalidDobPopup();

        //Step-4.Click on OK button of the popup.
        pickupValidation_testScript.clickOkPopUp();

        //Step-5.To continue the flow of next test case, click on Clear button.
        pickupValidation_testScript.clickClearButton();

        Reporter.log(">>>tc05_orderSearchInvalidDate [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 6th Test Description: Verify if user is getting appropriate popup window on entering less than 4 digit phone number in Patient Phone field while the given DOB is correct.
     * JIRA ID: HWQEAUTO-7033
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 6, description = "Verify if user is getting appropriate popup window on entering less than 4 digit phone number in Patient Phone field while the given DOB is correct.",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSearchTestData1.json", sheetName = "TestData")
    public void tc06_orderSearchInsufficientPhone(Map<String, String> inputData) {

        Reporter.log(">>>tc06_orderSearchInsufficientPhone<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Enter Patient Last Name, Patient First Name, Patient DOB & Patient Phone (less than 4 digit).
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.Invalid Phone Number popup is displayed.
        pickupValidation_testScript.validateInvalidPhPopup();

        //Step-4.Click on OK button of the popup.
        pickupValidation_testScript.clickOkPopUp();

        //Step-5.To continue the flow of next test case, click on Clear button.
        pickupValidation_testScript.clickClearButton();

        Reporter.log(">>>tc06_orderSearchInsufficientPhone [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 7th Test Description: Verify if user is getting appropriate popup for invalid DOB and less than 4 digit phone number in Patient Phone field.
     * JIRA ID: HWQEAUTO-6986
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 7, description = "Verify if user is getting appropriate popup window on entering less than 4 digit phone number in Patient Phone field while the given DOB is correct.",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSearchTestData1.json", sheetName = "TestData")
    public void tc07_orderSearchInvalidDobInsufficientPhone(Map<String, String> inputData) {

        Reporter.log(">>>tc07_orderSearchInvalidDobInsufficientPhone<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Enter Patient Last Name, Patient First Name, invalid Patient DOB & Patient Phone (less than 4 digit).
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.Invalid Date Format popup is displayed instead of Invalid Phone Number popup.
        pickupValidation_testScript.validateInvalidDobPopup();

        //Step-4.Click on OK button of the popup.
        pickupValidation_testScript.clickOkPopUp();

        //Step-5.To continue the flow of next test case, click on Clear button.
        pickupValidation_testScript.clickClearButton();

        Reporter.log(">>>tc07_orderSearchInvalidDobInsufficientPhone [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 8th Test Description: Verify the Clear button functionality.
     * JIRA ID: HWQEAUTO-7040
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 8, description = "Verify the Clear button functionality.",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSearchTestData1.json", sheetName = "TestData")
    public void tc08_orderSearchClearButton(Map<String, String> inputData) {

        Reporter.log(">>>tc08_orderSearchClearButton<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Enter Patient Last Name, Patient First Name and Patient DOB of a Patient.
        pickupValidation_testScript.enterPatientDetails(inputData);

        //Step-2.Clear button should be enabled.
        pickupValidation_testScript.isClearButtonEnabled();

        //Step-2.Click on the Clear button.
        pickupValidation_testScript.clickClearButton();

        //Step-3.Input fields should become blank.
        pickupValidation_testScript.allFieldsBlank();

        Reporter.log(">>>tc08_orderSearchClearButton [Executed Successfully]<<<");
    }
    /**
     * ----------------------------------------------------------------------------------------------------------
     * 9th Test Description: Alerting upgrade for wrong RX scan at Tasco.
     * JIRA ID: HWPHME2E-5148
     * Author: kruthika
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 9, description = "Alerting upgrade for wrong RX scan at Tasco",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/DOM.json", sheetName = "TOSCO")
    public void HWPHME2E_5148_upgrade_for_wrong_RX_scan(Map<String, String> inputData) {
        int storeNbr = connexusAppUtils.getStoreId();
        Reporter.log("Store Number: " + storeNbr);
        Reporter.log("NDC Number from test data: " + inputData.get("NDC_NUMBER"));
        // Initialize test case with API context for patient creation
        boolean flagUpdated = false;
        pickupValidation_testScript.initializeTestCase(flagUpdated);
        // Set pharmacy parameter to make store behave as Specialty store
        pickupValidation_testScript.setSpecialtyStoreParameter(storeNbr);
        // Create patient and move order to pickup
        pickupValidation_testScript.createPatientAndMoveToPickup(inputData, storeNbr);
        pickupValidation_testScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // Perform RX scan at pickup validation screen
        pickupValidation_testScript.performRXscan(inputData);
        Reporter.log("Wrong RX scan test completed successfully");
    }

}