package connexus.sles.dom.testcases.theme1;

import connexus.sles.dom.testscript.PickupValidation_TestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.Map;

public class PickupValidationTestSet2_OrderSearch {

    PickupValidation_TestScript pickupValidation_testScript = new PickupValidation_TestScript();
    ConnexusAppUtils connexusAppUtils;

    @BeforeClass
    public void beforeClass() {
        //User logs into Connexus.
        pickupValidation_testScript.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAppUtils = new ConnexusAppUtils();
    }

    @AfterClass
    public void tearDown() {
        //Close All.
        pickupValidation_testScript.signOff();
        AutomationManager.getInstance().getConnexus().closeConnexus();
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 1st Test Description: Verify that the Previous Results icon is enabled and navigates to a blank screen.
     * JIRA ID: HWQEAUTO-7021
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 1, description = "Verify that the Previous Results icon is enabled and navigates to a blank screen")
    public void tc01_blankPreviousResults() {

        Reporter.log(">>>tc01_blankPreviousResults<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.
        pickupValidation_testScript.navigateToTaSCO();

        //Step-1.Previous Results icon should be enabled.
        pickupValidation_testScript.validatePreviousResults();

        //Step-2.Click on Previous Results icon.
        pickupValidation_testScript.navigateToPreviousResults();

        //Step-3.User should be navigated to Previous Results screen.
        pickupValidation_testScript.validateSearchResults();

        //Step-4.To continue the flow of next test case, click on Search button in top pane.
        pickupValidation_testScript.navigateSearchTopPane();

        Reporter.log(">>>tc01_blankPreviousResults [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 2nd Test Description: Verify that the Return to Pickup icon is enabled and navigates to a green Return to Pickup screen.
     * JIRA ID: HWQEAUTO-7021
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 2, description = "Verify that the Return to Pickup icon is enabled and navigates to a green Return to Pickup screen")
    public void tc02_returnToPickupIcon(){

        Reporter.log(">>>tc02_returnToPickupIcon<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Return to Pickup should be enabled.
        pickupValidation_testScript.validateReturnPickup();

        //Step-2.Click on Return to Pickup icon.
        pickupValidation_testScript.navigateToReturnToPickup();

        //Step-3.User should be navigated to Return to Pickup screen.
        pickupValidation_testScript.validateReturnToPickup();

        //Step-4.To continue the flow of next test case, click on Search button in top pane.
        pickupValidation_testScript.navigateSearchTopPane();

        Reporter.log(">>>tc02_returnToPickupIcon [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 3rd Test Description: Verify that the appropriate icons are disabled in the Order Search screen: Search and Order Comments.
     * JIRA ID: HWQEAUTO-7021
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 3, description = "Verify that the appropriate icons are disabled in the Order Search screen: Search and Order Comments")
    public void tc03_orderSearchDisabledIcons() {

        Reporter.log(">>>tc03_orderSearchDisabledIcons<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.User should see that the Search icon is enabled in the top pane, but is not functional.
        pickupValidation_testScript.validateSearchTopPane();
        pickupValidation_testScript.clickSearchTopPaneAndStay();

        //Step-2.User should see that the Order Comments icon is enabled in the top pane, but is not functional.
        pickupValidation_testScript.validateOrderComments();
        pickupValidation_testScript.clickOrderCommentsAndStay();

        Reporter.log(">>>tc03_orderSearchDisabledIcons [Executed Successfully]<<<\n");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 4th Test Description: Verify that the user is able to search all the Orders of a single Patient by entering valid Patient Last Name, Patient First Name and Patient DOB.
     * JIRA ID: HWQEAUTO-7014
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 4, description = "Verify that the user is able to search all the Orders of a single Patient by entering valid Patient Last Name, Patient First Name and Patient DOB",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSearchTestData2.json", sheetName = "TestData")
    public void tc04_singlePatientWithDob(Map<String, String> inputData) {

        Reporter.log(">>>tc04_singlePatientWithDob<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Enter Patient Last Name, Patient First Name and Patient DOB of a Patient.
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.User is navigated to Order Search Results screen.
        pickupValidation_testScript.validateSearchResults();

        //Step-4.To continue the flow of next test case, click on Search button in top pane.
        pickupValidation_testScript.navigateSearchTopPane();

        Reporter.log(">>>tc04_singlePatientWithDob [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 5th Test Description: Verify that the user is able to search all the Orders of a single Patient by entering valid Patient Last Name, Patient First Name and Patient Phone.
     * JIRA ID: HWQEAUTO-7014
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 5, description = "Verify that the user is able to search all the Orders of a single Patient by entering valid Patient Last Name, Patient First Name and Patient Phone",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSearchTestData2.json", sheetName = "TestData")
    public void tc05_singlePatientWithPhone(Map<String, String> inputData) {

        Reporter.log(">>>tc05_singlePatientWithPhone<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Enter Patient Last Name, Patient First Name and Patient Phone.
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.Validate the technical issues popup.
        pickupValidation_testScript.validateTechnicalIssuesPopup();

        //Step-4.To continue the flow of next test case, click on OK button in top pane.
        pickupValidation_testScript.clickOkPopUp();

        Reporter.log(">>>tc05_singlePatientWithPhone [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 6th Test Description: Verify that the user is able to search all the Orders of a single Patient by entering valid Patient Last Name, Patient First Name, Patient DOB and Patient Phone.
     * JIRA ID: HWQEAUTO-7014
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 6, description = "Verify that the user is able to search all the Orders of a single Patient by entering valid Patient Last Name, Patient First Name, Patient DOB and Patient Phone",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSearchTestData2.json", sheetName = "TestData")
    public void tc06_singlePatientWithBoth(Map<String, String> inputData) {

        Reporter.log(">>>tc06_singlePatientWithBoth<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Enter Patient Last Name, Patient First Name, Patient DOB and Patient Phone.
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.User is navigated to Order Search Results screen.
        pickupValidation_testScript.validateSearchResults();

        //Step-4.To continue the flow of next test case, click on Search button in top pane.
        pickupValidation_testScript.navigateSearchTopPane();

        Reporter.log(">>>tc06_singlePatientWithBoth [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 7th Test Description: Verify that the Previous Results icon shows the Order Search Result screen for the last Patient searched.
     * JIRA ID: HWQEAUTO-7021
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 7, description = "Verify that the Previous Results icon shows the Order Search Result screen for the last Patient searched")
    public void tc07_updatedPreviousResults() {

        Reporter.log(">>>tc07_updatedPreviousResults<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Click on Previous Results icon.
        pickupValidation_testScript.navigateToPreviousResults();

        //Step-2.User should be navigated to Previous Results screen.
        pickupValidation_testScript.validateSearchResults();

        //Step-3.To continue the flow of next test case, click on Search button in top pane.
        pickupValidation_testScript.navigateSearchTopPane();

        Reporter.log(">>>tc07_updatedPreviousResults [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 8th Test Description: Verify that the user is able to navigate to multiple Patient screen by entering valid Patient Last Name, Patient First Name and Patient DOB.
     * JIRA ID: HWQEAUTO-7095
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 8, description = "Verify that the user is able to navigate to multiple Patient screen by entering valid Patient Last Name, Patient First Name and Patient DOB",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSearchTestData2.json", sheetName = "TestData")
    public void tc08_multiplePatientWithDob(Map<String, String> inputData) {

        Reporter.log(">>>tc08_multiplePatientWithDob<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Enter Patient Last Name, Patient First Name and Patient DOB of a Patient.
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.Validate the Orders of Multiple Patients Found popup.
        pickupValidation_testScript.validateMultiplePatientFoundPopup();

        //Step-4.Click on OK button of the popup.
        pickupValidation_testScript.clickOkPopUp();

        //Step-5.User is navigated to Multiple Patient screen.
        pickupValidation_testScript.validateMultiplePatientScreen();

        //Step-6.To continue the flow of next test case, click on Search button in top pane.
        pickupValidation_testScript.navigateSearchTopPane();

        Reporter.log(">>>tc08_multiplePatientWithDob [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 9th Test Description: Verify that the user is able to navigate to multiple Patient screen by entering valid Patient Last Name, Patient First Name and Patient Phone.
     * JIRA ID: HWQEAUTO-7095
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 9, description = "Verify that the user is able to navigate to multiple Patient screen by entering valid Patient Last Name, Patient First Name and Patient Phone",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSearchTestData2.json", sheetName = "TestData")
    public void tc09_multiplePatientWithPhone(Map<String, String> inputData) {

        Reporter.log(">>>tc09_multiplePatientWithPhone<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Enter Patient Last Name, Patient First Name and Patient Phone.
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.Validate the technical issues popup.
        pickupValidation_testScript.validateTechnicalIssuesPopup();

        //Step-4.To continue the flow of next test case, click on OK button in top pane.
        pickupValidation_testScript.clickOkPopUp();

        Reporter.log(">>>tc09_multiplePatientWithPhone [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 10th Test Description: Verify that the user is able to navigate to multiple Patient screen by entering valid Patient Last Name, Patient First Name, Patient DOB and Patient Phone.
     * JIRA ID: HWQEAUTO-7095
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 10, description = "Verify that the user is able to navigate to multiple Patient screen by entering valid Patient Last Name, Patient First Name, Patient DOB and Patient Phone",
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/sles/dom/theme1/OrderSearchTestData2.json", sheetName = "TestData")
    public void tc10_multiplePatientWithBoth(Map<String, String> inputData) {

        Reporter.log(">>>tc10_multiplePatientWithBoth<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.

        //Step-1.Enter Patient Last Name, Patient First Name, Patient DOB and Patient Phone.
        //Step-2.Click on the Search button.
        pickupValidation_testScript.orderOrPatientSearch(inputData);

        //Step-3.Validate the Orders of Multiple Patients Found popup.
        pickupValidation_testScript.validateMultiplePatientFoundPopup();

        //Step-4.Click on OK button of the popup.
        pickupValidation_testScript.clickOkPopUp();

        //Step-5.User is navigated to Multiple Patient screen.
        pickupValidation_testScript.validateMultiplePatientScreen();

        Reporter.log(">>>tc10_multiplePatientWithBoth [Executed Successfully]<<<");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * 11th Test Description: Verify that the user is able to get Orders after selecting the Patient from multiple Patient screen.
     * JIRA ID: HWQEAUTO-7085
     * Author: M Eswara Visakan (vn50ym2)
     * -----------------------------------------------------------------------------------------------------------
     */

    @Test(priority = 11, description = "Verify that the user is able to get Orders after selecting the Patient from multiple Patient screen")
    public void tc11_multiplePatientSelect() {

        Reporter.log(">>>tc11_multiplePatientSelect<<<");

        //Pre-Conditions:
        //1.User has logged into Connexus.
        //2.User has navigated to TaSCO Order Search screen.
        //3.User has searched for a multiple Patient and is on the Multiple Patient screen.

        //Step-1.Click on the required patient.
        pickupValidation_testScript.selectSinglePatient();

        //Step-2.User is navigated to Order Search Results screen.
        pickupValidation_testScript.clickOkPopUp();
        pickupValidation_testScript.validateSearchResults();

        Reporter.log(">>>tc11_multiplePatientSelect [Executed Successfully]<<<");
    }
}
