package connexus.dcs.testscripts;

import com.aventstack.extentreports.Status;
import fom.NewOrderDrop;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.joda.time.DateTime;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;

import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static connexus.dcs.Constants.*;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.prop;

public class DCSTestScripts extends ConnexusTestScripts {
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;

    public DCSTestScripts(LoginAs.userType loginUserType) {
        super(loginUserType);
    }

    public void validateEarlyRefillPopUpAndCompleteInput(Map<String, String> inputData) {
        int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        String[] name = connexusAppUtils.readPatientNameFromFile();
        if (inputPage.getInputScreenPopupMessage().contains(inputData.get("EARLIST_FILL_DATE_MESSAGE"))) {
            inputPage.clickButtonOk();
            inputPage.clickEarliestFillDateCheckBox();
            Reporter.logScreenShot(Status.PASS, "EarliestFillDate", connexusStartPage.takeScreenShot("InputPage").getValue());
            inputPage.clickAccept();
            inputPage.clickOnOutofStockPopupOk();

            getRxNbr(name[0], name[1], siteId);
        }

    }

    /**
     * Consolidated ChkDUR method to handle all flag validation types
     * This method reduces code duplication across all performChkDUR methods
     */
    private void performChkDURConsolidated(ChkDURFlagType flagType, Map<String, String> inputData, boolean needsResolution, boolean needsComparison) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();

                if (chkdurPage.clickRedFlagsBtn()) {
                    List<String> redFlagsList = new ArrayList<>();

                    // Handle different red flag reading patterns
                    if (needsComparison) {
                        chkdurPage.readRedFlag(redFlagsList);
                        chkdurPage.compareRedFlags();
                        Reporter.log("Validate DCS alert matches with alert generated before at chkDUR queue and DUR alert is not displaying on second time since it's already resolved");
                    } else if (flagType == ChkDURFlagType.GENERIC) {
                        chkdurPage.readRedFlag(redFlagsList);
                    } else {
                        chkdurPage.readRedFlags();
                    }

                    // Perform specific flag validations
                    performSpecificFlagValidation(flagType, inputData);

                    Reporter.logScreenShot(Status.PASS, "Resolving Red flags", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    chkdurPage.selectResolvedCheckBoxes();
                    chkdurPage.clickDurBtn();
                    if (!needsComparison) {
                        Reporter.logScreenShot(Status.PASS, "Resolving DUR Alerts", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    }
                }

                if (!chkdurPage.clickClearConflictsBtn()) {
                    chkdurPage.selectAllCheckBoxes();
                }
                chkdurPage.clickNarxCareCheckBox();

                // Handle different DUR alerts methods
                if (flagType == ChkDURFlagType.MULTIPLE_REFUSAL_NATIONWIDE || flagType == ChkDURFlagType.MULTIPLE_REFUSAL_OHIO) {
                    chkdurPage.checkDURAlerts();
                } else {
                    chkdurPage.readDURAlerts();
                }

                if (needsComparison) {
                    Reporter.logScreenShot(Status.PASS, "DUR Alert Not Generated since it's already resolved", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                }

                chkdurPage.clickAccept();

                // Handle resolution page if needed
                if (needsResolution) {
                    ResolutionPage resolutionPage = new ResolutionPage();
                    resolutionPage.clickProblemResolved();
                }
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Performs specific flag validation based on the flag type
     */
    private void performSpecificFlagValidation(ChkDURFlagType flagType, Map<String, String> inputData) {
        switch (flagType) {
            case EARLY_REFILL_NATIONWIDE:
                chkdurPage.validateEarlyRefillNationwide(earlyRefillNationwideflag);
                break;
            case MULTIPLE_DCS_FLAG:
                chkdurPage.validateMultipleDCSFlag(multipleDCSflag);
                break;
            case DISTANCE_FLAG:
                chkdurPage.validateDistanceRedFlag(distanceflag1, distanceflag2,distanceflag3);
                break;
            case MULTIPLE_REFUSAL_NATIONWIDE:
                chkdurPage.validateMultipleRefusalRedFlagNationwide(multipleRefusalflagNationwide);
                break;
            case MULTIPLE_REFUSAL_OHIO:
                chkdurPage.validateMultipleRefusalRedFlagOhio(multipleRefusalflagOhio);
                break;
            case MULTIPLE_PRESCRIBER_NATIONWIDE:
                chkdurPage.validateMultiplePrescriberNationWide(multiplePrescriberNationwideflag);
                break;
            case PROFESSIONAL_JUDGEMENT:
                chkdurPage.validateProfessionalJudgementFlag(professionalJudgementflag);
                break;
            case COMBINATION_RED_FLAG:
                chkdurPage.validateCombinationRedFlag(CombinationRedflag);
                break;
            case MULTIPLE_PRESCRIBER_OHIO:
                chkdurPage.validateMultiplePrescriberOhio(MultiplePrescriberOhioflag);
                break;
            case EARLY_REFILL_OHIO:
                chkdurPage.validateEarlyRefillOhioRedFlag(earlyRefillOhioflag);
                break;
            case GENERIC:
            case AFTER_TP_TO_CASH_SWITCH:
            default:
                // No specific validation needed for generic cases
                break;
        }
    }

    public void performChkDURDCSAlertsBeforeSwitchingTPtoCASH() {
        performChkDURConsolidated(ChkDURFlagType.GENERIC, null, true, false);
    }

    public void performChkDUREarlyRefillNationwide() {
        performChkDURConsolidated(ChkDURFlagType.EARLY_REFILL_NATIONWIDE, null, false, false);
    }

    public void performChkDURMultipleDCSFlag() {
        performChkDURConsolidated(ChkDURFlagType.MULTIPLE_DCS_FLAG, null, false, false);
    }


    public void performChkDURDCSAlertsAfterSwitchingTPtoCASH() {
        performChkDURConsolidated(ChkDURFlagType.AFTER_TP_TO_CASH_SWITCH, null, false, true);
    }

    public void switchToCASHFromTPDCSAlerts(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.openModifyDetailsScreen();
                modifyDetails.modifyQtyPrescribed(inputData);
                modifyDetails.modifyQtyDispensed(inputData);
                modifyDetails.modifyDaysSupply(inputData);
                modifyDetails.switchPaymentPlan("CASH");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickAccept();
                modifyDetails.checkAndClickWarning();
                modifyDetails.selectReasonForPaymentSwitch(); //found it's an optional popup
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.checkAndClickWarning();
            } else {
                Reporter.log("RX is not in Visual verify queue");
                Assert.fail("RX is not in Visual verify queue");
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void performEarlyRefillsAuthorization(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.TroubleShooting.getValue())) {
                automationManager.getConnexusWorkFlow().completeResolutionForEarlyRefill(rxNbr);
            } else {
                Reporter.log("RX is not in Resolve queue");
                Assert.fail("RX is not in Resolve queue");
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void performChkDURDistanceFlag() {
        performChkDURConsolidated(ChkDURFlagType.DISTANCE_FLAG, null, false, false);
    }

    public void performChkDURMultipleRefusalFlagNationWide(Map<String, String> inputData) {
        performChkDURConsolidated(ChkDURFlagType.MULTIPLE_REFUSAL_NATIONWIDE, inputData, false, false);
    }

    public void validateCHkDURBeforeSwitchingFromTPToCASH(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.TroubleShooting.getValue())) {
                automationManager.getConnexusWorkFlow().completeResolutionForEarlyRefill(inputData.get("LAST_NAME") + "," + inputData.get("FIRST_NAME"));
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                orderSearch.launchOrderSearchScreen();
                patientSearchPage.performSearch(inputData.get("LAST_NAME") + "," + inputData.get("FIRST_NAME"));
                orderSearch.openFirstPatientRecord();
                if (chkdurPage.clickRedFlagsBtn()) {
                    List<String> redFlagsList = new ArrayList<>();
                    chkdurPage.readRedFlag(redFlagsList);
                    Reporter.logScreenShot(Status.PASS, "Resolving Red flags", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    chkdurPage.selectResolvedCheckBoxes();
                    chkdurPage.clickDurBtn();
                }

                if (!chkdurPage.clickClearConflictsBtn()) {
                    chkdurPage.selectAllCheckBoxes();
                }
                chkdurPage.clickNarxCareCheckBox();
                Reporter.logScreenShot(Status.PASS, "Resolving DUR Alerts if any", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                chkdurPage.readDURAlerts();
                chkdurPage.clickAccept();
                ResolutionPage resolutionPage = new ResolutionPage();
                resolutionPage.clickProblemResolved();
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at ChkDUR queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void dbValidation(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            int siteId;
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            siteId = Integer.parseInt(prop.getProperty("cnx.store"));
            IDatabaseContext cnx = automationManager.getConnexusDB(siteId);

            String patientId = connexusAppUtils.getPatientId(name[0], name[1]);
            String orderId = automationManager.getConnexusDB(siteId).getScalar(
                    "select OD.order_id from informix.rx_order_detail as OD join rx as RX \n" +
                            "on OD.rx_id =  RX.rx_id where RX.patient_id='" + patientId + "'limit 1", String.class);

            String rx_ID = automationManager.getConnexusDB().getScalar(
                    "select rx_id from rx where rx_nbr in (" + rxNbr + ");", String.class);
            String rx_fill_ID = automationManager.getConnexusDB().getScalar(
                    "select * from rx_fill where rx_id in (" + rx_ID + ");", String.class);
            String comment_id = automationManager.getConnexusDB().getScalar(
                    "select comment_id from conflict_comment where rx_id in (" + rx_ID + ");", String.class);
            String rx_conflict = "select * from rx_conflict where rx_id in (" + rx_ID + ");";
            DataTable conflict_dt = cnx.getDataTable(rx_conflict);
            Assert.assertNotEquals(conflict_dt.getRowCount(), 0);
            String rx_comment = "select * from rx_comment where rx_id in (" + rx_ID + ");";
            DataTable rx_comment_dt = cnx.getDataTable(rx_comment);
            Assert.assertNotEquals(rx_comment_dt.getRowCount(), 0);
            Reporter.log("DB records are inserted in rx_conflict and rx_comment");
        } catch (NumberFormatException e) {
            throw new RuntimeException(e);
        }
    }

    public void sendCurlRequestsMultipleRefusals() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        int storeNbr = Integer.parseInt(prop.getProperty("cnx.store"));
        IDatabaseContext cnx = automationManager.getConnexusDB(storeNbr);

        String patientId = connexusAppUtils.getPatientId(name[0], name[1]);
        LocalDate today = LocalDate.now();

        // Subtract one day to get yesterday's date
        LocalDate yesterday = today.minusDays(1);

        // Format the date as MM/DD/YYYY
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        String yesterdayFormatted = yesterday.format(formatter);
        int count = 0;
        for (int i = 0; i < 2; i++) {
            count++;
            req.setUrl("https://rtf-service.stg.hw.prm.cloud.walmart.com/v1/prescriber/refusalinfo?action=RTF");
            headers.put("content-type", "application/json");
            headers.put("WM_SVC.ENV", "stg");
            headers.put("WM_SVC.NAME", "HW-PRM-RTF-SERVICE");
            headers.put("WM_CONSUMER.ID", "cb8e5edf-ae01-4285-a19d-5ac1da92f5dc");
            req.setHeaders(headers);
            req.setRequestPayload("{\"storeId\":\"" + storeNbr + "\",\"patient\":{\"redFlags\":[\"Drugabuse\",\"etc...\"],\"firstName\":\"" + name[1] + "\",\"lastName\":\"" + name[0] + "\",\"middleName\":\"\",\"dob\":\"01/02/1981\",\"patientId\":\"" + patientId + "\",\"comments\":\"Commentsfield\",\"patientType\":\"HUMAN\"},\"prescriber\":{\"redFlags\":[\"WroteSimilarmedication,dosagedirectionsfornumberousindividuals\",\"Wroteprescribptionthatisunsualforprescriberspracticespeciality\",\"etc...\"],\"firstName\":\"THOMAS\",\"lastName\":\"WALDEN\",\"npi\":\"2999997788\",\"dea\":[\"BT2413146\"],\"address\":\"TESTADDR1,TE12345\",\"phone\":\"(707)944-2142\",\"fax\":\"(479)374-9972\",\"comments\":\"Commentshere\"},\"prescription\":{\"drugType\":\"Controlled\",\"drugName\":\"TRAMADOL\",\"writtenDate\":\"" + yesterdayFormatted + "\",\"datePresented\":\"" +yesterdayFormatted + "\",\"rxType\":\"Electronic\",\"isResident\":true},\"user\":{\"name\":\"GurjeetKaur\",\"win\":227624779,\"userId\":\"vn54zw4\",\"role\":\"USER\"},\"refusalReason\":\"AlteredRx\",\"validateRXwithPrescriber\":\"Yes\",\"active\":true}");
            Log.info("RequestPayload:\n" + req.getRequestPayload() + "\n");
            resp = automationManager.getRestContext().performPost(req, 2);
            Reporter.logJSON("Curl request sent to trigger" +" "+ count+" "+"refusal:", req.getRequestPayload());
            Reporter.logJSON(count +" "+"Refusal created successfully:", resp.getDataResponse());
            Assert.assertEquals(resp.getStatusCode(), 200, "Refusal triggered twice successfully");

        }
        Reporter.log("Multiple refusals created=" + count);

        req.setUrl("https://rtf-service.stg.hw.prm.cloud.walmart.com/v1/patient/refusalinfo?filterDays=30&storeId=5511");
        headers.put("content-type", "application/json");
        headers.put("WM_SVC.ENV", "stg");
        headers.put("WM_SVC.NAME", "HW-PRM-RTF-SERVICE");
        headers.put("WM_CONSUMER.ID", "cb8e5edf-ae01-4285-a19d-5ac1da92f5dc");
        req.setHeaders(headers);
        req.setRequestPayload("{\"patientLinks\":[{\"storeNbr\":\"" + storeNbr + "\",\"patientId\":\"" + patientId + "\"}],\"patient\":{\"patientId\":\"" + patientId + "\",\"storeNbr\":\"" + storeNbr + "\"}}");
        Log.info("RequestPayload:\n" + req.getRequestPayload() + "\n");
        Reporter.logJSON("Curl request sent to check refusal created:", req.getRequestPayload());
        resp = automationManager.getRestContext().performPost(req, 2);
        Reporter.logJSON("Response received successfully:", resp.getDataResponse());

    }

    public void performChkDURMultipleRefusalFlagOhio(Map<String, String> inputData) {
        performChkDURConsolidated(ChkDURFlagType.MULTIPLE_REFUSAL_OHIO, inputData, false, false);
    }

    public void sendCurlRequestsMultipleRefusalsOhio() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        int storeNbr = Integer.parseInt(prop.getProperty("cnx.store"));
        IDatabaseContext cnx = automationManager.getConnexusDB(storeNbr);

        String patientId = connexusAppUtils.getPatientId(name[0], name[1]);
        LocalDate today = LocalDate.now();

        // Subtract one day to get yesterday's date
        LocalDate yesterday = today.minusDays(1);

        // Format the date as MM/DD/YYYY
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        String yesterdayFormatted = yesterday.format(formatter);
        int count = 0;
        req.setUrl("https://rtf-service.stg.hw.prm.cloud.walmart.com/v1/prescriber/refusalinfo?action=RTF");
        headers.put("content-type", "application/json");
        headers.put("WM_SVC.ENV", "stg");
        headers.put("WM_SVC.NAME", "HW-PRM-RTF-SERVICE");
        headers.put("WM_CONSUMER.ID", "cb8e5edf-ae01-4285-a19d-5ac1da92f5dc");
        req.setHeaders(headers);
        req.setRequestPayload("{\"storeId\":\"" + storeNbr + "\",\"patient\":{\"redFlags\":[\"Drugabuse\",\"etc...\"],\"firstName\":\"" + name[1] + "\",\"lastName\":\"" + name[0] + "\",\"middleName\":\"\",\"dob\":\"01/02/1981\",\"patientId\":\"" + patientId + "\",\"comments\":\"Commentsfield\",\"patientType\":\"HUMAN\"},\"prescriber\":{\"redFlags\":[\"WroteSimilarmedication,dosagedirectionsfornumberousindividuals\",\"Wroteprescribptionthatisunsualforprescriberspracticespeciality\",\"etc...\"],\"firstName\":\"THOMAS\",\"lastName\":\"WALDEN\",\"npi\":\"2999997788\",\"dea\":[\"BT2413146\"],\"address\":\"TESTADDR1,TE12345\",\"phone\":\"(707)944-2142\",\"fax\":\"(479)374-9972\",\"comments\":\"Commentshere\"},\"prescription\":{\"drugType\":\"Controlled\",\"drugName\":\"TRAMADOL\",\"writtenDate\":\"" + yesterdayFormatted + "\",\"datePresented\":\"" + yesterdayFormatted + "\",\"rxType\":\"Electronic\",\"isResident\":true},\"user\":{\"name\":\"GurjeetKaur\",\"win\":227624779,\"userId\":\"vn54zw4\",\"role\":\"USER\"},\"refusalReason\":\"AlteredRx\",\"validateRXwithPrescriber\":\"Yes\",\"active\":true}");
        Log.info("RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = automationManager.getRestContext().performPost(req, 2);
        count++;
        Reporter.logJSON("Curl request sent to trigger a refusal:", req.getRequestPayload());
        Reporter.logJSON("Refusal created successfully:", resp.getDataResponse());
        Assert.assertEquals(resp.getStatusCode(), 200, "Refusal triggered once successfully");
        Reporter.log("Refusal created=" + count);
        Reporter.log("Curl request sent to check refusal created");
        req.setUrl("https://rtf-service.stg.hw.prm.cloud.walmart.com/v1/patient/refusalinfo?filterDays=30&storeId=5511");
        headers.put("content-type", "application/json");
        headers.put("WM_SVC.ENV", "stg");
        headers.put("WM_SVC.NAME", "HW-PRM-RTF-SERVICE");
        headers.put("WM_CONSUMER.ID", "cb8e5edf-ae01-4285-a19d-5ac1da92f5dc");
        req.setHeaders(headers);
        req.setRequestPayload("{\"patientLinks\":[{\"storeNbr\":\"" + storeNbr + "\",\"patientId\":\"" + patientId + "\"}],\"patient\":{\"patientId\":\"" + patientId + "\",\"storeNbr\":\"" + storeNbr + "\"}}");
        Log.info("RequestPayload:\n" + req.getRequestPayload() + "\n");
        Reporter.logJSON("Curl request sent to check refusal created:", req.getRequestPayload());
        resp = automationManager.getRestContext().performPost(req, 2);
        Reporter.logJSON("Response received successfully:", resp.getDataResponse());
    }

    public void performEarlyRefillAuthorization(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.TroubleShooting.getValue())) {
                ResolutionPage resolutionPage = new ResolutionPage();
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                resolutionPage.clickApprovalCheckBox();
                resolutionPage.enterReasonForEarlyRefill();
                resolutionPage.clickApproveEarlyRefill();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("Resolution completed");
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void completeResolution() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr,WorkQueueSettings.TroubleShooting.getValue())) {
                Reporter.log("RX is in Resolve queue");
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            } else {
                Reporter.log("RX is in not in Resolved queue");
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Filling queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public int getPatientId(Map<String, String> inputData) {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String query = "select patient_id from patient where first_name= " + "'" + name[1].toUpperCase() + "'" + " and last_name = " + "'" + name[0].toUpperCase() + "';";
        Log.info(query);
        int siteID = Integer.parseInt(prop.getProperty("cnx.store"));
        Log.info("siteId:" + siteID);
        int patientId = automationManager.getConnexusDB(siteID).getScalar
                (query, Integer.class);
        Log.info("patientId:" + patientId);
        return patientId;
    }

    /**
     * Consolidated Multi-RX drop-off method to handle 2, 3, or 4 RX scenarios
     * This method reduces code duplication across dropXRXTill4Point methods
     */
    private void performMultiRXDropOffConsolidated(MultiRXType rxType, Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            RxModel rxModel = new RxModel();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            // Perform drop-off based on RX count
            String patientFullName = name[0] + "," + name[1];
            switch (rxType) {
                case TWO_RX:
                    dropOffWith2Drug(patientFullName, Priority.Critical, 1, "12:30");
                    break;
                case THREE_RX:

                    dropOffWith3Drug(patientFullName, Priority.Critical, 1, "12:30");
                    break;
                case FOUR_RX:
                    dropOffWith4Drug(patientFullName, Priority.Critical, 1, "12:30");
                    break;
            }

            // Setup first RX model
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxModel.setNdc(inputData.get("DRUG_NAME"));
            rxModel.setPrescribedQty(inputData.get("QUANTITY"));
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            automationManager.getConnexusWorkFlow().performInput(rxModel);

            // Perform additional RX inputs based on count
            for (int i = 2; i <= rxType.getRxCount(); i++) {
                String drugKey = "DRUG_NAME" + (i-1);
                String prescriberKey = "PRESCRIBER_NAME" + (i-1);

                performInputForRXConsolidated(i, patientFullName,
                        inputData.get(drugKey),
                        inputData.get("QUANTITY"),
                        inputData.get("SIG"),
                        inputData.get("REFILLS"),
                        inputData.get(prescriberKey), inputData.get("EARLIST_FILL_DATE_MESSAGE"));
            }

        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed during Multi-RX drop-off");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Consolidated Multi-RX drop-off with drugs method
     * This method reduces code duplication across dropOffWithXDrug methods
     */
    private void performMultiRXDropOffWithDrugsConsolidated(MultiRXType rxType, String patientName, Priority priority, int noOfRx, String pickupTime) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DropOffPage dropOff = new DropOffPage();

        try {
            dropOff.clickDropOffQueue();
            dropOff.enterPatientName(patientName);
            dropOff.clickPatientSearch();
            dropOff.handleAnnualValidatePatInfoPopUp();

            // Process each RX
            for (int rxNumber = 1; rxNumber <= rxType.getRxCount(); rxNumber++) {
                dropOff.clickScanNewRx();
                dropOff.switchWindow();
                String barCode = dropOff.generateRxBarCode();
                dropOff.enterBarCode(barCode);
                Reporter.log("New barcode entered for RX " + rxNumber + ": " + barCode);
                dropOff.clickBtnAccept();
                dropOff.switchWindow();
                dropOff.clickVerifyBarCode();
                dropOff.selectRxOrigin();
                dropOff.clickBtnAccept();

                if (rxNumber < rxType.getRxCount()) {
                    Reporter.log("Completed RX " + rxNumber + ", proceeding to next RX");
                }
            }

            // Final drop-off steps
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            dropOff.selectPriority(priority.getPriority());

            if (priority == Priority.Future) {
                dropOff.selectPickupTime(pickupTime);
            }
            dropOff.clickBtnAccept();
            dropOff.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed for " + rxType.getDescription());

        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed during Multi-RX drop-off with drugs");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Consolidated Multi-RX input method
     * This method reduces code duplication across performInputXRX methods
     */
    private void performInputForRXConsolidated(int rxNumber, String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName, String earliestFillDate) {
        performInputForRXConsolidated(rxNumber, patientName, ndc, prescribedQty, sigCode, refills, prescriberName, null, earliestFillDate);
    }

    /**
     * Consolidated Multi-RX input method with optional input data for early fill handling
     */
    private void performInputForRXConsolidated(int rxNumber, String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName, Map<String, String> inputData, String earliestFillDate) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        F6Search rxSearch = new F6Search();
        InputPage inputPage = new InputPage();

        try {
            rxSearch.performSearch(patientName, SearchType.PatientRx);
            rxSearch.selectRowFromSearch(rxNumber - 1); // 0-based index
            inputPage.enterNdc(ndc);
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(prescribedQty);
            inputPage.enterSigCode(sigCode);
            inputPage.enterRefillQty(refills);
            inputPage.selectDAW(1);
            inputPage.enterPrescriber(prescriberName);
            Reporter.log("Prescriber NPI used for " + getOrdinalNumber(rxNumber) + " Input: " + prescriberName);

            // Handle optional fields
            if (inputPage.isTMCodeDisplayed()) {
                inputPage.selectTmCodeField(2);
            }
            if (inputPage.isDxCodeDisplayed()) {
                inputPage.inputRandomDXCode();
            }
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }

            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            if (inputPage.getInputScreenPopupMessage().contains(earliestFillDate)) {
                inputPage.clickButtonOk();
                inputPage.clickEarliestFillDateCheckBox();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                inputPage.clickAccept();
            }

            inputPage.pressKeys(KeyEvent.VK_ENTER);
            Reporter.log("Input completed for " + getOrdinalNumber(rxNumber) + " RX");

        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed during " + getOrdinalNumber(rxNumber) + " RX input");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /**
     * Helper method to convert number to ordinal string (1st, 2nd, 3rd, 4th)
     */
    private String getOrdinalNumber(int number) {
        switch (number) {
            case 1: return "1st";
            case 2: return "2nd";
            case 3: return "3rd";
            case 4: return "4th";
            default: return number + "th";
        }
    }

    public void drop3RXTill4Point(Map<String, String> inputData) {
        performMultiRXDropOffConsolidated(MultiRXType.THREE_RX, inputData);
    }

    public void dropOffWith3Drug(String patientName, Priority priority, int noOfRx, String pickupTime) {
        performMultiRXDropOffWithDrugsConsolidated(MultiRXType.THREE_RX, patientName, priority, noOfRx, pickupTime);
    }

    public void performInput3rdRX(String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName, String earliestFillDate) {
        performInputForRXConsolidated(3, patientName, ndc, prescribedQty, sigCode, refills, prescriberName,earliestFillDate);
    }

    public void performInput2ndRX(Map<String, String> inputData, String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName,String earliestFillDate) {
        performInputForRXConsolidated(2, patientName, ndc, prescribedQty, sigCode, refills, prescriberName, earliestFillDate);
    }
    public void perform4PointForControlledDrugForProfessionalJudgementFlag() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if(checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point "+rxNbr,"In progress",fileName,40, DateTime.now());
            } else {
                connexusAppUtils.writeTextToFile("RX is not in 4 point "+rxNbr,"In progress",fileName,40, DateTime.now());
                Reporter.log("RX is not in 4 Point, Performing Resolve Queue");
                performResolveQueue(rxNbr);
            }
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            String productName = orderSearch.getProductName(0);
            FourPoint fourpoint = new FourPoint();
            orderSearch.openFirstPatientRecord();
            if (fourpoint.isElementDisplayed(fourpoint.cmbDrugReEntry)) {
                Assert.assertFalse(fourpoint.isElementEnabled(fourpoint.btnValidateReEntry));
                fourpoint.selectValueFromTheListBasedOnIndex(fourpoint.cmbDrugReEntry, fourpoint.getDrugReleaseType(productName));
                fourpoint.click(fourpoint.btnValidateReEntry);
            }
            fourpoint.chkName();
            fourpoint.chkPrescribed();
            if (fourpoint.ischkStrength()) {
                fourpoint.chkStrength();
            }
            fourpoint.chkSIG();

            if (fourpoint.isElementDisplayed(fourpoint.chkDEA, 1)) {
                fourpoint.click(fourpoint.chkDEA);
            }
            if (fourpoint.isElementDisplayed(fourpoint.rdbAcute, 1)) {
                fourpoint.click(fourpoint.rdbAcute);
            }
            if (fourpoint.isElementDisplayed(fourpoint.rdbAcuteInitialFillYes, 5)) {
                fourpoint.click(fourpoint.rdbAcuteInitialFillYes);
            }
            if (fourpoint.isElementDisplayed(fourpoint.btnAcceptFill, 3)) {
                fourpoint.click(fourpoint.btnAcceptFill);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
            fourpoint.clickAccept();
            Reporter.log("4 point completed");
            if (chkdurPage.isChkDurOpen()) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("CheckDUR " + chkdurPage.takeScreenShot("CheckDUR").getKey());
                chkdurPage.selectCheckBoxes();
                chkdurPage.clickAccept();
            }

        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at 4 Point queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }
    public void performChkDURDCSAlerts() {
        performChkDURConsolidated(ChkDURFlagType.GENERIC, null, false, false);
    }
    public void validateDBRecords() {
        int siteId;
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);

        String patientId = connexusAppUtils.getPatientId(name[0], name[1]);
        String orderId = automationManager.getConnexusDB(siteId).getScalar(
                "select OD.order_id from informix.rx_order_detail as OD join rx as RX \n" +
                        "on OD.rx_id =  RX.rx_id where RX.patient_id='" + patientId + "'limit 1", String.class);

        String rx_ID = automationManager.getConnexusDB().getScalar(
                "select rx_id from rx where rx_nbr in (" + rxNbr + ");", String.class);
        String rx_fill_ID = automationManager.getConnexusDB().getScalar(
                "select * from rx_fill where rx_id in (" + rx_ID + ");", String.class);
        String comment_id = automationManager.getConnexusDB().getScalar(
                "select comment_id from conflict_comment where rx_id in (" + rx_ID + ");", String.class);
        String rx_conflict = "select * from rx_conflict where rx_id in (" + rx_ID + ");";
        DataTable conflict_dt = cnx.getDataTable(rx_conflict);
        Assert.assertNotEquals(conflict_dt.getRowCount(), 0);
        String rx_comment = "select * from rx_comment where rx_id in (" + rx_ID + ");";
        DataTable rx_comment_dt = cnx.getDataTable(rx_comment);
        Assert.assertNotEquals(rx_comment_dt.getRowCount(), 0);
        String comment_line = "select * from comment_line where comment_id in (" + comment_id + ");";
        DataTable comment_line_dt = cnx.getDataTable(comment_line);
        Assert.assertNotEquals(comment_line_dt.getRowCount(), 0);
        String pharmacy_message = "select * from pharmacy_message:dur_audit where rx_fill_id in (" + rx_fill_ID + ");";
        DataTable pharmacy_message_dt = cnx.getDataTable(pharmacy_message);
        Assert.assertEquals(pharmacy_message_dt.getRowCount(), 0);
        String pharmacy_message1 = "select * from pharmacy_message:dur_audit where rx_id in (" + rx_ID + ");";
        DataTable pharmacy_message1_dt = cnx.getDataTable(pharmacy_message1);
        Assert.assertEquals(pharmacy_message1_dt.getRowCount(), 0);
        Reporter.log("DB records are inserted in rx_conflict, rx_comment, comment_line and conflict_comment");
    }
    public void drop4RXTill4Point(Map<String, String> inputData) {
        performMultiRXDropOffConsolidated(MultiRXType.FOUR_RX, inputData);
    }
    public void performInput4thRX(String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName, String earliestFillDate) {
        performInputForRXConsolidated(4, patientName, ndc, prescribedQty, sigCode, refills, prescriberName,earliestFillDate);
    }
    public void dropOffWith4Drug(String patientName, Priority priority, int noOfRx, String pickupTime) {
        performMultiRXDropOffWithDrugsConsolidated(MultiRXType.FOUR_RX, patientName, priority, noOfRx, pickupTime);
    }
    public void performChkDURMultiplePrescriberNationWide() {
        performChkDURConsolidated(ChkDURFlagType.MULTIPLE_PRESCRIBER_NATIONWIDE, null, false, false);
    }
    public void performChkDURProfessionalJudgementFlag() {
        performChkDURConsolidated(ChkDURFlagType.PROFESSIONAL_JUDGEMENT, null, false, false);
    }
    public void drop2RXTill4Point(Map<String, String> inputData) {
        performMultiRXDropOffConsolidated(MultiRXType.TWO_RX, inputData);
    }
    public void dropOffWith2Drug(String patientName, Priority priority, int noOfRx, String pickupTime) {
        performMultiRXDropOffWithDrugsConsolidated(MultiRXType.TWO_RX, patientName, priority, noOfRx, pickupTime);
    }

    public void performChkDURCombinationRedFlag() {
        performChkDURConsolidated(ChkDURFlagType.COMBINATION_RED_FLAG, null, false, false);
    }
    public void performChkDURMultiplePrescriberOhio() {
        performChkDURConsolidated(ChkDURFlagType.MULTIPLE_PRESCRIBER_OHIO, null, false, false);
    }
    public void createNewOrderAndMoveToFilling(Map<String, String> inputData) {
        NewOrderDrop newOrderDrop = new NewOrderDrop();
        DataRow drugInfo;
        int storeA = Integer.parseInt(inputData.get("STOREA"));
        int patientID = Integer.parseInt(inputData.get("PATIENT_ID"));
        int numOfRefills = Integer.parseInt(inputData.get("REFILLS"));
        AutomationManager am = AutomationManager.getInstance();
        IDatabaseContext cnx = am.getConnexusDB(storeA);
        drugInfo = newOrderDrop.getDrugInfo(cnx, inputData.get("DRUG_NAME"));
        ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
        InputResponse multiRxResponse = connexusAPIManager.createNewOrderAndMoveToFilling(patientID, storeA, numOfRefills, drugInfo, inputData.get("DRUG_NAME"));
    }

    public void hostPullPatient(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientSearchPage.launchPatientSearchScreen();
        patientSearchPage.inputPatientName(inputData.get("LAST_NAME") + "," + inputData.get("FIRST_NAME"));
        patientSearchPage.inputPatientDob(inputData.get("DOB"));
        patientSearchPage.clickSearchNow();
        patientSearchPage.hostSearchPatient();
        patientSearchPage.doubleClickOnSearchGridRowforPatient(1);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        patientSearchPage.clickSaveAndClose();
    }

    public void performChkDUREarlyRefillOhioRedFlag() {
        performChkDURConsolidated(ChkDURFlagType.EARLY_REFILL_OHIO, null, false, false);
    }
    public void performInputForRX(Map<String, String> inputData) {
        performInputForRX(inputData, "Regular");
    }
    public void fetchRXFromDB(){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxNbr = getRxNbr(name[0] , name[1], siteId);
            if (rxNbr == null || rxNbr.isEmpty()) {
                Reporter.log("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
                Assert.fail("Input Failed or Failed to get the RX number for patient: " + name[0] + ", " + name[1]);
            }
            Reporter.log("In "+ currentStepMethodName + " Method, Rx number is " + rxNbr);

            connexusAppUtils.writeTextToFile("Input Completed","In progress",fileName,30, DateTime.now());
        }
        catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Input not Completed","Failed",fileName,30, DateTime.now());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }
    public void performInputForRX(Map<String, String> inputData, String inputType) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxModel.setNdc(inputData.get("DRUG_NAME_RX"));
            rxModel.setPrescribedQty(inputData.get("QUANTITY"));
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME_RX"));
            String rxCommentValue= inputData.get("RX_COMMENT");
            if (rxCommentValue != null && !rxCommentValue.isEmpty()) {
                rxModel.setRxComment(rxCommentValue);
            }
            if (isOrderInInputQueueDB(name[0],name[1],1)) {
                automationManager.getConnexusWorkFlow().performInput(rxModel, inputType);
            } else {
                Reporter.log("RX is not in Input queue");
                Assert.fail("RX is not in Input queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Input not Completed","Failed",fileName,30, DateTime.now());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


}

