package connexus.dcs.testscripts;

/**
 * Enum to define different ChkDUR flag validation types
 * Used for consolidating performChkDUR methods
 */
public enum ChkDURFlagType {
    GENERIC("Generic DCS alerts handling"),
    EARLY_REFILL_NATIONWIDE("Early refill validation for Nationwide"),
    MULTIPLE_DCS_FLAG("Multiple DCS flag validation"),
    DISTANCE_FLAG("Distance flag validation"),
    MULTIPLE_REFUSAL_NATIONWIDE("Multiple refusal flag validation for Nationwide"),
    MULTIPLE_REFUSAL_OHIO("Multiple refusal flag validation for Ohio"),
    MULTIPLE_PRESCRIBER_NATIONWIDE("Multiple prescriber validation for Nationwide"),
    PROFESSIONAL_JUDGEMENT("Professional judgement flag validation"),
    COMBINATION_RED_FLAG("Combination red flag validation"),
    MULTIPLE_PRESCRIBER_OHIO("Multiple prescriber validation for Ohio"),
    EARLY_REFILL_OHIO("Early refill Ohio red flag validation"),
    AFTER_TP_TO_CASH_SWITCH("DCS alerts after TP to Cash switch with comparison logic");

    private final String description;

    ChkDURFlagType(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}