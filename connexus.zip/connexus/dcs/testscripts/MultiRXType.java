package connexus.dcs.testscripts;

/**
 * Enum to define different Multi-RX scenarios
 * Used for consolidating Multi-RX drop-off and input methods
 */
public enum MultiRXType {
    TWO_RX(2, "Two RX prescriptions"),
    THREE_RX(3, "Three RX prescriptions"),
    FOUR_RX(4, "Four RX prescriptions");

    private final int rxCount;
    private final String description;

    MultiRXType(int rxCount, String description) {
        this.rxCount = rxCount;
        this.description = description;
    }

    public int getRxCount() {
        return rxCount;
    }

    public String getDescription() {
        return description;
    }
}