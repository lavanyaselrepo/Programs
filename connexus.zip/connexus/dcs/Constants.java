package connexus.dcs;

import java.util.Collections;
import java.util.List;

public class Constants {
    public static final List<String> distanceflag1 = Collections.singletonList("Distance Red Flag: The distance between the Patient/Prescriber/Pharmacy may exceed the established threshold. Patient to Pharmacy > 50 miles. Prescriber to Pharmacy > 50 miles.");
    public static final List<String> distanceflag2 = Collections.singletonList("Distance Red Flag: The distance between the Patient/Prescriber/Pharmacy may exceed the established threshold. Patient to Prescriber > 100 miles. Patient to Pharmacy > 50 miles. Prescriber to Pharmacy > 50 miles.");
    public static final List<String> distanceflag3= Collections.singletonList("Distance Red Flag: The distance between the Patient/Prescriber/Pharmacy may exceed the established threshold. Patient to Prescriber > 100 miles. Prescriber to Pharmacy > 50 miles.");
    public static final String multipleRefusalflagNationwide = "Multiple Refusals Red Flag: Patient has been identified as having multiple refusals submitted in the last 30 days";
    public static final String multipleRefusalflagOhio = "Previous RTF Red Flag: This prescription may have been previously refused to fill by a Walmart or Sam's club pharmacist.";
    public static final String multipleDCSflag = "Multiple 30-Day Rx Red Flag: Patient has been identified as receiving 3 or more controlled substance prescriptions, from 2 or more prescribers, with overlapping days' supply at Walmart/Sam's Club pharmacies in the last 30 days.";
    public static final String earlyRefillNationwideflag ="Early CII Rx Requests Red Flag: Patient has been identified as having 3 or more other controlled substance prescriptions with a remaining quantity exceeding a 3 day supply.";
    public static final String multiplePrescriberNationwideflag = "Multiple Prescribers Red Flag: Patient has been identified as receiving Designated Controlled Substance prescriptions at this pharmacy from more than four other prescribers in the last 180 days.";
    public static final String professionalJudgementflag = "Professional Judgment - system error: ConnexUs is currently unable to complete a Red Flag assessment due to system outage. Please use Professional Judgement to identify and resolve any Red Flags and document below.";
    public static final String CombinationRedflag = "Combination Red Flag: Patient has been identified as receiving a combination of medications requiring documented resolution.";
    public static final String MultiplePrescriberOhioflag = "Multiple Prescribers Red Flag: Patient has been identified as receiving controlled substance prescriptions at Walmart/Sam's Club pharmacies from four other prescribers in the last 180 days.";
    public static final String earlyRefillOhioflag= "Early Refill Red Flag: A patient may be attempting to fill an opioid prescription more than 3 days early";
}