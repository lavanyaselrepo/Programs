package connexus.dcs.testcases;

import connexus.dcs.testscripts.DCSTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.*;

public class DCS_Testcases {
    DCSTestScripts dcsTestScripts = new DCSTestScripts(LoginAs.userType.HOMEOFFICE_ADFlagOff);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    boolean flagUpdated = false;

    public void DCSFlagsSetUP() {
        flagUpdated = connexusAppUtils.readAndUpdateStoreState("AR");
        // AD flag 28750 has been deprecated in new SSO login. Related flag update and validation is no longer required
//        flagUpdated |= connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("31555", "TRUE");
        Reporter.log("DCS Red Flag Conflict Functionality Enabled");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("20013", "TRUE");
        Reporter.log("Central DUR flag Enabled");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("5361", "FALSE");
        Reporter.log("Specialty Pharmacy flag Disabled");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("5323", "Wal-Mart Pharmacy");
    }

    @BeforeClass
    public void loginToConnexus() {
        connexusAppUtils = new ConnexusAppUtils();
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    @Test(enabled = true, description = "Validate DCS alerts are displayed on Check DUR for a new patient after switching from TP to Cash",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/DCS/DCSDataBook.json", sheetName = "DCS")
    public void HWPHME2E_2805_DCS_Switch_to_CASH_From_TP_New_Patient(Map<String, String> inputData) {
        connexusAppUtils.getlogSiteIdAndState(inputData);
        DCSFlagsSetUP();
        dcsTestScripts.initializeTestCase(flagUpdated);
        dcsTestScripts.createNewPatient(inputData, 1);
        dcsTestScripts.performDropOff(Priority.Critical);
        dcsTestScripts.performInput(inputData);
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performChkDURDCSAlertsBeforeSwitchingTPtoCASH();
        Reporter.log("ChkDUR completed. DCS Alert and DUR alert resolved");
        dcsTestScripts.switchToCASHFromTPDCSAlerts(inputData);
        Reporter.log("Switched from TP to Cash");
        Reporter.log("Quantity updated for prescribed, dispensed and days supply fields");
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performChkDURDCSAlertsAfterSwitchingTPtoCASH();
        Reporter.log("ChkDUR completed. DCS Alert is resolved");
        dcsTestScripts.performFilling();
        dcsTestScripts.performVisualVerify();
        dcsTestScripts.performPickUp(inputData);
        dcsTestScripts.performCounselling();
        dcsTestScripts.performPOS();
    }

    @Test(enabled = true, description = "Validate DCS alerts are displayed on Check DUR for an existing patient after switching from TP to Cash",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/DCS/DCSDataBook.json", sheetName = "DCS")
    public void HWPHME2E_2806_DCS_Switch_to_CASH_From_TP_Existing_Patient(Map<String, String> inputData) {
        connexusAppUtils.getlogSiteIdAndState(inputData);
        DCSFlagsSetUP();
        dcsTestScripts.initializeTestCase(flagUpdated);
        dcsTestScripts.performDropOffForExistingPatient(inputData);
        dcsTestScripts.performInput(inputData);
        dcsTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performEarlyRefillsAuthorization(inputData);
        dcsTestScripts.validateCHkDURBeforeSwitchingFromTPToCASH(inputData);
        Reporter.log("ChkDUR completed. DCS Alert and DUR alert resolved");
        dcsTestScripts.completeResolution();
        dcsTestScripts.switchToCASHFromTPDCSAlerts(inputData);
        Reporter.log("Switched from TP to Cash");
        Reporter.log("Quantity updated for prescribed, dispensed and days supply fields");
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performEarlyRefillsAuthorization(inputData);
        dcsTestScripts.performChkDURDCSAlertsAfterSwitchingTPtoCASH();
        Reporter.log("ChkDUR completed. DCS Alert is resolved");
        dcsTestScripts.performFilling();
        dcsTestScripts.performVisualVerify();
    }

    @Test(enabled = true, description = "Verify red flag triggers for triangular distance.",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/DCS/DCSDataBook.json", sheetName = "DCS")
    public void HWPHME2E_273_triangular_distance(Map<String, String> inputData) {
        connexusAppUtils.getlogSiteIdAndState(inputData);
        DCSFlagsSetUP();
        dcsTestScripts.initializeTestCase(flagUpdated);
        dcsTestScripts.createNewPatient(inputData);
        dcsTestScripts.performDropOff(Priority.Critical);
        dcsTestScripts.performInput(inputData);
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performChkDURDistanceFlag();
        Reporter.log("ChkDUR completed. DCS Alert and DUR alert resolved");
        dcsTestScripts.performFilling();
        dcsTestScripts.performVisualVerify();
        dcsTestScripts.performPickUp(inputData);
        dcsTestScripts.performCounselling();
        dcsTestScripts.performPOS();
    }

    @Test(enabled = true, description = "verify red flag triggers for multiple refusals for Nationwide",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/DCS/DCSDataBook.json", sheetName = "DCS")
    public void HWPHME2E_3051_Multiple_Refusals_Nationwide(Map<String, String> inputData) {
        connexusAppUtils.getlogSiteIdAndState(inputData);
        DCSFlagsSetUP();
        dcsTestScripts.initializeTestCase(flagUpdated);
        dcsTestScripts.createNewPatient(inputData);
        dcsTestScripts.sendCurlRequestsMultipleRefusals();
        dcsTestScripts.performDropOff(Priority.Critical);
        dcsTestScripts.performInput(inputData);
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performChkDURMultipleRefusalFlagNationWide(inputData);
        Reporter.log("ChkDUR completed. DCS Alert resolved");
        dcsTestScripts.performFilling();
        dcsTestScripts.performVisualVerify();
        dcsTestScripts.performPickUp(inputData);
        dcsTestScripts.performCounselling();
        dcsTestScripts.performPOS();
        dcsTestScripts.dbValidation(inputData);
    }

    //Test Case HWPHME2E-3053 obsoleted
    @Test(enabled = false, description = "verify red flag triggers for multiple refusals for Ohio.",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/DCS/DCSDataBook.json", sheetName = "DCS")
    public void HWPHME2E_3053_Multiple_Refusals_Ohio(Map<String, String> inputData) {
        connexusAppUtils.getlogSiteIdAndState(inputData);
        DCSFlagsSetUP();
        dcsTestScripts.initializeTestCase(flagUpdated);
        dcsTestScripts.createNewPatient(inputData);
        dcsTestScripts.sendCurlRequestsMultipleRefusalsOhio();
        dcsTestScripts.performDropOff(Priority.Critical);
        dcsTestScripts.performInput(inputData);
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performChkDURMultipleRefusalFlagOhio(inputData);
        Reporter.log("ChkDUR completed. DCS Alert resolved");
        dcsTestScripts.performFilling();
        dcsTestScripts.performVisualVerify();
        dcsTestScripts.performPickUp(inputData);
        dcsTestScripts.performCounselling();
        dcsTestScripts.performPOS();
        dcsTestScripts.dbValidation(inputData);
    }

    @Test(enabled = true, description = "Verify red flag triggers for Multiple DCS in last 30 days.",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/DCS/DCSDataBook.json", sheetName = "DCS")
    public void HWPHME2E_277_Multiple_DCS(Map<String, String> inputData) {
        connexusAppUtils.getlogSiteIdAndState(inputData);
        DCSFlagsSetUP();
        dcsTestScripts.initializeTestCase(flagUpdated);
        dcsTestScripts.createNewPatient(inputData);
        dcsTestScripts.drop3RXTill4Point(inputData);
        dcsTestScripts.performDropOff(Priority.Critical);
        dcsTestScripts.performInputForRX(inputData);
        dcsTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performEarlyRefillAuthorization(inputData);
        dcsTestScripts.performChkDURMultipleDCSFlag();
        Reporter.log("ChkDUR completed. DCS and DUR Alerts are resolved");
        dcsTestScripts.performFilling();
        dcsTestScripts.performVisualVerify();
        dcsTestScripts.performPickUp(inputData);
        dcsTestScripts.performCounselling();
        dcsTestScripts.performPOS();
    }

    @Test(enabled = true, description = "Verify red flag triggers for Early Refill Nationwide",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/DCS/DCSDataBook.json", sheetName = "DCS")
    public void HWPHME2E_276_Early_Refill_Nationwide(Map<String, String> inputData) {
        connexusAppUtils.getlogSiteIdAndState(inputData);
        DCSFlagsSetUP();
        dcsTestScripts.initializeTestCase(flagUpdated);
        dcsTestScripts.createNewPatient(inputData);
        dcsTestScripts.drop3RXTill4Point(inputData);
        dcsTestScripts.performDropOff(Priority.Critical);
        dcsTestScripts.performInputForRX(inputData);
        dcsTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performEarlyRefillAuthorization(inputData);
        dcsTestScripts.performChkDUREarlyRefillNationwide();
        Reporter.log("ChkDUR completed. DCS and DUR Alerts are resolved");
        dcsTestScripts.performFilling();
        dcsTestScripts.performVisualVerify();
    }

    @Test(enabled = true, description = "Verify Professional Judgement triggers for Acute condition DCS if DCS API is down",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/DCS/DCSDataBook.json", sheetName = "DCS")
    public void HWPHME2E_279_Professional_Judgement_triggers_Acute_condition(Map<String, String> inputData) {
        connexusAppUtils.getlogSiteIdAndState(inputData);
        DCSFlagsSetUP();
        dcsTestScripts.initializeTestCase(flagUpdated);
        dcsTestScripts.createNewPatient(inputData);
        dcsTestScripts.performDropOff(Priority.Critical);
        dcsTestScripts.performInput(inputData);
        dcsTestScripts.perform4PointForControlledDrugForProfessionalJudgementFlag();
        dcsTestScripts.performChkDURDCSAlerts();
        Reporter.log("ChkDUR completed. DCS Alert and DUR alert resolved");
        connexusAppUtils.readAndUpdateFlag("20013", "FALSE");
        Reporter.log("Disabled 20013 flag to trigger Professional Judgement Flag");
        dcsTestScripts.performDropOff(Priority.Critical);
        dcsTestScripts.performInput(inputData);
        dcsTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performEarlyRefillAuthorization(inputData);
        dcsTestScripts.performChkDURProfessionalJudgementFlag();
        Reporter.log("ChkDUR completed. DCS and DUR Alerts are resolved");
        dcsTestScripts.validateDBRecords();
        dcsTestScripts.performFilling();
        dcsTestScripts.performVisualVerify();
        dcsTestScripts.performPickUp(inputData);
        dcsTestScripts.performCounselling();
        dcsTestScripts.performPOS();
    }

    @Test(enabled = true, description = "Verify red flag triggers for multiple prescriber for NationWide",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/DCS/DCSDataBook.json", sheetName = "DCS")
    public void HWPHME2E_272_Multiple_Prescriber_NationWide(Map<String, String> inputData) {
        connexusAppUtils.getlogSiteIdAndState(inputData);
        DCSFlagsSetUP();
        dcsTestScripts.initializeTestCase(flagUpdated);
        dcsTestScripts.createNewPatient(inputData);
        dcsTestScripts.drop4RXTill4Point(inputData);
        dcsTestScripts.performDropOff(Priority.Critical);
        dcsTestScripts.performInputForRX(inputData);
        dcsTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performEarlyRefillAuthorization(inputData);
        dcsTestScripts.performChkDURMultiplePrescriberNationWide();
        Reporter.log("ChkDUR completed. DCS and DUR Alerts are resolved");
        dcsTestScripts.performFilling();
        dcsTestScripts.performVisualVerify();
    }

    //Test Case HWPHME2E-3054 obsoleted
    @Test(enabled = false, description = "Verify red flag triggers for multiple prescriber for Ohio",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/DCS/DCSDataBook.json", sheetName = "DCS")
    public void HWPHME2E_3054_Multiple_Prescriber_Ohio(Map<String, String> inputData) {
        connexusAppUtils.getlogSiteIdAndState(inputData);
        DCSFlagsSetUP();
        dcsTestScripts.initializeTestCase(flagUpdated);
        dcsTestScripts.createNewPatient(inputData);
        dcsTestScripts.drop4RXTill4Point(inputData);
        dcsTestScripts.performDropOff(Priority.Critical);
        dcsTestScripts.performInput(inputData);
        dcsTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performEarlyRefillAuthorization(inputData);
        dcsTestScripts.performChkDURMultiplePrescriberOhio();
        Reporter.log("ChkDUR completed. DCS and DUR Alerts are resolved");
        dcsTestScripts.performFilling();
        dcsTestScripts.performVisualVerify();
    }

    @Test(enabled = true, description = "Verify red flag triggers for combination trinity red flag",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/DCS/DCSDataBook.json", sheetName = "DCS")
    public void HWPHME2E_274_Combination_Trininty_Flag(Map<String, String> inputData) {
        connexusAppUtils.getlogSiteIdAndState(inputData);
        DCSFlagsSetUP();
        dcsTestScripts.initializeTestCase(flagUpdated);
        dcsTestScripts.createNewPatient(inputData);
        dcsTestScripts.drop2RXTill4Point(inputData);
        dcsTestScripts.performDropOff(Priority.Critical);
        dcsTestScripts.performInputForRX(inputData);
        dcsTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performEarlyRefillAuthorization(inputData);
        dcsTestScripts.performChkDURCombinationRedFlag();
        Reporter.log("ChkDUR completed. DCS and DUR Alerts are resolved");
        dcsTestScripts.performFilling();
        dcsTestScripts.performVisualVerify();
    }

    //Test Case HWPHME2E-3053 obsoleted
    @Test(enabled = false, description = "Verify red flag triggers for C2 early refill Ohio",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/DCS/DCSDataBook.json", sheetName = "DCS")
    public void HWPHME2E_3052_Early_Refill(Map<String, String> inputData) {
        DCSFlagsSetUP();
        dcsTestScripts.createNewOrderAndMoveToFilling(inputData);
        dcsTestScripts.initializeTestCase(flagUpdated);
        dcsTestScripts.hostPullPatient(inputData);
        dcsTestScripts.performDropOffForExistingPatient(inputData);
        dcsTestScripts.performInput(inputData);
        dcsTestScripts.validateEarlyRefillPopUpAndCompleteInput(inputData);
        dcsTestScripts.perform4Point(true);
        dcsTestScripts.performEarlyRefillAuthorization(inputData);
        dcsTestScripts.performChkDUREarlyRefillOhioRedFlag();
        Reporter.log("ChkDUR completed. DCS and DUR Alerts are resolved");
        dcsTestScripts.performFilling();
        dcsTestScripts.performVisualVerify();
    }

}