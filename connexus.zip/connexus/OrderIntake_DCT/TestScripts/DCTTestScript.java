package connexus.OrderIntake_DCT.TestScripts;

import com.aventstack.extentreports.Status;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.pageobjectmodels.connexus.DCTResolutionPage;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.forklift.org.apache.commons.io.FileUtils;
import org.testng.Assert;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.logging.LogRecord;
import java.util.logging.XMLFormatter;
import org.json.JSONObject;

public class DCTTestScript extends ConnexusTestScripts {

    public DCTTestScript(LoginAs.userType loginUserType) {
        super(loginUserType);
    }

    private static ServiceResponse response;
    int patientId, siteId;
    String popUpText, patientName, rxInfoText,dctRxInfoText, rxOrigin, dctMsgTxtOnPopUp, typeOfRX,dctRxbarCode,originRxbarCode;
    String firstName, lastName;
    String[] name;
    List<String> ndcList= new ArrayList<>();
    PropertyReader prop = PropertyReader.getInstance();

    /**
     * Method to create Patient using API
     *
     * @param inputData
     */
    public void createPatient(Map<String, String> inputData) throws JsonProcessingException {

        ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        lastName = name[0];
        firstName = name[1];
        try {
            Long homePhone = Long.parseLong(inputData.get("PRIMARY_NUMBER"));
            Long workPhone = Long.parseLong(inputData.get("WORK_PHONE"));
            Long cellPhone = Long.parseLong(inputData.get("CELL_PHONE"));
            response = connexusAPIManager.createPatient(firstName, lastName, inputData.get("dob"), connexusAppUtils.getStoreId(), homePhone, workPhone, cellPhone);
            JSONObject res = new JSONObject(response);
            String dataresponse = res.optString("dataResponse", null);
            if (dataresponse != null) {
                JSONObject innerres = new JSONObject(dataresponse);
                firstName = innerres.optString("firstName", null);
                lastName = innerres.optString("lastName", null);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void selectDCTOrderFromFaxInbox(Map<String, String> inputData,boolean isNewRxPresent) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        name = connexusAppUtils.readPatientNameFromFile();
        try {
            faxInboxPage.openFaxInboxPage();
            if (connexusStartPage.getTextFromAppTitleBar(0).contains("Incoming Fax")) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            }
            faxInboxPage.selectFaxRow(0);
            faxInboxPage.clickSendToInput();
            faxInboxPage.searchAndSelectPatient(name[0], name[1]);
            faxInboxPage.getPatientDetails();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, faxInboxPage.takeScreenShot(currentStepMethodName).getValue());
            faxInboxPage.clickCreateRXFromThisPage();
            dctMsgTxtOnPopUp = dropOffPage.getDCTMessageText();
            Reporter.log("Text displayed on Competitive the Transfer PopUp  :" + dctMsgTxtOnPopUp);
            boolean isDisplayed = dctMsgTxtOnPopUp.toLowerCase().contains(inputData.get("popUpText"));
            Assert.assertTrue(isDisplayed, "Choose Competitive Transfer RX popup is not opened");
            if(isNewRxPresent){
                dropOffPage.clickFirstRecordOnPopUp();
                faxInboxPage.clickCreateRXCheckbox();
                dropOffPage.clickAcceptOnPopUp();
                typeOfRX = faxInboxPage.getRxType(0);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, faxInboxPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertTrue(typeOfRX.equalsIgnoreCase(inputData.get("rxInfoText1")),"New Rx is not present at index 0");
                Reporter.log("Text displayed in Rx Info Grid contains Rx Type at Index 0: " + typeOfRX);
                Assert.assertTrue(faxInboxPage.getRxType(1).equalsIgnoreCase(inputData.get("rxInfoText")),"Reassign rx is not present at index 1");
                Reporter.log("Text displayed in Rx Info Grid contains Rx Type at Index 1: " + faxInboxPage.getRxType(1));
            }else{
                dropOffPage.clickFirstRecordOnPopUp();
                dropOffPage.clickAcceptOnPopUp();
                typeOfRX = faxInboxPage.getRxType(0);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, faxInboxPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.assertTrue(typeOfRX.equalsIgnoreCase(inputData.get("rxInfoText")),"Reassign rx is not present at index 0");
                Reporter.log("Text displayed in Rx Info Grid contains Rx Type at Index 0: " + typeOfRX);
                String rxInfoText = dropOffPage.getRxInformation(0);
                Reporter.log("Text displayed in Rx Info Grid contains Rx Information: " + rxInfoText);
            }
            dropOffPage.clickBtnAccept();
            faxInboxPage.clickNo();
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void sendDCTOrderFromUI(Map<String, String> inputData, String xmlPath) throws SQLException, ParserConfigurationException, IOException, SAXException {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        name = connexusAppUtils.readPatientNameFromFile();
        File xmlData;
        String inputPayload;
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        //connect to store DB
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        //get pet patient id
        patientId = Integer.parseInt(connexusAppUtils.getPatientId(name[0], name[1]));
        //get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientId);
        //get xml file to generate input payload
        xmlData = new File(xmlPath);
        //update the xml with required storeNbr, Date-time and a unique messageId
        inputPayload = updateXMLWithPatientInfo(xmlData, String.valueOf(siteId), patientId, patientInfo);
        Reporter.log("Input Payload: " + formatXML(inputPayload));
        //drop ERX order
        orderSearch.openAboutPage();
        orderSearch.sendErxMsg(inputPayload);
        orderSearch.clickDotcomRadioBtn();
        orderSearch.clickSendTestBtn();
        popUpText = orderSearch.getPopUpText();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Text displayed on pop up on clicking sendTestERX button: " + formatXML(popUpText));
        boolean isSuccess = popUpText.toLowerCase().contains("success");
        Assert.assertTrue(isSuccess, "DCT Order submission failed.Success keyword not present on popup");
        orderSearch.closeAboutPage();

    }

    public static String formatXML(String xml) {
        XMLFormatter formatter = new XMLFormatter();
        LogRecord record = new LogRecord(java.util.logging.Level.INFO, xml);
        return formatter.format(record);
    }

    public String updateXMLWithPatientInfo(File xmlData, String storeNbr, int patientID, DataRow patientInfo)
            throws ParserConfigurationException, SAXException, IOException {

        String fileContext = FileUtils.readFileToString(xmlData, StandardCharsets.UTF_8);
        fileContext = fileContext.replaceAll("storeNbr", storeNbr);
        String currentTime = getCurrentTime();
        String pickUpTime = getFutureDate(3);
        String id = "W00NEW12567890tr52322hgh2d" + RandomStringUtils.randomAlphanumeric(2);
        fileContext = fileContext.replaceAll("submitTime", currentTime);
        fileContext = fileContext.replaceAll("patientLastName", patientInfo.getValue("last_name").toString().trim());
        fileContext = fileContext.replaceAll("patientFirstName", patientInfo.getValue("first_name").toString().trim());
        fileContext = fileContext.replaceAll("patientDOB", patientInfo.getValue("birth_date").toString());
        fileContext = fileContext.replaceAll("patientID", String.valueOf(patientID));
        fileContext = fileContext.replaceAll("pickUpTime", pickUpTime);
        fileContext = fileContext.replaceAll("generatedID", id);
        return fileContext;
    }

    public String getFutureDate(int daysToAdd) {
        LocalDateTime future = LocalDateTime.now().plusDays(daysToAdd);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        return future.format(formatter);
    }

    public void validatePopUpInDropOff(Map<String, String> inputData, Priority priority,boolean isAddOriginalRx) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickDropOffQueue();
            name = connexusAppUtils.readPatientNameFromFile();
            patientName = name[0] + "," + name[1];
            dropOffPage.enterPatientName(patientName);
            dropOffPage.clickPatientSearch();
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            dropOffPage.clickScanNewRx();
            dctMsgTxtOnPopUp = dropOffPage.getDCTMessageText();
            Reporter.log("Text displayed on Competitive the Transfer PopUp  :" + dctMsgTxtOnPopUp);
            boolean isDisplayed = dctMsgTxtOnPopUp.toLowerCase().contains(inputData.get("popUpText"));
            Assert.assertTrue(isDisplayed, "Choose Competitive Transfer RX popup is not opened");
            dropOffPage.clickFirstRecordOnPopUp();
            dropOffPage.clickAcceptOnPopUp();
            dctRxbarCode = dropOffPage.generateRxBarCode();
            dropOffPage.enterBarCode(dctRxbarCode);
            dropOffPage.clickBtnAccept();
            dropOffPage.clickVerifyBarCode();
            Assert.assertTrue(dropOffPage.getRxInformation(0).toLowerCase().contains(inputData.get("rxInfoText")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dctRxInfoText = dropOffPage.getRxInformation(0);
            Reporter.log("Text displayed in Rx Info Grid contains Reassign Rx: " + dctRxInfoText);
            if(isAddOriginalRx){
                dropOffPage.clickScanNewRx();
                originRxbarCode = dropOffPage.generateRxBarCode();
                dropOffPage.enterBarCode(originRxbarCode);
                dropOffPage.clickBtnAccept();
                dropOffPage.clickVerifyBarCode();
                dropOffPage.selectRxOrigin();
                dropOffPage.clickBtnAccept();
                Reporter.log("Original new Rx is added");
                Assert.assertTrue(dropOffPage.getRxInformation(1).toLowerCase().contains(inputData.get("rxInfoText1")));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                rxInfoText = dropOffPage.getRxInformation(1);
                Reporter.log("Text displayed in Rx Info Grid contains Reassign Rx: " + rxInfoText);
            }
            dropOffPage.selectPriority(priority.getPriority());
            if (priority == Priority.Critical) {
                dropOffPage.getReadyByTime();
            }
            dropOffPage.clickBtnAccept();
            dropOffPage.handleStorePickupTimePopup();
            dropOffPage.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DropOff queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }
    public void validateRxOriginInInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        orderSearch.launchOrderSearchScreen();
        name = connexusAppUtils.readPatientNameFromFile();
        String patientName = name[0] + "," + name[1];
        orderSearch.performSearch(patientName);
        orderSearch.openFirstPatientRecord();
        rxOrigin = inputPage.getRxOriginText();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Rx Origin displayed in Input Screen :" + rxOrigin);
        boolean isDisplayed = rxOrigin.toLowerCase().contains(inputData.get("rxOrigin"));
        Assert.assertTrue(isDisplayed, "Rx origin is not digital comp xfer");
    }

    /**
     * Performs multi-order DCT resolution with mixed approve/deny decisions.
     *
     * @param inputData       Test input data map
     * @param orderDecisions  List of decisions for each order. Each entry should contain:
     *                        - "action": "approve" or "deny"
     *                        - "verbalAuth": "true" or "false" (only for approve, defaults to true)
     *                        - "denialCode": denial code index as string (only for deny, defaults to "0")
     */
    public void performMultiDCT(Map<String, String> inputData, List<Map<String, String>> orderDecisions, boolean hasScanNo) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DCTResolutionPage dctResolutionPage = new DCTResolutionPage();
        try {
            orderSearch.launchOrderSearchScreen();
            name = connexusAppUtils.readPatientNameFromFile();
            String patientName = name[0] + "," + name[1];
            orderSearch.performSearch(patientName);
            orderSearch.openFirstPatientRecord();

            int verbalAuthCount = 0;
            boolean hasDeniedOrders = false;
            String deniedPopUpText = inputData.get("DENIED_POP_TEXT");
            
            for (int i = 0; i < orderDecisions.size(); i++) {
                Map<String, String> decision = orderDecisions.get(i);
                String action = decision.getOrDefault("action", "approve").toLowerCase();

                if ("approve".equals(action)) {
                    boolean verbalAuth = Boolean.parseBoolean(decision.getOrDefault("verbalAuth", "true"));
                    dctResolutionPage.selectApproveReason(i, verbalAuth);
                    if (verbalAuth) {
                        verbalAuthCount++;
                    }
                    Reporter.log("Order at index " + i + " marked as Approved with verbalAuth=" + verbalAuth);
                } else if ("deny".equals(action)) {
                    int denialCode = Integer.parseInt(decision.getOrDefault("denialCode", "0"));
                    dctResolutionPage.selectDenialReason(i, denialCode);
                    hasDeniedOrders = true;
                    Reporter.log("Order at index " + i + " marked as Denied with denialCode=" + denialCode);
                }
            }

            dctResolutionPage.clickSubmit();

            if (hasDeniedOrders) {
                dctResolutionPage.validateDeniedPopUp(deniedPopUpText);
                Reporter.log("Denied pop up handled successfully");
            }

            if (verbalAuthCount > 0 && !hasScanNo) {
                dctResolutionPage.validateYesScanNow();
                dctResolutionPage.validateSelectDCTScan(verbalAuthCount);
            } else if (verbalAuthCount > 0 && hasScanNo) {
                dctResolutionPage.validateScanNo();
                Reporter.log("Scan No selected for verbal auth orders");
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(patientName);
                orderSearch.openFirstPatientRecord();
                dctResolutionPage.validateScanVerbalAuth();
                dctResolutionPage.validateSelectDCTScan(verbalAuthCount);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at DCT Resolution");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Overloaded method for backward compatibility - approves single order at index 0.
     */
    public void performMultiDCT(Map<String, String> inputData) {
        List<Map<String, String>> singleApprove = new ArrayList<>();
        Map<String, String> approveDecision = new java.util.HashMap<>();
        approveDecision.put("action", "approve");
        approveDecision.put("verbalAuth", "true");
        singleApprove.add(approveDecision);
        performMultiDCT(inputData, singleApprove, false);
    }

    public void performMultiRxInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        ndcList = Arrays.asList(inputData.get("DRUG_NAME"), inputData.get("DRUG_NAME1"));
        int totalRxCount = ndcList.size();
        try {
            for (int i = 0; i < totalRxCount; i++) {
                name = connexusAppUtils.readPatientNameFromFile();
                rxModel.setPatientLastName(name[0]);
                rxModel.setPatientFirstName(name[1]);
                System.out.println("iteration loop:" + i);
                rxModel.setNdc(ndcList.get(i));
                rxModel.setPrescribedQty(inputData.get("QUANTITY"));
                rxModel.setSigCode(inputData.get("SIG"));
                rxModel.setNoOfRefills(inputData.get("REFILLS"));
                rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
                String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], i);
                if (rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue())) {
                    automationManager.getConnexusWorkFlow().performMultiRxInput(inputData, rxModel, i);
                } else {
                    Reporter.log("RX is not in Input queue");
                    Assert.fail();
                }
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }
}
