package connexus.OrderIntake_DCT.TestCases;

import connexus.OrderIntake_DCT.TestScripts.DCTTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DCTTestSet {
    DCTTestScript dctTestScript = new DCTTestScript(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    PropertyReader propertyReader = PropertyReader.getInstance();
    boolean flagUpdated = false;
    int siteId = Integer.parseInt(propertyReader.getProperty("cnx.store"));

    @BeforeClass
    public void loginToConnexus() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
       *Test Description: Validate able to select one DCT order from Drop Off pop up
       * Test Case ID: HWPHME2E-5323
       * Author: Purnima,Arora (vn58gdi)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate able to select one DCT order from Drop Off pop up", priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeDCT/OrderIntakeDCT.json", sheetName = "OrderIntakeDCT")
    public void HWPHME2E_5323_Validate_able_to_select_one_DCT_Order_from_DropOff_PopUp(Map<String, String> inputData) throws Exception {
        String xmlPayload = "src//test//resources//TestData//Connexus//OrderIntakeDCT/DCT.xml";
        connexusAppUtils.getStoreId();
        dctTestScript.initializeTestCase(flagUpdated, true);
        dctTestScript.createPatient(inputData);
        dctTestScript.sendDCTOrderFromUI(inputData, xmlPayload);
        dctTestScript.validatePopUpInDropOff(inputData, Priority.Critical,false);
        dctTestScript.validateRxOriginInInput(inputData);
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Validate able to select DCT order from Fax Inbox pop up
     * Test Case ID: HWPHME2E-5324
     * Author: Jyotirmayee,Priyadarshini(vn58g1s)
     ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Validate able to select DCT order from Fax Inbox pop up", priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeDCT/OrderIntakeDCT.json", sheetName = "OrderIntakeDCT")
    public void HWPHME2E_5324_Validate_able_to_select_DCT_order_from_Fax_Inbox_pop_up(Map<String, String> inputData) throws Exception {
        String xmlPayload = "src//test//resources//TestData//Connexus//OrderIntakeDCT/DCT.xml";
        connexusAppUtils.getStoreId();
        dctTestScript.initializeTestCase(flagUpdated, true);
        dctTestScript.createPatient(inputData);
        dctTestScript.sendDCTOrderFromUI(inputData, xmlPayload);
        dctTestScript.selectDCTOrderFromFaxInbox(inputData,false);
        dctTestScript.validateRxOriginInInput(inputData);

    }
    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Validate able to create new RX along with DCT when selecting from pop up
     * Test Case ID: HWPHME2E-5319
     * Author: Jyotirmayee,Priyadarshini(vn58g1s)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate able to create new RX along with DCT when selecting from pop up",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeDCT/OrderIntakeDCT.json", sheetName = "OrderIntakeDCT")
    public void HWPHME2E_5319_Validate_able_to_create_new_RX_along_with_DCT_when_selecting_from_pop_up(Map<String, String> inputData) throws Exception {
        String xmlPayload = "src//test//resources//TestData//Connexus//OrderIntakeDCT/DCT.xml";
        connexusAppUtils.updateInventoryQuantity(inputData.get("DRUG_NAME"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("DRUG_NAME1"));
        connexusAppUtils.getStoreId();
        dctTestScript.initializeTestCase(flagUpdated, true);
        dctTestScript.createPatient(inputData);
        dctTestScript.sendDCTOrderFromUI(inputData, xmlPayload);
        dctTestScript.validatePopUpInDropOff(inputData, Priority.Critical, true);
        dctTestScript.performMultiRxInput(inputData);
        dctTestScript.moveMultiRxToEod(String.valueOf(siteId));
        dctTestScript.verifyMultiRxInEOD();
    }
    /*----------------------------------------------------------------------------------------------------------
       *Test Description: Validate able to select one_DCT Order and create new rx from fax inbox pop up
       * Test Case ID: HWPHME2E-5320
       * Author: Purnima,Arora (vn58gdi)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate able to select one_DCT Order and create new rx from fax inbox pop up", priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeDCT/OrderIntakeDCT.json", sheetName = "OrderIntakeDCT")
    public void HWPHME2E_5320_Validate_able_to_select_one_DCT_Order_and_create_new_rx_from_fax_inbox_pop_up(Map<String, String> inputData) throws Exception {
        String xmlPayload = "src//test//resources//TestData//Connexus//OrderIntakeDCT/DCT.xml";
        connexusAppUtils.updateInventoryQuantity(inputData.get("DRUG_NAME"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("DRUG_NAME1"));
        connexusAppUtils.getStoreId();
        dctTestScript.initializeTestCase(flagUpdated, true);
        dctTestScript.createPatient(inputData);
        dctTestScript.sendDCTOrderFromUI(inputData, xmlPayload);
        dctTestScript.selectDCTOrderFromFaxInbox(inputData,true);
        dctTestScript.performMultiRxInput(inputData);
        dctTestScript.moveMultiRxToEod(String.valueOf(siteId));
        dctTestScript.verifyMultiRxInEOD();
    }
    /*
    Test Description: Validate able to handle mutliple DCT orders
    Test Case ID: HWPHME2E-5321
    Author Reichle, Devin (D0R0OZZ)
     */
    @Test(enabled = true, description = "Validate able to handle mutliple DCT orders", priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeDCT/OrderIntakeDCT.json", sheetName = "OrderIntakeDCT")
    public void HWPHME2E_5321(Map<String, String> inputData)throws Exception {
        String xmlPayload = "src//test//resources//TestData//Connexus//OrderIntakeDCT/multiDCT.txt";
        connexusAppUtils.getStoreId();
        dctTestScript.initializeTestCase(flagUpdated, true);
        
        //Creating Map of order decisions
        List<Map<String, String>> orderDecisions = new ArrayList<>();

        Map<String, String> order0 = new HashMap<>();
        order0.put("action", "approve");
        order0.put("verbalAuth", "true");
        orderDecisions.add(order0);

        Map<String, String> order1 = new HashMap<>();
        order1.put("action", "approve");
        order1.put("verbalAuth", "false");
        orderDecisions.add(order1);

        Map<String, String> order2 = new HashMap<>();
        order2.put("action", "deny");
        order2.put("denialCode", "1");
        orderDecisions.add(order2);

        Map<String, String> order3 = new HashMap<>();
        order3.put("action", "deny");
        order3.put("denialCode", "2");
        orderDecisions.add(order3);

        Map<String, String> order4 = new HashMap<>();
        order4.put("action", "deny");
        order4.put("denialCode", "3");
        orderDecisions.add(order4);

        dctTestScript.createPatient(inputData);
        dctTestScript.sendDCTOrderFromUI(inputData, xmlPayload);

       
        dctTestScript.performMultiDCT(inputData, orderDecisions, false);
        dctTestScript.validateRxOriginInInput(inputData);
    }
    
    /*
    Test Description: Validate able to select Scan later for Verbal Auth for multi DCT
    Test Case ID: HWPHME2E-5322
    Author Reichle, Devin (D0R0OZZ)
     */
    @Test(enabled = true, description = "Validate able to select Scan later for Verbal Auth for multi DCT", priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/OrderIntakeDCT/OrderIntakeDCT.json", sheetName = "OrderIntakeDCT")
    public void HWPHME2E_5322(Map<String, String> inputData)throws Exception {
        String xmlPayload = "src//test//resources//TestData//Connexus//OrderIntakeDCT/multiDCT.txt";
        connexusAppUtils.getStoreId();
        dctTestScript.initializeTestCase(flagUpdated, true);
        
        //Creating Map of order decisions
        List<Map<String, String>> orderDecisions = new ArrayList<>();

        Map<String, String> order0 = new HashMap<>();
        order0.put("action", "approve");
        order0.put("verbalAuth", "true");
        orderDecisions.add(order0);

        Map<String, String> order1 = new HashMap<>();
        order1.put("action", "approve");
        order1.put("verbalAuth", "true");
        orderDecisions.add(order1);

        Map<String, String> order2 = new HashMap<>();
        order2.put("action", "deny");
        order2.put("denialCode", "1");
        orderDecisions.add(order2);

        Map<String, String> order3 = new HashMap<>();
        order3.put("action", "deny");
        order3.put("denialCode", "2");
        orderDecisions.add(order3);

        Map<String, String> order4 = new HashMap<>();
        order4.put("action", "deny");
        order4.put("denialCode", "3");
        orderDecisions.add(order4);

        dctTestScript.createPatient(inputData);
        dctTestScript.sendDCTOrderFromUI(inputData, xmlPayload);
        dctTestScript.performMultiDCT(inputData, orderDecisions, true);
        dctTestScript.validateRxOriginInInput(inputData);
    }

}


