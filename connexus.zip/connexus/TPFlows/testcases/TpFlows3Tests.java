package connexus.TPFlows.testcases;

import bom.tests.WrapperTestScript;
import connexus.TPFlows.TpTestscripts.TpPlanInput;
import connexus.TPFlows.testscripts.TPFlowTestscripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import static connexus.ConnexusTestScripts.requireNonNullId;
import static connexus.ConnexusTestScripts.safeTearDown;

/**
 * TP Flow – Pharmacist/Technician: M3P billing, split bill, DUR. Login: PHARMACIST_ADFlagOff.
 * Flag 28750 is deprecated and no longer settable; all tests run with its effective value of TRUE.
 * HWPHME2E_282 re-logs as TECHNICIAN. Flag 31529 is TRUE by default; no explicit set/reset needed.
 * @author snehaa (vn57hhm), Avantika Srivastava (vn598z6), Diya (vn58o0i)
 */
public class TpFlows3Tests {

    private final TPFlowTestscripts tpFlowTestscripts = new TPFlowTestscripts();

    @BeforeClass
    public void beforeClass() {
        tpFlowTestscripts.connexusAppUtils.startAppiumServer();
        tpFlowTestscripts.loginUserType = LoginAs.userType.PHARMACIST_ADFlagOff;
        tpFlowTestscripts.initializeTestCase(false);
    }

    @BeforeMethod(alwaysRun = true)
    public void setPharmacistADFlag() {
        System.setProperty("testcaseId", getClass().getSimpleName());
        tpFlowTestscripts.waitForConnexusReady();
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            tpFlowTestscripts.escapeToHome();
        }
    }

    /**
     * HWPHME2E-282: Verify Technician cannot solve DUR_88 issue for Refill Rx (TP Plan: QA/REJ5)
     * @author snehaa (vn57hhm)
     */
    @Test(enabled = true,
            description = "To_verify_that_Technician_is_not_able_to_solve_the_issue_DUR_88_which_is_generated_for_a_Refill_Rx",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_282(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_282 - TC001_Technician_is_not_able_to_solve_the_issue_DUR_88");
        int rxNbrInt = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_282");
        String rxNbr = String.valueOf(rxNbrInt);
        tpFlowTestscripts.switchcash(rxNbr);
        tpFlowTestscripts.perform4Point(rxNbr);
        tpFlowTestscripts.Modifyplan(rxNbr);
        tpFlowTestscripts.performDropOffForRXWithRefills(rxNbr);
        // Defensive close before re-login as Technician — driver may already be dead.
        try {
            AutomationManager am = AutomationManager.getInstance();
            if (am != null && am.getConnexus() != null) {
                am.getConnexus().closeConnexus();
            }
        } catch (Exception e) {
            Reporter.log("HWPHME2E_282: closeConnexus before re-login threw " + e + " — continuing.");
        }
        tpFlowTestscripts.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        tpFlowTestscripts.TechNotAbleTosolve(rxNbr);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-3260: Verify Rx goes to Billing Error when M3P added in Modify Details (not payor of last resort)
     * @author Avantika Srivastava (vn598z6)
     */
    @Test(enabled = true,
            description = "Verify Rx goes to Billing Error Resolution when M3P is added in Modify Details Page",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_3260(Map<String, String> inputData) {
        Map<String, Object> objectInputdata = new HashMap<>(inputData);
        int patientId = WrapperTestScript.createPatient(objectInputdata, "HWPHME2E_3260 - Verify TP Error");
        tpFlowTestscripts.addPlansAndExit(patientId,
                TpPlanInput.fromInputData(inputData, 2));
        tpFlowTestscripts.dropRxtoFilling(inputData, tpFlowTestscripts.storeId, patientId);
        tpFlowTestscripts.changeTPPlanInModifyScreen(inputData, patientId);
        tpFlowTestscripts.verifyRxInResolutionQueueWithSplitbillM3P(inputData, patientId);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-3261: Verify Rx billing with M3P and TP plans MPD057/MPD574RX as secondary payer.
     * Flag 31529 is TRUE by default; no flag manipulation required.
     * @author Avantika Srivastava (vn598z6)
     */
    @Test(enabled = true,
            description = "Verify Rx goes through billing if M3P associated with TP plans MPD057 or MPD574RX as secondary payer via resolution screen",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_3261(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_3261 - Verify Rx goes through billing if M3P associated with TP plans MPD057 or MPD574RX as secondary payer via resolution screen");
        int rxNbrInt = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_3261");
        Integer patientId = stagedClaimData.getPatientId();
        Assert.assertNotNull(patientId, "patientId was null in StagedClaimData for HWPHME2E_3261");
        Map<String, String> stringInputData = inputData.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, e -> e.getValue() == null ? null : e.getValue().toString()));
        tpFlowTestscripts.verifyRxInResolutionQueueWithSplitbillM3P(stringInputData, String.valueOf(rxNbrInt));
        tpFlowTestscripts.addSecondaryTPPlan(stringInputData);
        tpFlowTestscripts.addInsuranceInModifyDetailsScreen(stringInputData);
        tpFlowTestscripts.checkRxIsIn4PointQueueFirstPatient(patientId);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-3265: Verify Billing Error when M3P added in Modify Details with existing Medicaid
     * @author Avantika Srivastava (vn598z6)
     */
    @Test(enabled = true,
            description = "Verify Rx goes to Billing Error Resolution when M3P is added in Modify Details Page (Medicaid exists)",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_3265(Map<String, String> inputData) {
        Map<String, Object> objectInputdata = new HashMap<>(inputData);
        int patientId = WrapperTestScript.createPatient(objectInputdata, "HWPHME2E_3265 - Verify TP Error");
        // Plan 2 uses TP_NAME_2 (full UI display name) instead of TP_PLAN_2 — see TpPlanInput.withName javadoc.
        tpFlowTestscripts.addPlansAndExit(patientId,
                TpPlanInput.withName(inputData, 2),
                TpPlanInput.fromInputData(inputData, 3),
                TpPlanInput.fromInputData(inputData, 4));
        tpFlowTestscripts.dropRxtoFilling(inputData, tpFlowTestscripts.storeId, patientId);
        tpFlowTestscripts.changePayerPlanInModifyScreen(inputData, patientId);
        tpFlowTestscripts.verifyRxInResolutionQueueWithSplitbillM3P(inputData, patientId);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-3259: Verify Rx billing with split bill enabled between MPP and MPD057.
     * Flag 31529 is TRUE by default; no flag manipulation required.
     * @author Diya (vn58o0i)
     */
    @Test(enabled = true,
            description = "Verify Rx goes through billing if M3P associated with TP plans MPD057 or MPD574RX in split bill",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_3259(Map<String, Object> inputData) {
        Integer patientId = WrapperTestScript.createPatient(inputData, "Create TP Patient");
        tpFlowTestscripts.splitBillWithPlans(patientId, inputData);
        WrapperTestScript.completePrescriptionDropOff(patientId, inputData, "Complete DropOff for TP Patient");
        Map<String, String> stringInputData = inputData.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey, e -> e.getValue() == null ? null : e.getValue().toString()));
        tpFlowTestscripts.performInput(stringInputData, patientId);
        tpFlowTestscripts.checkRxIsIn4PointQueueFirstPatient(patientId);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-126: Drop Rx for TP patient with split bill, complete multi-Rx input, move to EOD
     */
    @Test(enabled = true,
            description = "Verify Drop a singleRx for a TP patient with SPLIT Bill and complete Drop-off. Click Add Rx in Input and complete Input for both the Rx's and move Rx till EOD",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_126(Map<String, Object> inputData) {
        Integer patientId = WrapperTestScript.createPatient(inputData, "Create TP Patient");
        tpFlowTestscripts.splitBillWithPlans(patientId, inputData);
        tpFlowTestscripts.dropOffRx(patientId);
        tpFlowTestscripts.enterInputDetails(inputData, patientId);
        tpFlowTestscripts.moveMultiRxToEod(patientId);
        tpFlowTestscripts.softAssert.assertAll();
    }

    @AfterClass
    public void closeConnexus() {
        safeTearDown(tpFlowTestscripts.connexusAppUtils);
    }
}
