package connexus.TPFlows.testcases;

import bom.tests.WrapperTestScript;
import connexus.TPFlows.testscripts.TPFlowTestscripts;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static connexus.ConnexusTestScripts.requireNonNullId;
import static connexus.ConnexusTestScripts.safeTearDown;

/**
 * TP Flow – insulin popup, Medicare Part B card. Login: HOMEOFFICE_ADFlagOn.
 * Flags: 27267, 9335 = TRUE (set once in @BeforeClass). 28750, 24900 = TRUE by default, not set explicitly.
 * @author Bhavani Kokate (vn5a9ql), Baha Sadyrov (vn59rtp)
 */
public class TpFlows4Tests {

    private final TPFlowTestscripts tpFlowTestscripts = new TPFlowTestscripts();

    @BeforeClass
    public void beforeClass() {
        tpFlowTestscripts.connexusAppUtils.startAppiumServer();
        boolean flagUpdated  = tpFlowTestscripts.connexusAppUtils.readAndUpdateFlag("27267", "TRUE");
        flagUpdated         |= tpFlowTestscripts.connexusAppUtils.readAndUpdateFlag("9335",  "TRUE");
        tpFlowTestscripts.loginUserType = LoginAs.userType.HOMEOFFICE_ADFlagOn;
        tpFlowTestscripts.initializeTestCase(flagUpdated);
    }

    @BeforeMethod(alwaysRun = true)
    public void beforeMethod() {
        System.setProperty("testcaseId", getClass().getSimpleName());
        tpFlowTestscripts.waitForConnexusReady();
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            tpFlowTestscripts.escapeToHome();
        }
    }

    /**
     * Resolves a non-null drug identifier from input data.
     * Tests use either {@code DRUG_NAME} or {@code ndc} \u2014 both must be checked
     * to avoid passing {@code null} to {@link hwqe.baseframework.connexuscontext.ConnexusAppUtils#updateInventoryQuantity(String)}
     * (which would NPE on the SQL builder).
     */
    private static String requireDrugId(Map<String, String> inputData, String testName, String... candidateKeys) {
        for (String key : candidateKeys) {
            String value = inputData.get(key);
            if (value != null && !value.isBlank()) {
                return value;
            }
        }
        Assert.fail("None of the drug-id keys " + java.util.Arrays.toString(candidateKeys)
                + " were present (or were blank) in test data for " + testName);
        return null; // unreachable — Assert.fail throws
    }

    /**
     * HWPHME2E-5713: Insulin Rx lands in Contact Customer when Move to Resolution clicked
     *               (CASH patient, age >=65, BUPARM 27267/9335=TRUE)
     * @author Bhavani Kokate (vn5a9ql)
     */
    @Test(enabled = true,
            description = "Verify Rx lands in Contact Customer resolution when user clicks Move to Resolution on the Insulin Administration popup from INPUT screen (CASH-only patient; popup shows Patient does not have Med B or Med D)",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5713(Map<String, String> inputData) {
        String drugId = requireDrugId(inputData, "HWPHME2E_5713", "DRUG_NAME");
        tpFlowTestscripts.connexusAppUtils.updateInventoryQuantity(drugId);
        Map<String, Object> objectInputdata = new HashMap<>(inputData);
        int patientId = WrapperTestScript.createPatient(objectInputdata,
                "HWPHME2E_5713 - Verify Rx lands in Contact Customer resolution when user clicks Move to Resolution on the Insulin Administration popup");
        tpFlowTestscripts.informixWrapper.updateInsulinPumpIndicatorFlagForPatient(patientId, tpFlowTestscripts.storeId);
        tpFlowTestscripts.performDropOff(patientId);
        tpFlowTestscripts.verifyInsulinRxResolutionWhenUserSelectsMoveToResolutionOnAdministrationPopup(inputData, patientId);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5711: Insulin Rx lands in 4P when "Patient does not have Med B or Med D" clicked
     *               (CASH patient, age >=65, BUPARM 27267/9335=TRUE)
     * @author Bhavani Kokate (vn5a9ql)
     */
    @Test(enabled = true,
            description = "Verify Rx lands in 4P when user clicks Patient does not have Med B or Med D on the Insulin Administration popup from INPUT screen (CASH-only patient)",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5711(Map<String, String> inputData) {
        String drugId = requireDrugId(inputData, "HWPHME2E_5711", "DRUG_NAME");
        tpFlowTestscripts.connexusAppUtils.updateInventoryQuantity(drugId);
        Map<String, Object> objectInputdata = new HashMap<>(inputData);
        int patientId = WrapperTestScript.createPatient(objectInputdata,
                "HWPHME2E_5711 - Verify Rx lands in 4P when user clicks Patient does not have Med B or Med D on the Insulin Administration popup");
        tpFlowTestscripts.informixWrapper.updateInsulinPumpIndicatorFlagForPatient(patientId, tpFlowTestscripts.storeId);
        tpFlowTestscripts.dropRxtoFilling(inputData, tpFlowTestscripts.storeId, patientId);
        tpFlowTestscripts.verifyInsulinRxLandsIn4PointWhenUserSelectsPatientDoesNtHaveMedBorMedDOnAdministrationPopup(inputData, patientId);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5715: No Insulin Admin popup for patient with QA MEDPART B (age >=65, BUPARM 27267/9335=TRUE)
     * @author Bhavani Kokate (vn5a9ql)
     */
    @Test(enabled = true, description = "Verify No Insulin Administration pop-up upon input accept if patient profile has just QA MEDPART B",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5715(Map<String, String> inputData) {
        String drugId = requireDrugId(inputData, "HWPHME2E_5715", "DRUG_NAME");
        tpFlowTestscripts.connexusAppUtils.updateInventoryQuantity(drugId);
        Map<String, Object> objectInputdata = new HashMap<>(inputData);
        int patientId = WrapperTestScript.createPatient(objectInputdata,
                "HWPHME2E_5715 - Verify No Insulin Administration pop-up upon input accept if patient profile has just QA MEDPART B");
        tpFlowTestscripts.informixWrapper.updateInsulinPumpIndicatorFlagForPatient(patientId, tpFlowTestscripts.storeId);
        WrapperTestScript.completePrescriptionDropOff(patientId, objectInputdata, "Verify Complete Prescription Drop Off");
        tpFlowTestscripts.enterInsulinRxDataAndValidateAdministrationPopup(inputData, patientId, false, false, false);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5716: Insulin Admin popup shows "Patient does not have Med B" for MEDPART D only patient
     *               (age >=65, BUPARM 27267/9335=TRUE)
     * @author Bhavani Kokate (vn5a9ql)
     */
    @Test(enabled = true, description = "Verify Insulin Administration pop-up with Patient does not have Med B upon input accept if patient profile has just QA MEDPART D",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5716(Map<String, String> inputData) {
        String drugId = requireDrugId(inputData, "HWPHME2E_5716", "DRUG_NAME");
        tpFlowTestscripts.connexusAppUtils.updateInventoryQuantity(drugId);
        Map<String, Object> objectInputdata = new HashMap<>(inputData);
        int patientId = WrapperTestScript.createPatient(objectInputdata,
                "HWPHME2E_5716 - Verify Insulin Administration pop-up with Patient does not have Med B upon input accept if patient profile has just QA MEDPART D");
        tpFlowTestscripts.informixWrapper.updateInsulinPumpIndicatorFlagForPatient(patientId, tpFlowTestscripts.storeId);
        WrapperTestScript.completePrescriptionDropOff(patientId, objectInputdata, "Verify Complete Prescription Drop Off");
        tpFlowTestscripts.enterInsulinRxDataAndValidateAdministrationPopup(inputData, patientId, true, false, true);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5717: Insulin Admin popup shows "Patient does not have Med B or Med D" for CASH-only patient
     *               (age >=65, BUPARM 27267/9335=TRUE)
     * @author Bhavani Kokate (vn5a9ql)
     */
    @Test(enabled = true, description = "Verify Insulin Administration pop-up with Patient does not have Med B or Med D upon input accept if patient profile has just CASH",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5717(Map<String, String> inputData) {
        String drugId = requireDrugId(inputData, "HWPHME2E_5717", "DRUG_NAME");
        tpFlowTestscripts.connexusAppUtils.updateInventoryQuantity(drugId);
        Map<String, Object> objectInputdata = new HashMap<>(inputData);
        int patientId = WrapperTestScript.createPatient(objectInputdata,
                "HWPHME2E_5717 - Verify Insulin Administration pop-up with Patient does not have Med B or Med D upon input accept if patient profile has just CASH");
        tpFlowTestscripts.informixWrapper.updateInsulinPumpIndicatorFlagForPatient(patientId, tpFlowTestscripts.storeId);
        tpFlowTestscripts.dropRxtoFilling(inputData, tpFlowTestscripts.storeId, patientId);
        tpFlowTestscripts.enterInsulinRxDataAndValidateAdministrationPopup(inputData, patientId, true, true, false);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5685: No Insulin Admin popup for patient age &lt;65 (insulin pump checked, no DX code, no expanded sig)
     * @author Baha Sadyrov (vn59rtp)
     */
    @Test(enabled = true, description = "Verify No Insulin Administration popup upon input accept for patient age < 65 & insulin pump checked and insulin drug used with no DX code and no expanded sig",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/InsulinFlows.json", sheetName = "InsulinTests")
    public void HWPHME2E_5685(Map<String, String> inputData) {
        String drugId = requireDrugId(inputData, "HWPHME2E_5685", "DRUG_NAME");
        tpFlowTestscripts.connexusAppUtils.updateInventoryQuantity(drugId);
        int storeId = tpFlowTestscripts.connexusAppUtils.getStoreId();
        Map<String, Object> patientData = new HashMap<>(inputData);
        patientData.put("siteId", storeId);
        int patientId = WrapperTestScript.createPatient(patientData, "HWPHME2E_5685");
        tpFlowTestscripts.informixWrapper.updateInsulinPumpIndicatorFlagForPatient(patientId, storeId);
        WrapperTestScript.completePrescriptionDropOff(patientId, patientData, "HWPHME2E_5685");
        tpFlowTestscripts.enterInsulinRxDataAndValidateAdministrationPopup(inputData, patientId, false, false, false);
        tpFlowTestscripts.verifyNoInsulinAdministrationPopupOnInputPage();
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5686: No Insulin Admin popup for patient age &lt;65 (insulin pump checked, with expanded sig)
     * @author Baha Sadyrov (vn59rtp)
     */
    @Test(enabled = true, description = "Verify No Insulin Administration popup upon input accept for patient age < 65 & insulin pump checked and insulin drug used with expanded sig",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/InsulinFlows.json", sheetName = "InsulinTests")
    public void HWPHME2E_5686(Map<String, String> inputData) {
        String drugId = requireDrugId(inputData, "HWPHME2E_5686", "DRUG_NAME");
        tpFlowTestscripts.connexusAppUtils.updateInventoryQuantity(drugId);
        int storeId = tpFlowTestscripts.connexusAppUtils.getStoreId();
        Map<String, Object> patientData = new HashMap<>(inputData);
        patientData.put("siteId", storeId);
        int patientId = WrapperTestScript.createPatient(patientData, "HWPHME2E_5686");
        tpFlowTestscripts.informixWrapper.updateInsulinPumpIndicatorFlagForPatient(patientId, storeId);
        WrapperTestScript.completePrescriptionDropOff(patientId, patientData, "HWPHME2E_5686");
        tpFlowTestscripts.performInputWithFreeFormPopUpAndMaxDailyDoseValidation(inputData, patientId);
        tpFlowTestscripts.verifyNoInsulinAdministrationPopupOnInputPage();
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5707: Rx proceeds when "Proceed Without Part B Card" clicked
     *               (CASH patient, age &gt;65, BUPARM 27267/9335=TRUE)
     * @author Baha Sadyrov (vn59rtp)
     */
    @Test(enabled = true, description = "Verify Rx proceeds when clicking Proceed Without Part B Card in Contact Customer resolution",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/InsulinFlows.json", sheetName = "InsulinTests")
    public void HWPHME2E_5707(Map<String, String> inputData) {
        String drugId = requireDrugId(inputData, "HWPHME2E_5707", "DRUG_NAME");
        tpFlowTestscripts.connexusAppUtils.updateInventoryQuantity(drugId);
        int storeId = tpFlowTestscripts.connexusAppUtils.getStoreId();
        Map<String, Object> objectInputData = new HashMap<>(inputData);
        objectInputData.put("siteId", storeId);
        Integer patientId = WrapperTestScript.createPatient(objectInputData, "HWPHME2E_5707");
        tpFlowTestscripts.informixWrapper.updateInsulinPumpIndicatorFlagForPatient(patientId, storeId);
        WrapperTestScript.completePrescriptionDropOff(patientId, objectInputData, "HWPHME2E_5707");
        tpFlowTestscripts.verifyRxProceedsWhenProceedWithoutPartBCardClicked(inputData, patientId);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5708: Add Medicare Part B Card workflow from Resolution
     *               (CASH patient, age &gt;65, BUPARM 27267/9335=TRUE)
     * @author Baha Sadyrov (vn59rtp)
     */
    @Test(enabled = true, description = "Verify Rx proceeds when clicking Add Medicare Part B Card in Resolution workflow",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/InsulinFlows.json", sheetName = "InsulinTests")
    public void HWPHME2E_5708(Map<String, String> inputData) {
        String drugId = requireDrugId(inputData, "HWPHME2E_5708", "DRUG_NAME");
        tpFlowTestscripts.connexusAppUtils.updateInventoryQuantity(drugId);
        int storeId = tpFlowTestscripts.connexusAppUtils.getStoreId();
        Map<String, Object> objectInputData = new HashMap<>(inputData);
        objectInputData.put("siteId", storeId);
        Integer patientId = WrapperTestScript.createPatient(objectInputData, "HWPHME2E_5708");
        tpFlowTestscripts.informixWrapper.updateInsulinPumpIndicatorFlagForPatient(patientId, storeId);
        WrapperTestScript.completePrescriptionDropOff(patientId, objectInputData, "HWPHME2E_5708");
        tpFlowTestscripts.verifyRxMovesTo4PointAfterAddingMedBPlan(inputData, patientId);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5678: No Insulin Admin popup during refill drop-off
     *               (patient age &gt;65, insulin pump checked, BUPARM 27267/9335=TRUE)
     */
    @Test(enabled = true, description = "Verify No Insulin Administration popup in DROP OFF while raising refill for patient>65 y o & insulin pump checked and insulin drug used with expanded sig",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/InsulinFlows.json", sheetName = "InsulinTests")
    public void HWPHME2E_5678(Map<String, String> inputData) {
        String drugId = requireDrugId(inputData, "HWPHME2E_5678", "ndc", "DRUG_NAME");
        tpFlowTestscripts.connexusAppUtils.updateInventoryQuantity(drugId);
        int storeId = tpFlowTestscripts.connexusAppUtils.getStoreId();
        Map<String, Object> objectInputData = new HashMap<>(inputData);
        objectInputData.put("siteId", storeId);
        tpFlowTestscripts.verifyDrugHasInsulinRestriction(drugId, storeId);
        Integer patientId = WrapperTestScript.createPatient(objectInputData, "HWPHME2E_5678");
        tpFlowTestscripts.informixWrapper.updateInsulinPumpIndicatorFlagForPatient(patientId, storeId);
        WrapperTestScript.completePrescriptionDropOff(patientId, objectInputData, "HWPHME2E_5678");
        tpFlowTestscripts.enterInsulinRxDataAndMaxDailyDose(inputData, patientId);
        Integer rxNbr = tpFlowTestscripts.getLatestRxNbrForPatient(patientId);
        // getLatestRxNbrForPatient already throws on null, but assert to surface a clear test failure either way.
        int rxNbrInt = requireNonNullId(rxNbr, "rxNbr", "HWPHME2E_5678");
        String rxNbrStr = String.valueOf(rxNbrInt);
        tpFlowTestscripts.perform4PointWithLASAValidation(rxNbrStr, inputData);
        tpFlowTestscripts.performDropOffForRXWithRefills(rxNbrStr);
        tpFlowTestscripts.verifyNoInsulinAdministrationPopup();
        tpFlowTestscripts.softAssert.assertAll();
    }

    @AfterClass
    public void tearDown() {
        safeTearDown(tpFlowTestscripts.connexusAppUtils);
    }
}
