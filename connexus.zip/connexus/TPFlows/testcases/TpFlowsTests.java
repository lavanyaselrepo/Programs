package connexus.TPFlows.testcases;

import bom.tests.WrapperTestScript;
import connexus.TPFlows.testscripts.TPFlowTestscripts;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import static connexus.ConnexusTestScripts.requireNonNullId;
import static connexus.ConnexusTestScripts.safeTearDown;

/**
 * TP Flow – core reject/error/resolution flows. Login: HOMEOFFICE_ADFlagOn (session reused). Flags: 28750=TRUE (default, not set explicitly).
 * Recovery: relaunches only on flag change or exception. No restart required.
 * @author Sweety Saxena (vn56iwu), snehaa (vn57hhm)
 */
public class TpFlowsTests {

    private final TPFlowTestscripts tpFlowTestscripts = new TPFlowTestscripts();

    @BeforeClass
    public void beforeClass() {
        tpFlowTestscripts.connexusAppUtils.startAppiumServer();
        tpFlowTestscripts.loginUserType = LoginAs.userType.HOMEOFFICE_ADFlagOn;
        tpFlowTestscripts.initializeTestCase(false);
    }

    /**
     * Relaunches only if a flag change is detected externally. waitForConnexusReady() blocks up to 200s.
     */
    @BeforeMethod(alwaysRun = true)
    public void beforeMethod() {
        System.setProperty("testcaseId", getClass().getSimpleName());
        tpFlowTestscripts.waitForConnexusReady();
    }

    /**
     * On test failure, presses Escape 3x to close any orphaned screens before next test.
     */
    @AfterMethod(alwaysRun = true)
    public void afterMethod(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            tpFlowTestscripts.escapeToHome();
        }
    }

    /**
     * HWPHME2E-1821: Verify TP Reject with Contact Prescriber (TP Plan: QA MEDPARTB)
     * @author Sweety Saxena (vn56iwu)
     */
    @Test(enabled = true, description = "Verify TP Reject with Contact Prescriber", priority = 1,
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_1821(Map<String, Object> inputData) {
        Integer patientId = WrapperTestScript.createPatient(inputData, "Verify TP Reject with Contact Prescriber");
        WrapperTestScript.completePrescriptionDropOff(patientId, inputData, "Verify TP Reject with Contact Prescriber");
        tpFlowTestscripts.enterInputFromWrapper(patientId, inputData);
        tpFlowTestscripts.sendToManualResolution();
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-1819: Verify TP Reject with MED B Validation (TP Plan: QA MEDPARTB)
     * @author Sweety Saxena (vn56iwu)
     */
    @Test(enabled = true, description = "Verify TP Reject with MED B Validation", priority = 2,
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_1819(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData, "HWPHME2E_1819 - Verify TP Reject with MED B Validation");
        int rxNbr = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_1819");
        tpFlowTestscripts.verifyTPRejectInResolution(String.valueOf(rxNbr), inputData);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-1820: Drop Rx for TP patient with primary & secondary insurance (QA DISCOUNT + QA COUPON)
     * @author Sweety Saxena (vn56iwu)
     */
    @Test(enabled = true, description = "Drop a singleRx for a TP patient having Commercial TP as primary payment and Add Secondary Insurance.",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "TPFlows")
    public void HWPHME2E_1820(Map<String, Object> inputData) {
        tpFlowTestscripts.createNewPatientWith2TPPlans(inputData);
        tpFlowTestscripts.dropAnRxTillCheckDUR(inputData);
        int rxFillId = tpFlowTestscripts.getRXFromWrapper();
        WrapperTestScript.moveRXToEOD(rxFillId, tpFlowTestscripts.connexusAppUtils.getStoreId(), "MoveTOEOD");
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-1817: Verify TP Reject with NDC Not Covered (TP Plan: Q15 MEDICAID)
     * @author Sweety Saxena (vn56iwu)
     */
    @Test(enabled = true, description = "Verify TP Reject with NDC Not Covered", priority = 4,
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_1817(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData, "HWPHME2E_1817 - Verify TP Reject with NDC Not Covered");
        int rxNbr = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_1817");
        tpFlowTestscripts.verifyTPRejectProblemDescriptionInResolution(inputData, String.valueOf(rxNbr));
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-1816: Verify TP Reject with Prior Authorization (TP Plan: QA REJ2)
     * @author Sweety Saxena (vn56iwu)
     */
    @Test(enabled = true, description = "Verify TP Reject with Prior Authorization", priority = 5,
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_1816(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData, "HWPHME2E_1816 - Verify TP Reject with Prior Authorization");
        int rxNbr = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_1816");
        tpFlowTestscripts.verifyTPErrorInResolution(rxNbr, inputData);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5734: Save patient profile without Refer# in Workers Comp
     * @author Bhavani Kokate (vn5a9ql)
     */
    @Test(enabled = true, description = "Verify user able to save patient profile without providing Refer# in worker's comp",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5734(Map<String, Object> inputData) {
        Map<String, Object> objectInputdata = new HashMap<>(inputData);
        int patientId = WrapperTestScript.createPatient(objectInputdata,
                "HWPHME2E_5734 - Verify user able to save patient profile without providing Refer# in worker's comp");
        String yesterdayDate = LocalDate.now().minusDays(1).format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        objectInputdata.put("INJURY DATE", yesterdayDate);
        // Provide safe defaults for optional keys missing in this row of TPFlows.json (avoids NPE on .toString()).
        objectInputdata.putIfAbsent("ADDRESS2", "");
        tpFlowTestscripts.verifySavePatientProfileInWorkersCompensation(objectInputdata, patientId);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-80: Drop Rx for TP patient with rejection plan as primary (downtime scenario), move to EOD
     * @author snehaa (vn57hhm)
     */
    @Test(enabled = true,
            description = "Drop_a_singleRx_for_a_TP_patient_with_TP_rejection_plan_as_primary_downtime",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_80(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_80 - TC004_Drop_a_singleRx_for_a_TP_patient_with_TP_rejection_plan_as_primary_downtime");
        int rxNbr = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_80");
        tpFlowTestscripts.performResolution(String.valueOf(rxNbr));
        tpFlowTestscripts.perform4Point(String.valueOf(rxNbr));
        int rxFillId = requireNonNullId(stagedClaimData.getRxFillId(), "rxFillId", "HWPHME2E_80");
        WrapperTestScript.moveRXToEOD(rxFillId, tpFlowTestscripts.connexusAppUtils.getStoreId(), "MoveTOEOD");
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-64: Drop Rx for TP patient with rejection plan as primary, verify Resolution queue
     * @author snehaa (vn57hhm)
     */
    @Test(enabled = true,
            description = "Drop_a_singleRx_for_a_TP_patient_with_TP_rejection_plan_as_primary",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_64(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_64 - Drop_a_singleRx_for_a_TP_patient_with_TP_rejection_plan_as_primary");
        int rxNbr = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_64");
        tpFlowTestscripts.verifyWorkQueue(WorkQueue.RESOLVE.getWorkQueue(), String.valueOf(rxNbr));
        tpFlowTestscripts.openresolve(String.valueOf(rxNbr));
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-109: Drop Rx for TP patient with rejection plan as primary, switch to cash, move to EOD
     * @author snehaa (vn57hhm)
     */
    @Test(enabled = true,
            description = "Drop_a_singleRx_for_a_TP_patient_with_TP_rejection_plan_as_primary_switch_to_cash",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_109(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_109 - Drop_a_singleRx_for_a_TP_patient_with_TP_rejection_plan_as_primary_switch_to_cash");
        int rxNbr = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_109");
        tpFlowTestscripts.switchcash(String.valueOf(rxNbr));
        int rxFillId = requireNonNullId(stagedClaimData.getRxFillId(), "rxFillId", "HWPHME2E_109");
        WrapperTestScript.moveRXToEOD(rxFillId, tpFlowTestscripts.connexusAppUtils.getStoreId(), "MoveTOEOD");
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-1818: Drop Rx for TP patient with Commercial TP as primary (QA DISCOUNT), move to EOD.
     * No Connexus UI steps — purely wrapper/API (stageClaimSubmissionData + moveRXToEOD).
     * Runs last so it does not block UI-heavy tests from starting sooner.
     * @author Sweety Saxena (vn56iwu)
     */
    @Test(enabled = true, description = "Drop a singleRx for a TP patient having Commercial TP as primary payment.",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_1818(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_1818 - Drop a singleRx for a TP patient having Commercial TP as primary payment");
        int rxFillId = requireNonNullId(stagedClaimData.getRxFillId(), "rxFillId", "HWPHME2E_1818");
        WrapperTestScript.moveRXToEOD(rxFillId, tpFlowTestscripts.connexusAppUtils.getStoreId(), "MoveTOEOD");
    }

    @AfterClass
    public void tearDown() {
        safeTearDown(tpFlowTestscripts.connexusAppUtils);
    }
}