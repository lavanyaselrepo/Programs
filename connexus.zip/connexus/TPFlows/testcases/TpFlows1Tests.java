package connexus.TPFlows.testcases;

import bom.tests.WrapperTestScript;
import connexus.TPFlows.testscripts.TPFlowTestscripts;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Map;
import java.util.Objects;

import static connexus.ConnexusTestScripts.requireNonNullId;
import static connexus.ConnexusTestScripts.safeTearDown;

/**
 * TP Flow – claim screen, TP plan management, wrapper flows. Login: HOMEOFFICE_ADFlagOn. Flags: 28750=TRUE (default, not set explicitly).
 * No restart required.
 * @author Prasanna Yaragani (p0y00v9), Anju Mohan (a0m1jtc),
 *         Aradhana Surapaneni (a0s1czx), snehaa (vn57hhm)
 */
public class TpFlows1Tests {

    private final TPFlowTestscripts tpFlowTestscripts = new TPFlowTestscripts();

    @BeforeClass
    public void beforeClass() {
        tpFlowTestscripts.connexusAppUtils.startAppiumServer();
        tpFlowTestscripts.loginUserType = LoginAs.userType.HOMEOFFICE_ADFlagOn;
        tpFlowTestscripts.initializeTestCase(false);
    }

    @BeforeMethod(alwaysRun = true)
    public void beforeMethod() {
        System.setProperty("testcaseId", getClass().getSimpleName());
        tpFlowTestscripts.waitForConnexusReady();
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            tpFlowTestscripts.escapeToHome();
        }
    }

    /**
     * HWPHME2E-5111: Drop Rx for TP patient with RX origin as No Associated prescription, move to EOD
     * @author Prasanna Yaragani (p0y00v9)
     */
    @Test(enabled = true,
            description = "Drop a singleRx for a TP patient with RX origin as No Associated prescription",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5111(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_5111 - Drop a singleRx for a TP patient with RX origin as No Associated prescription");
        int rxFillId = requireNonNullId(stagedClaimData.getRxFillId(), "rxFillId", "HWPHME2E_5111");
        int rxNbrInt = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_5111");
        String rxNbr = String.valueOf(rxNbrInt);
        tpFlowTestscripts.validateClaimDetailsScreen(rxNbr, "rx");
        WrapperTestScript.moveRXToEOD(rxFillId, tpFlowTestscripts.connexusAppUtils.getStoreId(), "MoveTOEOD");
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-4878: Verify launching Modify Details in RxLookup for Rx with On-Hold status
     * @author Prasanna Yaragani (p0y00v9)
     */
    @Test(enabled = true,
            description = "Verify launching Modify Details in RxLookup for Rx that is put On-Hold",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_4878(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_4878 - Verify launching Modify Details in RxLookup for Rx that is put On-Hold");
        int rxNbrInt = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_4878");
        String rxNbr = String.valueOf(rxNbrInt);
        tpFlowTestscripts.performFourPointWithOnHoldStatus(rxNbr);
        tpFlowTestscripts.openModifyDetailsFromRxLookUpScreen(rxNbr);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5104: Verify ThirdParty Edit split bill setup between commercial plans with discount card
     * @author Anju Mohan (a0m1jtc)
     */
    @Test(enabled = true, description = "Verify ThirdParty Edit if patient has discount card active user is able to set up split bill between commercial plans",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "TPFlows")
    public void HWPHME2E_5104(Map<String, Object> inputData) {
        Integer patientId = WrapperTestScript.createPatient(inputData,
                "Verify ThirdParty Edit if patient has discount card active user is able to set up split bill between commercial plans");
        tpFlowTestscripts.splitBillWithPlans(patientId, inputData);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5103: Verify eligible cards display with discount coupon
     * @author Anju Mohan (a0m1jtc)
     */
    @Test(enabled = true, description = "Verify eligible cards display with discount coupon",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "TPFlows")
    public void HWPHME2E_5103(Map<String, Object> inputData) {
        Integer patientId = WrapperTestScript.createPatient(inputData, "Verify eligible cards display with discount coupon");
        tpFlowTestscripts.createSplitBillDiscountPlan(inputData, patientId);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5102: Verify Ineligible Cards Display Prompt
     * @author Anju Mohan (a0m1jtc)
     */
    @Test(enabled = true, description = "Verify Ineligible Cards Display Prompt Happy path",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5102(Map<String, Object> inputData) {
        Integer patientId = WrapperTestScript.createPatient(inputData, "Verify Ineligible Cards Display Prompt Happy path");
        tpFlowTestscripts.verifyPlanIneligible(patientId, inputData);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-1408: Validate claim details screen display in Connexus
     * @author Aradhana Surapaneni (a0s1czx)
     */
    @Test(enabled = true, description = "Validate claim details screen display",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_1408(Map<String, Object> inputData) {
        Integer patientId = WrapperTestScript.createPatient(inputData, "Validate claim details screen display");
        WrapperTestScript.completePrescriptionDropOff(patientId, inputData, "Validate claim details screen display");
        tpFlowTestscripts.enterInputFromWrapper(patientId, inputData);
        tpFlowTestscripts.inputScreenAccept();
        Map<String, Object> patientData = tpFlowTestscripts.connexusAppUtils
                .getPatientFirstNameAndLastName(tpFlowTestscripts.connexusAppUtils.getStoreId(), patientId);
        // Defensive: lookup may return null or be missing keys if DB row not found.
        Assert.assertNotNull(patientData, "Patient lookup returned null for patientId: " + patientId);
        String lastName  = Objects.toString(patientData.get("last_name"), null);
        String firstName = Objects.toString(patientData.get("first_name"), null);
        Assert.assertNotNull(lastName,  "Patient last_name missing in DB row for patientId: " + patientId);
        Assert.assertNotNull(firstName, "Patient first_name missing in DB row for patientId: " + patientId);
        String patientSearchTerm = lastName.trim() + ", " + firstName.trim();
        tpFlowTestscripts.validateClaimDetailsScreen(patientSearchTerm, "patientName");
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5200: Update TP plan with new plan using same CardHolderId
     * @author Aradhana Surapaneni (a0s1czx)
     */
    @Test(enabled = true, description = "Update TP plan with a new plan using same CardHolderId",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5200(Map<String, Object> inputData) {
        Integer patientId = WrapperTestScript.createPatient(inputData, "Update TP plan with a new plan");
        Map<String, Object> patientName = tpFlowTestscripts.connexusAppUtils
                .getPatientFirstNameAndLastName(tpFlowTestscripts.connexusAppUtils.getStoreId(), patientId);
        Assert.assertNotNull(patientName, "Patient lookup returned null for patientId: " + patientId);
        tpFlowTestscripts.changeTPPlanWithSameCardHolderId(inputData, patientName);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-3257: Verify M3P as payer of last resort even to Medicaid except TP plans
     * @author Aradhana Surapaneni (a0s1czx)
     */
    @Test(enabled = true, description = "Verify M3P as payer of last resort even to Medicaid except TP plans",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_3257(Map<String, Object> inputData) {
        Integer patientId = WrapperTestScript.createPatient(inputData,
                "Verify M3P as payer of last resort even to Medicaid except TP plans");
        tpFlowTestscripts.verifyM3pIsPayerOfLastResort(patientId, inputData);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-76: Drop Rx for TP patient with Medicaid as primary payment, move to EOD.
     * No Connexus UI steps — purely wrapper/API (stageClaimSubmissionData + moveRXToEOD).
     * @author snehaa (vn57hhm)
     */
    @Test(enabled = true, description = "Drop_a_singleRx_for_a_TP_patient_having_Medicaid_as_primary_payment",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_76(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_76 - Drop a singleRx for a TP patient having Medicaid TP as primary payment");
        int rxFillId = requireNonNullId(stagedClaimData.getRxFillId(), "rxFillId", "HWPHME2E_76");
        WrapperTestScript.moveRXToEOD(rxFillId, tpFlowTestscripts.connexusAppUtils.getStoreId(), "MoveTOEOD");
    }

    /**
     * HWPHME2E-71: Drop Rx for TP patient with Medicare plan (age >= 65), move to EOD.
     * No Connexus UI steps — purely wrapper/API (stageClaimSubmissionData + moveRXToEOD).
     * @author snehaa (vn57hhm)
     */
    @Test(enabled = true,
            description = "Drop_a_singleRx_for_a_TP_with_Medicare_plan_patient_whose_age_is_>=_65yrs",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_71(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "HWPHME2E_71 - Drop_a_singleRx_for_a_TP_with_Medicare_plan_patient_whose_age_is_>=_65yrs");
        int rxFillId = requireNonNullId(stagedClaimData.getRxFillId(), "rxFillId", "HWPHME2E_71");
        WrapperTestScript.moveRXToEOD(rxFillId, tpFlowTestscripts.connexusAppUtils.getStoreId(), "MoveTOEOD");
    }

    @AfterClass
    public void closeConnexus() {
        safeTearDown(tpFlowTestscripts.connexusAppUtils);
    }
}
