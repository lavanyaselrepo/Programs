package connexus.TPFlows.testcases;

import bom.tests.WrapperTestScript;
import connexus.TPFlows.testscripts.TPFlowTestscripts;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuscontext.RxOriginType;
import hwqe.baseframework.datacontext.DataProvider;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static connexus.ConnexusTestScripts.requireNonNullId;
import static connexus.ConnexusTestScripts.safeTearDown;

/**
 * TP Flow – split bill, copay, DAW, misc HOMEOFFICE flows. Login: HOMEOFFICE_ADFlagOn. Flags: 28750=TRUE (default, not set explicitly).
 * HWBOMSQ_7568 also sets 31543=FALSE. No restart required.
 * @author Aradhana Surapaneni (a0s1czx), Anju Mohan (a0m1jtc),
 *         Purnima Arora (vn58gdi), Baha Sadyrov (vn59rtp)
 */
public class TpFlows2Tests {

    private final TPFlowTestscripts tpFlowTestscripts = new TPFlowTestscripts();

    @BeforeClass
    public void beforeClass() {
        tpFlowTestscripts.connexusAppUtils.startAppiumServer();
        tpFlowTestscripts.loginUserType = LoginAs.userType.HOMEOFFICE_ADFlagOn;
        tpFlowTestscripts.initializeTestCase(false);
    }

    @BeforeMethod(alwaysRun = true)
    public void setDefaultADFlag() {
        System.setProperty("testcaseId", getClass().getSimpleName());
        tpFlowTestscripts.waitForConnexusReady();
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            tpFlowTestscripts.escapeToHome();
        }
    }

    /**
     * HWPHME2E-3256: Verify M3P payer of last resort error when Medicaid order is incorrect
     * @author Aradhana Surapaneni (a0s1czx)
     */
    @Test(enabled = true, description = "Verify M3P as payer of last resort error when M3P is last and medicaid is not in correct order",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_3256(Map<String, Object> inputData) {
        Integer patientId = WrapperTestScript.createPatient(inputData,
                "Verify payer of last resort error message when M3P is not the last payer with medicaid is not in correct order");
        tpFlowTestscripts.verifyM3pAsPayerOfLastResortError(patientId, inputData);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWBOMSQ-7984: Verify Additional Info and Help Tab validations on Third Party Edit page
     * @author Aradhana Surapaneni (a0s1czx)
     */
    @Test(enabled = true, description = "Verify Additional information and Help Tab's Field level validations on Third Party Edit page",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWBOMSQ_7984(Map<String, Object> inputData) {
        Integer patientId = WrapperTestScript.createPatient(inputData,
                "Verify Additional information and Help Tab's Field level validations on Third Party Edit page");
        tpFlowTestscripts.thirdPartyEditAdditionalInfoHelpTabValidations(patientId, inputData);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5241: Verify No Associated Prescription RX Origin Code mapped as 6
     * @author Purnima Arora (vn58gdi)
     */
    @Test(enabled = true, description = "Verify No Associated Prescription RX Origin Code mapped as 6-No Associated Prescription",
            priority = 3,
            dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5241(Map<String, String> inputData) {
        tpFlowTestscripts.createPatientAPI(inputData);
        tpFlowTestscripts.performDropOffWithRxOriginType(1, Priority.Critical, RxOriginType.No_associated_prescription);
        tpFlowTestscripts.performInput(inputData);
        tpFlowTestscripts.perform4Point();
        tpFlowTestscripts.performChkDUR();
        String[] patientName = tpFlowTestscripts.connexusAppUtils.readPatientNameFromFile();
        // Defensive: file IO can return null/short array if file is missing or malformed.
        Assert.assertNotNull(patientName, "readPatientNameFromFile() returned null for HWPHME2E_5241");
        Assert.assertTrue(patientName.length >= 2,
                "readPatientNameFromFile() returned " + patientName.length + " element(s); expected >= 2 for HWPHME2E_5241");
        String patientSearchTerm = patientName[0] + "," + patientName[1];
        tpFlowTestscripts.validateRxOriginCode(patientSearchTerm, "patientName", inputData.get("Expected Rx Origin"));
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5243: Verify paper bill copay for split bill with more than 2 payers
     * @author Anju Mohan (a0m1jtc)
     */
    @Test(enabled = true,
            description = "Verify paper bill copay for spilt bill with more than 2 payers",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5243(Map<String, Object> inputData) {
        String testtype = "Verify paper bill copay for spilt bill with more than 2 payers";
        Integer patientId = WrapperTestScript.createPatient(inputData, testtype);
        tpFlowTestscripts.splitBillWithPlans(patientId, inputData);
        WrapperTestScript.complete4PforExistingPatient(inputData, testtype, patientId);
        tpFlowTestscripts.validateCoPay(patientId);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5242: Verify paper bill copay for split bill with 2 payers
     * @author Anju Mohan (a0m1jtc)
     */
    @Test(enabled = true,
            description = "Verify paper bill copay for spilt bill with 2 payers",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5242(Map<String, Object> inputData) {
        String testtype = "Verify paper bill copay for spilt bill with 2 payers";
        Integer patientId = WrapperTestScript.createPatient(inputData, testtype);
        tpFlowTestscripts.splitBillWithPlans(patientId, inputData);
        WrapperTestScript.completePrescriptionDropOff(patientId, inputData, testtype);
        tpFlowTestscripts.dropOffRx(patientId);
        tpFlowTestscripts.enterInputFromWrapper(patientId, inputData);
        tpFlowTestscripts.validateCoPay(patientId);
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5667: Verify DAW values are populated correctly in Input screen
     * @author Anju Mohan (a0m1jtc)
     */
    @Test(enabled = true, description = "Verify DAW values are populated correctly in Input screen",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5667(Map<String, Object> inputData) {
        Integer patientId = WrapperTestScript.createPatient(inputData,
                "Verify DAW values are populated correctly in Input screen");
        WrapperTestScript.completePrescriptionDropOff(patientId, inputData,
                "Verify DAW values are populated correctly in Input screen");
        tpFlowTestscripts.enterInputFromWrapper(patientId, inputData);
        tpFlowTestscripts.inputScreenAccept();
        tpFlowTestscripts.verifyDAWValueInFourPoint(patientId);
        // NOTE: getRXFill signature is (storeId, patientId) but its inner call to InformixWrapper
        // uses the inverted (patientId, siteId) signature, so the original swapped-looking call
        // is in fact correct end-to-end. Do not "fix" the arg order without auditing both layers.
        int rxFillId = tpFlowTestscripts.getRXFill(patientId, tpFlowTestscripts.connexusAppUtils.getStoreId());
        WrapperTestScript.moveRXToEOD(rxFillId, tpFlowTestscripts.connexusAppUtils.getStoreId(), "MoveTOEOD");
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5668: Verify DAW values are populated correctly in Modify screen
     * @author Anju Mohan (a0m1jtc)
     */
    @Test(enabled = true, description = "Verify DAW values are populated correctly in modify screen",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5668(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "Verify DAW values are populated correctly in Modify screen");
        int rxNbrInt = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_5668");
        String rxNbr = String.valueOf(rxNbrInt);
        tpFlowTestscripts.changeDAWValue(rxNbr, inputData);
        tpFlowTestscripts.verifyDAWinModifyScreen(rxNbr, inputData);
        int rxFillId = requireNonNullId(stagedClaimData.getRxFillId(), "rxFillId", "HWPHME2E_5668");
        WrapperTestScript.moveRXToEOD(rxFillId, tpFlowTestscripts.connexusAppUtils.getStoreId(), "MoveTOEOD");
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWPHME2E-5669: Verify DAW values are populated correctly in Modify screen for a TP REJ
     * @author Anju Mohan (a0m1jtc)
     */
    @Test(enabled = true, description = "Verify DAW values are populated correctly in modify screen for a TP REJ",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/TPFlows.json", sheetName = "BOMTPFLOWS")
    public void HWPHME2E_5669(Map<String, Object> inputData) {
        WrapperTestScript.StagedClaimData stagedClaimData =
                WrapperTestScript.stageClaimSubmissionData(inputData,
                        "Verify DAW values are populated correctly in modify screen for a TP REJ");
        int rxNbrInt = requireNonNullId(stagedClaimData.getRxNbr(), "rxNbr", "HWPHME2E_5669");
        String rxNbr = String.valueOf(rxNbrInt);
        tpFlowTestscripts.verifyDAWValueInResolution(rxNbr, inputData);
        tpFlowTestscripts.verifyDAWinModifyScreen(rxNbr, inputData);
        int rxFillId = requireNonNullId(stagedClaimData.getRxFillId(), "rxFillId", "HWPHME2E_5669");
        WrapperTestScript.moveRXToEOD(rxFillId, tpFlowTestscripts.connexusAppUtils.getStoreId(), "MoveTOEOD");
        tpFlowTestscripts.softAssert.assertAll();
    }

    /**
     * HWBOMSQ-7568: Verify Third Party Edit UI Screen data entry.
     * <p><b>Extra flag:</b> 31543=FALSE (set inside this test only; does NOT require service restart).
     * @author Baha Sadyrov (vn59rtp)
     */
    @Test(enabled = false,
            description = "Verify user is able to enter information for Third Party Edit UI Screen",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/TPFlows/InsulinFlows.json", sheetName = "InsulinTests")
    public void HWBOMSQ_7568(Map<String, Object> inputData) {
        // Extra flag: 31543=FALSE (no restart needed)
        tpFlowTestscripts.connexusAppUtils.readAndUpdateFlag("31543", "FALSE");
        int storeId = tpFlowTestscripts.connexusAppUtils.getStoreId();
        Map<String, Object> objectInputData = new HashMap<>(inputData);
        objectInputData.put("siteId", storeId);
        Integer patientId = WrapperTestScript.createPatient(objectInputData, "HWBOMSQ-7568");
        tpFlowTestscripts.setupThirdPartyEditPage(patientId);
        // Defensive: helpers may return null \u2014 fall back to empty list to avoid NPE in for-each.
        List<Map<String, String>> planCardData = tpFlowTestscripts.getPlanCardIdTestData();
        if (planCardData == null) {
            planCardData = Collections.emptyList();
        }
        for (Map<String, String> data : planCardData) {
            tpFlowTestscripts.performPlanCardEdit(data);
            tpFlowTestscripts.validateTPPlanAndCardIdInDB(data, storeId, patientId);
        }
        List<Map<String, String>> carrierData = tpFlowTestscripts.getCarrierTestData();
        if (carrierData == null) {
            carrierData = Collections.emptyList();
        }
        for (Map<String, String> data : carrierData) {
            tpFlowTestscripts.performCarrierEdit(data);
            tpFlowTestscripts.validateTPCarrierFieldsInDB(data, storeId, patientId);
        }
        tpFlowTestscripts.softAssert.assertAll();
    }

    @AfterClass
    public void tearDown() {
        safeTearDown(tpFlowTestscripts.connexusAppUtils);
    }
}
