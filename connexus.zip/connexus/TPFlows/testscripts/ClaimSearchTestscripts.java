package connexus.TPFlows.testscripts;

import connexus.ConnexusTestScripts;
import hwqe.baseframework.models.pageobjectmodels.connexus.ClaimPage;

import java.util.ArrayList;
import java.util.List;

/**
 * Claim Search test scripts for validating claim search functionality.
 * Extends ConnexusTestScripts for login and common utilities.
 */
public class ClaimSearchTestscripts extends ConnexusTestScripts {

    private ClaimPage claimPage;

    private ClaimPage claimPage() {
        if (claimPage == null) {
            claimPage = new ClaimPage();
        }
        return claimPage;
    }

    // Launches the Claim Search screen.
    public void launchClaimSearch() {
        claimPage().launchClaimPage();
    }

    // Searches claims by Patient Name field and returns whether results are displayed.
    public void searchClaimByPatientName(String searchText) {
        claimPage().performClaimSearch(searchText, "patientname");
    }

    // Searches claims by Rx Number field and returns whether results are displayed.
    public void searchClaimByRxNumber(String searchText) {
        claimPage().performClaimSearch(searchText, "rx");
    }

    // Searches claims by Fill Date field and returns whether results are displayed.
    public void searchClaimByFillDate(String searchText) {
        claimPage().performClaimSearch(searchText, "filldate");
    }

    // Searches claims by Carrier field and returns whether results are displayed.
    public void searchClaimByCarrier(String searchText) {
        claimPage().performClaimSearch(searchText, "carrier");
    }

    // Searches claims by Plan field and returns whether results are displayed.
    public void searchClaimByPlan(String searchText) {
        claimPage().performClaimSearch(searchText, "plan");
    }

    // Searches claims by IIN field and returns whether results are displayed.
    public void searchClaimByIIN(String searchText) {
        claimPage().performClaimSearch(searchText, "iin");
    }

    // Searches claims by PCN field and returns whether results are displayed.
    public void searchClaimByPCN(String searchText) {
        claimPage().performClaimSearch(searchText, "pcn");
    }

    // Validates Patient Name field inputs by running searches and returning failing inputs.
    public void validateClaimSearchPatientNameFieldInputs() {
        validateClaimSearchFieldInputs("patientname", getPatientNameFieldTestInputs());
    }

    // Validates Rx Number field inputs by running searches and returning failing inputs.
    public void validateClaimRxNumberFieldInputs() {
        validateClaimSearchFieldInputs("rx", getRxNumberFieldTestInputs());
    }

    // Validates Fill Date field inputs by running searches and returning failing inputs.
    public void validateClaimSearchFillDateFieldInputs() {
        validateClaimSearchFieldInputs("filldate", getFillDateFieldTestInputs());
    }

    // Validates Carrier field inputs by running searches and returning failing inputs.
    public void validateClaimSearchCarrierFieldInputs() {
        validateClaimSearchFieldInputs("carrier", getCarrierFieldTestInputs());
    }

    // Validates Plan field inputs by running searches and returning failing inputs.
    public void validateClaimSearchPlanFieldInputs() {
        validateClaimSearchFieldInputs("plan", getPlanFieldTestInputs());
    }

    // Validates IIN field inputs by running searches and returning failing inputs.
    public void validateClaimSearchIINFieldInputs() {
        validateClaimSearchFieldInputs("iin", getIINFieldTestInputs());
    }

    // Validates PCN field inputs by running searches and returning failing inputs.
    public void validateClaimSearchPCNFieldInputs() {
        validateClaimSearchFieldInputs("pcn", getPCNFieldTestInputs());
    }

    // Runs Claim Search for each input for the given field type and collects failures.
    private void validateClaimSearchFieldInputs(String type, List<String> inputs) {
        for (String input : inputs) {
            claimPage().performClaimSearch(input, type);
        }
    }

    // Returns the Claim Search title text displayed on the UI.
    public String getClaimSearchTitleText() {
        return claimPage().getClaimSearchTitleText();
    }

    // Returns the Plan label text.
    public String getPlanLabelText() {
        return claimPage().getPlanLabelText();
    }

    // Returns the Patient Name label text.
    public String getPatientNameLabelText() {
        return claimPage().getPatientNameLabelText();
    }

    // Returns the Patient Rx Number label text.
    public String getRxNumberLabelText() {
        return claimPage().getRxNumberLabelText();
    }

    // Returns the Fill Date label text.
    public String getFillDateLabelText() {
        return claimPage().getFillDateLabelText();
    }

    // Returns the Carrier label text.
    public String getCarrierLabelText() {
        return claimPage().getCarrierLabelText();
    }

    // Returns the IIN label text.
    public String getIINLabelText() {
        return claimPage().getIINLabelText();
    }

    // Returns the PCN label text.
    public String getPCNLabelText() {
        return claimPage().getPCNLabelText();
    }

    // Builds the input set used for Patient Name field validation.
    private List<String> getPatientNameFieldTestInputs() {
        List<String> inputs = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            inputs.add(repeatChar('A', i));
        }

        inputs.add("123");
        inputs.add("1234567890");

        inputs.add("@");
        inputs.add("#%$");
        inputs.add("A@1");
        return inputs;
    }

    // Builds the input set used for Rx Number field validation.
    private List<String> getRxNumberFieldTestInputs() {
        List<String> inputs = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            inputs.add(repeatChar('1', i));
        }
        inputs.add("RX1");
        inputs.add("1RX");
        inputs.add("@1");
        return inputs;
    }

    // Builds the input set used for Fill Date field validation.
    private List<String> getFillDateFieldTestInputs() {
        List<String> inputs = new ArrayList<>();
        inputs.add("0"); // Current Date
        inputs.add("1"); // Future Date
        inputs.add("-1"); // Past Date
        return inputs;
    }

    // Builds the input set used for Carrier field validation.
    private List<String> getCarrierFieldTestInputs() {
        List<String> inputs = new ArrayList<>();
        for (int i = 1; i <= 3; i++) {
            inputs.add(repeatChar('C', i));
        }
        inputs.add("101");
        inputs.add("@1");
        return inputs;
    }

    // Builds the input set used for Plan field validation.
    private List<String> getPlanFieldTestInputs() {
        List<String> inputs = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            inputs.add(repeatChar('L', i));
        }
        inputs.add("123");
        inputs.add("@1");
        return inputs;
    }

    // Builds the input set used for IIN field validation.
    private List<String> getIINFieldTestInputs() {
        List<String> inputs = new ArrayList<>();
        for (int i = 1; i <= 8; i++) {
            inputs.add(repeatChar('1', i));
        }
        inputs.add("IIN1234");
        inputs.add("1IIN");
        inputs.add("@1");
        return inputs;
    }

    // Builds the input set used for PCN field validation.
    private List<String> getPCNFieldTestInputs() {
        List<String> inputs = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            inputs.add(repeatChar('P', i));
        }
        inputs.add("PCN1");
        inputs.add("1PCN");
        inputs.add("@1");
        return inputs;
    }

    // Returns a string made of the given character repeated count times.
    private String repeatChar(char c, int count) {
        StringBuilder sb = new StringBuilder(count);
        for (int i = 0; i < count; i++) {
            sb.append(c);
        }
        return sb.toString();
    }

}