package connexus.TPFlows.testscripts;

import bom.resources.BomUtils;
import bom.tests.WrapperTestScript;
import com.aventstack.extentreports.Status;
import connexus.TPFlows.TpTestscripts;
import connexus.uattest.testscripts.InputScreenUatTestScripts;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.connexus.AddressModel;
import hwqe.baseframework.models.datamodels.connexus.ContactModel;
import hwqe.baseframework.models.datamodels.connexus.DropRxModel;
import hwqe.baseframework.models.datamodels.connexus.PatientIdentityModel;
import hwqe.baseframework.models.datamodels.connexus.PatientMedicalConditionModel;
import hwqe.baseframework.models.datamodels.connexus.PatientProfileModel;
import hwqe.baseframework.models.datamodels.connexus.PrescriberModel;
import hwqe.baseframework.models.datamodels.connexus.RxModel;
import hwqe.baseframework.models.datamodels.connexus.ThirdPartyModel;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import hwqe.baseframework.utilities.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Advanced TP flows — complex workflows, split billing, wrapper API, and M3P methods. */
public class TPFlowTestscripts extends TpTestscripts {

    private static final Logger log = LoggerFactory.getLogger(TPFlowTestscripts.class);
    private static final String UNEXPECTED_EXCEPTION  = "Unexpected exception";
    private static final String DB_COL_LAST_NAME      = "last_name";
    private static final String DB_COL_FIRST_NAME     = "first_name";

    // Advanced TP-specific utilities (other fields inherited from parent classes)
    // bomUtils now inherited from TpTestscripts — do not redeclare here.
    public ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    public InputScreenUatTestScripts inputScreenUatTestScripts;

    // TPFlow-specific fields for wrapper integration
    public int orderId, rxFillId;
    PropertyReader propertyReader = PropertyReader.getInstance();
    public int storeId = Integer.parseInt(propertyReader.getProperty("cnx.store"));

    @Override
    public void loginConnexus(LoginAs.userType userType) {
        super.loginConnexus(userType);
        inputScreenUatTestScripts = new InputScreenUatTestScripts();
        fourPoint = new FourPoint();
        dropOffPage = new DropOffPage();
    }

    public void createNewPatientWith2TPPlans(Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Must initialise before use — field is null on a fresh test instance
            // (only createNewPatient() initialises it; loginConnexus() does not).
            patient                      = new PatientProfileModel();
            addressModel                 = new AddressModel();
            thirdPartyModel              = new ThirdPartyModel();
            contactModel                 = new ContactModel();
            patientMedicalConditionModel = new PatientMedicalConditionModel();
            patientIdentityModel         = new PatientIdentityModel();

            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(Objects.toString(inputData.get("PAT_DOB"), null));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            thirdPartyModel.setCarrierBin(Objects.toString(inputData.get("TP_CARRIER_BIN"), null));
            thirdPartyModel.setPlan(Objects.toString(inputData.get("TP_PLAN"), null));
            thirdPartyModel.setCardId(Objects.toString(inputData.get("TP_CARD_ID"), null));
            thirdPartyModel.setCarrierBin2(Objects.toString(inputData.get("TP_CARRIER_BIN_2"), null));
            thirdPartyModel.setPlan2(Objects.toString(inputData.get("TP_PLAN_2"), null));
            thirdPartyModel.setCardId2(Objects.toString(inputData.get("TP_CARD_ID_2"), null));
            patient.setPatientTp(thirdPartyModel);

            addressModel.setPatientAddressLine1(Objects.toString(inputData.get("PAT_ADDRESS_LINE1"), null));
            addressModel.setPatientCity(Objects.toString(inputData.get("CITY"), null));
            addressModel.setPatientState(Objects.toString(inputData.get("STATE"), null));
            addressModel.setPatientZipCode(Objects.toString(inputData.get("ZIP_CODE"), null));
            addressModel.setPatientCountry(Objects.toString(inputData.get("COUNTRY"), null));
            patient.setPatientAddress(addressModel);

            contactModel.setPatientPrimaryNumber(Objects.toString(inputData.get("PRIMARY_NUMBER"), null));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            automationManager.getConnexusWorkFlow().createNewPatient(true, patient);

            Reporter.log("Patient has been created.");
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void dropOffRx() {
        DropRxModel dropRxModel = new DropRxModel();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);
    }

    /** Enters required details in Input screen. */
    public void enterInputDetails(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            rxSearch.openSearch();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            rxSearch.selectRowFromSearch(0);
            automationManager.performSleep(1);
            inputPage.enterProductNameInPrescribedProduct(inputData.get("DRUG_NAME"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.selectDAW(1);
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            automationManager.performSleep(1);
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }


    /** Clicks Accept button from Input screen. */
    public void inputScreenAccept() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (inputPage.isTMCodeDisplayed()) {
                inputPage.selectTmCodeField(2);
            }
            if (inputPage.isDxCodeDisplayed()) {
                inputPage.inputRandomDXCode();
            }
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }
            inputPage.checkDiagnosisCode();
            inputPage.checkSpecificDirections();
            inputPage.enterDiagnosisCode();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            inputPage.clickOk();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }


    /** Clicks and validates Send to Resolution button. */
    public void sendToManualResolution() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        InputPage inputPage = new InputPage();
        try {
            automationManager.performSleep(3);
            inputPage.sendMedicareRxToManualResolution("Manual Resolution", InputPage.ManualResolutionType.CONTACT_PRESCRIBER);
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail("sendToManualResolution failed: " + e.getMessage());
            softAssert.assertAll();
        }
    }


    @Override
    public void dropAnRxTillEOD(Map<String, String> inputData) {
        DropRxModel dropRxModel = new DropRxModel();
        RxModel rxModel = new RxModel();
        PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        dropRxModel.setPatientLastName(name[0]);
        dropRxModel.setPatientFirstName(name[1]);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

        rxModel.setPatientLastName(name[0]);
        rxModel.setPatientFirstName(name[1]);
        rxModel.setNdc(inputData.get("DRUG_NAME"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(prescriberModel.getPrescriberLastName() + "," + prescriberModel.getPrescriberFirstName());
        automationManager.getConnexusWorkFlow().performInput(rxModel);
        String rxStatus = rxSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
            automationManager.performSleep(10);
        }
        //automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);

        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        rxStatus = rxSearch.getRXStatusForPatient(rxNbr, 0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            Reporter.log("RX is in Resolve queue");
        } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
            Reporter.log("RX is in CASH queue");
            automationManager.performSleep(5);
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        }
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        automationManager.getConnexusWorkFlow().completeFilling(rxNbr);

        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);

        if ("TRUE".equals(connexusAppUtils.readFlagValue("8670").get(0).get("phm_parm_value").toString().trim())) {
            automationManager.getConnexusWorkFlow().completeBagging(rxNbr);
        }
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
        automationManager.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("PAT_DOB"), rxNbr);
        automationManager.getConnexusWorkFlow().completeCounsel(rxNbr);
        automationManager.getConnexusWorkFlow().completeOfflineSale(rxNbr);

    }

    public void dropAnRxTillCheckDUR(Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            DropRxModel dropRxModel = new DropRxModel();
            RxModel rxModel = new RxModel();
            PrescriberModel prescriberModel = connexusAppUtils.selectPrescriberFromDb();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);

            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxModel.setNdc(Objects.toString(inputData.get("DRUG_NAME"), null));
            rxModel.setPrescribedQty(Objects.toString(inputData.get("QUANTITY"), null));
            rxModel.setSigCode(Objects.toString(inputData.get("SIG"), null));
            rxModel.setNoOfRefills(Objects.toString(inputData.get("REFILLS"), null));
            rxModel.setPrescriberName(prescriberModel.getPrescriberLastName() + "," + prescriberModel.getPrescriberFirstName());
            automationManager.getConnexusWorkFlow().performInput(rxModel);
            String rxStatus = rxSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            //automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail("dropAnRxTillCheckDUR failed: " + e.getMessage());
            softAssert.assertAll();
        }
    }

    public void fourPointToFilling() {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(name[0] + "," + name[1]);
        /*patientSearchPage.openFirstPatientRecord();*/
        rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(name[0] + "," + name[1]);
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);

        String rxStatus = rxSearch.getRXStatusForPatient(rxNbr, 0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            Reporter.log("RX is in Resolve queue");
        } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
            Reporter.log("RX is in CASH queue");
            automationManager.performSleep(5);
            automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
        }
        automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
        automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
    }

    public void changeTPPlanInVV(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = rxSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.DUR.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            rxStatus = rxSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            rxStatus = rxSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(name[0] + "," + name[1]);
                patientSearchPage.openFirstPatientRecord();
                modifyDetails.launchModifyDetailScreen();
                modifyDetails.selectClaimsDropDownSecond();
                String planName = inputData.get("TP_CARRIER_BIN") + " / " + inputData.get("TP_PLAN") + " / " + inputData.get("TP_CARD_ID");
                modifyDetails.switchToInsurance(planName);
                modifyDetails.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickOnConnexusPopUp();
                modifyDetails.checkAndClickWarning();
                modifyDetails.clickConnexusOk();
            } else {
                Reporter.log("RX is not in Visual Verify queue");
                Assert.fail("RX is not in Visual Verify queue");
            }
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    @Override
    public void createNewPatient(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNamesInFile();
            PatientIdentityModel patientIdentityModel = new PatientIdentityModel();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            if (patientSearchPage.isPatientSearchWindowDisplayed()) {
                patientSearchPage.inputPatientName(name[0] + "," + name[1]);
                patientSearchPage.inputPatientDob(inputData.get("PAT_DOB"));
                patientSearchPage.clickSearchNow();
                patientSearchPage.hostSearchPatient();
            }
            patientSearchPage.clickNew();
            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("PAT_DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("PAT_ADDRESS_LINE1"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            thirdPartyModel.setCarrierBin(inputData.get("TP_CARRIER_BIN"));
            thirdPartyModel.setPlan(inputData.get("TP_PLAN"));
            thirdPartyModel.setCardId(inputData.get("TP_CARD_ID"));

            patient.setPatientTp(thirdPartyModel);

            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);
            patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
            patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
            patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));

            patient.setPatientIdentityModel(patientIdentityModel);
            automationManager.performSleep(2);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);
            if (connexusStartPage.isConnexusLaunched()) {
                automationManager.performSleep(3);
                automationManager.getConnexusWorkFlow().createNewPatient(true, patient);
                Reporter.log("Patient has been created.");
                if (!patientSearchPage.verifyPatientSearchScreen()) {
                    patientSearchPage.launchPatientSearchScreen();
                }
                patientSearchPage.inputPatientName(patient.getPatientLastName() + "," + patient.getPatientFirstName());
                patientSearchPage.inputPatientDob(patient.getPatientDob());
                patientSearchPage.clickSearchNow();
                automationManager.performSleep(2);
                patientSearchPage.doubleClickOnSearchGridRow(0);
                patientMaintenancePage.selectRejectPlan(inputData.get("TP_PLAN"));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.clickSaveAndClose();
                patientSearchPage.clickClose();
            } else {
                softAssert.fail("Connexus not launched");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                softAssert.assertAll();
            }

        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void completeVVToEOD(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxSearch.openSearch();
            rxSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            //rxNbr = rxSearch.getRxNbr(0);
            //rxSearch.selectRowFromSearch(0);
            automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
            automationManager.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("PAT_DOB"), rxNbr);
            automationManager.getConnexusWorkFlow().completeCounsel(rxNbr);
            automationManager.getConnexusWorkFlow().completeOfflineSale(rxNbr);
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }

    public int getRXFromWrapper() {
        Map<String, Object> row = informixWrapper.getRX(storeId);
        if (row == null) {
            throw new IllegalStateException(
                    "informixWrapper.getRX returned no row for storeId=" + storeId
                            + ". The Rx might not have been persisted yet.");
        }
        Object rawRxFillId = row.get("rx_fill_id");
        if (rawRxFillId == null) {
            throw new IllegalStateException(
                    "informixWrapper.getRX returned a row without 'rx_fill_id' for storeId=" + storeId);
        }
        if (rawRxFillId instanceof Number) {
            return ((Number) rawRxFillId).intValue();
        }
        try {
            return Integer.parseInt(rawRxFillId.toString().trim());
        } catch (NumberFormatException nfe) {
            throw new IllegalStateException(
                    "Expected numeric rx_fill_id but got '" + rawRxFillId + "'", nfe);
        }
    }

    public int getRXFill(int storeId, Integer patientId) {
        Map<String, Object> row = informixWrapper.getRXFillId(storeId, patientId);
        if (row == null) {
            throw new IllegalStateException(
                    "informixWrapper.getRXFillId returned no row for storeId=" + storeId
                            + ", patientId=" + patientId);
        }
        Object rawRxFillId = row.get("rx_fill_id");
        if (rawRxFillId == null) {
            throw new IllegalStateException(
                    "informixWrapper.getRXFillId returned a row without 'rx_fill_id' for patientId=" + patientId);
        }
        if (rawRxFillId instanceof Number) {
            return ((Number) rawRxFillId).intValue();
        }
        try {
            return Integer.parseInt(rawRxFillId.toString().trim());
        } catch (NumberFormatException nfe) {
            throw new IllegalStateException(
                    "Expected numeric rx_fill_id but got '" + rawRxFillId + "'", nfe);
        }
    }

    public void enterInputFromWrapper(Integer patientId, Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            rxSearch.openSearch();
            automationManager.performSleep(5);
            Map<String, Object> name = informixWrapper.getPatientName(patientId, storeId);
            if (name == null) {
                try {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                } catch (Exception ignored) {
                    Reporter.log("Unable to capture screenshot for null patient lookup (driver may be down).");
                }
                Assert.fail("Patient lookup returned null for patientId: " + patientId);
                return;
            }
            String lastName = Objects.toString(name.get(DB_COL_LAST_NAME), null);
            String firstName = Objects.toString(name.get(DB_COL_FIRST_NAME), null);
            if (lastName == null || firstName == null) {
                try {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                } catch (Exception ignored) {
                    Reporter.log("Unable to capture screenshot for missing patient name (driver may be down).");
                }
                Assert.fail("Patient first/last name not found for patientId: " + patientId);
                return;
            }
            rxSearch.performSearch(lastName.trim() + "," + firstName.trim());
            automationManager.performSleep(5);
            rxSearch.selectRowFromSearch(0);
            automationManager.performSleep(5);
            connexusStartPage.clickAcceptInAddressPopUp();
            automationManager.performSleep(5);
            if (inputPage.isInvalidDataPopUpDisplayed("")) {
                inputPage.dismissValidationPopupAndWait();
                automationManager.performSleep(1);
            }
            String ndc = Objects.toString(inputData.get("ndc"), null);
            Reporter.log("drug name" + ndc);
            boolean productEntered = false;
            for (int attempt = 0; attempt < 3 && !productEntered; attempt++) {
                if (attempt > 0) {
                    Reporter.log("Retrying product entry, attempt " + (attempt + 1));
                }
                inputPage.clickOnPrescribedProductTextBox();
                automationManager.performSleep(2);
                inputPage.enterProductNameInPrescribedProduct(ndc);
                if (inputPage.isInvalidDataPopUpDisplayed("")) {
                    inputPage.dismissValidationPopupAndWait();
                    automationManager.performSleep(2);
                } else {
                    productEntered = true;
                }
            }
            if (!productEntered) {
                Assert.fail("Product entry failed after 3 attempts: " + ndc);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterPrescribedQty(Objects.toString(inputData.get("QUANTITY"), null));
            inputPage.enterSigCode(Objects.toString(inputData.get("SIG"), null));
            inputPage.enterRefillQty(Objects.toString(inputData.get("REFILLS"), null));
            inputPage.verifyDaw();
            // Use Number cast — Jackson sometimes deserializes JSON ints as Long, and string "1" should still work.
            Object dawRaw = inputData.getOrDefault("DAW", 1);
            if (dawRaw == null) {
                dawRaw = 1;
            }
            int dawValue;
            if (dawRaw instanceof Number) {
                dawValue = ((Number) dawRaw).intValue();
            } else {
                try {
                    dawValue = Integer.parseInt(dawRaw.toString().trim());
                } catch (NumberFormatException nfe) {
                    Reporter.log("Invalid DAW value '" + dawRaw + "' — falling back to default 1");
                    dawValue = 1;
                }
            }
            inputPage.selectDAW(dawValue);
            inputPage.enterPrescriber(Objects.toString(inputData.get("PRESCRIBER_NAME"), null));
            automationManager.performSleep(5);
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public void checkRxIsIn4PointQueueFirstPatient(Integer patientId) {
        try {
            String currentStepMethodName = StackUtils.getCurrentMethodName();
            orderSearch = new F6Search();
            Map<String, Object> name = informixWrapper.getPatientName(patientId, storeId);
            String lastName = Objects.toString(name.get(DB_COL_LAST_NAME), null);
            String firstName = Objects.toString(name.get(DB_COL_FIRST_NAME), null);
            if (lastName == null || firstName == null) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Patient name not found for patientId: " + patientId);
            }
            rxNbr = getRxNbr(lastName, firstName, siteId);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                Reporter.logScreenShot("FourPoint", patientSearchPage.takeScreenShot());
                Reporter.log("Rx landed in 4Point without any issue");
                patientSearchPage.clickClose();
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in 4 Point Queue");
            }
        } catch (Exception e) {
            Reporter.log("Failed at 4Point, " + e.getMessage());
            Assert.fail(e.toString());
        }
    }

    public void verifyM3pAsPayerOfLastResortError(Integer patientId, Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openPatientMaintenance(patientId);
            String cardId2 = bomUtils.getRandId(7);
            String cardId3 = bomUtils.getRandId(7);

            String carrierBin2 = Objects.toString(inputData.get("TP_CARRIER_BIN_2"), "");
            String plan2 = Objects.toString(inputData.get("TP_PLAN_2"), "");
            String carrierBin3 = Objects.toString(inputData.get("TP_CARRIER_BIN_3"), "");
            String plan3 = Objects.toString(inputData.get("TP_PLAN_3"), "");
            String validationMsg = Objects.toString(inputData.get("TP_VALIDATION_MESSAGE"), "");

            patientMaintenancePage.performAddAdditionalTPPlanOps(carrierBin2, plan2, cardId2);
            patientMaintenancePage.performAddAdditionalTPPlanOps(carrierBin3, plan3, cardId3);
            Assert.assertTrue(patientMaintenancePage.getTextFromTPEligibilityResponseAdditionPopUup().trim().startsWith(validationMsg.trim()),
                    "M3P pop up message not matching. Actual does not start with expected text.");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to verify M3P as payer of last resort error: " + e.getMessage());
            Assert.fail(e.toString());
        }
    }

    public void thirdPartyEditAdditionalInfoHelpTabValidations(Integer patientId, Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openPatientMaintenance(patientId);
            patientMaintenancePage.clickbtnTPOnThirdPartyInformation();
            patientMaintenancePage.validateContactOnThirdPartyEdit("Contact");
            patientMaintenancePage.validatePhoneOnThirdPartyEdit("2102102100");
            patientMaintenancePage.validateInsuranceBirthDateOnThirdPartyEdit("01/01/1980");
            patientMaintenancePage.thirdPartyHelpOnThirdPartyEdit("Test sample");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to verify Fields on Third party additional information and help page " + e.getMessage());
            Assert.fail(e.toString());
        }
    }

    public  void performInput(Map<String, String>inputData, Integer patientId) {
        RxModel rxModel = new RxModel();
        Map<String, Object> name = informixWrapper.getPatientName(patientId, storeId);
        String lastName = Objects.toString(name.get(DB_COL_LAST_NAME), null);
        String firstName = Objects.toString(name.get(DB_COL_FIRST_NAME), null);
        rxModel.setPatientLastName(lastName);
        rxModel.setPatientFirstName(firstName);
        rxModel.setNdc(inputData.get("DRUG_NAME"));
        rxModel.setPrescribedQty(inputData.get("QUANTITY"));
        rxModel.setSigCode(inputData.get("SIG"));
        rxModel.setNoOfRefills(inputData.get("REFILLS"));
        rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
        automationManager.getConnexusWorkFlow().performInput(rxModel);

    }
    public void dropOffRx(Integer patientId) {
        DropRxModel dropRxModel = new DropRxModel();
        Map<String, Object> name = informixWrapper.getPatientName(patientId, storeId);
        String lastName = Objects.toString(name.get(DB_COL_LAST_NAME), null);
        String firstName = Objects.toString(name.get(DB_COL_FIRST_NAME), null);
        dropRxModel.setPatientLastName(lastName);
        dropRxModel.setPatientFirstName(firstName);
        dropRxModel.setNoOfRx(1);
        dropRxModel.setPriority(Priority.Critical);
        automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);
    }

    public void enterInputDetails(Map<String, Object> inputData, Integer patientId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            inputPage = new InputPage();
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            patientSearchPage.launchOrderSearchScreen();
            Map<String, Object> name = informixWrapper.getPatientName(patientId, storeId);
            String lastName = Objects.toString(name.get(DB_COL_LAST_NAME), null);
            String firstName = Objects.toString(name.get(DB_COL_FIRST_NAME), null);
            patientSearchPage.performSearch(lastName.trim() + "," + firstName.trim());
            patientSearchPage.selectRowFromSearch(0);

            inputPage.enterProductNameInPrescribedProduct(Objects.toString(inputData.get("DRUG_NAME"), null));
            inputPage.enterPrescribedQty(Objects.toString(inputData.get("QUANTITY"), null));
            inputPage.enterSigCode(Objects.toString(inputData.get("SIG"), null));
            inputPage.enterRefillQty(Objects.toString(inputData.get("REFILLS"), null));
            inputPage.enterPrescriber(Objects.toString(inputData.get("PRESCRIBER_NAME"), null));
            automationManager.performSleep(1);
            addRxButtonValidation();
            inputPage.clickAccept();
            inputScreenCancelButtonPopupValidation(inputData);
            inputPage.enterProductNameInPrescribedProduct(Objects.toString(inputData.get("DRUG_NAME2"), null));
            inputPage.enterPrescribedQty(Objects.toString(inputData.get("QUANTITY"), null));
            inputPage.enterSigCode(Objects.toString(inputData.get("SIG"), null));
            inputPage.enterRefillQty(Objects.toString(inputData.get("REFILLS"), null));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void inputScreenCancelButtonPopupValidation(Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            inputPage.clickCancel();
            inputPage.switchWindow();
            if (inputPage.getInputScreenPopupMessage().contains((CharSequence) inputData.get("MESSAGE"))) {
                inputPage.clickInputCancelYesButton();
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void addRxButtonValidation() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Integer noOfRxBefore = Integer.parseInt(inputPage.getTextnoOfRxField());
            inputPage.clickAddRxButton();
            Integer noOfRxAfter = Integer.parseInt(inputPage.getTextnoOfRxField());
            if (noOfRxBefore < noOfRxAfter) {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void moveMultiRxToEod(Integer patientId) {
        List<Integer> multiRxNum = informixWrapper.getMultiRxNbrFromPatientId(patientId, storeId);
        try {
            for (int i = 0; i < multiRxNum.size(); i++) {
                rxNbr = String.valueOf(multiRxNum.get(i));
                WrapperTestScript.moveRXToEOD(connexusAppUtils.getFillId(rxNbr), storeId, "MoveTOEOD");
                Reporter.log("Rx " + rxNbr + " moved to EOD ");
            }
        } catch (Exception e) {
            Reporter.log("Test failed at Input queue: " + e.getMessage());
            log.error(UNEXPECTED_EXCEPTION, e);
            Assert.fail(e.toString());
        }
    }

    /** Launches Claim screen, searches, opens first record, asserts Claim Details renders. Closes in finally block. */
    public void validateClaimDetailsScreen(String searchTerm, String searchType) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        boolean claimOpened = false;
        try {
            openClaimDetailsForSearch(searchTerm, searchType, currentStepMethodName);
            claimOpened = true;
            Reporter.log("Claim details screen is displayed successfully");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, claimPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, claimPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Claim detail page is not validated: " + e.getMessage());
        } finally {
            closeClaimDetailsScreenQuietly(claimOpened);
        }
    }

    /** Launches Claim screen, opens first record, asserts RX Origin Code equals {@code expectedRxOrigin}. */
    public void validateRxOriginCode(String searchTerm, String searchType, String expectedRxOrigin) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        boolean claimOpened = false;
        try {
            openClaimDetailsForSearch(searchTerm, searchType, currentStepMethodName);
            claimOpened = true;
            String actualRxOrigin = claimPage.getRxOriginCd();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, claimPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertEquals(actualRxOrigin, expectedRxOrigin,
                    "Rx Origin Code mismatch for search [" + searchTerm + "]");
            Reporter.log("Rx Origin Code validated: " + actualRxOrigin);
        } catch (Exception e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, claimPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Rx Origin not validated: " + e.getMessage());
        } finally {
            closeClaimDetailsScreenQuietly(claimOpened);
        }
    }

    /** Shared open-and-assert helper for the Claim Details screen. */
    private void openClaimDetailsForSearch(String searchTerm, String searchType, String stepName) {
        String effectiveType = (searchType == null || searchType.isBlank()) ? "patientName" : searchType;

        if (claimPage == null){
            claimPage = new ClaimPage();
        }
        if (patientSearchPage == null){
            patientSearchPage = new PatientSearchPage();
        }
        if (loginPage == null){
            loginPage = new LoginPage();
        }
        claimPage.launchClaimPage();
        claimPage.performClaimSearch(searchTerm, effectiveType);
        Reporter.logScreenShot(Status.PASS, "Claim Search", claimPage.takeScreenShot(stepName).getValue());
        automationManager.performSleep(3);
        patientSearchPage.openFirstPatientRecord();
        automationManager.performSleep(3); // let claim details paint before asserting
        Assert.assertTrue(loginPage.validateClaimDetailsPageIsLaunched(),
                "Claim details page did not launch for: " + searchTerm);
    }

    /** Best-effort close — never mask the original failure. */
    private void closeClaimDetailsScreenQuietly(boolean claimOpened) {
        if (!claimOpened) {
            return;
        }
        try {
            claimPage.closeClaimDetailsScreen();
        } catch (Exception ignored) {
            // best-effort cleanup
        }
    }

    /** Changes TP plan when order in Filling queue. */
    public void changeTPPlanInModifyScreen(Map<String, String> inputData, Integer patientId ) {
        try {
            String currentStepMethodName = StackUtils.getCurrentMethodName();
            orderSearch = new F6Search();
            Map<String, Object> name = informixWrapper.getPatientName(patientId, storeId);
            String lastName = Objects.toString(name.get(DB_COL_LAST_NAME), null);
            String firstName = Objects.toString(name.get(DB_COL_FIRST_NAME), null);
            if (lastName == null || firstName == null) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Patient name not found for patientId: " + patientId);
            }
            rxNbr = getRxNbr(lastName, firstName, siteId);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.openFirstPatientRecord();
                modifyDetails.launchModifyDetailScreen();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.selectClaimsDropDown();
                String planName = inputData.get("TP_CARRIER_BIN") + " / " + inputData.get("TP_PLAN");
                modifyDetails.switchPaymentPlan(planName);
                modifyDetails.selectClaimsDropDownSecond();
                String planName2 = inputData.get("TP_CARRIER_BIN_2") + " / " + inputData.get("TP_PLAN_2");
                modifyDetails.switchPaymentPlan(planName2);
                modifyDetails.clickAccept();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickOnConnexusPopUp();
                modifyDetails.checkAndClickWarning();
            }else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in Filling Queue");
            }

        }catch (Throwable e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Reporter.log(Status.FAIL, "Either RX is not in " + inputData.get("CURRENT_WORKQUEUE") + " nor in " + inputData.get("ProblemDescription"));
            Assert.fail("Third Party Plan is not updated in Modify Details Page" + e.getMessage());
        }
    }

    public void changeTPPlanWithSameCardHolderId(Map<String, Object> inputData,  Map<String, Object> patientName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();

        try {
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.inputPatientName(String.valueOf(patientName.get(DB_COL_LAST_NAME)).trim() + ", " + String.valueOf(patientName.get(DB_COL_FIRST_NAME)).trim());
            patientSearchPage.clickSearchNow();
            automationManager.performSleep(3);
            patientSearchPage.selectRowFromSearch(0);
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickPopUpOkBtn();
            patientMaintenancePage.clickTpBtn();
            patientMaintenancePage.clickbtnEditTP();
            patientMaintenancePage.selectTPPlanOnThirdPartyEditScreen(String.valueOf(inputData.get("TP_PLAN_2")).trim());
            patientMaintenancePage.checkSameAsPatientIfUnchecked();
            patientMaintenancePage.clickbtnAcceptOnThirdPartyEdit();
            patientMaintenancePage.exitFromScreenUsingEscape();
            automationManager.performSleep(3);
            Assert.assertEquals(patientMaintenancePage.getTPPlan(), String.valueOf(inputData.get("TP_PLAN_2")).trim(), "TP plan is not updated with same card holder id");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Successfully updated patient TP plan with same card holder id");

        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to update patient TP plan with same card holder id: " + e.getMessage());
            Assert.fail(e.toString());
        }
    }

    public void verifyRxInResolutionQueueWithSplitbillM3P(Map<String, String> inputData, Integer patientId ) {
        try {
            String currentStepMethodName = StackUtils.getCurrentMethodName();
            orderSearch = new F6Search();
            Map<String, Object> name = informixWrapper.getPatientName(patientId, storeId);
            String lastName = Objects.toString(name.get(DB_COL_LAST_NAME), null);
            String firstName = Objects.toString(name.get(DB_COL_FIRST_NAME), null);
            if (lastName == null || firstName == null) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Patient name not found for patientId: " + patientId);
            }
            rxNbr = getRxNbr(lastName, firstName, siteId);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            Reporter.logScreenShot("Resolve WorkQueue", patientSearchPage.takeScreenShot());
            orderSearch.openFirstPatientRecord();
            Reporter.logScreenShot("Resolution Billing Sequence Error Page", patientSearchPage.takeScreenShot());
        } catch (Throwable e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Reporter.log(Status.FAIL, "Either RX is not in " + inputData.get("CURRENT_WORKQUEUE") + " nor in " + inputData.get("ProblemDescription"));
            Assert.fail("Rx is not in expected work Queue " + e.getMessage());
        }
    }

    /** Moves patient order to Filling status and returns rxNbr. */
    public String dropRxtoFilling (Map<String, String> inputData, int storeId,int patientId) {
        try {
            IDatabaseContext cnx = automationManager.getConnexusDB(storeId);
            DataRow drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("NDC_NUMBER"));
            int numRefills = Integer.parseInt(inputData.get("REFILLS"));

            InputResponse fillingResponse = connexusAPIManager.createNewOrderAndMoveToFilling(
                    patientId,
                    storeId,
                    numRefills,
                    drugInfo,
                    inputData.get("NDC_NUMBER")
            );

            rxNbr = String.valueOf(fillingResponse.getRxNbr());
            rxFillId = fillingResponse.getRxFillId();
            orderId = fillingResponse.getOrderId();
            Reporter.log("Order moved to Filling - rxNbr: " + rxNbr + ", rxFillId: " + rxFillId + ", orderId: " + orderId);
            return rxNbr;

        } catch (Exception e) {
            Reporter.log("Failed while moving to Filling: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public void verifyRxInResolutionQueueWithSplitbillM3P(Map<String, String> inputData , String rxNbr){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String workQueue = rxSearch.getWorkQueueStatus(rxNbr, 0);
            Reporter.log("Current Work Queue : " + workQueue);
            String problemDescription = rxSearch.getProblemMessage(0);
            Reporter.log("ProblemDescription : " + problemDescription);
            if ((workQueue.equalsIgnoreCase(inputData.get("CURRENT_WORKQUEUE"))) && (problemDescription.equalsIgnoreCase(inputData.get("ProblemDescription")))) {
                rxSearch.openFirstPatientRecord();
                Reporter.logScreenShot("Resolution Screen", resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.log(Status.FAIL, "Either RX is not in " + inputData.get("CURRENT_WORKQUEUE") + "Work Queue nor with Problem Description: " + inputData.get("ProblemDescription"));
                Assert.fail("Current Work Queue: " + workQueue + " and Problem Description: " + problemDescription);
            }
        } catch (Throwable e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Assert.fail("Failed in method verifyRxInResolutionQueueWithSplitbillM3P");
        }
    }

    public void addInsuranceInModifyDetailsScreen(Map<String,String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertTrue(modifyDetails.isDxCodeDisplayed(), "Modify Details screen not opened");
            modifyDetails.selectClaimsDropDownSecond();
            String planName = inputData.get("TP_CARRIER_BIN_2") + " / " + inputData.get("TP_PLAN_2") + " / " + inputData.get("TP_CARD_ID_2");
            modifyDetails.switchToInsurance(planName);
            Reporter.logScreenShot(currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickAccept();
        } catch (Throwable e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Assert.fail( "Insurance information not updated, failed in addInsuranceInModifyDetailsScreen method");
        }
    }

    public void validateCoPay(Integer patientId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            patientSearchPage.launchOrderSearchScreen();
            Map<String, Object> name = informixWrapper.getPatientName(patientId, connexusAppUtils.getStoreId());
            String lastName = Objects.toString(name.get(DB_COL_LAST_NAME), null);
            String firstName = Objects.toString(name.get(DB_COL_FIRST_NAME), null);
            rxSearch.performSearch(lastName.trim() + "," + firstName.trim());
            rxSearch.selectRowFromSearch(0);
            automationManager.performSleep(5);
            resolutionPage.clickPaperBillButton();
            resolutionPage.enterCoPayAmt("0.01");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            resolutionPage.clickAccept();
            resolutionPage.clickOkPaperBill();
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            patientSearchPage.openFirstPatientRecord();
            automationManager.performSleep(5);
            String patPay = resolutionPage.getPatientPay();
            Assert.assertEquals(patPay, "0.01");

        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }
    }

    /** Changes TP plan order in Modify Details when order in Filling queue. */
    public void changePayerPlanInModifyScreen(Map<String, String> inputData, Integer patientId ) {
        try {
            String currentStepMethodName = StackUtils.getCurrentMethodName();
            orderSearch = new F6Search();
            Map<String, Object> name = informixWrapper.getPatientName(patientId, storeId);
            String lastName = Objects.toString(name.get(DB_COL_LAST_NAME), null);
            String firstName = Objects.toString(name.get(DB_COL_FIRST_NAME), null);
            if (lastName == null || firstName == null) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Patient name not found for patientId: " + patientId);
            }
            rxNbr = getRxNbr(lastName, firstName, storeId);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                modifyDetails.launchModifyDetailScreen();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());

                String planName = inputData.get("TP_CARRIER_BIN_2").trim() + " / " + inputData.get("TP_PLAN_2").trim() + " / " + inputData.get("TP_CARD_ID_2").trim();
                modifyDetails.switchPaymentPlan(0, planName);
                String planName2 = inputData.get("TP_CARRIER_BIN_4").trim() + " / " + inputData.get("TP_PLAN_4").trim() + " / " + inputData.get("TP_CARD_ID_4").trim();
                modifyDetails.switchPaymentPlan(1, planName2);
                String planName3 = inputData.get("TP_CARRIER_BIN_3") + " / " + inputData.get("TP_PLAN_3") + " / " + inputData.get("TP_CARD_ID_3");
                modifyDetails.switchPaymentPlan(2, planName3);
                String planName4 = inputData.get("TP_CARRIER_BIN") + " / " + inputData.get("TP_PLAN") + " / " + firstName.trim() + lastName.trim();
                modifyDetails.switchPaymentPlan(3, planName4);
                automationManager.performSleep(2);
                modifyDetails.clickAccept();
                automationManager.performSleep(2);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickOnConnexusPopUp();
                modifyDetails.checkAndClickWarning();
                if (! checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    Assert.fail("Order not moved to Resolve Queue");
                }
            }else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in Filling Queue");
            }
        }catch (Throwable e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Assert.fail("Third Party Plan is not updated in Modify Details Page: " + e.getMessage());
        }
    }

    public void verifyDAWValueInFourPoint(Integer patientId) {

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            patientSearchPage.launchOrderSearchScreen();
            Map<String, Object> name = informixWrapper.getPatientName(patientId, connexusAppUtils.getStoreId());
            String lastName = Objects.toString(name.get(DB_COL_LAST_NAME), null);
            String firstName = Objects.toString(name.get(DB_COL_FIRST_NAME), null);
            rxSearch.performSearch(lastName.trim() + "," + firstName.trim());
            rxSearch.selectRowFromSearch(0);
            automationManager.performSleep(5);
            Assert.assertTrue(fourPoint.getDAW().contains("1"));

        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }
    }

    /** Performs drop-off for existing patient in DropOff queue. */
    public void performDropOff(Integer patientId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Retrieve and validate patient information
            Map<String, Object> patientInfo = informixWrapper.getPatientName(patientId, storeId);
            String lastName = Objects.toString(patientInfo.get(DB_COL_LAST_NAME), null);
            String firstName = Objects.toString(patientInfo.get(DB_COL_FIRST_NAME), null);
            Object birthDateObj = patientInfo.get("birth_date");
            if (lastName == null || firstName == null || birthDateObj == null) {
                Assert.fail("Patient information not found/invalid for patientId: " + patientId + " data=" + patientInfo);
            }
            String patientDob = LocalDate.parse(birthDateObj.toString().trim()).format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));

            dropRxModel.setPatientLastName(lastName.trim());
            dropRxModel.setPatientFirstName(firstName.trim());
            dropRxModel.setDob(patientDob);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.InStore);
            automationManager.getConnexusWorkFlow().existingPatientDropOff(dropRxModel);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            Reporter.log("Test failed at DropOff queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /** Enters Rx data and accepts Rx. */
    public void enterInsulinRxDataAndValidateAdministrationPopup(Map<String, String> inputData, Integer patientId, boolean isVisibleAdministrationPopup, boolean isVisibleMedBorMedDButton, boolean isVisibleMedBButton) {

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            handleInputBasicData(inputData, patientId);
            inputPage.clickInsulinAndInputAcceptBtn();
            inputPage.clickAccept();
            handleInputPopups();
            if(isVisibleAdministrationPopup){
                if(isVisibleMedBorMedDButton){
                    Assert.assertTrue(inputPage.isPatientDoesNotHaveMedBOrMedDButtonDisplayed());
                    Reporter.log("ASSERT PASSED. Patient does not have Med B or Med D button is displayed as expected");
                }else if(isVisibleMedBButton){
                    Assert.assertTrue(inputPage.isPatientDoesNotHaveMedBButtonDisplayed());
                    Reporter.log("ASSERT PASSED. Patient does not have Med B button is displayed as expected");
                }
                inputPage.verifyAdministrationPopupMessageDisplayed(isVisibleMedBorMedDButton, isVisibleMedBButton);
                Reporter.log("ASSERT PASSED. Insulin administration popup is displayed as expected");
            }else{
                Assert.assertFalse(inputPage.isPatientDoesNotHaveMedBOrMedDButtonDisplayed());
                Reporter.log("ASSERT PASSED. Patient does not have Med B or Med D button is not displayed as expected");
            }
        } catch (Throwable e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Assert.fail("Failed to enter Rx insulin data in input page and validating the Administration popup: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /** Verifies insulin administration popup when user clicks Yes in validate Rx popup. */
    public void verifyInsulinRxResolutionWhenUserSelectsMoveToResolutionOnAdministrationPopup(Map<String, String> inputData, Integer patientId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Retrieve and validate patient information
            String fullPatientName = getFullPatientNameFromDb(patientId, currentStepMethodName);

            enterInsulinRxDataAndValidateAdministrationPopup(inputData, patientId,true, true, false);
            inputPage.clickOnMoveToResolutionBtn();
            inputPage.clickOnOutofStockPopupOk();
            rxSearch.launchOrderSearchScreen();
            rxSearch.performSearch(fullPatientName);
            Assert.assertEquals(rxSearch.getWorkQueue(0), inputData.get("CURRENT_WORKQUEUE"));
            Reporter.log("ASSERT PASSED. Rx in Resolve Queue as expected");
            Assert.assertEquals(rxSearch.getProblemMessage(0), inputData.get("ProblemDescription"));
            Reporter.log("ASSERT PASSED. Rx Problem message is Contact Customer as expected");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Assert.fail("Failed to validate Rx work queue an problem message: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /** Verifies insulin administration popup when user clicks "Patient does not have Med B or Med D" button. */
    public void verifyInsulinRxLandsIn4PointWhenUserSelectsPatientDoesNtHaveMedBorMedDOnAdministrationPopup(Map<String, String> inputData, Integer patientId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Retrieve and validate patient information
            String fullPatientName = getFullPatientNameFromDb(patientId, currentStepMethodName);

            enterInsulinRxDataAndValidateAdministrationPopup(inputData, patientId, true, true, false);
            inputPage.clickOnPatientDoesNtHaveMedBorMedDBtn();
            inputPage.clickOnOutofStockPopupOk();
            rxSearch.launchOrderSearchScreen();
            rxSearch.performSearch(fullPatientName);
            Assert.assertEquals(rxSearch.getWorkQueue(0), inputData.get("CURRENT_WORKQUEUE"));
            Reporter.log("ASSERT PASSED. Rx in 4 Point work Queue as expected");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Assert.fail("Failed to Validate Rx 4 point queue status : " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    private void handleInputBasicData(Map<String, String> inputData, Integer patientId) {
        Map<String, Object> objectInputData = new HashMap<>(inputData);
        enterInputFromWrapper(patientId, objectInputData);
        String expandedSig = inputData.get("EXPANDED_SIG");
        if(StringUtils.isNotNullOrEmpty(expandedSig)){
            inputPage.enterExpandedSig(expandedSig);
        }
        if (inputPage.isEnterMaxDoseFieldIsDisplayed()){
            inputPage.enterMaxDose("1");
        }
        String dxCode = inputData.get("DX_CODE");
        if (StringUtils.isNotNullOrEmpty(dxCode) && inputPage.isDxCodeDisplayed()) {
            inputPage.inputDxCode(dxCode);
        }
        inputPage.enterDaysSupply("1");
        String insulinDiagnosisCode = inputData.get("INSULIN_DIAGNOSIS_CODE");
        if (StringUtils.isNotNullOrEmpty(insulinDiagnosisCode) && inputPage.isInsulinDiagnosisCodeDisplayed()) {
            inputPage.enterInsulinDiagnosisCode(insulinDiagnosisCode);
        }
    }

    private void handleInputPopups() {
        if (inputPage.isCnxPopUpMessageDisplayed()) {
            inputPage.clickOkOnCnxPopUpMessage();
        }
        if (inputPage.isTriplicateDisplayed()) {
            inputPage.inputTriplicateNumber();
        }
        inputPage.clickYesOnValidateRxPopUp();
        inputPage.clickOnOutofStockPopupOk();
    }

    public void verifyNoInsulinAdministrationPopupOnInputPage() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(3);
            if (inputPage.isInsulinAdministrationPopupMessageDisplayed()) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                        inputPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Insulin Administration pop-up appeared on Input page. " +
                        "This should NOT happen for patient < 65 years old with no Expanded Sig and no DX code.");
            } else {
                Reporter.log("PASS: No Insulin Administration pop-up displayed on Input page (as expected for patient < 65 years)");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                        inputPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            Reporter.log("ERROR during pop-up verification: " + e.getMessage());
            throw new RuntimeException("Failed to verify Insulin Administration pop-up on Input page: " + e.getMessage(), e);
        }
    }

    public void performInputWithFreeFormPopUpAndMaxDailyDoseValidation(Map<String, String> inputData, Integer patientId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            handleInputBasicData(inputData, patientId);
            inputPage.clickAccept();
            inputPage.clickMaxDoseButtonOk();
            if(inputPage.isMaxDoseBoxEnabled()){
                inputPage.enterMaxDose(inputData.get("MAX_DAILY_DOSE"));
            }
            inputPage.clickMaxDoseButtonOk();
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterDaysSupply(inputData.get("DAYS"));
            handleInputPopups();
            inputPage.clickAccept();
            if (inputPage.isCnxPopUpMessageDisplayed()) {
                inputPage.clickOkOnCnxPopUpMessage();
            }
            inputPage.clickYesOnValidateRxPopUp();
            inputPage.clickOnOutofStockPopupOk();
        } catch (Throwable e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Assert.fail("Failed to enter Rx insulin data in input page and validating the Administration popup: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    /** Common setup for Part B Card flows: enters insulin Rx, moves to resolution, verifies queue, opens record. Returns fullPatientName. */
    private String setupInsulinRxAndMoveToResolution(Map<String, String> inputData, Integer patientId, String currentStepMethodName) {
        String fullPatientName = getFullPatientNameFromDb(patientId, currentStepMethodName);
        try {
            handleInputBasicData(inputData, patientId);
            inputPage.clickMaxDoseButtonOk();
            if (inputPage.isMaxDoseBoxEnabled()) {
                inputPage.enterMaxDose(inputData.get("MAX_DAILY_DOSE"));
            }
            inputPage.clickMaxDoseButtonOk();
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterDaysSupply(inputData.get("DAYS"));
            String insulinDiagnosisCode = inputData.get("INSULIN_DIAGNOSIS_CODE");
            if (StringUtils.isNotNullOrEmpty(insulinDiagnosisCode) && inputPage.isInsulinDiagnosisCodeDisplayed()) {
                inputPage.enterInsulinDiagnosisCode(insulinDiagnosisCode);
            }
            inputPage.clickInsulinAndInputAcceptBtn();
            if (inputPage.isCnxPopUpMessageDisplayed()) {
                inputPage.clickOkOnCnxPopUpMessage();
            }
        } catch (Throwable e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Assert.fail("Failed to enter Rx insulin data in input page and validating the Administration popup: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
        inputPage.pressKeys(KeyEvent.VK_TAB);
        inputPage.pressKeys(KeyEvent.VK_ENTER);
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(fullPatientName);
        String actualWorkQueue = rxSearch.getWorkQueue(0);
        Assert.assertEquals(actualWorkQueue, "Resolve",
                "Expected Rx to be in Resolve queue after clicking Move to Resolution");
        automationManager.performSleep(5);
        patientSearchPage.openFirstPatientRecord();
        automationManager.performSleep(3);
        return fullPatientName;
    }

    private void verifyFinalQueueIs4Point(String fullPatientName) {
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(fullPatientName);
        String expectedQueue = "4 Point";
        String finalQueue = rxSearch.getWorkQueue(0);
        Assert.assertEquals(finalQueue, expectedQueue,
                "Expected Rx to move to " + expectedQueue + " queue after Part B Card action");
    }

    public void verifyRxProceedsWhenProceedWithoutPartBCardClicked(Map<String, String> inputData, Integer patientId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String fullPatientName = setupInsulinRxAndMoveToResolution(inputData, patientId, currentStepMethodName);
            resolutionPage.clickProceedWithoutPartBCard();
            automationManager.performSleep(5);
            verifyFinalQueueIs4Point(fullPatientName);
        } catch (Throwable e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to verify Proceed Without Part B Card flow: " + e.getMessage());
        }
    }

    public void verifyRxMovesTo4PointAfterAddingMedBPlan(Map<String, String> inputData, Integer patientId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String fullPatientName = setupInsulinRxAndMoveToResolution(inputData, patientId, currentStepMethodName);
            resolutionPage.clickAddMedB();
            automationManager.performSleep(5);
            rxSearch.launchOrderSearchScreen();
            rxSearch.performSearch(fullPatientName);
            patientSearchPage.openFirstPatientRecord();
            String randomCardId = bomUtils.getRandId(7);
            patientMaintenancePage.fillTPPlanDetailsAndAccept(inputData.get("TP_CARRIER_BIN"), Integer.parseInt(inputData.get("TP_PLAN_POSITION")), randomCardId);
            automationManager.performSleep(5);
            verifyFinalQueueIs4Point(fullPatientName);
        } catch (Throwable e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to verify Add Med B Plan flow: " + e.getMessage());
        }
    }

    private String getFullPatientNameFromDb(Integer patientId, String currentStepMethodName) {
        Map<String, Object> patientInfo = informixWrapper.getPatientName(patientId, storeId);
        String lastName = Objects.toString(patientInfo.get(DB_COL_LAST_NAME), null);
        String firstName = Objects.toString(patientInfo.get(DB_COL_FIRST_NAME), null);
        if (lastName == null || firstName == null) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Patient information not found for patientId: " + patientId);
        }
        return lastName.trim() + "," + firstName.trim();
    }

    /** Verifies saving Workers Compensation without Refer data. */
    public void verifySavePatientProfileInWorkersCompensation(Map<String, Object> inputData, Integer patientId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Map<String, Object> patientInfo = informixWrapper.getPatientName(patientId, storeId);
            if (patientInfo == null) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Patient info lookup returned null for patientId: " + patientId);
                return;
            }
            String lastName = Objects.toString(patientInfo.get(DB_COL_LAST_NAME), null);
            String firstName = Objects.toString(patientInfo.get(DB_COL_FIRST_NAME), null);
            Object birthDateObj = patientInfo.get("birth_date");

            if (lastName == null || firstName == null || birthDateObj == null) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Patient information not found for patientId: " + patientId);
                return;
            }
            String patientDob = LocalDate.parse(birthDateObj.toString().trim()).format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
            patientMaintenancePage.launchPatientSearchScreenAndOpenFirstRecord(lastName.trim(), firstName.trim(), patientDob);

            String carrierBin = Objects.toString(inputData.get("TP_CARRIER_BIN"), "").trim();
            String plan       = Objects.toString(inputData.get("TP_PLAN"), "").trim();
            // CARDID is optional in test data — Workers Comp does not require a specific id, so generate one if missing.
            String cardId     = Objects.toString(inputData.get("CARDID"), "").trim();
            if (cardId.isEmpty()) {
                cardId = bomUtils.getRandId(7);
                Reporter.log("CARDID not supplied in input data — generated random id: " + cardId);
            }
            Assert.assertFalse(carrierBin.isEmpty() || plan.isEmpty(),
                    "Missing required TP insurance data (carrierBin/plan)");

            patientMaintenancePage.enterInsurancePlanDetailsOnThirdPartyInfo(carrierBin, plan, cardId);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickOnWorkersCompensationTab();
            // Use Objects.toString(..., "") for every field — missing keys must NOT NPE.
            patientMaintenancePage.enterEmployer(Objects.toString(inputData.get("EMPLOYER"), ""));
            patientMaintenancePage.inputAddressLine1(Objects.toString(inputData.get("ADDRESS"), ""));
            patientMaintenancePage.inputAddressLine2(Objects.toString(inputData.get("ADDRESS2"), ""));
            patientMaintenancePage.ZipCode(Objects.toString(inputData.get("ZIP_CODE"), ""));
            patientMaintenancePage.enterInjuryDate(Objects.toString(inputData.get("INJURY DATE"), ""));
            patientMaintenancePage.enterContact(Objects.toString(inputData.get("CONTACT"), ""));
            patientMaintenancePage.enterPhone(Objects.toString(inputData.get("PRIMARY_NUMBER"), ""));
            patientMaintenancePage.clickbtnAcceptOnThirdPartyEdit();
            patientMaintenancePage.clickSaveAsEntered();
            Reporter.log("ASSERT PASSED. Able to save create Workers compensation without giving Refer data");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            verifyPatientProfileInWCP(inputData);
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to update patient's Worker Compensation TP plan without entering Refer Input: " + e.getMessage());
            Assert.fail(e.toString());
        }
    }

    /** Verifies Workers Compensation data in Patient Profile. */
    public void verifyPatientProfileInWCP(Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {

            patientMaintenancePage.cilckOnEditTpBtn();
            Assert.assertTrue(patientMaintenancePage.getCarrierIDInPTMSScreen().equalsIgnoreCase(inputData.get("TP_CARRIER_BIN").toString()));
            Assert.assertTrue(patientMaintenancePage.getPlanNameInPTMSScreen().equalsIgnoreCase(inputData.get("TP_PLAN").toString()));
            Assert.assertNotNull(patientMaintenancePage.getCardIDInTPEScreen());
            Assert.assertTrue(patientMaintenancePage.getTPCategoryInTPEScreen().contains("Workers Comp Plan"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());

            patientMaintenancePage.clickOnWorkersCompensationTab();
            String employer = "WALMART";
            Assert.assertTrue(patientMaintenancePage.getEmployer().equalsIgnoreCase(employer));
            Assert.assertTrue(patientMaintenancePage.getAddressLineText().equalsIgnoreCase(inputData.get("ADDRESS").toString()));
            Assert.assertTrue(patientMaintenancePage.getCityText().equalsIgnoreCase(inputData.get("CITY").toString()));
            Assert.assertNotNull(patientMaintenancePage.getZipText());
            Assert.assertNotNull(patientMaintenancePage.getStateText());
            Assert.assertNotNull(patientMaintenancePage.getInjuryDate());
            Assert.assertTrue(patientMaintenancePage.getContact().equalsIgnoreCase(employer));
            Assert.assertNotNull(patientMaintenancePage.getWorkPhone());

            // Remove all non-numeric characters from both values before comparison
            String actualPhone = patientMaintenancePage.getWorkPhone().replaceAll("[^0-9]", "");
            String expectedPhone = inputData.get("PRIMARY_NUMBER").toString().replaceAll("[^0-9]", "");
            Assert.assertEquals(actualPhone, expectedPhone,
                    "Work phone mismatch. Expected: " + inputData.get("PRIMARY_NUMBER") + ", Actual: " + patientMaintenancePage.getWorkPhone());

            String carrier = patientMaintenancePage.getCarrierFromWCP();
            String refer = patientMaintenancePage.getReferFromWCP();
            String other = patientMaintenancePage.getOtherFromWCP();
            Assert.assertTrue(carrier.isBlank() && refer.isBlank() && other.isBlank(),
                    "Carrier, Refer and Other fields should be blank. Found - Carrier: '" + carrier + "', Refer: '" + refer + "', Other : '" + other + "'");
            Reporter.log("ASSERT PASSED. Able to verify Workers compensation Data");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to update patient's Worker Compensation TP plan without entering Refer Input: " + e.getMessage());
            Assert.fail(e.toString());
        }
    }

    public void verifyDrugHasInsulinRestriction(String ndc, int storeId) {
        try {
            String normalizedInputNdc = ndc == null ? "" : ndc.replaceAll("\\D", "");
            if (normalizedInputNdc.isEmpty()) {
                Assert.fail("Input NDC is blank/invalid");
            }
            String query =
                    "SELECT FIRST 1 pi.ndc_nbr " +
                            "FROM pharmacy_offering:pharmacy_item pi " +
                            "JOIN pharmacy_offering:product_gpi_xref x " +
                            "  ON x.product_mds_fam_id = pi.product_mds_fam_id " +
                            "JOIN pharmacy_offering:genc_prod_restrict r " +
                            "  ON r.gpi_code = x.gpi_code " +
                            "WHERE r.restrict_type_code = 32757 " +
                            "  AND r.restriction_value = 'Y' " +
                            "  AND REPLACE(REPLACE(REPLACE(pi.ndc_nbr, '-', ''), ' ', ''), '.', '') = '" + normalizedInputNdc + "'";
            List<Map<String, Object>> resultList =
                    automationManager.getConnexusDB(storeId).executeQueryForList(query);
            if (resultList == null || resultList.isEmpty()) {
                Assert.fail("Drug prerequisite not met: NDC '" + normalizedInputNdc + "' is not restricted (restrict_type_code=32757, restriction_value='Y').");
            }
            Reporter.log("NDC " + normalizedInputNdc + " meets drug prerequisite (restrict_type_code=32757, restriction_value='Y')");
        } catch (Exception e) {
            throw new RuntimeException("Failed to verify drug prerequisite (restrict_type_code=32757)", e);
        }
    }

    public void enterInsulinRxDataAndMaxDailyDose(Map<String, String> inputData, Integer patientId) {

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            handleInputBasicData(inputData, patientId);
            inputPage.clickAccept();
            inputPage.clickMaxDoseButtonOk();
            if(inputPage.isMaxDoseBoxEnabled()){
                inputPage.enterMaxDose("1");
            }
            inputPage.clickMaxDoseButtonOk();
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterDaysSupply(inputData.get("DAYS"));
            inputPage.clickAccept();
            if (inputPage.isCnxPopUpMessageDisplayed()) {
                inputPage.clickOkOnCnxPopUpMessage();
            }
            inputPage.clickYesOnValidateRxPopUp();
        } catch (Throwable e) {
            log.error(UNEXPECTED_EXCEPTION, e);
            Assert.fail("Failed to enter Rx insulin data in input page and validating the Administration popup: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public Integer getLatestRxNbrForPatient(Integer patientId) {
        int effectiveStoreId = this.storeId > 0 ? this.storeId : connexusAppUtils.getStoreId();
        List<Integer> rxNbrList = informixWrapper.getMultiRxNbrFromPatientId(patientId, effectiveStoreId);
        if (rxNbrList == null || rxNbrList.isEmpty()) {
            throw new RuntimeException("No rx_nbr found for patientId: " + patientId + ". The prescription might not have been created successfully.");
        }
        return rxNbrList.get(rxNbrList.size() - 1);
    }

    public void perform4PointWithLASAValidation(String rxNbr, Map<String, String> inputData) {
        try {
            String drugDesc = inputData.get("DRUG_DESC");
            if (drugDesc == null || drugDesc.isEmpty()) {
                drugDesc = inputData.get("DRUG_NAME");
            }
            String drugStrength = inputData.get("DRUG_STRENGTH");
            if (drugStrength == null || drugStrength.isEmpty()) {
                drugStrength = "100 UNIT/ML";
            }
            rxSearch.launchOrderSearchScreen();
            rxSearch.performSearch(rxNbr);
            rxSearch.openFirstPatientRecord();
            automationManager.performSleep(3);
            fourPoint.handleLASAValidation(drugDesc, drugStrength);
            fourPoint.complete4PointVerification();
        } catch (Throwable e) {
            Assert.fail("Failed during 4 Point + LASA validation flow for rxNbr=" + rxNbr + ": " + e.getMessage(), e);
        }
    }

    @Override
    public void performDropOffForRXWithRefills(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(10);
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            automationManager.performSleep(2);
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            dropOffPage.clickYes();
            if (fourPoint.isEarlyRefillReasonPopupDisplayed()) {
                fourPoint.selectEarlyRefillReson();
                fourPoint.clickOkInEarlyRefillPopUp();
            }
            automationManager.performSleep(4);
            dropOffPage.clickOkButton();
            automationManager.performSleep(5);
            dropOffPage.selectPriority("Critical");
            dropOffPage.clickBtnAccept();
            dropOffPage.checkAndClickDropOffStation();
        } catch (Throwable e) {
            Assert.fail("Failed to enter Rx insulin data in input page and validating the Administration popup: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void verifyNoInsulinAdministrationPopup() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(3);
            String popUpText = this.dropOffPage.getPopUpTextIfDisplayed();
            if (popUpText != null && !popUpText.isEmpty()) {
                if (popUpText.contains("Insulin") && popUpText.contains("Medicare")) {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                            this.dropOffPage.takeScreenShot(currentStepMethodName).getValue());
                    this.dropOffPage.clickOkButton();
                    Assert.fail("Insulin Administration pop-up appeared " +
                            "This should NOT happen for patient < 65 years old. Pop-up text: " + popUpText);
                } else {
                    this.dropOffPage.clickOkButton();
                }
            } else {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                        this.dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to verify Insulin Administration pop-up: " + e.getMessage(), e);
        }
    }

    /** Generic DB value verification with consistent error handling and logging. */
    private void verifyDBValue(List<Map<String, Object>> resultList, String columnName, String dbColumnKey,
                               String expectedValue, String assertionMessage) {
        Reporter.log("Verifying DB Value - Column: " + columnName + ", Expected: " + expectedValue);

        if (resultList == null || resultList.isEmpty()) {
            Assert.fail("No DB rows found for column name: " + columnName + " for the expected column value: " + expectedValue);
        }

        Map<String, Object> result = resultList.get(0);
        Object rawValue = result.get(dbColumnKey);
        if (rawValue == null) {
            Assert.fail("DB column '" + dbColumnKey + "' is missing/null in result row: " + result);
        }
        String actualValue = String.valueOf(rawValue).trim();
        Reporter.log("Actual: " + actualValue + " | Expected: " + expectedValue.trim());

        Assert.assertTrue(actualValue.equalsIgnoreCase(expectedValue.trim()),
                "Pass: " + assertionMessage + " match with the expected value");
    }

    /** DB query types for workers compensation validation. */
    public enum WorkersCompDBQueryType {
        EMPLOYER_COMPANY("Employer Company", "phm_co_name"),
        EMPLOYER_ADDRESS("Employer Address", null),
        WORKERS_COMPENSATION("Workers Compensation Details", null),
        EMPLOYER_CONTACT("Workers Contact Details", null),
        WORKER_COMMUNICATION("Workers Communication Details", null),
        WORKER_CARRIER("Workers Carrier Details", null);

        private final String description;
        private final String defaultColumn;

        WorkersCompDBQueryType(String description, String defaultColumn) {
            this.description = description;
            this.defaultColumn = defaultColumn;
        }

        public String getDescription() {
            return description;
        }

        public String getDefaultColumn() {
            return defaultColumn;
        }
    }

    /** Generic DB validation for workers compensation queries. Consolidates 6 duplicate methods. */
    private void verifyWorkersCompDBValue(WorkersCompDBQueryType queryType, String columnName, String expectedValue) {
        String effectiveColumn = columnName != null ? columnName : queryType.getDefaultColumn();
        if (effectiveColumn == null || effectiveColumn.trim().isEmpty()) {
            Assert.fail("Column name is required for DB query type: " + queryType +
                    " (no default column configured).");
        }

        String logMessage = "=== Verifying " + queryType.getDescription() + " in DB" +
                (columnName != null ? " - Column: " + columnName : "");
        Reporter.log(logMessage);

        List<Map<String, Object>> resultList = executeWorkersCompQuery(queryType, effectiveColumn, expectedValue);
        verifyDBValue(resultList, effectiveColumn, effectiveColumn, expectedValue, queryType.getDescription() + " in DB");
    }

    /** Executes DB query based on query type. */
    private List<Map<String, Object>> executeWorkersCompQuery(WorkersCompDBQueryType queryType, String columnName, String value) {
        switch (queryType) {
            case EMPLOYER_COMPANY:
                return informixWrapper.getEmployerDetailsByCompanyName(value);
            case EMPLOYER_ADDRESS:
                return informixWrapper.getEmployerDetailsByAddress(columnName, value);
            case WORKERS_COMPENSATION:
                return informixWrapper.getEmployerCompensationDetails(columnName, value);
            case EMPLOYER_CONTACT:
                return informixWrapper.getEmployerContactDetail(columnName, value);
            case WORKER_COMMUNICATION:
                return informixWrapper.getEmployerPhoneDetails(columnName, value);
            case WORKER_CARRIER:
                return informixWrapper.getWorkerCarrierDetails(columnName, value);
            default:
                throw new IllegalArgumentException("Unknown query type: " + queryType);
        }
    }

    // Public wrapper methods for backward compatibility
    public void verifyEmployerCompanyInDB(String expectedName) {
        verifyWorkersCompDBValue(WorkersCompDBQueryType.EMPLOYER_COMPANY, null, expectedName);
    }

    public void verifyEmployerAddressInDB(String columnName, String expectedColumnValue) {
        verifyWorkersCompDBValue(WorkersCompDBQueryType.EMPLOYER_ADDRESS, columnName, expectedColumnValue);
    }

    public void verifyWorkersCompensationInDB(String columnName, String expectedColumnValue) {
        verifyWorkersCompDBValue(WorkersCompDBQueryType.WORKERS_COMPENSATION, columnName, expectedColumnValue);
    }

    public void verifyEmployerContactDetailsInDB(String columnName, String expectedColumnValue) {
        verifyWorkersCompDBValue(WorkersCompDBQueryType.EMPLOYER_CONTACT, columnName, expectedColumnValue);
    }

    public void verifyWorkerCommunicationDetailsInDB(String columnName, String expectedColumnValue) {
        verifyWorkersCompDBValue(WorkersCompDBQueryType.WORKER_COMMUNICATION, columnName, expectedColumnValue);
    }

    public void verifyWorkerCarrierDetailsInDB(String columnName, String expectedColumnValue) {
        verifyWorkersCompDBValue(WorkersCompDBQueryType.WORKER_CARRIER, columnName, expectedColumnValue);
    }

    public Map<String, Object> initializeAndSetupWorkersCompensationTestData(Map<String, String> inputData,
                                                                             int storeId,
                                                                             int patientId) {
        Reporter.log("=== Initializing Workers Compensation test data setup");
        Map<String, Object> objectInputdata = new HashMap<>(inputData);

        try {
            // Generate random test data
            Reporter.log("Step 1: Generating random test data");
            String cardId = bomUtils.getRandId(7);
            String yesterdayDate = LocalDate.now().minusDays(1).format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
            String address = StringUtils.addressGenerator();
            String address2 = StringUtils.addressGenerator();
            String employer = BomUtils.generateRandomName();
            String phone1 = StringUtils.phoneNumberGenerator();
            String contact = StringUtils.generateRandomFirstName();
            String carrier = BomUtils.generateRandomName();
            String refer = StringUtils.generateRandomNumber(3);
            String other = BomUtils.generateRandomName();

            Reporter.log("Generated Data - Card ID: " + cardId + ", Employer: " + employer +
                    ", Phone: " + phone1 + ", Contact: " + contact);

            // Update input data map with generated values
            Reporter.log("Step 2: Updating input data with generated values");
            objectInputdata.put("ADDRESS", address);
            objectInputdata.put("ADDRESS2", address2);
            objectInputdata.put("EMPLOYER", employer);
            objectInputdata.put("CARDID", cardId);
            objectInputdata.put("INJURY DATE", yesterdayDate);
            objectInputdata.put("ZIP_CODE", "72712");
            objectInputdata.put("CITY", "BENTONVILLE");
            objectInputdata.put("STATE", "AR");
            objectInputdata.put("CONTACT", contact);
            objectInputdata.put("PHONE", phone1);
            objectInputdata.put("CARRIER", carrier);
            objectInputdata.put("REFER", refer);
            objectInputdata.put("OTHER", other);

            Reporter.log("Step 3: Verifying and saving patient profile in Workers Compensation");
            verifySavePatientProfileInWorkersCompensation(objectInputdata, patientId);

            Reporter.log("=== Workers Compensation test data initialization completed successfully");
            return objectInputdata;

        } catch (Exception e) {
            Reporter.log("ERROR: Failed to initialize Workers Compensation test data: " + e.getMessage());
            throw new RuntimeException("Workers Compensation test data setup failed", e);
        }
    }

    public String[] getInfoOnPatientFromDb(Integer patientId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        Map<String, Object> patientInfo = informixWrapper.getPatientName(patientId, storeId);
        String lastName = Objects.toString(patientInfo.get(DB_COL_LAST_NAME), null);
        String firstName = Objects.toString(patientInfo.get(DB_COL_FIRST_NAME), null);
        Object birthDateObj = patientInfo.get("birth_date");
        if (lastName == null || firstName == null || birthDateObj == null) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Patient information not found for patientId: " + patientId);
        }
        String patientDob = LocalDate.parse(birthDateObj.toString().trim()).format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        return new String[]{lastName.trim(), firstName.trim(), patientDob};
    }

    public void openPatientMaintenancePage(Integer patientId) {
        String[] patientInfo = getInfoOnPatientFromDb(patientId);
        patientMaintenancePage.launchPatientSearchScreenAndOpenFirstRecord(patientInfo[0], patientInfo[1], patientInfo[2]);
    }

    public String generateRandomCard(){
        return bomUtils.getRandId(7);
    }

    public void setupThirdPartyEditPage(int patientId) {
        openPatientMaintenancePage(patientId);
        Assert.assertTrue(patientMaintenancePage.isElementDisplayed(patientMaintenancePage.btnTPOnThirdPartyInformation, 5),
                "TP button not found on Patient Maintenance page for patientId: " + patientId);
        patientMaintenancePage.clickOnTPInfoBtn();
        patientMaintenancePage.isElementDisplayed(patientMaintenancePage.btnEditTP, 5);
    }

    public List<Map<String, String>> getPlanCardIdTestData() {
        return List.of(
                Map.of("TP_PLAN", "COMM",   "TP_PLAN_POSITION", "9",  "CARD_ID", generateRandomCard()),
                Map.of("TP_PLAN", "COUPON", "TP_PLAN_POSITION", "10",  "CARD_ID", generateRandomCard()),
                Map.of("TP_PLAN", "GOVT",   "TP_PLAN_POSITION", "14", "CARD_ID", generateRandomCard()));
    }

    public List<Map<String, String>> getCarrierTestData() {
        return List.of(
                Map.ofEntries(
                        Map.entry("TP_CARRIER", "QA"),
                        Map.entry("TP_PLAN", "COMM"), Map.entry("TP_PLAN_POSITION", "9"),
                        Map.entry("CARD_ID", generateRandomCard()),
                        Map.entry("RELATION_POS", "1"), Map.entry("RELATION_CODE", "3201"),
                        Map.entry("MEDICAID_ID", "1234567890"),
                        Map.entry("STATE_POS", "4"), Map.entry("STATE", "AR"),
                        Map.entry("CATEGORY_POS", "1"), Map.entry("CATEGORY", "Commercial"),
                        Map.entry("GROUP", "TEST"), Map.entry("GROUP_DB", "62"),
                        Map.entry("DEPENDENT", "A0"),
                        Map.entry("INS_DOB", "01011981"),
                        Map.entry("ELIG_OVERRIDE_POS", "3"), Map.entry("ELIG_OVERRIDE_VALUE", "4602"),
                        Map.entry("PLACE_OF_SERVICE_POS", "2"), Map.entry("PLACE_OF_SERVICE_VALUE", "1003")),
                Map.ofEntries(
                        Map.entry("TP_CARRIER", "QA5"),
                        Map.entry("TP_PLAN", "TESTING"), Map.entry("TP_PLAN_POSITION", "2"),
                        Map.entry("CARD_ID", generateRandomCard()),
                        Map.entry("RELATION_POS", "1"), Map.entry("RELATION_CODE", "3201"),
                        Map.entry("MEDICAID_ID", "987654123"),
                        Map.entry("STATE_POS", "4"), Map.entry("STATE", "CA"),
                        Map.entry("CATEGORY_POS", "1"), Map.entry("CATEGORY", "Commercial"),
                        Map.entry("GROUP", "GP149"), Map.entry("GROUP_DB", "4"),
                        Map.entry("DEPENDENT", "A0"),
                        Map.entry("INS_DOB", "05051991"),
                        Map.entry("ELIG_OVERRIDE_POS", "4"), Map.entry("ELIG_OVERRIDE_VALUE", "4603"),
                        Map.entry("PLACE_OF_SERVICE_POS", "3"), Map.entry("PLACE_OF_SERVICE_VALUE", "1004")));
    }

    public void performPlanCardEdit(Map<String, String> data) {
        patientMaintenancePage.clickbtnEditTP();
        patientMaintenancePage.selectPlanOnTPEdit(data.get("TP_PLAN"), Integer.parseInt(data.get("TP_PLAN_POSITION")));
        patientMaintenancePage.sendTextToCardIdField(data.get("CARD_ID"));
        patientMaintenancePage.clickCheckboxSameAsPatient();
        patientMaintenancePage.clickbtnAcceptOnThirdPartyEdit();
        automationManager.performSleep(2);
    }

    public void performCarrierEdit(Map<String, String> data) {
        patientMaintenancePage.clickbtnEditTP();
        patientMaintenancePage.sendTextToCarrierBinFieldOnTP(data.get("TP_CARRIER"));
        patientMaintenancePage.clickSearch3DotsOnTPEdit();
        patientMaintenancePage.selectPlanOnTPEdit(data.get("TP_PLAN"), Integer.parseInt(data.get("TP_PLAN_POSITION")));
        patientMaintenancePage.sendTextToCardIdField(data.get("CARD_ID"));
        patientMaintenancePage.selectRelationOnTPEdit(Integer.parseInt(data.get("RELATION_POS")));
        patientMaintenancePage.sendTextToMedicaidIDOnTPEdit(data.get("MEDICAID_ID"));
        patientMaintenancePage.selectHomeStateOnTPEdit(Integer.parseInt(data.get("STATE_POS")));
        patientMaintenancePage.selectCategoryOnTPEdit(Integer.parseInt(data.get("CATEGORY_POS")));
        patientMaintenancePage.sendTextToGroupOnTPEdit(data.get("GROUP"));
        patientMaintenancePage.sendTextToDependentOnTPEdit(data.get("DEPENDENT"));
        patientMaintenancePage.sendTextToInsDOBOnTPEdit(data.get("INS_DOB"));
        patientMaintenancePage.selectEligibilityOverrideOnTPEdit(Integer.parseInt(data.get("ELIG_OVERRIDE_POS")));
        patientMaintenancePage.selectPlaceOfServiceOnTPEdit(Integer.parseInt(data.get("PLACE_OF_SERVICE_POS")));
        patientMaintenancePage.clickbtnAcceptOnThirdPartyEdit();
        automationManager.performSleep(3);
    }

    public void validateTPPlanAndCardIdInDB(Map<String, String> data, int storeId, int patientId) {
        try {
            String tpPlan = data.get("TP_PLAN");
            String cardId = data.get("CARD_ID");
            if (tpPlan == null || tpPlan.isEmpty()) {
                Assert.fail("Input value is blank/invalid");
            }
            List<Map<String, Object>> resultList = informixWrapper.queryTPEditPlanCardId(patientId, storeId);
            if (resultList != null && !resultList.isEmpty()) {
                for (int i = 0; i < resultList.size(); i++) {
                    Reporter.log("fetched row from DB : [" + i + "]: " + resultList.get(i));
                }
            }
            if (resultList == null || resultList.isEmpty()) {
                Assert.fail("No DB rows found for patientId: " + patientId);
            }
            boolean planAndCardFound = resultList.stream().anyMatch(row ->
                    tpPlan.equals(String.valueOf(row.get("ins_plan_ref_code")).trim()) &&
                            cardId.equals(String.valueOf(row.get("cardholder_id")).trim())
            );
            if (!planAndCardFound) {
                for (Map<String, Object> row : resultList) {
                    Reporter.log("MISMATCH: plan actual=" + String.valueOf(row.get("ins_plan_ref_code")).trim() + " expected=" + tpPlan
                            + " | cardId actual=" + String.valueOf(row.get("cardholder_id")).trim() + " expected=" + cardId);
                }
            }
            Assert.assertTrue(planAndCardFound,
                    "No DB row found with plan " + tpPlan + " and card ID " + cardId + " for patient " + patientId);
        } catch (Throwable e) {
            String currentStepMethodName = StackUtils.getCurrentMethodName();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to validate fields on DB validation: " + e.getMessage());
            Assert.fail(e.toString());
        }
    }

    public void validateTPCarrierFieldsInDB(Map<String, String> data, int storeId, int patientId) {
        try {
            List<Map<String, Object>> resultList = informixWrapper.queryTPEditCarrierFields(patientId, storeId);
            if (resultList != null && !resultList.isEmpty()) {
                for (int i = 0; i < resultList.size(); i++) {
                    Reporter.log("fetched row from DB : [" + i + "]: " + resultList.get(i));
                }
            }
            if (resultList == null || resultList.isEmpty()) {
                Assert.fail("No DB rows found for patientId: " + patientId);
            }
            String expectedPlan = data.get("TP_PLAN");
            String expectedCard = data.get("CARD_ID");
            String expectedRelation = data.get("RELATION_CODE");
            String expectedDependent = data.get("DEPENDENT");
            String expectedGroup = data.get("GROUP_DB");
            boolean allFieldsFound = resultList.stream().anyMatch(row ->
                    row.get("wcc_carrier") != null &&
                            expectedPlan.equals(String.valueOf(row.get("ins_plan_ref_code")).trim()) &&
                            expectedCard.equals(String.valueOf(row.get("cardholder_id")).trim()) &&
                            expectedRelation.equals(String.valueOf(row.get("relationship_code")).trim()) &&
                            expectedDependent.equals(String.valueOf(row.get("dependent_code")).trim()) &&
                            expectedGroup.equals(String.valueOf(row.get("bill_grp_seq_nbr")).trim())
            );
            if (!allFieldsFound) {
                for (Map<String, Object> row : resultList) {
                    Reporter.log("MISMATCH: carrier actual=" + row.get("wcc_carrier") + " (expected: not null)"
                            + " | plan actual=" + String.valueOf(row.get("ins_plan_ref_code")).trim() + " expected=" + expectedPlan
                            + " | cardId actual=" + String.valueOf(row.get("cardholder_id")).trim() + " expected=" + expectedCard
                            + " | relation actual=" + String.valueOf(row.get("relationship_code")).trim() + " expected=" + expectedRelation
                            + " | dependent actual=" + String.valueOf(row.get("dependent_code")).trim() + " expected=" + expectedDependent
                            + " | group actual=" + String.valueOf(row.get("bill_grp_seq_nbr")).trim() + " expected=" + expectedGroup);
                }
            }
            Assert.assertTrue(allFieldsFound,
                    "No single DB row matches all expected fields for patient " + patientId);
        } catch (Throwable e) {
            String currentStepMethodName = StackUtils.getCurrentMethodName();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to verify fields in DB validation: " + e.getMessage());
            Assert.fail(e.toString());
        }
    }

}