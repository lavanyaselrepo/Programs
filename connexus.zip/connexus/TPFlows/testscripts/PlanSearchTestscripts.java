package connexus.TPFlows.testscripts;

import connexus.ConnexusTestScripts;
import hwqe.baseframework.models.pageobjectmodels.connexus.PlanSearch;

import java.util.ArrayList;
import java.util.List;

/**
 * Plan Search test scripts for validating plan search functionality.
 * Extends ConnexusTestScripts for login and common utilities.
 */
public class PlanSearchTestscripts extends ConnexusTestScripts {

    private PlanSearch planSearch = new PlanSearch();

    // Launches the Plan Search screen.
    public void launchPlanSearch() {
        planSearch.launchPlanSearch();
    }

    // Searches plans by Name field and returns whether results are displayed.
    public void searchPlanByName(String searchText) {
        planSearch.performPlanSearch(searchText, "name");
    }

    // Validates Name field inputs by running searches and returning failing inputs.
    public void validatePlanSearchNameFieldInputs() {
        validatePlanSearchFieldInputs("plan", getPlanFieldTestInputs());
    }

    // Validates Carrier field inputs by running searches and returning failing inputs.
    public void validatePlanSearchCarrierFieldInputs() {
        validatePlanSearchFieldInputs("carrier", getCarrierFieldTestInputs());
    }

    // Validates BIN field inputs by running searches and returning failing inputs.
    public void validatePlanSearchBinFieldInputs() {
        validatePlanSearchFieldInputs("bin", getBinFieldTestInputs());
    }

    // Validates PCN field inputs by running searches and returning failing inputs.
    public void validatePlanSearchPcnFieldInputs() {
        validatePlanSearchFieldInputs("pcn", getPcnFieldTestInputs());
    }

    // Runs Plan Search for each input for the given field type and collects failures.
    private void validatePlanSearchFieldInputs(String type, List<String> inputs) {
        for (String input : inputs) {
            planSearch.performPlanSearch(input, type);
        }
    }

    // Returns the Plan Search title text displayed on the UI.
    public String getPlanSearchTitleText() {
        return planSearch.getPlanSearchTitleText();
    }

    // Returns the text of the Search Now button.
    public String getSearchButtonText() {
        return planSearch.getSearchNowButtonText();
    }

    // Returns the text of the New Search button.
    public String getClearButtonText() {
        return planSearch.getClearButtonText();
    }

    // Returns whether the Show Ineligible toggle/option is visible.
    public boolean isShowIneligibleVisible() {
        return planSearch.isShowIneligibleVisible();
    }

    // Returns the Plan section header/label text.
    public String getPlanSectionText() {
        return planSearch.getPlanSectionText();
    }

    // Returns the Name label text.
    public String getNameLabelText() {
        return planSearch.getNameLabelText();
    }

    // Returns the Carrier label text.
    public String getCarrierLabelText() {
        return planSearch.getCarrierLabelText();
    }

    // Returns the BIN label text.
    public String getBinLabelText() {
        return planSearch.getBinLabelText();
    }

    // Returns the PCN label text.
    public String getPcnLabelText() {
        return planSearch.getPcnLabelText();
    }

    // Builds the input set used for Name field validation.
    private List<String> getPlanFieldTestInputs() {
        List<String> inputs = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            inputs.add(repeatChar('A', i));
        }

        inputs.add("123");
        inputs.add("1234567890");

        inputs.add("@");
        inputs.add("#%$");
        inputs.add("A@1");
        return inputs;
    }

    // Builds the input set used for Carrier field validation.
    private List<String> getCarrierFieldTestInputs() {
        List<String> inputs = new ArrayList<>();
        for (int i = 1; i <= 3; i++) {
            inputs.add(repeatChar('C', i));
        }
        inputs.add("101");
        inputs.add("@1");
        return inputs;
    }

    // Builds the input set used for BIN field validation.
    private List<String> getBinFieldTestInputs() {
        List<String> inputs = new ArrayList<>();
        for (int i = 1; i <= 8; i++) {
            inputs.add(repeatChar('1', i));
        }
        inputs.add("BIN1234");
        inputs.add("1BIN");
        inputs.add("@1");
        return inputs;
    }

    // Builds the input set used for PCN field validation.
    private List<String> getPcnFieldTestInputs() {
        List<String> inputs = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            inputs.add(repeatChar('P', i));
        }
        inputs.add("PCN1");
        inputs.add("1PCN");
        inputs.add("@1");
        return inputs;
    }

    // Returns a string made of the given character repeated count times.
    private String repeatChar(char c, int count) {
        StringBuilder sb = new StringBuilder(count);
        for (int i = 0; i < count; i++) {
            sb.append(c);
        }
        return sb.toString();
    }

}