package connexus.TPFlows;

import bom.resources.BomUtils;
import bom.resources.InformixWrapper;
import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import connexus.OrderCreation.PayloadResource;
import connexus.e2e.testcases.E2E_TestCases;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuscontext.SearchType;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.models.datamodels.connexus.ContactModel;
import hwqe.baseframework.models.datamodels.connexus.PatientIdentityModel;
import hwqe.baseframework.models.datamodels.connexus.PatientMedicalConditionModel;
import hwqe.baseframework.models.datamodels.connexus.PatientProfileModel;
import hwqe.baseframework.models.datamodels.connexus.ThirdPartyModel;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.joda.time.DateTime;
import org.testng.Assert;

import java.util.Map;
import java.util.Objects;

/** TP test scripts — patient creation, claims, split billing, and resolution. */
public class TpTestscripts extends ConnexusTestScripts {

    // TP-specific page objects not in base class
    ResolutionTPRejPage resolutionTPRejPage;
    PayloadResource payloadResource = new PayloadResource();
    public InformixWrapper informixWrapper;

    /** Shared utility for generating random IDs (cardholder IDs, etc.). */
    protected final BomUtils bomUtils = new BomUtils();

    private static final int CARD_ID_LENGTH = 7;

    // TP PLAN INPUT VALUE OBJECT + CORE WORKFLOW HELPERS
    // TpPlanInput = single value-object for all TP flows (keeps workflow methods branch-free).
    // addPlans(...) = THE building block; all public TP workflows call it (single UI logic source).

    /** TP plan descriptor (carrierBin, plan, cardId, movePayerDown). Use static factories to extract from inputData. */
    public record TpPlanInput(String carrierBin, String plan, String cardId, boolean movePayerDown) {

        // Input-data key prefixes — single source of truth, used by the static factories below.
        private static final String CARRIER_BIN_PREFIX = "TP_CARRIER_BIN_";
        private static final String PLAN_PREFIX        = "TP_PLAN_";
        private static final String CARD_ID_PREFIX     = "TP_CARD_ID_";
        private static final String NAME_PREFIX        = "TP_NAME_";

        /** Convenience overload — defaults {@code movePayerDown} to {@code false}. */
        public TpPlanInput(String carrierBin, String plan, String cardId) {
            this(carrierBin, plan, cardId, false);
        }

        /** True iff this slot has both a carrier and a plan — used to skip empty optional plans. */
        public boolean isPresent() {
            return carrierBin != null && !carrierBin.isBlank()
                    && plan != null && !plan.isBlank();
        }

        /** Returns a copy with {@code movePayerDown=true} — builder-style toggle. */
        public TpPlanInput withMovePayerDown() {
            return new TpPlanInput(carrierBin, plan, cardId, true);
        }

        /** Reads {@code TP_CARRIER_BIN_<idx>} / {@code TP_PLAN_<idx>}; generates a random card id. */
        public static TpPlanInput randomCard(Map<String, ?> inputData, int idx, BomUtils bomUtils) {
            return new TpPlanInput(
                    mapStr(inputData, CARRIER_BIN_PREFIX + idx),
                    mapStr(inputData, PLAN_PREFIX + idx),
                    bomUtils.getRandId(CARD_ID_LENGTH));
        }

        /** Reads carrier/plan/card-id from {@code TP_CARRIER_BIN_<idx>} / {@code TP_PLAN_<idx>} / {@code TP_CARD_ID_<idx>}. */
        public static TpPlanInput fromInputData(Map<String, ?> inputData, int idx) {
            return new TpPlanInput(
                    mapStr(inputData, CARRIER_BIN_PREFIX + idx),
                    mapStr(inputData, PLAN_PREFIX + idx),
                    mapStr(inputData, CARD_ID_PREFIX + idx));
        }

        /** Reads plan from {@code TP_NAME_<idx>} (full display name) instead of {@code TP_PLAN_<idx>}. Needed for HWPHME2E_3265. */
        public static TpPlanInput withName(Map<String, ?> inputData, int idx) {
            return new TpPlanInput(
                    mapStr(inputData, CARRIER_BIN_PREFIX + idx),
                    mapStr(inputData, NAME_PREFIX + idx),
                    mapStr(inputData, CARD_ID_PREFIX + idx));
        }

        private static String mapStr(Map<String, ?> map, String key) {
            Object v = map.get(key);
            return v == null ? "" : v.toString().trim();
        }
    }

    /** Initialises the page object and navigates to Patient Maintenance for the given patient. */
    protected void openMaintenance(Integer patientId) {
        patientMaintenancePage = new PatientMaintenancePage();
        openPatientMaintenance(patientId);
    }

    /** Adds 1..N plans to open Patient Maintenance. Skips absent plans. Caller opens/exits PMS. */
    protected void addPlans(TpPlanInput... plans) {
        for (TpPlanInput plan : plans) {
            if (!plan.isPresent()) {
                continue;
            }
            if (plan.movePayerDown()) {
                patientMaintenancePage.performAddAdditionalTPPlanAndMovePayerDown(
                        plan.carrierBin(), plan.plan(), plan.cardId());
            } else {
                patientMaintenancePage.performAddAdditionalTPPlanOps(
                        plan.carrierBin(), plan.plan(), plan.cardId());
            }
        }
    }

    /** Click Accept → Yes (bill order change) → Accept on Third Party Edit. Stops short of {@code clickExit()}. */
    protected void acceptThirdPartyEdit() {
        patientMaintenancePage.clickAcceptTPInfo();
        patientMaintenancePage.clickYesBillOrderChange();
        patientMaintenancePage.clickonAcceptOnThirdPartyEditBtn();
    }

    /** Full close-out: accept dance + exit Patient Maintenance. */
    protected void finalizeThirdPartyEdit() {
        acceptThirdPartyEdit();
        patientMaintenancePage.clickExit();
    }

    public void initSharedDependencies() {
        if (automationManager == null) {
            automationManager = AutomationManager.getInstance();
        }
        if (connexusAppUtils == null) {
            connexusAppUtils = new ConnexusAppUtils();
        }
        if (informixWrapper == null) {
            informixWrapper = new InformixWrapper();
        }
    }

    @Override
    public void loginConnexus(LoginAs.userType userType) {
        initSharedDependencies();
        super.loginConnexus(userType);
        resolutionTPRejPage = new ResolutionTPRejPage();
        informixWrapper = new InformixWrapper();
    }

    public void createPatientWithTP(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PatientSearchPage patientSearchPage = new PatientSearchPage();
            PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
            PatientIdentityModel patientIdentityModel = new PatientIdentityModel();
            ThirdPartyModel thirdPartyModel = new ThirdPartyModel();
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();

            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("PAT_DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("PAT_ADDRESS_LINE1"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));

            patient.setPatientAddress(addressModel);

            contactModel.setPatientPhoneNumber1(inputData.get("PHONE_NUMBER1"));
            contactModel.setPatientPhoneNumber2(inputData.get("PHONE_NUMBER2"));
            contactModel.setPatientPhoneNumber3(inputData.get("PHONE_NUMBER3"));
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            contactModel.setPatientAlternateNumber(inputData.get("ALTERNATE_NUMBER"));
            contactModel.setPatientMessagingNumber(inputData.get("MESSAGING_NUMBER"));
            contactModel.setPreferredPhoneNumber(ContactModel.PreferredPhoneNumber.PHONE_NUMBER1);

            patient.setPatientContact(contactModel);
            thirdPartyModel.setCarrierBin(inputData.get("TP_CARRIER_BIN"));
            thirdPartyModel.setPlan(inputData.get("TP_PLAN"));
            thirdPartyModel.setCardId(inputData.get("TP_CARD_ID"));

            patient.setPatientTp(thirdPartyModel);
            patientIdentityModel.setPatientDrivingLicenseNumber(inputData.get("LICENSE_NUMBER"));
            patientIdentityModel.setPatientDrivingLicenseState(inputData.get("STATE"));
            patientIdentityModel.setDrivingLicenseExpiryDate(inputData.get("LICENSE_EXPIRATION_DATE"));

            patient.setPatientIdentityModel(patientIdentityModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);

            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            automationManager.getConnexusWorkFlow().searchAndCreatePatient(true, patient);
            if (!patientSearchPage.verifyPatientSearchScreen()) {
                patientSearchPage.launchPatientSearchScreen();
            }
            patientSearchPage.inputPatientName(patient.getPatientLastName() + "," + patient.getPatientFirstName());
            patientSearchPage.inputPatientDob(patient.getPatientDob());
            patientSearchPage.clickSearchNow();
            automationManager.performSleep(2);
            patientSearchPage.doubleClickOnSearchGridRow(0);
            patientMaintenancePage.selectMedicarePlan(inputData.get("TP_PLAN"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            patientSearchPage.clickClose();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }


    @Override
    public void performDropOff() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Critical);
            automationManager.getConnexusWorkFlow().performDropRx(dropRxModel);
        } catch (Exception e) {
            Reporter.log("Test failed at DropOff queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    @Override
    public void performInput(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxModel.setNdc(inputData.get("DRUG_NAME"));
            rxModel.setPrescribedQty("10");
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().performInput(rxModel);
            } else {
                Reporter.log("RX is not in Input queue");
                Assert.fail();
            }
        } catch (Exception e) {
            Reporter.log("Test failed at Input queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void TP() {

        String[] name = connexusAppUtils.readPatientNameFromFile();
        String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
        if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
            automationManager.performSleep(10);
        }

    }

    public void switchcash(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(20);
            }
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            patientSearchPage.openFirstPatientRecord();
            resolutionPage.clickSwitchToCashButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.selectReasonForSwitchToCash();
            automationManager.performSleep(5);
            modifyDetails.checkAndClickWarning();

        } catch (Throwable e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }

    public void tpRejSwitchToCash() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.performSleep(10);
            }
            patientSearchPage.openFirstPatientRecord();
            resolutionTPRejPage.clickSwitchToCash();
            modifyDetails.selectReasonForSwitchToCash();
            //modifyDetails.clickAccept();
            //automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.selectReasonForSwitchToCash();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(5);
            modifyDetails.checkAndClickWarning();
        } finally {
            Reporter.log("Resolved");
        }
    }

    public void perform4Point(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                automationManager.performSleep(20);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            rxNbr = automationManager.getConnexusWorkFlow().performFourPoint(rxNbr);
        } catch (Exception e) {
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }
    }

    public void Modifyplan(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {

            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            patientSearchPage.openFirstPatientRecord();
            automationManager.performSleep(3);
            modifyDetails.openModifyDetailsScreen();
            automationManager.performSleep(3);
            modifyDetails.switchPaymentPlan("QA REJ5");
            modifyDetails.inputDrugExpDate("09/09/2026");
            modifyDetails.clickAccept();
            modifyDetails.clickOnConnexusPopUp();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickok();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void performDropOffForRXWithRefills(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(10);
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            automationManager.performSleep(2);
            dropOffPage.handleAnnualValidatePatInfoPopUp();
            dropOffPage.clickYes();
            automationManager.performSleep(4);
            dropOffPage.clickOkButton();
            automationManager.performSleep(5);
            dropOffPage.selectPriority("Critical");
            dropOffPage.clickBtnAccept();
            dropOffPage.checkAndClickDropOffStation();
            Reporter.log("Drop-Off completed");
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
        }
    }

    public void performDropOffForARXWithNoRefills() {

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOffPage.clickDropOffQueue();
            dropOffPage.enterPatientName(rxNbr);
            dropOffPage.clickPatientSearch();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickYesInPopUp();
            dropOffPage.clickOkButton();
            dropOffPage.selectPriority("Critical");
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            dropOffPage.clickBtnAccept();
            Reporter.log("Drop-Off completed");
            softAssert.assertAll();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOffPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }

    }

    public void TechNotAbleTosolve(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            patientSearchPage.openFirstPatientRecord();
            automationManager.performSleep(3);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(3);
            patientSearchPage.clickok();
            Reporter.log("Pop up displayed indicates that the technician is not able to solve the issue");
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());


        }
    }

    public void performFilling(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            System.out.println("Rx status" + rxStatus);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
                connexusAppUtils.writeTextToFile("Completed ChkDUR " + rxNbr, "In progress", "E2E_execution_status.txt", 50, DateTime.now());
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                Reporter.log("RX is in CASH queue");
                automationManager.performSleep(15);
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
                Reporter.log("RX is in Resolve queue");
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.FILLING.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeFilling(rxNbr);
            }
            connexusAppUtils.writeTextToFile("Filling Completed " + rxNbr, "In progress", "E2E_execution_status.txt", 60, DateTime.now());
        } catch (Throwable e) {
            connexusAppUtils.writeTextToFile("Filling notCompleted " + rxNbr, "Failed", "E2E_execution_status.txt", 60, DateTime.now());
            //patientSearchPage.closeIfAnyPopUpOpened();
            Reporter.log("Test failed at Filling queue");
            loginConnexus(E2E_TestCases.loginUser_Type);
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    @Override
    public void performVisualVerify() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.VISUAL_VERIFY.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeVisualVerify(rxNbr);
            } else {
                Reporter.log("RX is not in Visual Verify queue");
                Assert.fail("RX is not in Visual Verify queue");
            }
        } catch (Exception e) {
            Reporter.log("Test failed at Visual Verify queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    @Override
    public void performPickUp(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.PICKUP.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("PAT_DOB"), rxNbr);
            } else {
                Reporter.log("RX is not in PickUp queue");
                Assert.fail("RX is not in PickUp queue");
            }
            connexusAppUtils.writeTextToFile("Pickup Completed " + rxNbr, "In progress", "E2E_execution_status.txt", 80, DateTime.now());
        } catch (Throwable e) {
            connexusAppUtils.writeTextToFile("Pickup not Completed " + rxNbr, "Failed", "E2E_execution_status.txt", 80, DateTime.now());
            Reporter.log("Test failed at PickUp queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void offlinevoid() {

        String[] name = connexusAppUtils.readPatientNameFromFile();
        String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);

        if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
            automationManager.getConnexusWorkFlow().completeResolution(name[0] + "," + name[1]);
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            patientSearchPage.offlinevoid();
            patientSearchPage.clickYes();
            patientSearchPage.clickok();
            automationManager.performSleep(10);
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            patientSearchPage.openFirstPatientRecord();
            resolutionTPRejPage.clickSwitchToCash();
            modifyDetails.selectReasonForSwitchToCash();
            automationManager.performSleep(5);
            modifyDetails.checkAndClickWarning();
        }


    }

    @Override
    public void performCounselling() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.COUNSEL.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeCounsel(rxNbr);
            } else {
                Reporter.log("RX is not in Counselling queue");
                Assert.fail();
            }
            connexusAppUtils.writeTextToFile("Counselling Completed " + rxNbr, "In progress", "E2E_execution_status.txt", 90, DateTime.now());
        } catch (Throwable e) {
            connexusAppUtils.writeTextToFile("Counselling Not Completed " + rxNbr, "Failed", "E2E_execution_status.txt", 90, DateTime.now());
            Reporter.log("Test failed at Counselling queue");
            loginConnexus(E2E_TestCases.loginUser_Type);
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    @Override
    public void performPOS() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.POS.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeOfflineSale(rxNbr);
            } else {
                Reporter.log("RX is not in POS queue");
                Assert.fail("RX is not in POS queue");
            }
        } catch (Exception e) {
            Reporter.log("Test failed at POS queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }


    public void performResolution(String rxNbr) {

        String currentStepMethodName = StackUtils.getCurrentMethodName();
        ResolutionPage resolutionPage = new ResolutionPage();
        F6Search search = new F6Search();
        String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
        automationManager.performSleep(5);
        patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(rxNbr);
        patientSearchPage.openFirstPatientRecord();
        automationManager.performSleep(2);
        resolutionPage.clickDownTime();
        Reporter.log("Clicked on DownTime Button");
        automationManager.performSleep(5);
        resolutionPage.enterCoPayAmt("0.0");
        Reporter.log("Entered copay Amount");
        resolutionPage.clickAccept();
        Reporter.log("Resolution " + resolutionPage.takeScreenShot("Resolution").getKey());
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
        automationManager.performSleep(5);
        Reporter.log("Resolution completed");
        automationManager.performSleep(5);

    }

    @Override
    public void performChkDUR() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }
        } catch (Exception e) {
            Reporter.log("Test failed at ChkDUR queue");
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    public void verifyWorkQueue(String workQueue, String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(5);
            String rxStat = orderSearch.getRXStatusForPatient(rxNbr, 0);
            automationManager.performSleep(2);
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            automationManager.performSleep(5);
            if (rxStatus.equalsIgnoreCase(workQueue)) {
                Assert.assertTrue(true, "Workqueue Matched");
            } else {

                Assert.fail("Workqueue not Matched, current work queue is " + rxStatus);
            }
        } catch (Exception e) {
            softAssert.fail(workQueue + " " + "not matched");
            Reporter.log(workQueue + " " + "not matched");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void openResolutionpage() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            ResolutionPage resolutionPage = new ResolutionPage();
            automationManager.performSleep(2);
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            orderSearch.selectRowFromSearch(0);
            orderSearch.openFirstPatientRecord();
            Reporter.log("Opened Resolution Page");
            patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
            patientSearchPage.openFirstPatientRecord();
            automationManager.performSleep(5);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Openedresolution page and displayed the solutions");
            Reporter.log("Resolution " + resolutionPage.takeScreenShot("Resolution").getKey());

        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }


    public void openresolve(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            patientSearchPage.openFirstPatientRecord();
            Reporter.log("Opened Resolution Page");
            //Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(5);
            Reporter.log("Opened resolution page and displayed the solutions");


        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }


    public void performFourPointWithOnHoldStatus(String rxNbr) {
        this.rxNbr = rxNbr;
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            if (fourPoint.isElementDisplayed(fourPoint.rdbNonAcute, 1)) {
                fourPoint.click(fourPoint.rdbNonAcute);
            }
            if (!fourPoint.onHoldButtonSelected()) {
                fourPoint.unCheckOnHold();
            }
            fourPoint.chkName();
            fourPoint.chkPrescribed();
            if (fourPoint.ischkStrength()) {
                fourPoint.chkStrength();
            }
            fourPoint.chkSIG();
            if (fourPoint.isElementDisplayed(fourPoint.chkDEA, 1)) {
                fourPoint.click(fourPoint.chkDEA);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            fourPoint.clickAccept();
            Reporter.log("4 point completed");
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Test failed at 4 Point queue: " + e);
        }
    }

    public void openModifyDetailsFromRxLookUpScreen(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(rxNbr);
            rxLookUp.clickSearch();
            Assert.assertTrue(rxLookUp.isRxLookUpOpened());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.launchModifyDetailScreen();
            Assert.assertTrue(modifyDetails.isModifyDetailsOpened(), "Modify Details screen did not open as expected");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }
    }

    public void changeDAWValue(String rxNbr, Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            patientSearchPage.openFirstPatientRecord();
            automationManager.performSleep(5);
            modifyDetails.openModifyDetailsScreen();
            automationManager.performSleep(6);
            int index = Integer.parseInt(String.valueOf(inputData.get("DAW_CODE")));
            modifyDetails.modifyDAW(Integer.parseInt(String.valueOf(index)));
            automationManager.performSleep(5);
            modifyDetails.clickOKBtn();
            automationManager.performSleep(5);
            modifyDetails.clickAccept();
            modifyDetails.clickOKBtn();
            modifyDetails.clickOKBtn();
            automationManager.performSleep(5);
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());

        }
    }

    public void verifyDAWinModifyScreen(String rxNbr,Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            patientSearchPage.openFirstPatientRecord();
            automationManager.performSleep(3);
            modifyDetails.openModifyDetailsScreen();
            automationManager.performSleep(5);

            String expectedDAW = Objects.toString(inputData.get("DAW_CODE"), "");
            String actualDAW = modifyDetails.getDAW();
            Assert.assertTrue(actualDAW.contains(expectedDAW),
                    "DAW code mismatch. Expected to contain: '" + expectedDAW + "', but got: '" + actualDAW + "'");
            modifyDetails.clickAccept();
            modifyDetails.clickOKBtn();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());

        }
    }

    public void verifyDAWValueInResolution(String rxNbr, Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            patientSearchPage.openFirstPatientRecord();
            automationManager.performSleep(3);
            resolutionPage.verifyDawInResolution(inputData);
            automationManager.performSleep(25);
            resolutionPage.clickSubmit();
            automationManager.performSleep(10);
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }
    }

    // PATIENT MANAGEMENT METHODS

    /** Opens Patient Maintenance for {@code patientId} (retrieves name from DB and searches). */
    public void openPatientMaintenance(Integer patientId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.launchPatientSearchScreen();
            Map<String, Object> name = informixWrapper.getPatientName(patientId, connexusAppUtils.getStoreId());
            String lastName = (String) name.get("last_name");
            String firstName = (String) name.get("first_name");
            if (!patientSearchPage.isPatientSearchWindowDisplayed()){
                Assert.fail("Failed to open the Patient Search Window");
            }
            patientSearchPage.inputPatientName(lastName.trim() + "," + firstName.trim());
            patientSearchPage.clickSearchNow();
            automationManager.performSleep(2);
            patientSearchPage.doubleClickOnSearchGridRow(0);
            if (!patientMaintenancePage.isGeneralInfoTabDisplayed()){
                Assert.fail("General Info tab is not displayed");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Test failed in openPatientMaintenance: " + e.getMessage());
        }
    }

    /** Opens PMS, adds payer, validates M3P eligibility popup against {@code TP_VALIDATION_MESSAGE}, and finalizes. */
    public void addAdditionalPayerAndProcess(Integer patientId, String carrierBin, String plan, Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openMaintenance(patientId);
            addPlans(new TpPlanInput(carrierBin, plan, bomUtils.getRandId(CARD_ID_LENGTH)));

            Assert.assertEquals(patientMaintenancePage.getTextFromTPEligibilityResponseAdditionPopUup(),
                    inputData.get("TP_VALIDATION_MESSAGE"), "M3P pop up message not matching");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.closeM3PPopUp();
            patientMaintenancePage.movePayerDown();
            finalizeThirdPartyEdit();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            throw new RuntimeException(e);
        }
    }

    // TP ERROR VERIFICATION METHODS

    /** Verifies TP error in resolution screen matches {@code ERROR_TEXT}. */
    public void verifyTPErrorInResolution(Integer rxNbr, Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            automationManager.performSleep(15);
            patientSearchPage.launchOrderSearchScreen();
            automationManager.performSleep(5);
            patientSearchPage.performSearch(String.valueOf(rxNbr));
            patientSearchPage.openFirstPatientRecord();
            automationManager.performSleep(10);
            String error = resolutionPage.getTPErrorMessage();
            Assert.assertNotNull(error, "TP error message was null — resolution screen did not load expected error element.");
            Assert.assertEquals(error.trim(), inputData.get("ERROR_TEXT"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(5);
            resolutionPage.clickCancel();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /** Verifies contact prescriber error in resolution matches {@code ERROR_TEXT} (searches by patient name from file). */
    public void verifyContactPrescriberInResolution(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.openSearch();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            orderSearch.selectRowFromSearch(0);
            automationManager.performSleep(9);
            String error = resolutionPage.getResolutionErrorMessage();
            Assert.assertEquals(error, inputData.get("ERROR_TEXT"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(9);
            resolutionPage.clickCancel();
        } catch (Exception e) {
            softAssert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
        }
    }

    /** Verifies TP reject problem description matches {@code ERROR_TEXT}. Resubmits if error ends with "Code". */
    public void verifyTPRejectProblemDescriptionInResolution(Map<String, Object> inputData, String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.openSearch();
            automationManager.performSleep(15);
            orderSearch.performSearch(rxNbr);
            orderSearch.selectRowFromSearch(0);
            String error = resolutionPage.getProblemDescription();
            Assert.assertNotNull(error, "Problem description was null — resolution screen did not load expected element.");
            if (error.endsWith("Code")) {
                resolutionPage.clickSubmit();
                orderSearch.performSearch(rxNbr);
                orderSearch.selectRowFromSearch(0);
                error = resolutionPage.getProblemDescription();
                Assert.assertNotNull(error, "Problem description was null after resubmit.");
            }
            automationManager.performSleep(5);
            Assert.assertEquals(error, inputData.get("ERROR_TEXT"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(5);
            resolutionPage.clickCancel();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }
    }

    /** Verifies TP reject error in resolution matches {@code ERROR_TEXT}. */
    public void verifyTPRejectInResolution(String rxNbr, Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.openSearch();
            automationManager.performSleep(10);
            orderSearch.performSearch(rxNbr);
            orderSearch.clickSearch();
            orderSearch.selectRowFromSearch(0);
            automationManager.performSleep(9);
            String error = resolutionPage.getResolutionTPErrorMessage();
            automationManager.performSleep(3);
            Assert.assertEquals(error, inputData.get("ERROR_TEXT"));
            automationManager.performSleep(3);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(9);
            resolutionPage.clickCancel();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.assertAll();
            softAssert.fail(e.toString());
        }
    }

    // PUBLIC TP WORKFLOW METHODS
    // Each method = one end-to-end PMS flow (Open → action → exit). Plan-add UI logic centralized in addPlans().

    /** Opens PMS, adds plans, exits without accepting. Use for setup — no split-bill or validation. */
    public void addPlansAndExit(Integer patientId, TpPlanInput... plans) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openMaintenance(patientId);
            automationManager.performSleep(2);
            addPlans(plans);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickExit();
        } catch (Exception e) {
            Assert.fail("TP plan(s) not added successfully: " + e.getMessage());
        }
    }

    /** Opens PMS, adds plans 2 & 3, toggles split-bill, finalizes. Configures 3-payer split if plan 3 present. */
    public void splitBillWithPlans(Integer patientId, Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openMaintenance(patientId);
            automationManager.performSleep(2);

            TpPlanInput plan2 = TpPlanInput.randomCard(inputData, 2, bomUtils);
            TpPlanInput plan3 = TpPlanInput.randomCard(inputData, 3, bomUtils);
            addPlans(plan2);
            if (plan3.isPresent()) {
                addPlans(plan3);
                patientMaintenancePage.splitBillWithThreePayer();
            }

            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickOnchkSplitBill();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            finalizeThirdPartyEdit();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            throw new RuntimeException(e);
        }
    }

    /** Opens PMS, adds discount plan, toggles split-bill, asserts popup shown, exits without finalizing. */
    public void createSplitBillDiscountPlan(Map<String, Object> inputData, Integer patientId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openMaintenance(patientId);
            automationManager.performSleep(2);
            addPlans(TpPlanInput.randomCard(inputData, 2, bomUtils));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickOnchkSplitBill();
            Reporter.log("Error pop up is displayed with message \t" + patientMaintenancePage.getDiscountnPopupText());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickExit();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            throw new RuntimeException(e);
        }
    }

    /** Discontinues plan, adds plans 2 & 3, enables split-bill, discontinues plan 2, verifies split-bill disabled with "include not eligible cards". */
    public void verifyPlanIneligible(Integer patientId, Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openMaintenance(patientId);
            patientMaintenancePage.discontinueTpPlan();

            automationManager.performSleep(5);
            addPlans(TpPlanInput.randomCard(inputData, 2, bomUtils));
            automationManager.performSleep(5);
            addPlans(TpPlanInput.randomCard(inputData, 3, bomUtils));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());

            automationManager.performSleep(5);
            patientMaintenancePage.clickOnchkSplitBill();
            patientMaintenancePage.clickAcceptTPInfo();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickYesBillOrderChange();
            automationManager.performSleep(7);
            patientMaintenancePage.discontinueTpPlan();
            patientMaintenancePage.clickbtnTPOnThirdPartyInformation();
            patientMaintenancePage.clickIncludeNotEligibleCards();
            Assert.assertFalse(patientMaintenancePage.isSplitBillEnabled(), "Split bill should be disabled");
            modifyDetails.clickCancel();
            patientMaintenancePage.clickExit();
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            throw new RuntimeException(e);
        }
    }

    /** Verifies M3P as payer of last resort: adds Medicaid plan (payer-down), then TP plan, asserts surfaced plan equals plan 3. */
    public void verifyM3pIsPayerOfLastResort(Integer patientId, Map<String, Object> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openMaintenance(patientId);

            addPlans(TpPlanInput.randomCard(inputData, 2, bomUtils).withMovePayerDown());
            patientMaintenancePage.clickPopUpOkBtn();

            TpPlanInput plan3 = TpPlanInput.randomCard(inputData, 3, bomUtils);
            addPlans(plan3);
            acceptThirdPartyEdit();
            automationManager.performSleep(3);

            Assert.assertEquals(patientMaintenancePage.getTPPlan().trim(), plan3.plan(),
                    "TP plan updated incorrectly");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Successfully verified M3P as payer of last resort except TP plans");
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Failed to verify M3P as payer of last resort: " + e.getMessage());
            Assert.fail(e.toString());
        } finally {
            try {
                if (patientMaintenancePage != null) {
                    patientMaintenancePage.clickExit();
                }
            } catch (Exception ignored) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                        patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            }
        }
    }

    /**
     * Adds secondary plan via Modify Details → Patient Maintenance → Save & Close.
     * Uses {@link #addPlans} logic but differs from {@link #addPlansAndExit} in entry/exit path.
     */
    public void addSecondaryTPPlan(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            modifyDetails.openModifyDetailsScreen();
            Assert.assertTrue(modifyDetails.isDxCodeDisplayed(), "Modify Details screen not opened");
            Reporter.logScreenShot("Modify Details Screen", modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickPatientMaintenanceIcon();
            patientMaintenancePage = new PatientMaintenancePage();   // PMS opened via icon, not openMaintenance()

            TpPlanInput plan = TpPlanInput.fromInputData(inputData, 2).withMovePayerDown();
            Reporter.log("Adding TP Plan: " + plan.plan());
            addPlans(plan);

            Reporter.logScreenShot("Updating TP information", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickSaveAndClose();
            Reporter.log("PMS screen closed successfully");
        } catch (Exception e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("TP information not updated, failed in addSecondaryTPPlan method: " + e.getMessage());
        }
    }
}