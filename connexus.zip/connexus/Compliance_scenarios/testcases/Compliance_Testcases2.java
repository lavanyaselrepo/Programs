package connexus.Compliance_scenarios.testcases;

import connexus.Compliance_scenarios.testscripts.Compliance_Testscripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.text.ParseException;
import java.util.Map;

public class Compliance_Testcases2 {
    Compliance_Testscripts complianceTestScripts=new Compliance_Testscripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    boolean flagUpdated = false;

    @BeforeClass
    public void loginToConnexus() {
        connexusAppUtils.startAppiumServer();
        complianceTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * Test Description:
     * Author: Nagarjuna(vn575ve)
     * ----------------------------------------------------------------------------------------------------------
     */
    @Test(enabled = true, description = "Verify whether serial/Triplicate number is displayed in input screen of speciality stores forTX prescriber_NonCS drug",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE2")
    public void HWPHME2E_207_TriplicateNumber_Displayed_for_NonCS_Drug(Map<String, String> inputData) {
        Reporter.log("HWPHME2E_207_TriplicateNumber_Displayed_for_NonCS_Drug");

        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("5361", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("10766", "FALSE");
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff();
        complianceTestScripts.validateTriplicateNumber(inputData);
        Reporter.log("serial/Triplicate number is displayed in input screen of speciality stores forTX prescriber_NonCS drug");
    }

    /*----------------------------------------------------------------------------------------------------------
* HWPHME2E-197 Test Description: Verify user is able to save Gender as Male and 'Gender Identity' as Not-Specified.
*                   Verify the values are populating appropriately in another store when the profile is host pulled.
*
* Pre-Conditions:
*
* 1.User is logged into Connexus
*
* Author: Aparna Ramalingam(vn50izt)
----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Verify user is able to save Gender as Male and 'Gender Identity' as Not-Specified. Verify the values are populating appropriately in another store when the profile is host pulled.",
            priority = 37, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_197_hostpull_patient_data(Map<String, String> inputData) {
        complianceTestScripts.initializeTestCase(false);
        complianceTestScripts.createPatientAndUpdateGenderIdentity(inputData);
        complianceTestScripts.performCreateOrderAndMoveTocheckDUR(inputData);
        connexusAppUtils.getStoreId();
        complianceTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        complianceTestScripts.validatePatientGenderIdentity(inputData);

    }

}
