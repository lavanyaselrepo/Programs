package connexus.Compliance_scenarios.testcases;

import connexus.Compliance_scenarios.testscripts.Compliance_Testscripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Map;

public class Compliance_Testcases {
    Compliance_Testscripts complianceTestScripts=new Compliance_Testscripts(LoginAs.userType.PHARMACIST_ADFlagOff);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ConnexusAPIManager connexusAPIManager;
    PropertyReader prop = PropertyReader.getInstance();
    boolean flagUpdated = false;
    boolean relaunchConnexus;
    String siteId =prop.getProperty("cnx.store");
    @BeforeClass
    public void loginToConnexus() {
        connexusAppUtils.startAppiumServer();
    }
    @BeforeMethod
    public void setup() {
        connexusAPIManager = new ConnexusAPIManager();
    }
    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }
    public void restartConnexusService(){
        if (flagUpdated) {
            Reporter.log("Restarting Connexus service to apply updated flags");
            connexusAPIManager.restartConnexusService(siteId);
            relaunchConnexus = true;
        } else {
            Reporter.log("No flags updated, skipping Connexus service restart");
        }
    }
    /**
     * ----------------------------------------------------------------------------------------------------------
     * Test Description:
     * Author: Nagarjuna(vn575ve)
     * ----------------------------------------------------------------------------------------------------------
     */
    //@Jira(testID = "HWPHME2E-244")
    @Test(enabled = true, description = "Verify, Rx Moves to Next workqueue when a pharmacist Clicks Problem Resolved-Financial Hardship for RX in Resolution when the amount paid at the POS Using Register Sale is Different from the Patient Pay amount for TP transactions, Original_RX",
            priority = 31, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_244_Problem_Resolved_Financial_Hardship_ForRX_In_Resolution(Map<String, String> inputData) {
        Reporter.log("Verify Rx Moves to Next workqueue when a pharmacist Clicks Problem Resolved-Financial Hardship for RX in Resolution when the amount paid at the POS Using Register Sale is Different from the Patient Pay amount for TP transactions, Original_RX");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData,1);
        complianceTestScripts.performDropOff();
        complianceTestScripts.performInput(inputData);
        complianceTestScripts.perform4Point();
        complianceTestScripts.performFilling();
        complianceTestScripts.performVisualVerify();
        complianceTestScripts.performPickUp(inputData);
        complianceTestScripts.performCounselling();
        complianceTestScripts.updatePatientPayAmountIneOfflineSale();
        complianceTestScripts.completeResolutionByUsingFinancialHardshipOption();
        complianceTestScripts.validatePaymentUpdateMessageInRXNotes(inputData);

        Reporter.log("Rx Moves to Next workqueue when a pharmacist Clicks Problem Resolved-Financial Hardship for RX in Resolution when the amount paid at the POS Using Register Sale is Different from the Patient Pay amount for TP transactions, Original_RX");
    }

    //@Jira(testID = "HWPHME2E-227")
    @Test(enabled = true, description = "Verify, Rx Moves to Next workqueue when a pharmacist Clicks Problem Resolved-Qualified Medicare Beneficiary for RX in Resolution when the amount paid at the POS Using Register Sale is Different from the Patient Pay amount for TP transactions, Original_RX",
            priority = 32, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_227_Problem_Resolved_Qualified_Medicare_Beneficiary_ForRX_In_Resolution(Map<String, String> inputData) {
        Reporter.log("Verify Rx Moves to Next workqueue when a pharmacist Clicks Problem Resolved-Qualified Medicare Beneficiary for RX in Resolution when the amount paid at the POS Using Register Sale is Different from the Patient Pay amount for TP transactions, Original_RX");
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.initializeTestCase(false);
        complianceTestScripts.createNewPatient(inputData,1);
        complianceTestScripts.performDropOff();
        complianceTestScripts.performInput(inputData);
        complianceTestScripts.perform4Point();
        complianceTestScripts.performFilling();
        complianceTestScripts.performVisualVerify();
        complianceTestScripts.performPickUp(inputData);
        complianceTestScripts.performCounselling();
        complianceTestScripts.updatePatientPayAmountIneOfflineSale();
        complianceTestScripts.completeResolutionByUsingQualifiedMedicareBenificiryOption();
       complianceTestScripts.validatePaymentUpdateMessageInRXNotes(inputData);

        Reporter.log("Rx Moves to Next workqueue when a pharmacist Clicks Problem Resolved-Financial Hardship for RX in Resolution when the amount paid at the POS Using Register Sale is Different from the Patient Pay amount for TP transactions, Original_RX");
    }


    //@Jira(testID = "HWPHME2E-248")
    @Test(enabled = true, description = "Rx_Moved_To_4Point_By_Clicking_Yes_Button_In_DAW1_Validation_Popup",
            priority = 35, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_248_Verify_Rx_Moved_To_4Point_By_Clicking_Yes_Button_In_DAW1_Validation_Popup(Map<String, String> inputData) {
        Reporter.log("Verify Rx_Moved_To_4Point_By_Clicking_Yes_Button_In_DAW1_Validation_Popup");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData,1);
        complianceTestScripts.performDropOff();
        complianceTestScripts.performInput(inputData, "DAW1");
        complianceTestScripts.validateDawValidationPopUpAndClickOnYesButton(inputData);
        complianceTestScripts.verifyRxIn4PointQueue();

        Reporter.log("Rx_Moved_To_4Point_By_Clicking_Yes_Button_In_DAW1_Validation_Popup");
    }

    //@Jira(testID = "HWPHME2E-221")
    @Test(enabled = true, description = "Verify_Dx_Code_option_displayed_In_Input_Screen_For_OR_STATE",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_221_Verify_Dx_Code_option_displayed_In_Input_Screen_For_OR_STATE(Map<String, String> inputData) {
        Reporter.log("Verify Dx code option should be displayed above to the Accept button in Input screen.");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        flagUpdated = connexusAppUtils.readAndUpdateFlag("10766", "FALSE");
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.validateDxCodeInputScreen(inputData);

        Reporter.log("Dx_Code_option_displayed_In_Input_Screen_For_OR_STATE");
    }

    //@Jira(testID = "HWPHME2E-215")
    @Test(enabled = true, description = "Verify_Dx_Code_option_displayed_In_Input_Screen_For_C2_Drug_And_RI_STATE",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_215_Verify_Dx_Code_option_displayed_In_Input_Screen_For_C2_Drug_And_RI_STATE(Map<String, String> inputData) {
        Reporter.log("Verify Dx code option should be displayed above to the Accept button in Input screen for C2 Drug for RI state.");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.clickingOnAcceptButtonWithOutProvidingDxCodeInInputScreen(inputData,"QUANTITY");
        complianceTestScripts.validateDxCodeInvalidDataPopUpAndClickOnYesButton(inputData);
        complianceTestScripts.enterDxCodeAndClickOnAcceptButton();
        complianceTestScripts.verifyRxIn4PointQueue();

        Reporter.log("Dx_Code_option_displayed_In_Input_Screen_For_C2_Drug_And_RI_STATE");
    }

    //@Jira(testID = "HWPHME2E-216")
    @Test(enabled = true, description = "Verify_Prescription_Is_Not_Allowed_For_More_Than_31_Days_Supply_For_SC_State_C2_Drugs",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_216_Verify_Prescription_Is_Not_Allowed_For_More_Than_31_Days_Supply_For_SC_State_C2_Drugs(Map<String, String> inputData) {
        Reporter.log("Verify whether prescription is not allowed for more than 31 days supply for SC state C2 drugs.");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInputAndClickAccept(inputData,true);
        complianceTestScripts.verifyInputPopUpOnly(inputData);

        Reporter.log("prescription is not allowed for more than 31 days supply for SC state C2 drugs.");
    }

    //@Jira(testID = "HWPHME2E-211")
    @Test(enabled = true, description = "Verify_RX_Is_Not_Allowed_For_More_Than_35_Days_Supply_For_AL_State_C3_Drugs",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_211_Verify_RX_Is_Not_Allowed_For_More_Than_35_Days_Supply_For_AL_State_C3_Drugs(Map<String, String> inputData) {
        Reporter.log("Verify whether prescription is not allowed for more than 35 days supply for AL state C3 drugs.");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("35","15211","200");
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.clickingOnAcceptButtonWithOutProvidingDxCodeInInputScreen(inputData,"QUANTITY");
        complianceTestScripts.validateRxNotAllowedForGreaterThan35DaysSupplyPopUpAndClickOnOkButton(inputData);

        Reporter.log("prescription is not allowed for more than 35 days supply for AL state C3 drugs.");
    }

    //@Jira(testID = "HWPHME2E-220")
    @Test(enabled = true, description = "Verify whether Collaborating physician is not required to fill the prescription in Input screen if license number of the IL state Nurse Practitioner starts with 277_original Rx",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_220_Verify_Collaborating_Physician_Is_Not_Required_To_Fill_The_Prescription_In_Input_Screen(Map<String, String> inputData) {
        Reporter.log("Verify whether Collaborating physician is not required to fill the prescription in Input screen if license number of the IL state Nurse Practitioner starts with 277_original Rx");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.validateCollaboratingPhysicianDetailsNotDisplayedInInputScreen(inputData);

        Reporter.log("Collaborating physician is not required to fill the prescription in Input screen if license number of the IL state Nurse Practitioner starts with 277_original Rx");
    }

    //@Jira(testID = "HWPHME2E-219")
    @Test(enabled = true, description = "Verify_30_Day_Expiration_Date_Displayed_In_Input_Screen_For_C2_Drug_And_NY_STATE",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_219_Verify_30_Day_Expiration_Date_Displayed_In_Input_Screen_For_C2_Drug_And_NY_STATE(Map<String, String> inputData) {
        Reporter.log("Verify 30 day expiration date displayed in Input screen for C2 Drug for NY state.");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.verifyExpirationDateShouldBe30DaysForControlledDrugInInputScreen(inputData);

        Reporter.log("30 day expiration date displayed in Input screen for C2 Drug for NY state.");
    }

    //@Jira(testID = "HWPHME2E-233")
      @Test(enabled = true, description = "Rx_Notes_Is_Documented_On_Clicking_Yes_In_M2_Rejection",
             priority = 34, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_233_Rx_Notes_Is_Documented_On_Clicking_Yes_In_M2_Rejection(Map<String, String> inputData) {
        Reporter.log("Verify whether I have contacted the insurance plan and received authorization to fill as cash rx notes is documented on clicking Yes in M2 rejection");
        //no specific  userlogin
        flagUpdated = connexusAppUtils.readAndUpdateFlag("15167", "TRUE");
        complianceTestScripts.initializeTestCase(flagUpdated);
          connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData,1);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInput(inputData);
        complianceTestScripts.verifyM2RejectionPopUpAndClickYes(inputData);
        complianceTestScripts.validateM2RejectionMessageInRXNotes(inputData);

        Reporter.log("Able to see I have contacted the insurance plan and received authorization to fill as cash rx notes is documented on clicking Yes in M2 rejection");
    }

    //@Jira(testID = "HWPHME2E-214")
    @Test(enabled = true, description = "Rx_Moved_Resolution_On_Clicking_No_In_M2_Rejection",
            priority = 33, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_214_Rx_Moved_Resolution_On_Clicking_No_In_M2_Rejection(Map<String, String> inputData) {
        Reporter.log("Verify Rx_Moved_Resolution_On_Clicking_No_In_M2_Rejection");
        //no specific user login, MCIAD24
        flagUpdated = connexusAppUtils.readAndUpdateFlag("15167", "TRUE");
        connexusAppUtils.getlogSiteIdAndState(inputData);
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData,1);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInput(inputData);
        complianceTestScripts.verifyM2RejectionPopUpAndClickNo(inputData);
        complianceTestScripts.verifyRxMovedToResolutionQueue(inputData);

        Reporter.log("Rx_Moved_Resolution with_problem_Code_As_Contact_Customer_On_Clicking_No_In_M2_Rejection");
    }

    //@Jira(testID = "HWPHME2E-231")
    @Test(enabled = true, description = "New_prescriptionN_Not_Allowed_To_Process_Input_If_Written_Date_LessThan_Six_Months",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_231_Verify_New_prescriptionN_Not_Allowed_To_Process_Input_If_Written_Date_LessThan_Six_Months(Map<String, String> inputData) {
        Reporter.log("Verify new prescription not allowed to process if written date is less than six months.");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInputWithWrittenDateLessThanSixMonths(inputData);
        complianceTestScripts.verifyPrescriptionLessThanSixMonthsPopUpAndClickYes(inputData);

        Reporter.log("New prescription not allowed to process if written date is less than six months in Input screen.");
    }

    //@Jira(testID = "HWPHME2E-218")
    @Test(enabled = true, description = "Change_Non_Opioid_To_Opioid_drug_And_Chekck_TM_Code_For_OK_State",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_218_Change_Non_Opioid_To_Opioid_drug_And_Chekck_TM_Code_For_OK_State(Map<String, String> inputData) {
        Reporter.log("Validate TM code Options by changing Non opioid drug to Opioid drug in Input screen.");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y","15179","236");
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("M","15121","236");
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.validateTMCodeOptionsByChangingNonOpioidDrugToOpioidDrug(inputData);

        Reporter.log("TM code Options displayed by changing Non opioid drug to Opioid drug in Input screen.");
    }

    //@Jira(testID = "HWPHME2E-424")
    @Test(enabled = true, description = "Verify whether warning message is displayed in application when standing Order for the prescriber got expired _TX State.",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_424_Standing_Order_Warning_Message(Map<String, String> inputData) {
        Reporter.log("Verify whether warning message is displayed in application when standing Order for the prescriber got expired _TX State.");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.launchConnexusAndValidateStandingOrderProtocolPopup();

        Reporter.log("Warning message is displayed in application when standing Order for the prescriber got expired _TX State.");
    }

    //@Jira(testID = "HWPHME2E-176")
    @Test(enabled = true, description = "Verify__Error_Message_Is_Displayed_In_Input_Screen_For_PA_Prescriber_CII_Hydrocodone_Drug_For_Morethan_5_Days_Supply_MO_State",
            priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_176_Verify_Hydro_CII_Error_Message_Is_Displayed_In_Input_Screen_For_PA_Prescriber(Map<String, String> inputData) {
        Reporter.log("Verify whether error message is displayed in input when PA prescriber prescribes CII hydrocodone drug for more than 5 days supply_MO state prescriber_Original Rx");
        //no specific user login
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        flagUpdated = connexusAppUtils.readAndUpdateFlag("15238", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInputWithPrescriberSelectionBasedOnState(inputData);
        complianceTestScripts.validateErrorMessageInPopUpAndClickOnOkButton(inputData);

        Reporter.log("Validated Hydro_CII_Error_Message_Is_Displayed_In_Input_Screen for MO state PA prescriber.");
    }

    //@Jira(testID = "HWPHME2E-177")
    @Test(enabled = true, description = "Verify__Error_Message_Is_Displayed_In_Input_Screen_For_ANP_Prescriber_CII_Hydrocodone_Drug_For_Morethan_5_Days_Supply_MO_State",
            priority = 18, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_177_Verify_Hydro_CII_Error_Message_Is_Displayed_In_Input_Screen_For_ANP_Prescriber(Map<String, String> inputData) {
        Reporter.log("Verify whether error message is displayed in input when ANP prescriber prescribes CII hydrocodone drug for more than 5 days supply_MO state prescriber_Original Rx");
        //no specific user login
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        flagUpdated = connexusAppUtils.readAndUpdateFlag("15238", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInputWithPrescriberSelectionBasedOnState(inputData);
        complianceTestScripts.validateErrorMessageInPopUpAndClickOnOkButton(inputData);

        Reporter.log("Validated Hydro_CII_Error_Message_Is_Displayed_In_Input_Screen for MO state ANP prescriber.");
    }

    //@Jira(testID = "HWPHME2E-178")
    @Test(enabled = true, description = "Verify_Non_Hydro_CII_Error_Message_Is_Displayed_In_Input_Screen_For_PA_Prescriber",
            priority = 19, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_178_Verify_Non_Hydro_CII_Error_Message_Is_Displayed_In_Input_Screen_For_PA_Prescriber(Map<String, String> inputData) {
        Reporter.log("Verify whether Non Hydro CII error message is displayed in input when PA prescriber prescribes CII non hydrocodone drug _MO state prescriber_Original Rx");
        //no specific user login
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        flagUpdated = connexusAppUtils.readAndUpdateFlag("15238", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInputWithPrescriberSelectionBasedOnState(inputData);
        complianceTestScripts.validateErrorMessageInPopUpAndClickOnOkButton(inputData);

        Reporter.log("Validated_Non_Hydro_CII_Error_Message_Is_Displayed_In_Input_Screen for MO state PA prescriber.");
    }

    //@Jira(testID = "HWPHME2E-179")
    @Test(enabled = true, description = "Verify_Non_Hydro_CII_Error_Message_Is_Displayed_In_Input_Screen_For_ANP_Prescriber",
            priority = 20, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_179_Verify_Non_Hydro_CII_Error_Message_Is_Displayed_In_Input_Screen_For_ANP_Prescriber(Map<String, String> inputData) {
        Reporter.log("Verify whether Non Hydro CII error message is displayed in input when ANP prescriber prescribes CII non hydrocodone drug _MO state prescriber_Original Rx");
        //no specific user login
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        flagUpdated = connexusAppUtils.readAndUpdateFlag("15238", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInputWithPrescriberSelectionBasedOnState(inputData);
        complianceTestScripts.validateErrorMessageInPopUpAndClickOnOkButton(inputData);

        Reporter.log("Validated_Non_Hydro_CII_Error_Message_Is_Displayed_In_Input_Screen for MO state ANP prescriber.");
    }

    //@Jira(testID = "HWPHME2E-190")
    @Test(enabled = true, description = "Change_Non_Opioid_To_Opioid_drug_And_Chekck_TM_Code_For_OK_State",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_190_Validate_TM_Code_is_Optional_IN_Input_And_ModifyDetails_Screen_For_IL_State(Map<String, String> inputData) {
        Reporter.log("Verify TM code is an optional Field field and NO warning popup appears if the field is blank and accept is clicked at Input and Modify Details screens for IL state");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("O","15121","213");
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInputWithBlankTMCode(inputData);
        complianceTestScripts.verifyRxIn4PointQueue();
        complianceTestScripts.clickAcceptButtonwithBlankTMCodeInModifyDetailsScreen();
        complianceTestScripts.verifyRxIn4PointQueue();

        Reporter.log("TM code is an optional Field field and NO warning popup appears if the field is blank and accept is clicked at Input and Modify Details screens for IL state");
    }

    //@Jira(testID = "HWPHME2E-185")
    @Test(enabled = true, description = "Validate_TM_Code_is_Mandatory_IN_Input_And_ModifyDetails_Screen_For_OK_State",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_185_Validate_TM_Code_is_Mandatory_IN_Input_And_ModifyDetails_Screen_For_OK_State(Map<String, String> inputData) {
        Reporter.log("Verify TM code is a mandatory field and a warning popup appears if the field is blank and accept is clicked at Input and Modify Details");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        flagUpdated |=connexusAppUtils.updateAgencyRequirementParmTbl("Y","15179","236");
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("M","15121","213");
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInputWithBlankTMCode(inputData);
        complianceTestScripts.validateErrorMessageInPopUpAndClickOnOkButton(inputData);
        complianceTestScripts.performInput(inputData);
        complianceTestScripts.verifyRxIn4PointQueue();
        complianceTestScripts.clickAcceptButtonwithBlankTMCodeInModifyDetailsScreen();
        complianceTestScripts.validateErrorMessageInPopUpAndClickOnOkButton(inputData);

        Reporter.log("TM code is a mandatory field and a warning popup appears if the field is blank and accept is clicked at Input and Modify Details");
    }

    //@Jira(testID = "HWPHME2E-183")
    @Test(enabled = true, description = "HWPHME2E_183_Verify_Remaining_quantity_voided_Before_Filling_C3_Non_Opioid_For_ARNP_Prescriber",
            priority = 24, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_183_Verify_Remaining_quantity_voided_Before_Filling_C3_Non_Opioid_For_ARNP_Prescriber(Map<String, String> inputData) {
        Reporter.log("Verify, remaining qty is voided before Filling when a CIII Non-Opioid drug is prescribed above the days supply limit by ARNP prescriber from MO state");
        //no specific user login
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        flagUpdated = connexusAppUtils.readAndUpdateFlag("15238", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(1, Priority.Critical, 1, RxOriginType.Phone);
        complianceTestScripts.performInputWithGreaterThanDaysSupplyLimitAndUpdateDispenseQty(inputData);
        complianceTestScripts.perform4Point(false);
        complianceTestScripts.validateRemainingQuantityAndRxNotesInModifyDetailsScreen(inputData);
        complianceTestScripts.verifyActivityCodeInRxActivityTable();

        Reporter.log("Validated remaining qty is voided before Filling when a CIII Non-Opioid drug is prescribed above the days supply limit by ARNP prescriber from MO state");
    }

    //@Jira(testID = "HWPHME2E-182")
    @Test(enabled = true, description = "Verify_Remaining_quantity_voided_Before_Filling_C3_Non_Opioid_For_PA_Prescriber",
            priority = 23, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_182_Verify_Remaining_quantity_voided_Before_Filling_C3_Non_Opioid_For_PA_Prescriber(Map<String, String> inputData) {
        Reporter.log("Verify, remaining qty is voided before Filling when a CIII Non-Opioid drug is prescribed above the days supply limit by PA prescriber from MO state");
        //no specific user login

        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        flagUpdated = connexusAppUtils.readAndUpdateFlag("15238", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(1, Priority.Critical, 1, RxOriginType.Fax);
        complianceTestScripts.performInputWithGreaterThanDaysSupplyLimitAndUpdateDispenseQty(inputData);
        complianceTestScripts.perform4Point(false);
        complianceTestScripts.validateRemainingQuantityAndRxNotesInModifyDetailsScreen(inputData);
        complianceTestScripts.verifyActivityCodeInRxActivityTable();

        Reporter.log("Validated remaining qty is voided before Filling when a CIII Non-Opioid drug is prescribed above the days supply limit by ARNP prescriber from MO state");
    }

    //@Jira(testID = "HWPHME2E-181")
    @Test(enabled = true, description = "HWPHME2E_181_Verify_Remaining_quantity_voided_Before_Filling_C3_Opioid_For_ARNP_Prescriber",
            priority = 22, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_181_Verify_Remaining_quantity_voided_Before_Filling_C3_Opioid_For_ARNP_Prescriber(Map<String, String> inputData) {
        Reporter.log("Verify, remaining qty is voided before Filling when a CIII Opioid drug is prescribed above the days supply limit by ARNP prescriber from MO state");
        //no specific user login
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        flagUpdated = connexusAppUtils.readAndUpdateFlag("15238", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInputWithGreaterThanDaysSupplyLimitAndUpdateDispenseQty(inputData);
        complianceTestScripts.perform4Point(false);
        complianceTestScripts.validateRemainingQuantityAndRxNotesInModifyDetailsScreen(inputData);
        complianceTestScripts.verifyActivityCodeInRxActivityTable();

        Reporter.log("Validated remaining qty is voided before Filling when a CIII Opioid drug is prescribed above the days supply limit by ARNP prescriber from MO state");
    }

    //@Jira(testID = "HWPHME2E-165")
    @Test(enabled = true, description = "Verify_Remaining_quantity_voided_Before_Filling_For_Buprenorphine_drug_For_PA_Prescriber",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_165_Verify_Remaining_quantity_voided_Before_Filling_For_Buprenorphine_drug_For_PA_Prescriber(Map<String, String> inputData) {
        Reporter.log("Verify, remaining qty is voided before Filling when a Buprenorphine drug is prescribed above the days supply limit(30) by PA prescriber from MO State");
        //no specific user login
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        flagUpdated = connexusAppUtils.readAndUpdateFlag("15238", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInputWithGreaterThanDaysSupplyLimitAndUpdateDispenseQty(inputData);
        complianceTestScripts.perform4Point(false);
        complianceTestScripts.validateRemainingQuantityAndRxNotesInModifyDetailsScreen(inputData);
        complianceTestScripts.verifyActivityCodeInRxActivityTable();

        Reporter.log("Validated remaining qty is voided before Filling when a CIII Opioid drug is prescribed above the days supply limit by ARNP prescriber from MO state");
    }

    //@Jira(testID = "HWPHME2E-171")
    @Test(enabled = true, description = "HWPHME2E_171_Verify_Error_message_For_Rx_Expiration_Days_Supply_Input_And_Modify_Detail_Screen_NM_Prescriber",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_171_Verify_Error_message_For_Rx_Expiration_Days_Supply_Input_And_Modify_Detail_Screen_NM_Prescriber(Map<String, String> inputData) {
        Reporter.log("Verify, error message for RX Expiration and Days supply violation displayed in input and modify when RX written date is >90 days and Days supply is >90 respectively & excess qty is Voided for NM Prescriber from TX state.");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInputWithExpiryDateGreaterThan90Days(inputData,1);
        complianceTestScripts.verifyInvalidRxDatePopUpOnly(inputData);
        complianceTestScripts.updateWrittenDateAndAccept(inputData);
        complianceTestScripts.verifyInputPopUpAndInputAccept(inputData);
        complianceTestScripts.perform4Point(false);
        complianceTestScripts.performChkDUR();
        complianceTestScripts.launchModifyScreenForValidation();
        complianceTestScripts.ClickOnAcceptButtonByProvidingrxExpiryDateSelectionThan90Days(inputData);
        complianceTestScripts.verifyInvalidRxDatePopUpAndClickOKOnModifyScreen(inputData);
        complianceTestScripts.clickCancelOnModifyScreen();
        complianceTestScripts.launchModifyScreenForValidation();
        complianceTestScripts.ClickOnAcceptButtonByProvidingWrittenDateLessThan90Days(inputData);
        complianceTestScripts.verifyModifyPopUpOnly(inputData);

        Reporter.log("Validated error message for RX Expiration and Days supply violation displayed in input and modify when RX written date is >90 days and Days supply is >90 respectively & excess qty is Voided for NM Prescriber from TX state.");
    }

    //@Jira(testID = "HWPHME2E-172")
    @Test(enabled = true, description = "HWPHME2E_172_Verify_Error_message_For_Rx_Expiration_Days_Supply_Input_And_Modify_Detail_Screen_CRNA_Prescriber",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_172_Verify_Error_message_For_Rx_Expiration_Days_Supply_Input_And_Modify_Detail_Screen_CRNA_Prescriber(Map<String, String> inputData) {
        Reporter.log("Verify, error message for RX Expiration and Days supply violation displayed in input and modify when RX written date is >90 days and Days supply is >90 respectively & excess qty is Voided for CRNA Prescriber from TX state.");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(1, Priority.Critical, 1, RxOriginType.Fax);
        complianceTestScripts.performInputWithExpiryDateGreaterThan90Days(inputData,1);
        complianceTestScripts.verifyInvalidRxDatePopUpOnly(inputData);
        complianceTestScripts.updateWrittenDateAndAccept(inputData);
        complianceTestScripts.verifyInputPopUpAndInputAccept(inputData);
        complianceTestScripts.perform4Point(false);
        complianceTestScripts.performChkDUR();
        complianceTestScripts.launchModifyScreenForValidation();
        complianceTestScripts.ClickOnAcceptButtonByProvidingrxExpiryDateSelectionThan90Days(inputData);
        complianceTestScripts.verifyInvalidRxDatePopUpAndClickOKOnModifyScreen(inputData);
        complianceTestScripts.clickCancelOnModifyScreen();
        complianceTestScripts.launchModifyScreenForValidation();
        complianceTestScripts.ClickOnAcceptButtonByProvidingWrittenDateLessThan90Days(inputData);
        complianceTestScripts.verifyModifyPopUpOnly(inputData);


        Reporter.log("Validated error message for RX Expiration and Days supply violation displayed in input and modify when RX written date is >90 days and Days supply is >90 respectively & excess qty is Voided for CRNA Prescriber from TX state.");
    }

    //@Jira(testID = "HWPHME2E-188")
    @Test(enabled = true, description = "Validate_Medicare_B_Plan_Pop_Up_In_PickUp_Screen",
            priority = 36, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_188_Validate_Medicare_B_Plan_Pop_Up_In_PickUp_Screen(Map<String, String> inputData) {
        Reporter.log("Verify Medicare B Validation popup is processed at pickup screen when a patient with Age >=65 is prescribed a Medicare B item.");
        //no specific user login
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.initializeTestCase(false);
        complianceTestScripts.createNewPatient(inputData,1);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInput(inputData);
        complianceTestScripts.perform4Point(false);
        complianceTestScripts.performFilling();
        complianceTestScripts.performVisualVerify();
        complianceTestScripts.verifyMedicareBPopUpInPickUpScreen(inputData);

        Reporter.log("Verified Medicare B Validation popup is processed at pickup screen");
    }

    //@Jira(testID = "HWPHME2E-168")
    @Test(enabled = true, description = "Verify_Error_message_For_Days_Supply_In_Input_And_Modify_Detail_Screen_TN_State_For_C2_Opioid_Drug",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_168_Verify_Error_message_For_Days_Supply_In_Input_And_Modify_Detail_Screen_TN_State_For_C2_Opioid_Drug(Map<String, String> inputData) {
        Reporter.log("Verify error message for Days supply voilation is displayed in input and modify detail screen when Days supply is above 30 for an RX with CII OPIOID drug in TN state");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        flagUpdated |=connexusAppUtils.updateAgencyRequirementParmTbl("30","15010","242");
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("30","15096","242");
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.clickingOnAcceptButtonWithOutProvidingDxCodeInInputScreen(inputData,"EXTEND_QUANTITY");
        complianceTestScripts.verifyInputPopUpAndInputAccept(inputData);
        complianceTestScripts.perform4Point(false);
        complianceTestScripts.performChkDUR();
        complianceTestScripts.launchModifyScreenForValidation();
        complianceTestScripts.updateQuantitiesAndAcceptInModifyDetails(inputData,"EXTEND_QUANTITY");
        complianceTestScripts.verifyModifyPopUpOnly(inputData);
        Reporter.log("Error message displayed for Days supply voilation in input and modify detail screen when Days supply is above 30 for an RX with CII OPIOID drug in TN state");
    }

    //@Jira(testID = "HWPHME2E-192")
    @Test(enabled = true, description = "Verify whether CSID screen is displayed for DOC drug after changing the drug from NonCS to DOC via Return To Tech in WI state",
            priority = 41, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_192_Verify_CSID_Screen_Displayed_For_DOC_Drug_After_Changing_Drug_From_NonCS_To_DOC_Via_Return_To_TechFor_WI_State(Map<String, String> inputData) {
        Reporter.log("Verify whether CSID screen is displayed for DOC drug after changing the drug from NonCS to DOC via Return To Tech in WI state");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.initializeTestCase(false);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInput(inputData);
        complianceTestScripts.performPrescriptionUpdateByClickingReturnToTechButtonIn4Point();
        complianceTestScripts.updatePrescriptionDetailsInInputScreen(inputData);
        complianceTestScripts.perform4Point(false);
        complianceTestScripts.performFilling();
        complianceTestScripts.performVisualVerify();
        complianceTestScripts.performPickUp(inputData);


        Reporter.log("CSID screen is displayed for DOC drug after changing the drug from NonCS to DOC via Return To Tech in WI state");
    }

    //@Jira(testID = "HWPHME2E-210")
    @Test(enabled = true, description = "Verify_Customer_Signature_Is_Captured_When_Patient_Having_Medicaid_Plan_From_IA_State",
            priority = 42, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_210_Verify_Customer_Signature_Is_Captured_When_Patient_Having_Medicaid_Plan_From_IA_State(Map<String, String> inputData) {
        Reporter.log("Verify, customer signature is captured when the Patient having a Medicaid Plan from IA state.");
        //no specific user login

        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y","14116","215");
        complianceTestScripts.initializeTestCase(false);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData,1);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInput(inputData);
        complianceTestScripts.perform4Point(false);
        complianceTestScripts.performFilling();
        complianceTestScripts.performVisualVerify();
        complianceTestScripts.switchToCASHFromTP();
        complianceTestScripts.verifyCustomerSignatureIsMandatoryInPickUpScreen(inputData);

        Reporter.log("Verified customer signature is captured when the Patient having a Medicaid Plan from IA state");
    }

    //@Jira(testID = "HWPHME2E-200")
    @Test(description = "POS_Queue_Is_NOT_Skipped_When_Payment_Processed_Is_Unsuccessfully",
            priority = 41, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_200_POS_Queue_Is_NOT_Skipped_When_Payment_Processed_Is_Unsuccessfully(Map<String, String> inputData) {
        System.out.println("<<<HWPHME2E_200_POS_Queue_Is_NOT_Skipped_When_Payment_Processed_Is_Unsuccessfully>>>");
        //no specific user login
        flagUpdated = connexusAppUtils.readAndUpdateFlag("8670", "FALSE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("5361", "FALSE");
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        int patientID = complianceTestScripts.performCreatePatientThroughAPI(inputData, complianceTestScripts.siteId);
        complianceTestScripts.addCardToPatientAccountAPI(patientID, inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.performInput(inputData);
        complianceTestScripts.perform4Point(true);
        complianceTestScripts.performFilling();
        complianceTestScripts.performVisualVerify();
        complianceTestScripts.updateP2pTokenValue();
        complianceTestScripts.performPickUp(inputData);
        complianceTestScripts.performCounselling();
        complianceTestScripts.verifyRxInPOSQueue();
        complianceTestScripts.verifyEntryInAuditTable();
        System.out.println("<<<HWPHME2E_200_POS_Queue_Is_NOT_Skipped_When_Payment_Processed_Is_Unsuccessfully>>>");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * Test Description:
     * Author: Nagarjuna(vn575ve)
     * ----------------------------------------------------------------------------------------------------------
     */
    @Test(enabled = true, description = "Verify whether serial/Triplicate number is displayed in input screen of speciality stores forTX prescriber_NonCS drug",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE2")
    public void HWPHME2E_207_TriplicateNumber_Displayed_for_NonCS_Drug(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-207-Verify whether serial/Triplicate number is displayed in input screen of speciality stores forTX prescriber_NonCS drug");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("5361", "TRUE");
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("10766", "FALSE");
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff(Priority.Critical);
        complianceTestScripts.validateTriplicateNumber(inputData);
        Reporter.log("serial/Triplicate number is displayed in input screen of speciality stores forTX prescriber_NonCS drug");
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * HWPHME2E-197 Test Description: Verify user is able to save Gender as Male and 'Gender Identity' as Not-Specified.
     * Verify the values are populating appropriately in another store when the profile is host pulled.
     * Pre-Conditions:
     *      1.User is logged into Connexus
     * Author: Aparna Ramalingam(vn50izt)
     * ----------------------------------------------------------------------------------------------------------
     */
    @Test(description = "Verify user is able to save Gender as Male and 'Gender Identity' as Not-Specified. Verify the values are populating appropriately in another store when the profile is host pulled.",
            priority = 37, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE")
    public void HWPHME2E_197_hostpull_patient_data(Map<String, String> inputData) {
        complianceTestScripts.createPatientAndUpdateGenderIdentity(inputData);
        complianceTestScripts.performCreateOrderAndMoveTocheckDUR(inputData);
        connexusAppUtils.getStoreId();
        complianceTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        complianceTestScripts.validatePatientGenderIdentity(inputData);
    }


    @Test(enabled = true, description = "Verify, Rx expiry is calculated as 30 days from EFD date when an Rx is dropped for a C2 drug_OK state_Input screen_ACRP flag 15137 Y _Original Rx",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/Compliance/ComplianceFile.json", sheetName = "COMPLIANCE2")
    public void HWPHME2E_209_RX_Expiry_date_Calculated_30Days_From_EFD(Map<String, String> inputData) {
        Reporter.log("HWPHME2E_209_RX_Expiry_date_Calculated_30Days_From_EFD");
        flagUpdated = connexusAppUtils.readAndUpdateStoreState(inputData.get("STATE_UPDATE"));
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y","15137","236");
        restartConnexusService();
        complianceTestScripts.initializeTestCase(flagUpdated);
        connexusAppUtils.fetchlogSiteIdAndState(inputData.get("STATE_UPDATE"));
        complianceTestScripts.createNewPatient(inputData);
        complianceTestScripts.performDropOff();
        complianceTestScripts.validateRxExpiryDateFromEFD(inputData);
        Reporter.log("Validation is done for HWPHME2E_209_RX_Expiry_date_Calculated_30Days_From_EFD");
    }
}