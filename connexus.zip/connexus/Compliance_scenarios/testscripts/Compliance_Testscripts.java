package connexus.Compliance_scenarios.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import connexus.OrderCreation.PayloadResource;
import connexus.OrderCreation.testcases.OrderCreationRegressionTestSet5;
import connexus.e2e.testcases.E2E_TestCases;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.joda.time.DateTime;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import java.util.*;
import java.util.List;

import static connexus.e2e.testcases.E2E_TestCases.loginUser_Type;

public class Compliance_Testscripts extends ConnexusTestScripts {

    PayloadResource payloadResource = new PayloadResource();
    InputResponse inputResp = new InputResponse();
    int patientId;
    String patientName;

    public Compliance_Testscripts(LoginAs.userType userType) {
        super(userType);
    }

    public void updateStoreState(String state) {
        connexusAppUtils.updateStoreState(state);
    }

    public void launchConnexusAndValidateStandingOrderProtocolPopup() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            loginPage = new LoginPage(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            loginPage.clickloginScreenUserNameTextField();
            loginPage.inputHoUserNameAndPassword();
            loginPage.clickHomeOfficeCheckBox();
            loginPage.clickAccept();
            loginPage.clickSecurityWarningAccept();
            int count = 0;
            while (count < 7) {
                if (loginPage.isElementDisplayed(loginPage.okButton, 10)) {
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
                    String text= loginPage.getErrorPopUpText();
                    if (!"The following Emergency C2 Rxs are pending in Resolution queue:".contains(text)) {
                        loginPage.click(loginPage.okButton);
                    }
                } else {
                    loginPage.switchWindow();
                }
                count++;
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Navigates to the patient's input record, fills all Rx fields using the V2
     * state-aware prescriber flow, and completes the full accept chain.
     *
     * <p>This method uses {@code enterPrescriberBasedOnStateV2} which requires
     * explicit tab navigation ({@code clickPrescriberTab} → {@code clickAttendingPhysicianTab})
     * unlike the standard {@code enterPrescriberBasedOnState} used in
     * {@link #fillBasicRxFields(Map)}. Use this method when the test data
     * includes both {@code PRESCRIBER_NAME} and {@code STATE_UPDATE} and the
     * attending physician tab navigation must be explicitly exercised.
     */
    public void performInputWithPrescriberSelectionBasedOnState(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            navigateToPatientInputRecord();
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            // V2 prescriber flow requires explicit tab navigation
            inputPage.enterPrescriberBasedOnStateV2(inputData.get("PRESCRIBER_NAME"), inputData.get("STATE_UPDATE"));
            fillV2PrescriberTabsAndOptionalFields(inputData, currentStepMethodName);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            inputPage.clickYesOnValidateRxPopUp();
            inputPage.clickOnOutofStockPopupOk();
            inputPage.clickYesOnValidateRxPopUp();
            Reporter.log("Input completed");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Input not Completed", "Failed", "E2E_execution_status.txt", 30, DateTime.now());
        }
    }

    /**
     * Navigates to the input screen, fills the mandatory Rx fields, then asserts
     * that the DX-code field is visible before cancelling. The DX code is
     * intentionally left unfilled — this step only verifies its presence.
     */
    public void validateDxCodeInputScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            navigateToPatientInputRecord();
            inputPage.isAddressValidationViewPopupDisplayed();
            fillBasicRxFields(inputData);
            if (inputPage.isDxCodeDisplayed()) {
                Assert.assertTrue(true, "Dx code displayed in Input screen");
                Reporter.log("Dx code displayed in Input screen");
            } else {
                Assert.fail("DX code not displayed in Input screen.");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickCancel();
            orderSearch.clickYes();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Navigates to the input screen, fills the mandatory Rx fields, then asserts
     * that the attending-physician tab is NOT present — verifying the state rules
     * do not require a collaborating physician.
     */
    public void validateCollaboratingPhysicianDetailsNotDisplayedInInputScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            navigateToPatientInputRecord();
            inputPage.isAddressValidationViewPopupDisplayed();
            fillBasicRxFields(inputData);
            if (!inputPage.isAttendingPhysicianTabDisplayed()) {
                Assert.assertTrue(true, "Attending Physician Details not Required in Input screen");
                Reporter.log("Attending Physician Details not Required in Input screen");
            } else {
                Assert.fail("Attending Physician Details displayed in Input screen");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickCancel();
            orderSearch.clickYes();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateTMCodeOptionsByChangingNonOpioidDrugToOpioidDrug(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            inputPage.isAddressValidationViewPopupDisplayed();
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            Reporter.log("TM code not displayed in Input screen for Non Opioid drug");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clearPrescribedProduct();
            inputPage.enterNdc(inputData.get("UPDATE_DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            if(inputPage.isTMCodeDisplayed()){
                String expctedTmDropdownList= inputData.get("TM_CODE_VALUES");
                List<String> TMCodeValues = new ArrayList<>(Arrays.asList(expctedTmDropdownList.split(",")));
                List<String> tmDropdownList = inputPage.getPrescriberDegreeDropdownValues();
                Reporter.log("Expected TM code Values"+TMCodeValues);
                Reporter.log("Actaul Code values"+tmDropdownList);
                Assert.assertEquals(TMCodeValues, tmDropdownList,"TM code values are not matching");
                Assert.assertTrue(true, "TM code displayed in Input screen for Opioid drug");
                Reporter.log("TM code displayed in Input screen");
            }else{
                Assert.fail("TM code not displayed in Input screen.");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickCancel();
            inputPage.clickCancel();
            orderSearch.clickYes();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * Navigates to the input screen, fills the mandatory Rx fields, then clicks
     * Accept <em>without</em> filling the DX code — intentionally triggering the
     * DX-code validation popup so the caller can assert on its content.
     *
     * <p>Triplicate is still handled because it is unrelated to the DX-code
     * validation being tested and must be present for Accept to proceed.
     */
    public void clickingOnAcceptButtonWithOutProvidingDxCodeInInputScreen(Map<String, String> inputData,String quantityKey) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            navigateToPatientInputRecord();
            inputPage.isAddressValidationViewPopupDisplayed();
            fillBasicRxFields(inputData,quantityKey);
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }
            if (inputPage.isDxCodeDisplayed()) {
                Assert.assertTrue(true, "Dx code displayed in Input screen");
            } else {
                Assert.fail("DX code not displayed in Input screen.");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyExpirationDateShouldBe30DaysForControlledDrugInInputScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(name[0] + "," + name[1]);
            orderSearch.openFirstPatientRecord();
            inputPage.isAddressValidationViewPopupDisplayed();
            inputPage.enterNdc(inputData.get("DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            Reporter.logScreenShot(Status.PASS, "Expiration Date before Entering the Controlled drug", inputPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Expiration date should be 30 days from the current date for controlled drug in input screen.");
            String expirationDate=inputPage.getExpirationDate();
            String writtenDate=inputPage.getWrittenDate();
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            Calendar cal = Calendar.getInstance();
            cal.setTime(sdf.parse(writtenDate));
            cal.add(Calendar.DAY_OF_MONTH, 30);
            String expectedExpirationDate = sdf.format(cal.getTime());
            Assert.assertEquals(expectedExpirationDate,expirationDate,"Date is not matching");
            Reporter.logScreenShot(Status.PASS, "Expiration Date After Entering the Controlled drug", inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickCancel();
            orderSearch.clickYes();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }



    public void performInputWithWrittenDateLessThanSixMonths(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxModel.setNdc(inputData.get("DRUG_NAME"));
            rxModel.setPrescribedQty(inputData.get("QUANTITY"));
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            if (isOrderInInputQueueDB(name[0],name[1],1)) {
                automationManager.getConnexusWorkFlow().performInputWithWrittenDateLessThanSixMonths(rxModel);
            } else {
                Reporter.log("RX is not in Input queue");
                Assert.fail();
            }
            connexusAppUtils.writeTextToFile("Input Completed","In progress","E2E_execution_status.txt",30, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Input queue");
            connexusAppUtils.writeTextToFile("Input not Completed","Failed","E2E_execution_status.txt",30, DateTime.now());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void performPrescriptionUpdateByClickingReturnToTechButtonIn4Point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if(checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                connexusAppUtils.writeTextToFile("RX is in 4 point "+rxNbr,"In progress",fileName,40, DateTime.now());
            } else {
                connexusAppUtils.writeTextToFile("RX is not in 4 point "+rxNbr,"In progress",fileName,40, DateTime.now());
                Reporter.log("RX is not in 4 Point, Performing Resolve Queue");
                performResolveQueue(rxNbr);
            }
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            fourPoint.clickSigpad();
            fourPoint.clickPricription();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            fourPoint.clickReturnToTechButton();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("4 point Not Completed","Failed","E2E_execution_status.txt",40, DateTime.now());
            Reporter.log("Test failed at 4 Point queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void updatePrescriptionDetailsInInputScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            inputPage.clearPrescribedProduct();
            inputPage.enterNdc(inputData.get("UPDATE_DRUG_NAME"));
            inputPage.clickProductSearch3Dots();
            inputPage.cleareSigTextBox();
            inputPage.enterSigCode(inputData.get("UPDATE_SIG_CODE"));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourPoint.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            inputPage.clickYesOnValidateRxPopUp();
            inputPage.clickOnOutofStockPopupOk();
            inputPage.clickYesOnValidateRxPopUp();
            inputPage.partialpopup();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            connexusAppUtils.writeTextToFile("4 point Not Completed", "Failed", "E2E_execution_status.txt", 40, DateTime.now());
            Reporter.log("Test failed at 4 Point queue");
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyCustomerSignatureIsMandatoryInPickUpScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Pickup.getValue())) {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in PickUp queue");
            }
            tascoPage.launchTascoScreen();
            if(tascoPage.isElementDisplayed(tascoPage.txtFirstName)) {
                tascoPage.inputPatientLastName(name[0]);
                tascoPage.pressTabKey();
                tascoPage.inputPatientFirstName(name[1]);
                tascoPage.pressTabKey();
                tascoPage.inputPatientDob(inputData.get("DOB"));
                tascoPage.pressTabKey();
                tascoPage.pressTabKey();
            }else {
                tascoPage.inputPatientRxnumber(rxNbr);
            }
            tascoPage.clickSearchOnTascoPage();
            tascoPage.clickRow(0);
            if (!tascoPage.validateCheckoutBkt()) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Checkout button not enabled on tasco screen");
                return;
            }
            tascoPage.continueCheckout();
            tascoPage.clickCheckout();
            tascoPage.handleConnexusCheckoutCashPayPopup();
            int fillId = connexusAppUtils.getFillId(rxNbr);
            String siteId = propertyReader.getProperty("cnx.store");
            if(tascoPage.isToteNbrDisplayed()){
                if(siteId.length()==4) {
                    tascoPage.scanRx("0" + siteId + "00" + rxNbr + "0000");
                }else{
                    tascoPage.scanRx(siteId + "00" + rxNbr + "0000");
                }
            }else if(tascoPage.isTxtCounselCommentsDisplayed()){
                tascoPage.scanRx("4793" + fillId + "0");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.handleDoYouHaveAnyQuestionsToTheDoctorPopup();
            tascoPage.clickAcceptCheckout();
            tascoPage.clickOk();
            tascoPage.clickPatientRefused();
            tascoPage.clickOk();
            tascoPage.clickOk();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.clickOk();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.cancelPickUpValidation();
            tascoPage.clickAccept();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.click(tascoPage.closePopupWindow);
            tascoPage.clickExitInTasco();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Pickup not Completed "+rxNbr,"Failed","E2E_execution_status.txt",80, DateTime.now());
            Reporter.log("Test failed at PickUp queue");
            Assert.fail("Pick up failed");
        }
    }

    public void verifyMedicareBPopUpInPickUpScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Pickup.getValue())) {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in PickUp queue");
            }

            tascoPage.launchTascoScreen();
            if(tascoPage.isElementDisplayed(tascoPage.txtFirstName,10)) {
                tascoPage.inputPatientLastName(name[0]);
                tascoPage.pressTabKey();
                tascoPage.inputPatientFirstName(name[1]);
                tascoPage.pressTabKey();
                tascoPage.inputPatientDob(inputData.get("DOB"));
                tascoPage.pressTabKey();
                tascoPage.pressTabKey();
            }else {
                tascoPage.inputPatientRxnumber(rxNbr);
            }
            tascoPage.clickSearchOnTascoPage();
            tascoPage.clickRow(0);
            tascoPage.handleOtherOrdersAvailablePopUp();
            if (!tascoPage.validateCheckoutBkt()) {
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Assert.fail("Checkout button not enabled on tasco screen");
                return;
            }
            tascoPage.continueCheckout();
            tascoPage.clickCheckout();
            if (tascoPage.isElementDisplayed(tascoPage.btnMedB_By_Pass, 30) && tascoPage.isElementDisplayed(tascoPage.btnScanSignatureSlip, 30)) {
                Assert.assertTrue(true);
                Reporter.log("Medicare B pop up displayed in pickup screen.");
            }else {
                Assert.fail("Medicare B pop up not displayed in pickup screen.");
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
            tascoPage.click(tascoPage.closePopupWindow);
            tascoPage.clickExitInTasco();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Pickup not Completed "+rxNbr,"Failed","E2E_execution_status.txt",80, DateTime.now());
            Reporter.log("Test failed at PickUp queue");
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyEntryInAuditTable(){
        int rxFillId = connexusAppUtils.getFillId(rxNbr);
        int rowCount = connexusAppUtils.verifyEntryInAuditActivityTable(rxFillId);
        Assert.assertTrue(rowCount > 0, "Expected entry in the audit table in DB for rxFillId:" + rxFillId);
        Reporter.log("Entry found in DB for rxFillId:" + rxFillId);
    }

    public void updatePatientPayAmountIneOfflineSale() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        F6Search search = new F6Search();
        orderSearch.launchOrderSearchScreen();
        orderSearch.performSearch(rxNbr);
        search.clickOfflineSold();
        search.enterPatientPayAmt("1.0");
        search.clickSoldAccept();
        search.clickSoldYes();
        search.clickSoldOk();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, search.takeScreenShot(currentStepMethodName).getValue());
        search.closeSearch();
        Reporter.log("RX moved to Resolve queue");
    }

    public void completeResolutionByUsingFinancialHardshipOption() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            ResolutionPage resolutionPage = new ResolutionPage();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            if (resolutionPage.isElementDisplayed(resolutionPage.btnProblemResolved, 5)) {
                resolutionPage.clickProblemResolved();
                resolutionPage.clickFinancialHardship();
                resolutionPage.selectReason();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
                resolutionPage.clickAccept();
            } else {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
                resolutionPage.clickDownTime();
                if (resolutionPage.isElementDisplayed(resolutionPage.txtCoPayAmt, 10)) {
                    resolutionPage.enterCoPayAmt("0.0");
                    resolutionPage.clickAccept();
                }
            }
            Reporter.log("Resolution completed");
        }catch (Throwable e){
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Resolution not completed");
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void completeResolutionByUsingQualifiedMedicareBenificiryOption() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            ResolutionPage resolutionPage = new ResolutionPage();
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            if (resolutionPage.isElementDisplayed(resolutionPage.btnProblemResolved, 5)) {
                resolutionPage.clickProblemResolved();
                resolutionPage.clickQualifiedMedicareBeneficiary();
                resolutionPage.selectReason();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
                resolutionPage.clickAccept();
            } else {
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
                resolutionPage.clickDownTime();
                if (resolutionPage.isElementDisplayed(resolutionPage.txtCoPayAmt, 10)) {
                    resolutionPage.enterCoPayAmt("0.0");
                    resolutionPage.clickAccept();
                }
            }
            Reporter.log("Resolution completed");
        }catch (Throwable e){
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Resolution not completed");
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }


    public void clickAcceptButtonwithBlankTMCodeInModifyDetailsScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                String productName = orderSearch.getProductName(0);
                orderSearch.openFirstPatientRecord();
                if (!orderSearch.isFourPointPageDisplayed()) {
                    Assert.fail("FourPoint - page not loaded");
                }
                if (fourPoint.isElementDisplayed(fourPoint.cmbDrugReEntry, 30)) {
                    Assert.assertFalse(fourPoint.isElementEnabled(fourPoint.btnValidateReEntry));
                    System.out.print("index number"+fourPoint.getDrugReleaseType(productName));
                    fourPoint.selectValueFromTheListBasedOnIndex(fourPoint.cmbDrugReEntry, fourPoint.getDrugReleaseType(productName));
                    fourPoint.click(fourPoint.btnValidateReEntry);
                }
                modifyDetails.launchModifyDetailScreen();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.unSelectTmCodeField(2);
                modifyDetails.clickAccept();
                fourPoint.clickBtnCancel();
            }

        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyErrorMessageByProvidingDispenseQtyGreaterThanDaysSupplyInModifyDetailsScreen(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
                modifyDetails.clearDespQty();
                modifyDetails.enterDespQty(inputData.get("QUANTITY"));
                modifyDetails.clickAccept();
                Assert.assertEquals(inputData.get("VALIDATION_TEXT").trim(),inputPage.getValidationPopText().trim());
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                inputPage.clickOKButtonDEAPopup();
                inputPage.clickCancel();
                orderSearch.clickYes();

        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyRxMovedToResolutionQueue(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
            }
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                Assert.assertTrue(true);
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(name[0] + "," + name[1]);
                String problem=orderSearch.getProblemName(0);
                Assert.assertEquals(problem,inputData.get("PROBLEM_TEXT"));
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                Reporter.log("RX is in Resolve queue");
                orderSearch.closeSearch();
            }else {
                Assert.fail("RX not in Resolve queue");
                Reporter.log("RX not in Resolve queue");
            }

        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyM2RejectionPopUpAndClickYes(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            if (resolutionPage.isElementDisplayed(resolutionPage.btnSwithtoCash)) {
                resolutionPage.clickSwitchToCashButton();
                Assert.assertEquals(inputData.get("M2_REJECTION_TEXT"),inputPage.getValidationPopText());
                Reporter.log("M2 Rejection Pop up displayed with Yes and NO buttons and clicked on Yes button");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                inputPage.clickYesButtonInDAWValidationPopup();
                modifyDetails.selectReasonForSwitchToCash();
                modifyDetails.OkWarningClick();
            }else {
                Assert.fail("RX not in Resolve queue");
                Reporter.log("RX not in Resolve queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyM2RejectionPopUpAndClickNo(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();
            if (resolutionPage.isElementDisplayed(resolutionPage.btnSwithtoCash)) {
                resolutionPage.clickSwitchToCashButton();
                Assert.assertEquals(inputPage.getValidationPopText(),inputData.get("M2_REJECTION_TEXT"));
                Reporter.log("M2 Rejection Pop up displayed with Yes and NO buttons and clicked on No button");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
                inputPage.clickNoButtonInDAWValidationPopup();
            }else {
                Assert.fail("RX not in Resolve queue");
                Reporter.log("RX not in Resolve queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void verifyPrescriptionLessThanSixMonthsPopUpAndClickYes(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertEquals(inputData.get("PRESCRIPTION_TEXT"),inputPage.getValidationPopText());
            Reporter.log("Prescription must be dropped off and filled for the first time with in 6 months pop up should be displayed");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickButtonOk();
            inputPage.clickCancel();
            orderSearch.clickYes();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validatePaymentUpdateMessageInRXNotes(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            String productName = orderSearch.getProductName(0);
            rxNbr = orderSearch.getRxNbr(0);
            orderSearch.openFirstPatientRecord();
            menuBar.launchRxNotesScreen();
            String date = consolidatedNotesPage.getTxtDate().trim();
            String time = consolidatedNotesPage.getTxtTime().trim();
            String username = consolidatedNotesPage.getTxtUser().trim();
            String siteId = consolidatedNotesPage.getTxtSiteId().trim();
            String rxNumber = consolidatedNotesPage.getRxNbr().trim();
            String notes = consolidatedNotesPage.getTxtNotes().trim();
            String drugName = consolidatedNotesPage.getDrugName().trim();
            Reporter.log("Price Overridden message displayed in Rx notes");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            consolidatedNotesPage.clickCancel();
            consolidatedNotesPage.clickCancel();
            orderSearch.clickYes();
            Reporter.log("Rx notes card displayed with " + date + time + username + siteId + rxNumber + drugName + notes);
            Assert.assertEquals(notes, inputData.get("OVERRIDDEN_MESSAGE"));
            Assert.assertEquals(drugName.trim(), productName);
            Assert.assertEquals(siteId, propertyReader.getProperty("cnx.store"));
            Assert.assertEquals(username, propertyReader.getProperty("cnx.rph.userName"));
            Assert.assertEquals(rxNumber, rxNbr);
        }catch (Throwable e){
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log(" Price Overridden message not displayed in Rx notes");
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateM2RejectionMessageInRXNotes(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            String productName = orderSearch.getProductName(0);
            orderSearch.openFirstPatientRecord();
            menuBar.launchRxNotesScreen();
            String date = consolidatedNotesPage.getTxtDate().trim();
            String time = consolidatedNotesPage.getTxtTime().trim();
            String username = consolidatedNotesPage.getTxtUser().trim();
            String siteId = consolidatedNotesPage.getTxtSiteId().trim();
            String rxNumber = consolidatedNotesPage.getRxNbr().trim();
            String notes = consolidatedNotesPage.getTxtNotes().trim();
            String drugName = consolidatedNotesPage.getDrugName().trim();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            consolidatedNotesPage.clickCancel();
            consolidatedNotesPage.clickCancel();
            Reporter.log("Rx notes card displayed with " + date + time + username + siteId + rxNumber + drugName + notes);
            Assert.assertEquals(notes, inputData.get("M2_RX_NOTES_MESSAGE"));
            Assert.assertEquals(drugName.trim(), productName);
            Assert.assertEquals(siteId, propertyReader.getProperty("cnx.store"));
            Assert.assertEquals(username.toLowerCase(), propertyReader.getProperty("cnx.ho.userName"));
            Assert.assertEquals(rxNumber, rxNbr);
            Reporter.log("M2 rejection message displayed in Rx notes");
        }catch (Throwable e){
            isExceptionCaptured = true;
            Reporter.log("M2 Rejection message not displayed in Rx notes");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateDawValidationPopUpAndClickOnYesButton(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertEquals(inputData.get("DAW_VALIDATION_TEXT"),inputPage.getValidationPopText());
            Reporter.log("DAW validation Pop up displayed with Yes and NO buttons");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickYesButtonInDAWValidationPopup();

        } catch (Exception e) {
            isExceptionCaptured=true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateDxCodeInvalidDataPopUpAndClickOnYesButton(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertEquals(inputPage.getValidationPopText(),inputData.get("DX_CODE_VALIDATION_TEXT"));
            Reporter.log("Dx code Invalid Data pop up displayed by clicking Accept button without entering DX code in Input screen.");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickOKButtonDEAPopup();
        } catch (Exception e) {
            isExceptionCaptured=true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateInvalidDaysSupplyPopUpAndClickOnOkButton(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertEquals(inputData.get("VALIDATION_TEXT").trim(),inputPage.getValidationPopText().trim());
            Reporter.log("Invalid days supply pop up displayed when we enter quantity greater than 31");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickOKButtonDEAPopup();
            inputPage.clickCancel();
            orderSearch.clickYes();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateRxNotAllowedForGreaterThan35DaysSupplyPopUpAndClickOnOkButton(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertEquals(inputData.get("VALIDATION_TEXT").trim(),inputPage.getValidationPopText().trim());
            Reporter.log("Rx not allowed for greater than 35 days supply pop up displayed when we enter quantity greater than 35");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickOKButtonDEAPopup();
            inputPage.clickCancel();
            orderSearch.clickYes();
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateErrorMessageAndUpdateDispenseQuantity(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertEquals(inputData.get("VALIDATION_TEXT").trim(),inputPage.getValidationPopText().trim());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickOKButtonDEAPopup();
            inputPage.clickDispensedProductQty();
            inputPage.clearDispensedProductQty();
            inputPage.enterDispensedProductQty(inputData.get("EXTEND_QUANTITY"));
            inputPage.clickAccept();
            inputPage.clickYesOnValidateRxPopUp();
            inputPage.clickOnOutofStockPopupOk();
            inputPage.clickYesOnValidateRxPopUp();
            Reporter.log("Input completed");
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateErrorMessageInPopUpAndClickOnOkButton(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertEquals(inputData.get("VALIDATION_TEXT").trim(),inputPage.getValidationPopText().trim());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickOKButtonDEAPopup();
            inputPage.clickCancel();
            orderSearch.clickYes();
        } catch (Exception e) {
            isExceptionCaptured=true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }





    public void enterDxCodeAndClickOnAcceptButton() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            inputPage.inputRandomDXCode();
            if(inputPage.isTMCodeDisplayed()){
                inputPage.selectTmCodeField(2);
            }
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickAccept();
            inputPage.clickYesOnValidateRxPopUp();
            inputPage.clickOnOutofStockPopupOk();
            inputPage.clickYesOnValidateRxPopUp();
            Reporter.log("Input completed");
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateDawValidationPopUpAndClickOnNoButton(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            Assert.assertEquals(inputData.get("DAW_VALIDATION_TEXT"),inputPage.getValidationPopText());
            Reporter.log("DAW validation Pop up displayed with Yes and NO buttons and clicked on NO button");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickNoButtonInDAWValidationPopup();
        } catch (Exception e) {
            isExceptionCaptured=true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void selectNavigation(AppMenu menu, AppMenuItemsIndex menuNavigation, AppMenuSubItemsIndex subMenuNavigation, AppMenuSuperSubItemsIndex superSubMenuNavigation) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        Robot robot;
        try {
            String[] menuItems = menu.getAppMenu().split("->");
            menuBar.selectMenuItem(menuItems[0]);
            Reporter.logScreenShot(Status.PASS, menu.getAppMenu(), menuBar.takeScreenShot(currentStepMethodName).getValue());
            robot = new Robot();
            for (int i = 0; i < menuNavigation.getAppMenu(); i++) {
                automationManager.performSleep(1);
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            automationManager.performSleep(1);
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            automationManager.performSleep(2);
            robot.keyPress(KeyEvent.VK_UP);
            robot.keyRelease(KeyEvent.VK_UP);
            for (int i = 0; i < subMenuNavigation.getAppMenu(); i++) {
                automationManager.performSleep(2);
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            automationManager.performSleep(3);
            robot.keyPress(KeyEvent.VK_TAB);
            robot.keyRelease(KeyEvent.VK_TAB);
            automationManager.performSleep(2);
            robot.keyPress(KeyEvent.VK_UP);
            robot.keyRelease(KeyEvent.VK_UP);
            for (int i = 0; i < superSubMenuNavigation.getAppMenu(); i++) {
                automationManager.performSleep(2);
                robot.keyPress(KeyEvent.VK_DOWN);
                robot.keyRelease(KeyEvent.VK_DOWN);
            }
            Reporter.logScreenShot(Status.PASS, menu.getAppMenu(), menuBar.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(2);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
        } catch (Exception exception) {
            int count = 0;
            while (count < 3) {
                menuBar.pressKeys(KeyEvent.VK_ESCAPE);
                count++;
            }
        }
    }

    public void selectAuditTypeAnsClickOnSearchButton() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (loginPage.isElementDisplayed(loginPage.getErrorPopUpText)) {
                Assert.assertEquals("error Test",loginPage.getErrorPopUpText());
                Reporter.log("Warning Message For Standing Order For The Prescriber Got Expired Is Displayed");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
                loginPage.clickOk();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Assert.fail("Warning Message For Standing Order For The Prescriber Got Expired Is not Displayed");
                Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            }
        } catch (Exception e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, loginPage.takeScreenShot(currentStepMethodName).getValue());
            SoftAssert softAssert = new SoftAssert();
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public int getActivityCode(){
        String query = "select activity_code  from rx_activity order by activity_ts desc";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        int activity_code = Integer.parseInt(rxInfo.get("activity_code").toString());
        System.out.println("Filld is "+activity_code);
        return activity_code;
    }

    public void validateTriplicateNumber(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            orderSearch.selectRowFromSearch(0);
            inputPage.enterProductNameInPrescribedProduct(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.enterPrescriber(inputData.get("PRESCRIBER_NAME"));
            Assert.assertTrue(inputPage.isTriplicateDisplayed());
            Reporter.logScreenShot(Status.PASS, "Triplicate Number is displayed for Non CS drug", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickCancel();
            inputPage.clickYesOnAbondonPopup();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
        }
    }

    public void validateRxExpiryDateFromEFD(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.performSearch(name[0] + "," + name[1], SearchType.PatientRx);
            orderSearch.selectRowFromSearch(0);
            String DefaultEFD = inputPage.getEarliestFillDate();
            Reporter.log("DefaultEFD" + DefaultEFD);
            String DefaultExpDate = inputPage.getExpirationDate();
            Reporter.log("DefaultExpDate" + DefaultExpDate);
            Reporter.logScreenShot(Status.PASS, "Input screen with Default EFD and Default Rx expiry Date", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.enterProductNameInPrescribedProduct(inputData.get("DRUG_NAME"));
            inputPage.enterPrescribedQty(inputData.get("QUANTITY"));
            inputPage.enterSigCode(inputData.get("SIG"));
            inputPage.enterRefillQty(inputData.get("REFILLS"));
            inputPage.clickEarliestFillDateCheckBox();
            inputPage.EFDDateSelection(5);
            
            // Use Java 8+ date API to avoid DST issues
            String efdDateStr = inputPage.getEarliestFillDate();
            String expDateStr = inputPage.getExpirationDate();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate efdDate = LocalDate.parse(efdDateStr, formatter);
            LocalDate expDate = LocalDate.parse(expDateStr, formatter);
            long daysDifference = ChronoUnit.DAYS.between(efdDate, expDate);
            
            String UpdatedEFD = efdDateStr;
            Reporter.log("UpdatedEFD: " + UpdatedEFD);
            String UpdatedExpDate = expDateStr;
            Reporter.log("UpdatedExpDate: " + UpdatedExpDate);
            Reporter.log("daysDifference: " + daysDifference);
            Assert.assertEquals(daysDifference, 30, "RX Expiry should be exactly 30 days from EFD");
            Reporter.logScreenShot(Status.PASS, "Updated Rx Expiry Date", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            inputPage.clickCancel();
            inputPage.clickYesOnAbondonPopup();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            // Re-throw preserving original exception type to ensure TestNG marks the test as FAILED
            if (e instanceof Error) {
                throw (Error) e;  // Includes AssertionError, OutOfMemoryError, etc.
            }
            if (e instanceof RuntimeException) {
                throw (RuntimeException) e;  // Includes NullPointerException, IllegalArgumentException, etc.
            }
            // Only wrap checked exceptions (IOException, ParseException, etc.)
            throw new RuntimeException("Test failed: " + e.getMessage(), e);
        }
    }

    /*
     * Method to drop Rx and move to ChkDUR using API
     */
    public String performCreateOrderAndMoveTocheckDUR(Map<String, String> inputData) {
        try {
            int numRefills = Integer.parseInt(inputData.get("REFILLS"));
            String ndc = inputData.get("DRUG_NAME1");
            int strNbr = Integer.parseInt(inputData.get("STORE_NUMBER"));
            Reporter.log("Dropping RX and moving it to ChkDUR using API in store "+ strNbr);
            inputResp = connexusAPIManager.createOrderAndMoveTocheckDUR(patientId, strNbr, numRefills, ndc, connexusAPIManager.PrescriberDetails());
            rxNbr = String.valueOf(inputResp.getRxNbr());
            return rxNbr;
        }
        catch (Exception e) {
            isExceptionCaptured = true;
            Assert.fail("Error while creating order and moving to check DUR using API "+e.getMessage());
            return null;
        }
    }

    /*
     * Method to update patient's Gender Identity using API
     */
    public void createPatientAndUpdateGenderIdentity(Map<String, String> inputData) {
        int strNbr = Integer.parseInt(inputData.get("STORE_NUMBER"));
        Reporter.log("Creating patient using create patient API in store "+strNbr);
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        patientName = name[0] + "," + name[1];
        patientId = createPatientUsingApi(inputData, strNbr, patientName);
        Reporter.log("Updating patient's Gender Identity to " + inputData.get("GENDER_IDENTITY") + " using update patient API");
        updatePatientData(inputData, name[1], name[0], strNbr, false, patientId);
        Reporter.log("Updated patient's Gender Identity to "+inputData.get("GENDER_IDENTITY") + " in store "+strNbr);
    }
    /*
     * Method to serach patient in Connexus and host lookup patient with patient name and DOB
     */
    public void patientSearchInConnexus(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientSearchPage.launchPatientSearchScreen();
            String patientDOB = inputData.get("DOB");
            patientSearchPage.inputPatientName(patientName);
            patientSearchPage.inputPatientDob(patientDOB);
            patientSearchPage.clickSearchNow();
            patientSearchPage.hostSearchPatient();
            Reporter.logScreenShot("Patient serach host lookup", patientMaintenancePage.takeScreenShot());
            patientSearchPage.openMatchingPatientRecord(patientName, patientDOB);

        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot());
            Reporter.log("Failed to open patient maintenance screen for patient: " + e.getMessage());
            loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
            Assert.fail(e.toString());
        }
    }

    /*
     * Method to validate patient's Gender Identity in PMS
     */
    public void validatePatientGenderIdentity(Map<String, String> inputData) {
        try {
            patientMaintenancePage = new  PatientMaintenancePage();
            String[] name = patientName.split(",");
            String lastName = name[0];
            String firstName = name[1];
            connexusAppUtils.addRandomNamesInFile(lastName, firstName);
            patientSearchInConnexus(inputData);
            String GenderIdentity = patientMaintenancePage.getGenderIdentity();
            Reporter.logScreenShot("Patient Maintenance Screen", patientMaintenancePage.takeScreenShot());
            Reporter.log("Gender Identity in PMS: " + GenderIdentity);
            Assert.assertEquals(GenderIdentity, inputData.get("GENDER_IDENTITY"));
        }
        catch (Exception e) {
            isExceptionCaptured = true;
            Assert.fail("Error while validating patient data in PMS "+e.getMessage());
            Assert.fail();
        }
    }

    public void performInputWithBlankTMCode(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxModel.setPatientLastName(name[0]);
            rxModel.setPatientFirstName(name[1]);
            rxModel.setNdc(inputData.get("DRUG_NAME"));
            rxModel.setPrescribedQty(inputData.get("QUANTITY"));
            rxModel.setSigCode(inputData.get("SIG"));
            rxModel.setNoOfRefills(inputData.get("REFILLS"));
            rxModel.setPrescriberName(inputData.get("PRESCRIBER_NAME"));
            String rxStatus = orderSearch.getRXStatusForPatient(name[0]+","+name[1],0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.INPUT.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().performInputWithBlankTMCode(rxModel);
            } else {
                Reporter.log("RX is not in Input queue");
                Assert.fail();
            }
            connexusAppUtils.writeTextToFile("Input Completed","In progress","E2E_execution_status.txt",30, DateTime.now());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Input queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            connexusAppUtils.writeTextToFile("Input not Completed","Failed","E2E_execution_status.txt",30, DateTime.now());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

}
