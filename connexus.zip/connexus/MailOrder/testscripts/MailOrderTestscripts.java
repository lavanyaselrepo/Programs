package connexus.MailOrder.testscripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import connexus.coretest.cardcreation.CreditCardFlowsFunctions;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.Assert;
import java.util.List;
import java.util.Map;

public class MailOrderTestscripts extends ConnexusTestScripts {

    CreditCardFlowsFunctions creditCardFlowsFunctions = new CreditCardFlowsFunctions(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    public MailOrderTestscripts(LoginAs.userType loginUserType) {
        super(loginUserType);
    }

    public void editCreditCardAndValidateDB(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            creditCardFlowsFunctions.editCreditCardForPatient();
            patientSearchPage.clickEasyPayAccount();

            patientMaintenancePage.isValidateButtonDisabledIfPresent();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Validate button is disabled");

            patientMaintenancePage.mouseHoverOnCard(0);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("tooltip message displayed");

            String cardHolderName = inputData.get("cardHolderName");
            String query = "SELECT card_validity_stat_code, last_validated_ts FROM phm_pymt_acct WHERE card_holder_name = '" + cardHolderName + "' ORDER BY last_validated_ts DESC";
            Reporter.log("Card details: " + query);
            List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
            String card_validity_stat_code = result.get(0).get("card_validity_stat_code").toString();
            String last_validated_ts = result.get(0).get("last_validated_ts").toString();

            Reporter.log("card_validity_stat_code=" + card_validity_stat_code + ",last_validated_ts=" + last_validated_ts);
            Assert.assertEquals(card_validity_stat_code, "25342", "card_validity_stat_code not VALID");
            Assert.assertNotNull(last_validated_ts, "last_validate_timestamp is null");
        } catch (Throwable e) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }
}