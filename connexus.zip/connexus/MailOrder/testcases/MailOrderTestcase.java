package connexus.MailOrder.testcases;
import connexus.MailOrder.testscripts.MailOrderTestscripts;
import connexus.RXPD.testScripts.RXPDTestScripts;
import connexus.coretest.cardcreation.CreditCardFlowsFunctions;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.util.Map;

public class MailOrderTestcase {
    CreditCardFlowsFunctions creditCardFlowsFunctions = new CreditCardFlowsFunctions(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    RXPDTestScripts rxpdTestScripts = new RXPDTestScripts(LoginAs.userType.PHARMACIST_ADFlagOff);
    MailOrderTestscripts mailOrderTestscripts = new MailOrderTestscripts(LoginAs.userType.HOMEOFFICE_ADFlagOn);
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();

    @BeforeClass
    public void loginToConnexus() {
        connexusAppUtils.startAppiumServer();
        creditCardFlowsFunctions.loginConnexus(LoginAs.userType.HOMEOFFICE_ADFlagOn);
        connexusAPIManager = new ConnexusAPIManager();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    @Test(enabled = true, description = "HWPHME2E-1853 Mail order payment card Edit Existing Card - successful",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/MailOrder/MailOrder.json", sheetName = "mailOrder")
    public void HWPHME2E_1853_Mail_order_payment_card_Edit_Existing_Card_successful(Map<String, String> inputData) {
        Reporter.log("HWPHME2E-1853 Mail order payment card Edit Existing Card - successful");
        connexusAppUtils.getStoreId();
        mailOrderTestscripts.initializeTestCase(true);
        //add new card to patient profile
        creditCardFlowsFunctions.addMasterCreditCardInPatientProfile(inputData);
        //edit credit card and validate
        mailOrderTestscripts.editCreditCardAndValidateDB(inputData);
        Reporter.log("HWPHME2E-1853 Mail order payment card Edit Existing Card - successful");

    }
    @Test(description = "AutoFill RX: Drop with Future priority and set Pick Up TS as tomorrow past 1 PM",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/Connexus/MailOrder/MailOrder.json", sheetName = "mailOrder")
    public void HWPHME2E_1851_AutoFill_FuturePriority_PickupTomorrowAfter1PM(Map<String, String> inputData) {
        Reporter.log("HWPHME2E_1851 Drop RX with Future priority and set Pick Up TS as tomorrow past 1 PM");
        int storeNbr = connexusAppUtils.getStoreId();
        mailOrderTestscripts.initializeTestCase(true);
        //create patient and move till pick up with Future priority and select  pickup time tomorrow past 1 PM
        rxpdTestScripts.createPatientAndMoveToPickup(inputData,storeNbr);
        //Validate Future Priority and pick up time in DB
        rxpdTestScripts.validateFuturePriorityAndPickupTimeInDB();
        Reporter.log("HWPHME2E_1851 Drop RX with Future priority and set Pick Up TS as tomorrow past 1 PM");
    }
}