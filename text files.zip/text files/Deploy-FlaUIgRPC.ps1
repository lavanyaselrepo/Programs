<#
.SYNOPSIS
    Builds the FlaUI gRPC Server locally and deploys it to a remote RXPC machine.

.DESCRIPTION
    1. Checks for .NET 8 SDK (installs via winget if missing)
    2. Publishes the C# server as a self-contained Windows x64 single-file exe
    3. Copies the publish folder to \RXPC\C$\FlaUIgRPC\ via admin share
    4. Opens firewall port 50051 on the RXPC via PSRemoting (Invoke-Command)
    5. Starts FlaUIgRPC.Server.exe on the RXPC
    6. Verifies the server is reachable from this machine

.PARAMETER RxpcHostname
    FQDN or hostname of the target RXPC machine.
    Example: RXPC72421582991.s05511.us.wal-mart.com

.PARAMETER Port
    gRPC server port (default: 50051)

.PARAMETER SkipBuild
    Skip the dotnet publish step and reuse the last publish output.

.PARAMETER Credential
    PSCredential for remote operations. Omit to use current Windows credentials.

.EXAMPLE
    .\Deploy-FlaUIgRPC.ps1 -RxpcHostname "RXPC72421582991.s05511.us.wal-mart.com"
    .\Deploy-FlaUIgRPC.ps1 -RxpcHostname "RXPC72421582991.s05511.us.wal-mart.com" -SkipBuild
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$RxpcHostname,
    [int]$Port = 50051,
    [switch]$SkipBuild,
    [System.Management.Automation.PSCredential]$Credential
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Walmart proxy — needed for dotnet restore on Walmart network
$env:HTTP_PROXY  = 'http://sysproxy.wal-mart.com:8080'
$env:HTTPS_PROXY = 'http://sysproxy.wal-mart.com:8080'

$ScriptDir    = $PSScriptRoot
$ServerDir    = Join-Path $ScriptDir 'grpc-server\FlaUIgRPC.Server'
$PublishDir   = Join-Path $ServerDir 'publish'
$PublishedExe = Join-Path $PublishDir 'FlaUIgRPC.Server.exe'
$RemotePath   = 'C:\FlaUIgRPC'
$RemoteExe    = "$RemotePath\FlaUIgRPC.Server.exe"
$LogDir       = "$RemotePath\logs"

# ================================================================
# Helpers — defined first so all callers below can use them
# ================================================================
function Write-Step { param($m) Write-Host "`n[>>] $m" -ForegroundColor Cyan }
function Write-Ok   { param($m) Write-Host "  [OK]   $m" -ForegroundColor Green }
function Write-Warn { param($m) Write-Host "  [WARN] $m" -ForegroundColor Yellow }
function Write-Fail { param($m) Write-Host "  [FAIL] $m" -ForegroundColor Red }

function Invoke-Remote {
    param([string]$Host, [scriptblock]$Sb)
    $p = @{ ComputerName = $Host; ScriptBlock = $Sb }
    if ($Credential) { $p['Credential'] = $Credential }
    Invoke-Command @p
}

function Show-ManualFallback {
    Write-Host @"

  ===== MANUAL FALLBACK (do these steps on the RXPC via RDP) =====

  RDP into: $RxpcHostname

  Then run in PowerShell (as Admin):

    # 1. Create folders
    New-Item -ItemType Directory -Path C:\FlaUIgRPC\logs -Force

    # 2. Copy the .exe from your machine to C:\FlaUIgRPC\ on the RXPC
    #    Source on your machine: $PublishedExe
    #    Use RDP clipboard or another transfer method.

    # 3. Open firewall
    netsh advfirewall firewall add rule name="FlaUI gRPC Server" dir=in action=allow protocol=TCP localport=$Port

    # 4. Start the server
    Start-Process -FilePath C:\FlaUIgRPC\FlaUIgRPC.Server.exe -WindowStyle Hidden

    # 5. Verify from your dev machine
    Test-NetConnection -ComputerName $RxpcHostname -Port $Port

  =================================================================
"@
}

# ================================================================
# STEP 1 — Check / install .NET 8 SDK
# ================================================================
Write-Step 'Checking .NET 8 SDK'
try {
    $ver = & dotnet --version 2>$null
    if ($ver -match '^8\.') {
        Write-Ok ".NET SDK $ver is installed."
    } else {
        throw "Wrong SDK version detected: $ver (need 8.x)"
    }
} catch {
    Write-Warn '.NET 8 SDK not found — attempting winget install...'
    winget source update --name winget --accept-source-agreements 2>$null
    winget install Microsoft.DotNet.SDK.8 `
        --accept-package-agreements --accept-source-agreements --source winget
    $env:Path = [System.Environment]::GetEnvironmentVariable('Path','Machine') + ';' +
                [System.Environment]::GetEnvironmentVariable('Path','User')
    $ver = & dotnet --version 2>$null
    Write-Ok "Installed .NET SDK $ver"
}

# ================================================================
# STEP 2 — Build (publish self-contained exe)
# ================================================================
if (-not $SkipBuild) {
    Write-Step 'Publishing FlaUIgRPC.Server (self-contained win-x64 single-file)'

    if (-not (Test-Path $ServerDir)) {
        Write-Fail "Server source not found at: $ServerDir"; exit 1
    }

    Push-Location $ServerDir
    try {
        & dotnet publish `
            -c Release `
            -r win-x64 `
            --self-contained true `
            '-p:PublishSingleFile=true' `
            -o $PublishDir
        if ($LASTEXITCODE -ne 0) {
            Write-Fail 'dotnet publish failed — see output above.'; exit 1
        }
    } finally {
        Pop-Location
    }
    Write-Ok "Published to: $PublishDir"
} else {
    Write-Warn '-SkipBuild set — reusing existing publish output.'
}

if (-not (Test-Path $PublishedExe)) {
    Write-Fail "Expected exe not found: $PublishedExe"; exit 1
}
$sizeMB = [math]::Round((Get-Item $PublishedExe).Length / 1MB, 1)
Write-Ok "Exe ready: $PublishedExe ($sizeMB MB)"

# ================================================================
# STEP 3 — Copy to RXPC via admin share (C$)
# ================================================================
Write-Step "Copying files to \$RxpcHostname\C`$\FlaUIgRPC"

$uncDest = "\$RxpcHostname\C`$\FlaUIgRPC"
$uncLogs = "$uncDest\logs"

try {
    if (-not (Test-Path $uncDest)) {
        New-Item -ItemType Directory -Path $uncDest -Force | Out-Null
    }
    if (-not (Test-Path $uncLogs)) {
        New-Item -ItemType Directory -Path $uncLogs -Force | Out-Null
    }

    # Stop any running server so we can overwrite the locked exe
    Write-Warn 'Stopping existing server process on RXPC (if running)...'
    try {
        Invoke-Remote $RxpcHostname {
            Stop-Process -Name 'FlaUIgRPC.Server' -Force -ErrorAction SilentlyContinue
        }
        Start-Sleep -Seconds 2
    } catch { Write-Warn "Could not stop remote process (non-fatal): $_" }

    Copy-Item -Path "$PublishDir\*" -Destination $uncDest -Recurse -Force
    Write-Ok 'Files copied successfully.'

} catch {
    Write-Fail "Cannot copy via admin share: $_"
    Write-Host ''
    Write-Warn 'This usually means the RXPC admin share (C$) is blocked or you lack local-admin rights.'
    Show-ManualFallback
    exit 1
}

# ================================================================
# STEP 4 — Open firewall port on RXPC
# ================================================================
Write-Step "Opening TCP port $Port in Windows Firewall on RXPC"

# Build the firewall command as a string — avoids heredoc quoting headaches
$fwCmd = "netsh advfirewall firewall add rule name='FlaUI gRPC Server' dir=in action=allow protocol=TCP localport=$Port"
$fwCheck = "netsh advfirewall firewall show rule name='FlaUI gRPC Server'"

try {
    Invoke-Remote $RxpcHostname ([scriptblock]::Create(@"
        `$check = & cmd /c '$fwCheck' 2>`$null
        if (`$check -notmatch 'No rules match') {
            Write-Host 'Firewall rule already exists.'
        } else {
            & cmd /c '$fwCmd' | Out-Null
            Write-Host 'Firewall rule added: port $Port open.'
        }
"\@))
    Write-Ok "Port $Port is open."
} catch {
    Write-Warn "Firewall step failed (may already be open, continuing): $_"
}

# ================================================================
# STEP 5 — Start the gRPC server on RXPC
# ================================================================
Write-Step 'Starting FlaUIgRPC.Server.exe on RXPC'

try {
    Invoke-Remote $RxpcHostname ([scriptblock]::Create(@"
        `$exe = '$RemoteExe'
        if (-not (Test-Path `$exe)) { throw "Server exe not found at: `$exe" }
        Stop-Process -Name 'FlaUIgRPC.Server' -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 1
        Start-Process -FilePath `$exe -WindowStyle Hidden
        Start-Sleep -Seconds 4
        `$proc = Get-Process -Name 'FlaUIgRPC.Server' -ErrorAction SilentlyContinue
        if (`$proc) {
            Write-Host "Server running (PID `$(`$proc.Id))"
        } else {
            throw 'Process did not start — check logs at $LogDir'
        }
"\@))
    Write-Ok 'Server process is running on RXPC.'
} catch {
    Write-Fail "Failed to start server: $_"
    Show-ManualFallback
    exit 1
}

# ================================================================
# STEP 6 — Verify connectivity from THIS machine
# ================================================================
Write-Step "Verifying TCP connectivity to $RxpcHostname`:$Port"

Start-Sleep -Seconds 3
$connected = $false

for ($i = 1; $i -le 5; $i++) {
    try {
        $tcp  = [System.Net.Sockets.TcpClient]::new()
        $conn = $tcp.BeginConnect($RxpcHostname, $Port, $null, $null)
        if ($conn.AsyncWaitHandle.WaitOne(3000, $false) -and $tcp.Connected) {
            $connected = $true
            $tcp.Close()
            break
        }
        $tcp.Close()
    } catch { }
    Write-Warn "Attempt $i/5 — not yet reachable, waiting 3s..."
    Start-Sleep -Seconds 3
}

if (-not $connected) {
    Write-Fail "Cannot reach $RxpcHostname`:$Port after 5 attempts."
    Write-Host '  Checklist:'
    Write-Host '    1. Firewall rule added?  -> netsh advfirewall firewall show rule name="FlaUI gRPC Server"'
    Write-Host '    2. Process running?      -> Get-Process FlaUIgRPC.Server'
    Write-Host '    3. Server log?           -> Get-Content C:\FlaUIgRPC\logs\flaui-grpc-*.log -Tail 20'
    Write-Host '    4. VPN / Eagle WiFi connected?'
    exit 1
}

# ================================================================
# All done!
# ================================================================
Write-Host ''
Write-Host '================================================' -ForegroundColor Green
Write-Host '  FlaUI gRPC Server deployed successfully!'     -ForegroundColor Green
Write-Host "  Host : $RxpcHostname"                        -ForegroundColor Green
Write-Host "  Port : $Port"                                -ForegroundColor Green
Write-Host "  Logs : \$RxpcHostname\C`$\FlaUIgRPC\logs" -ForegroundColor Green
Write-Host '================================================' -ForegroundColor Green
Write-Host ''
Write-Host 'Run your tests now:' -ForegroundColor Cyan
Write-Host "  mvn clean test ``"
Write-Host "    "-Dsurefire.suiteXmlFiles=src/test/resources/suites/connexus/grpc_poc/Validate_gRPC_CashFlow_E2E.xml" ``"
Write-Host "    "-Dapp.driver.type=grpc" ``"
Write-Host "    "-Dgrpc.server.host=$RxpcHostname" ``"
Write-Host "    "-Dgrpc.server.port=$Port""
Write-Host ''