# Dragon Framework

<p align="center">
  <img src="src/main/resources/images/dragon.gif" width="350" >
</p>

---

## Overview

**Dragon Framework** is an all-in-one automation solution for testing:

- Windows applications
- Mobile applications
- Websites
- APIs
- Databases
- Kafka queues

---

## Features

- Centralized `AutomationManager` for orchestrating automation tasks
- Session management for Connexus, Boss, Storing, and Dispense apps (create or attach as needed)
- Database connectivity (Informix, DB2, SQL Server, CosmosDB) with Spring `JdbcTemplate`
- REST operations: GET, POST, PUT
- Kafka connectors for publishing and consuming messages
- Slack integration for posting messages and uploading files
- JIRA integration for updating test run status and uploading attachments
- Azure AppVault and CCM integration for secure cloud key retrieval
- RSA and AES encryption/decryption utilities
- Data provider for reading input from Excel files
- ExtentReports integration for reporting (Slack and Test Burst)

---

## Getting Started

- **Java Version:** Use Java 21 (Zulu flavor). More info: [Dragon Framework - Updating to Java 21](https://confluence.walmart.com/display/HWAREA/Dragon+Framework+-+Updating+to+Java+21)
- **Repository:** [AutomationBaseFramework](https://gecgithub01.walmart.com/CustomerTechnologies/AutomationBaseFramework)

### Clone the Repository

```sh
git clone https://gecgithub01.walmart.com/CustomerTechnologies/AutomationBaseFramework.git
```

### Install Dependencies

```sh
mvn clean install -DskipTests
```

### Import Project in Eclipse

1. Go to `File` → `Import...`
2. Select `Maven` → `Existing Maven Projects`
3. Choose the root directory of your cloned project
4. Click `OK` and `Finish`

### Running Tests

- In Eclipse, expand `src/test/java/<package>` in Project Explorer or Navigator
- Right-click the desired Java class → `Run As` → `TestNG Test`
- You can also run entire suites as needed

---

## Database Connectivity

- Uses Spring `JdbcTemplate` for database access
- Connections are determined by store numbers or `config.properties`
- Supports insert, update, delete, and select operations
- Maps data to POJO classes

---

## Sample Test Code

```java
public class Sample {
    AutomationManager am = AutomationManager.getInstance();
    @Jira(testID = "PROJECT-1234")
    @Test(priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getData")
    @DataProviderArguments(filePath = "TestData/Sample/SampleExcel.xlsx", sheetName = "sheet1")
    public void sampleTest(int x, float y, boolean isTrue) {
        am.getSlack().postToSlack("value of x:" + x + ", value of y:" + y + ", result:" + isTrue);
        Assert.assertTrue(true);
    }
}
```

---

## CI/CD & Status

- [Build Status ![Build Status](https://ci.walmart.com/buildStatus/icon?job=/DragonBuilder)](https://ci.walmart.com/job/DragonBuilder)
- [Looper Project](https://ci.walmart.com/job/DragonBuilder)
- [Concord Repo](https://concord.prod.walmart.com/#/org/HWPharmacy_QE/project/DragonAutomationRunner/process)

---

## Pull Request Guidelines

- Please follow the [Pull Request Guidelines](https://collaboration.wal-mart.com/pages/viewpage.action?pageId=643926006)

---

For more details, refer to the internal Confluence page or contact the maintainers.

### Access to the Repo

In order to contribute to the repo, you need to be a member of Customer Technologies Org in GitHub. To get yourself added to the Org, log a request at https://walmartglobal.service-now.com/wm_sp?id=sc_cat_item_guide&sys_id=f74b28b687f305107d7762cd0ebb356c
