package clinicalservices.Immunization.testcases;

import clinicalservices.Immunization.testScripts.ImzTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;


public class ImzRegistryTestCases {

    ImzTestScripts imzTestScripts= new ImzTestScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();


    @BeforeClass
    public void startAppiumServer() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Validate New Patient |Patient Profile|IMZ Registry Value
    * Pre-Conditions:
            28750 should set to false in order to login as Pharmacist
    ----------------------------------------------------------------------------------------------------------*/

    //@Jira(testID = "HWPHME2E-3106")

    @Test(enabled = true, description = "Validate New Patient |Patient Profile|IMZ Registry Value", priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZRegistryTestData")
    public void HWPHME2E_3106_Validate_IMZ_Registry_For_New_Patient(Map<String, String> appointmentInfo) throws SQLException, ParserConfigurationException, IOException, SAXException {

        Reporter.log("HWPHME2E-3106-->Validate IMZ Registry in PMS for new patient");

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzTestScripts.createNewPatientImz(appointmentInfo);
        imzTestScripts.validateImzRegistryFromPMS(appointmentInfo);
        Reporter.log("HWPHME2E-3106-->Completed Validation of IMZ Registry in PMS for new patient");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Validate ERX |Patient Profile|IMZ Registry Value
    * Pre-Conditions:
            28750 should set to false in order to login as Pharmacist
    ----------------------------------------------------------------------------------------------------------*/

    //@Jira(testID = "HWPHME2E-3105")

    @Test(enabled = true, description = "Validate ERX |Patient Profile|IMZ Registry Value", priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZRegistryTestData")
    public void HWPHME2E_3105_Validate_IMZ_Registry_After_Dropping_ERX(Map<String, String> appointmentInfo) throws SQLException, ParserConfigurationException, IOException, SAXException {
        /*PreConditions: 28750 should set to false in order to login as Pharmacist*/
        Reporter.log("HWPHME2E-3105--> Validate IMZ Registry in PMS after dropping an ERX");

        String xmlPayload="src//test//resources//TestData//Connexus//ERXpayload.xml";

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzTestScripts.createNewPatientImz(appointmentInfo);
        imzTestScripts.performERXImz(appointmentInfo,xmlPayload);
        imzTestScripts.verifyOrderStatusAfterDroppingERX();
        imzTestScripts.validateImzRegistryFromPMS(appointmentInfo);
        Reporter.log("HWPHME2E-3105--> Completed Validation of IMZ Registry in PMS after dropping an ERX");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Update IMZ registry to No and drop ERX |Validate IMZ Registry
    * Pre-Conditions:
            28750 should set to false in order to login as Pharmacist
    ----------------------------------------------------------------------------------------------------------*/


    @Test(enabled = true, description = "Update IMZ registry to No and drop ERX |Validate IMZ Registry", priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZRegistryTestData")
    public void HWPHME2E_3109_Update_IMZ_Registry_No_And_Validate_IMZ_Registry_After_Dropping_ERX(Map<String, String> appointmentInfo) throws SQLException, ParserConfigurationException, IOException, SAXException {

        Reporter.log("HWPHME2E-3109--> Validate IMZ Registry No in PMS after dropping an ERX");

        String xmlPayload="src//test//resources//TestData//Connexus//ERXpayload.xml";

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzTestScripts.createNewPatientImz(appointmentInfo);
        imzTestScripts.selectIMZRegistryValueNoForPatient(appointmentInfo);
        imzTestScripts.performERXImz(appointmentInfo,xmlPayload);
        imzTestScripts.verifyOrderStatusAfterDroppingERX();
        imzTestScripts.validateImzRegistryNoFromPMS();
        Reporter.log("HWPHME2E-3109--> Completed Validation of IMZ Registry No in PMS after dropping an ERX");
    }
    @Test(enabled = true, description = "Validate Host Profile for a patient|Patient Profile|IMZ Registry Value", priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZRegistryTestData")
    public void HWPHME2E_3104_Validate_Host_Profile_for_A_Patient_IMZ_Registry_After_Getting_A_Host_Profile(Map<String, String> appointmentInfo) throws  InterruptedException {

        Reporter.log("HWPHME2E-3104--> Validate IMZ Registry Yes in PMS after getting a host profile");

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        imzTestScripts.restartService();
        imzTestScripts.performCreatePatientThroughAPI(appointmentInfo);
        imzTestScripts.performUpdatePatientThroughAPI(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzTestScripts.validateIMZRegistryYesForHostProfileFromPMS(appointmentInfo);
        Reporter.log("HWPHME2E-3104--> Completed Validation of IMZ Registry Yes in PMS after dropping an ERX");
    }
    @Test(enabled = true, description = "Update IMZ registry to No and get a host profile|Validate IMZ Registry", priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZRegistryTestData")
    public void HWPHME2E_3110_Update_IMZ_Registry_No_And_Validate_IMZ_Registry_After_Getting_A_Host_Profile(Map<String, String> appointmentInfo) throws InterruptedException {
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        imzTestScripts.restartService();
        imzTestScripts.performCreatePatientThroughAPI(appointmentInfo);
        imzTestScripts.performUpdatePatientThroughAPI(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzTestScripts.validateIMZRegistryNoForHostProfileFromPMS(appointmentInfo);
    }
    @Test(enabled = true, description = "Validate STS Patient Profile IMZ Registry Value", priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZRegistryTestData")
    public void HWPHME2E_3107_Validate_STS_Patient_Profile_IMZ_Registry_Value(Map<String, String> appointmentInfo) throws InterruptedException {
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        imzTestScripts.restartService();
        imzTestScripts.performCreatePatientAndCompleteTillEOD(appointmentInfo);
        imzTestScripts.performUpdatePatientThroughAPI(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzTestScripts.validateIMZRegistryYesInPMSFromDropOff(appointmentInfo);
    }
    @Test(enabled = true, description = "Update IMZ registry to No and get a host profile in different store and Validate IMZ Registry in PMS", priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZRegistryTestData")
    public void HWPHME2E_3111_Update_IMZ_Registry_No_And_Drop_STS_To_Validate_Registry(Map<String, String> appointmentInfo) throws InterruptedException {
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        imzTestScripts.restartService();
        imzTestScripts.performCreatePatientAndCompleteTillEOD(appointmentInfo);
        imzTestScripts.performUpdatePatientThroughAPI(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzTestScripts.validateIMZRegistryNoInPMSFromDropOff(appointmentInfo);
    }
}