package clinicalservices.Immunization.testcases;

import clinicalservices.Immunization.testScripts.ImzSettingsTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class ImzSettingsTestSet {

    ImzSettingsTestScript imzSettingsTestScript = new ImzSettingsTestScript();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    PropertyReader prop = PropertyReader.getInstance();
    String siteId = prop.getProperty("cnx.store");
    String stateCode = "";

    public void imzFlagsSetUP(Map<String, String> inputData) {

        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        Reporter.log("Login to Pharmacist flag Disabled");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        // Turn ON  IMZ settings flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14102");
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14108");
        //restart services
        connexusAPIManager.restartConnexusService(siteId);
    }

    @BeforeClass
    public void startAppiumServer() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }


    /*----------------------------------------------------------------------------------------------------------
     * Test Description: SO - Edit enable date from sonic UI and check connexus immunization settings
     * Jira(testID = "HWPHME2E-3139")
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate SO Protocol Edit enable date from sonic UI and check connexus immunization settings",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZSettingsTestData")
    public void HWPHME2E_3139_Validate_SO_Protocol_Edit_enable_date_from_sonic_API_and_verify_connexus_UI_immunization_settings(Map<String, String> inputData) {
        Reporter.log("Validate SO Protocol Edit enable date from sonic UI and check connexus immunization settings");

        //Pre-condition
        imzFlagsSetUP(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndcNbr1"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndcNbr2"));
        imzSettingsTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Launch IMZ Event screen
        imzSettingsTestScript.createCloudServiceSettingsSO(inputData);
        //Validate service_pre_auth using store_pre_auth_id obtained from the response in Step 1
        imzSettingsTestScript.validatdeServicePreAuthId();
        //Validate the IMZ SO settings in Connexus
        imzSettingsTestScript.validateImzSoSettingsFields(inputData);
        Reporter.log("Immunization Settings SO protocol created successfully and validated required fields in Connexus UI successfully");
    }
}
