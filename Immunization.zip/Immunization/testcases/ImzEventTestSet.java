package clinicalservices.Immunization.testcases;

import clinicalservices.Immunization.testScripts.ImzEventTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class ImzEventTestSet {

    ImzEventTestScript imzEventTestScript = new ImzEventTestScript();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    PropertyReader prop = PropertyReader.getInstance();
    String siteId = prop.getProperty("cnx.store");
    String stateCode = "";

    public void imzEventFlagsSetUP(Map<String, String> inputData) {

        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        Reporter.log("Login to Pharmacist flag Disabled");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        // Turn ON  IMZ settings flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14102");
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14108");
        //restart services
        connexusAPIManager.flushCache(siteId);
    }

    @BeforeClass
    public void startAppiumServer() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }


    /*----------------------------------------------------------------------------------------------------------
    * Test Description: [IMZ Event]Validate multiple NDCs of a Product can be used in the same event while creating an event
    *  and Validate appropriate details updated in Phm_event table
    * Jira(testID = "HWPHME2E-1050 and HWPHME2E-1055")
    * Author: Lavanya Torrikonda(vn575up)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate multiple NDCs for a product and verify details are updated in Phm_event_table while creating an event & search(HWPHME2E-1050 & 1055)",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZEventTestData")
    public void HWPHME2E_1055_Validate_multiple_NDCs_for_a_product_and_verify_details_are_updated_in_Phm_event_table_while_creating_an_event_and_search(Map<String, String> inputData) {
        Reporter.log("Validate IMZ event search and verify appropriate details are updated in the Phm_event table after creating an event");
        //Pre-condition
        imzEventFlagsSetUP(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndcNbr1"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndcNbr2"));
        imzEventTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzEventTestScript.unChkAllImgScanDownOption();

        //Launch IMZ Event screen
        imzEventTestScript.launchImzEventScreen();
        //Create IMZ Event
        imzEventTestScript.createNewIMZEvent(inputData);
        //launch IMZ Event Search page
        imzEventTestScript.launchIMZEventSearch();
        //Validate race and ethnicity values in dropOff and PMS
        imzEventTestScript.validatePhmEventDetails();
        AutomationManager.getInstance().getConnexus().closeConnexus();
        Reporter.log("Validated IMZ event search and verified appropriate details are updated in the Phm_event table after creating an event");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Validate Race & Ethnicity details are saved in Drop off - IMZ Events
    * Jira(testID = "HWPHME2E-1031")
    * Precondition: In Tools menu under Store Settings, uncheck the 'All Image Scanner Down' option
    * Author: Lavanya Torrikonda(vn575up)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Race & Ethnicity details are saved in Drop off - IMZ Events",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZEventTestData")
    public void HWPHME2E_1031_Validate_Race_and_Ethnicity_details_are_saved_in_Drop_off_IMZ_Events_and_reflected_in_PMS(Map<String, String> inputData) {
        Reporter.log("Validate Race & Ethnicity details are saved in Drop off and same values are reflected in PMS");
        //Pre-condition
        imzEventFlagsSetUP(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndcNbr1"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndcNbr2"));
        imzEventTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzEventTestScript.unChkAllImgScanDownOption();

        //Create IMZ Event
        imzEventTestScript.createNewIMZEvent(inputData);
        //Create a new patient
        imzEventTestScript.createNewPatient(inputData);
        //perform imz event drop off by selecting race and ethnicity values
        imzEventTestScript.performImzEventDropOff(inputData);
        //Validate race and ethnicity values in dropOff and PMS
        imzEventTestScript.validateRaceAndEthnicityValuesInPMS(inputData);
        AutomationManager.getInstance().getConnexus().closeConnexus();
        Reporter.log("Validated Race & Ethnicity details are saved in Drop off and same values are reflected in PMS");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: [IMZ Event]Validate Multiple Products can be Added in the same event.
    * Jira(testID = "HWPHME2E-1051")
    * Author: Lavanya Torrikonda(vn575up)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Multiple Products can be Added in the same event",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZEventTestData")
    public void HWPHME2E_1051_Validate_multiple_products_with_multiple_NDCs_in_same_event(Map<String, String> inputData) {
        Reporter.log("Validate multiple products with multiple NDCs in same_event");
        //Pre-condition
        imzEventFlagsSetUP(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndcNbr1"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndcNbr2"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndcNbr3"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndcNbr4"));
        imzEventTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzEventTestScript.unChkAllImgScanDownOption();

        //Create IMZ Event
        imzEventTestScript.createNewIMZEvent(inputData);
        //Create a new patient
        imzEventTestScript.createNewPatient(inputData);
        //perform imz event drop off
        imzEventTestScript.performImzEventDropOff(inputData);
        AutomationManager.getInstance().getConnexus().closeConnexus();
        Reporter.log("Validated multiple products with multiple NDCs in same_event");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: [IMZ Event]Validate IMZ event flow to EOD and validate the phm_service table
    * Jira(testID = "HWPHME2E-1054")
    * Precondition: In Tools menu under Store Settings, uncheck the 'All Image Scanner Down' option
    * Author: Lavanya Torrikonda(vn575up)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate IMZ event flow to EOD and validate the phm_service table",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZEventTestData")
    public void HWPHME2E_1054_Validate_IMZ_event_flow_to_EOD_and_phm_service_table_updated_in_DB(Map<String, String> inputData) {
        Reporter.log("Validate IMZ event flow to EOD and phm_service table updated in DB");
        //Pre-condition
        imzEventFlagsSetUP(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndcNbr1"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndcNbr2"));
        imzEventTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzEventTestScript.unChkAllImgScanDownOption();

        //Create IMZ Event
        imzEventTestScript.createNewIMZEvent(inputData);
        //Create a new patient
        imzEventTestScript.createNewPatient(inputData);
        //perform imz event drop off by selecting race and ethnicity values
        imzEventTestScript.performImzEventDropOff(inputData);
        //perform 4 point
        imzEventTestScript.perform4Point(false, false);
        //perform chkDur
        imzEventTestScript.performChkDUR();
        //perform POS
        imzEventTestScript.performPOS();
        //verify order is in EOD
        imzEventTestScript.verifyRxInEOD();
        //Validate race and ethnicity values in dropOff and PMS
        imzEventTestScript.validatePhmEventDetails();
        AutomationManager.getInstance().getConnexus().closeConnexus();
        Reporter.log("Validate IMZ event flow to EOD and phm_service table updated in DB");
    }

}