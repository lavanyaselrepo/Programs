package clinicalservices.Immunization.testcases;

import clinicalservices.Immunization.testScripts.NaloxoneTestScripts;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.AutomationManager;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class NaloxoneTestSet {

    NaloxoneTestScripts naloxoneE2eTestScripts = new NaloxoneTestScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    String statecode = "";

    @BeforeClass
    public void startAppiumServer() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    public void flagsCheckUp() {
        //c2 drug popup flag should set <past date>
        connexusAppUtils.readAndUpdateFlag("27107", "2021-07-08");
        //Verify and set the flag 27268 for c2 control drug  to TRUE
        connexusAppUtils.readAndUpdateFlag("27268", "TRUE");
    }


    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Validate Naloxone E2E for RPH Issued Order Type and process to EOD.
     * Pre-Conditions:
       1. Set the store state as : WV
          select * from bus_unit_addr;
       2. To enable the 'Protocol  for State Specific standing order:
          Turn ON the OTC billing setting flag 15317 and 14108 IMZ RPh
          1. select * from informix.bu_phm_parm where phm_parm_code in(14137); - should be set as 'TRUE'
          2. select * from agency_rqmt_parm where restrict_type_code in (14118,14120) and issue_agency_code = 248;
           Note: issue_agency_code - will change based on state wise.
     *
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Naloxone E2E for RPH Issued Order Type and process to EOD",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "NalaxoneOrderCreation")
    public void HWPHME2E_1744_Naloxone_E2E(Map<String, String> inputData) {
        Reporter.log("Validate Naloxone E2E for RPH Issued Order Type and process to EOD");

        //Pre-condition
        flagsCheckUp();
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON Naloxone setting flag 14137 for RPh
        connexusAppUtils.readAndUpdateFlag("14137", "TRUE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("F", "14118", statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14120", statecode);
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC1"));
        naloxoneE2eTestScripts.flushCache();
        naloxoneE2eTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        naloxoneE2eTestScripts.createNewPatient(inputData);
        naloxoneE2eTestScripts.performNaloxoneDropOffRx(inputData);
        naloxoneE2eTestScripts.perform4Point();
        naloxoneE2eTestScripts.performChkDUR();
        naloxoneE2eTestScripts.performFilling();
        naloxoneE2eTestScripts.performVisualVerify();
        naloxoneE2eTestScripts.performPickUp(inputData);
        naloxoneE2eTestScripts.performCounselling();
        naloxoneE2eTestScripts.performPOS();
        naloxoneE2eTestScripts.verifyWorkQueueStatusAsEOD();
        Reporter.log("Validated Naloxone E2E for RPH Issued Order Type and process to EOD");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Validate User is able to drop Orders and process for Naloxone SO when the Naloxone SO expires TODAY.
     * Jira(testID = "HWPHME2E-2519")
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate User is able to drop Orders and process for Naloxone SO when the Naloxone SO expires TODAY",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "NalaxoneOrderCreation")
    public void HWPHME2E_2519_Validate_User_able_To_Drop_Orders_And_Process_When_Naloxone_SO_Expires_TODAY(Map<String, String> inputData) {
        Reporter.log("Validate User is able to drop Orders and process for Naloxone SO when the Naloxone SO expires TODAY");

        //Pre-condition
        flagsCheckUp();
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON Naloxone setting flag 14137 for SO
        connexusAppUtils.readAndUpdateFlag("14137", "TRUE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14118", statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("F", "14120", statecode);
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC1"));
        naloxoneE2eTestScripts.flushCache();
        naloxoneE2eTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        naloxoneE2eTestScripts.createNewPatient(inputData);
        naloxoneE2eTestScripts.performNaloxoneDropOffRx(inputData);
        naloxoneE2eTestScripts.perform4Point();
        naloxoneE2eTestScripts.performChkDUR();

        //Complete Filling and move to EOD for single order
        naloxoneE2eTestScripts.performSingleRxFillingAndMoveToEOD();
        Reporter.log("Validated User is able to drop Orders and process for Naloxone SO when the Naloxone SO expires TODAY");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Naloxone State Partnership | Drop walk-in order - FIRST RSPNDR product |Verify that QTY box is
     * allowing to enter only even numbers in between >=2 and <=30 (for example 2,4,6,8,10,12,14,18,20,22,24,26,28,30)
     * Jira(testID = "HWPHME2E-2440")
     * Test Description:Naloxone State Partnership | Drop walk-in order - FIRST RSPNDR product
     * Verify that QTY box should not allow to enter odd numbers 1,3,5,7,9,11,13,17,19,21,23,25,27,29
     * Jira(testID = "HWPHME2E-2441")
     * Author: Lavanya Torrikonda(vn575up)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate that QTY box is allowing to enter only even numbers in between >=2 and <=30",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "NalaxoneOrderCreation")
    public void HWPHME2E_2440_2441_Validate_QTY_box_is_allowing_to_enter_only_even_numbers_not_odd_numbers(Map<String, String> inputData) {
        Reporter.log("Validate that QTY box is allowing to enter only even numbers and should not allow to enter odd numbers");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        // Turn ON Naloxone State Partnership setting flags
        connexusAppUtils.readAndUpdateFlag("31604", "TRUE");
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("TRUE", "31600", statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("TRUE", "31602", statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("TRUE", "31604", statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("TRUE", "31605", statecode);
        connexusAppUtils.updateInventoryQuantity(inputData.get("NDC1"));
        naloxoneE2eTestScripts.restartService();
        naloxoneE2eTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient
        naloxoneE2eTestScripts.createNewPatient(inputData);
        //validate that QTY field is allowing to enter only even numbers and not odd nums
        naloxoneE2eTestScripts.performNaloxoneStatePartnershipDropOff(inputData);
        Reporter.log("Validated that QTY box is allowing to enter only even numbers and should not allow to enter odd numbers");
    }

}