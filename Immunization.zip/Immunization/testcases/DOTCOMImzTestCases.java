package clinicalservices.Immunization.testcases;

import clinicalservices.Immunization.testScripts.ImzTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.imzapp.constants.ProblemTypes;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.awt.*;
import java.io.IOException;
import java.util.Map;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.*;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.imzapp.constants.Constants.CS_IMZ_APP_STORE_ID;


public class DOTCOMImzTestCases {

    ImzTestScripts imzTestScripts = new ImzTestScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    String stateCode = "";
    int storeId = Integer.parseInt(CS_IMZ_APP_STORE_ID.getPropValue(prop));
    public boolean flagUpdated = false;

    @BeforeClass
    public void startAppiumServer() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    //update common flags
    public void flagsSetup(Map<String, String> inputData) {
        //Verify and set the flag to login to Pharmacist
        flagUpdated = connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        Reporter.log("Login to Pharmacist flag Disabled");
        //update state
        flagUpdated |= connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("PHARMACY_STATE"));
        connexusAppUtils.getLogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        // Turn ON  IMZ settings and Clin Intel flags
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y", "14102", stateCode);
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y", "14108", stateCode);
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15337", "TRUE");
    }

    //Marked as Obselete
    @Test(enabled = false, description = "Creating dotcom IMZ Order for a patient and complete Administration using IMZ APIs",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_976_Complete_Administration_Of_Dotcom_IMZOrder(Map<String, String> appointmentInfo) {
        //PreConditions: 1. 28750 should set to false in order to login as Pharmacist

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);

        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);

        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();

        //performs IMZ administration by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);

        //completes POS in Connexus
        imzTestScripts.performPOS();

        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);

        //cosmos DB Validation
        imzTestScripts.validationOfDataInCosmos(appointmentInfo);

        Reporter.log("Completed Administration of DOTCOM IMZ order using IMZ APIs and Validated data in PMS and COSMOS");
    }

    //Marked as Obselete
    /*@Test(enabled = false, description = "Complete Administration of dotcom IMZ Order created for a patient with Copay",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1092_Complete_Administration_Of_Dotcom_Patient_With_Copay(Map<String, String> appointmentInfo) {
        //PreConditions: 28750 should set to false in order to login as Pharmacist

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ RPh
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue("AR");
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("STATE"));
        Reporter.log("State code:" + stateCode);
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("N", "14108", stateCode);
        imzTestScripts.clearCache();
        closeConnexus();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);

        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreationWithTP(appointmentInfo);

        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();

        //performs IMZ administration by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);

        //completes POS in Connexus
        imzTestScripts.performPOS();

        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);

        //cosmos DB Validation
        imzTestScripts.validationOfDataInCosmos(appointmentInfo);

        Reporter.log("Completed Administration of DOTCOM order for a patient with Copay");
    }*/

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:[Regression][SO]Dotcom Complete IMZ administration for a patient with cash TP Plan.
    * Pre-Conditions: 28750 should set to false in order to login as Pharmacis
            1. Set the store state as : WV
    select * from bus_unit_addr;
      2. To enable the 'Protocol  for State Specific standing order:
    Turn ON Immunization settings for IMZ SO for below flags.
            1. select * from informix.bu_phm_parm where phm_parm_code in(15311,15149);
         2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248; -- should be set as 14102-TRUE and 14108- FALSE
    Note: issue_agency_code - will change based on state wise.
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1089")
    @Test(enabled = true, description = "[Regression][SO]Dotcom Complete IMZ administration for a patient with cash TP Plan.",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1089_SO_Dotcom_Complete_IMZ_Administration_for_patient_with_cash(Map<String, String> appointmentInfo) throws AWTException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        imzTestScripts.restartService();
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        //imzTestScripts.clearCache();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);

        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();

        //performs IMZ administration by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);

        //completes POS in Connexus
        imzTestScripts.performPOS();

        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);

        //validating RX Notes

        imzTestScripts.validateRxNotes();

        //cosmos DB Validation
        imzTestScripts.validationOfDataInCosmos(appointmentInfo);

        Reporter.log("[Regression][SO]Dotcom Complete IMZ administration for a patient with cash TP Plan IMZ APIs and Validated data in PMS");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:[Regression][SO] |RX admin notes validation of Dotcom Order and Complete IMZ administration for a patient with $0 copay.
    * Pre-Conditions: 28750 should set to false in order to login as Pharmacist
            1. Set the store state as : WV
    select * from bus_unit_addr;
      2. To enable the 'Protocol  for State Specific standing order:
    Turn ON Immunization settings for IMZ SO for below flags.
            1. select * from informix.bu_phm_parm where phm_parm_code in(15311,15149);
         2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248; -- should be set as 14102-TRUE and 14108- FALSE
    Note: issue_agency_code - will change based on state wise.
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1105")
    @Test(enabled = true, description = "[Regression][SO] |RX admin notes validation of Dotcom Order and Complete IMZ administration for a patient with $0 copay",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1105_SO_RX_admin_notes_Dotcom_Complete_IMZ_administration_for_patient_with_$0_copay(Map<String, String> appointmentInfo) throws ParserConfigurationException, IOException, SAXException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreationWithTP(appointmentInfo);

        //Adding PCP on PMS
        imzTestScripts.addPrescriberOnProfileTab(appointmentInfo);

        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();

        //performs IMZ administration by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);

        //completes POS in Connexus
        imzTestScripts.performPOS();

        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);

        //Validating details in RxNotes
        imzTestScripts.validateRxNotes();

        //Validation Of Fax
        imzTestScripts.validateFaxUnderActionItems();

        //Validating STC details in  DB
        imzTestScripts.validationOfSTCSentFromDB();

        //cosmos DB Validation
        imzTestScripts.validationOfDataInCosmos(appointmentInfo);

        Reporter.log("Completed IMZ Administration of DOTCOM order for a patient with Copay and validation of RX Admin notes from service details of PMS");
    }

    //Marked as Obselete
    /*@Test(enabled = false, description = "[Regression][RPH Authority] |RX admin notes |Complete IMZ administration for a patient with COMM copay ",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1004_RPH_Authority_RX_admin_notes_Dotcom_Complete_IMZ_administration_for_patient_with_COMM_copay(Map<String, String> appointmentInfo) {
        //PreConditions: 28750 should set to false in order to login as Pharmacist

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ RPh
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue("WV");
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("STATE"));
        Reporter.log("State code:" + stateCode);
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("N", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        imzTestScripts.clearCache();
        closeConnexus();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreationWithTP(appointmentInfo);

        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();

        //performs IMZ administration by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);

        //completes POS in Connexus
        imzTestScripts.performPOS();

        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);

        //validating RX Notes
        imzTestScripts.validateRxNotes();

        //cosmos DB Validation
        imzTestScripts.validationOfDataInCosmos(appointmentInfo);

        Reporter.log("Completed IMZ Administration of DOTCOM order for a patient with TP Plan Copay and validation of RX Admin notes from service details of PMS");
    }*/

    /*----------------------------------------------------------------------------------------------------------
   * Test Description:[F6 Search]Validate all Future dates orders are displayed in F6 search
   * Pre-Conditions: 28750 should set to false in order to login as Pharmacist
           1. Set the store state as : WV
   select * from bus_unit_addr;
     2. To enable the 'Protocol  for State Specific standing order:
   Turn ON Immunization settings for IMZ SO for below flags.
           1. select * from informix.bu_phm_parm where phm_parm_code in(15311,15149);
        2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248; -- should be set as 14102-TRUE and 14108- FALSE
   Note: issue_agency_code - will change based on state wise.
   ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-907")
    @Test(enabled = true, description = "[F6 Search]Validate all Future dates orders are displayed in F6 search",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_907_Validate_Future_Date_Order_Are_Displayed_In_F6_Search(Map<String, String> appointmentInfo) {
        Reporter.log("Create future dated dotcom order and validate future orders in F6 search screen");

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        //imzTestScripts.clearCache();
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        imzTestScripts.createDotcomOrderForFutureToConnexus(appointmentInfo);
        imzTestScripts.verifyFutureDatedOrder();
        Reporter.log("Created future dated order in dotcom and Validated future dated order displayed in F6 search screen");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Validate IMZ order is administrated successfully to a patient >18yrs with a legally authorized rep signing the consent.
    * Pre-Conditions: 28750 should set to false in order to login as Pharmacis
            1. Set the store state as : WV
    select * from bus_unit_addr;
      2. To enable the 'Protocol  for State Specific standing order:
    Turn ON Immunization settings for IMZ SO for below flags.
            1. select * from informix.bu_phm_parm where phm_parm_code in(15311,15149);
         2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248; -- should be set as 14102-TRUE and 14108- FALSE
    Note: issue_agency_code - will change based on state wise.
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-3113")
    @Test(enabled = true, description = "Validate IMZ order is administrated successfully to a patient >18yrs with a legally authorized rep signing the consent.",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_3113_SO_Validate_IMZ_Order_Administrated_for_patient_with_18_Years(Map<String, String> appointmentInfo) {

        //imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));

        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        //imzTestScripts.clearCache();
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);

        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();

        //performs IMZ administration gaurdian by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);

        //completes POS in Connexus
        imzTestScripts.performPOS();

        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);

        //cosmos DB Validation
        imzTestScripts.validationOfDataInCosmos(appointmentInfo);

        Reporter.log("Validate IMZ order is administrated successfully to a patient >18yrs ");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:[Regression][RPH Authority] Validate PCP details are updated on a patient profile when order created for local patient match found and validate autosync back.
    * Pre-Conditions: 28750 should set to false in order to login as Pharmacist
            1. Set the store state as : WV
    select * from bus_unit_addr;
      2. To enable the 'Protocol  for State Specific standing order:
    Turn ON Immunization settings for IMZ SO for below flags.
            1. select * from informix.bu_phm_parm where phm_parm_code in(15311,15149);
         2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248; -- should be set as 14102-FALSE and 14108- TRUE
   * Add prescriber with proper details in test data sheet with respective to store
    Note: issue_agency_code - will change based on state wise.
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-997")
    @Test(enabled = true, description = "[Regression][RPH Authority] Validate PCP details are updated on a patient profile when order created for local patient match found and validate autosync back.",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_997_RPH_Validate_PCP_Details_Are_Updated_On_Patient_Profile_For_Local_Patient(Map<String, String> appointmentInfo) {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        //imzTestScripts.clearCache();
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //creating patient in local
        imzTestScripts.createNewPatientImz(appointmentInfo);
        //create dotcom order
        imzTestScripts.createDotcomOrderToConnexusForExistingPatientWithPCP(appointmentInfo);
        //Verifying workQueue status for existing patient
        imzTestScripts.verifyOrderForExistingPatientAfterDotComOrderCreation(appointmentInfo);
        //validating PCP details on PMS and with DB
        imzTestScripts.validatePCPFromPMS(appointmentInfo);

        Reporter.log("Validated PCP details on PMS after creation of DOTCOM order fro local patient");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:[Regression][SO] Validate PCP details are updated on a patient profile when order created for local patient match found and validate autosync back.
    * Pre-Conditions: 28750 should set to false in order to login as Pharmacist
            1. Set the store state as : WV
    select * from bus_unit_addr;
      2. To enable the 'Protocol  for State Specific standing order:
    Turn ON Immunization settings for IMZ SO for below flags.
            1. select * from informix.bu_phm_parm where phm_parm_code in(15311,15149);
         2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248; -- should be set as 14102-TRUE and 14108- FALSE
         * Add prescriber with proper details in test data sheet with respective to store
    Note: issue_agency_code - will change based on state wise.
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1083")
    @Test(enabled = true, description = "[Regression][SO] Validate PCP details are updated on a patient profile when order created for local patient match found and validate autosync back.",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1083_SO_Validate_PCP_Details_Are_Updated_On_Patient_Profile_For_Local_Patient(Map<String, String> appointmentInfo) {

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //updating as pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        //imzTestScripts.clearCache();
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //creating patient in local
        imzTestScripts.createNewPatientImz(appointmentInfo);
        //create dotcom order
        imzTestScripts.createDotcomOrderToConnexusForExistingPatientWithPCP(appointmentInfo);
        //Verifying workQueue status for existing patient
        imzTestScripts.verifyOrderForExistingPatientAfterDotComOrderCreation(appointmentInfo);
        //validating PCP details on PMS and with DB
        imzTestScripts.validatePCPFromPMS(appointmentInfo);

        Reporter.log("Validated PCP details on PMS after creation of DOTCOM order for local patient");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Create DOTCOM Order and Validate Pharmacist is not allowed to change product in Patient Name mismatch resolution.
    * Pre-Conditions: 28750 should set to false in order to login as Pharmacist
            1. Set the store state as : WV
    select * from bus_unit_addr;
      2. To enable the 'Protocol  for State Specific standing order:
    Turn ON Immunization settings for IMZ SO for below flags.
            1. select * from informix.bu_phm_parm where phm_parm_code in(15311,15149);
         2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248; -- should be set as 14102-TRUE and 14108- FALSE
    Note: issue_agency_code - will change based on state wise.
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1038")
    @Test(enabled = true, description = "Create DOTCOM Order and Validate Pharmacist is not allowed to change product in Patient Name mismatch resolution.",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1038_Validate_Pharmacist_Not_Allowed_To_Change_Product_In_Patient_Mismatch_Resolution(Map<String, String> appointmentInfo) throws AWTException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        //imzTestScripts.clearCache();
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();

        //Verify modify order details is not enabled
        imzTestScripts.verifyIMZChangeProduct();

        Reporter.log("Completed validation of Pharmacist not allowed to change product in Patient Name mismatch resolution.");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Create DOTCOM Order with invalid PCP details and Validate Pharmacist is not allowed to change product in Contact Customer resolution.
    * Pre-Conditions: 28750 should set to false in order to login as Pharmacist
            1. Set the store state as : WV
    select * from bus_unit_addr;
      2. To enable the 'Protocol  for State Specific standing order:
    Turn ON Immunization settings for IMZ SO for below flags.
            1. select * from informix.bu_phm_parm where phm_parm_code in(15311,15149);
         2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248; -- should be set as 14102-TRUE and 14108- FALSE
         * Provide invalid PCP/prescriber details in test data sheet
    Note: issue_agency_code - will change based on state wise.
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1039")
    @Test(enabled = true, description = "Create DOTCOM Order with invalid PCP details and Validate Pharmacist is not allowed to change product in Contact Customer resolution.",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1039_Validate_Pharmacist_Not_Allowed_To_Change_Product_In_Contact_Customer_Resolution(Map<String, String> appointmentInfo) throws AWTException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        //imzTestScripts.clearCache();
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderToConnexusForNewPatientWithPCP(appointmentInfo);

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        //perform patient creation from resolution page
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);
        //verify workQueue after patient mismatch for invalid PCP
        imzTestScripts.verifyWorkQueueAndNeedToContactPrescriberProblemStatus();
        //Verify modify order details is not enabled
        imzTestScripts.verifyIMZChangeProduct();

        Reporter.log("Completed validation of Pharmacist not allowed to change product in Contact Customer resolution.");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Create DOTCOM Order with invalid PCP details and Validate Pharmacist is not allowed to change product in Contact Customer resolution.
    * Pre-Conditions: 28750 should set to false in order to login as Pharmacist
            1. Set the store state as : WV
    select * from bus_unit_addr;
      2. To enable the 'Protocol  for State Specific standing order:
    Turn ON Immunization settings for IMZ SO for below flags.
            1. select * from informix.bu_phm_parm where phm_parm_code in(15311,15149);
         2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248; -- should be set as 14102-TRUE and 14108- FALSE
    Note: issue_agency_code - will change based on state wise.
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1041")
    @Test(enabled = true, description = "Create DOTCOM Order with future date and Validate Pharmacist is not allowed to change product in Future Fill resolution. ",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1041_Validate_Pharmacist_Not_Allowed_To_Change_Product_In_Future_Fill_Resolution(Map<String, String> appointmentInfo) throws AWTException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        //imzTestScripts.clearCache();
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderForFutureToConnexus(appointmentInfo);

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        //perform patient creation from resolution page
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);
        //verify workQueue after patient creation for future fill
        imzTestScripts.verifyWorkQueueAndProblemStatusAsFutureFill();
        //Verify modify order details is not enabled
        imzTestScripts.verifyIMZChangeProduct();
        Reporter.log("Completed validation of Pharmacist not allowed to change product in Future Fill resolution.");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:[Regression][RPH Authority] Complete IMZ administration for a patient with cash TP Plan.
    * Jira(testID = "HWPHME2E-970")
    * Author: Lavanya Torrikonda(vn575up)
  ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "[Regression][RPH Authority] Complete IMZ administration for a patient with cash TP Plan.",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_970_RPH_Complete_IMZ_Administration_for_patient_with_cash_TP_Plan(Map<String, String> appointmentInfo) {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("N", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        //imzTestScripts.clearCache();
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderForFutureToConnexus(appointmentInfo);

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);
        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);
        //completes POS in Connexus
        imzTestScripts.performPOS();
        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);
        //validating RX Notes
        imzTestScripts.validateRxNotes();
        //cosmos DB Validation
        imzTestScripts.validationOfDataInCosmos(appointmentInfo);
        Reporter.log("Validated RPH Completed IMZ administration for a patient with cash TP Plan IMZ APIs and Validated data in PMS");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:[Regression][RPH Authority] |validation of Dotcom Order and Complete IMZ administration for a patient with $0 copay.
    * Jira(testID = "HWPHME2E-973")
    * Author: Lavanya Torrikonda(vn575up)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "[Regression][RPH Authority]Complete IMZ administration for a patient with $0 copay",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_973_RPH_Validate_Complete_IMZ_Administration_for_patient_with_$0_copay(Map<String, String> appointmentInfo) {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("N", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderForFutureToConnexus(appointmentInfo);

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreationWithTP(appointmentInfo);
        //Adding PCP on PMS
        imzTestScripts.addPrescriberOnProfileTab(appointmentInfo);
        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);
        //completes POS in Connexus
        imzTestScripts.performPOS();
        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);
        //Validating details in RxNotes
        imzTestScripts.validateRxNotes();
        //Validation Of Fax
        imzTestScripts.validateFaxUnderActionItems();
        //Validating STC details in  DB
        imzTestScripts.validationOfSTCSentFromDB();
        //cosmos DB Validation
        imzTestScripts.validationOfDataInCosmos(appointmentInfo);
        Reporter.log("Validated RPH Completed IMZ Administration of DOTCOM order for a patient with $0 Copay");
    }

    @Test(enabled = true, description = "Validate new PQCF is pick up for a patient >18yrs with a legally authorized rep signing the consent.",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_2521_Validate_new_PQCF_is_pick_up_for_the_patient_greater_than_18_Years(Map<String, String> appointmentInfo) {

        //imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        imzTestScripts.flushCache();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);
        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration gaurdian by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);
        //completes POS in Connexus
        imzTestScripts.performPOS();
        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);
        //validating guardian info in db
        imzTestScripts.verifyGuardianInfoAsSelf(appointmentInfo);
        //cosmos DB Validation
        imzTestScripts.validationOfDataInCosmos(appointmentInfo);

        Reporter.log("Validate new PQCF is pick up for a patient >18yrs with a legally authorized rep signing the consent ");
    }

    @Test(enabled = true, description = "Validate order is in RPh manual resolution when we do not authorize it before order creation for existing patient",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_3115_Validate_Order_In_RphManualResolution_When_Dont_Authorized_Before_OrderCreation_For_existing_Patient(Map<String, String> appointmentInfo) throws AWTException {

        Reporter.log("HWPHME2E-3115--> Validate order is in RPh manual resolution when we do not authorize it before order creation for existing patient");

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("STATE"));
        Reporter.log("State code:" + stateCode);
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("N", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14108");
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        Reporter.log("Store Id :" + storeId);
        processImzOrderRequest(storeId, questionsWithAllFalse(), appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //connexus search for patient and validate order status is in rph manual resolution
        imzTestScripts.verifyImzOrderWorkQueueStatus();
        imzTestScripts.verifyProblemMessage(ProblemTypes.ManualResolution);

        Reporter.log("HWPHME2E-3115--> Validate order is in RPh manual resolution when we do not authorize it before order creation for existing patient");
    }

    @Test(enabled = true, description = "Validate order is NOT RPh manual resolution when we authorize it before order creation for new patient",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_3114_Validate_Order_Not_In_RphManualResolution_When_We_Authorize_Before_OrderCreation_For_New_Patient(Map<String, String> appointmentInfo) throws AWTException {

        Reporter.log("HWPHME2E-3114--> Validate order is NOT RPh manual resolution when we authorize it before order creation for new patient");

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");

        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");

        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("STATE"));
        Reporter.log("State code:" + stateCode);
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("N", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14108");
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        Reporter.log("Store Id :" + storeId);
        processImzOrderRequest(storeId, questionsWithAllFalse(), appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //connexus search for patient and validate order status is in rph manual resolution
        imzTestScripts.verifyImzOrderWorkQueueStatus();
        imzTestScripts.verifyProblemMessage(ProblemTypes.PatientNameMismatch);
        Reporter.log("HWPHME2E-3114--> Validate order is NOT RPh manual resolution when we authorize it before order creation for new patient");
    }


/*----------------------------------------------------------------------------------------------------------
    * Test Description:[Dotcom] Single Patient Single IMZ - Drop and order for SPIKEVAX for age 6M-11yrs and complete administration in handheld
    * Jira(testID = "HWPHME2E-1025")
    * Author: Nithiya Jayasankar(vn58al5)
    ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Creating dotcom IMZ Order for a patient and complete Administration using IMZ APIs",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1025_Complete_Administration_Of_Dotcom_IMZOrder(Map<String, String> appointmentInfo) {
        //imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));

        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        //imzTestScripts.clearCache();
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);

        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();

        //performs IMZ administration
        imzTestScripts.performImZAdministration(appointmentInfo);
        //completes POS in Connexus
        imzTestScripts.performPOS();
        //validating allergy in pms
        imzTestScripts.verifyAllergydetailsInPMS(appointmentInfo);
        // Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);
        // validation in central DB ----- TO DO
        // imzTestScripts.autosyncValidationinDB(appointmentInfo);

        //cosmos DB Validation
        imzTestScripts.validationOfDataInCosmos(appointmentInfo);
        Reporter.log("Creating dotcom IMZ Order for a patient with Allergy and complete Administration using IMZ APIs");
    }

    @Test(enabled = true, description = "Creating dotcom IMZ Order for a patient and complete Administration using IMZ APIs",
            priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_992_Complete_Administration_Of_Dotcom_IMZOrder_with_chronic_conditions(Map<String, String> appointmentInfo) {
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));

        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        //imzTestScripts.clearCache();
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);

        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration
        imzTestScripts.performImZAdministration(appointmentInfo);
        //completes POS in Connexus
        imzTestScripts.performPOS();
        //validating allergy in pms
        imzTestScripts.verifyMedicalConditionInPMS(appointmentInfo);
        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);
        // validation in central DB ----TO DO
        // imzTestScripts.autosyncValidationinDB(appointmentInfo);

        //cosmos DB Validation
        imzTestScripts.validationOfDataInCosmos(appointmentInfo);
        Reporter.log("Creating dotcom IMZ Order for a patient and complete Administration using IMZ APIs");
    }

    @Test(enabled = true, description = "Pharmacist should be able to change drug and NDC from IMZ Change product popup from CheckDUR Screen ",
            priority = 18, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1037_Validate_Pharmacist_Is_Able_To_Change_Product_In_CheckDUR_Screen(Map<String, String> appointmentInfo) throws AWTException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");

        // Turn ON setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");

        // Update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);

        // Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating Dotcom Order
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        //perform patient creation from resolution page
        imzTestScripts.performPatientSearchAndPatientCreationWithTP(appointmentInfo);
        imzTestScripts.checkAndOpenCheckDURScreen(appointmentInfo);
        imzTestScripts.validateChangeProductInCheckDURScreen(appointmentInfo);

        Reporter.log("Validated Pharmacist is able to change Product from checkDUR Screen");


    }

    @Test(enabled = true, description = "Pharmacist should be able to change drug and NDC from IMZ Change product popup from Modify Detail Screen ",
            priority = 19, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1036_Validate_Pharmacist_Is_Able_To_Change_Product_In_Modify_Detail_Screen(Map<String, String> appointmentInfo) throws AWTException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");

        // Turn ON setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");

        // Update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);

        // Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating Dotcom Order
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);

        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        //perform patient creation from resolution page
        imzTestScripts.performPatientSearchAndPatientCreationWithTP(appointmentInfo);
        imzTestScripts.checkAndOpenCheckDURScreen(appointmentInfo);
        imzTestScripts.validateChangeProductInModifyDetailScreen(appointmentInfo);

        Reporter.log("Validated Pharmacist is able to change Product from Modify Detail Screen");


    }
    /*----------------------------------------------------------------------------------------------------------
    * Test Description:[Dotcom]-"Pharmacist should be able to change drug and NDC from IMZ Change product popup in drug not authorized resolution screen "
    *  Jira(testID = "HWPHME2E-1035")
    * Precondition - Drug used to drop the dotcom order should not be authorized list
    * Author: Purnima Arora (vn58gdi)
    ----------------------------------------------------------------------------------------------------------*/

    @Test(enabled = true, description = "Pharmacist should be able to change drug and NDC from IMZ Change product popup in drug not authorized resolution screen ",
            priority = 20, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1035_Validate_Pharmacist_Is_Able_To_Change_Product_In_Drug_Not_Authorized_Resolution(Map<String, String> appointmentInfo) throws AWTException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        // Turn ON setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15149", "TRUE");
        // Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //Creating Dotcom Order
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //connexus search for patient and open resolution Screen
        imzTestScripts.navigateToManualResolutionScreenForRxOrder();
        //Change the drug and NDC in resolution page
        imzTestScripts.validateChangeProductInResolutionPage(appointmentInfo);
        Reporter.log("Validated Pharmacist is able to change Product from Drug Not Authorized Resolution Screen");
    }

    /*-----------------------------------------------------------------------------------------------------------------
  * Test Description:[Dotcom]-" Create Dotcom Order for multiple patients with single IMZ Type i.e. COVID first patient
    age is 6M-11Y(Moderna Drug) and second patient age is 18+Y(Spikevax Drug) "
  *  Jira(testID = "HWPHME2E-1933")
  * Author: Purnima Arora (vn58gdi)
  ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Create DOTCOM Order for multiple patients with single IMZ first is age 6M-11yrs order and second is age 12+yrs order for covid products ",
            priority = 21, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1933_Validate_New_PQCF_with_Pediatric_MPMI_new_patient(Map<String, String> appointmentInfo) throws AWTException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        // Turn ON setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15149", "TRUE");
        // Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // **Creating IMZ Scheduling Order Through DOTCOM for multiple patients**
        imzTestScripts.createDotcomOrderToConnexusForMultiPatients(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // Connexus search for patient and perform resolution
        imzTestScripts.verifyWorkQueueAndProblemStatusAndCreatePatients(appointmentInfo);
        // Perform DUR and moves to Service Administration
        imzTestScripts.completeCheckDURForMultiPatientsAndVerifySvcAdmin(appointmentInfo);
        // Perform IMZ administration using APIs
        imzTestScripts.performIMZAdministrationForMultiPatients(appointmentInfo);
        // Complete POS in Connexus
        imzTestScripts.performPOSForMultiPatients(appointmentInfo);
        // Validate details in PMS
        imzTestScripts.verifyServiceDetailsInPMSForMultiPatients(appointmentInfo,false);
        // Cosmos DB Validation
        imzTestScripts.validationOfDataInCosmosForMultiPatients(appointmentInfo);
        Reporter.log("Validate IMZ order is administrated successfully for both patients.");
    }

    /*-----------------------------------------------------------------------------------------------------------------
* Test Description:[Dotcom]-" Create Dotcom Order for multiple patients with single IMZ Type i.e. FLU first patient
  age is 6M-11Y(Fluzone Drug) and second patient age is 18+Y(Flublok Drug) "
*  Jira(testID = "HWPHME2E-1933")
* Author: Purnima Arora (vn58gdi)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Create DOTCOM Order for multiple patients with single IMZ first is age 6M-11yrs order and second is age 12+yrs order for flu products ",
            priority = 22, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1932_Validate_New_PQCF_with_Adult_MPMI(Map<String, String> appointmentInfo) throws AWTException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        // Turn ON setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15149", "TRUE");
        // Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // **Creating IMZ Scheduling Order Through DOTCOM for multiple patients**
        imzTestScripts.createDotcomOrderToConnexusForMultiPatients(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // Connexus search for patient and perform resolution
        imzTestScripts.verifyWorkQueueAndProblemStatusAndCreatePatients(appointmentInfo);
        // Perform DUR and moves to Service Administration
        imzTestScripts.completeCheckDURForMultiPatientsAndVerifySvcAdmin(appointmentInfo);
        // Perform IMZ administration using APIs
        imzTestScripts.performIMZAdministrationForMultiPatients(appointmentInfo);
        // Complete POS in Connexus
        imzTestScripts.performPOSForMultiPatients(appointmentInfo);
        // Validate details in PMS
        imzTestScripts.verifyServiceDetailsInPMSForMultiPatients(appointmentInfo,false);
        // Cosmos DB Validation
        imzTestScripts.validationOfDataInCosmosForMultiPatients(appointmentInfo);
        Reporter.log("Validate IMZ order is administrated successfully for both patients.");
    }
    /*-----------------------------------------------------------------------------------------------------------------
* Test Description:[Dotcom]-" Create Dotcom Order for with covid product.Administer that order.Validate
that covid product used to place the order should not be displayed in Cycle Count Report Page
*  Jira(testID = "HWPHME2E-2439")
* Author: Purnima Arora (vn58gdi)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate_Covid_Products_Are_Not_Displaying_In_Cycle_Count_Report",
            priority = 23, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_2439_Validate_Covid_Products_Are_Not_Displaying_In_Cycle_Count_Report(Map<String, String> appointmentInfo)  {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        // Turn ON setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15149", "TRUE");
        // Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);
        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);
        //completes POS in Connexus
        imzTestScripts.performPOS();
        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);
        //cosmos DB Validation
        imzTestScripts.validationOfDataInCosmos(appointmentInfo);
        // validating covid product not present in cycle count report
        imzTestScripts.validateCovidProductNotPresentInCycleCount(appointmentInfo);

        Reporter.log("Validated Covid Product is not displaying in cycle count report");
    }


    @Test(enabled = true, description = "Validate RPH can add or change product in handheld",
            priority = 24, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1046_Validate_RPH_can_add_or_change_product_in_handheld(Map<String, String> appointmentInfo) {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("N", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        //imzTestScripts.clearCache();
        imzTestScripts.restartService();
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreationWithTP(appointmentInfo);
        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration by using APIs
        imzTestScripts.performImZAdministrationForDotcomAddProduct(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //completes POS in Connexus
        imzTestScripts.performPOSForDotcomMultiRx();
        imzTestScripts.performGetPaymentStatusForMultiRxAddProduct();
        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);
        //cosmos DB Validation
        imzTestScripts.validationOfDataInCosmos(appointmentInfo);
        Reporter.log("Validate RPH can add or change product in handheld");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:[COVID Flag OFF][RPH Auth][COVID Drug] Validate the license code in RX image when RPH is dual licensed.
     * Jira(testID = "HWPHME2E-1460")
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "[COVID Flag OFF][RPH Auth][COVID Drug]Validate the license code in RX image when RPH is dual licensed",
            priority = 25, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1460_Validate_license_code_in_RX_image_when_RPH_is_dual_licensed(Map<String, String> appointmentInfo) {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        //update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        // Turn ON setting flag IMZ
        connexusAppUtils.updateAgencyRequirementParmTable("N", "14102", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14102");
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14108");
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);
        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);
        //completes POS in Connexus
        imzTestScripts.performPOS();
        //validate dual license prescriber
        imzTestScripts.validateDualLicencePrescriber(appointmentInfo);
        //validate license number in RxImage
        imzTestScripts.validateRxImageDetailsInPMS(appointmentInfo);
        Reporter.log("Validated license code in RX image when RPH is dual licensed");
    }

    /*-----------------------------------------------------------------------------------------------------------------
  * Test Description:[Dotcom]-" Create Dotcom Order for multiple patients with single IMZ Type i.e. COVID first patient
    age is 6M-11Y(Moderna Drug) and second patient age is 18+Y(Spikevax Drug) "
  *  Jira(testID = "HWPHME2E-1938")
  * Author: Nithiya Jayashankar(vn58al5
  ----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Validate new PQCF for 3-18y with Health care power attorney in app",
            priority = 26, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1938_Validate_New_PQCF_for_3to18yrs_with_Health_care_power_attorney(Map<String, String> appointmentInfo) throws AWTException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        // Turn ON setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15149", "TRUE");
        // Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // Creating IMZ Scheduling Order Through DOTCOM for multiple patients**
        imzTestScripts.createDotcomOrderToConnexusForMultiPatients(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // Connexus search for patient and perform resolution
        imzTestScripts.verifyWorkQueueAndProblemStatusAndCreatePatients(appointmentInfo);
        // Perform DUR and moves to Service Administration
        imzTestScripts.completeCheckDURForMultiPatientsAndVerifySvcAdmin(appointmentInfo);
        // Perform IMZ administration using APIs
        imzTestScripts.performIMZAdministrationForMultiPatients(appointmentInfo);
        // Complete POS in Connexus
        imzTestScripts.performPOSForMultiPatients(appointmentInfo);
        // Validate details in PMS
        imzTestScripts.verifyServiceDetailsInPMSForMultiPatients(appointmentInfo,false);
        // Cosmos DB Validation
        imzTestScripts.validationOfDataInCosmosForMultiPatients(appointmentInfo);
        Reporter.log("Validate IMZ order is administrated successfully for both patients.");
    }

    /*-----------------------------------------------------------------------------------------------------------------
* Test Description:[Dotcom]-"[Dotcom] Mutli Patient Multi IMZ - Drop and order for Moderna  6M-11yrs-
* Add product and complete administration in handheld "
*  Jira(testID = "HWPHME2E-1026")
* Author: Nithiya Jayashankar (vn58al5)
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Create DOTCOM Order for multiple patients and Add Product in HH and administer both products",
            priority = 27, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1026_Multi_Patient_and_Multi_IMZ(Map<String, String> appointmentInfo) throws AWTException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        // Turn ON setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15149", "TRUE");
        // Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // **Creating IMZ Scheduling Order Through DOTCOM for multiple patients**
        imzTestScripts.createDotcomOrderToConnexusForMultiPatients(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // Connexus search for patient and perform resolution
        imzTestScripts.verifyWorkQueueAndProblemStatusAndCreatePatients(appointmentInfo);
        // Perform DUR and moves to Service Administration
        imzTestScripts.completeCheckDURForMultiPatientsAndVerifySvcAdmin(appointmentInfo);
        // Perform IMZ administration using APIs
        imzTestScripts.performImZAdministrationForDotcomAddProductforMultiPatient(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // Complete POS in Connexus
        imzTestScripts.performPOSForMultiPatientsWithMultiRx(appointmentInfo);
        // Validate details in PMS
        imzTestScripts.verifyServiceDetailsInPMSForMultiPatients(appointmentInfo,false);
        // Cosmos DB Validation
        imzTestScripts.validationOfDataInCosmosForMultiPatients(appointmentInfo);
        Reporter.log("Validate IMZ order is administrated successfully for both patients.");
    }
    /*-----------------------------------------------------------------------------------------------------------------
  * Test Description:[Dotcom]-" Create Dotcom Order for multiple patients with single IMZ Type i.e. FLU. Administer the order as Technician
    Both Patient age is greater than 18 years
  *  Jira(testID = "HWPHME2E-1936")
  * Author: Purnima Arora (vn58gdi)
  *  Pre-Condition - Create Technician Login and mention user id in config
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Create DOTCOM Order for multiple patients with single IMZ and Both patients age is greater than 18Y.Administer the Order as Technician ",
            priority = 25, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1936_Validate_New_PQCF_Is_Pullup_For_Tech_Admin_And_Patient_Age_Greater_Than_18Y(Map<String, String> appointmentInfo) throws AWTException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        // Turn ON setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15149", "TRUE");
        // Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15219", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15309", stateCode);
        imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // **Creating IMZ Scheduling Order Through DOTCOM for multiple patients**
        imzTestScripts.createDotcomOrderToConnexusForMultiPatients(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // Connexus search for patient and perform resolution
        imzTestScripts.verifyWorkQueueAndProblemStatusAndCreatePatients(appointmentInfo);
        // Perform DUR and moves to Service Administration
        imzTestScripts.completeCheckDURForMultiPatientsAndVerifySvcAdmin(appointmentInfo);
        // Perform IMZ administration using APIs
        imzTestScripts.performIMZAdministrationForMultiPatientsTechAdmin(appointmentInfo);
        // Complete POS in Connexus
        imzTestScripts.performPOSForMultiPatients(appointmentInfo);
        // Validate details in PMS
        imzTestScripts.verifyServiceDetailsInPMSForMultiPatients(appointmentInfo,true);
        // Cosmos DB Validation
        imzTestScripts.validationOfDataInCosmosForMultiPatients(appointmentInfo);
        Reporter.log("Validate IMZ order is administrated successfully by Technician for both patients.");
    }
    /*-----------------------------------------------------------------------------------------------------------------
  * Test Description:[Dotcom]-" Create Dotcom Order for multiple patients with single IMZ Type i.e. COVID. Administer the order as Technician
    Both Patient age is less than 18 years
  *  Jira(testID = "HWPHME2E-1937")
  * Author: Purnima Arora (vn58gdi)
  * Pre-Condition - Create Technician Login and mention user id in config
----------------------------------------------------------------------------------------------------------*/
    @Test(enabled = true, description = "Create DOTCOM Order for multiple patients with single IMZ and Both patients age is less than 18Y.Administer the Order as Technician ",
            priority = 26, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_1937_Validate_New_PQCF_Is_Pullup_For_Tech_Admin_And_Patient_Age_Less_Than_18Y(Map<String, String> appointmentInfo) throws AWTException {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Update state
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(appointmentInfo.get("PHARMACY_STATE"));
        Reporter.log("State code:" + stateCode);
        // Turn ON setting flag 15311 and 15149 IMZ
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15149", "TRUE");

        // Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15219", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15309", stateCode);
        // imzTestScripts.restartService();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // **Creating IMZ Scheduling Order Through DOTCOM for multiple patients**
        imzTestScripts.createDotcomOrderToConnexusForMultiPatients(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        // Connexus search for patient and perform resolution
        imzTestScripts.verifyWorkQueueAndProblemStatusAndCreatePatients(appointmentInfo);
        // Perform DUR and moves to Service Administration
        imzTestScripts.completeCheckDURForMultiPatientsAndVerifySvcAdmin(appointmentInfo);
        // Perform IMZ administration using APIs
        imzTestScripts.performIMZAdministrationForMultiPatientsTechAdmin(appointmentInfo);
        // Complete POS in Connexus
        imzTestScripts.performPOSForMultiPatients(appointmentInfo);
        // Validate details in PMS
        imzTestScripts.verifyServiceDetailsInPMSForMultiPatients(appointmentInfo,true);
        // Cosmos DB Validation
        imzTestScripts.validationOfDataInCosmosForMultiPatients(appointmentInfo);
        Reporter.log("Validate IMZ order is administrated successfully by Technician for both patients.");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Validate TP to Cash change post save product and check inventory for dotcom flow
    * Jira(testID = "HWPHME2E-4820")
    * Author: Lavanya Torrikonda(vn575up)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate TP to CASH change post save product and check inventory for dotcom flow",
            priority = 27, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "IMZTestData")
    public void HWPHME2E_4820_Validate_TPToCash_change_post_save_product_and_check_inventory(Map<String, String> appointmentInfo) {
        Reporter.log("Validate TP to Cash change post save product and check inventory for dotcom flow");
        //Pre-condition
        flagsSetup(appointmentInfo);
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        imzTestScripts.initializeTestCase(flagUpdated);

        //Retrieve the initial quantities of the product from the DB
        Map<String, Integer> previousQuantities1 = connexusAppUtils.getPharmacyItemQuantities(appointmentInfo.get("DRUG_NAME"));

        //Creating IMZ Scheduling Order Through DOTCOM
        imzTestScripts.createDotcomOrderToConnexus(appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //Verify quantities of the product after create dotcom order
        Map<String, Integer> previousQuantities2 = connexusAppUtils.validateAndGetQuantities(appointmentInfo.get("DRUG_NAME"), previousQuantities1);
        //connexus search for patient and perform resolution and ClinIntel Screen
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreationWithTP(appointmentInfo);
        //Verify quantities of the product after create patient
        Map<String, Integer> previousQuantities3 = connexusAppUtils.validateAndGetQuantities(appointmentInfo.get("DRUG_NAME"), previousQuantities2);
        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();
        //Verify quantities of the product after svcAdmin
        Map<String, Integer> previousQuantities4 = connexusAppUtils.validateAndGetQuantities(appointmentInfo.get("DRUG_NAME"), previousQuantities3);
        //Performs IMZ administration for unassigned orders by using APIs
        imzTestScripts.performImzAdministrationForUnassignOrders(appointmentInfo);
        //Validate DB quantities of the product after orders using Dotcom APIs
        Map<String, Integer> previousQuantities5 = connexusAppUtils.validateAndGetQuantities(appointmentInfo.get("DRUG_NAME"), previousQuantities4);
        //Change the billing from TP to Cash in Modify Details
        imzTestScripts.changeBillingFromTPToCashInModifyDetails(appointmentInfo,appointmentInfo.get("DRUG_NAME2"));
        //Validate DB quantities of the product after svcAdmn modified details
        Map<String, Integer> previousQuantities6 = connexusAppUtils.validateAndGetQuantities(appointmentInfo.get("DRUG_NAME"), previousQuantities5);
        //Performs IMZ administration for assigned orders
        imzTestScripts.performImZAdministration(appointmentInfo);
        //Verify quantities of the product after imz administration
        connexusAppUtils.validateAndGetQuantities(appointmentInfo.get("DRUG_NAME"), previousQuantities6);
        Reporter.log("Validated TP to Cash change post save product and check inventory for dotcom flow");
    }

}