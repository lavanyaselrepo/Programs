package clinicalservices.Immunization.testcases;

import clinicalservices.Immunization.testScripts.ClinicalIntelligenceTestScripts;
import clinicalservices.Immunization.testScripts.ImzTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;


import java.util.Map;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.processImzOrderRequest;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.questionsWithAllFalse;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.imzapp.constants.Constants.CS_IMZ_APP_STORE_ID;

public class QRScanTestCases {
    protected int storeId;
    ImzTestScripts imzTestScripts= new ImzTestScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();

    @BeforeSuite(alwaysRun = true)
    public void beforeSuiteExecution() {
        PropertyReader prop = PropertyReader.getInstance();
        storeId = Integer.parseInt(CS_IMZ_APP_STORE_ID.getPropValue(prop));
    }

    @BeforeClass
    public void startAppiumServer() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    @Test(enabled = true, description = "Validate- PickUp time should be +20 min from Schedule/current time and Run the QR Scan E2E flow(HWPHME2E_3112,HWPHME2E_3199)",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "QRScanTestData")
    public void HWPHME2E_3199_QRScan_FlowTest(Map<String, String> appointmentInfo) {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        imzTestScripts.flushCache();

        // Create QR Scan order
        processImzOrderRequest(storeId, questionsWithAllFalse(), appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //verify WQ And Problem Status
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        //Verify Pickup Date HWPHME2E_3112
        imzTestScripts.verifyOrderPickupdatestatus();
        //perform search from resolution page and create Patient
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);
        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);
        //Relogging into connexus to keep the session active
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //completes POS in Connexus
        imzTestScripts.performPOS();
        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);
    }

    @Test(enabled = true, description = "Validate- PickUp time should be +20 min from Schedule/current time and Run the QR Scan E2E flow for Single Patient & Multi Drug",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "QRScanTestData")
    public void HWPHME2E_3123_QRScan_MultiDrugFlowTest(Map<String, String> appointmentInfo) {

        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        imzTestScripts.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        imzTestScripts.flushCache();

        // Create QR Scan order
        processImzOrderRequest(storeId, questionsWithAllFalse(), appointmentInfo);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //verify WQ And Problem Status
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        //perform search from resolution page and create Patient
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);
        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformMultiCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdminMulti();
        //performs IMZ administration by using APIs
        imzTestScripts.performImZAdministrationMultiRx(appointmentInfo);
        //Relogging into connexus to keep the session active
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
       //completes POS in Connexus
        imzTestScripts.performPOSMultiRx();
        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMSMultiRx(appointmentInfo);
    }


    }