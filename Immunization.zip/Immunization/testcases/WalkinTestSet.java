package clinicalservices.Immunization.testcases;


import clinicalservices.Immunization.testScripts.ClinicalIntelligenceTestScripts;
import clinicalservices.Immunization.testScripts.WalkinTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

public class WalkinTestSet {

    WalkinTestScript walkinTestScript = new WalkinTestScript();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    String stateCode = "";
    public boolean flagUpdated = false;

    @BeforeClass
    public void startAppiumServer() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    //update common flags
    public void flagsSetup(Map<String, String> inputData) {
        //Verify and set the flag to login to Pharmacist
        flagUpdated = connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        Reporter.log("Login to Pharmacist flag Disabled");
        //update state
        flagUpdated |= connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        // Turn ON  IMZ settings and Clin Intel flags
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y", "14102", stateCode);
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y", "14108", stateCode);
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15337", "TRUE");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Verify the edit functionality in modify details screen for Standing Order.
    * Pre-Conditions:
    * 28750 should set to false in order to login as Pharmacist
       1. Set the store state as : WV
          select * from bus_unit_addr;
       2. To enable the 'Protocol  for State Specific standing order:
          Turn ON Immunization settings for IMZ SO for below flags.
          select * from agency_rqmt_parm where restrict_type_code in (15102) and issue_agency_code = 248; -should be set as 'TRUE'
          Note: issue_agency_code - will change based on state wise.
    *
    * Author: Lavanya Torrikonda(vn575up)
   ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-314")
    @Test(description = "Verify the edit functionality is disabled in modify details screen for SO",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "WalkinTestData")
    public void HWPHME2E_314_Verify_Edit_Functionality_InModifyDetailsScreen_for_SO(Map<String, String> inputData) {
        Reporter.log("Validate edit functionality is disabled in modify details screen for SO");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        //Updating ARP flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15102", stateCode);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr1"));
        walkinTestScript.flushCache();
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        walkinTestScript.createNewPatient(inputData);
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        walkinTestScript.checkAndPerformCheckDUR();
        walkinTestScript.verifyWorkQueueStatusAsServiceAdmin();
        //Validate ModifyDetails
        walkinTestScript.verifyIMZModifyDetails();
        Reporter.log("Validated edit functionality is disabled in modify details screen for SO");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:
      Drop FLU order, perform IMZ administration by using Walkin APIs and Validate latest PQCF is used to generate the form in PMS .
    * Pre-Conditions:
    * 28750 should set to false in order to login as Pharmacist
      1. Set the store state as : WV
         select * from bus_unit_addr;
      2. To enable the 'Protocol  for State Specific standing order:
         Turn ON Immunization settings for IMZ SO for below flags.
         1. select * from informix.bu_phm_parm where phm_parm_code in(15312,15149); - should be set as 14102-FALSE and 14108- TRUE
         2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248; -should be set as 'TRUE'
          Note: issue_agency_code - will change based on state wise.
    *
    * Author: Lavanya Torrikonda(vn575up)
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-909")
    @Test(description = "Drop FLU order, perform IMZ administration by using Walkin APIs and Validate latest PQCF in PMS",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "WalkinTestData")
    public void HWPHME2E_909_DropFLUOrder_And_Validate_Latest_PQCF_IsUsedTo_Generate_the_Form_With_IMZ_Rph_Details(Map<String, String> inputData) {
        Reporter.log("Drop FLU order, perform IMZ administration by using Walkin APIs and Validate latest PQCF is used to generate the form in PMS");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15312 and 15149 IMZ Rph
        connexusAppUtils.readAndUpdateFlag("15312", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr1"));
        walkinTestScript.flushCache();
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient
        walkinTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform DUR and moves to SrvcAdmn
        walkinTestScript.checkAndPerformCheckDUR();
        walkinTestScript.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkin(inputData);
        //completes POS in Connexus
        walkinTestScript.performPOS();
        //Get Payment Status
        walkinTestScript.performGetPaymentStatus();
        //In PMS screen select IMZ form to view PQCF
        walkinTestScript.verifyServiceDetailsInPMS(inputData);
        Reporter.log("Completed IMZ administration by using Walkin APIs and Validated latest PQCF is used to generate the form in PMS");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Drop a walk-in single order for Covid 5y-11y and complete Administration and validate Service details in PMS.
    * Pre-Conditions:
    * 28750 should set to false in order to login as Pharmacist
      1. Set the store state as : WV
         select * from bus_unit_addr;
      2. To enable the 'Protocol  for State Specific standing order:
         Turn ON Immunization settings for IMZ SO for below flags.
         1. select * from informix.bu_phm_parm where phm_parm_code in(15311,15149); - should be set as 15311-TRUE and 15149-TRUE
         2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248;
          Note: issue_agency_code - will change based on state wise.
    *
    * Author: Lavanya Torrikonda(vn575up)
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-981")
    @Test(description = "Drop a walk-in single order for Covid 5y-11y and complete Administration and validate Service details in PMS",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "WalkinTestData")
    public void HWPHME2E_981_Drop_WalkInOrder_for_Covid_5yto11y_And_Complete_Administration(Map<String, String> inputData) {
        Reporter.log("Drop a walk-in single order for Covid 5y-11y and complete Administration and validate Service details in PMS");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ Rph
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr1"));
        walkinTestScript.flushCache();
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient
        walkinTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform DUR and moves to SrvcAdmn
        walkinTestScript.checkAndPerformCheckDUR();
        walkinTestScript.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkin(inputData);
        //completes POS in Connexus
        walkinTestScript.performPOS();
        //Get Payment Status
        walkinTestScript.performGetPaymentStatus();
        //In PMS screen validate Service details
        walkinTestScript.verifyServiceDetailsInPMS(inputData);
        Reporter.log("Drop a walk-in single order for Covid 5y-11y and complete Administration and validated Service details in PMS");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Drop a walk-in single order for Spikevax BPK for 12y+ and complete Administration and validate Service details in PMS.
    * Pre-Conditions:
    * 28750 should set to false in order to login as Pharmacist
      1. Set the store state as : WV
         select * from bus_unit_addr;
      2. To enable the 'Protocol  for State Specific standing order:
         Turn ON Immunization settings for IMZ SO for below flags.
         1. select * from informix.bu_phm_parm where phm_parm_code in(15311,15149); - should be set as 15311-TRUE and 15149-TRUE
         2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248;
          Note: issue_agency_code - will change based on state wise.
    *
    * Author: Lavanya Torrikonda(vn575up)
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-975")
    @Test(description = "Drop a walk-in single order for Spikevax BPK for 12y+ and complete Administration and validate Service details in PMS",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "WalkinTestData")
    public void HWPHME2E_975_Drop_WalkInOrder_for_Spikevax_BPK_for_12yplus_And_Complete_Administration(Map<String, String> inputData) {
        Reporter.log("Drop a walk-in single order for Spikevax BPK for 12y+ and complete Administration and validate Service details in PMS");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ Rph
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr1"));
        walkinTestScript.flushCache();
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient
        walkinTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform DUR and moves to SrvcAdmn
        walkinTestScript.checkAndPerformCheckDUR();
        walkinTestScript.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkin(inputData);
        //completes POS in Connexus
        walkinTestScript.performPOS();
        //Get Payment Status
        walkinTestScript.performGetPaymentStatus();
        //In PMS screen validate Service details
        walkinTestScript.verifyServiceDetailsInPMS(inputData);
        Reporter.log("Drop a walk-in single order for Spikevax BPK for 12y+ and complete Administration and validated Service details in PMS");
    }

    /*----------------------------------------------------------------------------------------------------------
   * Test Description: Drop a walk-in multi order for Spikevax SDV + FLU for 12y+ and complete Administration and validate Service details in PMS.
   * Pre-Conditions:
   * 28750 should set to false in order to login as Pharmacist
     1. Set the store state as : WV
        select * from bus_unit_addr;
     2. To enable the 'Protocol  for State Specific standing order:
        Turn ON Immunization settings for IMZ SO for below flags.
        1. select * from informix.bu_phm_parm where phm_parm_code in(15311,15149); -should be set as 15311-TRUE and 15149-TRUE
        2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248;
         Note: issue_agency_code - will change based on state wise.
   *
   * Author: Lavanya Torrikonda(vn575up)
   ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1014")
    @Test(description = "Drop a walk-in multi order for Spikevax SDV + FLU for 12y+ and complete Administration and validate Service details in PMS",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "WalkinTestData")
    public void HWPHME2E_1014_Drop_WalkInOrder_for_SpikevaxSDV_And_FLUfor12yplus_And_Complete_Administration(Map<String, String> inputData) {
        Reporter.log("Drop a walk-in multi order for Spikevax SDV + FLU for 12y+ and complete Administration and validate Service details in PMS");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15311 and 15149 IMZ Rph
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr1"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr2"));
        walkinTestScript.flushCache();
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient
        walkinTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForMultiDrugs(inputData);
        //perform DUR and moves to SrvcAdmn
        walkinTestScript.checkAndPerformMultiCheckDUR();
        walkinTestScript.verifyWorkQueueStatusAsServiceAdminForMultiRx();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkinMultiRx(inputData);
        //completes POS in Connexus
        walkinTestScript.performPOSForMultiRx();
        //Get Payment Status
        walkinTestScript.performGetPaymentStatusForMultiRx();
        //In PMS screen validate Service details
        walkinTestScript.verifyServiceDetailsInPMS(inputData);
        Reporter.log("Drop a walk-in multi order for Spikevax SDV + FLU for 12y+ and complete Administration and validated Service details in PMS");
    }

    /*----------------------------------------------------------------------------------------------------------
   * Test Description: Validate user is able to add covid products using the Add Product through walkin Apis and validate Service details in PMS.
   * Pre-Conditions:
   * 28750 should set to false in order to login as Pharmacist
     1. Set the store state as : WV
        select * from bus_unit_addr;
     2. To enable the 'Protocol  for State Specific standing order:
        Turn ON Immunization settings for IMZ SO for below flags.
        1. select * from informix.bu_phm_parm where phm_parm_code in(15311,15149); - should be set as 14102-FALSE and 14108- TRUE
        2. select * from agency_rqmt_parm where restrict_type_code in (14102,14108) and issue_agency_code = 248; -should be set as 'TRUE'
         Note: issue_agency_code - will change based on state wise.
   *
   * Author: Lavanya Torrikonda(vn575up)
   ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-969")
    @Test(description = "Validate user is able to add covid products using the Add Product through walkin Apis and validate Service details in PMS",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "WalkinTestData")
    public void HWPHME2E_969_Validate_user_is_able_to_add_covid_products_using_the_Add_Product_through_walkinApis_And_Complete_Admin(Map<String, String> inputData) {
        Reporter.log("Validate user is able to add covid products using the Add Product through walkin Apis and validate Service details in PMS");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON  setting flag 15312 and 15149 IMZ Rph
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr1"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        walkinTestScript.flushCache();
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient
        walkinTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform DUR and moves to SrvcAdmn
        walkinTestScript.checkAndPerformCheckDUR();
        walkinTestScript.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkinAddProduct(inputData);
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //completes POS in Connexus
        walkinTestScript.performPOSForMultiRx();
        //Get Payment Status
        walkinTestScript.performGetPaymentStatusForMultiRxAddProduct();
        //In PMS screen validate Service details
        walkinTestScript.verifyServiceDetailsInPMS(inputData);
        Reporter.log("Validate user is able to add covid products using the Add Product through walkin Apis and validate Service details in PMS");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Validate that dosage/mL validation screen is displayed for covid orders for pediatric patients.
    * Author: Lavanya Torrikonda(vn575up)
    ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-974")
    @Test(description = "Validate that dosage/mL validation screen is displayed for covid orders for pediatric patients",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "WalkinTestData")
    public void HWPHME2E_974_Validate_Dosage_ML_for_pediatric_patients_And_Complete_Administration_PMS(Map<String, String> inputData) {
        Reporter.log("Validate dosage ML in PMS screen is displayed for covid orders for pediatric patients");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        Reporter.log("Login to Pharmacist flag Disabled");
        // Turn ON  setting flag 15311 and 15149 IMZ Covid Rph
        connexusAppUtils.readAndUpdateFlag("15311", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15149", "TRUE");
        Reporter.log("IMZ Covid flag Enabled");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        Reporter.log("Restrict type value and code for SO");
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        Reporter.log("Restrict type value and code for RPH");
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr1"));
        walkinTestScript.flushCache();
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient
        walkinTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform DUR and moves to SrvcAdmn
        walkinTestScript.checkAndPerformCheckDUR();
        walkinTestScript.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkin(inputData);
        //completes POS in Connexus
        walkinTestScript.performPOS();
        //Get Payment Status
        walkinTestScript.performGetPaymentStatus();
        //In PMS screen validate Dosage info on Service details
        walkinTestScript.verifyServiceDetailsInPMS(inputData);
        Reporter.log("Validate dosage ML in PMS screen is displayed for covid orders for pediatric patients");
    }

    /*----------------------------------------------------------------------------------------------------------
       * Test Description: Validate Fax is sent to PCP after Vaccine is administered and PCP notified with Times stamp
                          [COVID Flag ON][RPH Auth][COVID Drug] Mutli Rx.
       * Author: Lavanya Torrikonda(vn575up)
     ------------------------------------------------------------------------------------------------------------*/
    //*@Jira(testID = "HWPHME2E-1023")
    @Test(description = "Validate Fax is sent to PCP after Vaccine is administered and PCP notified with Times stamp for Multi order",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "WalkinFaxPCPTestData")
    public void HWPHME2E_1023_CovidRPH_Validate_Fax_sent_to_PCP_after_Vaccine_administered_and_PCP_notified_with_Times_stamp_for_MultiOrder(Map<String, String> inputData) {
        Reporter.log("Validate Fax is sent to PCP after Vaccine is administered and PCP notified with Times stamp for Multi order");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        Reporter.log("Login to Pharmacist flag Disabled");
        //Cfax flag Enable Fax Hybrid Flow
        connexusAppUtils.readAndUpdateFlag("20050", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("20050", "TRUE");
        // Turn ON  IMZ settings flag for Rph
        connexusAppUtils.readAndUpdateFlag("15313", "FALSE");
        connexusAppUtils.fetchPharmacyCodeTxt("15313", "FALSE");
        connexusAppUtils.readAndUpdateFlag("15314", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15314", "TRUE");

        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        // Turn ON  IMZ settings flag for Rph
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14102");
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14108");
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr1"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr2"));
        walkinTestScript.flushCache();
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient
        walkinTestScript.createNewPatient(inputData);
        //Adding PCP on PMS
        walkinTestScript.addPrescriberOnProfileTab(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForMultiDrugs(inputData);
        //perform DUR and moves to SrvcAdmn
        walkinTestScript.checkAndPerformMultiCheckDUR();
        walkinTestScript.verifyWorkQueueStatusAsServiceAdminForMultiRx();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkinMultiRx(inputData);
        //completes POS in Connexus
        walkinTestScript.performPOSForMultiRx();
        //Validation Of Fax
        walkinTestScript.validateRphPCPFaxIdStatusUnderActionItems();
        //Validate PCP fax id generated, entry and service activity in DB
        walkinTestScript.validatePCPFaxIdEntryAndServiceActivityDetailsForMultiOrder(inputData);
        //Validate Fax is sent to PCP Profile set up on the patient profile.
        walkinTestScript.validateFaxPCPNotificationInPMSForMultiOrder(inputData);
        Reporter.log("Validate Fax is sent to PCP after Vaccine is administered and PCP notified with Times stamp for Multi order");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: [COVID Flag ON][SO][COVID Drug] Validate Fax is sent to PCP after Vaccine is administered-Multi RX
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1024")
    @Test(description = "Validate Fax is sent to PCP after Vaccine is administered and PCP notified with Times stamp for Multi order",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "WalkinFaxPCPTestData")
    public void HWPHME2E_1024_CovidSO_Validate_Fax_sent_to_PCP_after_Vaccine_administered_for_MultiOrder(Map<String, String> inputData) {
        Reporter.log("Validate Fax is sent to PCP after Vaccine is administered and PCP notified with Times stamp for Multi order");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        Reporter.log("Login to Pharmacist flag Disabled");
        //Cfax flag Enable Fax Hybrid Flow
        connexusAppUtils.readAndUpdateFlag("20050", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("20050", "TRUE");
        // Turn ON  IMZ settings flag for SO
        connexusAppUtils.readAndUpdateFlag("15313", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("15313", "TRUE");
        connexusAppUtils.readAndUpdateFlag("15314", "FALSE");
        connexusAppUtils.fetchPharmacyCodeTxt("15314", "FALSE");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        // Turn ON  IMZ settings flag for SO
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14102");
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14108");
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr1"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr2"));
        walkinTestScript.flushCache();
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient
        walkinTestScript.createNewPatient(inputData);
        //Adding PCP on PMS
        walkinTestScript.addPrescriberOnProfileTab(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForMultiDrugs(inputData);
        //perform DUR and moves to SrvcAdmn
        walkinTestScript.checkAndPerformMultiCheckDUR();
        walkinTestScript.verifyWorkQueueStatusAsServiceAdminForMultiRx();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkinMultiRx(inputData);
        //completes POS in Connexus
        walkinTestScript.performPOSForMultiRx();
        //Validation Of Fax
        walkinTestScript.validateRphPCPFaxIdStatusUnderActionItems();
        //Validate PCP fax id generated, entry and service activity in DB
        walkinTestScript.validatePCPFaxIdEntryAndServiceActivityDetailsForMultiOrder(inputData);
        //Validate Fax is sent to PCP Profile set up on the patient profile.
        walkinTestScript.validateFaxPCPNotificationInPMSForMultiOrder(inputData);
        Reporter.log("Validate Fax is sent to PCP after Vaccine is administered and PCP notified with Times stamp for Multi order");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: [Regression][SO] Validate orders are cancelled with the nightly job when patient does not show up
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1107")
    @Test(description = "Validate orders are cancelled with the nightly job when patient does not show up",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "WalkinTestData")
    public void HWPHME2E_1107_Validate_orders_are_cancelled_with_nightly_job_when_patient_does_not_show_up(Map<String, String> inputData) {
        Reporter.log("Validate orders are cancelled with the nightly job in PMS clinical services tab");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        Reporter.log("Login to Pharmacist flag Disabled");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        // Turn ON  IMZ settings flag for SO
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14102");
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14108");
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr1"));
        walkinTestScript.flushCache();
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient
        walkinTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform DUR and moves to SrvcAdmn
        walkinTestScript.checkAndPerformCheckDUR();
        walkinTestScript.verifyWorkQueueStatusAsServiceAdmin();
        //Trigger the Cleanup job
        walkinTestScript.runConnexusScript(inputData);
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //Trigger the Cleanup job and validate the IMZ Scheduled Order status.
        walkinTestScript.validateIMZScheduledOrderStatusInPMS(inputData);
        Reporter.log("Validated orders are cancelled with the nightly job in PMS clinical services tab");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description: Validate Fax is sent to SO prescriber after Vaccine is administered. - Multi RX
     * Jira(testID = "HWPHME2E-4478")
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Fax is sent to SO prescriber notified with time stamp after Vaccine is administered for Multi order",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "WalkinFaxPCPTestData")
    public void HWPHME2E_4478_Validate_Fax_sent_to_SO_prescriber_after_Vaccine_administered_for_MultiOrder(Map<String, String> inputData) {
        Reporter.log("Validate Fax is sent to SO prescriber notified date after Vaccine is administered for Multi order");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        Reporter.log("Login to Pharmacist flag Disabled");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        //Cfax flag Enable Fax Hybrid Flow
        connexusAppUtils.readAndUpdateFlag("20050", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("20050", "TRUE");
        // Turn ON  IMZ settings flags
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14102", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14102");
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "14108", stateCode);
        connexusAppUtils.fetchPharmacyCodeTxt("14108");
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr1"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr2"));
        walkinTestScript.flushCache();
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient
        walkinTestScript.createNewPatient(inputData);
        //Drop an order, Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForMultiDrugs(inputData);
        //perform DUR and moves to SrvcAdmn
        walkinTestScript.checkAndPerformMultiCheckDUR();
        walkinTestScript.verifyWorkQueueStatusAsServiceAdminForMultiRx();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkinMultiRx(inputData);
        //completes POS in Connexus
        walkinTestScript.performPOSForMultiRx();
        //verify work queue status is in EOD
        walkinTestScript.verifyWorkQueueStatusAsEOD();
        //All Order administered with SO drugs/protocol will be reported after a nightly job +
        //Trigger the nightly job for process IMZ SO Fax
        walkinTestScript.runConnexusScript(inputData);
        //Validation Of Fax outbound under Action Items
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        walkinTestScript.validateSOFaxIdStatusUnderActionItems();
        //Validate entry found in service activity and Successfully sent for SO fax
        walkinTestScript.validateServiceActivityDetailsInDB(inputData);
        // Validate Standing Order Prescriber Notified Time Stamp in PMS
        walkinTestScript.validateSOPrescriberNotifiedInPMS(inputData);
        Reporter.log("Validated Fax is sent to SO prescriber notified date after Vaccine is administered for Multi order");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Validate TP to TP change post save product and check inventory for walkin flow
    * Jira(testID = "HWPHME2E-4818")
    * Author: Lavanya Torrikonda(vn575up)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate TP to TP change post save product and check inventory for walkin flow",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "WalkinTestData")
    public void HWPHME2E_4818_Validate_TPToTP_change_post_save_product_and_check_inventory(Map<String, String> inputData) {
        Reporter.log("Validate TP to TP change post save product and check inventory for walkin flow");
        //Pre-condition
        flagsSetup(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr1"));
        walkinTestScript.initializeTestCase(flagUpdated);

        //Create a new patient with a TP plan
        walkinTestScript.createNewPatient(inputData, 1);
        //Retrieve the initial quantities of the product from the DB
        Map<String, Integer> previousQuantities1 = connexusAppUtils.getPharmacyItemQuantities(inputData.get("ndc_nbr1"));
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //Verify quantities of the product after imz drop-off
        Map<String, Integer> previousQuantities2 = connexusAppUtils.validateAndGetQuantities(inputData.get("ndc_nbr1"), previousQuantities1);
        //perform chkDUR and close ClinIntel Screen
        walkinTestScript.performCheckDURAndClinIntel();
        //Verify quantities of the product after svcAdmin
        Map<String, Integer> previousQuantities3 = connexusAppUtils.validateAndGetQuantities(inputData.get("ndc_nbr1"), previousQuantities2);
        //Performs IMZ administration for unassigned orders using Walkin APIs
        walkinTestScript.performImzAdministrationForUnassignOrders(inputData);
        //Verify quantities of the product after imz drop-off
        Map<String, Integer> previousQuantities4 = connexusAppUtils.validateAndGetQuantities(inputData.get("ndc_nbr1"), previousQuantities3);
        //Change the billing from TP to TP in Modify Details
        walkinTestScript.changeBillingFromTPToTPInModifyDetails(inputData, inputData.get("DRUG_NAME1"));
        //Validate DB quantities of the product after svcAdmn modified details
        Map<String, Integer> previousQuantities5 = connexusAppUtils.validateAndGetQuantities(inputData.get("ndc_nbr1"), previousQuantities4);
        //Performs IMZ administration for assigned orders using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkin(inputData);
        //Verify quantities of the product after imz administration
        connexusAppUtils.validateAndGetQuantities(inputData.get("ndc_nbr1"), previousQuantities5);
        Reporter.log("Validated TP to TP change post save product and check inventory for walkin flow");
    }
    
}
