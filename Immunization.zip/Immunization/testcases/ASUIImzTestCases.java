package clinicalservices.Immunization.testcases;

import clinicalservices.Immunization.testScripts.*;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.prop;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.imzapp.constants.Constants.CS_IMZ_APP_STORE_ID;

public class ASUIImzTestCases {
    ImzTestScripts imzTestScripts = new ImzTestScripts();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ASUITestScripts asuiTestScripts = new ASUITestScripts();
    WalkinTestScript walkinTestScript = new WalkinTestScript();
    String stateCode = "";
    public boolean flagUpdated = false;

    @BeforeClass
    public void startAppiumServer() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    //update common flags
    public void flagsSetup(Map<String, String> inputData) {
        //Verify and set the flag to login to Pharmacist
        flagUpdated = connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        //update state
        flagUpdated |= connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("PHARMACY_STATE"));
        connexusAppUtils.getLogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        // Turn ON  IMZ settings and Clin Intel flags
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y", "14102", stateCode);
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y", "14108", stateCode);
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15337", "TRUE");
    }

    @Test(enabled = true, description = "Validate E2E For Arexvy", priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ASUITestData")
    public void HWPHME2E_3101_Validate_E2E_For_Arexvy(Map<String, String> appointmentInfo) {
        //PreConditions: 1. 28750 should set to false in order to login as Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        connexusAppUtils.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        imzTestScripts.flushCache();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //Creating ASUI Scheduling Order by using APIs
        asuiTestScripts.createASUIOrderToConnexus(appointmentInfo, true, true);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);
        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration  by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);
        //completes POS in Connexus
        imzTestScripts.performPOS();
        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);
        //cosmos DB Validation
        asuiTestScripts.validationOfDataInCosmos(appointmentInfo,true);
        Reporter.log("Completed Administration of ASUI order using IMZ APIs and Validated data in PMS and COSMOS");
    }

    //HWPHME2E-3102 and HWPHME2E-4682 both the testcases are covered
    @Test(enabled = true, description = "Validate E2E For Abrysvo", priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ASUITestData")
    public void HWPHME2E_3102_Validate_E2E_For_Abrysvo(Map<String, String> appointmentInfo) {
        //PreConditions: 1. 28750 should set to false in order to login as Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        connexusAppUtils.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        imzTestScripts.flushCache();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //Creating ASUI Scheduling Order by using APIs
        asuiTestScripts.createASUIOrderToConnexus(appointmentInfo, true, true);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);
        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration  by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);
        //completes POS in Connexus
        imzTestScripts.performPOS();
        //Validate IMZ Registry Value for a new Patient as part of HWPHME2E-4682 TC
        imzTestScripts.validateImzRegistryFromPMS(appointmentInfo);
        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);
        //cosmos DB Validation
        asuiTestScripts.validationOfDataInCosmos(appointmentInfo,true);
        Reporter.log("Completed Administration of ASUI order using IMZ APIs and Validated data in PMS and COSMOS");
    }

    @Test(enabled = true, description = "Validate Drug Substitution for Novavax", priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ASUITestData")
    public void HWPHME2E_3103_Validate_Drug_Substitution_for_Novavax(Map<String, String> appointmentInfo) {
        //PreConditions: 1. 28750 should set to false in order to login as Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        connexusAppUtils.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        imzTestScripts.flushCache();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //Creating ASUI Scheduling Order by using APIs
        asuiTestScripts.createASUIOrderToConnexus(appointmentInfo, true, true);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //connexus search for patient and perform resolution
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);
        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration  by using APIs
        imzTestScripts.performImZAdministration(appointmentInfo);
        //completes POS in Connexus
        imzTestScripts.performPOS();
        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMS(appointmentInfo);
        //cosmos DB Validation
        asuiTestScripts.validationOfDataInCosmos(appointmentInfo,true);
        Reporter.log("Completed Administration of ASUI order using IMZ APIs and Validated data in PMS and COSMOS");
    }
    @Test(enabled = true, description = "Validate user is able to process ASUI order like walkin order/imzRegistry value in PMS screen(HWPHME2E-1021,HWPHME2E-4683)", priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ASUITestData")
    public void HWPHME2E_1021_For_a_New_Patient_Validate_User_is_able_to_Process_an_ASUI_Order_Like_a_walkin_Order_in_Connexus_once_PQCF_is_Submitted_in_OneDay_Remainder_Text(Map<String, String> appointmentInfo) {
        //PreConditions: 1. 28750 should set to false in order to login as Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        //Updating CI Flag to False to move the order directly to SVC ADMIN
        connexusAppUtils.readAndUpdateFlag("15337", "FALSE");
        connexusAppUtils.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        imzTestScripts.flushCache();
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //Creating ASUI Scheduling Order by using APIs
        asuiTestScripts.createASUIOrderToConnexus(appointmentInfo, true, false);
        walkinTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //Hostpull a patient in PMS
        walkinTestScript.createPatientFromHostProfileFromPMS(appointmentInfo);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(appointmentInfo,false);
        //perform DUR and moves to SrvcAdmn
        walkinTestScript.checkAndPerformCheckDUR();
        walkinTestScript.verifyWorkQueueStatusAsServiceAdmin();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkin(appointmentInfo);
        //completes POS in Connexus
        walkinTestScript.performPOS();
        //Validate IMZ Registry Value for an existing Patient as part of HWPHME2E-4683 TC
        imzTestScripts.validateImzRegistryFromPMS(appointmentInfo);
        //In PMS screen validate Service details
        walkinTestScript.verifyServiceDetailsInPMS(appointmentInfo);
        //cosmos DB Validation
        asuiTestScripts.validationOfDataInCosmos(appointmentInfo,true);
        Reporter.log("Completed Administration of ASUI order using IMZ APIs and Validated data in PMS and COSMOS");
    }
    @Test(enabled = true, description = "Validate User is able to Process and RSV Order till EOD for a Existing patient", priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ASUITestData")
    public void HWPHME2E_1022_Validate_User_is_able_to_Process_and_RSV_Order_till_EOD_for_a_Existing_patient(Map<String, String> appointmentInfo) {
        //PreConditions: 1. 28750 should set to false in order to login as Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        connexusAppUtils.updateStateValue(appointmentInfo.get("PHARMACY_STATE"));
        //update inventory quantity
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        imzTestScripts.flushCache();
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //Creating ASUI Scheduling Order by using APIs
        asuiTestScripts.createASUIOrderToConnexus(appointmentInfo,false,true);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //connexus search for patient and perform resolution
        imzTestScripts.verifyExistingPatientWorkQueueAndProblemStatus();
        //perform DUR and moves to SrvcAdmn
        imzTestScripts.checkAndPerformCheckDURForExistingPatient(appointmentInfo);
        imzTestScripts.verifyWorkQueueStatusAsServiceAdminForExistingPateint();
        //performs IMZ administration  by using APIs
        imzTestScripts.performImZAdministrationForExistingPatient(appointmentInfo);
        //completes POS in Connexus
        imzTestScripts.performPOS();
        //Validating details in PMS
        imzTestScripts.verifyServiceDetailsInPMSForExistingPatient(appointmentInfo);
        //cosmos DB Validation
        asuiTestScripts.validationOfDataInCosmos(appointmentInfo,false);
        Reporter.log("Completed Administration of ASUI order using IMZ APIs and Validated data in PMS and COSMOS");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description: Validate CASH to TP change post save product and check inventory for ASUI flow
    * Jira(testID = "HWPHME2E-4819")
    * Author: Lavanya Torrikonda(vn575up)
   ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Cash to TP change post save product and check inventory for ASUI flow",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ASUITestData")
    public void HWPHME2E_4819_Validate_CashToTP_change_post_save_product_and_check_inventory(Map<String, String> appointmentInfo) {
        Reporter.log("Validate CASH to TP change post save product and check inventory for ASUI flow");
        //Pre-condition
        flagsSetup(appointmentInfo);
        //Central host pull flag
        flagUpdated = connexusAppUtils.readAndUpdateFlag("26846", "TRUE");
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        walkinTestScript.initializeTestCase(flagUpdated);

        //Retrieve the initial quantities of the product from the DB
        Map<String, Integer> previousQuantities1 = connexusAppUtils.getPharmacyItemQuantities(appointmentInfo.get("DRUG_NAME"));

        //Creating ASUI Scheduling Order by using APIs
        asuiTestScripts.createASUIOrderToConnexus(appointmentInfo, true, false);
        imzTestScripts.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //Retrieve the initial quantities of the product from the DB
        Map<String, Integer> previousQuantities2 = connexusAppUtils.validateAndGetQuantities(appointmentInfo.get("DRUG_NAME"), previousQuantities1);
        //Hostpull a patient in PMS
        walkinTestScript.createPatientFromHostProfileFromPMS(appointmentInfo);
        //Verify quantities of the product after create patient
        Map<String, Integer> previousQuantities3 = connexusAppUtils.validateAndGetQuantities(appointmentInfo.get("DRUG_NAME"), previousQuantities2);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(appointmentInfo,false);
        //Verify quantities of the product after imz drop-off
        Map<String, Integer> previousQuantities4 = connexusAppUtils.validateAndGetQuantities(appointmentInfo.get("DRUG_NAME"), previousQuantities3);
        //perform chkDUR and close ClinIntel Screen
        walkinTestScript.performCheckDURAndClinIntel();
        //Verify quantities of the product after svcAdmin
        Map<String, Integer> previousQuantities5 = connexusAppUtils.validateAndGetQuantities(appointmentInfo.get("DRUG_NAME"), previousQuantities4);
        //Performs IMZ administration for unassigned orders using Walkin APIs
        walkinTestScript.performImzAdministrationForUnassignOrders(appointmentInfo);
        //Validate DB quantities of the product after svcAdmn modified details
        Map<String, Integer> previousQuantities6 = connexusAppUtils.validateAndGetQuantities(appointmentInfo.get("DRUG_NAME"), previousQuantities5);
        //Change the billing from CASH to TP in Modify Details
        walkinTestScript.changeBillingFromCashToTPInModifyDetails(appointmentInfo, appointmentInfo.get("DRUG_NAME1"));
        //Validate DB quantities of the product after svcAdmn modified details
        Map<String, Integer> previousQuantities7 = connexusAppUtils.validateAndGetQuantities(appointmentInfo.get("DRUG_NAME"), previousQuantities6);
        //Performs IMZ administration for assigned orders using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkin(appointmentInfo);
        //Verify quantities of the product after imz administration
        connexusAppUtils.validateAndGetQuantities(appointmentInfo.get("DRUG_NAME"), previousQuantities7);
        Reporter.log("Validated CASH to TP change post save product and check inventory for ASUI flow");
    }

}