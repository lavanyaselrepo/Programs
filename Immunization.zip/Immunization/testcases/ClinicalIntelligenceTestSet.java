package clinicalservices.Immunization.testcases;

import clinicalservices.Immunization.testScripts.ClinicalIntelligenceTestScripts;
import clinicalservices.Immunization.testScripts.WalkinTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.processImzOrderRequest;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.ProcessImzOrderRequestWrapper.questionsWithAllFalse;

public class ClinicalIntelligenceTestSet {
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    WalkinTestScript walkinTestScript = new WalkinTestScript();
    ClinicalIntelligenceTestScripts clinicalIntelligenceTestScript = new ClinicalIntelligenceTestScripts(LoginAs.userType.PHARMACIST_ADFlagOff);
    PropertyReader prop = PropertyReader.getInstance();
    protected int storeId;
    String siteId = prop.getProperty("cnx.store");
    boolean flagUpdated = false;
    String stateCode = "";

    @BeforeClass
    public void performlogin() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }

    //update common flags
    public void flagsSetup(Map<String, String> inputData) {
        //Verify and set the flag to login to Pharmacist
        flagUpdated = connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        //update state
        flagUpdated |= connexusAppUtils.updateStateValue(inputData.get("STATE"));
        stateCode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + stateCode);
        // Turn ON  IMZ settings and Clin Intel flags
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y", "14102", stateCode);
        flagUpdated |= connexusAppUtils.updateAgencyRequirementParmTbl("Y", "14108", stateCode);
        flagUpdated |= connexusAppUtils.readAndUpdateFlag("15337", "TRUE");
    }

    @Test(enabled = true, description = "Verify Clinical Intelligence Button is visible but not enabled for technician",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5088_Verify_Clinical_Intelligence_Button_is_visible_but_not_enabled_for_technician(Map<String, String> inputData) {
        Reporter.log("Verify Clinical Intelligence Button is visible but not enabled for technician");
        flagsSetup(inputData);

        clinicalIntelligenceTestScript.setLoginUserType(LoginAs.userType.TECHNICIAN_ADFlagOff);
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);
        clinicalIntelligenceTestScript.validateClinicalIntelligenceBtnDisabled();
    }

    @Test(enabled = true, description = "Verify that pharmacist is able to see clinical Intelligence and do ad hoc clinical Intelligence look up through F7 by clicking Clinical Intelligence Button.",
            priority = 2)
    public void HWPHME2E_5096_Verify_pharmacist_able_to_see_clinical_Intelligence_and_do_ad_hoc_clinical_Intelligence_look_up_through_F7_by_clicking_Clinical_Intelligence_Button() {
        Reporter.log("Verify that pharmacist is able to see clinical Intelligence and do ad hoc clinical Intelligence look up through F7 by clicking Clinical Intelligence Button");
        // Enable Clinical Intelligence Phase 1 flag
        flagUpdated = connexusAppUtils.updateFlagValueBasedOnCode("15337", "TRUE");
        Reporter.log("Updated parm value for 15337 (Clinical Intelligence Phase 1 flag)");
        // Enable Clinical Intelligence Phase 2 flag
        flagUpdated |= connexusAppUtils.updateFlagValueBasedOnCode("15338", "TRUE");
        Reporter.log("Updated parm value for 15338 (Clinical Intelligence Phase 2 flag)");
        // Create patient and drop prescription via API, returns [lastName, firstName]
        String[] patientName = clinicalIntelligenceTestScript.createPatientAndDropOrderForCIAdHoc();
        // Login as Pharmacist and open F7/RxLookup to search for the patient
        clinicalIntelligenceTestScript.setLoginUserType(LoginAs.userType.PHARMACIST_ADFlagOff);
        clinicalIntelligenceTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);
        // Open F7 RxLookup, search for the patient, verify CI button is ENABLED and click it
        clinicalIntelligenceTestScript.validateCIEnabledInF7Screen(patientName[0], patientName[1]);
    }

    @Test(enabled = true, description = "Verify that pharmacist is able to see clinical Intelligence and do ad hoc clinical Intelligence look up through F6",
            priority = 3)
    public void HWPHME2E_5094_Verify_that_pharmacist_is_able_to_see_clinical_Intelligence_and_do_ad_hoc_clinical_Intelligence_look_up_through_F6() {
        Reporter.log("Verify that pharmacist is able to see clinical Intelligence and do ad hoc clinical Intelligence look up through F6");
        Reporter.log("Logged in store:" + siteId);
        // Enable Clinical Intelligence Phase 1 flag
        flagUpdated = connexusAppUtils.updateFlagValueBasedOnCode("15337", "TRUE");
        Reporter.log("Updated parm value for 15337 (Clinical Intelligence Phase 1 flag)");
        // Enable Clinical Intelligence Phase 2 flag
        flagUpdated |= connexusAppUtils.updateFlagValueBasedOnCode("15338", "TRUE");
        Reporter.log("Updated parm value for 15338 (Clinical Intelligence Phase 2 flag)");
        // Create patient and drop prescription via API, returns [lastName, firstName]
        String[] patientName = clinicalIntelligenceTestScript.createPatientAndDropOrderForCIAdHoc();
        // Login as Pharmacist and open F6/OrderSearch to search for the patient
        clinicalIntelligenceTestScript.setLoginUserType(LoginAs.userType.PHARMACIST_ADFlagOff);
        clinicalIntelligenceTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);
        // Open F6 Order Search, search for the patient, verify CI button is ENABLED and click it
        clinicalIntelligenceTestScript.validateCIEnabledInF6Screen(patientName[0], patientName[1]);
    }


    @Test(enabled = true, description = "Verify Flu And Covid Recommendations Are Labelled As Annual",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5247_Verify_Flu_Covid_Recommendations_Are_Labelled_As_Annual(Map<String, String> inputData) {
        Reporter.log("Verify that Covid and Flu recommendations are labeled as Annual.");
        Reporter.log("Logged in store:" + siteId);
        flagsSetup(inputData);
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);
        clinicalIntelligenceTestScript.createNewPatient(inputData);
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        walkinTestScript.checkAndPerformCheckDUR();
        clinicalIntelligenceTestScript.checkAndOpenClinIntel();
        clinicalIntelligenceTestScript.validateFluAndCovidLabel();
    }

    // Jira(testID = "HWPHME2E-5095")
    @Test(enabled = true, description = "Verify if patient maintenance screen opens on click on patient panel on CI screen",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5095_Validate_patient_maintenance_screen_opens_and_click_on_patient_panel_on_CI_screen(Map<String, String> inputData) {
        Reporter.log("Validate patient maintenance screen opens and click on patient panel on CI screen");
        //Pre-condition
        flagsSetup(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);

        //Create a new patient
        clinicalIntelligenceTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform chkDUR for IMZ
        walkinTestScript.checkAndPerformCheckDUR();
        //validate PMS screen is opening through CI screen
        clinicalIntelligenceTestScript.validatePMSInClinIntel();
        Reporter.log("Validated patient maintenance screen opens and click on patient panel on CI screen");
    }
//   Blocked for Phase-2 Development test, once resolved will resume back
  /*  @Test(enabled = false, description = "Verify that the Order moves to CI WQ and user able to add IMZ recommendations for QR Scan orders", priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "QRScanTestData")
    public void HWPHME2E_5081_QRScan_CI_WQ(Map<String, String> appointmentInfo) {
        Reporter.log("Validate QR Scan Order moves to CI WQ with enabled CI Button ");
        Reporter.log("Logged in store:" + siteId);

        //update inventory quantity and CI WQ Flag
        connexusAppUtils.updateInventoryQuantity(appointmentInfo.get("DRUG_NAME"));
        flagUpdated = connexusAppUtils.updateFlagValueBasedOnCode("15337", "TRUE");
        Reporter.log("Updated pharm value for 15337 Flag To enable Clinical Intelligence on CNX");

        // Create QR Scan order
        processImzOrderRequest(Integer.parseInt(siteId), questionsWithAllFalse(), appointmentInfo);
        imzTestScripts.initializeTestCase(flagUpdated);
        //verify WQ And Problem Status
        imzTestScripts.verifyPatientWorkQueueAndProblemStatus();
        imzTestScripts.performPatientSearchAndPatientCreation(appointmentInfo);
        //perform DUR and moves to ClinicalIntelligence
        imzTestScripts.checkAndPerformCheckDUR(appointmentInfo);
        clinicalIntelligenceTestScript.validateClinicalIntelligenceBtnEnabled();
    }*/

    @Test(enabled = true, description = "Verify that Inventory is displayed correctly in Product Selection Modal of Clinical Intelligence View",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5249_Verify_inventory_is_displayed_correctly_in_product_selection_modal(Map<String, String> inputData) {
        Reporter.log("Verify that Inventory is displayed correctly in Product Selection Modal of Clinical Intelligence View");
        Reporter.log("Logged in store:" + siteId);
        flagsSetup(inputData);
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);
        clinicalIntelligenceTestScript.createNewPatient(inputData);
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        walkinTestScript.checkAndPerformCheckDUR();
        clinicalIntelligenceTestScript.checkAndOpenClinIntel();
        clinicalIntelligenceTestScript.validateInventoryOnAddProductPopUp();
    }

    @Test(enabled = true, description = "When an Rx is in Clinical Intelligence WQ , for technician on double click on the IMZ order it should open RX modify details in non-editable mode except for TP",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5083_Verify_TP_Enabled_in_Clinical_Intelligence_Queue_for_technician(Map<String, String> inputData) {
        Reporter.log("Validate IMZ Order in CI WQ should provide TP access to the Technician in Modify Details Screen");
        Reporter.log("Logged in store:" + siteId);
        flagUpdated = connexusAppUtils.updateFlagValueBasedOnCode("15337", "TRUE");
        Reporter.log("Updated pharm value for 15337 (Flag To enable Clinical Intelligence on CNX");
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);

        //Create a new patient
        clinicalIntelligenceTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform chkDUR for IMZ
        walkinTestScript.checkAndPerformCheckDUR();
        clinicalIntelligenceTestScript.validateClinicalIntelligenceBtnDisabled();
        //Login as Technician
        clinicalIntelligenceTestScript.loginConnexus(LoginAs.userType.TECHNICIAN_ADFlagOff);
        Reporter.log("Logged in as a Technician");
        //Validate ModifyDetails
        clinicalIntelligenceTestScript.verifyIMZModifyDetailsCI();
        Reporter.log("Verify TP is enabled for technician");
    }

    // Jira(testID = "HWPHME2E-5091")
    @Test(enabled = true, description = "Verify the user able to add recommendation and process it with cash payment",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5091_Verify_user_able_to_add_recommendation_and_process_it_with_cash_payment(Map<String, String> inputData) {
        Reporter.log("Verify the user able to add recommendation and process it with cash payment");
        //Pre-condition
        flagsSetup(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);

        //Create a new patient
        clinicalIntelligenceTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform chkDUR for IMZ
        walkinTestScript.checkAndPerformCheckDUR();
        //verify ClinIntel Screen
        clinicalIntelligenceTestScript.checkAndOpenClinIntel();
        //Verify Patient Details at the top displayed
        clinicalIntelligenceTestScript.verifyPatientDetailsDisplayed();
        //validate the In-progress lock section
        clinicalIntelligenceTestScript.validateInProgressOrderForLockIconPanel(inputData);
        //validate the recommended section
        clinicalIntelligenceTestScript.validateRecommendedSectionWithDetails();
        //validate history section
        clinicalIntelligenceTestScript.validateHistorySection();
        //Add and validate recommendation product in in-progress section
        clinicalIntelligenceTestScript.addRecommendedProductInProgressSection(1,1);
        clinicalIntelligenceTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //perform chkDUR and moves to SvcAdmn
        walkinTestScript.checkAndPerformMultiCheckDUR();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkinMultiRx(inputData);
        //completes POS in Connexus
        walkinTestScript.performPOSForMultiRx();
        //Get Payment Status
        walkinTestScript.performGetPaymentStatusForMultiRx();
        //validate history in EOD
        clinicalIntelligenceTestScript.checkAndValidateHistoryInEOD();
        //In PMS screen validate Service details
        walkinTestScript.verifyServiceDetailsInPMSForMultiRx(inputData);
        Reporter.log("Verify the user able to add recommendation and process it with cash payment");
    }

    @Test(enabled = true, description = "Verify that Inventory is displayed correctly in Manual add Flow of Clinical Intelligence View",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5246_Verify_Inventory_Displayed_Correctly_In_Manual_Add_Flow(Map<String, String> inputData) {
        Reporter.log("Verify that Inventory is displayed correctly in Manual add Flow of Clinical Intelligence View");
        Reporter.log("Logged in store:" + siteId);
        flagUpdated = connexusAppUtils.updateFlagValueBasedOnCode("15337", "TRUE");
        Reporter.log("Updated parm value for 15337 (Flag To enable Clinical Intelligence on CNX");
        clinicalIntelligenceTestScript.initializeTestCase(false);
        clinicalIntelligenceTestScript.createNewPatient(inputData);
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        walkinTestScript.checkAndPerformCheckDUR();
        clinicalIntelligenceTestScript.checkAndOpenClinIntel();
        clinicalIntelligenceTestScript.validateInventoryDisplayedInDescendingOrderOnProductPopUp();
    }

    // Jira(testID = "HWPHME2E-5089")
    @Test(description = "Verify the user able to change product after recommendation moved to in-progress",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5089_Verify_user_able_to_change_product_after_recommendation_moved_to_inprogress(Map<String, String> inputData) {
        Reporter.log("Verify the user able to change product after recommendation moved to in-progress");
        //Pre-condition
        flagsSetup(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);

        clinicalIntelligenceTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform chkDUR for IMZ
        walkinTestScript.checkAndPerformCheckDUR();
        //verify ClinIntel Screen
        clinicalIntelligenceTestScript.checkAndOpenClinIntel();
        //Verify Patient Details at the top displayed
        clinicalIntelligenceTestScript.verifyPatientDetailsDisplayed();
        //validate the In-progress lock section
        clinicalIntelligenceTestScript.validateInProgressOrderForLockIconPanel(inputData);
        //validate the recommended section
        clinicalIntelligenceTestScript.validateRecommendedSectionWithDetails();
        //validate history section
        clinicalIntelligenceTestScript.validateHistorySection();
        // Add and Change product and validate recommended product in in-progress section
        clinicalIntelligenceTestScript.addAndChangeRecommendedProductInProgressSection(1,1, 2);
        Reporter.log("Validated the user able to change product after recommendation moved to in-progress");
    }

    // Jira(testID = "HWPHME2E-5087")
    @Test(enabled = true, description = "Verify the user able to suppress recommendation",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5087_Verify_user_able_to_suppress_recommendation(Map<String, String> inputData) {
        Reporter.log("Validate the user able to suppress recommendation details");
        //Pre-condition
        flagsSetup(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);

        //Create a new patient
        clinicalIntelligenceTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform chkDUR for IMZ
        walkinTestScript.checkAndPerformCheckDUR();
        //verify ClinIntel Screen
        clinicalIntelligenceTestScript.checkAndOpenClinIntel();
        //Verify Patient Details at the top displayed
        clinicalIntelligenceTestScript.verifyPatientDetailsDisplayed();
        //validate the In-progress lock section
        clinicalIntelligenceTestScript.validateInProgressOrderForLockIconPanel(inputData);
        //validate the recommended section
        clinicalIntelligenceTestScript.validateRecommendedSectionWithDetails();
        //Add removal reason for suppress recommendation
        clinicalIntelligenceTestScript.suppressRecommendationForNotInterested(1, 1);
        //validate suppressed recommendation panel
        clinicalIntelligenceTestScript.validateSuppressedRecommendationPanel();
        Reporter.log("Validated the user able to suppress recommendation details");
    }

    // Jira(testID = "HWPHME2E-5093")
    @Test(description = "Verify the user able to add recommendation and process it with TP payment",
            priority = 12, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5093_Verify_user_able_to_add_recommendation_and_process_it_with_TP_payment(Map<String, String> inputData) {
        Reporter.log("Verify the user able to add recommendation and process it with TP payment");
        //Pre-condition
        flagsSetup(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);

        //Create a new patient with a TP plan
        clinicalIntelligenceTestScript.createNewPatient(inputData,1);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform chkDUR for IMZ
        walkinTestScript.checkAndPerformCheckDUR();
        //verify ClinIntel Screen
        clinicalIntelligenceTestScript.checkAndOpenClinIntel();
        //Verify Patient Details at the top displayed
        clinicalIntelligenceTestScript.verifyPatientDetailsDisplayed();
        //validate the In-progress lock section
        clinicalIntelligenceTestScript.validateInProgressOrderForLockIconPanel(inputData);
        //validate the recommended section
        clinicalIntelligenceTestScript.validateRecommendedSectionWithDetails();
        //validate history section
        clinicalIntelligenceTestScript.validateHistorySection();
        //Add and validate recommendation product in in-progress section
        clinicalIntelligenceTestScript.addRecommendedProductInProgressSection(1,1);
        clinicalIntelligenceTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //perform chkDUR and moves to SvcAdmn
        walkinTestScript.checkAndPerformMultiCheckDUR();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkinMultiRx(inputData);
        //completes POS in Connexus
        walkinTestScript.performPOSForMultiRx();
        //Get Payment Status
        walkinTestScript.performGetPaymentStatusForMultiRx();
        //In PMS screen validate Service details
        walkinTestScript.verifyServiceDetailsInPMSForMultiRx(inputData);
        Reporter.log("Validated the user able to add recommendation and process it with TP payment");
    }

    @Test(description = "Verify the Clinical Note section of Clinical Intelligence View",
            priority = 13, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5248_Verify_the_Clinical_Note_section_of_Clinical_Intelligence_View(Map<String, String> inputData) {
        Reporter.log("Verify the Clinical Note section of Clinical Intelligence View");
        //Pre-condition
        flagsSetup(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);

        //Create a new patient
        clinicalIntelligenceTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform chkDUR for IMZ
        walkinTestScript.checkAndPerformCheckDUR();
        //verify ClinIntel Screen
        clinicalIntelligenceTestScript.checkAndOpenClinIntel();
        //Verify Patient Details at the top displayed
        clinicalIntelligenceTestScript.verifyPatientDetailsDisplayed();
        //validate the In-progress lock section
        clinicalIntelligenceTestScript.validateInProgressOrderForLockIconPanel(inputData);
        //validate the recommended section
        clinicalIntelligenceTestScript.validateRecommendedSectionWithDetails();
        //validate history section
        clinicalIntelligenceTestScript.validateHistorySection();
        clinicalIntelligenceTestScript.validateClinicalNoteBtn(inputData);
        clinicalIntelligenceTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        walkinTestScript.checkAndPerformCheckDUR();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkin(inputData);
        //completes POS in Connexus
        walkinTestScript.performPOS();
        //Get Payment Status
        walkinTestScript.performGetPaymentStatus();
    }

    // Jira(testID = "HWPHME2E-5085")
    @Test(enabled = true, description = "Verify the user able to add Multiple recommendations into the order",
            priority = 14, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5085_Verify_user_able_to_add_Multiple_recommendations_into_the_order(Map<String, String> inputData) {
        Reporter.log("Validate the user able to add Multiple recommendations into the order");
        //Pre-condition
        flagsSetup(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);

        //Create a new patient
        clinicalIntelligenceTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform chkDUR for IMZ
        walkinTestScript.checkAndPerformCheckDUR();
        //verify ClinIntel Screen
        clinicalIntelligenceTestScript.checkAndOpenClinIntel();
        //Verify Patient Details at the top displayed
        clinicalIntelligenceTestScript.verifyPatientDetailsDisplayed();
        //validate the In-progress lock section
        clinicalIntelligenceTestScript.validateInProgressOrderForLockIconPanel(inputData);
        //validate the recommended section
        clinicalIntelligenceTestScript.validateRecommendedSectionWithDetails();
        //validate history section
        clinicalIntelligenceTestScript.validateHistorySection();
        //Add and validate multiple recommendation products in in-progress section
        clinicalIntelligenceTestScript.addMultipleRecommendationProducts(new int[][] {{1, 1},{1, 2}});
        clinicalIntelligenceTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        //perform chkDUR and moves to SvcAdmn
        walkinTestScript.checkAndPerformMultiCheckDUR();
        //performs IMZ administration by using Walkin APIs
        walkinTestScript.performImZAdministrationForWalkinMultiRx(inputData);
        //completes POS in Connexus
        walkinTestScript.performPOSForMultiRx();
        //Get Payment Status
        walkinTestScript.performGetPaymentStatusForMultiRx();
        //In PMS screen validate Service details
        walkinTestScript.verifyServiceDetailsInPMSForMultiRx(inputData);
        Reporter.log("Validated the user able to add Multiple recommendations into the order");
    }


    // Jira(testID = "HWPHME2E-5090")
    @Test(enabled = true, description = "Verify the user able to add note to recommendation",
            priority = 15, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5090_Verify_User_add_Notes_to_Recommendation(Map<String, String> inputData){
        Reporter.log("Validate should be able to add notes to the recommended section");
        flagsSetup(inputData);
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);
        //Create a new patient
        clinicalIntelligenceTestScript.createNewPatient(inputData);
        //Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        //perform chkDUR for IMZ
        walkinTestScript.checkAndPerformCheckDUR();
        clinicalIntelligenceTestScript.checkAndOpenClinIntel();
        clinicalIntelligenceTestScript.verifyPatientDetailsDisplayed();
        //validate the In-progress lock section
        clinicalIntelligenceTestScript.validateInProgressOrderForLockIconPanel(inputData);
        //validate the recommended section
        clinicalIntelligenceTestScript.validateRecommendedSectionWithDetails();
        //validate history section
        clinicalIntelligenceTestScript.validateHistorySection();
        clinicalIntelligenceTestScript.validateRecommendationNotes();
        Reporter.log("Verified the User added Notes to the Recommendation Section in the CI screen");
    }

    // Jira(testID = "HWPHME2E-5470")
    @Test(enabled = true, description = "Verify if Patient does not change on CI order when searching patient in F7",
            priority = 16, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5470_Verify_if_Patient_does_not_change_on_CI_order_when_searching_other_patient_in_F7(Map<String, String> inputData) {
        Reporter.log("Verify if Patient does not change on CI order when searching patient in F7");
        //Pre-condition
        flagsSetup(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);

        // Create a new patient
        clinicalIntelligenceTestScript.createNewPatient(inputData);
        // Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        // perform chkDUR for IMZ
        walkinTestScript.checkAndPerformCheckDUR();
        // verify ClinIntel Screen
        clinicalIntelligenceTestScript.checkAndOpenClinIntel();
        // Verify Patient Details at the top displayed
        clinicalIntelligenceTestScript.verifyPatientDetailsDisplayed();
        // validate the In-progress lock section
        clinicalIntelligenceTestScript.validateInProgressOrderForLockIconPanel(inputData);
        // validate the recommended section
        clinicalIntelligenceTestScript.validateRecommendedSectionWithDetails();
        // validate history section
        clinicalIntelligenceTestScript.validateHistorySection();
        // search different patient using F7 and open PMS screen
        // we have added a new patient in the test data to search for existing patient scenario,  this needs to be enhanced to create a new patient on the fly and search to cover both new and existing patient search scenario
        clinicalIntelligenceTestScript.searchDifferentPatientUsingF7AndOpenPMS(inputData);
        // validate patient details remains unchanged in CI screen
        clinicalIntelligenceTestScript.validatePatientNameUnchangedOnCIScreen();
        Reporter.log("Validated if Patient does not change on CI order when searching for a new/existing patient in F7");
    }

    // Jira(testID = "HWPHME2E-5469")
    @Test(enabled = true, description = "Verify the clinical notes screen gets updated with recent suppressed/restored IMZ and are moved to the top list",
            priority = 17, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5469_Verify_clinical_notes_gets_updated_with_recent_IMZ_suppressed_or_restored_moved_to_the_top_list(Map<String, String> inputData) {
        Reporter.log("Verify clinical notes reflects recent IMZ suppressed/restored and moves them to the top of the list");
        //Pre-condition
        flagsSetup(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);

        // Create a new patient
        clinicalIntelligenceTestScript.createNewPatient(inputData);
        // Drop an order on the Connexus Select Order type as "Immunization Instore"
        walkinTestScript.performIMZDropOffForSingleDrug(inputData,false);
        // perform chkDUR for IMZ
        walkinTestScript.checkAndPerformCheckDUR();
        // verify ClinIntel Screen
        clinicalIntelligenceTestScript.checkAndOpenClinIntel();
        // Verify Patient Details at the top displayed
        clinicalIntelligenceTestScript.verifyPatientDetailsDisplayed();
        // validate the In-progress lock section
        clinicalIntelligenceTestScript.validateInProgressOrderForLockIconPanel(inputData);
        // validate the recommended section
        clinicalIntelligenceTestScript.validateRecommendedSectionWithDetails();
        // validate history section
        clinicalIntelligenceTestScript.validateHistorySection();
        // Add removal reason for suppress recommendation
        clinicalIntelligenceTestScript.suppressRecommendationForNotInterested(1, 1);
        //validate suppressed recommendation panel row details
        clinicalIntelligenceTestScript.validateSuppressedRecommendationMovedToTopInClinicalNotes(1);
        // add notes in clinical notes section
        clinicalIntelligenceTestScript.addNotesInClinicalNotesSection();
        // validate clinical notes panel for top entry with the date, storeNbr and userID
        clinicalIntelligenceTestScript.validateTopClinicalNotesPanel(1);
        Reporter.log("Validated clinical notes reflects recent IMZ suppressed/restored and moves them to the top of the list");
    }

    // Jira(testID = "HWPHME2E-5559")
    @Test(enabled = true, description = "Verify the cancel button on the Clinical Intelligence View is cancel the screen from view for Ad Hoc look up",
            priority = 18, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "ClinicalIntelligence")
    public void HWPHME2E_5559_Verify_the_Cancel_button_exists_the_CI_view_for_Adhoc_lookup(Map<String, String> inputData) {
        Reporter.log("Verify the cancel button on the Clinical Intelligence View is cancel the screen from view for Ad Hoc look up");
        //Pre-condition
        flagsSetup(inputData);
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr"));
        connexusAppUtils.updateInventoryQuantity(inputData.get("ndc_nbr1"));
        clinicalIntelligenceTestScript.initializeTestCase(flagUpdated);

        // Create a new patient
        clinicalIntelligenceTestScript.createNewPatient(inputData);
        // Drop a normal order
        clinicalIntelligenceTestScript.performDropOff(Priority.Critical);
        // Perform multi Rx input by adding Additional Rx through UI
        clinicalIntelligenceTestScript.performMultiRxInput(inputData, true);
        // Validate Prescription History in F7 Screen
        clinicalIntelligenceTestScript.validatePrescriptionHistoryInF7(inputData);
        // Open Clinical Intelligence View from F7 Screen
        clinicalIntelligenceTestScript.openClinicalIntelligence();
        // Click on Cancel button in CI view for Adhoc lookup
        clinicalIntelligenceTestScript.clickCancelBtnInCIView();
        Reporter.log("Verified the Cancel button exists in the CI view for Adhoc lookup");
    }
}
