package clinicalservices.Immunization.testcases;

import clinicalservices.Immunization.testScripts.COVIDTestKitTestScript;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.datacontext.DataProvider;
import hwqe.baseframework.utilities.Reporter;
import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import java.util.Map;


public class COVIDTestKitTestSet {

    COVIDTestKitTestScript covidTestKitTestScript = new COVIDTestKitTestScript();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    String statecode = "";


    @BeforeClass
    public void startAppiumServer() {
        connexusAppUtils.startAppiumServer();
    }

    @AfterClass
    public void closeConnexus() {
        AutomationManager.getInstance().getConnexus().closeConnexus();
        connexusAppUtils.stopAppiumServer();
    }



    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Validate Rx Image for COVID Test kit orders dropped with RPH Protocol.
     * Pre-Conditions:
       1. Set the store state as : WV
          select * from bus_unit_addr;
       2. To enable the 'Protocol  for State Specific standing order:
          Turn ON the OTC billing setting flag 15317 and 14108 IMZ RPh
          1. select * from informix.bu_phm_parm where phm_parm_code in(14102,14108); - should be set as 'TRUE'
          2. select * from agency_rqmt_parm where restrict_type_code in (15317,15318) and issue_agency_code = 248; -should be set as 'TRUE'
     *
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1094")
    @Test(description = "Validate Rx Image for COVID Test kit orders dropped with RPH Protocol",
            priority = 1, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "CovidTestKitTestData")
    public void HWPHME2E_1094_Validate_RxImage_For_COVIDTestkit_Orders_Dropped_With_RPH_Protocol(Map<String, String> inputData) {
        Reporter.log(">>>HWPHME2E_1094_Validate Rx Image for COVID Test kit orders dropped with RPH Protocol<<<");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON the OTC billing setting flag 15317 and 14108 IMZ RPh
        connexusAppUtils.readAndUpdateFlag("14102", "TRUE");
        connexusAppUtils.readAndUpdateFlag("14108", "TRUE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15317", statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15318", statecode);
        covidTestKitTestScript.flushCache();
        covidTestKitTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient with a TP plan
        covidTestKitTestScript.createNewPatient(inputData,1);
        //Drop an order on the Connexus Select Order type as " COVID Testing Kit" with TP Plan
        covidTestKitTestScript.performCovidTestingKitDropOff(inputData);
        //Complete 4Point
        covidTestKitTestScript.perform4Point();
        //Complete Filling
        covidTestKitTestScript.performFilling();
        //Complete Visual Verify
        covidTestKitTestScript.performVisualVerify();
        //Complete PickUp
        covidTestKitTestScript.performPickUp(inputData);
        //Complete Counselling
        covidTestKitTestScript.performCounselling();
        //Perform POS - Offline Sale
        covidTestKitTestScript.performPOS();
        //In EOD Page go to the menu bar and hover over Notes Menu, then click on RX Image
        //Verify the RX Image | Rx Image should be verified
        covidTestKitTestScript.validateRxImage();
        Reporter.log(">>>HWPHME2E_1094_Validated Rx Image for COVID Test kit orders dropped with RPH Protocol<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Validate Rx Notes for COVID Test kit orders dropped with RPH Protocol.
     * Pre-Conditions:
       1. Set the store state as : WV
          select * from bus_unit_addr;
       2. To enable the 'Protocol  for State Specific standing order:
          Turn ON the OTC billing setting flag 15317 and 14108 IMZ RPh
          1. select * from informix.bu_phm_parm where phm_parm_code in(14108); - should be set as 'TRUE'
          2. select * from agency_rqmt_parm where restrict_type_code in (15317) and issue_agency_code = 248; -should be set as 'TRUE'
          update the language for PR it should be spanish
          3. select * from bu_phm_parm where phm_bu_id = strNbr and phm_parm_code in (5351);
     *
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    //@Jira(testID = "HWPHME2E-1104")
    @Test(description = "Validate Rx Notes for COVID Test kit orders dropped with RPH Protocol.",
            priority = 2, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "CovidTestKitTestData")
    public void HWPHME2E_1104_Validate_RxNotes_For_COVIDTestkit_Orders_Dropped_With_RPH_Protocol(Map<String, String> inputData) {
        Reporter.log(">>>HWPHME2E_1104_Validate Rx Notes for COVID Test kit orders dropped with RPH Protocol<<<");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON the OTC billing setting flag 15317 and 14108 IMZ RPh
        connexusAppUtils.readAndUpdateFlag("14108", "TRUE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15317", statecode);
        //update the language for store, it should be spanish
        connexusAppUtils.readAndUpdateFlag("102", "5351");
        covidTestKitTestScript.flushCache();
        covidTestKitTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient with a TP plan
        covidTestKitTestScript.createNewPatient(inputData,1);
        //Drop an order on the Connexus Select Order type as " COVID Testing Kit" with TP Plan
        covidTestKitTestScript.performCovidTestingKitDropOff(inputData);
        //Complete 4Point
        covidTestKitTestScript.perform4Point();
        //Complete Filling
        covidTestKitTestScript.performFilling();
        //Complete Visual Verify
        covidTestKitTestScript.performVisualVerify();
        //Complete PickUp
        covidTestKitTestScript.performPickUp(inputData);
        //Complete Counselling
        covidTestKitTestScript.performCounselling();
        //Perform POS - Offline Sale
        covidTestKitTestScript.performPOS();
        //In EOD Page go to the menu bar and hover over CURRENT RX, then click on RX NOTES
        //Verify the RX Notes | Rx Notes should be verified
        covidTestKitTestScript.validateRxNotes(inputData);
        Reporter.log(">>>HWPHME2E_1104_Validated Rx Notes for COVID Test kit orders dropped with RPH Protocol<<<");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Validate COVID Test Kit order is submitted to Medicaid successfully and process to EOD.
     * Jira(testID = "HWPHME2E-1062")
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate COVID Test Kit order is submitted to Medicaid successfully and process to EOD",
            priority = 3, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "CovidTestKitTestData")
    public void HWPHME2E_1062_Validate_COVID_Test_Kit_Order_Is_Submitted_To_Medicaid_Successfully_And_Process_To_EOD(Map<String, String> inputData) {
        Reporter.log("Validate COVID Test Kit order is submitted to Medicaid successfully and process to EOD");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON the OTC billing setting flag 15317 and 14108 IMZ RPh
        connexusAppUtils.readAndUpdateFlag("14102", "FALSE");
        connexusAppUtils.readAndUpdateFlag("14108", "TRUE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15317", statecode);
        covidTestKitTestScript.flushCache();
        covidTestKitTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient with a TP plan
        covidTestKitTestScript.createNewPatient(inputData,1);
        //Drop an order on the Connexus Select Order type as " COVID Testing Kit" with TP Plan
        covidTestKitTestScript.performCovidTestingKitDropOff(inputData);
        //Complete 4Point
        covidTestKitTestScript.perform4Point();
        //Complete chkDUR
        covidTestKitTestScript.checkAndPerformCheckDUR();

        //Complete Filling and move to EOD for single order through API
        covidTestKitTestScript.performSingleRxFillingAndMoveToEOD();
        Reporter.log("Validate COVID Test Kit order is submitted to Medicaid successfully and process to EOD");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Validate COVID Test Kit order is submitted to Medicare successfully and process to EOD.
     * Jira(testID = "HWPHME2E-1079")
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate COVID Test Kit order is submitted to Medicare successfully and process to EOD",
            priority = 4, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "CovidTestKitTestData")
    public void HWPHME2E_1079_Validate_COVID_Test_Kit_Order_Is_Submitted_To_Medicare_Successfully_And_Process_To_EOD(Map<String, String> inputData) {
        Reporter.log("Validate COVID Test Kit order is submitted to Medicare successfully and process to EOD");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON the OTC billing setting flag 15317 and 14108 IMZ RPh
        connexusAppUtils.readAndUpdateFlag("14102", "FALSE");
        connexusAppUtils.readAndUpdateFlag("14108", "TRUE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15317", statecode);
        covidTestKitTestScript.flushCache();
        covidTestKitTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient with a TP plan
        covidTestKitTestScript.createNewPatient(inputData,1);
        //Drop an order on the Connexus Select Order type as " COVID Testing Kit" with TP Plan
        covidTestKitTestScript.performCovidTestingKitDropOff(inputData);
        //Complete 4Point
        covidTestKitTestScript.perform4Point();
        //Complete chkDUR
        covidTestKitTestScript.checkAndPerformCheckDUR();

        //Complete Filling and move to EOD for single order through API
        covidTestKitTestScript.performSingleRxFillingAndMoveToEOD();
        Reporter.log("Validate COVID Test Kit order is submitted to Medicare successfully and process to EOD");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Validate Drop a COVID Kit Order in PR Store with RPH Protocol and process it to EOD
     * Jira(testID = "HWPHME2E-1066")
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Drop a COVID Kit Order in PR Store with RPH Protocol and process it to EOD",
            priority = 5, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "CovidTestKitTestData")
    public void HWPHME2E_1066_Validate_Drop_a_COVID_Kit_Order_in_PR_Store_with_RPH_Protocol_and_process_it_to_EOD(Map<String, String> inputData) {
        Reporter.log("Validate Drop a COVID Kit Order in PR Store with RPH Protocol and process it to EOD");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON the OTC billing setting flag 15317 and 14108 IMZ RPh
        connexusAppUtils.readAndUpdateFlag("14108", "TRUE");
        connexusAppUtils.readAndUpdateFlag("14102", "FALSE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15317", statecode);
        //update the language for store, it should be spanish
        connexusAppUtils.readAndUpdateFlag("102", "5351");
        covidTestKitTestScript.flushCache();
        covidTestKitTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient with a TP plan
        covidTestKitTestScript.createNewPatient(inputData,1);
        //Drop an order on the Connexus Select Order type as " COVID Testing Kit" with TP Plan
        covidTestKitTestScript.performCovidTestingKitDropOff(inputData);
        //Complete 4Point
        covidTestKitTestScript.perform4Point();
        //Complete chkDUR
        covidTestKitTestScript.checkAndPerformCheckDUR();

        //Complete Filling and move to EOD for single order through API
        covidTestKitTestScript.performSingleRxFillingAndMoveToEOD();
        Reporter.log("Validate Drop a COVID Kit Order in PR Store with RPH Protocol and process it to EOD");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Validate Drop a COVID Kit Order in PR Store with SO Protocol and process it to EOD
     * Jira(testID = "HWPHME2E-1073")
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Drop a COVID Kit Order in PR Store with SO Protocol and process it to EOD",
            priority = 6, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "CovidTestKitTestData")
    public void HWPHME2E_1073_Validate_Drop_a_COVID_Kit_Order_in_PR_Store_with_SO_Protocol_and_process_it_to_EOD(Map<String, String> inputData) {
        Reporter.log("Validate Drop a COVID Kit Order in PR Store with SO Protocol and process it to EOD");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON the OTC billing setting flag 15317 and 14108 IMZ SO
        connexusAppUtils.readAndUpdateFlag("14102", "TRUE");
        connexusAppUtils.readAndUpdateFlag("14108", "FALSE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15317", statecode);
        //update the language for store, it should be spanish
        connexusAppUtils.readAndUpdateFlag("102", "5351");
        covidTestKitTestScript.flushCache();
        covidTestKitTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient with a TP plan
        covidTestKitTestScript.createNewPatient(inputData,1);
        //Drop an order on the Connexus Select Order type as " COVID Testing Kit" with TP Plan
        covidTestKitTestScript.performCovidTestingKitDropOff(inputData);
        //Complete 4Point
        covidTestKitTestScript.perform4Point();
        //Complete chkDUR
        covidTestKitTestScript.checkAndPerformCheckDUR();

        //Complete Filling and move to EOD for single order through API
        covidTestKitTestScript.performSingleRxFillingAndMoveToEOD();
        Reporter.log("Validate Drop a COVID Kit Order in PR Store with SO Protocol and process it to EOD");
    }

    /*----------------------------------------------------------------------------------------------------------
    * Test Description:Validate RPH is able to add more than 1 type of COVID Test kits to the same order and process it to EOD
    * Jira(testID = "HWPHME2E-1084")
    * Author: Lavanya Torrikonda(vn575up)
    ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate RPH multi order for COVID Test kits to the same order and process it to EOD",
            priority = 7, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "CovidTestKitTestData")
    public void HWPHME2E_1084_Validate_RPH_Multi_Order_for_COVID_Test_kits_to_the_same_order_and_process_to_EOD(Map<String, String> inputData) {
        Reporter.log("Validate RPH Multi Order for COVID Test kits to the same order and process it to EOD");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON the OTC billing setting flag 15317 and 14108 IMZ RPh
        connexusAppUtils.readAndUpdateFlag("14108", "TRUE");
        connexusAppUtils.readAndUpdateFlag("14102", "FALSE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15317", statecode);
        //update the language for store, it should be spanish
        connexusAppUtils.readAndUpdateFlag("102", "5351");
        covidTestKitTestScript.flushCache();
        covidTestKitTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient with a TP plan
        covidTestKitTestScript.createNewPatient(inputData,1);
        //Drop an order on the Connexus Select Order type as " COVID Testing Kit" with TP Plan
        covidTestKitTestScript.performCovidTestKitDropOffForMultiDrugs(inputData);
        //Complete 4Point for multi orders
        covidTestKitTestScript.perform4PointForMultiOrder();
        //perform chkDUR for multi orders
        covidTestKitTestScript.checkAndPerformMultiCheckDUR();

        //Complete Filling and move to EOD for multi orders
        covidTestKitTestScript.multiRxFillingAndMoveToEOD(inputData);
        Reporter.log("Validate RPH Multi Order for COVID Test kits to the same order and process it to EOD");
    }

    /*----------------------------------------------------------------------------------------------------------
        * Test Description:Validate NDC text field allows to search for COVID Drugs
        * Jira(testID = "HWPHME2E-1034")
        * Author: Lavanya Torrikonda(vn575up)
        ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate NDC text field allows to search for COVID Drugs",
            priority = 8, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "CovidTestKitTestData")
    public void HWPHME2E_1034_Validate_NDC_text_field_allows_to_search_for_COVID_Drugs(Map<String, String> inputData) {
        Reporter.log("Validate NDC text field allows to search for COVID Drugs");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        Reporter.log("Login to Pharmacist flag Disabled");
        //Turn ON IMZ Settings 14108 RPH Order allowed flag
        connexusAppUtils.readAndUpdateFlag("14108", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("14108", "TRUE");
        connexusAppUtils.readAndUpdateFlag("14102", "FALSE");
        connexusAppUtils.fetchPharmacyCodeTxt("14102", "FALSE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15317", statecode);
        Reporter.log("Updating restrict type value and code");
        covidTestKitTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Open product search screen
        covidTestKitTestScript.openProductSearchWindow();
        //Search Product with Name
        covidTestKitTestScript.searchProductName(inputData);
        //Search Product with Name and NDC
        covidTestKitTestScript.searchProductWithNameAndNDCFields(inputData);
        Reporter.log("Validate NDC text field allows to search for COVID Drugs");
    }

    /*----------------------------------------------------------------------------------------------------------
     * Test Description:Validate rx_ord_dtl_activty for COVID Test kit order dropped with SO Protocol and process it to EOD.
     * Jira(testID = "HWPHME2E-999")
     * Author: Lavanya Torrikonda(vn575up)
     ----------------------------------------------------------------------------------------------------------*/
    @Test(description = "Validate Order details activity for COVID Test kit order dropped with SO Protocol and process it to EOD",
            priority = 9, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "CovidTestKitTestData")
    public void HWPHME2E_999_Validate_Order_details_activity_codes_for_COVID_Test_Kit_order_with_SO_Protocol_and_process_to_EOD(Map<String, String> inputData) {
        Reporter.log("Validate Order details activity codes for COVID Test kit order dropped with SO Protocol and process it to EOD");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        Reporter.log("Login to Pharmacist flag Disabled");
        //update state
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        //Turn ON IMZ Settings flag
        connexusAppUtils.readAndUpdateFlag("14102", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("14102", "TRUE");
        connexusAppUtils.readAndUpdateFlag("14108", "FALSE");
        connexusAppUtils.fetchPharmacyCodeTxt("14108", "FALSE");
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15317", statecode);
        connexusAppUtils.fetchPharmacyCodeTxt("15317");
        covidTestKitTestScript.flushCache();
        covidTestKitTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //Create a new patient with a TP plan
        covidTestKitTestScript.createNewPatient(inputData,1);
        //Drop an order on the Connexus Select Order type as " COVID Testing Kit"
        covidTestKitTestScript.performCovidTestingKitDropOff(inputData);
        //Complete 4Point
        covidTestKitTestScript.perform4Point();
        //Complete chkDUR
        covidTestKitTestScript.checkAndPerformCheckDUR();
        //Complete Filling and move to EOD for single order through API
        covidTestKitTestScript.performSingleRxFillingAndMoveToEOD();
        //Validate the Order details activity codes in activity text
        covidTestKitTestScript.validateActivityCodesFromOrderId();
        Reporter.log("Validate Order details activity codes for COVID Test kit order dropped with SO Protocol and process it to EOD");
    }

    @Test(description = "Validate that user is able to update the inventory successfully using the search product feature",
            priority = 10, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "CovidTestKitTestData")
    public void HWPHME2E_1008_Validate_inventory_update_using_product_feature(Map<String, String> inputData) {
        Reporter.log("Validate that user is able to update the inventory successfully using the search product feature");

        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        Reporter.log("Login to Pharmacist flag Disabled");
        //Turn ON IMZ Settings 14108 RPH Order allowed flag
        connexusAppUtils.readAndUpdateFlag("14108", "TRUE");
        connexusAppUtils.fetchPharmacyCodeTxt("14108", "TRUE");
        connexusAppUtils.readAndUpdateFlag("14102", "FALSE");
        connexusAppUtils.fetchPharmacyCodeTxt("14102", "FALSE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15317", statecode);
        Reporter.log("Updating restrict type value and code");
        covidTestKitTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);

        //get Inventory info fromAPI
        covidTestKitTestScript.checkInventoryInfoInAPI(inputData);
        //Open product search screen
        covidTestKitTestScript.openProductSearchWindow();
        //Search Product with Name and NDC
        covidTestKitTestScript.searchProductWithNameAndNDCFields(inputData);
        //check product updates in Item Maintenance Screen, DB and API
        covidTestKitTestScript.checkProductUpdates(inputData);
        Reporter.log("Validate that user is able to update the inventory successfully using the search product feature");
    }
    //@Jira(testID = "HWPHME2E-1020")
    @Test(description = "Validate Rx Image scan functionality for RPh protocol for Covid Test kits",
            priority = 11, dataProviderClass = DataProvider.class, dataProvider = "getDataAsMap")
    @DataProviderArguments(filePath = "TestData/ClinicalServicesImmunization/ClinicalServicesImmunizationTestData.json", sheetName = "CovidTestKitTestData")
    public void HWPHME2E_1020_Validate_Rx_Image_Scan_Functionality_For_RPh_Protocol_For_Covid_Testkits(Map<String, String> inputData) {
        Reporter.log("Validate Rx Image scan functionality for RPh protocol for Covid Test kits");
        //Pre-condition
        //Verify and set the flag 28750 (AD Authentication) FALSE to login to Pharmacist
        connexusAppUtils.readAndUpdateFlag("28750", "FALSE");
        // Turn ON the OTC billing setting flag 15317 and 14108 IMZ RPh
        connexusAppUtils.readAndUpdateFlag("14102", "TRUE");
        connexusAppUtils.readAndUpdateFlag("14108", "TRUE");
        connexusAppUtils.updateStateValue(inputData.get("STATE"));
        statecode = connexusAppUtils.fetchIssueAgencyCodeOfState(inputData.get("STATE"));
        connexusAppUtils.getlogSiteIdAndState(inputData);
        Reporter.log("State code:" + statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15317", statecode);
        connexusAppUtils.updateAgencyRequirementParmTable("Y", "15318", statecode);
        covidTestKitTestScript.flushCache();
        covidTestKitTestScript.loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
        covidTestKitTestScript.unChkAllImgScanDownOption();
        covidTestKitTestScript.scanRxImageForRphProtocol(inputData);
        //Create a new patient with a TP plan
        covidTestKitTestScript.createNewPatient(inputData,1);
        //Drop an order on the Connexus Select Order type as " COVID Testing Kit" with TP Plan
        covidTestKitTestScript.performCovidTestingKitDropOff(inputData);
        //Complete 4Point
        covidTestKitTestScript.perform4Point();
        //Complete Filling and move to EOD for single order through API
        covidTestKitTestScript.performSingleRxFillingAndMoveToEOD();
        //In EOD Page go to the menu bar and hover over Notes Menu, then click on RX Image
        //Verify the RX Image | Rx Image should be verified
        covidTestKitTestScript.validateRxImage();
        Reporter.log("Validate Rx Image scan functionality for RPh protocol for Covid Test kits");
    }


}