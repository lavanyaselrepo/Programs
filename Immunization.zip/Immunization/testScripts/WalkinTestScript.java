package clinicalservices.Immunization.testScripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.assignOrder.request.OrderInfo;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.getAuthorizedIMZDrugsResponse.GetAuthorizedIMZDrugs;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.getImzInfoResponse.GetImzInfo;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.getImzInfoResponse.Patient;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import rxpd.RXPDE2E.Utils.Poller;

import java.util.*;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.GetAuthorizedIMZDrugsWrapper.getAuthorizedIMZDrugs;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.GetImzInfoWrapper.getImzInfo;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.imzapp.constants.Consts.*;

public class WalkinTestScript extends ConnexusTestScripts {

    int siteId, orderId, orderSeqNbr, patientId, rxFillId, serviceId, itemMdsFamId, prescriberId, rowCount;
    String rxNbr = null, vaccineName, currentRxNbr, pcpFaxId, todaysDate, statusCodeFromDB, statusCodeDesc, rxStatus, fillIdStatus, pcpServiceId,
            prescriberFromPMS, pcpNotificationDateTime, scriptName, targetBoxType, soFaxId, faxId, soPCPNotifiedDate, title;
    Long productMdsFamId;
    List<Integer> orderSeqNbrList = new ArrayList<>();
    List<Integer> rxFillIdList = new ArrayList<>();
    List<Integer> serviceIdList = new ArrayList<>();
    List<Integer> itemMdsFamIdList = new ArrayList<>();
    List<String> vaccineNameList = new ArrayList<>();
    List<OrderInfo> orderInfoList = new ArrayList<>();
    List<Long> productMdsFamIdList = new ArrayList<>();
    GetImzInfo getImzInfo;
    List<Integer> rxFillIdList2 = new ArrayList<>();
    ConnexusAPIManager connexusAPIManager;
    List<Integer> multiRxNbr = new ArrayList<>();
    List<String> serviceIds;
    ClinicalIntelligenceTestScripts clinIntelTestScript = new ClinicalIntelligenceTestScripts(LoginAs.userType.PHARMACIST_ADFlagOff);

    public WalkinTestScript() {
        propertyReader.loadCustomProperties("config/connexus/");
        propertyReader.loadCustomProperties("config/connexustestharness/");
        propertyReader.loadCustomProperties("config/fom/");
        propertyReader.loadCustomProperties("config/imzapp/");
        siteId = Integer.parseInt(propertyReader.getProperty("cs.imzapp.storeId"));
        connexusAppUtils = new ConnexusAppUtils();
        connexusAPIManager = new ConnexusAPIManager();
    }

    public void createPatientFromHostProfileFromPMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientSearchPage = new PatientSearchPage();
        patientMaintenancePage = new PatientMaintenancePage();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.isPatientSearchWindowDisplayed();
            Reporter.log("Patient Name" + name[0] + "," + name[1]);
            Log.info("Patient Name :" + name[0] + "," + name[1]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            Reporter.log("DOB :" + inputData.get("DOB"));
            patientSearchPage.inputPatientDob(inputData.get("DOB"));
            patientSearchPage.clickSearchNow();
            //hostlookup
            patientSearchPage.clickSearchHost();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertTrue(patientSearchPage.isPatientRecordDisplayed(0));
            patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(patient.getPatientLastName() + "," + patient.getPatientFirstName());
            patientSearchPage.openFirstPatientRecord();
            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);
            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);
            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            patient.setPatientTp(thirdPartyModel);
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);
            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);
            patientMaintenancePage.clickSaveAndClose();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed while creating patient in patient maintaince screen" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }


    //perform drop off for IMZ
    public void performIMZDropOffForSingleDrug(Map<String, String> inputData, boolean isExistingPatient) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        dropRxModel = new DropRxModel();
        try {
            if (isExistingPatient) {
                dropRxModel.setPatientLastName(inputData.get("LAST_NAME"));
                dropRxModel.setPatientFirstName(inputData.get("FIRST_NAME"));

            } else {
                String[] name = connexusAppUtils.readPatientNameFromFile();
                dropRxModel.setPatientLastName(name[0]);
                dropRxModel.setPatientFirstName(name[1]);
            }
            dropRxModel.setPriority(Priority.Critical);
            String imzDrug = inputData.get("DRUG_NAME");
            automationManager.getConnexusWorkFlow().performIMZDropOffForSingleDrug(dropRxModel, imzDrug, inputData.get("PRESCRIBER_NAME"));
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed at DropOff queue" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, "performIMZDropOff", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    //perform chkDUR for IMZ
    public void checkAndPerformCheckDUR() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        orderSearch = new F6Search();
        clinicalIntelligencePage = new ClinicalIntelligencePage();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_40)) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }
            // If CI opens after chkDur, click Wait to Serve; order must release from API to continue the flow
            clinicalIntelligencePage.clickWaitToServeBtn();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed at ChkDUR" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    //perform chkDUR and move to SvcAdmn
    public void checkAndPerformMultiCheckDUR() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientId = getPatientId();
        multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                rxNbr = String.valueOf(multiRxNbr.get(i));
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
                }
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_20)) {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed at ChkDUR" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    public void verifyWorkQueueStatusAsServiceAdmin() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.ServiceAdministration.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                Reporter.log("order is in service admin ");
            }else {
                Reporter.log("order is not in service admin ");
            }
        } catch (Throwable e) {
            Reporter.log("RX not in service admin queue" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyIMZModifyDetails() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            boolean var;
            orderSearch = new F6Search();

            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr=getRxNbr(name[0], name[1], siteId);
            Reporter.log("RX Nbr found "+rxNbr);
            if (ischeckIMZOrderQueueDB(rxNbr, WorkQueueSettings.ServiceAdministration.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                Reporter.log("order moved to service admin ");
            } else {
                Reporter.log("order is not in service admin ");
                Assert.fail("order is not in service admin ");
            }
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(rxNbr);
            orderSearch.openFirstPatientRecord();

            var = modifyDetails.isElementEnabled(modifyDetails.txtpatientName);
            Assert.assertFalse(var, "Patient Name field not disabled");
            Reporter.log("Patient Name field is disabled");
            var = modifyDetails.isElementEnabled(modifyDetails.dropdownRxOrigin);
            Assert.assertFalse(var, "Rx Origin field is not disabled");
            Reporter.log("Rx Origin field is disabled");
            var = modifyDetails.isElementEnabled(modifyDetails.txtPrescribedProduct);
            Assert.assertFalse(var, "Prescribed Product field is not disabled");
            Reporter.log("Prescribed Product field disabled");
            var = modifyDetails.isElementEnabled(modifyDetails.txtSig);
            Assert.assertFalse(var, "Sig field is not disabled");
            Reporter.log("Sig field disabled");
            var = modifyDetails.isElementEnabled(modifyDetails.txtPrescriberName);
            Assert.assertFalse(var, "Prescribed Name field is not disabled");
            Reporter.log("Prescribed Name field disabled");
            var = modifyDetails.isElementEnabled(modifyDetails.txtPrescriberQty);
            Assert.assertFalse(var, "Prescribed Quantity field is not disabled");
            Reporter.log("Prescribed Quantity field disabled");
            var = modifyDetails.isElementEnabled(modifyDetails.dispQunatity);
            Assert.assertFalse(var, "Dispensed Quantity field is not disabled");
            Reporter.log("Dispensed Quantity field disabled");
            var = modifyDetails.isElementEnabled(modifyDetails.txtDaysSupply);
            Assert.assertFalse(var, "Days Supply field is not disabled");
            Reporter.log("Days Supply field disabled");
            var = modifyDetails.isElementEnabled(modifyDetails.refillAuth);
            Assert.assertFalse(var, "Refill Auth field is not disabled");
            Reporter.log("Refill Auth field disabled");
            var = modifyDetails.isElementEnabled(modifyDetails.chkTamperResistant);
            Assert.assertFalse(var, "Tamper Resistant field is not disabled");
            Reporter.log("Tamper Resistant field disabled");
            var = modifyDetails.isElementEnabled(modifyDetails.paymentInsuranceTitle);
            Assert.assertTrue(var, "Third Party Insurance field is enabled");
            Reporter.log("Third Party Insurance field enabled");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            modifyDetails.clickCancel();
            modifyDetails.clickYes();

        } catch (Throwable e) {
            Reporter.log("Test failed at Clin Intel queue" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performImZAdministrationForWalkin(Map<String, String> appointmentInfo) {
        prescriberId = getprescriberId(appointmentInfo);
        GetImzInfo getImzInfo = getImzInfo(siteId);
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String expirationDate = appointmentInfo.get("expirationDate");
        int patientList = getImzInfo.getSvcOrderDetails().size();
        Log.info("patientList from getImZInfo:" + patientList);
        //Get IMZ info
        for (int i = 0; i < patientList; i++) {
            if (getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getLastName().equalsIgnoreCase(name[0])) {
                orderId = getImzInfo.getSvcOrderDetails().get(i).getOrderId();
                orderSeqNbr = getImzInfo.getSvcOrderDetails().get(i).getOrderSeqNbr();
                patientId = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getPatientId();
                rxFillId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillId();
                serviceId = getImzInfo.getSvcOrderDetails().get(i).getService().getServiceId();
                itemMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getItemMdsFamId();
                productMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getProductMdsFamId();
                vaccineName = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getShortName();
                Reporter.log("orderId:" + orderId + "\t  patientId:" + patientId + "\t  rxFillId:" + rxFillId + "\t  serviceId:" + serviceId + "\t  itemMdsFamId:" + itemMdsFamId + "\t " +
                        " productItemMdsFamId:" + productMdsFamId + "\t orderSeqNbr:" + orderSeqNbr);
            }
        }
        List<OrderInfo> orderInfoList = new ArrayList<>();
        orderInfoList.add(new OrderInfo(orderId, orderSeqNbr));

        // Assigning the order
        AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);

        //Save Consent Form
        SaveConsentFormWrapper.saveConsentForm(siteId, rxFillId, prescriberId, serviceId, Svc_Image_Txt, SignerName, SupervisorSignature, SupervisorName, ImmunizerSignature,
                ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME);

        //saves Product information
        SaveProductInformationWrapper.saveProductInformation(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId);

        //completes order
        CompleteOrderWrapper.completeOrder(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId, vaccineName,
                serviceId, patientId, prescriberId);

        Reporter.log("Completed IMZ Administration for Walkin");
    }

    //Get payment status for single fillId
    public void performGetPaymentStatus() {
        //getPaymentStatus
        GetPaymentStatus.getPaymentStatus(siteId, String.valueOf(rxFillId));
    }

    @Override
    public void performPOS() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.IMZReporting.getValue())) {
                Reporter.log("order is in IMZ queue");
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.POS.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().completeOfflineSale(String.valueOf(rxNbr));
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at POS or IMZREP queue" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyServiceDetailsInPMS(Map<String, String> appointmentInfo) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            Reporter.log("Patient Name" + name[0] + "," + name[1]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.inputPatientDobCR(appointmentInfo.get("DOB"));
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickClinicalServicesTab();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("clicked on clinical services");

            //verify rxFillID,Status and click serviceDetails Button
            patientMaintenancePage.selectActiveRxFillIdRow(rxFillId);
            Assert.assertTrue(patientMaintenancePage.isServiceDetailsEnabled());
            patientMaintenancePage.clickServiceDetails();
            Reporter.log("Assert: Validation of RxfillId details is completed");
            Reporter.logScreenShot(Status.PASS, "PatientMaintenance", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

            //verify lot Numbers
            Assert.assertEquals(patientMaintenancePage.getLotNo(), appointmentInfo.get("lotNbr"), "lot numbers are different");
            Reporter.log("Assert: validation of Actual lot numbers with expected is completed");

            //verify Administrated BY
            String expectedPrescriberName = appointmentInfo.get("PRESCRIBER_NAME");
            String administerName = patientMaintenancePage.getAdministratorValue().trim();
            boolean isPrescriberNameValid = administerName.contains(expectedPrescriberName);
            Assert.assertTrue(isPrescriberNameValid,
                    String.format("Prescriber name validation failed. Expected: '%s' to be contained in Administrator name: '%s'",
                            expectedPrescriberName, administerName));
            Reporter.log("Assert: Validation of Administrated by completed with given value is matched");

            //verify VIS PublishDate
            String visPubDate = getVisPubFromDB();
            Log.info("visPubdate" + visPubDate);
            visPubDate = connexusAppUtils.dateConversion(visPubDate);
            Assert.assertEquals(visPubDate, patientMaintenancePage.getVISPublishDate().trim(), "VIS Publish Date did not Matched");
            Reporter.log("Assert: Validation of VIS PublishDate from PMS is completed");
            Reporter.logScreenShot(Status.PASS, "ServiceAdministration", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

            //verify VIS GivenDate
            String todaysDate = connexusAppUtils.getCurrentDate("MM/dd/yyyy");
            Assert.assertNotNull(patientMaintenancePage.getVISGivenDate(), "VIS Given Date is  null");
            Assert.assertEquals(patientMaintenancePage.getVISGivenDate().trim(), todaysDate, "VIS GIVEN Date is Matched");
            Reporter.log("Assert: Validation of VIS GivenDate from PMS is completed");

            //verify Dosage ML
            String dosageML = patientMaintenancePage.getDosageMLValue().trim();
            Assert.assertTrue(true, dosageML);
            Reporter.log("Assert: Validation of Dosage ML info:" + dosageML);

            //Clikcing IMZForm and check for IMZForm
            patientMaintenancePage.clickImzForm();
            Boolean pqcfImg = patientMaintenancePage.verifyPvImage();
            Assert.assertTrue(pqcfImg, "PQCF Image doesnot exist");
            Reporter.logScreenShot(Status.PASS, "ScanIMZForm", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

            //closes IMZ form
            patientMaintenancePage.clickExit();
            //closes services administration page
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();
            //closes clinical services page
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            Reporter.log("Test failed at PatientMaintainance page" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public String getVisPubFromDB() {
        String query = "select vis.vis_publish_date from imz_product ip join\n" +
                "vaccine_info_sheet vis on ip.vis_id = vis.vis_id\n" +
                "where ip.product_mds_fam_id in ( " + "'" + productMdsFamId + "');";
        Reporter.log("To get VISPublish From Db: " + query);
        String visPubDate = automationManager.getConnexusDB(siteId).getScalar(query, String.class);
        Reporter.log("VisPublishDate from DB:" + visPubDate);
        return visPubDate;
    }

    public void flushCache() {
        connexusAPIManager.flushCache(String.valueOf(siteId));
    }

    public void performIMZDropOffForMultiDrugs(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        List<String> drugList;
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setPriority(Priority.Critical);
            drugList = Arrays.asList(inputData.get("DRUG_NAME"), inputData.get("DRUG_NAME2"));
            automationManager.getConnexusWorkFlow().performIMZDropOffForMultiDrug(dropRxModel, drugList, inputData.get("PRESCRIBER_NAME"));
        } catch (Throwable e) {
            Reporter.log("Test failed at DropOff queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyWorkQueueStatusAsServiceAdminForMultiRx() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            for (int i = 0; i < 2; i++) {
                String[] name = connexusAppUtils.readPatientNameFromFile();
                rxNbr = orderSearch.getMultiRxNbrForPatient(name[0] + "," + name[1], i);
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.ServiceAdministration.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    patientSearchPage.launchOrderSearchScreen();
                    patientSearchPage.performSearch(rxNbr);
                    Reporter.log("WorkQueue: " + rxStatus);
                    Reporter.log("Order is in service admin ");
                    Assert.assertEquals(rxStatus, WorkQueue.SVC_ADMIN.getWorkQueue(), "order is not in service admin queue");
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    orderSearch.closeSearch();
                }
            }
        } catch (Throwable e) {
            Reporter.log("RX not in service admin queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    //Performs IMZ administration for assigned multi orders using Walkin APIs
    public void performImZAdministrationForWalkinMultiRx(Map<String, String> appointmentInfo) {
        prescriberId = getprescriberId(appointmentInfo);
        GetImzInfo getImzInfo = getImzInfo(siteId);
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String expectedLastName = name[0];
        String expectedFirstName = name[1];
        String expirationDate = appointmentInfo.get("expirationDate");
        int patientList = getImzInfo.getSvcOrderDetails().size();
        Log.info("patientList from getImZInfo:" + patientList);
        // Clear lists to avoid duplicates
        orderSeqNbrList.clear();
        rxFillIdList.clear();
        serviceIdList.clear();
        itemMdsFamIdList.clear();
        vaccineNameList.clear();
        orderInfoList.clear();
        productMdsFamIdList.clear();

        //Get IMZ info
        boolean isPatientFound = false;
        for (int i = 0; i < patientList; i++) {
            Patient patient = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient();
            String lastNameFromSvc = patient.getLastName();
            String firstNameFromSvc = patient.getFirstName();
            if (lastNameFromSvc != null && firstNameFromSvc != null
                    && lastNameFromSvc.equalsIgnoreCase(expectedLastName) && firstNameFromSvc.equalsIgnoreCase(expectedFirstName)) {
                isPatientFound = true;
                orderId = getImzInfo.getSvcOrderDetails().get(i).getOrderId();
                orderSeqNbr = getImzInfo.getSvcOrderDetails().get(i).getOrderSeqNbr();
                orderSeqNbrList.add(orderSeqNbr);
                patientId = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getPatientId();
                rxFillId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillId();
                rxFillIdList.add(rxFillId);
                serviceId = getImzInfo.getSvcOrderDetails().get(i).getService().getServiceId();
                serviceIdList.add(serviceId);
                itemMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getItemMdsFamId();
                productMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getProductMdsFamId();
                productMdsFamIdList.add(productMdsFamId);
                itemMdsFamIdList.add(itemMdsFamId);
                vaccineName = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getShortName();
                vaccineNameList.add(vaccineName);
                Reporter.log("orderId:" + orderId + "\t  patientId:" + patientId + "\t  rxFillId:" + rxFillId + "\t  serviceId:" + serviceId + "\t  itemMdsFamId:" + itemMdsFamId + "\t  " +
                        "productItemMdsFamId:" + productMdsFamId + "\t orderSeqNbr:" + orderSeqNbr);
            }
        }
        Assert.assertTrue(isPatientFound, "Patient not found in GetImzInfo response for name: " + expectedLastName + ", " + expectedFirstName);
        List<OrderInfo> orderInfoList = new ArrayList<>();

        for (int z = 0; z < orderSeqNbrList.size(); z++) {
            orderInfoList.add(new OrderInfo(orderId, orderSeqNbrList.get(z)));
        }
        // Assigning the multi order
        AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);

        for (int i = 0; i < orderSeqNbrList.size(); i++) {
            //Save Consent Form
            SaveConsentFormWrapper.saveConsentForm(siteId, rxFillIdList.get(i), prescriberId, serviceIdList.get(i), Svc_Image_Txt, SignerName, SupervisorSignature, SupervisorName, ImmunizerSignature,
                    ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME);
            break;
        }
        //saves Product information for multi orders
        SaveProductInformationWrapper.saveProductInformationForMultiRx(siteId, Integer.parseInt(appointmentInfo.get("lotNbr")), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate,
                itemMdsFamIdList, rxFillIdList);
        //completes order - for multi orders
        CompleteOrderWrapper.completeOrderForMultiRx(siteId, Integer.parseInt(appointmentInfo.get("lotNbr")), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamIdList,
                rxFillIdList, vaccineNameList, serviceIdList, patientId, prescriberId);
        Reporter.log("Completed IMZ Administration for Walkin");
    }


    public void performPOSForMultiRx() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientId = getPatientId();
            multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
            for (int i = 0; i < multiRxNbr.size(); i++) {
                rxNbr = String.valueOf(multiRxNbr.get(i));
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.IMZReporting.getValue())) {
                    Reporter.log("order is in IMZ queue");
                }
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.POS.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    automationManager.getConnexusWorkFlow().completeOfflineSale(String.valueOf(rxNbr));
                }
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at POS or IMZREP queue" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    //Get payment status for multiple fillIds
    public void performGetPaymentStatusForMultiRx() {
        if (rxFillIdList == null || rxFillIdList.isEmpty()) {
            Reporter.log("rxFillIdList is empty or null");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < rxFillIdList.size(); i++) {
            sb.append(rxFillIdList.get(i));
            if (i < rxFillIdList.size() - 1) {
                sb.append(",");
            }
        }
        String fillIdList = sb.toString();
        GetPaymentStatus.getPaymentStatus(siteId, fillIdList);
    }

    public void performImZAdministrationForWalkinAddProduct(Map<String, String> appointmentInfo) {
        int patientListInfo, orderSeqNbr2, rxFillId2, serviceId2, itemMdsFamId2;
        String vaccineName2;
        prescriberId = getprescriberId(appointmentInfo);
        getImzInfo = getImzInfo(siteId);
        List<Integer> orderSeqNbrList2 = new ArrayList<>();
        List<OrderInfo> orderInfoList2 = new ArrayList<>();
        List<Integer> serviceIdList2 = new ArrayList<>();
        List<Integer> itemMdsFamIdList2 = new ArrayList<>();
        List<String> vaccineNameList2 = new ArrayList<>();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String expirationDate = appointmentInfo.get("expirationDate");
        int patientList = getImzInfo.getSvcOrderDetails().size();
        Log.info("patientList from getImZInfo:" + patientList);

        //Get IMZ info
        for (int i = 0; i < patientList; i++) {
            if (getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getLastName().equalsIgnoreCase(name[0])) {
                orderId = getImzInfo.getSvcOrderDetails().get(i).getOrderId();
                orderSeqNbr = getImzInfo.getSvcOrderDetails().get(i).getOrderSeqNbr();
                orderSeqNbrList.add(orderSeqNbr);
                patientId = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getPatientId();
                rxFillId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillId();
                rxFillIdList.add(rxFillId);
                serviceId = getImzInfo.getSvcOrderDetails().get(i).getService().getServiceId();
                serviceIdList.add(serviceId);
                itemMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getItemMdsFamId();
                itemMdsFamIdList.add(itemMdsFamId);
                vaccineName = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getShortName();
                vaccineNameList.add(vaccineName);
                Reporter.log("orderId:" + orderId + "\t  patientId:" + patientId + "\t  rxFillId:" + rxFillId + "\t  serviceId:" + serviceId + "\t  itemMdsFamId:" + itemMdsFamId + "\t orderSeqNbr:" + orderSeqNbr);
            }
        }
        for (int z = 0; z < orderSeqNbrList.size(); z++) {
            orderInfoList.add(new OrderInfo(orderId, orderSeqNbrList.get(z)));
            if (orderSeqNbrList.get(z) == 1) {
                // Assigning the 1st order seq number
                AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);
                //Save Consent Form
                SaveConsentFormWrapper.saveConsentForm(siteId, rxFillId, prescriberId, serviceId, Svc_Image_Txt, SignerName, SupervisorSignature, SupervisorName, ImmunizerSignature,
                        ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME);
            }
            break;
        }
        //Get Authorized IMZDrugs
        GetAuthorizedIMZDrugs getAuthImzDrugs = getAuthorizedIMZDrugs(siteId, String.valueOf(patientId));
        int productList = getAuthImzDrugs.getImzProductDetails().size();
        Log.info("ProductList from GetAuthorizedIMZDrugs:" + productList);

        for (int k = 0; k < productList; k++) {
            productMdsFamId = getAuthImzDrugs.getImzProductDetails().get(0).getProductMdsFamId();
            Reporter.log("productMdsFamId:" + productMdsFamId);
            break;
        }
        //Add IMZDrug - adding 2nd drug
        AddIMZDrugWrapper.addIMZDrug(orderId, productMdsFamId, patientId, ASSIGNED_USER_ID_AUT_TEST, siteId, WORK_STATION_HOST_NAME);

        //perform chkDur - for 2nd rxNbr
        automationManager.performSleep(20);
        this.checkAndPerformCheckDUR();

        //Get IMZ info - getting 2nd order seq number
        getImzInfo = getImzInfo(siteId);
        patientListInfo = getImzInfo.getSvcOrderDetails().size();
        Log.info("patientList from getImZInfo:" + patientList);
        for (int i = 0; i < patientListInfo; i++) {
            if (getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getLastName().equalsIgnoreCase(name[0])) {
                orderId = getImzInfo.getSvcOrderDetails().get(i).getOrderId();
                orderSeqNbr2 = getImzInfo.getSvcOrderDetails().get(i).getOrderSeqNbr();
                orderSeqNbrList2.add(orderSeqNbr2);
                patientId = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getPatientId();
                rxFillId2 = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillId();
                rxFillIdList2.add(rxFillId2);
                serviceId2 = getImzInfo.getSvcOrderDetails().get(i).getService().getServiceId();
                serviceIdList2.add(serviceId2);
                itemMdsFamId2 = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getItemMdsFamId();
                itemMdsFamIdList2.add(itemMdsFamId2);
                vaccineName2 = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getShortName();
                vaccineNameList2.add(vaccineName2);
                Reporter.log("orderId:" + orderId + "\t  patientId:" + patientId + "\t  rxFillId:" + rxFillId2 + "\t  serviceId:" + serviceId2 + "\t  itemMdsFamId:" + itemMdsFamId2 + "\t " +
                        "orderSeqNbr:" + orderSeqNbr2);
            }
        }
        automationManager.performSleep(60);
        for (int z = 0; z < orderSeqNbrList2.size(); z++) {
            if (orderSeqNbrList2.get(z) == 2) {
                orderInfoList2.add(new OrderInfo(orderId, orderSeqNbrList2.get(z)));
                // Assigning the 2nd order seq number
                AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList2);
            }
        }
        //saves Product information for multi orders
        SaveProductInformationWrapper.saveProductInformationForMultiRx(siteId, Integer.parseInt(appointmentInfo.get("lotNbr")), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME,
                expirationDate, itemMdsFamIdList2, rxFillIdList2);
        //completes order for multi orders
        CompleteOrderWrapper.completeOrderForMultiRx(siteId, Integer.parseInt(appointmentInfo.get("lotNbr")), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate,
                itemMdsFamIdList2, rxFillIdList2, vaccineNameList2, serviceIdList2, patientId, prescriberId);

        Reporter.log("Completed IMZ Administration for Walkin Add Product Mulit Rx");
    }

    public void performGetPaymentStatusForMultiRxAddProduct() {
        //getPaymentStatus for multi orders
        if (rxFillIdList2.size() <= 2) {
            String fillIdList = rxFillIdList2.get(0) + "," + rxFillIdList2.get(1);
            GetPaymentStatus.getPaymentStatus(siteId, fillIdList);
        } else {
            Log.error("rxFillIdList is not found::" + rxFillIdList2.size());
        }
    }

    public void restartService(){
        connexusAPIManager.restartConnexusService(String.valueOf(siteId));
    }

    public int getprescriberId(Map<String, String> inputData) {
        prescriberId = connexusAppUtils.getPrescriberIdFromName(inputData.get("PRESCRIBER_NAME"));
        return prescriberId;
    }

    public void addPrescriberOnProfileTab(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        patientSearchPage.launchPatientSearchScreen();
        try {
            Reporter.log("Patient Name" + name[0] + "," + name[1]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            Reporter.log("DOB" + inputData.get("DOB"));
            patientSearchPage.inputPatientDob(inputData.get("DOB"));
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            Log.info("add prescriber");
            patientMaintenancePage.clickTabProfile();
            Reporter.log("Adding PCP on PMS Profile/Other tab");
            patientMaintenancePage.enterPrescriberName(inputData.get("PRESCRIBER_NAME"));
            patientMaintenancePage.clickProductSearch3Dots();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Added PCP on PMS Profile/Other tab");
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            Reporter.log("Test failed at PatientMaintainance page");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateFaxPCPNotificationInPMSForMultiOrder(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            //open ClinicalServices Tab In PMS
            this.openClinicalServicesTabInPMS(inputData);
            patientId = getPatientId();
            multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbr.get(i));
                patientMaintenancePage.selectActiveRxNbrRow(currentRxNbr, i);

                //verify rxFillID,Status and click serviceDetails Button
                this.verifyAndOpenServiceDetailsForRxFillId();
                //verify PCP Notification Time Stamp
                prescriberFromPMS = patientMaintenancePage.getPrescriberName();
                Assert.assertEquals(prescriberFromPMS, inputData.get("PRESCRIBER_NAME"), "prescriber not found or doesnot match in PMS");
                pcpNotificationDateTime = patientMaintenancePage.getPCPNotification();
                Assert.assertNotNull(pcpNotificationDateTime, "pcp Notification Date Time is not displayed in UI");
                todaysDate = connexusAppUtils.getCurrentDate("MM/dd/yyyy");
                String pcpNotify[] = pcpNotificationDateTime.split(" ");
                Assert.assertEquals(pcpNotify[0].trim(), todaysDate.trim(), "PCP Notify date is not matched");
                Reporter.log("Validation of pcp Notification Date" + pcpNotify[0].trim());
                Assert.assertTrue(true, pcpNotify[1].trim());
                Reporter.log("Validation of pcp Notification TimeStamp" + pcpNotify[1].trim());
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

                //closes services administration page
                patientMaintenancePage.clickExit();
                patientMaintenancePage.clickYes();
            }
            //closes clinical services page
            patientMaintenancePage.clickSaveAndClose();

        } catch (Throwable e) {
            Reporter.log("Test failed at PatientMaintainance page");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateFaxUnderActionItemsForMultiOrder() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientId = getPatientId();
        multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        try {
            ActionItemsPage actionItemsPage = new ActionItemsPage();
            actionItemsPage.clickActionItems();
            actionItemsPage.clickFaxInbox();
            actionItemsPage.selectOutBox();
            actionItemsPage.clickOk();
            automationManager.performSleep(2);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            actionItemsPage.recordCount();
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbr.get(i));
                String faxNumber = actionItemsPage.getFaxStatusForRxNbr(currentRxNbr);
                Reporter.log("Fax has been sent to\t" + faxNumber);
            }
            actionItemsPage.clickClose();
        } catch (Throwable e) {
            Reporter.log("Test failed at Action Items page");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validatePCPFaxIdEntryAndServiceActivityDetailsForMultiOrder(Map<String, String> inputData) {
        Reporter.log("<--validation started: PCP FaxId Entry And Service Activity Details ForMultiOrder-->");
        patientId = getPatientId();
        multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbr.get(i));

                //PCP_fax_id is generated for fill id
                rxFillId = connexusAppUtils.getRxFillIdTableInfo(siteId, currentRxNbr);
                pcpFaxId = connexusAppUtils.getPCPFaxId(rxFillId);
                Reporter.log("PCPFaxId:" + pcpFaxId);
                Assert.assertNotNull(pcpFaxId, "PCP fax id is  null");
                Assert.assertTrue(true, pcpFaxId);
                Reporter.log("Assert: Validation of pcpFaxId:" + pcpFaxId);

                //PCP_fax_id should have entry in pharmacy_fax table
                String faxIdPharmacyTbl = connexusAppUtils.getFaxIdInPharmacyTable(pcpFaxId);
                rowCount = connexusAppUtils.getPCPFaxIdCount(faxIdPharmacyTbl);
                Assert.assertTrue(rowCount > 0, "Expected entry in pharmacy fax table for pcpFaxId:" + pcpFaxId);
                Reporter.log("Assert: Entry found in DB for pcpFaxId:" + pcpFaxId + "  " + "Row count: " + rowCount);

                //Verify service activity (14150-Successfully sent pcp value)
                serviceIds = connexusAppUtils.getServiceIds(siteId, currentRxNbr);
                pcpServiceId = serviceIds.get(i);
                rowCount = connexusAppUtils.getServiceIdCount(pcpServiceId, Integer.parseInt(inputData.get("activityCode")));
                Assert.assertTrue(rowCount > 0, "Expected entry in pharmacy fax table for serviceId:" + pcpServiceId);
                Reporter.log("Assert: Entry found in DB for serviceId:" + pcpServiceId + "  " + "Row count: " + rowCount);
            }
            Reporter.log("<--validation Completed: PCP FaxId Entry And Service Activity Details ForMultiOrder-->");
        } catch (Throwable e) {
            Reporter.log("Exception occurred:" + e);
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /*Trigger the Cleanup job
     *Run a script in connexus backend through a wrapper job call*/
    public void runConnexusScript(Map<String, String> inputData) {
        scriptName = inputData.get("scriptName");
        targetBoxType = inputData.get("targetBoxType");
        connexusAPIManager.runConnexusScriptBE(String.valueOf(siteId), scriptName, targetBoxType);
    }

    public void openClinicalServicesTabInPMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientSearchPage = new PatientSearchPage();
        patientMaintenancePage = new PatientMaintenancePage();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            Reporter.log("Patient Name" + name[0] + "," + name[1]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.inputPatientDob(inputData.get("DOB"));
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickClinicalServicesTab();
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("clicked on clinical services Tab");
        } catch (Throwable e) {
            Reporter.log("Test failed at Patient Maintenance page");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateIMZScheduledOrderStatusInPMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            this.openClinicalServicesTabInPMS(inputData);
            //verify IMZ Scheduled Order Rx and the corresponding fill id status
            patientId = getPatientId();
            multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbr.get(i));
                //getting status Code and Desc from DB
                statusCodeFromDB = connexusAppUtils.getStatusCode(siteId, currentRxNbr);
                Reporter.log("Status code from DB: " + statusCodeFromDB);
                statusCodeDesc = connexusAppUtils.getCodeDesc(statusCodeFromDB);
                //verify rxNbr status
                rxStatus = patientMaintenancePage.getRxStatusInPMS(patientId, 0);
                Assert.assertEquals(rxStatus, statusCodeDesc, "rxNbr status not matched");
                Reporter.log("Validated rxNbr status is: " + rxStatus);
                //verify fillId status
                fillIdStatus = patientMaintenancePage.getFillIdStatusInPMS(patientId, 0);
                Assert.assertEquals(fillIdStatus, statusCodeDesc, "fillId status not matched");
                Reporter.log("Validated rxfillId status is: " + fillIdStatus);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.clickSaveAndClose();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at Patient Maintenance page");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyWorkQueueStatusAsEOD() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientId = getPatientId();
        multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbr.get(i));
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(currentRxNbr);
                rxStatus = orderSearch.getWorkQueue(0);
                Reporter.log("WorkQueue status: " + rxStatus);
                Assert.assertEquals(rxStatus.toLowerCase(), "eod", "rx order is not in EOD work queue");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                orderSearch.closeSearch();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at EOD work queue status");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void navigateOutBoundUnderActionItems() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            actionItemsPage.clickActionItems();
            actionItemsPage.clickFaxInbox();
            actionItemsPage.selectOutBox();
            actionItemsPage.clickOk();
            actionItemsPage.recordCount();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.log("Test failed at Action Items page");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateSOFaxIdStatusUnderActionItems() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientId = getPatientId();
        multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        try {
            this.navigateOutBoundUnderActionItems();
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbr.get(i));

                //PCP_fax_id is generated for fill id
                rxFillId = connexusAppUtils.getRxFillIdTableInfo(siteId, currentRxNbr);
                soFaxId = connexusAppUtils.getSOPFaxId(rxFillId);
                Assert.assertNotNull(soFaxId, "SO fax id is  null");
                Assert.assertTrue(true, soFaxId);
                Reporter.log("validated soFaxId:" + soFaxId);
                faxId = actionItemsPage.getFaxStatus(soFaxId, "Fax ID");
                Reporter.log("Fax has been sent to\t" + faxId);
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, actionItemsPage.takeScreenShot(currentStepMethodName).getValue());
            }
            actionItemsPage.clickClose();
        } catch (Throwable e) {
            Reporter.log("Test failed at Action Items page");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, actionItemsPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateServiceActivityDetailsInDB(Map<String, String> inputData) {
        patientId = getPatientId();
        multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbr.get(i));
                serviceIds = connexusAppUtils.getServiceIds(siteId, currentRxNbr);

                //Verify service activity Successfully sent for SO or RPH fax value
                pcpServiceId = serviceIds.get(i);
                rowCount = connexusAppUtils.getServiceIdCount(pcpServiceId, Integer.parseInt(inputData.get("activityCode")));
                Assert.assertTrue(rowCount > 0, "Expected entry in pharmacy fax table for serviceId:" + pcpServiceId);
                Reporter.log("Entry found in DB for serviceId:" + pcpServiceId + "  " + "Row count: " + rowCount);
            }
        } catch (Throwable e) {
            Reporter.log("Exception occurred:" + e.getMessage());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyAndOpenServiceDetailsForRxFillId() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientMaintenancePage = new PatientMaintenancePage();
        try {
            //verify rxFillID,Status and click serviceDetails Button
            patientMaintenancePage.selectActiveRxFillIdRow(rxFillId);
            Assert.assertTrue(patientMaintenancePage.isServiceDetailsEnabled());
            patientMaintenancePage.clickServiceDetails();
            Reporter.log("Validation of RxfillId details is completed");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.log("Test failed at clinical Service tab in PMS");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateSOPrescriberNotifiedInPMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            //open ClinicalServices Tab In PMS
            this.openClinicalServicesTabInPMS(inputData);
            patientId = getPatientId();
            multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbr.get(i));
                patientMaintenancePage.selectActiveRxNbrRow(currentRxNbr, i);

                //verify rxFillID,Status and click serviceDetails Button
                this.verifyAndOpenServiceDetailsForRxFillId();
                //verify Standing Order Prescriber Notified Time Stamp
                soPCPNotifiedDate = patientMaintenancePage.getSOPrescriberNotification();
                Assert.assertNotNull(soPCPNotifiedDate, "Standing Order prescriber notified time stamp is not displayed in UI");
                todaysDate = connexusAppUtils.getCurrentDate("M/d/yyyy");
                Assert.assertEquals(soPCPNotifiedDate.trim(), todaysDate.trim(), "Standing Order Prescriber Notified is not matched");
                Reporter.log("Validate of Standing Order prescriber notified date:" + soPCPNotifiedDate.trim());
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());

                //closes services administration page
                patientMaintenancePage.clickExit();
                patientMaintenancePage.clickYes();
            }
            //closes clinical services page
            patientMaintenancePage.clickSaveAndClose();

        } catch (Throwable e) {
            Reporter.log("Test failed at Standing Order Prescriber Notified in PMS");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateRphPCPFaxIdStatusUnderActionItems() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientId = getPatientId();
        multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        try {
            this.navigateOutBoundUnderActionItems();
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbr.get(i));
                String faxNumber = actionItemsPage.getFaxStatus(currentRxNbr, "Rx#");
                Reporter.log("Fax has been sent to\t" + faxNumber);
            }
            actionItemsPage.clickClose();
        } catch (Throwable e) {
            Reporter.log("Test failed at Action Items page");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    //perform chkDUR and close ClinIntel Screen
    public void performCheckDURAndClinIntel() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        orderSearch = new F6Search();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_20)) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }
            // check open ClinIntel Screen and close
            if (ischeckIMZOrderQueueDB(rxNbr, WorkQueueSettings.ClinicalIntelligence.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                title = clinicalIntelligencePage.getTitle();
                if ("Clinical Intelligence IMZ Rx".equalsIgnoreCase(title)) {
                    Reporter.log("Assert: title matched in Clin Intel screen");
                    Reporter.logScreenShot(Status.PASS, "ClinicalIntelligence", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                    clinicalIntelligencePage.clickAcceptBtn();
                } else {
                    //open and close ClinIntel Screen
                    clinIntelTestScript.verifyWQStatusOpenAndCloseForClinIntel();
                }
            }
            if (ischeckIMZOrderQueueDB(rxNbr, WorkQueueSettings.ServiceAdministration.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                Reporter.log("order is in service admin ");
            } else {
                Reporter.log("order is not in service admin ");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /**
     * Performs imz administration for unassigned orders through Walkin APIs.
     * @param inputData test data details
     */
    public void performImzAdministrationForUnassignOrders(Map<String, String> inputData) {
        prescriberId = getprescriberId(inputData);
        GetImzInfo getImzInfo = getImzInfo(siteId);
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String expirationDate = inputData.get("expirationDate");
        int patientList = getImzInfo.getSvcOrderDetails().size();
        Log.info("patientList from getImZInfo:" + patientList);
        //Get IMZ info
        for (int i = 0; i < patientList; i++) {
            if (getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getLastName().equalsIgnoreCase(name[0])) {
                orderId = getImzInfo.getSvcOrderDetails().get(i).getOrderId();
                orderSeqNbr = getImzInfo.getSvcOrderDetails().get(i).getOrderSeqNbr();
                patientId = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getPatientId();
                rxFillId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillId();
                serviceId = getImzInfo.getSvcOrderDetails().get(i).getService().getServiceId();
                itemMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getItemMdsFamId();
                productMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getProductMdsFamId();
                vaccineName = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getShortName();
                Reporter.log("orderId:" + orderId + "\t  patientId:" + patientId + "\t  rxFillId:" + rxFillId + "\t  serviceId:" + serviceId + "\t  itemMdsFamId:" + itemMdsFamId + "\t  " +
                        "productItemMdsFamId:" + productMdsFamId + "\t orderSeqNbr:" + orderSeqNbr);
            }
        }
        List<OrderInfo> orderInfoList = new ArrayList<>();
        orderInfoList.add(new OrderInfo(orderId, orderSeqNbr));

        // Assigning the order
        AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);
        //Save Consent Form
        SaveConsentFormWrapper.saveConsentForm(siteId, rxFillId, prescriberId, serviceId, Svc_Image_Txt, SignerName, SupervisorSignature, SupervisorName, ImmunizerSignature,
                ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME);
        //saves Product information
        SaveProductInformationWrapper.saveProductInformation(siteId, inputData.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId);
        //Unassign the orders
        UnassignOrdersWrapper.unassignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);
        Reporter.log("Completed IMZ Administration until unassign orders for walkin order through APIs");
    }

    /**
     * Verifies service details in PMS for multi Rx orders.
     * @param inputData test data details
     */
    public void verifyServiceDetailsInPMSForMultiRx(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientMaintenancePage = new PatientMaintenancePage();
        try {
            //open ClinicalServices Tab In PMS
            this.openClinicalServicesTabInPMS(inputData);
            patientId = getPatientId();
            multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
            Assert.assertEquals(productMdsFamIdList.size(), multiRxNbr.size(), "Mismatch between productMdsFamIdList size and multiRxNbr size");
            for (int i = 0; i < multiRxNbr.size(); i++) {
                rxNbr = String.valueOf(multiRxNbr.get(i));
                patientMaintenancePage.selectActiveRxNbrRow(rxNbr, i);

                //verify rxFillID,Status and click serviceDetails Button
                this.verifyAndOpenServiceDetailsForRxFillId();

                //verify lot Numbers
                Assert.assertEquals(patientMaintenancePage.getLotNo(), inputData.get("lotNbr"), "lot numbers are different");
                Reporter.log("Assert: validation of Actual lot numbers with expected is completed");

                //verify Administrated BY
                String expectedPrescriberName = inputData.get("PRESCRIBER_NAME");
                String administerName = patientMaintenancePage.getAdministratorValue().trim();
                boolean isPrescriberNameValid = administerName.contains(expectedPrescriberName);
                Assert.assertTrue(isPrescriberNameValid,
                        String.format("Prescriber name validation failed. Expected: '%s' to be contained in Administrator name: '%s'",
                                expectedPrescriberName, administerName));
                Reporter.log("Assert: Validation of Administrated by completed with given value is matched");

                //verify VIS PublishDate
                int productIndex = productMdsFamIdList.size() - 1 - i;
                productMdsFamId = productMdsFamIdList.get(productIndex);

                String visPubDate = getVisPubFromDB();
                Log.info("visPubdate" + visPubDate);
                visPubDate = connexusAppUtils.dateConversion(visPubDate);
                Assert.assertEquals(visPubDate, patientMaintenancePage.getVISPublishDate().trim(), "VIS Publish Date did not Matched");
                Reporter.log("Assert: Validation of VIS PublishDate from PMS is completed");
                Reporter.logScreenShot(Status.PASS, "ServiceAdministration", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());

                //verify VIS GivenDate
                String todaysDate = connexusAppUtils.getCurrentDate("MM/dd/yyyy");
                Assert.assertNotNull(patientMaintenancePage.getVISGivenDate(), "VIS Given Date is  null");
                Assert.assertEquals(patientMaintenancePage.getVISGivenDate().trim(), todaysDate, "VIS GIVEN Date is Matched");
                Reporter.log("Assert: Validation of VIS GivenDate from PMS is completed");

                //verify Dosage ML
                String dosageML = patientMaintenancePage.getDosageMLValue().trim();
                Assert.assertTrue(true, dosageML);
                Reporter.log("Assert: Validation of Dosage ML info:" + dosageML);

                //Clikcing IMZForm and check for IMZForm
                patientMaintenancePage.clickImzForm();
                Boolean pqcfImg = patientMaintenancePage.verifyPvImage();
                Assert.assertTrue(pqcfImg, "PQCF Image doesnot exist");
                Reporter.logScreenShot(Status.PASS, "ScanIMZForm", patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());

                //closes IMZ form
                patientMaintenancePage.clickExit();
                //closes services administration page
                patientMaintenancePage.clickExit();
                patientMaintenancePage.clickYes();
            }
            //closes clinical services page
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed at PatientMaintainance page" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }
}