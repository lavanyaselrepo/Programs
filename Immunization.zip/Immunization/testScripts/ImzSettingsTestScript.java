package clinicalservices.Immunization.testScripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.Sonic.wrappers.CreateImzSettingsWrapper;
import hwqe.baseframework.utilities.PropertyReader;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.imzapp.constants.Consts.*;

import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.Assert;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Map;


public class ImzSettingsTestScript extends ConnexusTestScripts {
    CreateImzSettingsWrapper createImzSettingsWrapper = new CreateImzSettingsWrapper();
    DateTimeFormatter df = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    String futureDate = LocalDate.now().plusDays(45).format(df);
    int storePreAuthId, servicePreAuthIdFromDB;
    String stateCode,lastUpdateReason,protocolName,authorizationType,lastUpdateUser,createUserId,faxIndicator,faxNumber,drugAuthType,delegatePrescriberData,
     authorizedServiceLineItems,sigCode,sigText,txtSOFaxNumberFromUI,lastUpdatedInfoFromUI, soExpiresDateFromUI;
    List<String> shortNameList;
    List<Integer> productMdsFamIdList;
    List<String> drugShortNamesFromDB;
    List<String> authDrugListFromUI;

    public ImzSettingsTestScript() {
        PropertyReader prop = PropertyReader.getInstance();
        prop.loadCustomProperties("config/connexus/");
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
    }

    /**
     * Create Immunization Settings for SO protocol
     * @param inputData
     * @return storePreAuthId
     */
    public int createCloudServiceSettingsSO(Map<String, String> inputData) {
        stateCode = inputData.get("stateCode");
        lastUpdateReason = inputData.get("lastUpdateReason");
        protocolName = inputData.get("protocolName");
        authorizationType = inputData.get("authorizationType");
        lastUpdateUser = inputData.get("lastUpdateUser");
        createUserId = inputData.get("createUserId");
        faxIndicator = inputData.get("faxIndicator");
        faxNumber = inputData.get("faxNumber");
        drugAuthType = inputData.get("drugAuthType");
        shortNameList = Arrays.asList(inputData.get("drugShortName1"), inputData.get("drugShortName2"));
        productMdsFamIdList = Arrays.asList(Integer.parseInt(inputData.get("productMdsFamId1")), Integer.parseInt(inputData.get("productMdsFamId2")));
        delegatePrescriberData = inputData.get("delegatePrescriberData");
        authorizedServiceLineItems = inputData.get("authorizedServiceLineItems");
        sigCode = inputData.get("sigCode");
        sigText = inputData.get("sigText");

        //Create Immunization Settings for SO protocol
        storePreAuthId = createImzSettingsWrapper.createSettingsSo(stateCode, lastUpdateReason, clinicalService, protocolName, authorizationType, status,
                lastUpdateUser, preAuthId, createUserId, delegatePrescriberData, authorizedServiceLineItems, centralId, pdfCentralId, centralPrescriberId,
                centralClinicId, delegatePrescriberId, delegateClinicId, faxIndicator, faxNumber, shortNameList, productMdsFamIdList, drugAuthType, sigCode, sigText);
        Reporter.log("Generated storePreAuthId : " + storePreAuthId);
        Reporter.log("Immunization Settings SO protocol created successfully");

        return storePreAuthId;
    }

    /**
     * Validate the stored service pre-auth ID with the one retrieved from DB
     */
    public void validatdeServicePreAuthId() {
        try {
            servicePreAuthIdFromDB = connexusAppUtils.getPreAuthId(String.valueOf(storePreAuthId));
            Assert.assertEquals(storePreAuthId, servicePreAuthIdFromDB, "Sonic Pre auth id did not match");
            Reporter.log("Validated storePreAuthId response is matched from API: " + storePreAuthId + " and DB: " + servicePreAuthIdFromDB);
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Failed to validate storePreAuthId: " + e.getMessage());
            Assert.fail("Failed to validate storePreAuthId: " + e.getMessage());
        }
    }

    /**
     * Validate Immunization Settings fields for SO protocol
     * @param inputData
     */
    public void validateImzSoSettingsFields(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            //open Immunization Settings page
            imzSettingsPage.openImzSettingsPage();
            Reporter.log("<--Validating SO protocol fields in Immunization Settings page-->");

            // Validate fax number
            txtSOFaxNumberFromUI = imzSettingsPage.getSOFaxNumber().replaceAll("[^\\d]", "");
            faxNumber = inputData.get("faxNumber");
            Assert.assertEquals(txtSOFaxNumberFromUI, faxNumber, "SO fax number text validation failed");
            Reporter.log("Validated SO fax number is matched from UI: " + txtSOFaxNumberFromUI + " and API req: " + faxNumber);

            // Validate last Updated User Info
            lastUpdatedInfoFromUI = imzSettingsPage.getLastUpdated();
            lastUpdateUser = inputData.get("lastUpdateUser");
            Assert.assertEquals(lastUpdatedInfoFromUI, lastUpdateUser, "Last Updated User info is not matched");
            Reporter.log("Validated Last Updated User info is matched from UI: " + lastUpdatedInfoFromUI + " and API req: " + lastUpdateUser);

            // Validate SO protocol auth products that the drug names match
            productMdsFamIdList = Arrays.asList(Integer.parseInt(inputData.get("productMdsFamId1")), Integer.parseInt(inputData.get("productMdsFamId2")));
            drugShortNamesFromDB = connexusAppUtils.getPharmacyProductDrugName(productMdsFamIdList);
            authDrugListFromUI = imzSettingsPage.getAuthProductList();
            Assert.assertEquals(authDrugListFromUI, drugShortNamesFromDB, "Drugs are not matched");
            Reporter.log("Validated SO protocol products is matched from UI: " + authDrugListFromUI + " and DB: " + drugShortNamesFromDB);

            // Validate SO protocol RxImage So Expire date
            imzSettingsPage.clickBtnProtocolSORXImage();
            soExpiresDateFromUI = imzSettingsPage.getSOExpiresDate();
            Assert.assertEquals(soExpiresDateFromUI, futureDate, "SO Expires date validation failed");
            Reporter.log("Validated SO Expires date is matched from UI: " + soExpiresDateFromUI + " and API req: " + futureDate);
            Reporter.logScreenShot(Status.PASS, "StandingOrderRxImage", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            // click so rxImage cancel btn
            imzSettingsPage.btnCancel();
            Reporter.log("Validated SO protocol fields in Immunization Settings page successfully");

            Reporter.logScreenShot(Status.PASS, "ImmunizationSettings", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            // click imz settings cancel btn
            imzSettingsPage.btnCancel();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Failed to validate Immunization Settings fields for SO protocol: " + e.getMessage());
        }
    }


}
