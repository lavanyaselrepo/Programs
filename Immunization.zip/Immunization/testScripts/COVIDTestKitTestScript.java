package clinicalservices.Immunization.testScripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.pharmaIMZApp.imzInventory.response.GetInventoryResponse;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.pharmaIMZApp.wrappers.PharmaInventoryAPIWrapper;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import opticaltests.inventorytests.InventoryWrapper;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class COVIDTestKitTestScript extends ConnexusTestScripts {

    ConnexusAPIManager connexusApiManager;
    int patientId, numRefills, siteId, rxFillId, orderId, orderSeqNbr, rxId, rxClinicId, prescriberId;
    Map<String, Integer> value = new HashMap<>();
    List<String> ndcList;
    List<Integer> multiRxNbrValues = new ArrayList<>();
    List<Integer> rxFillIdList = new ArrayList<>();
    List<Integer> rxIdList = new ArrayList<>();
    InventoryWrapper api = new InventoryWrapper();
    String serviceType, productmdsID;
    int productMdsFamID;
    List<Integer> multiRxNbr = new ArrayList<>();


    public COVIDTestKitTestScript() {
        propertyReader.loadCustomProperties("config/connexus/");
        propertyReader.loadCustomProperties("config/fom/");
        siteId = Integer.parseInt(propertyReader.getProperty("cnx.store"));
        connexusApiManager = new ConnexusAPIManager();
    }

    /*
     * Perform Covid Testing Kit Drop Off by selecting product
     * */
    public void performCovidTestingKitDropOff(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setNoOfRx(1);
            dropRxModel.setPriority(Priority.Future);
            automationManager.getConnexusWorkFlow().performCovidTestingKitDropRx(dropRxModel, inputData.get("PRESCRIBER_NAME"));
        } catch (Throwable e) {
            Reporter.log("Test failed at DropOff queue" +e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /*
     * Perform 4 Point Check for single order
     * based on the product sometimes it will directly move to filling queue
     * */
    @Override
    public void perform4Point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_40)) {
                automationManager.getConnexusWorkFlow().performFourPoint(rxNbr);
            } else if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_40)) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                automationManager.getConnexusWorkFlow().performFourPoint(rxNbr);
                Reporter.log("RX is in 4point queue");
            } else if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                Reporter.log("It will perform Filling through UI or FillingAndMoveToEOD through api");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void checkAndPerformCheckDUR() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(),ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }else if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue(),ConnexusConstants.WAIT_TIMEOUT_30)) {
                Reporter.log("It will performing FillingAndMoveToEOD through api");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR" +e.getMessage());
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /*
     * Perform PickUp for single order
     * performing action to selfHelpResetUser to order to move to PickUp queue
     * */
    @Override
    public void performPickUp(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            orderSearch.getRXStatusForPatientSelfHelp(rxNbr, 0, inputData);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.Pickup.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("DOB"), rxNbr);
            } else if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                automationManager.getConnexusWorkFlow().completePickup(name[1], name[0], inputData.get("DOB"), rxNbr);
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at PickUp queue" + e.getMessage());
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    public void launchEODAndValidateRxImage() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.EOD.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(3);
                eod.clickBtnNo();
                automationManager.getConnexusWorkFlow().navigateToRxImage(rxNbr);
            } else {
                Reporter.log("RX is not in EOD queue");
                Assert.fail("RX is not in EOD queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at EOD queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void launchEODAndValidateRxNotes(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String textUser, drugName, rxNotes;
        textUser = inputData.get("TEXT_USER");
        drugName = inputData.get("DRUG_NAME");
        rxNotes = inputData.get("RX_NOTES");
        try {
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.EOD.getWorkQueue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                automationManager.performSleep(3);
                eod.clickBtnNo();
                automationManager.getConnexusWorkFlow().navigateToRxNotes(rxNbr, textUser, drugName, rxNotes);
            } else {
                Reporter.log("RX Notes is not in EOD queue");
                Assert.fail("RX Notes is not in EOD queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at EOD queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    public void validateRxNotes(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String textUser, drugName, rxNotes;
        textUser = inputData.get("TEXT_USER");
        drugName = inputData.get("DRUG_NAME1");
        rxNotes = inputData.get("RX_NOTES");
        try {
            //validate Rx Notes on Rx LookUp screen
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(rxNbr);
            rxLookUp.clickSearch();
            automationManager.getConnexusWorkFlow().navigateToRxNotes(rxNbr, textUser, drugName, rxNotes);
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            Reporter.log("Test failed at validateRxNotes" +e.getMessage());
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /*
     * Validate Rx Image on Rx LookUp screen
     * */
    public void validateRxImage() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(rxNbr);
            rxLookUp.clickSearch();
            automationManager.getConnexusWorkFlow().navigateToRxImage(rxNbr);
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            Reporter.log("Test failed at Rx Image" +e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void flushCache() {
        connexusApiManager.flushCache(String.valueOf(siteId));
    }

    public void performCovidTestKitDropOffForMultiDrugs(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        List<String> drugList;
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setPriority(Priority.Critical);
            drugList = Arrays.asList(inputData.get("DRUG_NAME1"), inputData.get("DRUG_NAME2"));
            automationManager.getConnexusWorkFlow().performCovidTestingKitForMultiDrug(dropRxModel, drugList, inputData.get("PRESCRIBER_NAME"));
        } catch (Throwable e) {
            Reporter.log("Test failed at DropOff queue" +e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void perform4PointForMultiOrder() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientId = getPatientIdFromName();
        multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                String[] name = connexusAppUtils.readPatientNameFromFile();
                rxNbr = orderSearch.getMultiRxNbrForPatient(name[0] + "," + name[1], i);
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue(), ConnexusConstants.WAIT_TIMEOUT_40)) {
                    automationManager.getConnexusWorkFlow().performFourPoint(rxNbr);
                } else if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_40)) {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                    automationManager.getConnexusWorkFlow().performFourPoint(rxNbr);
                    Reporter.log("RX is in 4point queue");
                }
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue" +e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public int getPatientIdFromName(){
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String query = "select patient_id from patient where first_name= " + "'" + name[1].toUpperCase() + "'" + " and last_name = " + "'" + name[0].toUpperCase() + "';";
        patientId = automationManager.getConnexusDB(siteId).getScalar(query, Integer.class);
        return patientId;
    }

    public void checkAndPerformMultiCheckDUR() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientId = getPatientIdFromName();
        multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                String[] name = connexusAppUtils.readPatientNameFromFile();
                rxNbr = orderSearch.getMultiRxNbrForPatient(name[0] + "," + name[1], i);
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                    automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
                } else if (checkOrderQueueDB(rxNbr, WorkQueueSettings.WorkQueueFill.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    Reporter.log("It will performing FillingAndMoveToEOD through api");
                }
            }
        } catch(Throwable e){
            Reporter.log("Test failed at ChkDUR" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void multiRxFillingAndMoveToEOD(Map<String, String> inputData) {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        automationManager.performSleep(5);
        patientId = Integer.parseInt(connexusAppUtils.getPatientId(name[0], name[1]));
        Log.info("patientId:" + patientId);
        multiRxNbrValues = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        Log.info("multiRxNbrValues:" + multiRxNbrValues);
        ndcList = Arrays.asList(inputData.get("NDC1"), inputData.get("NDC2"));
        numRefills = Integer.parseInt(inputData.get("REFILLS"));
        String currentRxNbr;
        try {
            for (int i = 0; i < multiRxNbrValues.size(); i++) {
                currentRxNbr = String.valueOf(multiRxNbrValues.get(i));
                value = connexusAppUtils.getRxOrderDetailsBasedOnNextWorkQueCode(siteId, currentRxNbr);
                orderId = value.get("orderId");
                rxId = value.get("rxId");
                rxIdList.add(rxId);
                rxFillId = value.get("rxFillId");
                rxFillIdList.add(rxFillId);
            }
            connexusApiManager.multiRxFillingToEOD(Integer.parseInt(String.valueOf(patientId)), orderId, siteId, rxFillIdList, rxIdList, numRefills, ndcList, multiRxNbrValues);
            Reporter.log("POS has completed and work queue move to EOD");
        } catch (Throwable e) {
            Reporter.log("Error message in Perform multiRxFillingAndMoveToEOD"+e.getMessage());
            Reporter.log("Test failed at Filling and move to EOD queue");
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void restartService() {
        connexusApiManager.restartConnexusService(String.valueOf(siteId));
    }

    public void openProductSearchWindow() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            productSearchPage.launchProductSearchScreen();
            Assert.assertTrue(productSearchPage.isProductNameComboBoxDisplayed());
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.log("Test failed at product search window" +e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void searchProductName(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            productSearchPage.enterProductName(inputData.get("PRODUCT_NAME"));
            productSearchPage.clickSearchNow();
            productSearchPage.clickHostLookUp();
            Assert.assertTrue(productSearchPage.isProductRecordDisplayed(0));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.log("Test failed at search product name" +e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void searchProductWithNameAndNDCFields(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            productSearchPage.enterProductName(inputData.get("PRODUCT_NAME"));
            productSearchPage.enterProductNDC(inputData.get("PRODUCT_NDC"));
            productSearchPage.clickSearchNow();
            productSearchPage.clickHostLookUp();
            Assert.assertTrue(productSearchPage.getProductNameFromSearchGridShortNameColumn(0).contains(inputData.get("PRODUCT_NAME")));
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
            productSearchPage.openProductRecordFromSearch(0);
            productSearchPage.clickBtnYes();
            String title = productMaintenancePage.getTitle();
            Assert.assertEquals("Product Screen", title, "title did not match");
            Reporter.log("Assert: title matched in product screen");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            //commented this step to execute on hand quantity update in item maintenance screen
            //reused this method (HWPHME2E-1008),
            // will not affect existing tc
            //productMaintenancePage.clickCancelBtn();
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, productSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }
    }

    //Validate Activity codes from order detail and activity text
    public void validateActivityCodesFromOrderId() {
        try {
            List<String> actualActivityCodesFromOrderDtl, expectedActivityCodeFromText;
            List<Integer> expectedCodes = Arrays.asList(1100, 1101, 1122, 1127, 1130);
            actualActivityCodesFromOrderDtl = connexusAppUtils.getActivityCodesFromOrderDtlTbl(siteId, rxNbr, expectedCodes);
            expectedActivityCodeFromText = connexusAppUtils.fetchActivityCodesFromText(expectedCodes);
            Assert.assertEquals(actualActivityCodesFromOrderDtl, expectedActivityCodeFromText, "Activity codes do not match");
            Reporter.log("Validated both activity codes from order detail and activity text table matched in DB");
        }catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Activity codes did not matched");
            Assert.fail(e.toString());
        }
    }

    public float checkInventoryInfoInAPI(Map<String, String> inputData) {
        float inventoryQuantity = 0;
        serviceType = inputData.get("SERVICE_TYPE");
        productmdsID = inputData.get("Product Mds FamId");
        productMdsFamID = Integer.parseInt(productmdsID);
        PharmaInventoryAPIWrapper pharmaInventoryWrapper = new PharmaInventoryAPIWrapper();
        GetInventoryResponse inventory = pharmaInventoryWrapper.getInventoryQuantity(siteId, serviceType);
        // Check if the inventory list is not null or empty
        if (inventory == null || inventory.getInventory() == null || inventory.getInventory().isEmpty()) {
            Reporter.log("Error: Inventory data is empty or not available.");
            return inventoryQuantity;
        }
        boolean productFound = false;
        for (int i = 0; i < inventory.getInventory().size(); i++) {
            if (inventory.getInventory().get(i).getProductMdsFamId() == productMdsFamID) {
                if (inventory.getInventory().get(i).getQuantity() != null && !inventory.getInventory().get(i).getQuantity().isEmpty()) {
                    inventoryQuantity = inventory.getInventory().get(i).getQuantity().get(0).getValue();
                    Reporter.log("Assert: Product Quantity in API: " + inventoryQuantity);
                } else {
                    Reporter.log("Error: Quantity for product with MdsFamId " + productMdsFamID + " is not available.");
                }
                productFound = true;
                break;
            }
        }
        if (!productFound) {
            Reporter.log("Error: Product with MdsFamId " + productMdsFamID + " was not found in the inventory.");
        }
        return inventoryQuantity;
    }

    public void refreshInventoryAPI() {
        Reporter.log("Perform RefreshInventory API");
        api.refreshInventory(Collections.singletonList(siteId));
        automationManager.performSleep(180);
    }

    public void updateInventoryAPICheck(Map<String, String> inputData, String updatedQuantity) {
        float updatedinventoryvalue = checkInventoryInfoInAPI(inputData);
        String updatedvalueinInventory = String.valueOf(updatedinventoryvalue);
        BigDecimal value = new BigDecimal(updatedvalueinInventory);
        value = value.stripTrailingZeros();
        String valueinapiafterupdate = value.toPlainString();
        Reporter.log("updated value in API: " + updatedinventoryvalue);
        Assert.assertEquals(valueinapiafterupdate, updatedQuantity, "Quantity not updated");
    }

    public void checkProductUpdates(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            Reporter.log("Product update happening in Connexus in Item maintenance page");
            String ndc = inputData.get("PRODUCT_NDC");
            String onHandQuantityBeforeChange = productMaintenancePage.getOnHandDrugQuantityFromItemSearchGrid(0);
            Reporter.log("The On hand Quantity of the drug is " + onHandQuantityBeforeChange);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());

            Reporter.log("Product quantity before update=" + onHandQuantityBeforeChange);
            productMaintenancePage.doubleClickOnItemsGridRow(0);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, productMaintenancePage.takeScreenShot(currentStepMethodName).getValue());

            Reporter.log("on_hand_qty before inventory update in UI");
            checkQuantityInDB(ndc, onHandQuantityBeforeChange);

            itemMaintenancePage.clearOnHandDrugQty();
            Reporter.log("onhandquantitycleared");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());

            int updateQuantityBy1 = Integer.parseInt(onHandQuantityBeforeChange) + 10;
            itemMaintenancePage.inputOnHandDrugQty(String.valueOf(updateQuantityBy1));
            Reporter.log("updatedQuantityentered=" + updateQuantityBy1);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());

            itemMaintenancePage.clickAccept();
            c2LogBookAdjustmentReasonPage.clickAdjustmentReason(0);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());

            c2LogBookAdjustmentReasonPage.clickContinue();
            String onHandQuantityAfterChange = productMaintenancePage.getOnHandDrugQuantityFromItemSearchGrid(0);
            Reporter.log("Quantity_After_update_in_UI=" + onHandQuantityAfterChange);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, itemMaintenancePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.assertNotEquals(onHandQuantityBeforeChange, onHandQuantityAfterChange, "Both quantities are same or update quantity didn't not fetch the value");
            Reporter.log("Product Screen is displayed with the new on hand Drug Quantity " + onHandQuantityAfterChange + " in On-Hand field");

            c2LogBookAdjustmentReasonPage.clickAccept();
            productMaintenancePage.clickAccept();

            Reporter.log("on_hand_qty after inventory update in UI");
            Reporter.log("On hand quantity check in DB");
            checkQuantityInDB(ndc, onHandQuantityAfterChange);
            Reporter.log("Hitting Refresh Inventory API");
            refreshInventoryAPI();
            Reporter.log("Hitting Update Inventory API agin to check value update");
            updateInventoryAPICheck(inputData, onHandQuantityAfterChange);

        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void checkQuantityInDB(String ndc, String onHandQuantities) {
        String on_hand_qty = connexusAppUtils.getOnHandQuantity(ndc);
        BigDecimal value = new BigDecimal(on_hand_qty);
        value = value.stripTrailingZeros();
        String onHandQuantityinDB = value.toPlainString();
        Reporter.log("quantity_in_db--:" + on_hand_qty);
        Assert.assertEquals(onHandQuantityinDB, onHandQuantities, "No update in on hand quantity");
    }

    public void scanRxImageForRphProtocol(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            menuBar.selectNavigation(AppMenu.OTC_BILLING_SETTINGS,AppMenuItemsIndex.TOOLS_OTC_BILLING_SETTINGS,null,null);
            Reporter.log("OTC Billing Setting screen displayed");
            otcBillingSettingPage.clickRadioBtnrphIssueOrder();
            Reporter.log("pop up screen displayed");
            otcBillingSettingPage.clickYesBtn();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, otcBillingSettingPage.takeScreenShot(currentStepMethodName).getValue());
            List<String> drugList =Arrays.asList(inputData.get("DRUG_NAME1"));
            otcBillingSettingPage.selectAuthImzDrug(drugList);
            Reporter.log("drug added to the auth list");
            otcBillingSettingPage.performScanNewProtocolRPh();
            Reporter.log("expire date is selected");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, otcBillingSettingPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("OTC Billing settings pop up screen displayed with message");
            otcBillingSettingPage.clickOk();
            otcBillingSettingPage.clickAccept();
            connexusAppUtils.getServicePreAuthId(inputData.get("PRE_AUTH_ID"));
        }catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Rx Image scan for Rph Protocol is failed" +e.getMessage());
            Assert.fail(e.toString());
        }
    }

}