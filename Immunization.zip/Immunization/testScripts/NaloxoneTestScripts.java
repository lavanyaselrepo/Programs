package clinicalservices.Immunization.testScripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import org.testng.Assert;

import java.util.HashMap;
import java.util.Map;

public class NaloxoneTestScripts extends ConnexusTestScripts {

    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();

    public NaloxoneTestScripts() {
        propertyReader.loadCustomProperties("config/connexus/");
        propertyReader.loadCustomProperties("config/connexustestharness/");
        propertyReader.loadCustomProperties("config/fom/");
        siteId = Integer.parseInt(propertyReader.getProperty("cnx.store"));

    }

    /*
     * This method performs the drop-off of a naloxone-in store.
     * @param inputData A map containing input data, including the drug name.
     */
    public void performNaloxoneDropOffRx(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String imzDrug;
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setPriority(Priority.Critical);
            imzDrug = inputData.get("DRUG_NAME1");
            automationManager.getConnexusWorkFlow().performNaloxoneDropOffRx(dropRxModel, imzDrug, inputData.get("PRESCRIBER_NAME"));
        } catch (Throwable e) {
            Reporter.log("Test failed at DropOff queue");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /*
     *  This method performs the 4-point check for a naloxone order.
     * */
    @Override
    public void perform4Point() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.wm4PointCheck.getValue())) {
                automationManager.getConnexusWorkFlow().performFourPoint(rxNbr);
            } else if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
                automationManager.getConnexusWorkFlow().performFourPoint(rxNbr);
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at 4 Point queue" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /*
     * This method verifies if a order rxNbr has reached to the EOD status in the work queue.
     * It checks the database for the order's status and confirms if it is in the EOD queue.
     * */
    public void verifyWorkQueueStatusAsEOD() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String rxStatus;
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.IMZReporting.getValue())) {
                Reporter.log("Rx is in IMZREP queue");
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.EOD.getValue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                Assert.assertEquals(rxStatus, "eod", "order is not in eod queue");
                Reporter.log("Rx is in EOD");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                orderSearch.closeSearch();
            }
        } catch (Throwable e) {
            Reporter.log("RX not in EOD queue");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    public void restartService(){
        connexusAPIManager.restartConnexusService(String.valueOf(siteId));
    }

    public void flushCache() {
        connexusAPIManager.flushCache(String.valueOf(siteId));
    }

    /*
     * This method performs the drop-off of a naloxone state partnership flow.
     * @param inputData A map containing input data, including the drug name and quantity details.
     * */
    public void performNaloxoneStatePartnershipDropOff(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String imzDrug;
        int qtyEvenNum, qtyOddNum, minRangeEvenNum, maxRangeEvenNum, minRangeOddNum, maxRangeOddNum;
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dropRxModel.setPriority(Priority.Critical);
            imzDrug = inputData.get("DRUG_NAME1");
            qtyEvenNum = Integer.parseInt(inputData.get("qtyEvenNum"));
            qtyOddNum = Integer.parseInt(inputData.get("qtyOddNum"));
            minRangeEvenNum = Integer.parseInt(inputData.get("minRangeEvenNum"));
            maxRangeEvenNum = Integer.parseInt(inputData.get("maxRangeEvenNum"));
            minRangeOddNum = Integer.parseInt(inputData.get("minRangeOddNum"));
            maxRangeOddNum = Integer.parseInt(inputData.get("maxRangeOddNum"));
            automationManager.getConnexusWorkFlow().performNaloxoneStatePartnershipDropOff(dropRxModel, imzDrug, qtyEvenNum, qtyOddNum, minRangeEvenNum, maxRangeEvenNum, minRangeOddNum, maxRangeOddNum);
        } catch (Throwable e) {
            Reporter.log("Test failed at DropOff queue" + e.getMessage());
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }
}