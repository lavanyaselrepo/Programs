package clinicalservices.Immunization.testScripts;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.PFSConstants;
import clinicalservices.IMZSchedulingPlatformServices.wrappers.CosmosWrapper;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.AsuiSlot.bookAppointment.Response.StoreBookResponse;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.datacontext.CosmosContext;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.AsuiSlot.wrappers.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;
import java.util.*;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.AsuiSlot.wrappers.BookAppointmentWrapper.bookRequest;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.utils.DateHelper.getRandomDate;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.pharmaIMZApp.wrappers.PharmaIMZSchedulingWrapper.questionsWithAllFalse;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.pharmaIMZApp.cosmosResponse.CosmosResponseObject;
public class ASUITestScripts extends ConnexusTestScripts {
    ConnexusAppUtils connexusAppUtils;
    AutomationManager am;
    ConnexusAPIManager connexusAPIManager;
    StoreBookResponse resp;
    int siteId;
    String[] name;
    String accessPointId,slotId,slotTime,asuiSlotDate,slotDate,reservationId,appointmentId,orderId;
    PropertyReader prop = PropertyReader.getInstance();
    CosmosContext cosmosContext;
    static Random random = new Random();
    BookAppointmentWrapper bookAppointment;
    ImzTestScripts imzTestScripts;
    String centralPatientId,patientId,pharmaIMZappointmentId,asuiPatientId,startDate,endDate,fulfillmentType,reservationType,accountId;

    public ASUITestScripts() {
        prop.loadCustomProperties("config/connexus/");
        prop.loadCustomProperties("config/connexustestharness/");
        prop.loadCustomProperties("config/fom/");
        prop.loadCustomProperties("config/imzapp/");
        siteId = Integer.parseInt(prop.getProperty("cs.imzapp.storeId"));
        connexusAppUtils = new ConnexusAppUtils();
        am = AutomationManager.getInstance();
        connexusAPIManager = new ConnexusAPIManager();
        imzTestScripts = new ImzTestScripts();
        bookAppointment = new BookAppointmentWrapper();
        cosmosContext = CosmosWrapper.getCosmosContext();
    }
    public void createASUIOrderToConnexus(Map<String, String> appointmentInfo, boolean isNewPatient, boolean isPQCFRequired) {
        Reporter.log("Executing in store:" + siteId);
        if (isNewPatient) {
            patientId = "90111" + random.nextInt(9999);
            connexusAppUtils.addRandomNamesInFile();
            name = connexusAppUtils.readPatientNameFromFile();
            Reporter.log("Patient Name:" + name[0] + ',' + name[1]);
        }
        else {
            patientId = PFSConstants.PATIENT_ID;
            String fullName = PFSConstants.LAST_NAME + " " + PFSConstants.FIRST_NAME;
            name = fullName.split(" ");
            Reporter.log("Existing Patient Name:" + name[0] + ',' + name[1]);
        }
        startDate = connexusAppUtils.getCurrentDate("yyyy-MM-dd");
        endDate = startDate;
        fulfillmentType = PFSConstants.ASUI_FULFILLEMENT_TYPE;
        reservationType = PFSConstants.ASUI_RESERVATION_TYPE;
        Map<String, String> availableSlotDetails = SlotsWrapper.getSlotAndAccessPoint(startDate, endDate, String.valueOf(siteId), fulfillmentType, reservationType);
        accessPointId = availableSlotDetails.get("ACCESS_POINT_ID");
        accountId = prop.getProperty("cs.PharmaIMZ.customerAccountId");
        orderId = "123" + random.nextInt(99999);
        slotId = availableSlotDetails.get("SLOT_ID");
        slotTime = availableSlotDetails.get("START_TIME");
        asuiSlotDate = availableSlotDetails.get("SLOT_DATE");
        reservationId = SoftWrapper.getReservationId(accessPointId, slotId, fulfillmentType, reservationType, name[1], name[0], accountId, orderId);
        reservationId = ConfrimRequestWrapper.getReservationId(fulfillmentType, reservationType, name[1], name[0], accountId, orderId, reservationId);
        if (isNewPatient) {
            patientId = "90111" + random.nextInt(9999);
            centralPatientId = patientId;
        } else {
            patientId = PFSConstants.PATIENT_ID;
            Reporter.log("Existing Patient Id:" + patientId);
            centralPatientId = null;
        }
        if(isPQCFRequired){
            resp = bookRequest(appointmentInfo, name[1], name[0], patientId, String.valueOf(siteId), appointmentId, reservationId);
            appointmentId = bookAppointment.getAppointmentId();
            Reporter.log("ASUI Appointment ID:" + appointmentId);
            slotDate = connexusAppUtils.getCurrentDate("MMddyyyy");
            pharmaIMZappointmentId = ASUIPharmaIMZOrderWrapper.getAppointmentId(appointmentId, appointmentInfo, siteId, slotDate, slotTime, reservationId, accessPointId, questionsWithAllFalse(), name[1], name[0]);
            Reporter.log("PharmaIMZ Appointment ID:" + pharmaIMZappointmentId);
        }
        else {
            resp = bookRequest(appointmentInfo, name[1], name[0], null, String.valueOf(siteId), appointmentId, reservationId);
            appointmentId = bookAppointment.getAppointmentId();
            Reporter.log("ASUI Appointment ID:" + appointmentId);
            CosmosResponseObject dbResponse = cosmosContext.executeQuery("storeDetails", "SELECT * from c WHERE c.appointmentId=\"" + appointmentId + "\"", CosmosResponseObject.class);
            patientId=dbResponse.getPatientId();
            centralPatientId=dbResponse.getCentralPatientId();
        }
        appointmentInfo.put("appointmentId", pharmaIMZappointmentId);
        appointmentInfo.put("reservationId", reservationId);
        appointmentInfo.put("appointmentDate", getRandomDate(true));
        appointmentInfo.put("patientId", patientId);
        appointmentInfo.put("centralPatientId", centralPatientId);
        appointmentInfo.put("fName", name[1]);
        appointmentInfo.put("lName", name[0]);
        CosmosWrapper.validateWithASUIAppointmentIdPharmaIMZ(cosmosContext, Integer.parseInt(String.valueOf(siteId)), appointmentInfo, appointmentId);
    }
    public void validationOfDataInCosmos(Map<String, String> appointmentInfo,boolean isNewPatient ) {
        if (isNewPatient) {
            patientId = String.valueOf(imzTestScripts.getPatientId());
            Reporter.log("Patient Id:" + patientId);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            Log.info(name[0] + ',' + name[1]);
        } else {
            patientId = PFSConstants.PATIENT_ID;
            Reporter.log("Existing Patient Id:" + patientId);
            String fullName = PFSConstants.LAST_NAME + " " + PFSConstants.FIRST_NAME;
            name = fullName.split(" ");
            Log.info(name[0] + ',' + name[1]);
        }
        appointmentInfo.put("appointmentId", appointmentId);
        appointmentInfo.put("reservationId", reservationId);
        appointmentInfo.put("appointmentDate", getRandomDate(true));
        appointmentInfo.put("patientId", patientId);
        appointmentInfo.put("centralPatientId", centralPatientId);
        appointmentInfo.put("fName", name[1]);
        appointmentInfo.put("lName", name[0]);
        CosmosWrapper.validateWithASUIAppointmentIdPharmaIMZAfterAdministration(cosmosContext, Integer.parseInt(String.valueOf(siteId)), appointmentInfo, appointmentId);
    }

}