package clinicalservices.Immunization.testScripts;

import com.aventstack.extentreports.Status;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.ConnexusConstants;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.models.datamodels.connexus.AddressInfo;
import hwqe.baseframework.models.datamodels.connexus.ImzEventModel;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.joda.time.DateTime;
import org.testng.Assert;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class ImzEventTestScript extends ConnexusTestScripts {
    ImzEventModel imzEventModel;
    AddressInfo addressModel;
    String eventName = null;
    String name,imzEventDesc,eventStartDate,eventExpirationDate,dob,raceDropOffValue,ethnicityDropOffValue,raceTextFromPMS,ethnicityTextFromPMS,todaysDate;
    Map<String, String> value = new HashMap<>();
    List<String> ndcList;
    int lotNbr;
    List<String> drugList = Arrays.asList();
    String imzEventName = null;


    public ImzEventTestScript(){
        PropertyReader prop = PropertyReader.getInstance();
        prop.loadCustomProperties("config/connexus/");
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        imzEventModel = new ImzEventModel();
        addressModel = new AddressInfo();
    }

    public void launchImzEventScreen()  {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            imzEventPage.launchImzEventScreen();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("IMZ Event info screen launched");
        } catch (Throwable e) {
            Reporter.log("IMZ Event info screen not launched");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Creates a new IMZ Event based on the provided input data.
     * @param inputData A map containing the input data required to create the IMZ Event.
     * @return The name of the created IMZ Event name.
     */
    public String createNewIMZEvent(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            connexusAppUtils.addRandomNameInFile();
            name = connexusAppUtils.readNameFromFile().toUpperCase();
            imzEventModel.setImzEventName(name);
            imzEventModel.setImzOrganizationName(name);
            imzEventModel.setPhoneNumber(inputData.get("PHONE_NUMBER"));
            addressModel.setAddressLine1(inputData.get("ADDRESS"));
            addressModel.setCity(inputData.get("CITY"));
            addressModel.setState(inputData.get("STATE"));
            addressModel.setZipCode(inputData.get("ZIP_CODE"));
            addressModel.setCountry(inputData.get("COUNTRY"));
            imzEventModel.setAddress(addressModel);

            //Validate if it's a single-drug or multi-drug scenario
            if (inputData.containsKey("DRUG_NAME2") && inputData.get("DRUG_NAME2") != null && !inputData.get("DRUG_NAME2").trim().isEmpty()) {
                // Multi-drug scenario
                drugList = Arrays.asList(inputData.get("DRUG_NAME1"), inputData.get("DRUG_NAME2"));
                ndcList = Arrays.asList(inputData.get("ndcNbr1"), inputData.get("ndcNbr2"), inputData.get("ndcNbr3"), inputData.get("ndcNbr4"));
            } else {
                // Single-drug scenario
                drugList =Arrays.asList(inputData.get("DRUG_NAME1"));
                ndcList = Arrays.asList(inputData.get("ndcNbr1"), inputData.get("ndcNbr2"));
            }
            lotNbr = ThreadLocalRandom.current().nextInt(10, 100);

            // Create IMZ event name
            imzEventModel = automationManager.getConnexusWorkFlow().createNewIMZEvent(
                    imzEventModel, drugList, String.valueOf(lotNbr), inputData.get("expireDate"), ndcList, inputData.get("PRESCRIBER_RPH"),
                    inputData.get("PRESCRIBER_SO"), inputData.get("groupName"), inputData.get("invalidNdc"));

            imzEventName = imzEventModel.getImzEventName();
            Reporter.log("IMZ Event has been created and its event name: " + imzEventName);
        } catch (Throwable e) {
            Reporter.log("IMZ Event has not been created." +e.getMessage());
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
        return imzEventName;
    }

    public void launchIMZEventSearch() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            imzEventPage.launchSearchImzEventScreen();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            Reporter.log("IMZ Event search screen not launched.");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    public void validatePhmEventDetails() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            //perform search
            eventName = imzEventPage.getImzEventName(imzEventName,0);
            //Fetch DB values
            value = connexusAppUtils.getImzEventDetails(eventName);
            imzEventDesc = value.get("imzEventDesc");
            eventStartDate = value.get("eventStartDate");
            eventExpirationDate = value.get("eventExpirationDate");

            //Validate UI and DB values
            String eventName = imzEventPage.getIMZEventNameValue(0);
            Assert.assertEquals(eventName, imzEventDesc, "Event Description is not matched");
            Reporter.log("Validated event description name is matched from UI: " +eventName+ " and DB: " +imzEventDesc);

            String eventDateFromUI = imzEventPage.getEventDateValue(0);
            String convertEventDateFromUI = ConnexusAppUtils.convertDateFormat("MM/dd/yyyy", "yyyy-MM-dd", eventDateFromUI);
            Assert.assertEquals(convertEventDateFromUI, eventStartDate, "Event Start Date is not matched");
            Reporter.log("Validated event start date is matched from UI: " +convertEventDateFromUI+ " and DB: " +eventStartDate);

            String eventExpireDate = imzEventPage.getEventExpireDateValue(0);
            String convertEventExpireDateFromUI = ConnexusAppUtils.convertDateFormat("MM/dd/yyyy", "yyyy-MM-dd", eventExpireDate);
            Assert.assertEquals(convertEventExpireDateFromUI, eventExpirationDate, "Event Expiration Date is not matched");
            Reporter.log("Validated event expiration date is matched from UI : " +convertEventExpireDateFromUI+ " and DB: " +eventExpirationDate);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());

            //close search page
            imzEventPage.closeSearch();
        } catch (Throwable e) {
            Reporter.log("IMZ Event search screen not launched or details are not matched.");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    public void performImzEventDropOff(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            dropRxModel.setPatientLastName(name[0]);
            dropRxModel.setPatientFirstName(name[1]);
            dob = inputData.get("DOB");
            raceDropOffValue = inputData.get("raceValue");
            ethnicityDropOffValue = inputData.get("ethnicityValue");

            // Retrieve the imzEventName from createNewIMZEvent method
            todaysDate = new SimpleDateFormat("M/d/yyyy").format(new Date()) + " 12:00:00 AM";
            String imzEvent = todaysDate + " " + imzEventName;
            // Perform the drop off workflow
            automationManager.getConnexusWorkFlow().performImzEventDropOff(dropRxModel,dob,imzEvent,raceDropOffValue,ethnicityDropOffValue,inputData.get("imzEventDrug"));
        } catch (Throwable e) {
            Reporter.log("Test failed at IMZ Event Drop-Off queue");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    public void validateRaceAndEthnicityValuesInPMS(Map<String, String> inputData){
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            Reporter.log("Patient Name" + name[0] + "," + name[1]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.inputPatientDob(inputData.get("DOB"));
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickClinicalServicesTab();
            Reporter.logScreenShot(Status.PASS, "openClinicalServicesTabInPMS", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("clicked on clinical services Tab");

            //verify race and Ethnicity values from PMS
            Reporter.log("Verifying race and ethnicity from PMS");
            raceTextFromPMS = patientMaintenancePage.getRace();
            Assert.assertEquals(raceDropOffValue, raceTextFromPMS, "race did not match");
            Reporter.log("Validated race value is matched from drop off: " +raceDropOffValue+ " and PMS: " +raceTextFromPMS);

            ethnicityTextFromPMS = patientMaintenancePage.getEthinicty();
            Assert.assertEquals(ethnicityDropOffValue, ethnicityTextFromPMS, "ethnicity did not match");
            Reporter.log("Validated ethnicity value is matched from drop off: " +ethnicityDropOffValue+ " and PMS: " +ethnicityTextFromPMS);

            //closes clinical services page
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        }catch (Throwable e) {
            Reporter.log("Test failed at DropOff queue");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    @Override
    public void performChkDUR() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue())) {
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            } else if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                performResolveQueue(rxNbr);
                automationManager.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            } else if (checkOrderQueueDB(rxNbr, WorkQueueSettings.POS.getValue())) {
                Reporter.log("order is in POS queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    @Override
    public void verifyRxInEOD() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue())) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.IMZReporting.getValue())) {
                Reporter.log("Rx is in IMZREP queue");
            }
            String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.EOD.getValue())) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                Assert.assertEquals(rxStatus, "eod", "order is not in eod queue");
                Reporter.log("Rx is in EOD");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                orderSearch.closeSearch();
            }
        } catch (Throwable e) {
            Reporter.log("RX not in EOD queue");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

}
