package clinicalservices.Immunization.testScripts;


import clinicalservices.IMZSchedulingPlatformServices.wrappers.CosmosWrapper;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.PFSConstants;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.UpdatePatient.Wrapper.UpdatePatientWrapper;
import com.aventstack.extentreports.Status;
import connexus.PMP.testScripts.PMPTestDataGenerationTestScripts;
import fom.NewERXorderTest;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.*;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.CosmosContext;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.assignOrder.request.OrderInfo;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.getAuthorizedIMZDrugsResponse.GetAuthorizedIMZDrugs;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.getImzInfoResponse.Patient;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.*;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.imzapp.constants.ProblemTypes;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.imzapp.constants.Service_Type_Code;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.pharmaIMZApp.wrappers.PharmaIMZSchedulingWrapper;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.pharmaIMZApp.wrappers.*;
import hwqe.baseframework.models.pageobjectmodels.clinicalservices.pharmaIMZApp.wrappers.SoftLockWrapper;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import io.strati.libs.forklift.org.apache.commons.io.FileUtils;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;

import rxpd.RXPDE2E.Utils.Poller;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.GetAuthorizedIMZDrugsWrapper.getAuthorizedIMZDrugs;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.wrappers.GetImzInfoWrapper.*;

import hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.getImzInfoResponse.GetImzInfo;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.pharmaIMZApp.wrappers.PharmaIMZSchedulingWrapper.*;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.imzapp.constants.Consts.*;
import static hwqe.baseframework.models.pageobjectmodels.clinicalservices.imzapp.constants.Consts.WORK_STATION_HOST_NAME;

public class ImzTestScripts extends ConnexusTestScripts {
    HashMap<String, String> headers = new HashMap<>();
    String rxNbr, changedDrug, rxStatus, currentrxNbr, title;
    ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    WrapperUtils wrapperUtils = new WrapperUtils();
    ServiceResponse resp;
    ServiceRequest req = new ServiceRequest();
    InputResponse inputResponse = new InputResponse();
    int siteId, orderId, orderSeqNbr, patientId, rxFillId, serviceId, itemMdsFamId, prescriberId;
    Long productMdsFamId;
    Boolean IsDisplayed,IsVisible,IsNDCPresent,IsTodayDateAvailable;
    String vaccineName, accessPointId, slotId, slotTime, slotDate, reservationId, appointmentId, txtUser, drugName, rxNbrFromRxNotes, txtNote, race, ethnicity, drug, ndc;
    DataRow drugInfo;
    String[] name;
    public static PropertyReader prop = PropertyReader.getInstance();
    CosmosContext cosmosContext = CosmosWrapper.getCosmosContext();
    PatientProfileModel patient = new PatientProfileModel();
    AddressModel addressModel = new AddressModel();
    ContactModel contactModel = new ContactModel();
    PatientMedicalConditionModel patientMedicalConditionModel = new PatientMedicalConditionModel();
    ThirdPartyModel thirdPartyModel = new ThirdPartyModel();
    ConsolidatedNotesPage consolidatedNotesPage;
    UpdatePatientWrapper updateapiWrapper= new UpdatePatientWrapper();
    String firstName,lastName,orderNDC,currentDate;
    String inputDob;
    Boolean status;
    List<Integer> orderSeqNbrList = new ArrayList<>();
    List<Integer> rxFillIdList = new ArrayList<>();
    List<Integer> serviceIdList = new ArrayList<>();
    List<Integer> itemMdsFamIdList = new ArrayList<>();
    List<String> vaccineNameList = new ArrayList<>();
    List<OrderInfo> orderInfoList = new ArrayList<>();
    List<Long> productMdsFamIdList = new ArrayList<>();
    GetImzInfo getImzInfo;
    List<Integer> rxFillIdList2 = new ArrayList<>();
    CycleCountReportPage cycleCountReportPage;
    MenuBar menuBar;
    ConnexusTestScripts connexusTestScripts;
    String inputPickupDate, inputRxExpDate;
    int requestTypeCode, priorityId, dispenseType;
    PrescriberSearchPage prescriberSearchPage;
    List<String> getPrescriberLicenseTbl;
    List<Integer> multiRxNbr = new ArrayList<>();
    List<String> statusAndProblem = new ArrayList<>();
    ClinicalIntelligenceTestScripts clinIntelTestScript = new ClinicalIntelligenceTestScripts(LoginAs.userType.PHARMACIST_ADFlagOff);

    public ImzTestScripts() {
        prop.loadCustomProperties("config/connexus/");
        prop.loadCustomProperties("config/connexustestharness/");
        prop.loadCustomProperties("config/fom/");
        prop.loadCustomProperties("config/imzapp/");
        siteId = Integer.parseInt(prop.getProperty("cs.imzapp.storeId"));
        connexusAppUtils = new ConnexusAppUtils();
    }

    public void createDotcomOrderToConnexus(Map<String, String> appointmentInfo) {
        Reporter.log("Executing in store:" + siteId);
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        Log.info(name[0] + ',' + name[1]);
        String imzType = appointmentInfo.get("serviceType");
        String questiontype = appointmentInfo.get("QUESTION_TYPE");
        Map<String, String> availableSlotDetailsAndAccessPoint = PharmaIMZSlotsWrapper.getSlotDetailsAndAccessPoint(name[1], name[0], imzType, siteId);
        accessPointId = availableSlotDetailsAndAccessPoint.get("ACCESS_POINT_ID");
        slotId = availableSlotDetailsAndAccessPoint.get("SLOT_ID");
        slotTime = availableSlotDetailsAndAccessPoint.get("START_TIME");
        slotDate = availableSlotDetailsAndAccessPoint.get("SLOT_DATE");
        reservationId = SoftLockWrapper.getReservationId(name[1], name[0], slotId, siteId, accessPointId);
        if (questiontype != null && !questiontype.isEmpty() && "Allergy".equals(questiontype)) {
            appointmentId = PharmaIMZSchedulingWrapper.getAppointmentId(appointmentInfo, siteId, slotDate, slotTime, reservationId, accessPointId, questionsWithAllergyTrue(), name[1], name[0]);
        } else if (questiontype != null && !questiontype.isEmpty() && "Medication".equals(questiontype)) {
            appointmentId = PharmaIMZSchedulingWrapper.getAppointmentId(appointmentInfo, siteId, slotDate, slotTime, reservationId, accessPointId, questionsWithChronicTrue(), name[1], name[0]);
        } else {
            appointmentId = PharmaIMZSchedulingWrapper.getAppointmentId(appointmentInfo, siteId, slotDate, slotTime, reservationId, accessPointId, questionsWithAllFalse(), name[1], name[0]);
        }
        String date = dateTimeConversion(slotDate, slotTime);
        appointmentInfo.put("appointmentId", appointmentId);
        appointmentInfo.put("reservationId", reservationId);
        appointmentInfo.put("appointmentDate", date);
        appointmentInfo.put("fName", name[1]);
        appointmentInfo.put("lName", name[0]);

        CosmosWrapper.validateWithDotcomAppointmentIdPharmaIMZ(cosmosContext, Integer.parseInt(String.valueOf(siteId)), appointmentInfo, appointmentId);

    }

    public void checkAndPerformCheckDUR(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            Log.info("WorkQueue:" + statusAndProblem.get(0));
            Log.info("problem:" + statusAndProblem.get(1));
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Future Date")) {
                Reporter.log("Patient is in Resolve Queue with Waiting for Filling-Future Date");
                am.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Manual Resolution")) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(name[0] + "," + name[1]);
                patientSearchPage.openFirstPatientRecord();
                if (resolutionPage.manualResolutionVerification().contains("REASON: DUE TO RPH PRESCRIPTIVE AUTHORITY REQUIREMENTS, THIS IMMUNIZATION NEEDS ADDITIONAL ACTION BY A PHARMACIST.")) {
                    am.getConnexusWorkFlow().performRphManualResolutionForAdditionalAction(name[0] + "," + name[1], inputData.get("PRESCRIBER_NAME"));
                    Reporter.log("This IMMUNIZATION needs Additional action by Prescriber is resolved");
                }
            }
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Reject")) {
                am.getConnexusWorkFlow().completeResolution(rxNbr);
                Reporter.log("Invalid Reject Code is resolved");
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(),ConnexusConstants.WAIT_TIMEOUT_20)) {
                am.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(),ConnexusConstants.WAIT_TIMEOUT_40)) {
                am.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }else if (checkOrderQueueDB(rxNbr, WorkQueueSettings.ServiceAdministration.getValue())) {
                Reporter.log("order is in service admin ");
            }
        } catch (Throwable e) {
            Reporter.log("patient is not in chkDUR queue");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    @Override
    public void verifyPatientWorkQueueAndProblemStatus() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Manual Resolution")) {
                Reporter.log("Patient is in Resolve Queue");
                am.getConnexusWorkFlow().performRphManualResolution(rxNbr);
                Reporter.log("Unauthorised drug problem is resolved");
            }
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            Reporter.log("WorkQueue:" + statusAndProblem.get(0));
            Reporter.log("Problem:" + statusAndProblem.get(1));
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && "Patient Name Mismatch".equalsIgnoreCase(statusAndProblem.get(1))) {
                patientSearchPage.openFirstPatientRecord();
                Reporter.log("Problem is patient Name Mismatch so Resolution Page is launched to create patient");
            }
        } catch (Throwable e) {
            Reporter.log("Patient is not resolve queue or problem message did not match");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performPatientSearchAndPatientCreation(Map<String, String> appointmentInfo) {
        //perform search from resolution page and create Patient
        ResolutionPage resolutionPage = new ResolutionPage();
        resolutionPage.clickPatientSearch();
        createNewPatient(appointmentInfo);
        resolutionPage.selectPriority(String.valueOf(Priority.Today));
        //verifyDetailsFromCentralPatientLookup();
        resolutionPage.clickUsePatientButton();
    }

    @Override
    public void createNewPatient(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);

            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            Log.info("" + name[1] + "," + name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            patient.setPatientTp(thirdPartyModel);
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);
            if (connexusStartPage.isConnexusLaunched()) {
                am.getConnexusWorkFlow().createNewPatientFromResolutionPage(false, patient);
                Reporter.log("Patient has been created.");
            } else {
                logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
                Assert.fail("Connexus not launched");
            }

        } catch (Throwable e) {
            Reporter.log("Failed while creating the patient");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyWorkQueueStatusAsServiceAdmin() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.ServiceAdministration.getValue(), ConnexusConstants.WAIT_TIMEOUT_40)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                String rxStatus = orderSearch.getWorkQueue(0);
                Reporter.log("WorkQueue status: " + rxStatus);
                Assert.assertEquals(rxStatus.toLowerCase(), WorkQueue.SVC_ADMIN.getWorkQueue(), "order is not in service admin queue");
                logScreenshotSafely(Status.PASS, "verifyWorkQueueStatusAsSvcAdmin", connexusStartPage.takeScreenShot(currentStepMethodName));
                orderSearch.closeSearch();
            }
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("order is not in service admin queue" + e.getMessage());
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Assert.fail(e.toString());
        }
    }

    @Override
    public void performPOS() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.POS.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().completeOfflineSale(String.valueOf(rxNbr));
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.EOD.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                Reporter.log("order is in EOD work queue");
            } else {
                Reporter.log("order is not in EOD work queue");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at POS queue" +e.getMessage());
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyServiceDetailsInPMS(Map<String, String> appointmentInfo) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        prescriberId = getprescriberId(appointmentInfo);
        try {
            String todaysDate = getCurrentDate("MM/dd/yyyy");
            String rxStatus = orderSearch.getWorkQueue(0);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            Reporter.log("Patient Name" + name[0] + "," + name[1]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            Reporter.log("DOB" + patient.getPatientDob());
            patientSearchPage.inputPatientDob(patient.getPatientDob());
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickClinicalServicesTab();
            logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Reporter.log("clicked on clinical services");

            //verify race and Ethnicity
            Reporter.log("Verifying race and ethicity from PMS");
            String raceFromPMS = patientMaintenancePage.getRace();
            Assert.assertEquals(raceFromPMS, race, "race did not match");
            String ethnicityFromPMS = patientMaintenancePage.getEthinicty();
            Assert.assertEquals(ethnicityFromPMS, ethnicity, "ethicity did not match");
            Reporter.log("Verified race and enthnicity on PMS with expected values passed while creation of order");

            //verify rxFillID,Status and click serviceDetails Button
            patientMaintenancePage.selectActiveRxFillIdRow(rxFillId);
            Assert.assertTrue(patientMaintenancePage.isServiceDetailsEnabled());
            patientMaintenancePage.clickServiceDetails();
            Reporter.log("Assert: Validation of RxfillId details is completed");
            logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));

            //verify lot Numbers
            Assert.assertEquals(patientMaintenancePage.getLotNo(), appointmentInfo.get("lotNbr"), "lot numbers are different");
            Reporter.log("Assert: validation of Actual lot numbers with expected is completed");
            //verify Administrated BY
            String expectedPrescriberName = appointmentInfo.get("PRESCRIBER_NAME");
            String administerName = patientMaintenancePage.getAdministratorValue().trim();
            boolean isPrescriberNameValid = administerName.contains(expectedPrescriberName);
            Assert.assertTrue(isPrescriberNameValid,
                    String.format("Prescriber name validation failed. Expected: '%s' to be contained in Administrator name: '%s'",
                            expectedPrescriberName, administerName));
            Reporter.log("Assert: Validation of Administrated by completed with given value is matched");
            //verify IMZRegistryNotify
            if (rxStatus.equalsIgnoreCase(WorkQueue.EOD.getWorkQueue())) {

                String imzRegistryDateTime = patientMaintenancePage.getImzAdministry();
                String imzReg[] = imzRegistryDateTime.split(" ");
                Assert.assertEquals(imzReg[0].trim(), todaysDate.trim(), "Notify date is not matched");
                logScreenshotSafely(Status.PASS, "currentStepMethodName", connexusStartPage.takeScreenShot(currentStepMethodName));
                Reporter.log("Assert: Validation of IMZRegistryNotify Date is completed");
            }
            //verify VIS PublishDate
            String visPubDate = getVisPubFromDB();
            Log.info("visPubdate" + visPubDate);
            if (visPubDate == null) {
                visPubDate = todaysDate.trim();
                Assert.assertEquals(visPubDate, patientMaintenancePage.getVISPublishDate().trim(), "VIS Publish Date did not Matched");
                Reporter.log("Assert: Validation of VIS PublishDate from PMS is completed");
            } else {
                visPubDate = dateConversion(visPubDate);
                Assert.assertEquals(visPubDate, patientMaintenancePage.getVISPublishDate().trim(), "VIS Publish Date did not Matched");
                Reporter.log("Assert: Validation of VIS PublishDate from PMS is completed");
            }
            //verify VIS GivenDate
            Assert.assertNotNull(patientMaintenancePage.getVISGivenDate(), "VIS Given Date is  null");
            Assert.assertEquals(todaysDate, patientMaintenancePage.getVISGivenDate().trim(), "VIS GIVEN Date is Matched");
            Reporter.log("Assert: Validation of VIS GivenDate from PMS is completed");

            //Clikcing IMZForm and check for IMZForm
            patientMaintenancePage.clickImzForm();
            Boolean pqcfImg = patientMaintenancePage.verifyPvImage();
            Assert.assertTrue(pqcfImg, "PQCF Image doesnot exist");
            logScreenshotSafely(Status.PASS, "ServiceAdministration", connexusStartPage.takeScreenShot(currentStepMethodName));

            //closes IMZ form
            patientMaintenancePage.clickExit();

            //closes services administration page
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();

            //closes clinical services page
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            Reporter.log("Test failed at PatientMaintainance page");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performImZAdministration(Map<String, String> appointmentInfo) {
        prescriberId = getprescriberId(appointmentInfo);
        boolean isGuardian = false;
        String relationCode = appointmentInfo.get("GUARDIAN_RELATION_CODE");
        GetImzInfo getImzInfo = getImzInfo(siteId);
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String firstName = name[0];
        String lastName = name[1];
        String expirationDate = appointmentInfo.get("expirationDate");
        int patientList = getImzInfo.getSvcOrderDetails().size();
        Log.info("patientList from getImZInfo:" + patientList);
        for (int i = 0; i < patientList; i++) {
            if (getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getLastName()
                    .equalsIgnoreCase(name[0])) {
                orderId = getImzInfo.getSvcOrderDetails().get(i).getOrderId();
                orderSeqNbr = getImzInfo.getSvcOrderDetails().get(i).getOrderSeqNbr();
                patientId = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getPatientId();
                rxFillId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillId();
                serviceId = getImzInfo.getSvcOrderDetails().get(i).getService().getServiceId();
                itemMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getItemMdsFamId();
                productMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getProductMdsFamId();
                vaccineName = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getShortName();
                race = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getRaceType();
                ethnicity = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getEthnicityType();

                Reporter.log("orderId:" + orderId + "patientId:" + patientId + "rxFillId:" + rxFillId + "serviceId:" + serviceId + "itemMdsFamId:" + itemMdsFamId + "productItemMdsFamId:" + productMdsFamId + "vaccineName:" + vaccineName + "race:" + race + "ethnicity:" + ethnicity);
            }
        }

        List<OrderInfo> orderInfoList = new ArrayList<>();
        orderInfoList.add(new OrderInfo(orderId, orderSeqNbr));

        // Assigning the order
        AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);

        //get onlinequestionnarie form
        OnlineQuestionnarieFormWrapper.getOnlineQuestionnarieForm(siteId, String.valueOf(serviceId));

        //save Questionnarie form
        OnlineQuestionnarieFormWrapper.saveOnlineQuestionnarieForm(siteId, questionsWithAllFalse(), String.valueOf(serviceId), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, prescriberId, isGuardian);

        //saves Product information
        SaveProductInformationWrapper.saveProductInformation(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId);

        //isGaurdianSignInConsentForm
        IsGaurdianSignInConsentWrapper.getGaudrianSigninResponseDetails(siteId, String.valueOf(serviceId));

        //completes order
        // relation code 318 is for Guardian as self with patient name for tc-HWPHME2E_2521
        // relation code 321 is for patient with Guardian details for tc-HWPHME2E_3113
        if (relationCode != null && !relationCode.isEmpty() && "318".equals(relationCode)) {
            CompleteOrderWrapper.completeOrderForGuardian(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId, vaccineName, serviceId, patientId, prescriberId, firstName, lastName, Integer.parseInt(appointmentInfo.get("GUARDIAN_RELATION_CODE")));
        } else if (relationCode != null && !relationCode.isEmpty() && "321".equals(relationCode)) {
            CompleteOrderWrapper.completeOrderForGuardian(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId, vaccineName, serviceId, patientId, prescriberId, appointmentInfo.get("GUARDIAN_FNAME"), appointmentInfo.get("GUARDIAN_LNAME"), Integer.parseInt(appointmentInfo.get("GUARDIAN_RELATION_CODE")));
        } else {
            CompleteOrderWrapper.completeOrder(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId, vaccineName, serviceId, patientId, prescriberId);
        }

        Reporter.log("Completed IMZ Administration for dotcom order through APIs");
    }

    @Override
    public int getPatientId() {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        //its taking time to get data from DB
        String query = "select patient_id from patient where first_name= " + "'" + name[1].toUpperCase() + "'" + " and last_name = " + "'" + name[0].toUpperCase() + "';";
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1, "PatientId is not reflecting in informix DB with required patient firstname and lastname");
        DataRow row = dt.getDataRows().get(0);
        int patientId = row.getValue("patient_id");
        return patientId;
    }

    public int getRxNbrFromPatientId(int patientID) {
        String query = "select rx_nbr from rx where patient_id= " + "'" + patientID + "';";
        Log.info(query);
        int rxNbr = am.getConnexusDB(siteId).getScalar
                (query, Integer.class);
        Log.info("rxNbr from patientId:" + rxNbr);
        return rxNbr;
    }

    public int getPrescriberIdFromName(String prescriberName, int presId) {
        String names[] = prescriberName.split(",");
        String firstName[] = names[1].split(" ");
        String query = "select prescriber_id from prescriber where first_name= " + "'" + firstName[1].toUpperCase().trim() + "'" + " and last_name = " + "'" + names[0].toUpperCase().trim() + "' and prescriber_id=" + presId + ";";
        Log.info(query);
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1, "Prescriber details not found in informix DB");
        DataRow row = dt.getDataRows().get(0);
        int prescriberId = row.getValue("prescriber_id");
        Reporter.log("PrescriberId from Name:" + prescriberId);
        return prescriberId;
    }

    public String getCurrentDate(String pattern) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        Log.info(simpleDateFormat.format(new Date()));
        return simpleDateFormat.format(new Date());
    }

    public String dateTimeConversion(String date, String time) {
// Parse the date
        String month = date.substring(0, 2);
        String day = date.substring(2, 4);
        String year = date.substring(4, 8);
// Create a LocalDateTime object
        LocalDateTime dateTime = LocalDateTime.parse(year + "-" + month + "-" + day + "T" + time + ":00", DateTimeFormatter.ISO_LOCAL_DATE_TIME);
// Format to ISO 8601 format
        String formattedDateTime = dateTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
// Output the result
        Log.info(formattedDateTime);
        return formattedDateTime;
    }

    public void validationOfDataInCosmos(Map<String, String> appointmentInfo) {

        String[] name = connexusAppUtils.readPatientNameFromFile();
        Log.info(name[0] + ',' + name[1]);
        String date = dateTimeConversion(slotDate, slotTime);
        appointmentInfo.put("appointmentId", appointmentId);
        appointmentInfo.put("reservationId", reservationId);
        appointmentInfo.put("appointmentDate", date);
        appointmentInfo.put("fName", name[1]);
        appointmentInfo.put("lName", name[0]);
        appointmentInfo.put("patientId", String.valueOf(patientId));

        CosmosWrapper.validateWithDotcomAppointmentIdPharmaIMZAfterAdministration(cosmosContext, Integer.parseInt(String.valueOf(siteId)), appointmentInfo, appointmentId);

    }

    @Override
    public void performPatientSearchAndPatientCreationWithTP(Map<String, String> appointmentInfo) {
        //perform search from resolution page and create Patient With TP
        ResolutionPage resolutionPage = new ResolutionPage();
        resolutionPage.clickPatientSearch();
        createNewPatientWithTP(appointmentInfo);
        resolutionPage.selectPriority(String.valueOf(Priority.Today));
        //verifyDetailsFromCentralPatientLookup();
        resolutionPage.clickUsePatientButton();
    }

    @Override
    public void createNewPatientWithTP(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);

            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            Log.info("" + name[1] + "," + name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            thirdPartyModel.setCarrierBin(inputData.get("TP_CARRIER_BIN"));
            thirdPartyModel.setPlan(inputData.get("TP_PLAN"));
            thirdPartyModel.setCardId(inputData.get("TP_CARD_ID"));
            patient.setPatientTp(thirdPartyModel);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            if (patientMaintenancePage.isOkDisplayed()) {
                patientMaintenancePage.clickOk();
            }
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);

            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);

            am.getConnexusWorkFlow().createNewPatientFromResolutionPage(true, patient);

            Reporter.log("Patient has been created.");

        } catch (Throwable e) {
            Reporter.log("Test failed while creating patient");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyDetailsFromCentralPatientLookup() {
        int patientID = getPatientId();
        Map<String, Object> centralPatientLookup;
        String query = "select status_code,last_change_user_id from pharmacy_message:central_patient_lookup\n" +
                "where  patient_id= " + "'" + patientID + "'" + " and txn_type_code=1209\n" +
                "order by request_ts desc;";
        Reporter.log(query);
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1, "patient ID not reflecting in pharmacy_message:central_patient_lookup");
        DataRow row = dt.getDataRows().get(0);
        int last_change_user_id = (short) row.getValue("last_change_user_id");
        Reporter.log("verifying patient is AutoSynced in central patient lookup Table");
        Reporter.log("Required " + patientID + " is reflected in patient lookup table with " + last_change_user_id);
    }

    public void flushCache() {
        connexusAPIManager.flushCache(String.valueOf(siteId));
    }

    public void callFlushCacheAPI(String siteID) {
        String serviceEndPointURL = StoreIDManager.createEndPointURL(siteID, prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexustestharness.flushCacheEndPoint"));
        req.setUrl(serviceEndPointURL);
        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        resp = am.getRestContext().performPost(req);
        Assert.assertEquals(resp.getStatusCode(), 200, "Flush Cache Not Successful");
        Log.info("Flush Cache Successful");
    }

    public boolean updateStateValue(String stateValue) {
        String updateQuery = "update bus_unit_addr set state =\"" + stateValue + "\" where bu_nbr=\"" + siteId + "\"";
        try {
            String resultSet = Integer.toString(am.getConnexusDB().executeUpdateQuery(updateQuery));
            if (resultSet != null) {
                Reporter.log("Updated State to:" + stateValue);
                return true;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return false;
    }


    public void verifyRxAdminNotesForServiceDetailsInPMS(Map<String, String> appointmentInfo) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            if (patientSearchPage.isPatientSearchWindowDisplayed()) {
                Reporter.log("Patient Name" + name[0] + "," + name[1]);
                patientSearchPage.inputPatientName(name[0] + "," + name[1]);
                Reporter.log("DOB" + patient.getPatientDob());
                patientSearchPage.inputPatientDob(patient.getPatientDob());
                patientSearchPage.clickSearchNow();
                patientSearchPage.openFirstPatientRecord();
                am.performSleep(3);
                logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
                patientMaintenancePage.clickClinicalServicesTab();
                logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
                //verify rxFillID,Status and click serviceDetails Button
                patientMaintenancePage.selectActiveRxFillIdRow(rxFillId);
                Assert.assertTrue(patientMaintenancePage.isServiceDetailsEnabled());
                patientMaintenancePage.clickNotesButton();
                am.performSleep(2);
                logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
                Reporter.log("Validating required details in Rx Admin Notes from PMS for service details");
                Log.info("searched test required");
                txtUser = consolidatedNotesPage.getTxtUser().trim();
                Reporter.log("logged in User: " + txtUser);
                Assert.assertEquals(txtUser, ASSIGNED_USER_ID_AUT_TEST, "Logged User Info is not reflecting in RXNotes");
                Reporter.log("Assert: Logged user name is validated from rx Admin Notes");

                drugName = consolidatedNotesPage.getDrugName().trim();
                Reporter.log("Drug Name From Rx Admin Notes: " + drugName);
                Assert.assertEquals(drugName.toUpperCase(), vaccineName.trim().toUpperCase(), "DrugName didnot match");
                Reporter.log("Assert: Drug Name from Rx Admin Notes with Drug Name used in IMZ Administration is matched");
                rxNbrFromRxNotes = consolidatedNotesPage.getRxNbr().trim();
                Reporter.log("RxNbr From Rx Admin Notes: " + rxNbrFromRxNotes);
                Assert.assertEquals(rxNbrFromRxNotes, rxNbr, "rxNbr didnot match");
                Reporter.log("Assert: RxNumber reflected in Rx Admin Notes is validated with required Rx Number");
                txtNote = consolidatedNotesPage.getTxtNote().trim();
                Assert.assertEquals(txtNote, prop.getProperty("api.completeOrder.notes"), "Notes Entered didnot match");
                Reporter.log("Assert:" + txtNote + " reflected in Rx Admin Notes is validated with required NotesTxt");
                consolidatedNotesPage.clickButtonExit();
                patientMaintenancePage.clickSaveAndClose();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at PatientMaintainance page");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public String dateConversion(String dateFormat) {

        String formattedDate = "";
        // Define the input format
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");

        // Define the output format
        SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy");

        try {
            // Parse the date string into a Date object
            Date parsedDate = inputFormat.parse(dateFormat);

            // Format the Date object to the desired output format
            formattedDate = outputFormat.format(parsedDate);

            Log.info("Formatted date: " + formattedDate);
        } catch (Exception e) {
            Log.info("Error: " + e);
        }
        return formattedDate;
    }

    public String getVisPubFromDB() {
        String query = "select vis.vis_publish_date from imz_product ip join\n" +
                "vaccine_info_sheet vis on ip.vis_id = vis.vis_id\n" +
                "where ip.product_mds_fam_id in ( " + "'" + productMdsFamId + "');";
        Reporter.log("To get VISPublish From Db: " + query);
        String visPubDate = am.getConnexusDB(siteId).getScalar(query, String.class);
        Reporter.log("VisPublishDate from DB:" + visPubDate);
        return visPubDate;
    }

    public void validateRxNotes() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            Log.info(name[0] + ',' + name[1]);
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + ',' + name[1], 0);
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(rxNbr);
            rxLookUp.clickSearch();
            am.getConnexusWorkFlow().navigateToRxNotesAndPerformValidation(rxNbr, vaccineName, ASSIGNED_USER_ID_AUT_TEST, prop.getProperty("api.completeOrder.notes"));
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            Reporter.log("Test failed while validating RxNotes");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail("Test failed while validating RxNotes");
        }
    }


    public void createDotcomOrderForFutureToConnexus(Map<String, String> appointmentInfo) {
        Reporter.log("Executing in store:" + siteId);
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        Log.info(name[0] + ',' + name[1]);
        String imzType = appointmentInfo.get("serviceType");
        Map<String, String> availableSlotDetailsAndAccessPoint = PharmaIMZSlotsWrapper.getFutureSlotDetailsAndAccessPoint(name[1], name[0], imzType, siteId);
        accessPointId = availableSlotDetailsAndAccessPoint.get("ACCESS_POINT_ID");
        slotId = availableSlotDetailsAndAccessPoint.get("SLOT_ID");
        slotTime = availableSlotDetailsAndAccessPoint.get("START_TIME");
        slotDate = availableSlotDetailsAndAccessPoint.get("SLOT_DATE");
        reservationId = SoftLockWrapper.getReservationId(name[1], name[0], slotId, siteId, accessPointId);
        appointmentId = PharmaIMZSchedulingWrapper.getAppointmentId(appointmentInfo, siteId, slotDate, slotTime, reservationId, accessPointId, questionsWithAllFalse(), name[1], name[0]);
        String date = dateTimeConversion(slotDate, slotTime);
        appointmentInfo.put("appointmentId", appointmentId);
        appointmentInfo.put("reservationId", reservationId);
        appointmentInfo.put("appointmentDate", date);
        appointmentInfo.put("fName", name[1]);
        appointmentInfo.put("lName", name[0]);

        CosmosWrapper.validateWithDotcomAppointmentIdPharmaIMZ(cosmosContext, Integer.parseInt(String.valueOf(siteId)), appointmentInfo, appointmentId);

    }

    public void verifyFutureDatedOrder() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            String priority = orderSearch.getPriority(0);
            Reporter.log("Validating future order in F6 Search Screen");
            Assert.assertEquals(priority, "Future", "Order is not future dated");
            Reporter.log("Assert: Passed, Future dated order Found");
            logScreenshotSafely(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName));
            orderSearch.closeSearch();
        } catch (Throwable e) {
            Reporter.log("Patient/order is not found in F6 search screen");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }

    }

    public void validateImzRegistryFromPMS(Map<String, String> appointmentInfo) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            if (patientSearchPage.isPatientSearchWindowDisplayed()) {
                Reporter.log("Patient Name" + name[0] + "," + name[1]);
                patientSearchPage.inputPatientName(name[0] + "," + name[1]);
                Reporter.log("DOB" + patient.getPatientDob());
                patientSearchPage.inputPatientDob(patient.getPatientDob());
                patientSearchPage.clickSearchNow();
                patientSearchPage.openFirstPatientRecord();
                patientMaintenancePage.clickTabProfile();
                Boolean status = patientMaintenancePage.imzRegistryReporting();
                Reporter.log("Validating Imz Registry Reporting Value");
                logScreenshotSafely(Status.INFO, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName));
                Assert.assertTrue(status, "Imz registry reporting is not Yes");
                Reporter.log("Validated the IMZ Registry reporting as Yes");
                patientMaintenancePage.clickSaveAndClose();
            } else {
                Reporter.log("Patient maintainance screen not launched");
                logScreenshotSafely(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName));
                Assert.fail("Patient maintainance screen not launched");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed while validating service details in PMS screen");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }


    }

    public void createNewPatientImz(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        Reporter.log("Executing in Store--> " + siteId);
        try {
            connexusAppUtils.addRandomNamesInFile();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patient.setPatientType(PatientProfileModel.PatientType.HUMAN);

            patient.setPatientFirstName(name[1]);
            patient.setPatientLastName(name[0]);
            Log.info("" + name[1] + "," + name[0]);
            patient.setPatientDob(inputData.get("DOB"));
            patient.setPatientGender(PatientProfileModel.PatientGender.MALE);

            addressModel.setPatientAddressLine1(inputData.get("ADDRESS"));
            addressModel.setPatientCity(inputData.get("CITY"));
            addressModel.setPatientState(inputData.get("STATE"));
            addressModel.setPatientZipCode(inputData.get("ZIP_CODE"));
            addressModel.setPatientCountry(inputData.get("COUNTRY"));
            patient.setPatientAddress(addressModel);
            patient.setPatientTp(thirdPartyModel);
            contactModel.setPatientPrimaryNumber(inputData.get("PRIMARY_NUMBER"));
            patient.setPatientContact(contactModel);

            patientMedicalConditionModel.setAllergies(PatientMedicalConditionModel.Allergies.NO);
            patientMedicalConditionModel.setMedicalCondition(PatientMedicalConditionModel.MedicalCondition.NO);
            patient.setPatientMedicalConditionModel(patientMedicalConditionModel);
            if (connexusStartPage.isConnexusLaunched()) {
                am.getConnexusWorkFlow().createNewPatient(false, patient);
                Reporter.log("Patient has been created.");
            } else {
                Reporter.log("Connexus not launched");
                logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
                Assert.fail("Connexus not launched");
            }

        } catch (Throwable e) {
            Reporter.log("Test failed while creating patient");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performERXImz(Map<String, String> inputData, String xmlPath) throws SQLException, ParserConfigurationException, IOException, SAXException {
        NewERXorderTest newERXorderTest = new NewERXorderTest();
        PMPTestDataGenerationTestScripts pmpTestScripts = new PMPTestDataGenerationTestScripts();
        File xmlData;
        String messageId, inputPayload, ndc, drugName;
        int rxResponseId, fillCount, index;
        List<Integer> respIds = new ArrayList<>();
        Random random_method = new Random();
        patientId = getPatientId();
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        //get patient details
        DataRow patientInfo = getPatientInfo(cnx, patientId);
        //get xml file to generate input payload
        xmlData = new File(xmlPath);
        ndc = inputData.get("DRUG_NAME");
        drugName = pmpTestScripts.getDrugName(cnx, inputData.get("DRUG_NAME"));
        Reporter.log("Drug name :" + drugName);
        //update the xml with required storeNbr, Date-time and a unique messageId
        messageId = UUID.randomUUID().toString().substring(0, 35);
        String siteID = String.valueOf(siteId);
        if (siteID.length() == 4) {
            siteID = "0" + siteID;
        }
        inputPayload = updateXML(xmlData, siteID, messageId, patientInfo, ndc, drugName);
        Log.info("inputPayload:" + inputPayload);
        //drop ERX order
        rxResponseId = dropERX(inputPayload, siteID, patientId, messageId, cnx);
        respIds.add(rxResponseId);
    }

    @Override
    public DataRow getPatientInfo(IDatabaseContext cnx, int patientId) {
        String getPatientInfo = "select last_name, first_name, gender_code, birth_date from rx21c:informix.patient \n" +
                "where patient_id = " + patientId + ";";
        DataTable dt = cnx.getDataTable(getPatientInfo);
        Assert.assertEquals(dt.getRowCount(), 1);
        DataRow row = dt.getDataRows().get(0);
        return row;
    }

    public String getDrugName(IDatabaseContext cnx, String ndc) {
        String drugName;
        String getDrugName = "select pp.short_name from pharmacy_offering:pharmacy_product as pp \n" +
                "join pharmacy_offering:pharmacy_item as pi \n" +
                "on pp.product_mds_fam_id = pi.product_mds_fam_id \n" +
                "where pi.ndc_nbr = " + ndc + ";";
        drugName = cnx.getScalar(getDrugName, String.class).trim();
        return drugName;
    }

    @Override
    public String updateXML(File xmlData, String storeNbr, String messageId, DataRow patientInfo, String ndc, String drugName)
            throws ParserConfigurationException, SAXException, IOException {

        String fileContext = FileUtils.readFileToString(xmlData, StandardCharsets.UTF_8);
        fileContext = fileContext.replaceAll("storeNbr", storeNbr);
        fileContext = fileContext.replaceAll("messageId", messageId);
        String currentTime = getCurrentTime();
        fileContext = fileContext.replaceAll("sentTime", currentTime);
        fileContext = fileContext.replaceAll("writtenDate", currentTime);
        fileContext = fileContext.replaceAll("patientLastName", patientInfo.getValue("last_name").toString().trim());
        fileContext = fileContext.replaceAll("patientFirstName", patientInfo.getValue("first_name").toString().trim());
        fileContext = fileContext.replaceAll("patientGender", patientInfo.getValue("gender_code"));
        fileContext = fileContext.replaceAll("patientDOB", patientInfo.getValue("birth_date").toString());
        fileContext = fileContext.replaceAll("drugName", drugName);
        fileContext = fileContext.replaceAll("ndc", ndc);
        return fileContext;
    }

    @Override
    public String getCurrentTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String Ts = sdf.format(timestamp);
        return Ts;
    }

    public int dropERX(String inputPayload, String storeNbr, int patientId, String messageId, IDatabaseContext cnx) throws SQLException {

        //drop ERX via POST
        headers.put("content-type", "application/xml");
        headers.put("User-Agent", "PostmanRuntime/7.28.4");
        headers.put("Accept", "*/*");
        headers.put("Accept-Encoding", "gzip, deflate, br");
        headers.put("Connection", "keep-alive");
        req.setHeaders(headers);
        req.setUrl("https://rxInt-PharmacySSerxv2inboundreq-qa-edc.wal-mart.com/services/ProcessERx");
        req.setRequestPayload(inputPayload);
        resp = am.getRestContext().performPost(req);

        //verify POST request is successful
        Assert.assertEquals(resp.getStatusCode(), 200, "POST request returned error");
        Reporter.log("ERX order posting successful for patientId = " + patientId + " in store # " + storeNbr +
                ". The resp message_id is " + messageId);

        // verify ERX order is created --> response_stat_code = 26005 in raw_eltnc_rx_resp table
        int rxResponseId = 0;
        //rxResponseId = verifyOrderCreation(cnx, messageId);

        return rxResponseId;
    }

    public int verifyOrderCreation(IDatabaseContext cnx, String messageId) throws SQLException {

        String query = "select response_stat_code, rx_response_id from rx21c:informix.raw_eltnc_rx_resp limit 1";
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1);
        DataRow row = dt.getDataRows().get(0);
        int respStatCode = (short) row.getValue("response_stat_code");
        Reporter.log("respStatCode:" + respStatCode);
        Assert.assertEquals(respStatCode, 26005, "ERX order processing failed");
        int rxRespId = row.getValue("rx_response_id");

        return rxRespId;
    }

    public void verifyOrderStatusAfterDroppingERX() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(name[0] + "," + name[1]);
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            Reporter.log("WorkQueue: " + rxStatus);
            if (connexusTestScripts.checkOrderQueueDB(rxNbr, WorkQueueSettings.Input.getValue(), ConnexusConstants.WAIT_TIMEOUT_60)) {
                Reporter.log("Order has been successfully moved to Input Queue");
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(name[0] + "," + name[1]);
                patientSearchPage.openFirstPatientRecord();
                logScreenshotSafely(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName));
                inputPage.exitInputScreen();
                inputPage.clickYes();
            }
        } catch (Throwable e) {
            Reporter.log("Patient/order is not found in F6 search screen");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }

    }

    public void addPrescriberOnProfileTab(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        patientSearchPage.launchPatientSearchScreen();
        try {
            Reporter.log("Patient Name" + name[0] + "," + name[1]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            Reporter.log("DOB" + inputData.get("DOB"));
            patientSearchPage.inputPatientDob(inputData.get("DOB"));
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            Log.info("add prescriber");
            patientMaintenancePage.clickTabProfile();
            Reporter.log("Adding PCP on PMS Profile/Other tab");
            patientMaintenancePage.enterPrescriberName(inputData.get("PRESCRIBER_NAME"));
            patientMaintenancePage.clickProductSearch3Dots();
            logScreenshotSafely(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName));
            Reporter.log("Added PCP on PMS Profile/Other tab");
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            Reporter.log("Test failed at PatientMaintainance page");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public String getStcXmlRequestFromDB() {
        String query = "select mb.xml_message_txt from rx r,informix.phm_mb_message phm,pharmacy_message:mb_message mb where\n" +
                "        r.rx_nbr=" + rxNbr + "\n" +
                "        and r.rx_id = phm.rx_id\n" +
                "        and phm.mb_message_id=mb.mb_message_id\n" +
                "        and mb.message_type_code=1001;";
        Reporter.log(query);
        Log.info(String.valueOf(siteId));
        String xmlRequest = am.getConnexusDB(siteId).getScalar
                (query, String.class);
        Reporter.log("xmlRequest:" + xmlRequest);
        Log.info("xmlRequest:" + xmlRequest);
        return xmlRequest;

    }

    public String getStcXmlResponseFromDB() {
        String query = "select mb.xml_message_txt from rx r,informix.phm_mb_message phm,pharmacy_message:mb_message mb where\n" +
                "        r.rx_nbr=" + rxNbr + "\n" +
                "        and r.rx_id = phm.rx_id\n" +
                "        and phm.mb_message_id=mb.mb_message_id\n" +
                "        and mb.message_type_code=1002;";
        Reporter.log(query);
        Log.info(String.valueOf(siteId));
        String xmlRes = am.getConnexusDB(siteId).getScalar
                (query, String.class);
        Reporter.log("xmlResponse:" + xmlRes);
        Log.info("xmlRes" + xmlRes);
        return xmlRes;

    }

    public void parseXMLResponse(String xml) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        InputSource src = new InputSource();
        src.setCharacterStream(new StringReader(xml));

        Document doc = builder.parse(src);
        if (doc.getElementsByTagName("errorCode").getLength() > 0) {
            String status = doc.getElementsByTagName("status").item(0).getTextContent();
            String errorCode = doc.getElementsByTagName("errorCode").item(0).getTextContent();
            Reporter.log("Status:\t" + status + "errorCode:\t" + errorCode);
            Assert.assertEquals(status, "ok", "status is equal to OK");
            Assert.assertEquals(errorCode, "0", "errorCode is not equal to Zero");
            Reporter.log("status and errorCode from XML Response are validated");
        } else {
            Reporter.log(" STC XML response doesnot contain errorCode TagName and its not the proper STC XMl response");
            Assert.fail();
        }

    }

    public void parseXMLRequest(String xml, Map<String, String> appointmentInfo) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        InputSource src = new InputSource();
        src.setCharacterStream(new StringReader(xml));

        Document doc = builder.parse(src);
        if (doc.getElementsByTagName("patientName").getLength() > 0) {
            //to get patient firstName,LastName,NDC
            String firstName = doc.getElementsByTagName("patientName").item(0).getTextContent();
            String lastName = doc.getElementsByTagName("lastName").item(1).getTextContent();
            String ndcNbr = doc.getElementsByTagName("ndcNbr").item(0).getTextContent();
            Reporter.log("firstNameFromXML:\t" + firstName + "lastNameFromXML:\t" + lastName + "ndcNbrFromXML:\t" + ndcNbr);
            String name[] = connexusAppUtils.readPatientNameFromFile();
            Assert.assertEquals(lastName.toUpperCase().trim(), name[0].toUpperCase().trim(), "patient lastName in STC XML didnot match with patient name we have used");
            Assert.assertEquals(firstName.toUpperCase().trim(), name[1].toUpperCase().trim(), "patient firstName in STC XML didnot match with patient name we have used");
            Assert.assertEquals(ndcNbr.trim(), appointmentInfo.get("NDC_NBR").trim(), "patient firstName in STC XML didnot match with patient name we have used");
            Reporter.log("patient details and drug are validated with expected from STC XML request");
        } else {
            Reporter.log(" STC XML response doesnot contain patient/NDC TagName and its not the proper STC XMl request");
            Assert.fail();
        }


    }

    public void validationOfXMLFromDb(Map<String, String> appointmentInfo) throws ParserConfigurationException, IOException, SAXException {
        String reqXml = getStcXmlRequestFromDB();
        String resXml = getStcXmlResponseFromDB();
        Reporter.log("Validation of Patient and drug from STC XML Request");
        parseXMLRequestForTP(reqXml, appointmentInfo);
        Reporter.log("Validation of status and errorCode from STC XML Response");
        parseXMLResponse(resXml);
    }


    public void validateFaxUnderActionItems() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            ActionItemsPage actionItemsPage = new ActionItemsPage();
            actionItemsPage.clickActionItems();
            actionItemsPage.clickFaxInbox();
            actionItemsPage.selectOutBox();
            actionItemsPage.clickOk();
            logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            actionItemsPage.recordCount();
            String faxNumber = actionItemsPage.getFaxStatusForRxNbr(rxNbr);
            Reporter.log("Fax has been sent to\t" + faxNumber);
            actionItemsPage.clickClose();
        } catch (Throwable e) {
            Reporter.log("Test failed at Action Items page");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }

    }

    public void validateDetailsFromXMLRequestDB(String xml, Map<String, String> appointmentInfo) {
        String name[] = connexusAppUtils.readPatientNameFromFile();
        Reporter.log(xml);
        Reporter.log("Validation od details in XML request");
        Reporter.log(name[1].toUpperCase() + name[0].toUpperCase());
        if (xml.contains(name[1].toUpperCase() + name[0].toUpperCase())) {
            Reporter.log("XML contains the reuqired patient details\t" + name[1].toUpperCase() + "\t" + name[0].toUpperCase());
        } else {
            Reporter.log("XML doesnot contain required patient details");
        }

        if (xml.contains(appointmentInfo.get("NDC_NBR"))) {
            Reporter.log("XML contains the required NDC\t" + appointmentInfo.get("NDC_NBR"));
        }
    }

    public void parseXMLRequestForTP(String xml, Map<String, String> appointmentInfo) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        InputSource src = new InputSource();
        src.setCharacterStream(new StringReader(xml));

        Document doc = builder.parse(src);
        if (doc.getElementsByTagName("PatFirstName").getLength() > 0) {
            //to get patient firstName,LastName,NDC
            String firstName = doc.getElementsByTagName("PatFirstName").item(0).getTextContent();
            String lastName = doc.getElementsByTagName("PatLastName").item(0).getTextContent();
            String ndcNbr = doc.getElementsByTagName("ProdServiceId").item(0).getTextContent();
            Reporter.log("firstNameFromXML:\t" + firstName + "lastNameFromXML:\t" + lastName + "ndcNbrFromXML:\t" + ndcNbr);
            String name[] = connexusAppUtils.readPatientNameFromFile();
            Assert.assertEquals(lastName.toUpperCase().trim(), name[0].toUpperCase().trim(), "patient lastName in STC XML didnot match with patient name we have used");
            Assert.assertEquals(firstName.toUpperCase().trim(), name[1].toUpperCase().trim(), "patient firstName in STC XML didnot match with patient name we have used");
            Assert.assertEquals(ndcNbr.trim(), appointmentInfo.get("NDC_NBR").trim(), "patient firstName in STC XML didnot match with patient name we have used");
            Reporter.log("patient details and drug are validated with expected from STC XML request");
        } else {
            Reporter.log(" STC XML response doesnot contain patient/NDC TagName and its not the proper STC XMl request");
            Assert.fail();
        }


    }

    public void validationOfSTCSentFromDB() {
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        String query = "select rpt_status_code from rx r,informix.rx_order_detail ro, informix.imz_thd_party_rpt imz \n" +
                "where r.rx_nbr=\n" + rxNbr +
                "and r.rx_id=ro.rx_id\n" +
                "and ro.rx_fill_id=imz.rx_fill_id;";
        Reporter.log("Query to verify STC status:\t" + query);
        Log.info(String.valueOf(siteId));
        DataTable dt = cnx.getDataTable(query);
        DataRow row = dt.getDataRows().get(0);
        Assert.assertEquals(dt.getRowCount(), 1);
        int rptStatusCode = (short) row.getValue("rpt_status_code");
        Assert.assertEquals(rptStatusCode, 1008, "STC sending is not successfull");
        Reporter.log("STC is successfully sent with status code:\t" + rptStatusCode);
    }

    public void selectIMZRegistryValueNoForPatient(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        patientSearchPage.launchPatientSearchScreen();
        try {
            if (patientSearchPage.isPatientSearchWindowDisplayed()) {
                Reporter.log("Patient Name" + name[0] + "," + name[1]);
                patientSearchPage.inputPatientName(name[0] + "," + name[1]);
                Reporter.log("DOB" + inputData.get("DOB"));
                patientSearchPage.inputPatientDob(inputData.get("DOB"));
                patientSearchPage.clickSearchNow();
                patientSearchPage.openFirstPatientRecord();
                patientMaintenancePage.clickTabProfile();
                patientMaintenancePage.clickIMZRegistryNo();
                logScreenshotSafely(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName));
                Reporter.log("updated IMZ registry to NO on PMS Profile/Other tab");
                patientMaintenancePage.clickSaveAndClose();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at PatientMaintainance page");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateImzRegistryNoFromPMS() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            if (patientSearchPage.isPatientSearchWindowDisplayed()) {
                Reporter.log("Patient Name" + name[0] + "," + name[1]);
                patientSearchPage.inputPatientName(name[0] + "," + name[1]);
                Reporter.log("DOB" + patient.getPatientDob());
                patientSearchPage.inputPatientDob(patient.getPatientDob());
                patientSearchPage.clickSearchNow();
                patientSearchPage.openFirstPatientRecord();
                patientMaintenancePage.clickTabProfile();
                Boolean status = patientMaintenancePage.verifyImzRegistryReportingNo();
                Reporter.log("Validating Imz Registry Reporting Value");
                logScreenshotSafely(Status.INFO, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName));
                Assert.assertTrue(status, "Imz registry reporting is not No");
                Reporter.log("Validated the IMZ Registry reporting as No");
                patientMaintenancePage.clickSaveAndClose();
            } else {
                logScreenshotSafely(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName));
                Assert.fail("Patient maintainance screen not launched");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed while creating patient in patient maintaince screen");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public String getPrescriberNameFromPatient() {
        String query = "select pres.prescbr_label_name from patient pat,prescriber pres where pat.patient_id=" + patientId + "and pat.pri_prescriber_id =pres.prescriber_id;";
        Log.info(query);
        String prescriberLabelName = am.getConnexusDB(siteId).getScalar
                (query, String.class);
        Reporter.log("PrescriberName from Patient:" + prescriberLabelName);
        return prescriberLabelName;
    }

    public int getPrescriberIdFromPatient(int patientId) {
        String query = "select pri_prescriber_id from patient where patient_Id=" + patientId + ";";
        Log.info(query);
        int prescriberId = am.getConnexusDB(siteId).getScalar
                (query, Integer.class);
        Reporter.log("PrescriberId from PatientId:" + prescriberId);
        return prescriberId;
    }

    public void validatePCPFromPMS(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        patientSearchPage.launchPatientSearchScreen();
        try {
            if (patientSearchPage.isPatientSearchWindowDisplayed()) {
                Log.info("Validation of PCP");
                Reporter.log("Patient Name" + name[0] + "," + name[1]);
                patientSearchPage.inputPatientName(name[0] + "," + name[1]);
                Reporter.log("DOB" + inputData.get("DOB"));
                patientSearchPage.inputPatientDob(inputData.get("DOB"));
                patientSearchPage.clickSearchNow();
                patientSearchPage.openFirstPatientRecord();
                patientMaintenancePage.clickTabProfile();
                Reporter.log("get PCP on PMS Profile/Other tab");
                String prescriberFromPMS = patientMaintenancePage.getPrescriberName();
                Assert.assertNotNull(prescriberFromPMS);
                Reporter.log("PCP on PMS screen is validated after creation of dotcom order");
                int presIdWithNameFromPMS = getPrescriberIdFromName(prescriberFromPMS);
                Reporter.log("PCP From PMS Screen:\t" + prescriberFromPMS);
                int patientID = getPatientId();
                int presId = getPrescriberIdFromPatient(patientID);
                Assert.assertEquals(presIdWithNameFromPMS, presId, "Prescriber is not matched");
                Reporter.log("Prescriber is validated in DB with respective patientName");
                logScreenshotSafely(Status.PASS, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName));
                Reporter.log("Validated PCP on PMS Profile/Other tab");
                patientMaintenancePage.clickSaveAndClose();
            }
        } catch (Exception e) {
            Reporter.log("Test failed at PatientMaintainance page");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public int getPrescriberIdFromName(String prescriberName) {
        String names[] = prescriberName.split(",");
        String firstName[] = names[1].split(" ");
        String query = "select prescriber_id from prescriber where first_name= " + "'" + firstName[1].toUpperCase().trim() + "'" + " and last_name = " + "'" + names[0].toUpperCase().trim() + "';";
        Log.info(query);
        int prescriberId = am.getConnexusDB(siteId).getScalar
                (query, Integer.class);
        Reporter.log("PrescriberId from Name:" + prescriberId);
        return prescriberId;
    }

    public void verifyOrderForExistingPatientAfterDotComOrderCreation(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<String> statusAndProblem = new ArrayList<>();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            Reporter.log("WorkQueue:" + statusAndProblem.get(0));
            Reporter.log("problem:" + statusAndProblem.get(1));
            String patientName = orderSearch.getPatientName(0);
            Reporter.log("PatientName in order search connexus after dotcom Order creation:" + patientName);
            Assert.assertEquals(patientName, name[0].toUpperCase() + "," + name[1].toUpperCase(), "Required patient not reflected in connexus");
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            Reporter.log("RxNbr in Connexus after creation of dotcom order:" + rxNbr);
        } catch (Throwable e) {
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Assert.fail(e.toString());
        }
    }

    public void createDotcomOrderToConnexusForExistingPatientWithPCP(Map<String, String> appointmentInfo) {
        Reporter.log("Executing in store:" + siteId);
        String[] name = connexusAppUtils.readPatientNameFromFile();
        Log.info(name[0] + ',' + name[1]);
        String imzType = appointmentInfo.get("serviceType");
        Map<String, String> availableSlotDetailsAndAccessPoint = PharmaIMZSlotsWrapper.getSlotDetailsAndAccessPoint(name[1], name[0], imzType, siteId);
        accessPointId = availableSlotDetailsAndAccessPoint.get("ACCESS_POINT_ID");
        slotId = availableSlotDetailsAndAccessPoint.get("SLOT_ID");
        slotTime = availableSlotDetailsAndAccessPoint.get("START_TIME");
        slotDate = availableSlotDetailsAndAccessPoint.get("SLOT_DATE");
        reservationId = SoftLockWrapper.getReservationId(name[1], name[0], slotId, siteId, accessPointId);
        appointmentId = PharmaIMZSchedulingWrapper.getAppointmentIdForPCP(appointmentInfo, siteId, slotDate, slotTime, reservationId, accessPointId, questionsWithAllFalse(), name[1], name[0]);
        String date = dateTimeConversion(slotDate, slotTime);
        appointmentInfo.put("appointmentId", appointmentId);
        appointmentInfo.put("reservationId", reservationId);
        appointmentInfo.put("appointmentDate", date);
        appointmentInfo.put("fName", name[1]);
        appointmentInfo.put("lName", name[0]);

        CosmosWrapper.validateWithDotcomAppointmentIdPharmaIMZ(cosmosContext, Integer.parseInt(String.valueOf(siteId)), appointmentInfo, appointmentId);

    }

    public void verifyIMZChangeProduct() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            ResolutionPage resolutionPage = new ResolutionPage();
            Boolean enabled = resolutionPage.verifyModifyOrder();
            logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Reporter.log("Verifying modify order details is not enabled and unable to change product in  resolution screen ");
            Assert.assertEquals(enabled, false, "Modify order details is enabled and able to change product ");
            Reporter.log("Assert: Validated Modify order details is not enabled and pharmacist not able to change product ");
        } catch (Throwable e) {
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Assert.fail(e.toString());
        }
    }

    public void createDotcomOrderToConnexusForNewPatientWithPCP(Map<String, String> appointmentInfo) {
        Reporter.log("Executing in store:" + siteId);
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        Log.info(name[0] + ',' + name[1]);
        String imzType = appointmentInfo.get("serviceType");
        Map<String, String> availableSlotDetailsAndAccessPoint = PharmaIMZSlotsWrapper.getSlotDetailsAndAccessPoint(name[1], name[0], imzType, siteId);
        accessPointId = availableSlotDetailsAndAccessPoint.get("ACCESS_POINT_ID");
        slotId = availableSlotDetailsAndAccessPoint.get("SLOT_ID");
        slotTime = availableSlotDetailsAndAccessPoint.get("START_TIME");
        slotDate = availableSlotDetailsAndAccessPoint.get("SLOT_DATE");
        reservationId = SoftLockWrapper.getReservationId(name[1], name[0], slotId, siteId, accessPointId);
        appointmentId = PharmaIMZSchedulingWrapper.getAppointmentIdForPCP(appointmentInfo, siteId, slotDate, slotTime, reservationId, accessPointId, questionsWithAllFalse(), name[1], name[0]);
        String date = dateTimeConversion(slotDate, slotTime);
        appointmentInfo.put("appointmentId", appointmentId);
        appointmentInfo.put("reservationId", reservationId);
        appointmentInfo.put("appointmentDate", date);
        appointmentInfo.put("fName", name[1]);
        appointmentInfo.put("lName", name[0]);

        CosmosWrapper.validateWithDotcomAppointmentIdPharmaIMZ(cosmosContext, Integer.parseInt(String.valueOf(siteId)), appointmentInfo, appointmentId);

    }

    public void verifyWorkQueueAndNeedToContactPrescriberProblemStatus() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<String> statusAndProblem = new ArrayList<>();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Need to Contact Prescriber")) {
                Reporter.log("Patient is in Resolve Queue with Need to contact Prescriber");
                patientSearchPage.openFirstPatientRecord();
            } else {
                Assert.fail("Patient not landed in Resolve Queue with Need to contact Prescriber");
            }
        } catch (Throwable e) {
            Reporter.log("Patient is not resolve queue or problem message did not match");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Assert.fail(e.toString());
        }

    }


    public void createDotcomOrderWithNewPatientPCPForFutureDatedToConnexus(Map<String, String> appointmentInfo) {
        Reporter.log("Executing in store:" + siteId);
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        Log.info(name[0] + ',' + name[1]);
        String imzType = appointmentInfo.get("serviceType");
        Map<String, String> availableSlotDetailsAndAccessPoint = PharmaIMZSlotsWrapper.getFutureSlotDetailsAndAccessPoint(name[1], name[0], imzType, siteId);
        accessPointId = availableSlotDetailsAndAccessPoint.get("ACCESS_POINT_ID");
        slotId = availableSlotDetailsAndAccessPoint.get("SLOT_ID");
        slotTime = availableSlotDetailsAndAccessPoint.get("START_TIME");
        slotDate = availableSlotDetailsAndAccessPoint.get("SLOT_DATE");
        reservationId = SoftLockWrapper.getReservationId(name[1], name[0], slotId, siteId, accessPointId);
        appointmentId = PharmaIMZSchedulingWrapper.getAppointmentIdForPCP(appointmentInfo, siteId, slotDate, slotTime, reservationId, accessPointId, questionsWithAllFalse(), name[1], name[0]);
        String date = dateTimeConversion(slotDate, slotTime);
        appointmentInfo.put("appointmentId", appointmentId);
        appointmentInfo.put("reservationId", reservationId);
        appointmentInfo.put("appointmentDate", date);
        appointmentInfo.put("fName", name[1]);
        appointmentInfo.put("lName", name[0]);
        CosmosWrapper.validateWithDotcomAppointmentIdPharmaIMZ(cosmosContext, Integer.parseInt(String.valueOf(siteId)), appointmentInfo, appointmentId);
    }

    public void verifyWorkQueueAndProblemStatusAsFutureFill() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<String> statusAndProblem = new ArrayList<>();
        try {
            am.performSleep(5);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Future Date")) {
                Reporter.log("Patient is in Resolve Queue with Waiting for Filling-Future Date");
                am.performSleep(10);
                patientSearchPage.openFirstPatientRecord();
                logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            } else {
                Assert.fail("Patient not landed in Resolve Queue with Waiting for Filling-Future Date");
            }
        } catch (Throwable e) {
            Reporter.log("Patient is not resolve queue or problem message did not match");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Assert.fail(e.toString());
        }
    }

    public void restartService() {
        connexusAPIManager.restartConnexusService(String.valueOf(siteId));
    }

    public int getprescriberId(Map<String, String> inputData) {
        prescriberId = connexusAppUtils.getPrescriberIdFromName(inputData.get("PRESCRIBER_NAME"));
        return prescriberId;
    }

    public int performCreatePatientThroughAPI(Map<String, String> inputData) {
        connexusAppUtils.addRandomNamesInFile();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        firstName = name[0];
        lastName = name[1];
        long homePhone, workPhone, cellPhone;
        siteId = Integer.parseInt(inputData.get("siteId"));
        homePhone = Long.parseLong(inputData.get("HOME_PHONE"));
        workPhone = Long.parseLong(inputData.get("WORK_PHONE"));
        cellPhone = Long.parseLong(inputData.get("CELL_PHONE"));
        inputDob = inputData.get("inputDob");
        resp = connexusAPIManager.createPatient(lastName, firstName, inputDob, siteId, homePhone, workPhone, cellPhone);
        Assert.assertEquals(resp.getStatusCode(), 201, "createPatient API response status code did not match");
        inputResponse = resp.getDataResponse(InputResponse.class);
        patientId = inputResponse.getPatientId();
        Log.info("patientId = " + patientId);
        Reporter.log("Patient has been created in Store:" + siteId);
        return patientId;
    }

    public void performUpdatePatientThroughAPI(Map<String, String> inputData) throws InterruptedException {
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow patientInfo = getPatientInfo(cnx, patientId);
        lastName = patientInfo.getValue("last_name").toString().trim();
        firstName = patientInfo.getValue("first_name").toString().trim();
        inputDob = inputData.get("patDob");
        resp = updateapiWrapper.updatePatient(inputData, lastName, firstName, inputDob, patientId, siteId);
        Assert.assertEquals(resp.getStatusCode(), 202, "updatePatient API response status code did not match");
        Reporter.log("Patient details has been updated in Store:" + siteId);
    }

    public void performCreatePatientAndCompleteTillEOD(Map<String, String> inputData) {
        //setting properties
        requestTypeCode = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        priorityId = Integer.parseInt(prop.getProperty("fom.OrderPriorityId"));
        dispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));
        siteId = Integer.parseInt(inputData.get("siteId"));
        patientId = performCreatePatientThroughAPI(inputData);
        inputRxExpDate = wrapperUtils.getExpiryDate();
        inputPickupDate = wrapperUtils.getPickUpDate();
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        //get drug details
        drugInfo = connexusAPIManager.getDrugInfo(cnx, inputData.get("DRUG_NAME"));
        Prescriber prescriber = connexusAPIManager.PrescriberDetails();
        //complete drop-off
        resp = connexusAPIManager.createOrderAndDropOff(requestTypeCode, priorityId, dispenseType, patientId, siteId, inputPickupDate, inputRxExpDate, Integer.parseInt(inputData.get("REFILLS")), drugInfo, prescriber, Integer.parseInt(inputData.get("rxOriginCode")));
        Assert.assertEquals(resp.getStatusCode(), 201, "createOrderToPickup API response status code did not match");
        //moveOrderToEOD
        resp = connexusAPIManager.moveOrderToEOD(resp.getDataResponse());
        Assert.assertEquals(resp.getStatusCode(), 201, "NewOrderToEOD API response status code did not match");
        Log.info("resp" + resp.getDataResponse());
        inputResponse = resp.getDataResponse(InputResponse.class);
        Reporter.log("orderId = " + inputResponse.getOrderId() + ", rxNbr = " + inputResponse.getRxNbr() + ", rxId = " + inputResponse.getRxId() + ", rxFillId = " + inputResponse.getRxFillId());
    }

    public void validateIMZRegistryYesInPMSFromDropOff(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            DropOffPage dropOff = new DropOffPage();
            dropOff.clickDropOffQueue();
            logScreenshotSafely(Status.INFO, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName));
            String patientName = name[0] + "," + name[1];
            dropOff.enterPatientName(patientName);
            dropOff.clickPatientSearch();
            Reporter.log("DOB :" + inputData.get("DOB"));
            patientSearchPage.inputPatientDob(inputData.get("DOB"));
            patientSearchPage.clickSearchNow();
            patientSearchPage.clickSearchHost();
            logScreenshotSafely(Status.INFO, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName));
            Assert.assertTrue(patientSearchPage.isPatientRecordDisplayed(0));
            patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(patient.getPatientLastName() + "," + patient.getPatientFirstName());
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickSaveAndClose();
            dropOff.handleAnnualValidatePatInfoPopUp();
            dropOff.clickHostProfile();
            dropOff.clickBtnPatientMaintenance();
            logScreenshotSafely(Status.INFO, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName));
            patientMaintenancePage.clickTabProfile();
            Boolean status = patientMaintenancePage.imzRegistryReporting();
            logScreenshotSafely(Status.INFO, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName));
            Assert.assertTrue(status, "Imz registry reporting is not Yes");
            Reporter.log("Validated the IMZ Registry reporting as Yes");
        } catch (Throwable e) {
            Reporter.log("Test failed while validating service details in PMS screen");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateIMZRegistryNoInPMSFromDropOff(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            DropOffPage dropOff = new DropOffPage();
            dropOff.clickDropOffQueue();
            logScreenshotSafely(Status.INFO, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName));
            String patientName = name[0] + "," + name[1];
            dropOff.enterPatientName(patientName);
            dropOff.clickPatientSearch();
            Reporter.log("DOB :" + inputData.get("DOB"));
            patientSearchPage.inputPatientDob(inputData.get("DOB"));
            patientSearchPage.clickSearchNow();
            patientSearchPage.clickSearchHost();
            logScreenshotSafely(Status.INFO, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName));
            Assert.assertTrue(patientSearchPage.isPatientRecordDisplayed(0));
            patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(patient.getPatientLastName() + "," + patient.getPatientFirstName());
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickSaveAndClose();
            dropOff.handleAnnualValidatePatInfoPopUp();
            dropOff.clickHostProfile();
            dropOff.clickBtnPatientMaintenance();
            logScreenshotSafely(Status.INFO, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName));
            patientMaintenancePage.clickTabProfile();
            status = patientMaintenancePage.verifyImzRegistryReportingNo();
            logScreenshotSafely(Status.INFO, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName));
            Assert.assertTrue(status, "Imz registry reporting is not No");
            Reporter.log("Validated the IMZ Registry reporting as No");
        } catch (Throwable e) {
            Reporter.log("Test failed while validating service details in PMS screen");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateIMZRegistryYesForHostProfileFromPMS(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            if (patientSearchPage.isPatientSearchWindowDisplayed()) {
                Reporter.log("Patient Name" + name[0] + "," + name[1]);
                Log.info("Patient Name :" + name[0] + "," + name[1]);
                patientSearchPage.inputPatientName(name[0] + "," + name[1]);
                Reporter.log("DOB :" + inputData.get("DOB"));
                patientSearchPage.inputPatientDob(inputData.get("DOB"));
                patientSearchPage.clickSearchNow();
                patientSearchPage.clickSearchHost();
                Assert.assertTrue(patientSearchPage.isPatientRecordDisplayed(0));
                patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(patient.getPatientLastName() + "," + patient.getPatientFirstName());
                patientSearchPage.openFirstPatientRecord();
                patientMaintenancePage.clickTabProfile();
                Boolean status = patientMaintenancePage.imzRegistryReporting();
                Reporter.log("Validating Imz Registry Reporting Value");
                logScreenshotSafely(Status.INFO, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName));
                Assert.assertTrue(status, "Imz registry reporting is not Yes");
                Reporter.log("Validated the IMZ Registry reporting as Yes");
                patientMaintenancePage.clickSaveAndClose();
            } else {
                Reporter.log("Patient maintainance screen not launched");
                logScreenshotSafely(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName));
                Assert.fail("Patient maintainance screen not launched");
            }
        } catch (Throwable e) {
            Reporter.log("Test failed while validating service details in PMS screen");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateIMZRegistryNoForHostProfileFromPMS(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            connexusAppUtils.getStoreId();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            patientSearchPage.isPatientSearchWindowDisplayed();
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.inputPatientDob(inputData.get("DOB"));
            patientSearchPage.clickSearchNow();
            patientSearchPage.clickSearchHost();
            logScreenshotSafely(Status.INFO, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName));
            Assert.assertTrue(patientSearchPage.isPatientRecordDisplayed(0));
            patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(patient.getPatientLastName() + "," + patient.getPatientFirstName());
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickTabProfile();
            status = patientMaintenancePage.verifyImzRegistryReportingNo();
            logScreenshotSafely(Status.INFO, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName));
            Assert.assertTrue(status, "Imz registry reporting is not No");
            Reporter.log("Validated the IMZ Registry reporting as No");
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            Reporter.log("Test failed while creating patient in patient maintaince screen");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void autosyncValidationinDB(Map<String, String> appointmentInfo) {
        String txn_type_code = appointmentInfo.get("TXN_TYPE_CODE");
        String query = "select * from pharmacy_message:central_patient_lookup where patient_id = " + patientId + " and txn_type_code= " + txn_type_code + " order by request_ts desc;";
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        Reporter.log("select * from pharmacy_message:central_patient_lookup where patient_id = " + patientId + " and txn_type_code= " + txn_type_code + " order by request_ts desc;");
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 3);
        DataRow row = dt.getDataRows().get(0);
        String userId = row.getValue("last_change_user_id");
        Reporter.log("last_change_user_id:" + userId);
        Assert.assertEquals(userId.trim(), "AUTOSYNC", "last_change_user_id as Autosync in central db");
        int typeCode = (short) row.getValue("txn_type_code");
        Reporter.log("Txn_type_code :" + typeCode);
        Assert.assertEquals(String.valueOf(typeCode), txn_type_code, "assn_subj_type_code");

    }

    public void verifyOrderPickupdatestatus() {
        List<String> pickUpUIDate = new ArrayList<>();
        try {
            Reporter.log("PickUp Date and Time Validated");
            String[] name = connexusAppUtils.readPatientNameFromFile();
            pickUpUIDate = orderSearch.getVerifyPickUpDate(name[0] + "," + name[1], 0);
            String convertPickUpUIDate = convertDateFormat("MM/dd/yyyy hh:mm:ss a", "yyyy-MM-dd hh:mm:ss a", pickUpUIDate.get(0));
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            orderId = connexusAppUtils.getRxOrderIdFromTable(siteId, rxNbr);
            String pickUpDate = connexusAppUtils.getVerifyPickUpDate(orderId);
            String convertPickUpDate = convertDateFormat("yyyy-MM-dd hh:mm:ss", "yyyy-MM-dd hh:mm:ss a", pickUpDate);
            Assert.assertEquals(convertPickUpUIDate, convertPickUpDate);

        } catch (Throwable e) {
            Reporter.log("PickUp Date and Time did not match");
            Assert.fail(e.toString());
        }
    }

    //Convert Date Format from 24 hours to 12 hours
    public static String convertDateFormat(String inputFormat, String outputFormat, String inputDateString) {
        String outputDateString = null;
        SimpleDateFormat inputDateFormat = new SimpleDateFormat(inputFormat);
        SimpleDateFormat outputDateFormat = new SimpleDateFormat(outputFormat);
        try {
            Date date = inputDateFormat.parse(inputDateString);
            outputDateString = outputDateFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return outputDateString;
    }

    public void validateSubjectAssociationValues(String ass_Fname, String ass_Lname, Service_Type_Code type_code, String ass_type_code) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();

        try {
            String GuardianInfo = "select * from subject_association where subject_id = " + patientId + ";";
            IDatabaseContext cnx = am.getConnexusDB(siteId);
            DataTable dt = cnx.getDataTable(GuardianInfo);
            Assert.assertEquals(dt.getRowCount(), 1);
            DataRow row = dt.getDataRows().get(0);
            Reporter.log("Fetching Guardian info using query: select * from subject_association where subject_id");

            String SubjectAssnFName = row.getValue("subj_assn_first_name");
            Reporter.log("GuardianFirstName:" + SubjectAssnFName);
            Assert.assertEquals(SubjectAssnFName.trim(), ass_Fname, "Ass first name is not same as patient first name");

            String SubjectAssnLName = row.getValue("subj_assn_last_name");
            Reporter.log("GuardianLastName:" + SubjectAssnLName);
            Assert.assertEquals(SubjectAssnLName.trim(), ass_Lname, "Ass last name is not same as patient last name");

            int AssociateSubjectTypecode = (short) row.getValue("assn_subj_type_code");
            Reporter.log("GuardianSubjectTypeCode:" + AssociateSubjectTypecode);
            Assert.assertEquals(String.valueOf(AssociateSubjectTypecode), ass_type_code, "Invalid associate type code");

            int SubjectTypeCode = (short) row.getValue("subject_type_code");
            Assert.assertEquals(SubjectTypeCode, type_code.getCode(), "Invalid subject_type_code");
            Reporter.log("SubjectTypeCode:" + SubjectTypeCode);

            Reporter.log("DB validations on Subject Association is completed");

        } catch (Throwable e) {
            Reporter.log("DB Validations failed");
            Assert.fail(e.toString());
        }
    }

    public void verifyGuardianInfoAsSelf(Map<String, String> appointmentInfo) {
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String firstName = name[0].toUpperCase().trim();
            Reporter.log("firstname: " + firstName);
            String lastName = name[1].toUpperCase().trim();
            Reporter.log("lastname: " + lastName);
            String relationcode = appointmentInfo.get("GUARDIAN_RELATION_CODE");
            //for guardian as self use enum as patient
            Service_Type_Code serviceType = Service_Type_Code.Patient;

            validateSubjectAssociationValues(firstName, lastName, serviceType, relationcode);
            Reporter.log("validations are success ");

        } catch (Throwable e) {
            Reporter.log(" GuardianInfoAsSelf Validations failed");
            Assert.fail(e.toString());
        }
    }

    public void verifyAllergydetailsInPMS(Map<String, String> appointmentInfo) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        prescriberId = getprescriberId(appointmentInfo);
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            Reporter.log("Patient Name" + name[0] + "," + name[1]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            Reporter.log("DOB" + patient.getPatientDob());
            patientSearchPage.inputPatientDob(patient.getPatientDob());
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickAllergyMedicalTab();

            Assert.assertTrue(patientMaintenancePage.areAllAllergiesDisplayed());
            Reporter.log("Assert: All Allergies are displayed in UI");
            List<String> allergies = patientMaintenancePage.getAllergyNamesDisplayed();
            Reporter.log("Allergies displayed" + allergies);
            Assert.assertTrue(patientMaintenancePage.isAllergyAddedDateDisplayed(0));
            Reporter.log("Assert: Allergy added date is displayed in UI");
            Assert.assertTrue(patientMaintenancePage.isAllergytypeOfReactionDisplayed(0));
            Reporter.log("Assert: Type of reaction is displayed in UI");
            logScreenshotSafely(Status.PASS, "Added Allergy Conditon", patientMaintenancePage.takeScreenShot(currentStepMethodName));
            //verify added date
            String todaysDate = getCurrentDate("MM/dd/yyyy");
            Reporter.log("Todays_Date:" + todaysDate);
            String allergyDate = patientMaintenancePage.getAllergyAddedDateDisplayed(0);
            String addedDate[] = allergyDate.split(" ");
            Reporter.log("Allergy added date:" + addedDate[0].trim());
            Assert.assertEquals(addedDate[0].trim(), todaysDate.trim(), "Allergy added date is not same as today's date");
            logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Reporter.log("Assert: Validation of Allergy added Date is completed");
            // verify type of reaction
            String typeOfReaction = patientMaintenancePage.gettypeOfReactionDisplayed(0);
            Reporter.log("Type of Reaction Displayed as:" + typeOfReaction);
            Assert.assertEquals(typeOfReaction, "Unknown", "Type of Reaction is not unknown");
            logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Reporter.log("Assert: Validation of type of reaction is completed");
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            Reporter.log("Test failed at PatientMaintainance page");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyMedicalConditionInPMS(Map<String, String> appointmentInfo) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        prescriberId = getprescriberId(appointmentInfo);
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            Reporter.log("Patient Name" + name[0] + "," + name[1]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            Reporter.log("DOB" + patient.getPatientDob());
            patientSearchPage.inputPatientDob(patient.getPatientDob());
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickAllergyMedicalTab();

            Assert.assertTrue(patientMaintenancePage.isMedicaconditionNameDisplayed(0));
            Reporter.log("Assert: All Medical conditions are displayed in UI");
            List<String> medicalconditions = patientMaintenancePage.getMedicalConditionsNamesDisplayed();
            Reporter.log("Medicalconditions displayed--" + medicalconditions);
            Assert.assertTrue(patientMaintenancePage.isMedicalCondtionAddedDateDisplayed(0));
            Reporter.log("Assert: Medical conditions added date is displayed in UI");
            logScreenshotSafely(Status.PASS, "Added Medical conditions", patientMaintenancePage.takeScreenShot(currentStepMethodName));
            //verify added date
            String todaysDate = getCurrentDate("MM/dd/yyyy");
            Reporter.log("Todays_Date:" + todaysDate);
            String MedicalConditionDate = patientMaintenancePage.getMedicalConditionsAddedDateDisplayed(0);
            String addedDate[] = MedicalConditionDate.split(" ");
            Reporter.log("MedicalCondition added date:" + addedDate[0].trim());
            Assert.assertEquals(addedDate[0].trim(), todaysDate.trim(), "MedicalCondition added date is not same as today's date");
            logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Reporter.log("Assert: Validation of Allergy added Date is completed");

            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            Reporter.log("Test failed at PatientMaintainance page");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }


    public String verifyImzOrderWorkQueueStatus() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<String> statusAndProblem = new ArrayList<>();
        String problemMsg = null;
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            Reporter.log("WorkQueue:" + statusAndProblem.get(0));
            problemMsg = statusAndProblem.get(1);
            Reporter.log("Problem:" + problemMsg);
            logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
        } catch (Throwable e) {
            Reporter.log("Patient is not resolve queue or problem message did not match");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
        return problemMsg;
    }

    public void verifyProblemMessage(ProblemTypes problemMessage) {
        String problemMsg = verifyImzOrderWorkQueueStatus();
        switch (problemMessage) {
            case ManualResolution:
                Assert.assertEquals(problemMsg, "[RPh] - Manual Resolution", "order is not in [Rph]- Manual Resolution");
                Reporter.log("Validated :" + problemMsg);
                break;
            case PatientNameMismatch:
                Assert.assertEquals(problemMsg, "Patient Name Mismatch", "order is not in Patient Name Mismatch");
                Reporter.log("Validated :" + problemMsg);
                break;
        }

    }

    public void checkAndOpenCheckDURScreen(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<String> statusAndProblem = new ArrayList<>();
        ResolutionPage resolutionPage = new ResolutionPage();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            Log.info("WorkQueue:" + statusAndProblem.get(0));
            Log.info("problem:" + statusAndProblem.get(1));
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Manual Resolution")) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(name[0] + "," + name[1]);
                patientSearchPage.openFirstPatientRecord();
                if (resolutionPage.manualResolutionVerification().contains("REASON: DUE TO RPH PRESCRIPTIVE AUTHORITY REQUIREMENTS, THIS IMMUNIZATION NEEDS ADDITIONAL ACTION BY A PHARMACIST.")) {
                    am.getConnexusWorkFlow().performRphManualResolutionForAdditionalAction(name[0] + "," + name[1], inputData.get("PRESCRIBER_NAME"));
                    Reporter.log("This IMMUNIZATION needs Additional action by Prescriber is resolved");
                } else {
                    Assert.fail("Drugs not in authorised list");
                }
            }
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);

            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Reject")) {
                am.getConnexusWorkFlow().completeResolution(rxNbr);
                Reporter.log("Invalid Reject Code is resolved");
            }

            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (connexusTestScripts.checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                am.getConnexusWorkFlow().openCheckDURScreen(rxNbr);
            }
        } catch (Throwable e) {
            Reporter.log("patient is not in DUR queue");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }

    }


    public void validateChangeProductInCheckDURScreen(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            resolutionPage.clickOnIMZProductChangeOption(11);
            Boolean displayed = resolutionPage.verifyIMZChangeProductPopUpDisplayed();
            Assert.assertEquals(displayed, true, "IMZ Change Product Pop Up is displayed  ");
            drug = resolutionPage.selectIMZDrug();
            ndc = resolutionPage.selectIMZNDC();
            resolutionPage.clickAcceptIMZ();
            logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            checkAndOpenCheckDURScreen(inputData);
            String drugFromCheckDUR = resolutionPage.getDrugText();
            String ndcFromDb = connexusAppUtils.getNDCFromRx(rxNbr);
            Assert.assertEquals(ndc, ndcFromDb, "Selected NDC from pop up and NDC fetched from DB are NOT matched ");
            Assert.assertEquals(drug, drugFromCheckDUR, "Selected Drug from pop up and Drug from checkDUR screen after clicking on Accept button are NOT matched ");
            Reporter.log("NDC changed from pop up" + ndc + "And NDC fetched from DB" + ndcFromDb + "are matched !!");
            Reporter.log("Drug changed from pop up" + drug + "And Drug captured from checkDUR Screen after clicking Accept on pop up " + drugFromCheckDUR + "are matched !!");
        } catch (Throwable e) {
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Assert.fail(e.toString());
        }
    }

    public void validateChangeProductInModifyDetailScreen(Map<String, String> inputData) throws AWTException {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        modifyDetails.openModifyDetailsScreen();
        resolutionPage.clickOnIMZProductChangeOption(12);
        Boolean displayed = resolutionPage.verifyIMZChangeProductPopUpDisplayed();
        Assert.assertEquals(displayed, true, "IMZ Change Product Pop Up is displayed ");
        drug = resolutionPage.selectIMZDrug();
        ndc = resolutionPage.selectIMZNDC().trim();
        resolutionPage.clickAcceptIMZ();
        logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
        checkAndOpenCheckDURScreen(inputData);
        String drugFromCheckDUR = resolutionPage.getDrugText();
        logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
        Reporter.log("Drug is changed for current RX");
        String ndcFromDb = connexusAppUtils.getNDCFromRx(rxNbr).trim();
        Assert.assertEquals(ndc.trim(), ndcFromDb.trim(), "Selected NDC from pop up and NDC fetched from DB are NOT matched ");
        Assert.assertEquals(drug, drugFromCheckDUR, "Selected Drug from pop up and Drug from Modify Detail screen after clicking on Accept button are NOT matched ");
        Reporter.log("NDC changed from pop up" + ndc + "And NDC fetched from DB" + ndcFromDb + "are matched !!");
        Reporter.log("Drug changed from pop up" + drug + "And Drug captured from checkDUR Screen after clicking Accept on pop up " + drugFromCheckDUR + "are matched !!");
    }

    public void navigateToManualResolutionScreenForRxOrder() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<String> statusAndProblem = new ArrayList<>();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Manual Resolution")) {
                Reporter.log("Patient is in Resolve Queue");
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                Reporter.log("Unauthorised drug resolution screen is opened");
            }

        } catch (Throwable e) {
            Reporter.log("Patient is not Drug Unauthorized resolution ");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void navigateToPatientNameMismatchResolutionForRxOrder() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<String> statusAndProblem = new ArrayList<>();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            am.performSleep(3);
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && "Patient Name Mismatch".equalsIgnoreCase(statusAndProblem.get(1))) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                patientSearchPage.openFirstPatientRecord();
                Reporter.log("Problem is patient Name Mismatch so Resolution Page is launched");
            }
        } catch (Throwable e) {
            Reporter.log("Patient is not Patient Name Mismatch resolution ");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateChangeProductInResolutionPage(Map<String, String> inputData) throws AWTException {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        resolutionPage.clickOnIMZProductChangeOption(10);
        IsDisplayed = resolutionPage.verifyIMZChangeProductPopUpDisplayed();
        Assert.assertEquals(IsDisplayed, true, "IMZ Change Product Pop Up is displayed ");
        drug = resolutionPage.selectIMZDrug();
        ndc = resolutionPage.selectIMZNDC().trim();
        resolutionPage.clickAcceptIMZ();
        logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
        navigateToPatientNameMismatchResolutionForRxOrder();
        changedDrug = resolutionPage.getPrescribedDrugText();
        logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
        Reporter.log("Drug is changed for current RX");
        String ndcFromDb = connexusAppUtils.getNDCFromRx(rxNbr).trim();
        Assert.assertEquals(ndc.trim(), ndcFromDb.trim(), "Selected NDC from pop up and NDC fetched from DB are NOT matched ");
        Assert.assertEquals(drug, changedDrug, "Selected Drug from pop up and Drug from Patient Name Mismatch after clicking on Accept button are NOT matched ");
        Reporter.log("NDC changed from pop up" + ndc + "And NDC fetched from DB" + ndcFromDb + "are matched !!");
        Reporter.log("Drug changed from pop up" + drug + "And Drug changed after clicking Accept on pop up captured from Patient Name mismatch screen " + changedDrug + "are matched !!");
    }

    public void performImZAdministrationForDotcomAddProduct(Map<String, String> appointmentInfo) {
        int patientListInfo, orderSeqNbr2, rxFillId2, serviceId2, itemMdsFamId2;
        String vaccineName2;
        boolean isGuardian = false;
        prescriberId = getprescriberId(appointmentInfo);
        getImzInfo = getImzInfo(siteId);
        List<Integer> orderSeqNbrList2 = new ArrayList<>();
        List<OrderInfo> orderInfoList2 = new ArrayList<>();
        List<Integer> serviceIdList2 = new ArrayList<>();
        List<Integer> itemMdsFamIdList2 = new ArrayList<>();
        List<String> vaccineNameList2 = new ArrayList<>();
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String expirationDate = appointmentInfo.get("expirationDate");
        int patientList = getImzInfo.getSvcOrderDetails().size();
        Reporter.log("patientList from getImZInfo:" + patientList);

        //Get IMZ info
        for (int i = 0; i < patientList; i++) {
            if (getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getLastName().equalsIgnoreCase(name[0])) {
                orderId = getImzInfo.getSvcOrderDetails().get(i).getOrderId();
                orderSeqNbr = getImzInfo.getSvcOrderDetails().get(i).getOrderSeqNbr();
                orderSeqNbrList.add(orderSeqNbr);
                patientId = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getPatientId();
                rxFillId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillId();
                rxFillIdList.add(rxFillId);
                serviceId = getImzInfo.getSvcOrderDetails().get(i).getService().getServiceId();
                serviceIdList.add(serviceId);
                itemMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getItemMdsFamId();
                itemMdsFamIdList.add(itemMdsFamId);
                vaccineName = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getShortName();
                race = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getRaceType();
                ethnicity = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getEthnicityType();
                vaccineNameList.add(vaccineName);
                Reporter.log("orderId:" + orderId + "\t  patientId:" + patientId + "\t  rxFillId:" + rxFillId + "\t  serviceId:" + serviceId + "\t  itemMdsFamId:" + itemMdsFamId + "\t orderSeqNbr:" + orderSeqNbr);
            }
        }
        for (int z = 0; z < orderSeqNbrList.size(); z++) {
            orderInfoList.add(new OrderInfo(orderId, orderSeqNbrList.get(z)));
            if (orderSeqNbrList.get(z) == 1) {
                // Assigning the 1st order seq number
                AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);
                //getIMZRecommendations
                GetIMZRecommendationsWrapper.getIMZRecommendationsForNewPatient(siteId, patientId, ASSIGNED_USER_ID_AUT_TEST);
                //get onlinequestionnarie form
                OnlineQuestionnarieFormWrapper.getOnlineQuestionnarieForm(siteId, String.valueOf(serviceId));

                //save Questionnarie form
                OnlineQuestionnarieFormWrapper.saveOnlineQuestionnarieForm(siteId, questionsWithAllFalse(), String.valueOf(serviceId), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, prescriberId, isGuardian);
            }
            break;
        }
        //Get Authorized IMZDrugs
        GetAuthorizedIMZDrugs getAuthImzDrugs = getAuthorizedIMZDrugs(siteId, String.valueOf(patientId));
        int productList = getAuthImzDrugs.getImzProductDetails().size();
        Log.info("ProductList from GetAuthorizedIMZDrugs:" + productList);

        for (int k = 0; k < productList; k++) {
            productMdsFamId = getAuthImzDrugs.getImzProductDetails().get(0).getProductMdsFamId();
            Reporter.log("productMdsFamId:" + productMdsFamId);
            break;
        }
        //Add IMZDrug - adding 2nd drug
        AddIMZDrugWrapper.addIMZDrug(orderId, productMdsFamId, patientId, ASSIGNED_USER_ID_AUT_TEST, siteId, WORK_STATION_HOST_NAME);

        //perform chkDur - for 2nd rxNbr
        am.performSleep(20);
        this.checkAndPerformCheckDUR(appointmentInfo);

        //Get IMZ info - getting 2nd order seq number
        getImzInfo = getImzInfo(siteId);
        patientListInfo = getImzInfo.getSvcOrderDetails().size();
        Log.info("patientList from getImZInfo:" + patientList);
        for (int i = 0; i < patientListInfo; i++) {
            if (getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getLastName().equalsIgnoreCase(name[0])) {
                orderId = getImzInfo.getSvcOrderDetails().get(i).getOrderId();
                orderSeqNbr2 = getImzInfo.getSvcOrderDetails().get(i).getOrderSeqNbr();
                orderSeqNbrList2.add(orderSeqNbr2);
                patientId = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getPatientId();
                rxFillId2 = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillId();
                rxFillIdList2.add(rxFillId2);
                serviceId2 = getImzInfo.getSvcOrderDetails().get(i).getService().getServiceId();
                serviceIdList2.add(serviceId2);
                itemMdsFamId2 = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getItemMdsFamId();
                itemMdsFamIdList2.add(itemMdsFamId2);
                vaccineName2 = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getShortName();
                vaccineNameList2.add(vaccineName2);
                Reporter.log("orderId:" + orderId + "\t  patientId:" + patientId + "\t  rxFillId:" + rxFillId2 + "\t  serviceId:" + serviceId2 + "\t  itemMdsFamId:" + itemMdsFamId2 + "\t orderSeqNbr:" + orderSeqNbr2);
            }
        }
        am.performSleep(60);
        for (int z = 0; z < orderSeqNbrList2.size(); z++) {
            if (orderSeqNbrList2.get(z) == 2) {
                orderInfoList2.add(new OrderInfo(orderId, orderSeqNbrList2.get(z)));
                // Assigning the 2nd order seq number
                AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList2);
            }
        }
        //Save Consent Form
        SaveConsentFormWrapper.saveConsentForm(siteId, rxFillId, prescriberId, serviceId, Svc_Image_Txt, SignerName, SupervisorSignature, SupervisorName, ImmunizerSignature, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME);
        //saves Product information for multi orders
        SaveProductInformationWrapper.saveProductInformationForMultiRx(siteId, Integer.parseInt(appointmentInfo.get("lotNbr")), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamIdList2, rxFillIdList2);
        //isGaurdianSignInConsentForm
        IsGaurdianSignInConsentWrapper.getGaudrianSigninResponseDetails(siteId, String.valueOf(serviceId));
        //completes order for multi orders
        CompleteOrderWrapper.completeOrderForMultiRx(siteId, Integer.parseInt(appointmentInfo.get("lotNbr")), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamIdList2, rxFillIdList2, vaccineNameList2, serviceIdList2, patientId, prescriberId);

        Reporter.log("Completed IMZ Administration for dotcom Add Product Multi Rx");
    }

    public void performGetPaymentStatusForMultiRxAddProduct() {
        //getPaymentStatus for multi orders
        if (rxFillIdList2.size() <= 2) {
            String fillIdList = rxFillIdList2.get(0) + "," + rxFillIdList2.get(1);
            GetPaymentStatus.getPaymentStatus(siteId, fillIdList);
        } else {
            Reporter.log("rxFillIdList is not found::" + rxFillIdList2.size());
        }
    }

    public void performPOSForDotcomMultiRx() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            for (int i = 0; i < 2; i++) {
                String[] name = connexusAppUtils.readPatientNameFromFile();
                rxNbr = orderSearch.getMultiRxNbrForPatient(name[0] + "," + name[1], i);
                String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.IMZRep.getWorkQueue())) {
                    orderSearch.closeSearch();
                }
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                    am.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.POS.getWorkQueue())) {
                    am.getConnexusWorkFlow().completeOfflineSale(String.valueOf(rxNbr));
                }
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at POS queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
        }
    }


    public void createDotcomOrderToConnexusForMultiPatients(Map<String, String> appointmentInfo) {
        Reporter.log("Executing in store: " + siteId);
        //Add random names to file and read from it
        connexusAppUtils.addRandomNamesInFile();
        List<String> firstNames = new ArrayList<>();
        List<String> lastNames = new ArrayList<>();
        // Generate names for multiple patients
        for (int i = 0; i < 2; i++) {
            connexusAppUtils.addRandomNamesInFile();
            String[] patient = connexusAppUtils.readPatientNameFromFile();
            firstNames.add(patient[0]);
            lastNames.add(patient[1]);
            Log.info(patient[0] + ',' + patient[1]);
        }
        String imzType = appointmentInfo.get("serviceType");
        Map<String, String> availableSlotDetailsAndAccessPoint = PharmaIMZSlotsWrapper.getSlotDetailsAndAccessPointForMultiplePatients(
                firstNames, lastNames, imzType, siteId);
        accessPointId = availableSlotDetailsAndAccessPoint.get("ACCESS_POINT_ID");
        slotId = availableSlotDetailsAndAccessPoint.get("SLOT_ID");
        slotTime = availableSlotDetailsAndAccessPoint.get("START_TIME");
        slotDate = availableSlotDetailsAndAccessPoint.get("SLOT_DATE");
        List<String> reservationIds = SoftLockWrapper.getReservationIdsForMultiplePatients(firstNames, lastNames, slotId, siteId, accessPointId);
        appointmentId = PharmaIMZSchedulingWrapper.getAppointmentIdForMultiplePatients(appointmentInfo, siteId, slotDate, slotTime, reservationIds, accessPointId, questionsWithAllFalse(), firstNames, lastNames);
        String date = dateTimeConversion(slotDate, slotTime);
        appointmentInfo.put("appointmentId", appointmentId);
        appointmentInfo.put("reservationIds", String.join(",", reservationIds));
        appointmentInfo.put("appointmentDate", date);
        appointmentInfo.put("firstNames", String.join(",", firstNames));
        appointmentInfo.put("lastNames", String.join(",", lastNames));

        CosmosWrapper.validateDotcomAppointmentIdForMultiPatients(cosmosContext, Integer.parseInt(String.valueOf(siteId)), appointmentInfo, appointmentId);

    }

    public void verifyWorkQueueAndProblemStatusAndCreatePatients(Map<String, String> appointmentInfo) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<String> statusAndProblem = new ArrayList<>();
        List<String> firstNames = Arrays.asList(appointmentInfo.get("firstNames").split(","));
        List<String> lastNames = Arrays.asList(appointmentInfo.get("lastNames").split(","));
        try {
            for (int i = 0; i < firstNames.size(); i++) {
                Reporter.log("Creating Patient " + (i + 1));
                statusAndProblem = orderSearch.getRxStatusAndProblem(lastNames.get(i) + "," + firstNames.get(i), 0);
                rxNbr = orderSearch.getRxNbrForPatient(lastNames.get(i) + "," + firstNames.get(i), 0);
                if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Manual Resolution")) {
                    Reporter.log("Patient is in Resolve Queue");
                    am.getConnexusWorkFlow().performRphManualResolution(rxNbr);
                    Reporter.log("Unauthorised drug problem is resolved");
                }
                statusAndProblem = orderSearch.getRxStatusAndProblem(lastNames.get(i) + "," + firstNames.get(i), 0);
                Reporter.log("WorkQueue:" + statusAndProblem.get(0));
                Reporter.log("Problem:" + statusAndProblem.get(1));
                if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && "Patient Name Mismatch".equalsIgnoreCase(statusAndProblem.get(1))) {
                    patientSearchPage.openFirstPatientRecord();
                    Reporter.log("Problem is patient Name Mismatch so Resolution Page is launched to create patient");
                    performPatientSearchAndPatientCreation(appointmentInfo);
                }
            }
        } catch (Throwable e) {
            Reporter.log("Patient is not resolve queue or problem message did not match");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void completeCheckDURForMultiPatientsAndVerifySvcAdmin(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<String> statusAndProblem = new ArrayList<>();
        List<String> firstNames = Arrays.asList(inputData.get("firstNames").split(","));
        List<String> lastNames = Arrays.asList(inputData.get("lastNames").split(","));
        ResolutionPage resolutionPage = new ResolutionPage();
        try {
            for (int i = 0; i < firstNames.size(); i++) {
                Reporter.log("Processing patient " + (i + 1));
                statusAndProblem = orderSearch.getRxStatusAndProblem(lastNames.get(i) + "," + firstNames.get(i), 0);
                Log.info("WorkQueue:" + statusAndProblem.get(0));
                Log.info("problem:" + statusAndProblem.get(1));
                rxNbr = orderSearch.getRxNbrForPatient(lastNames.get(i) + "," + firstNames.get(i), 0);
                if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Future Date")) {
                    Reporter.log("Patient is in Resolve Queue with Waiting for Filling-Future Date");
                    am.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                statusAndProblem = orderSearch.getRxStatusAndProblem(lastNames.get(i) + "," + firstNames.get(i), 0);
                if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Manual Resolution")) {
                    patientSearchPage.launchOrderSearchScreen();
                    patientSearchPage.performSearch(lastNames.get(i) + "," + firstNames.get(i));
                    patientSearchPage.openFirstPatientRecord();
                    if (resolutionPage.manualResolutionVerification().contains("REASON: DUE TO RPH PRESCRIPTIVE AUTHORITY REQUIREMENTS, THIS IMMUNIZATION NEEDS ADDITIONAL ACTION BY A PHARMACIST.")) {
                        am.getConnexusWorkFlow().performRphManualResolutionForAdditionalAction(lastNames.get(i) + "," + firstNames.get(i), inputData.get("PRESCRIBER_NAME"));
                        Reporter.log("This IMMUNIZATION needs Additional action by Prescriber is resolved");
                    } else {
                        Assert.fail("Drugs not in authorised list");
                    }
                }
                String rxStatus = orderSearch.getRXStatusForPatient(lastNames.get(i) + "," + firstNames.get(i), 0);

                statusAndProblem = orderSearch.getRxStatusAndProblem(lastNames.get(i) + "," + firstNames.get(i), 0);
                if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Reject")) {
                    am.getConnexusWorkFlow().completeResolution(rxNbr);
                    Reporter.log("Invalid Reject Code is resolved");
                }
                rxStatus = orderSearch.getRXStatusForPatient(lastNames.get(i) + "," + firstNames.get(i), 0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                    am.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                rxStatus = orderSearch.getRXStatusForPatient(lastNames.get(i) + "," + firstNames.get(i), 0);
                if (connexusTestScripts.checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    am.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
                    rxStatus = orderSearch.getRXStatusForPatient(lastNames.get(i) + "," + firstNames.get(i), 0);
                    statusAndProblem = orderSearch.getRxStatusAndProblem(lastNames.get(i) + "," + firstNames.get(i), 0);
                    if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Reject")) {
                        am.getConnexusWorkFlow().completeResolution(rxNbr);
                        Reporter.log("Invalid Reject Code is resolved");
                    }
                    rxStatus = orderSearch.getRXStatusForPatient(lastNames.get(i) + "," + firstNames.get(i), 0);
                    Reporter.log("WorkQueue: " + rxStatus);
                    Assert.assertEquals(rxStatus, "svc admn", "Either RX not in chkDur/service admin queue");
                    if (connexusTestScripts.checkOrderQueueDB(rxNbr, WorkQueueSettings.ServiceAdministration.getValue(), ConnexusConstants.WAIT_TIMEOUT_10)) {
                        Reporter.log("order is in service admin ");
                    }
                }
            }
        } catch (Throwable e) {
            Reporter.log("patient is not in chkDUR queue");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performImZAdministrationForDotcomAddProductforMultiPatient(Map<String, String> appointmentInfo) {
        int patientListInfo, orderSeqNbr2, rxFillId2, serviceId2, itemMdsFamId2;
        String vaccineName2;
        List<String> firstNames = Arrays.asList(appointmentInfo.get("firstNames").split(","));
        List<String> lastNames = Arrays.asList(appointmentInfo.get("lastNames").split(","));
        for (int i = 0; i < firstNames.size(); i++) {
            Reporter.log("Administering patient : " + (i + 1) + "---" + lastNames.get(i) + "," + firstNames.get(i));
            boolean isGuardian = false;
            prescriberId = getprescriberId(appointmentInfo);
            getImzInfo = getImzInfo(siteId);
            List<Integer> orderSeqNbrList2 = new ArrayList<>();
            List<OrderInfo> orderInfoList2 = new ArrayList<>();
            List<Integer> serviceIdList2 = new ArrayList<>();
            List<Integer> itemMdsFamIdList2 = new ArrayList<>();
            List<String> vaccineNameList2 = new ArrayList<>();
            List<Integer> rxFillIdList3 = new ArrayList<>();
            String[] name = connexusAppUtils.readPatientNameFromFile();
            String expirationDate = appointmentInfo.get("expirationDate");
            int patientList = getImzInfo.getSvcOrderDetails().size();
            Reporter.log("patientList from getImZInfo:" + patientList);

            //Get IMZ info
            for (int j = 0; j < patientList; j++) {
                if (getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getLastName().equalsIgnoreCase(lastNames.get(i))) {
                    orderId = getImzInfo.getSvcOrderDetails().get(j).getOrderId();
                    orderSeqNbr = getImzInfo.getSvcOrderDetails().get(j).getOrderSeqNbr();
                    orderSeqNbrList.add(orderSeqNbr);
                    patientId = getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getPatientId();
                    rxFillId = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillId();
                    rxFillIdList.add(rxFillId);
                    serviceId = getImzInfo.getSvcOrderDetails().get(j).getService().getServiceId();
                    serviceIdList.add(serviceId);
                    itemMdsFamId = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillItem().getItemMdsFamId();
                    itemMdsFamIdList.add(itemMdsFamId);
                    vaccineName = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillItem().getShortName();
                    race = getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getRaceType();
                    ethnicity = getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getEthnicityType();
                    vaccineNameList.add(vaccineName);
                    Reporter.log("orderId:" + orderId + "\t  patientId:" + patientId + "\t  rxFillId:" + rxFillId + "\t  serviceId:" + serviceId + "\t  itemMdsFamId:" + itemMdsFamId + "\t orderSeqNbr:" + orderSeqNbr);
                }
            }
            for (int z = 0; z < orderSeqNbrList.size(); z++) {
                orderInfoList.add(new OrderInfo(orderId, orderSeqNbrList.get(z)));
                if (orderSeqNbrList.get(z) == 1) {
                    // Assigning the 1st order seq number
                    AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);
                    //getIMZRecommendations
                    GetIMZRecommendationsWrapper.getIMZRecommendationsForNewPatient(siteId, patientId, ASSIGNED_USER_ID_AUT_TEST);
                    //get onlinequestionnarie form
                    OnlineQuestionnarieFormWrapper.getOnlineQuestionnarieForm(siteId, String.valueOf(serviceId));

                    //save Questionnarie form
                    OnlineQuestionnarieFormWrapper.saveOnlineQuestionnarieForm(siteId, questionsWithAllFalse(), String.valueOf(serviceId), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, prescriberId, isGuardian);
                }
                break;
            }
            orderInfoList.clear();
            //Get Authorized IMZDrugs
            GetAuthorizedIMZDrugs getAuthImzDrugs = getAuthorizedIMZDrugs(siteId, String.valueOf(patientId));
            int productList = getAuthImzDrugs.getImzProductDetails().size();
            Log.info("ProductList from GetAuthorizedIMZDrugs:" + productList);

            for (int k = 0; k < productList; k++) {
                productMdsFamId = getAuthImzDrugs.getImzProductDetails().get(0).getProductMdsFamId();
                Reporter.log("productMdsFamId:" + productMdsFamId);
                break;
            }
            //Add IMZDrug - adding 2nd drug
            AddIMZDrugWrapper.addIMZDrug(orderId, productMdsFamId, patientId, ASSIGNED_USER_ID_AUT_TEST, siteId, WORK_STATION_HOST_NAME);
            loginConnexus(LoginAs.userType.PHARMACIST_ADFlagOff);
            //perform chkDur - for 2nd rxNbr
            Reporter.log("Performing CheckDUR for 2nd RX");
            checkAndPerformCheckDURforAddProduct(appointmentInfo, i);
            //Get IMZ info - getting 2nd order seq number
            getImzInfo = getImzInfo(siteId);
            patientListInfo = getImzInfo.getSvcOrderDetails().size();

            Log.info("patientList from getImZInfo:" + patientList);
            for (int j = 0; j < patientListInfo; j++) {
                if (getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getLastName().equalsIgnoreCase(lastNames.get(i))) {
                    orderId = getImzInfo.getSvcOrderDetails().get(j).getOrderId();
                    orderSeqNbr2 = getImzInfo.getSvcOrderDetails().get(j).getOrderSeqNbr();
                    orderSeqNbrList2.add(orderSeqNbr2);
                    patientId = getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getPatientId();
                    rxFillId2 = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillId();
                    rxFillIdList3.add(rxFillId2);
                    serviceId2 = getImzInfo.getSvcOrderDetails().get(j).getService().getServiceId();
                    serviceIdList2.add(serviceId2);
                    itemMdsFamId2 = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillItem().getItemMdsFamId();
                    itemMdsFamIdList2.add(itemMdsFamId2);
                    vaccineName2 = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillItem().getShortName();
                    vaccineNameList2.add(vaccineName2);
                    vaccineName = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillItem().getShortName();
                    race = getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getRaceType();
                    ethnicity = getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getEthnicityType();
                    vaccineNameList.add(vaccineName);
                    Reporter.log("orderId:" + orderId + "\t  patientId:" + patientId + "\t  rxFillId:" + rxFillId2 + "\t  serviceId:" + serviceId2 + "\t  itemMdsFamId:" + itemMdsFamId2 + "\t orderSeqNbr:" + orderSeqNbr2);
                }
            }
            Poller poller = new Poller(30, 2000);
            poller.pollForSuccess(() -> {
                for (int z = 0; z < orderSeqNbrList2.size(); z++) {
                    if (orderSeqNbrList2.get(z) == 2) {
                        orderInfoList2.add(new OrderInfo(orderId, orderSeqNbrList2.get(z)));
                        // Assigning the 2nd order seq number
                        AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList2);
                    }
                }
                return true;
            });

            //Save Consent Form
            SaveConsentFormWrapper.saveConsentForm(siteId, rxFillId, prescriberId, serviceId, Svc_Image_Txt,
                    SignerName, SupervisorSignature, SupervisorName, ImmunizerSignature, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME);
            //saves Product information for multi orders
            SaveProductInformationWrapper.saveProductInformationForMultiRx(siteId, Integer.parseInt(appointmentInfo.get("lotNbr")),
                    ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamIdList2, rxFillIdList3);
            //isGaurdianSignInConsentForm
            IsGaurdianSignInConsentWrapper.getGaudrianSigninResponseDetails(siteId, String.valueOf(serviceId));
            //completes order for multi orders
            CompleteOrderWrapper.completeOrderForMultiRx(siteId, Integer.parseInt(appointmentInfo.get("lotNbr")),
                    ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamIdList2, rxFillIdList3, vaccineNameList2, serviceIdList2, patientId, prescriberId);

            Reporter.log("Completed IMZ Administration for dotcom Add Product Multi Rx");
            connexusAppUtils.validateProductCountofPatient(patientId);
            connexusAppUtils.validateOrderSeqcountofOrder(orderId);
        }
    }

    public void checkAndPerformCheckDURforAddProduct(Map<String, String> appointmentInfo, int i) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<String> firstNames = Arrays.asList(appointmentInfo.get("firstNames").split(","));
        List<String> lastNames = Arrays.asList(appointmentInfo.get("lastNames").split(","));
        try {
            Reporter.log("Processing patient " + "---" + lastNames.get(i) + "," + firstNames.get(i));
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(lastNames.get(i) + "," + firstNames.get(i));
            logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            rxNbr = orderSearch.getMultiRxNbrForPatient(lastNames.get(i) + "," + firstNames.get(i), 0);
            String rxStatus = orderSearch.getRXStatusForPatient(lastNames.get(i) + "," + firstNames.get(i), 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                Reporter.log("WorkQueue: " + rxStatus);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
                Reporter.log("WorkQueue: " + rxStatus);
            }
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                am.getConnexusWorkFlow().completeResolution(rxNbr);
            }

            rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                Reporter.log("WorkQueue: " + rxStatus);
                am.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.SVC_ADMIN.getWorkQueue())) {
                Reporter.log("WorkQueue: " + rxStatus);
                Assert.assertEquals(rxStatus, "svc admn", "order is not in service admin queue");
                Reporter.log("order is in service admin ");
            }

        } catch (Throwable e) {
            Reporter.log("Test failed at ChkDUR");
            e.printStackTrace();
            Assert.fail(e.toString());
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
        }


    }


    public void performPOSForMultiPatientsWithMultiRx(Map<String, String> appointmentInfo) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<Integer> multiRxNbr = new ArrayList<>();
        List<String> firstNames = Arrays.asList(appointmentInfo.get("firstNames").split(","));
        List<String> lastNames = Arrays.asList(appointmentInfo.get("lastNames").split(","));
        try {
            for (int i = 0; i < firstNames.size(); i++) {
                Reporter.log("Processing POS for patient: " + firstNames.get(i) + " " + lastNames.get(i));
                String patientid = connexusAppUtils.getPatientId(lastNames.get(i), firstNames.get(i));
                multiRxNbr = getMultiRxNbrFromPatientId(siteId, Integer.parseInt(patientid));
                for (int j = 0; j < multiRxNbr.size(); j++) {
                    rxNbr = String.valueOf(multiRxNbr.get(i));
                    String patientName = lastNames.get(i) + "," + firstNames.get(i);
                    rxNbr = orderSearch.getMultiRxNbrForPatient(patientName, j);
                    String rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
                    if (rxStatus.equalsIgnoreCase(WorkQueue.IMZRep.getWorkQueue())) {
                        orderSearch.closeSearch();
                    }
                    rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
                    if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                        am.getConnexusWorkFlow().completeResolution(rxNbr);
                    }
                    rxStatus = orderSearch.getRXStatusForPatient(rxNbr, 0);
                    if (rxStatus.equalsIgnoreCase(WorkQueue.POS.getWorkQueue())) {
                        am.getConnexusWorkFlow().completeOfflineSale(String.valueOf(rxNbr));
                    }
                }
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at POS queue");
            e.printStackTrace();
            Assert.fail(e.toString());
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
        }
    }


    public void performIMZAdministrationForMultiPatients(Map<String, String> appointmentInfo) {
        List<String> firstNames = Arrays.asList(appointmentInfo.get("firstNames").split(","));
        List<String> lastNames = Arrays.asList(appointmentInfo.get("lastNames").split(","));
        for (int i = 0; i < firstNames.size(); i++) {
            Reporter.log("Administering patient : " + (i + 1));
            prescriberId = getprescriberId(appointmentInfo);
            boolean isGuardian = false;
            String dobKey = i == 0 ? "patDob" : "patDob2";
            String patientDOB = appointmentInfo.get(dobKey);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate birthDate = LocalDate.parse(patientDOB, formatter);
            LocalDate currentDate = LocalDate.now();
            int age = Period.between(birthDate, currentDate).getYears();
            GetImzInfo getImzInfo = getImzInfo(siteId);
            String expirationDate = appointmentInfo.get("expirationDate");
            int patientListSize = getImzInfo.getSvcOrderDetails().size();
            Log.info("patientList from getImZInfo:" + patientListSize);
            for (int j = 0; j < patientListSize; j++) {
                if (getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getLastName()
                        .equalsIgnoreCase(lastNames.get(i))) {
                    orderId = getImzInfo.getSvcOrderDetails().get(j).getOrderId();
                    orderSeqNbr = getImzInfo.getSvcOrderDetails().get(j).getOrderSeqNbr();
                    patientId = getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getPatientId();
                    rxFillId = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillId();
                    serviceId = getImzInfo.getSvcOrderDetails().get(j).getService().getServiceId();
                    itemMdsFamId = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillItem().getItemMdsFamId();
                    productMdsFamId = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillItem().getProductMdsFamId();
                    vaccineName = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillItem().getShortName();
                    race = getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getRaceType();
                    ethnicity = getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getEthnicityType();

                    Reporter.log("orderId:" + orderId + "patientId:" + patientId + "rxFillId:" + rxFillId + "serviceId:" + serviceId + "itemMdsFamId:" + itemMdsFamId + "productItemMdsFamId:" + productMdsFamId + "vaccineName:" + vaccineName + "race:" + race + "ethnicity:" + ethnicity);
                }
            }
            List<OrderInfo> orderInfoList = new ArrayList<>();
            orderInfoList.add(new OrderInfo(orderId, orderSeqNbr));
            // Assigning the order
            AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);
            //getIMZRecommendations
            GetIMZRecommendationsWrapper.getIMZRecommendationsForNewPatient(siteId, patientId, ASSIGNED_USER_ID_AUT_TEST);
            //get onlinequestionnarie form
            OnlineQuestionnarieFormWrapper.getOnlineQuestionnarieForm(siteId, String.valueOf(serviceId));
            //save Questionnarie form
            if (age < 18) {
                isGuardian = true;
                OnlineQuestionnarieFormWrapper.saveOnlineQuestionnarieForm(siteId, questionsWithAllFalse(), String.valueOf(serviceId), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, prescriberId, isGuardian);
                //saves Product information
                SaveProductInformationWrapper.saveProductInformation(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId);
                //isGaurdianSignInConsentForm
                IsGaurdianSignInConsentWrapper.assertGuardianSignInRequired(siteId, String.valueOf(serviceId), age);
                //completes order
                CompleteOrderWrapper.completeOrderForGuardian(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId, vaccineName, serviceId, patientId, prescriberId, appointmentInfo.get("GUARDIAN_FNAME"), appointmentInfo.get("GUARDIAN_LNAME"), Integer.parseInt(appointmentInfo.get("GUARDIAN_RELATION_CODE")));
                Reporter.log("Completed IMZ Administration for dotcom order through APIs");
            } else {
                OnlineQuestionnarieFormWrapper.saveOnlineQuestionnarieForm(siteId, questionsWithAllFalse(), String.valueOf(serviceId), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, prescriberId, isGuardian);
                //saves Product information
                SaveProductInformationWrapper.saveProductInformation(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId);
                //isGaurdianSignInConsentForm
                IsGaurdianSignInConsentWrapper.getGaudrianSigninResponseDetails(siteId, String.valueOf(serviceId));
                //completes order
                CompleteOrderWrapper.completeOrder(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId, vaccineName, serviceId, patientId, prescriberId);
                Reporter.log("Completed IMZ Administration for dotcom order through APIs");
            }
        }
    }
    public void performIMZAdministrationForMultiPatientsTechAdmin(Map<String, String> appointmentInfo) {
        List<String> firstNames = Arrays.asList(appointmentInfo.get("firstNames").split(","));
        List<String> lastNames = Arrays.asList(appointmentInfo.get("lastNames").split(","));
        for (int i = 0; i < firstNames.size(); i++) {
            Reporter.log("Administering patient : " + (i + 1));
            prescriberId = getprescriberId(appointmentInfo);
            boolean isGuardian = false;
            String dobKey = i == 0 ? "patDob" : "patDob2";
            String patientDOB = appointmentInfo.get(dobKey);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate birthDate = LocalDate.parse(patientDOB,formatter);
            LocalDate currentDate = LocalDate.now();
            int age = Period.between(birthDate,currentDate).getYears();
            GetImzInfo getImzInfo = getImzInfo(siteId);
            String expirationDate = appointmentInfo.get("expirationDate");
            int patientListSize = getImzInfo.getSvcOrderDetails().size();
            Log.info("patientList from getImZInfo:" + patientListSize);
            for (int j = 0; j < patientListSize; j++) {
                if (getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getLastName()
                        .equalsIgnoreCase(lastNames.get(i))) {
                    orderId = getImzInfo.getSvcOrderDetails().get(j).getOrderId();
                    orderSeqNbr = getImzInfo.getSvcOrderDetails().get(j).getOrderSeqNbr();
                    patientId = getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getPatientId();
                    rxFillId = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillId();
                    serviceId = getImzInfo.getSvcOrderDetails().get(j).getService().getServiceId();
                    itemMdsFamId = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillItem().getItemMdsFamId();
                    productMdsFamId = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillItem().getProductMdsFamId();
                    vaccineName = getImzInfo.getSvcOrderDetails().get(j).getRxFill().getRxFillItem().getShortName();
                    race = getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getRaceType();
                    ethnicity = getImzInfo.getSvcOrderDetails().get(j).getService().getPatient().getEthnicityType();

                    Reporter.log("orderId:" + orderId + "patientId:" + patientId + "rxFillId:" + rxFillId + "serviceId:" + serviceId + "itemMdsFamId:" + itemMdsFamId + "productItemMdsFamId:" + productMdsFamId + "vaccineName:" + vaccineName + "race:" + race + "ethnicity:" + ethnicity);
                }
            }
            List<OrderInfo> orderInfoList = new ArrayList<>();
            orderInfoList.add(new OrderInfo(orderId, orderSeqNbr));
            // Assigning the order
            AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);
            //getIMZRecommendations
            GetIMZRecommendationsWrapper.getIMZRecommendationsForNewPatient(siteId, patientId, ASSIGNED_USER_ID_AUT_TEST);
            //get onlinequestionnarie form
            OnlineQuestionnarieFormWrapper.getOnlineQuestionnarieForm(siteId, String.valueOf(serviceId));
            //save Questionnarie form
            if(age<18)
            {
                isGuardian =true;
                OnlineQuestionnarieFormWrapper.saveOnlineQuestionnarieForm(siteId, questionsWithAllFalse(), String.valueOf(serviceId), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, prescriberId, isGuardian);
                //saves Product information
                SaveProductInformationWrapper.saveProductInformation(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId);
                //isGaurdianSignInConsentForm
                IsGaurdianSignInConsentWrapper.assertGuardianSignInRequired(siteId, String.valueOf(serviceId),age);
                //Unassign the orders
                UnassignOrdersWrapper.unassignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);
                //Assign the orders to Technician
                AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_TECH_ID, WORK_STATION_HOST_NAME, orderInfoList);
                //completes order as Technician
                CompleteOrderWrapper.completeOrderForGuardian(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_TECH_ID, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId, vaccineName, serviceId, patientId, prescriberId, appointmentInfo.get("GUARDIAN_FNAME"), appointmentInfo.get("GUARDIAN_LNAME"), Integer.parseInt(appointmentInfo.get("GUARDIAN_RELATION_CODE")));
                Reporter.log("Completed IMZ Administration for dotcom order through APIs");
            }
            else {
                OnlineQuestionnarieFormWrapper.saveOnlineQuestionnarieForm(siteId, questionsWithAllFalse(), String.valueOf(serviceId), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, prescriberId, isGuardian);
                //saves Product information
                SaveProductInformationWrapper.saveProductInformation(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId);
                //isGaurdianSignInConsentForm
                IsGaurdianSignInConsentWrapper.getGaudrianSigninResponseDetails(siteId, String.valueOf(serviceId));
                //Unassign the orders
                UnassignOrdersWrapper.unassignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);
                //Assign the orders to Technician
                AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_TECH_ID, WORK_STATION_HOST_NAME, orderInfoList);
                //completes order as Technician
                CompleteOrderWrapper.completeOrder(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_TECH_ID, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId, vaccineName, serviceId, patientId, prescriberId);
                Reporter.log("Completed IMZ Administration for dotcom order through APIs");
            }
        }
    }

    public void performPOSForMultiPatients(Map<String, String> appointmentInfo) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<String> firstNames = Arrays.asList(appointmentInfo.get("firstNames").split(","));
        List<String> lastNames = Arrays.asList(appointmentInfo.get("lastNames").split(","));
        try {
            for (int i = 0; i < firstNames.size(); i++) {
                Reporter.log("Moving to EOD patient-" + (i + 1));
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(lastNames.get(i) + "," + firstNames.get(i));
                String rxStatus = orderSearch.getWorkQueue(0);
                rxNbr = orderSearch.getRxNbrForPatient(lastNames.get(i) + "," + firstNames.get(i), 0);
                if (rxStatus.equalsIgnoreCase(WorkQueue.POS.getWorkQueue())) {
                    am.getConnexusWorkFlow().completeOfflineSale(String.valueOf(rxNbr));
                    rxStatus = orderSearch.getWorkQueue(0);
                    Reporter.log("WorkQueue: " + rxStatus);
                    if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                        if (orderSearch.getProblemMessage(0).contains("Down Time")) {
                            am.getConnexusWorkFlow().completeResolution(String.valueOf(rxNbr));
                        }
                    }
                    if (rxStatus.equalsIgnoreCase(WorkQueue.EOD.getWorkQueue())) {
                        orderSearch.closeSearch();
                    }

                } else {
                    Reporter.log("RX is not in POS queue");
                    Assert.fail("RX is not in POS queue");
                }
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at POS queue");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyServiceDetailsInPMSForMultiPatients(Map<String, String> appointmentInfo,boolean isTechnician) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        prescriberId = getprescriberId(appointmentInfo);
        List<String> firstNames = Arrays.asList(appointmentInfo.get("firstNames").split(","));
        List<String> lastNames = Arrays.asList(appointmentInfo.get("lastNames").split(","));
        try {
            for (int i = 0; i < firstNames.size(); i++) {
                Reporter.log("Validating Service Details in PMS for Patient-" + (i + 1));
                patientSearchPage.launchPatientSearchScreen();
                Reporter.log("Patient Name" + lastNames.get(i) + "," + firstNames.get(i));
                patientSearchPage.inputPatientName(lastNames.get(i) + "," + firstNames.get(i));
                String dobKey = i == 0 ? "DOB" : "DOB2";
                String DOB = appointmentInfo.get(dobKey);
                if (appointmentInfo.containsKey(dobKey)) {
                    Reporter.log("DOB" + DOB);
                    patientSearchPage.inputPatientDob(DOB);
                }
                patientSearchPage.clickSearchNow();
                patientSearchPage.openFirstPatientRecord();
                patientMaintenancePage.clickClinicalServicesTab();
                logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
                Reporter.log("clicked on clinical services");
                //verify race and Ethnicity
                Reporter.log("Verifying race and ethicity from PMS");
                String raceFromPMS = patientMaintenancePage.getRace();
                Assert.assertEquals(raceFromPMS, race, "race did not match");
                String ethnicityFromPMS = patientMaintenancePage.getEthinicty();
                Assert.assertEquals(ethnicityFromPMS, ethnicity, "ethicity did not match");
                Reporter.log("Verified race and enthnicity on PMS with expected values passed while creation of order");
                //verify rxFillID,Status and click serviceDetails Button
                patientMaintenancePage.clickServiceHistory(1);
                patientMaintenancePage.selectActiveRxFillIdRow(rxFillId);
                Assert.assertTrue(patientMaintenancePage.isServiceDetailsEnabled());
                patientMaintenancePage.clickServiceDetails();
                Reporter.log("Assert: Validation of RxfillId details is completed");
                logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
                //verify lot Numbers
                Assert.assertEquals(patientMaintenancePage.getLotNo(), appointmentInfo.get("lotNbr"), "lot numbers are different");
                Reporter.log("Assert: validation of Actual lot numbers with expected is completed");
                //verify Administrated BY
                if(isTechnician) {
                    String administerName = patientMaintenancePage.getAdministratorValue().trim();
                    Assert.assertEquals(administerName, appointmentInfo.get("TECHNICIAN_NAME"), "person administrated by doesnot match");
                } else {
                    String administerName = patientMaintenancePage.getAdministratorValue().trim();
                    Assert.assertEquals(administerName, appointmentInfo.get("PRESCRIBER_NAME"), "person administrated by doesnot match");
                }
                Reporter.log("Assert: Validation of Administrated by with given value is completed");
                //verify IMZRegistryNotify
                String todaysDate = getCurrentDate("MM/dd/yyyy");
                String imzRegistryDateTime = patientMaintenancePage.getImzAdministry();
                String imzReg[] = imzRegistryDateTime.split(" ");
                Assert.assertEquals(imzReg[0].trim(), todaysDate.trim(), "Notify date is not matched");
                logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
                Reporter.log("Assert: Validation of IMZRegistryNotify Date is completed");
                //verify VIS PublishDate
                String productMdsFamIdKey = i == 0 ? "productMdsFamId" : "productMdsFamId2";
                productMdsFamId = Long.valueOf(appointmentInfo.get(productMdsFamIdKey));
                Reporter.log("ProductMdsFamId " + productMdsFamId);
                String visPubDate = getVisPubFromDB();
                Log.info("visPubdate" + visPubDate);
                if (visPubDate == null) {
                    visPubDate = todaysDate.trim();
                    Assert.assertEquals(visPubDate, patientMaintenancePage.getVISPublishDate().trim(), "VIS Publish Date did not Matched");
                    Reporter.log("Assert: Validation of VIS PublishDate from PMS is completed");
                } else {
                    visPubDate = dateConversion(visPubDate);
                    Assert.assertEquals(visPubDate, patientMaintenancePage.getVISPublishDate().trim(), "VIS Publish Date did not Matched");
                    Reporter.log("Assert: Validation of VIS PublishDate from PMS is completed");
                }
                //verify VIS GivenDate
                Assert.assertNotNull(patientMaintenancePage.getVISGivenDate(), "VIS Given Date is  null");
                Assert.assertEquals(todaysDate, patientMaintenancePage.getVISGivenDate().trim(), "VIS GIVEN Date is Matched");
                Reporter.log("Assert: Validation of VIS GivenDate from PMS is completed");

                //Clikcing IMZForm and check for IMZForm
                patientMaintenancePage.clickImzForm();
                Boolean pqcfImg = patientMaintenancePage.verifyPvImage();
                Assert.assertTrue(pqcfImg, "PQCF Image doesnot exist");
                am.performSleep(3);
                logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
                //closes IMZ form
                patientMaintenancePage.clickExit();
                //closes services administration page
                patientMaintenancePage.clickExit();
                patientMaintenancePage.clickYes();
                //closes clinical services page
                patientMaintenancePage.clickSaveAndClose();
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at PatientMaintainance page");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validationOfDataInCosmosForMultiPatients(Map<String, String> appointmentInfo) {
        List<String> firstNames = Arrays.asList(appointmentInfo.get("firstNames").split(","));
        List<String> lastNames = Arrays.asList(appointmentInfo.get("lastNames").split(","));
        List<String> reservationIds = Arrays.asList(appointmentInfo.get("reservationIds"));
        List<String> patientIds = new ArrayList<>();
        for (int i = 0; i < firstNames.size(); i++) {
            String patientId = connexusAppUtils.getPatientId(lastNames.get(i), firstNames.get(i));
            patientIds.add(String.valueOf(patientId));
            String date = dateTimeConversion(slotDate, slotTime);
            appointmentInfo.put("appointmentId", appointmentId);
            appointmentInfo.put("reservationIds", String.join(",", reservationIds));
            appointmentInfo.put("appointmentDate", date);
            appointmentInfo.put("firstNames", String.join(",", firstNames));
            appointmentInfo.put("lastNames", String.join(",", lastNames));
            appointmentInfo.put("patientIds", String.join(",", patientIds));
        }
        CosmosWrapper.validateDotcomAppointmentIdPostAdministrationForMultiPatients(cosmosContext, Integer.parseInt(String.valueOf(siteId)), appointmentInfo, appointmentId);
    }

    public void validateCovidProductNotPresentInCycleCount(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        menuBar.selectNavigation(AppMenu.CYCLE_COUNT, AppMenuItemsIndex.INVENTORY_REPORTS,
                AppMenuSubItemsIndex.CYCLE_COUNT_REPORT, null);
        IsVisible = cycleCountReportPage.isCycleCountVisble();
        Assert.assertFalse(IsVisible, "Cycle count Page is not opened");
        orderNDC = inputData.get("DRUG_NAME");
        currentDate = ConnexusAppUtils.getCurrentTimestamp("M/d/yyyy");
        Reporter.log("Validating that NDC used to drop Order: " + orderNDC + "is not present in today's date entries-" + currentDate);
        IsTodayDateAvailable = cycleCountReportPage.sortAndCheckTodayDateInCreateDate();
        logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
        if (!IsTodayDateAvailable) {
            Reporter.log("No entries found with Today's date-" + currentDate + "in Cycle Count Report");
            return;
        }
        IsNDCPresent = false;
        int rowIndex = 0;
        while (true) {
            try {
                String createDate = cycleCountReportPage.getCreateDateByRow(rowIndex);
                if (createDate == null || createDate.trim().isEmpty()) {
                    Reporter.log("No entries present at all in Cycle Count Page");
                    break;
                }
                if (createDate.trim().equals(currentDate.trim())) {
                    String ndcFromReport = cycleCountReportPage.getNdcNbr(rowIndex);
                    if (ndcFromReport.equalsIgnoreCase(orderNDC)) {
                        IsNDCPresent = true;
                        break;
                    }
                }
                rowIndex++;
            } catch (Exception e) {
                e.printStackTrace();
                break;
            }
        }
        Assert.assertFalse(IsNDCPresent, "NDC used to place order is present in Cycle Count Report Page");
        Reporter.log("Validated NDC used to place order is NOT present in Cycle Count Report Page");
    }

    public void validateDualLicencePrescriber(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            prescriberSearchPage.launchPrescriberSearchScreen();
            prescriberSearchPage.inputPrescriberName(inputData.get("PRESCRIBER_NAME"));
            prescriberSearchPage.clickSearchStore();
            prescriberSearchPage.doubleClickOnSearchGridRow(0);

            List<String> stateLicenses = new ArrayList<>();
            int totalRows = prescriberSearchPage.getTotalIdentifierRows();

            for (int i = 0; i < totalRows - 1; i++) {
                String license = prescriberSearchPage.prescriberIdentifierRow(i);
                stateLicenses.add(license.trim());
            }
            Reporter.log("Found state license details from UI: " + stateLicenses);
            getPrescriberLicenseTbl = connexusAppUtils.getLicenseDetailsFromPrescriber(inputData.get("PRESCRIBER_NAME"));
            if (getPrescriberLicenseTbl == null) {
                throw new IllegalStateException("No license details found in the database for the given prescriber.");
            }
            Collections.sort(stateLicenses);
            Collections.sort(getPrescriberLicenseTbl);
            Assert.assertEquals(stateLicenses, getPrescriberLicenseTbl, "License numbers do not match between UI and DB.");
            Reporter.log("Validated: License numbers match between UI and DB.");
            logScreenshotSafely(Status.PASS, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName));
            prescriberSearchPage.clickCancelButtonOnPrescriberMaintenanceWindow();
        } catch (Exception e) {
            Reporter.log("Test failed at Prescriber Dual Licence details due to an unexpected error." + e.getMessage());
            logScreenshotSafely(Status.FAIL, currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void validateRxImageDetailsInPMS(Map<String, String> appointmentInfo) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            Reporter.log("Patient Name: " + name[0] + "," + name[1]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.inputPatientDob(appointmentInfo.get("DOB"));
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickClinicalServicesTab();
            logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Reporter.log("clicked on clinical services");

            //verify rxFillID,Status and click serviceDetails Button
            patientMaintenancePage.selectActiveRxFillIdRow(rxFillId);
            Assert.assertTrue(patientMaintenancePage.isServiceDetailsEnabled());
            patientMaintenancePage.clickServiceDetails();
            Reporter.log("Validation of RxfillId details is completed");

            //Click RxImage and validate license number in pvImage
            patientMaintenancePage.clickRxImage();
            logScreenshotSafely(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName));
            patientMaintenancePage.verifyRxPvImageContent(appointmentInfo);
            patientMaintenancePage.clickPbMinImg();
            Boolean rxPvImage = patientMaintenancePage.verifyPvImage();
            Assert.assertTrue(rxPvImage, "Rx pvImage doesnot exist");
            patientMaintenancePage.handleRxImagePopup();
            logScreenshotSafely(Status.PASS, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName));

            //closes IMZ form
            patientMaintenancePage.clickExit();
            //closes services administration page
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();
            //closes clinical services page
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            Reporter.log("Test failed at RxImage content in PMS");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, patientMaintenancePage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void performImZAdministrationMultiRx(Map<String, String> appointmentInfo) {
        prescriberId = getprescriberId(appointmentInfo);
        boolean isGuardian = false;
        String relationCode = appointmentInfo.get("GUARDIAN_RELATION_CODE");
        GetImzInfo getImzInfo = getImzInfo(siteId);
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String firstName = name[0];
        String lastName = name[1];
        String expirationDate = appointmentInfo.get("expirationDate");
        int patientList = getImzInfo.getSvcOrderDetails().size();
        Log.info("patientList from getImZInfo:" + patientList);
        Log.info("patientList from getImZInfo:" + patientList);
        List<Integer> orderSeqNbrList = new ArrayList<>();
        List<Integer> rxFillIdList = new ArrayList<>();
        List<Integer> serviceIdList = new ArrayList<>();
        List<Integer> itemMdsFamIdList = new ArrayList<>();
        List<String> vaccineNameList = new ArrayList<>();


        //Get IMZ info

        for (int i = 0; i < patientList; i++) {
            if (getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getLastName()
                    .equalsIgnoreCase(name[0])) {
                orderId = getImzInfo.getSvcOrderDetails().get(i).getOrderId();
                orderSeqNbr = getImzInfo.getSvcOrderDetails().get(i).getOrderSeqNbr();
                orderSeqNbrList.add(orderSeqNbr);
                patientId = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getPatientId();
                rxFillId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillId();
                rxFillIdList.add(rxFillId);
                serviceId = getImzInfo.getSvcOrderDetails().get(i).getService().getServiceId();
                serviceIdList.add(serviceId);
                itemMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getItemMdsFamId();

                productMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getProductMdsFamId();
                itemMdsFamIdList.add(itemMdsFamId);
                vaccineName = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getShortName();
                vaccineNameList.add(vaccineName);
                race = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getRaceType();
                ethnicity = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getEthnicityType();

                Reporter.log("orderId:" + orderId + "patientId:" + patientId + "rxFillId:" + rxFillId + "serviceId:" + serviceId + "itemMdsFamId:" + itemMdsFamId + "productItemMdsFamId:" + productMdsFamId + "vaccineName:" + vaccineName + "race:" + race + "ethnicity:" + ethnicity);
            }
        }

        List<OrderInfo> orderInfoList = new ArrayList<>();
        for (int z = 0; z < orderSeqNbrList.size(); z++) {
            orderInfoList.add(new OrderInfo(orderId, orderSeqNbrList.get(z)));
        }
        // Assigning the order
        AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);

        //get onlinequestionnarie form
        OnlineQuestionnarieFormWrapper.getOnlineQuestionnarieForm(siteId, String.valueOf(serviceId));
        //save Questionnarie form
        OnlineQuestionnarieFormWrapper.saveOnlineQuestionnarieForm(siteId, questionsWithAllFalse(), String.valueOf(serviceId), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, prescriberId, isGuardian);

        //saves Product information
        SaveProductInformationWrapper.saveProductInformationForMultiRx(siteId, Integer.parseInt(appointmentInfo.get("lotNbr")), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamIdList, rxFillIdList);
        //isGaurdianSignInConsentForm
        IsGaurdianSignInConsentWrapper.getGaudrianSigninResponseDetails(siteId, String.valueOf(serviceId));
        //completes order
        if (relationCode != null && !relationCode.isEmpty() && "318".equals(relationCode)) {
            CompleteOrderWrapper.completeOrderForGuardianForMultiRx(siteId, Integer.parseInt(appointmentInfo.get("lotNbr")), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamIdList, rxFillIdList, vaccineName, serviceIdList, patientId, prescriberId, firstName, lastName, Integer.parseInt(appointmentInfo.get("GUARDIAN_RELATION_CODE")));
        } else if (relationCode != null && !relationCode.isEmpty() && "321".equals(relationCode)) {
            CompleteOrderWrapper.completeOrderForGuardianForMultiRx(siteId, Integer.parseInt(appointmentInfo.get("lotNbr")), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamIdList, rxFillIdList, vaccineName, serviceIdList, patientId, prescriberId, appointmentInfo.get("GUARDIAN_FNAME"), appointmentInfo.get("GUARDIAN_LNAME"), Integer.parseInt(appointmentInfo.get("GUARDIAN_RELATION_CODE")));
        } else {
            CompleteOrderWrapper.completeOrderForMultiRx(siteId, Integer.parseInt(appointmentInfo.get("lotNbr")), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamIdList, rxFillIdList, vaccineNameList, serviceIdList, patientId, prescriberId);
        }
        Reporter.log("Completed IMZ Administration for dotcom order through APIs");
    }

    public List<Integer> getMultiRxNbrFromPatientId(int siteId, int patientId) {
        List<Integer> rxNbrList = new ArrayList<>();
        String query = "select rx_nbr from rx where patient_id = " + patientId + ";";

        Poller poller = new Poller(5, 2000); // 30 attempts, 2 second delay
        poller.pollForSuccess(() -> {
            List<Map<String, Object>> resultSet = am.getConnexusDB(siteId)
                    .executeQueryForList(query);

            if (resultSet != null && !resultSet.isEmpty()) {
                rxNbrList.clear();
                for (Map<String, Object> row : resultSet) {
                    int rxNbr = ((Number) row.get("rx_nbr")).intValue();
                    rxNbrList.add(rxNbr);
                }
                return true;
            }
            return false;
        });

        return rxNbrList;
    }

    public void checkAndPerformMultiCheckDUR(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientId = getPatientIdFromName();
            multiRxNbr = getMultiRxNbrFromPatientId(siteId, patientId);
            for (int i = 0; i < multiRxNbr.size(); i++) {
                rxNbr = String.valueOf(multiRxNbr.get(i));
                statusAndProblem = orderSearch.getRxStatusAndProblem(rxNbr, 0);
                Log.info("WorkQueue:" + statusAndProblem.get(0));
                Log.info("problem:" + statusAndProblem.get(1));
                if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Future Date")) {
                    Reporter.log("Patient is in Resolve Queue with Waiting for Filling-Future Date");
                    am.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                statusAndProblem = orderSearch.getRxStatusAndProblem(rxNbr, 0);
                if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Manual Resolution")) {
                    patientSearchPage.launchOrderSearchScreen();
                    patientSearchPage.performSearch(rxNbr);
                    patientSearchPage.openFirstPatientRecord();
                    if (resolutionPage.manualResolutionVerification().contains("REASON: DUE TO RPH PRESCRIPTIVE AUTHORITY REQUIREMENTS, THIS IMMUNIZATION NEEDS ADDITIONAL ACTION BY A PHARMACIST.")) {
                        am.getConnexusWorkFlow().performRphManualResolutionForAdditionalAction(rxNbr, inputData.get("PRESCRIBER_NAME"));
                        Reporter.log("This IMMUNIZATION needs Additional action by Prescriber is resolved");
                    }
                }
                statusAndProblem = orderSearch.getRxStatusAndProblem(rxNbr, 0);
                if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Reject")) {
                    am.getConnexusWorkFlow().completeResolution(rxNbr);
                    Reporter.log("Invalid Reject Code is resolved");
                }
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(),ConnexusConstants.WAIT_TIMEOUT_20)) {
                    am.getConnexusWorkFlow().completeResolution(rxNbr);
                }
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.CheckDUR.getValue(),ConnexusConstants.WAIT_TIMEOUT_40)) {
                    am.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
                }else if (checkOrderQueueDB(rxNbr, WorkQueueSettings.ServiceAdministration.getValue())) {
                    Reporter.log("order is in service admin ");
                }
            }
        } catch (Throwable e) {
            Reporter.log("patient is not in chkDUR queue");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyWorkQueueStatusAsServiceAdminMulti() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientId = getPatientIdFromName();
            multiRxNbr = getMultiRxNbrFromPatientId(siteId, patientId);
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentrxNbr = String.valueOf(multiRxNbr.get(i));
                if (checkOrderQueueDB(currentrxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    automationManager.getConnexusWorkFlow().completeResolution(currentrxNbr);
                }
                if (checkOrderQueueDB(currentrxNbr, WorkQueueSettings.ServiceAdministration.getValue(), ConnexusConstants.WAIT_TIMEOUT_40)) {
                    patientSearchPage.launchOrderSearchScreen();
                    patientSearchPage.performSearch(currentrxNbr);
                    String rxStatus = orderSearch.getWorkQueue(0);
                    Reporter.log("WorkQueue status: " + rxStatus);
                    Assert.assertEquals(rxStatus.toLowerCase(), WorkQueue.SVC_ADMIN.getWorkQueue(), "order is not in service admin queue");
                    logScreenshotSafely(Status.PASS, "verifyWorkQueueStatusAsSvcAdmin", connexusStartPage.takeScreenShot(currentStepMethodName));
                    orderSearch.closeSearch();
                }
            }
        } catch (Throwable e) {
            Reporter.log("Either RX not in chkDur/service admin queue" + e.getMessage());
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public int getPatientIdFromName() {
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String query = "select patient_id from patient where first_name= " + "'" + name[1].toUpperCase() + "'" + " and last_name = " + "'" + name[0].toUpperCase() + "';";
        patientId = am.getConnexusDB(siteId).getScalar(query, Integer.class);
        return patientId;
    }


    public void performPOSMultiRx() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientId = getPatientIdFromName();
            multiRxNbr = getMultiRxNbrFromPatientId(siteId, patientId);
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentrxNbr = String.valueOf(multiRxNbr.get(i));
                if (checkOrderQueueDB(currentrxNbr, WorkQueueSettings.POS.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    automationManager.getConnexusWorkFlow().completeOfflineSale(String.valueOf(currentrxNbr));
                }
                if (checkOrderQueueDB(currentrxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    automationManager.getConnexusWorkFlow().completeResolution(currentrxNbr);
                }
                if (checkOrderQueueDB(currentrxNbr, WorkQueueSettings.EOD.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    patientSearchPage.launchOrderSearchScreen();
                    patientSearchPage.performSearch(currentrxNbr);
                    String rxStatus = orderSearch.getWorkQueue(0);
                    Reporter.log("WorkQueue status: " + rxStatus);
                    Assert.assertEquals(rxStatus.toLowerCase(), WorkQueue.EOD.getWorkQueue(), "rx order is not in EOD work queue");
                    logScreenshotSafely(Status.PASS, "verifyWorkQueueStatusAsEOD", connexusStartPage.takeScreenShot(currentStepMethodName));
                    orderSearch.closeSearch();
                }
            }
        } catch (Throwable e) {
            Reporter.log("Test failed at POS queue");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyServiceDetailsInPMSMultiRx(Map<String, String> appointmentInfo) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        prescriberId = getprescriberId(appointmentInfo);
        try {
            String todaysDate = getCurrentDate("MM/dd/yyyy");
            String rxStatus = orderSearch.getWorkQueue(0);
            String[] name = connexusAppUtils.readPatientNameFromFile();
            patientSearchPage.launchPatientSearchScreen();
            Reporter.log("Patient Name" + name[0] + "," + name[1]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            Reporter.log("DOB" + patient.getPatientDob());
            patientSearchPage.inputPatientDob(patient.getPatientDob());
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickClinicalServicesTab();
            logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Reporter.log("clicked on clinical services");

            //verify race and Ethnicity
            Reporter.log("Verifying race and ethicity from PMS");
            String raceFromPMS = patientMaintenancePage.getRace();
            Assert.assertEquals(raceFromPMS, race, "race did not match");
            String ethnicityFromPMS = patientMaintenancePage.getEthinicty();
            Assert.assertEquals(ethnicityFromPMS, ethnicity, "ethicity did not match");
            Reporter.log("Verified race and enthnicity on PMS with expected values passed while creation of order");

            //verify rxFillID,Status and click serviceDetails Button
            patientId = getPatientIdFromName();
            multiRxNbr = getMultiRxNbrFromPatientId(siteId, patientId);
            for (int i = 0; i < multiRxNbr.size(); i++) {
                currentrxNbr = String.valueOf(multiRxNbr.get(i));
                int currentFillId = getCurrentFillId(currentrxNbr);
                patientMaintenancePage.selectActiveRxNbrRow(currentrxNbr, i);
                this.verifyAndOpenServiceDetailsForRxFillId(currentFillId);
                Reporter.log("Assert: Validation of RxfillId details is completed");
                logScreenshotSafely(Status.PASS, "PatientMaintenance", connexusStartPage.takeScreenShot(currentStepMethodName));

                //verify lot Numbers
                Assert.assertEquals(patientMaintenancePage.getLotNo(), appointmentInfo.get("lotNbr"), "lot numbers are different");
                Reporter.log("Assert: validation of Actual lot numbers with expected is completed");
                //verify Administrated BY
                String expectedPrescriberName = appointmentInfo.get("PRESCRIBER_NAME");
                String administerName = patientMaintenancePage.getAdministratorValue().trim();
                boolean isPrescriberNameValid = administerName.contains(expectedPrescriberName);
                Assert.assertTrue(isPrescriberNameValid,
                        String.format("Prescriber name validation failed. Expected: '%s' to be contained in Administrator name: '%s'",
                                expectedPrescriberName, administerName));
                Reporter.log("Assert: Validation of Administrated by completed with given value is matched");
                logScreenshotSafely(Status.PASS, "ServiceAdministration", connexusStartPage.takeScreenShot(currentStepMethodName));
                //verify IMZRegistryNotify
                if (rxStatus.equalsIgnoreCase(WorkQueue.EOD.getWorkQueue())) {
                    String imzRegistryDateTime = patientMaintenancePage.getImzAdministry();
                    String imzReg[] = imzRegistryDateTime.split(" ");
                    Assert.assertEquals(imzReg[0].trim(), todaysDate.trim(), "Notify date is not matched");
                    logScreenshotSafely(Status.PASS, "currentStepMethodName", connexusStartPage.takeScreenShot(currentStepMethodName));
                    Reporter.log("Assert: Validation of IMZRegistryNotify Date is completed");
                }
                //Clikcing IMZForm and check for IMZForm
                patientMaintenancePage.clickImzForm();
                Boolean pqcfImg = patientMaintenancePage.verifyPvImage();
                Assert.assertTrue(pqcfImg, "PQCF Image doesnot exist");
                logScreenshotSafely(Status.PASS, "ScanIMZForm", connexusStartPage.takeScreenShot(currentStepMethodName));

                //closes IMZ form
                patientMaintenancePage.clickExit();
                //closes services administration page
                patientMaintenancePage.clickExit();
                patientMaintenancePage.clickYes();
            }
            //closes clinical services page
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            Reporter.log("Test failed at PatientMaintainance page");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyAndOpenServiceDetailsForRxFillId(int currentFillId) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            //verify rxFillID,Status and click serviceDetails Button
            patientMaintenancePage.selectActiveRxFillIdRow(currentFillId);
            Assert.assertTrue(patientMaintenancePage.isServiceDetailsEnabled());
            patientMaintenancePage.clickServiceDetails();
            Reporter.log("Validation of RxfillId details is completed");
            logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
        } catch (Throwable e) {
            Reporter.log("Test failed at clinical Service tab in PMS");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());

        }
    }

    public int getCurrentFillId(String rxNbr) {
        String query = "select rx_fill_id  from  rx_order_detail where rx_id =(select rx_id from rx where rx_nbr=\"" + rxNbr + "\")";
        Map<String, Object> rxInfo = am.getConnexusDB().executeQuery(query);
        int fillId = Integer.parseInt(rxInfo.get("rx_fill_id").toString());
        return fillId;
    }
    public void verifyExistingPatientWorkQueueAndProblemStatus() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<String> statusAndProblem = new ArrayList<>();
        try {

            String fullName = PFSConstants.LAST_NAME + " " + PFSConstants.FIRST_NAME;
            String [] name = fullName.split(" ");
            Reporter.log("Existing Patient Name:" + name[0] + ',' + name[1]);
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Manual Resolution")) {
                Reporter.log("Patient is in Resolve Queue");
                am.getConnexusWorkFlow().performRphManualResolution(rxNbr);
                Reporter.log("Unauthorised drug problem is resolved");
            }
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            Reporter.log("WorkQueue:" + statusAndProblem.get(0));
            Reporter.log("Problem:" + statusAndProblem.get(1));
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && "Patient Name Mismatch".equalsIgnoreCase(statusAndProblem.get(1))) {
                patientSearchPage.openFirstPatientRecord();
                Reporter.log("Problem is patient Name Mismatch so Resolution Page is launched to create patient");
            }
        } catch (Throwable e) {
            Reporter.log("Patient is not resolve queue or problem message did not match");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }
    public void checkAndPerformCheckDURForExistingPatient(Map<String, String> inputData) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        List<String> statusAndProblem = new ArrayList<>();
        ResolutionPage resolutionPage = new ResolutionPage();
        try {
            String fullName = PFSConstants.LAST_NAME + " " + PFSConstants.FIRST_NAME;
            String [] name = fullName.split(" ");
            Reporter.log("Existing Patient Name:" + name[0] + ',' + name[1]);
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            Log.info("WorkQueue:" + statusAndProblem.get(0));
            Log.info("problem:" + statusAndProblem.get(1));
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Future Date")) {
                Reporter.log("Patient is in Resolve Queue with Waiting for Filling-Future Date");
                am.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Manual Resolution")) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(name[0] + "," + name[1]);
                patientSearchPage.openFirstPatientRecord();
                if (resolutionPage.manualResolutionVerification().contains("REASON: DUE TO RPH PRESCRIPTIVE AUTHORITY REQUIREMENTS, THIS IMMUNIZATION NEEDS ADDITIONAL ACTION BY A PHARMACIST.")) {
                    am.getConnexusWorkFlow().performRphManualResolutionForAdditionalAction(name[0] + "," + name[1], inputData.get("PRESCRIBER_NAME"));
                    Reporter.log("This IMMUNIZATION needs Additional action by Prescriber is resolved");
                } else {
                    Assert.fail("Drugs not in authorised list");
                }
            }
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
            } else if (rxStatus.equalsIgnoreCase(WorkQueue.CASH.getWorkQueue())) {
            }
            statusAndProblem = orderSearch.getRxStatusAndProblem(name[0] + "," + name[1], 0);
            if (statusAndProblem.get(0).equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue()) && statusAndProblem.get(1).contains("Reject")) {
                am.getConnexusWorkFlow().completeResolution(rxNbr);
                Reporter.log("Invalid Reject Code is resolved");
            }
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                am.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.CHK_DUR.getWorkQueue())) {
                am.getConnexusWorkFlow().checkAndPerformCheckDUR(rxNbr);
            }
        } catch (Throwable e) {
            Reporter.log("patient is not in chkDUR queue");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }
    public void verifyWorkQueueStatusAsServiceAdminForExistingPateint() {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        try {
            String fullName = PFSConstants.LAST_NAME + " " + PFSConstants.FIRST_NAME;
            String [] name = fullName.split(" ");
            Reporter.log("Existing Patient Name:" + name[0] + ',' + name[1]);
            String rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            Reporter.log("WorkQueue: " + rxStatus);
            if (rxStatus.equalsIgnoreCase(WorkQueue.TP.getWorkQueue())) {
                orderSearch.closeSearch();
            }
            rxStatus = orderSearch.getRXStatusForPatient(name[0] + "," + name[1], 0);
            if (rxStatus.equalsIgnoreCase(WorkQueue.RESOLVE.getWorkQueue())) {
                am.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            patientSearchPage.launchOrderSearchScreen();
            patientSearchPage.performSearch(rxNbr);
            rxStatus = orderSearch.getWorkQueue(0);
            Reporter.log("WorkQueue status: " + rxStatus);
            Assert.assertEquals(rxStatus.toLowerCase(), "svc admn", "order is not in service admin queue");
            logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            orderSearch.closeSearch();
        } catch (Throwable e) {
            Reporter.log("order is not in service admin queue");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }
    public void performImZAdministrationForExistingPatient(Map<String, String> appointmentInfo) {
        prescriberId = getprescriberId(appointmentInfo);
        boolean isGuardian = false;
        String relationCode = appointmentInfo.get("GUARDIAN_RELATION_CODE");
        GetImzInfo getImzInfo = getImzInfo(siteId);
        String fullName = PFSConstants.LAST_NAME + " " + PFSConstants.FIRST_NAME;
        String [] name = fullName.split(" ");
        Reporter.log("Existing Patient Name:" + name[0] + ',' + name[1]);
        String firstName = name[0];
        String lastName = name[1];
        String expirationDate = appointmentInfo.get("expirationDate");
        int patientList = getImzInfo.getSvcOrderDetails().size();
        Log.info("patientList from getImZInfo:" + patientList);
        for (int i = 0; i < patientList; i++) {
            if (getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getLastName()
                    .equalsIgnoreCase(name[0])) {
                orderId = getImzInfo.getSvcOrderDetails().get(i).getOrderId();
                orderSeqNbr = getImzInfo.getSvcOrderDetails().get(i).getOrderSeqNbr();
                patientId = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getPatientId();
                rxFillId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillId();
                serviceId = getImzInfo.getSvcOrderDetails().get(i).getService().getServiceId();
                itemMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getItemMdsFamId();
                productMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getProductMdsFamId();
                vaccineName = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getShortName();
                race = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getRaceType();
                ethnicity = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getEthnicityType();

                Reporter.log("orderId:" + orderId + "patientId:" + patientId + "rxFillId:" + rxFillId + "serviceId:" + serviceId + "itemMdsFamId:" + itemMdsFamId + "productItemMdsFamId:" + productMdsFamId + "vaccineName:" + vaccineName + "race:" + race + "ethnicity:" + ethnicity);
            }
        }

        List<OrderInfo> orderInfoList = new ArrayList<>();
        orderInfoList.add(new OrderInfo(orderId, orderSeqNbr));

        // Assigning the order
        AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);

        //getIMZRecommendations API is not in use and no more required for this flow.
        //GetIMZRecommendationsWrapper.getIMZRecommendationsForNewPatient(siteId, patientId, ASSIGNED_USER_ID_AUT_TEST);

        //get onlinequestionnarie form
        OnlineQuestionnarieFormWrapper.getOnlineQuestionnarieForm(siteId, String.valueOf(serviceId));

        //save Questionnarie form
        OnlineQuestionnarieFormWrapper.saveOnlineQuestionnarieForm(siteId, questionsWithAllFalse(), String.valueOf(serviceId), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, prescriberId, isGuardian);

        //saves Product information
        SaveProductInformationWrapper.saveProductInformation(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId);

        //isGaurdianSignInConsentForm
        IsGaurdianSignInConsentWrapper.getGaudrianSigninResponseDetails(siteId, String.valueOf(serviceId));

        //completes order
        // relation code 318 is for Guardian as self with patient name for tc-HWPHME2E_2521
        // relation code 321 is for patient with Guardian details for tc-HWPHME2E_3113
        if (relationCode != null && !relationCode.isEmpty() && "318".equals(relationCode)) {
            CompleteOrderWrapper.completeOrderForGuardian(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId, vaccineName, serviceId, patientId, prescriberId, firstName, lastName, Integer.parseInt(appointmentInfo.get("GUARDIAN_RELATION_CODE")));
        } else if (relationCode != null && !relationCode.isEmpty() && "321".equals(relationCode)) {
            CompleteOrderWrapper.completeOrderForGuardian(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId, vaccineName, serviceId, patientId, prescriberId, appointmentInfo.get("GUARDIAN_FNAME"), appointmentInfo.get("GUARDIAN_LNAME"), Integer.parseInt(appointmentInfo.get("GUARDIAN_RELATION_CODE")));
        } else {
            CompleteOrderWrapper.completeOrder(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId, vaccineName, serviceId, patientId, prescriberId);
        }

        Reporter.log("Completed IMZ Administration for dotcom order through APIs");
    }

    public void verifyServiceDetailsInPMSForExistingPatient(Map<String, String> appointmentInfo) {
        String currentStepMethodName = new Object() {
        }.getClass().getEnclosingMethod().getName();
        prescriberId = getprescriberId(appointmentInfo);
        try {
            String todaysDate =getCurrentDate("MM/dd/yyyy");
            String rxStatus = orderSearch.getWorkQueue(0);
            String fullName = PFSConstants.LAST_NAME + " " + PFSConstants.FIRST_NAME;
            String [] name = fullName.split(" ");
            patientSearchPage.launchPatientSearchScreen();
            Reporter.log("Patient Name" + name[0] + "," + name[1]);
            patientSearchPage.inputPatientName(name[0] + "," + name[1]);
            patientSearchPage.inputPatientDob(appointmentInfo.get("DOB"));
            patientSearchPage.clickSearchNow();
            patientSearchPage.openFirstPatientRecord();
            patientMaintenancePage.clickClinicalServicesTab();
            logScreenshotSafely(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            Reporter.log("clicked on clinical services");

            //verify race and Ethnicity
            Reporter.log("Verifying race and ethicity from PMS");
            String raceFromPMS = patientMaintenancePage.getRace();
            Assert.assertEquals(raceFromPMS, race, "race did not match");
            String ethnicityFromPMS = patientMaintenancePage.getEthinicty();
            Assert.assertEquals(ethnicityFromPMS, ethnicity, "ethicity did not match");
            Reporter.log("Verified race and enthnicity on PMS with expected values passed while creation of order");
            //verify rxFillID,Status and click serviceDetails Button
            patientMaintenancePage.selectActiveRxFillIdRow(rxFillId);
            Assert.assertTrue(patientMaintenancePage.isServiceDetailsEnabled());
            patientMaintenancePage.clickServiceDetails();
            Reporter.log("Assert: Validation of RxfillId details is completed");
            logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));

            //verify lot Numbers
            Assert.assertEquals(patientMaintenancePage.getLotNo(), appointmentInfo.get("lotNbr"), "lot numbers are different");
            Reporter.log("Assert: validation of Actual lot numbers with expected is completed");
            //verify Administrated BY
            String administerName = patientMaintenancePage.getAdministratorValue().trim();
            Assert.assertEquals(administerName, appointmentInfo.get("PRESCRIBER_NAME"), "person administrated by doesnot match");
            Reporter.log("Assert: Validation of Administrated by with given value is completed");
            //verify IMZRegistryNotify
            if (rxStatus.equalsIgnoreCase(WorkQueue.EOD.getWorkQueue())) {

                String imzRegistryDateTime = patientMaintenancePage.getImzAdministry();
                String imzReg[] = imzRegistryDateTime.split(" ");
                Assert.assertEquals(imzReg[0].trim(), todaysDate.trim(), "Notify date is not matched");
                logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
                Reporter.log("Assert: Validation of IMZRegistryNotify Date is completed");
            }
            //verify VIS PublishDate
            String visPubDate = getVisPubFromDB();
            Log.info("visPubdate" + visPubDate);
            if (visPubDate == null) {
                visPubDate = todaysDate.trim();
                Assert.assertEquals(visPubDate, patientMaintenancePage.getVISPublishDate().trim(), "VIS Publish Date did not Matched");
                Reporter.log("Assert: Validation of VIS PublishDate from PMS is completed");
            } else {
                visPubDate = dateConversion(visPubDate);
                Assert.assertEquals(visPubDate, patientMaintenancePage.getVISPublishDate().trim(), "VIS Publish Date did not Matched");
                Reporter.log("Assert: Validation of VIS PublishDate from PMS is completed");
            }
            //verify VIS GivenDate
            Assert.assertNotNull(patientMaintenancePage.getVISGivenDate(), "VIS Given Date is  null");
            Assert.assertEquals(todaysDate, patientMaintenancePage.getVISGivenDate().trim(), "VIS GIVEN Date is Matched");
            Reporter.log("Assert: Validation of VIS GivenDate from PMS is completed");

            //Clikcing IMZForm and check for IMZForm
            patientMaintenancePage.clickImzForm();
            Boolean pqcfImg = patientMaintenancePage.verifyPvImage();
            Assert.assertTrue(pqcfImg, "PQCF Image doesnot exist");
            logScreenshotSafely(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));

            //closes IMZ form
            patientMaintenancePage.clickExit();

            //closes services administration page
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();

            //closes clinical services page
            patientMaintenancePage.clickSaveAndClose();
        } catch (Throwable e) {
            Reporter.log("Test failed at PatientMaintainance page");
            logScreenshotSafely(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName));
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /**
     * Performs imz administration for unassigned orders through Dotcom APIs.
     * @param appointmentInfo test data details
     */
    public void performImzAdministrationForUnassignOrders(Map<String, String> appointmentInfo) {
        prescriberId = getprescriberId(appointmentInfo);
        boolean isGuardian = false;
        GetImzInfo getImzInfo = getImzInfo(siteId);
        String[] name = connexusAppUtils.readPatientNameFromFile();
        String expirationDate = appointmentInfo.get("expirationDate");
        int patientList = getImzInfo.getSvcOrderDetails().size();
        Log.info("patientList from getImZInfo:" + patientList);
        for (int i = 0; i < patientList; i++) {
            if (getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getLastName()
                    .equalsIgnoreCase(name[0])) {
                orderId = getImzInfo.getSvcOrderDetails().get(i).getOrderId();
                orderSeqNbr = getImzInfo.getSvcOrderDetails().get(i).getOrderSeqNbr();
                patientId = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getPatientId();
                rxFillId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillId();
                serviceId = getImzInfo.getSvcOrderDetails().get(i).getService().getServiceId();
                itemMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getItemMdsFamId();
                productMdsFamId = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getProductMdsFamId();
                vaccineName = getImzInfo.getSvcOrderDetails().get(i).getRxFill().getRxFillItem().getShortName();
                race = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getRaceType();
                ethnicity = getImzInfo.getSvcOrderDetails().get(i).getService().getPatient().getEthnicityType();

                Reporter.log("orderId:" + orderId + "patientId:" + patientId + "rxFillId:" + rxFillId + "serviceId:" + serviceId + "itemMdsFamId:" + itemMdsFamId + "productItemMdsFamId:" + productMdsFamId + "vaccineName:" + vaccineName + "race:" + race + "ethnicity:" + ethnicity);
            }
        }
        List<OrderInfo> orderInfoList = new ArrayList<>();
        orderInfoList.add(new OrderInfo(orderId, orderSeqNbr));
        // Assigning the order
        AssignOrdersWrapper.assignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);
        //get onlinequestionnarie form
        OnlineQuestionnarieFormWrapper.getOnlineQuestionnarieForm(siteId, String.valueOf(serviceId));
        //save Questionnarie form
        OnlineQuestionnarieFormWrapper.saveOnlineQuestionnarieForm(siteId, questionsWithAllFalse(), String.valueOf(serviceId), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, prescriberId, isGuardian);
        //saves Product information
        SaveProductInformationWrapper.saveProductInformation(siteId, appointmentInfo.get("lotNbr"), ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, expirationDate, itemMdsFamId, rxFillId);
        //Unassign the orders
        UnassignOrdersWrapper.unassignOrders(siteId, ASSIGNED_USER_ID_AUT_TEST, WORK_STATION_HOST_NAME, orderInfoList);
        Reporter.log("Completed IMZ Administration until unassign orders for dotcom order through APIs");
    }

    /**
     * Safe screenshot logging helper method
     * Handles null Pair returns from takeScreenShot()
     */
    private void logScreenshotSafely(Status status, String stepName, javafx.util.Pair<String, String> screenshotPair) {
        if (screenshotPair != null && screenshotPair.getValue() != null) {
            Reporter.logScreenShot(status, stepName, screenshotPair.getValue());
        } else {
            Reporter.log("Screenshot could not be captured for step: " + stepName);
        }
    }
}









