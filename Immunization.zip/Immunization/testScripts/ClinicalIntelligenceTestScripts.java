package clinicalservices.Immunization.testScripts;

import com.aventstack.extentreports.Status;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import connexus.ConnexusTestScripts;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.ConnexusConstants;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.SearchType;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.enums.WorkQueueSettings;
import hwqe.baseframework.models.pageobjectmodels.connexus.ClinicalIntelligencePage;
import hwqe.baseframework.models.pageobjectmodels.connexus.F6Search;
import hwqe.baseframework.models.pageobjectmodels.connexus.ModifyDetails;
import hwqe.baseframework.models.pageobjectmodels.connexus.PatientSearchPage;
import hwqe.baseframework.utilities.DateUtils;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import hwqe.baseframework.utilities.StringUtils;
import org.testng.Assert;
import rxpd.RXPDE2E.Utils.Poller;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class ClinicalIntelligenceTestScripts extends ConnexusTestScripts {

    PropertyReader prop = PropertyReader.getInstance();
    int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
    int startTime, patientId;
    List<String> expectedImmunizations = Arrays.asList("Influenza", "COVID-19", "HepB", "DTaP/Tdap/Td", "HPV");
    List<String> drugsWithAnnual = Arrays.asList("Influenza", "COVID-19");
    String rxNbr = null;
    String title, clinicalNotes, patientName, patientFirstName, patientLastName;
    List<Integer> multiRxNbr = new ArrayList<>();

    public ClinicalIntelligenceTestScripts(LoginAs.userType loginUserType) {
        super(loginUserType);
    }

    /**
     * Creates a new patient and drops a prescription via API
     * All patient details (name, DOB, phone) are auto-generated.
     * Inventory is verified before the order is dropped off.
     * @return String array {@code [lastName, firstName]} retrieved from the patient API response,
     *         for use in subsequent F6/F7 lookups
     */
    public String[] createPatientAndDropOrderForCIAdHoc() {
        try {
            ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
            createPatientViaApi(connexusAPIManager);
            fetchPatientName(connexusAPIManager, patientId);
            dropOrderViaApi(connexusAPIManager);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Failed to create patient and drop order for CI Ad Hoc: " + e.getMessage());
            softAssert.fail(e.toString());
        }
        return new String[]{patientLastName, patientFirstName};
    }

    /**
     * Creates a new patient via API and stores the resulting patientId.
     */
    private void createPatientViaApi(ConnexusAPIManager connexusAPIManager) {
        String firstName = StringUtils.uniqueFirstName();
        String lastName = StringUtils.uniqueLastName();
        String dob = DateUtils.birthdayGeneratorWithGivenFormat("MM/dd/yyyy");
        long homePhone = Long.parseLong(StringUtils.phoneNumberGenerator());
        long workPhone = Long.parseLong(StringUtils.phoneNumberGenerator());
        long cellPhone = Long.parseLong(StringUtils.phoneNumberGenerator());
        ServiceResponse response = connexusAPIManager.createPatient(firstName, lastName, dob, siteId, homePhone, workPhone, cellPhone);
        Assert.assertEquals(response.getStatusCode(), 201, "Patient creation failed: " + response.getDataResponse());
        patientId = response.getDataResponse(InputResponse.class).getPatientId();
        Reporter.log("Created patient with patientId=" + patientId);
    }

    /**
     * Calls the getPatientInformation API to retrieve the patient's first and last name
     */
    private void fetchPatientName(ConnexusAPIManager connexusAPIManager, int patientId) {
        ServiceResponse response = connexusAPIManager.getPatientInformation(siteId, patientId, "");
        Assert.assertEquals(response.getStatusCode(), 200, "getPatientInformation failed: " + response.getDataResponse());
        Gson gson = new Gson();
        JsonObject root = gson.fromJson(response.getDataResponse(), JsonObject.class);
        JsonObject personalInfo = root.getAsJsonObject("Patient")
                .getAsJsonObject("PatGeneralInfo")
                .getAsJsonObject("PersonalInfo");
        patientFirstName = personalInfo.get("FirstName").getAsString().trim();
        patientLastName = personalInfo.get("LastName").getAsString().trim();
        patientName = patientLastName + "," + patientFirstName;
        Reporter.log("Fetched patient name: " + patientName + " for patientId=" + patientId);
    }

    /**
     * Ensures inventory is available for the configured NDC, then creates and drops off an order
     * for the current patientId.
     */
    private void dropOrderViaApi(ConnexusAPIManager connexusAPIManager) {
        String ndc = prop.getProperty("cnx.ndc");
        connexusAppUtils.updateInventoryQuantity(ndc);
        IDatabaseContext dbContext = automationManager.getConnexusDB(siteId);
        DataRow drugInfo = connexusAPIManager.getDrugInfo(dbContext, ndc);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd yyyy HH:mm:ss.SSS z", Locale.ENGLISH);
        String pickUpDate = ZonedDateTime.now(ZoneId.of("UTC")).plusDays(1).format(formatter);
        String expirationDate = ZonedDateTime.now(ZoneId.of("UTC")).plusMonths(6).format(formatter);
        int requestTypeCode = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrderPriorityId"));
        int dispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));
        ServiceResponse response = connexusAPIManager.createOrderAndDropOff(requestTypeCode, priorityId, dispenseType, patientId, siteId, pickUpDate, expirationDate, 0, drugInfo);
        Assert.assertEquals(response.getStatusCode(), 201, "Order drop off failed: " + response.getDataResponse());
        Reporter.log("Order created and dropped off for patientId=" + patientId);
    }

    public void validateClinicalIntelligenceBtnDisabled() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            F6Search orderSearch = new F6Search();
            orderSearch.searchOrderByCIWorkQueue();
            orderSearch.validateCIBtnDisabled();
            orderSearch.closeSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at F6 Screen");
            softAssert.fail(e.toString());
        }
    }

    public void validateClinicalIntelligenceBtnEnabled(Map<String, String> inputData,boolean isExistingPatient) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            F6Search orderSearch = new F6Search();
            if(isExistingPatient){
                rxNbr = orderSearch.getRxNbrForPatient(inputData.get("LAST_NAME") + "," + inputData.get("FIRST_NAME"), 0);
            }
            else {
                String[] name = connexusAppUtils.readPatientNameFromFile();
                rxNbr = getRxNbrIfEmpty(name[0], name[1], siteId);
            }
            if (ischeckIMZOrderQueueDB(rxNbr, WorkQueueSettings.ClinicalIntelligence.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                Reporter.log("RX is in Clinical Intelligence queue");
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.validateCIBtnEnabled();
                orderSearch.closeSearch();
            } else {
                captureUnExpectedQueueResults(rxNbr, currentStepMethodName, "RX is not in Clinical Intelligence Queue to proceed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("RX is not in Clinical Intelligence queue");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    public void validateCIEnabledInF7Screen(String lastName, String firstName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            openRxLookUpPage(lastName, firstName);
            rxLookUp.validateCIBtnEnabled();
            rxLookUp.clickOnCIButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at F7 Screen");
            softAssert.fail(e.toString());
        }
    }

    public void validateCIEnabledInF6Screen(String lastName, String firstName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String patientSearch = lastName + "," + firstName;
            Reporter.log("Searching for patient in F6 Order Search: " + patientSearch);
            orderSearch.launchOrderSearchScreen();
            orderSearch.performSearch(patientSearch, SearchType.PatientRx);
            orderSearch.validateCIBtnEnabled();
            orderSearch.clickOnCIButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Test failed at validateCIEnabledInF6Screen: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    private String getRxNbrIfEmpty(String lastName, String firstName, int siteId) {
        if (rxNbr == null || rxNbr.isEmpty()) {
            rxNbr = getRxNbr(lastName, firstName, siteId);
            if (rxNbr == null || rxNbr.isEmpty()) {
                String errorMsg = "Failed to get the RX number for patient: " + lastName + ", " + firstName;
                Reporter.log(errorMsg);
                Assert.fail(errorMsg);
            }
            Reporter.log("In validateClinicalIntelligenceBtnEnabled Method, Rx number is " + rxNbr);
        }
        return rxNbr;
    }

    public void openRxLookUpPage(String lastName, String firstName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(lastName + "," + firstName);
            rxLookUp.clickSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Rx look up page not opened");
            softAssert.fail(e.toString());
        }
    }

    public void openRxLookUpPage() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(name[0] + "," + name[1]);
            rxLookUp.clickSearch();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Rx look up page not opened");
            softAssert.fail(e.toString());
        }
    }

    public void validateIMZRecommendationsAndHistory() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Verify Recommendations Section
            clinicalIntelligencePage.validateRecommendationHeader();
            // Validate Recommended Immunizations
            clinicalIntelligencePage.validateRecommendedImmunizations(expectedImmunizations);

            // Validate Dose Information
            clinicalIntelligencePage.validateDoseLabels(expectedImmunizations);

            // Verify History header and no message is displayed
            clinicalIntelligencePage.validateNoHistoryMessage();

            //Verify Add Recommendation button is not present
            clinicalIntelligencePage.isAddButtonNotPresent();
            //Verify  Recommendation InProgress section is not present
            clinicalIntelligencePage.isReviewOrderInProgressSectionNotPresent();
            Reporter.log("Verified Recommendations and History sections are displayed correctly");
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed to verify Recommendations and History");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            softAssert.fail(e.toString());
            softAssert.assertAll();
        }
    }

    /**
     * This method verifies the work queue status for clinical intelligence and
     * closes it if it is open.
     * * Author: Lavanya Torrikonda (vn575up)
     */
    public void verifyWQStatusOpenAndCloseForClinIntel() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        clinicalIntelligencePage = new ClinicalIntelligencePage();
        patientSearchPage = new PatientSearchPage();
        orderSearch = new F6Search();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = orderSearch.getRxNbrForPatient(name[0] + "," + name[1], 0);

            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (ischeckIMZOrderQueueDB(rxNbr, WorkQueueSettings.ClinicalIntelligence.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                patientSearchPage.launchOrderSearchScreen();
                patientSearchPage.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();
                title = clinicalIntelligencePage.getTitle();
                Assert.assertEquals("Clinical Intelligence IMZ Rx", title, "title did not match");
                Reporter.log("Assert: title matched in ClinIntel screen");
                Reporter.logScreenShot(Status.PASS, "ClinicalIntelligence", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                clinicalIntelligencePage.clickAcceptBtn();
            } else {
                Assert.fail("Order is not in Clin Intel work queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    public void verifyIMZModifyDetailsCI() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            boolean var;
            F6Search orderSearch = new F6Search();
            patientSearchPage = new PatientSearchPage();
            modifyDetails = new ModifyDetails();

            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbrIfEmpty(name[0], name[1], siteId);
            Reporter.log("RX Nbr found " + rxNbr);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (ischeckIMZOrderQueueDB(rxNbr, WorkQueueSettings.ClinicalIntelligence.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                orderSearch.openFirstPatientRecord();

                var = modifyDetails.isElementEnabled(modifyDetails.txtpatientName);
                Assert.assertFalse(var, "Patient Name field not disabled");
                Reporter.log("Patient Name field is disabled");
                var = modifyDetails.isElementEnabled(modifyDetails.dropdownRxOrigin);
                Assert.assertFalse(var, "Rx Origin field is not disabled");
                Reporter.log("Rx Origin field is disabled");
                var = modifyDetails.isElementEnabled(modifyDetails.txtPrescribedProduct);
                Assert.assertFalse(var, "Prescribed Product field is not disabled");
                Reporter.log("Prescribed Product field disabled");
                var = modifyDetails.isElementEnabled(modifyDetails.txtSig);
                Assert.assertFalse(var, "Sig field is not disabled");
                Reporter.log("Sig field disabled");
                var = modifyDetails.isElementEnabled(modifyDetails.txtPrescriberName);
                Assert.assertFalse(var, "Prescribed Name field is not disabled");
                Reporter.log("Prescribed Name field disabled");
                var = modifyDetails.isElementEnabled(modifyDetails.txtPrescriberQty);
                Assert.assertFalse(var, "Prescribed Quantity field is not disabled");
                Reporter.log("Prescribed Quantity field disabled");
                var = modifyDetails.isElementEnabled(modifyDetails.dispQunatity);
                Assert.assertFalse(var, "Dispensed Quantity field is not disabled");
                Reporter.log("Dispensed Quantity field disabled");
                var = modifyDetails.isElementEnabled(modifyDetails.txtDaysSupply);
                Assert.assertFalse(var, "Days Supply field is not disabled");
                Reporter.log("Days Supply field disabled");
                var = modifyDetails.isElementEnabled(modifyDetails.refillAuth);
                Assert.assertFalse(var, "Refill Auth field is not disabled");
                Reporter.log("Refill Auth field disabled");
                var = modifyDetails.isElementEnabled(modifyDetails.chkTamperResistant);
                Assert.assertFalse(var, "Tamper Resistant field is not disabled");
                Reporter.log("Tamper Resistant field disabled");
                var = modifyDetails.isElementEnabled(modifyDetails.paymentInsuranceTitle);
                Assert.assertTrue(var, "Third Party Insurance field is enabled");
                Reporter.log("Third Party Insurance field enabled");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
                modifyDetails.clickCancel();
                modifyDetails.clickYes();
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            Reporter.log("Test failed at Clin Intel queue" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, modifyDetails.takeScreenShot(currentStepMethodName).getValue());
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /**
     * This method checks if the order is in the Clin Intel and opens it.
     * Author: Lavanya Torrikonda (vn575up)
     */
    public void checkAndOpenClinIntel() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxNbr = getRxNbrIfEmpty(name[0], name[1], siteId);
            if (checkOrderQueueDB(rxNbr, WorkQueueSettings.TroubleShooting.getValue(), ConnexusConstants.WAIT_TIMEOUT_20)) {
                automationManager.getConnexusWorkFlow().completeResolution(rxNbr);
            }
            if (ischeckIMZOrderQueueDB(rxNbr, WorkQueueSettings.ClinicalIntelligence.getValue(), ConnexusConstants.WAIT_TIMEOUT_120)) {
                orderSearch.launchOrderSearchScreen();
                orderSearch.performSearch(rxNbr);
                Reporter.logScreenShot(Status.PASS, "verifyWorkQueueStatusAsClinIntel", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                orderSearch.clickOnCIButton();
            } else {
                Assert.fail("Order is not in Clin Intel queue");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("order is not in Clinical Intelligence queue");
            Reporter.logScreenShot(Status.FAIL, "verifyWorkQueueStatusAsClinIntel", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    public void validateInventoryDisplayedInDescendingOrderOnProductPopUp() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (clinicalIntelligencePage.isClinIntelTitleDisplayed()) {
                clinicalIntelligencePage.clickManuallyAddRecommendation();
                clinicalIntelligencePage.validateInventoryDescendingOrder();
            } else {
                Assert.fail("Clin Intel screen not displayed");
            }
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Add button pop up not opened in Clin Intel screen" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Validate PMS screen in Clinical Intelligence queue and navigates to it.
     * Author: Lavanya Torrikonda (vn575up)
     */
    public void validatePMSInClinIntel() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            this.checkAndOpenClinIntel();
            if (clinicalIntelligencePage.isClinIntelTitleDisplayed()) {
                clinicalIntelligencePage.clickOnPatientName();
                title = patientMaintenancePage.getTitle();
                Assert.assertEquals("Patient Maintenance", title, "title did not match");
                Reporter.log("Assert: title matched in Patient Maintenance screen");
                Reporter.logScreenShot(Status.PASS, "PatientMaintenance", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
                patientMaintenancePage.clickExit();
                patientMaintenancePage.clickYes();
                Reporter.logScreenShot(Status.PASS, "ClinicalIntelligence", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Assert.fail("Clin Intel screen not displayed");
            }
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("PMS Screen not found in Clin Intel queue" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    public void validateFluAndCovidLabel() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            for (String drug : drugsWithAnnual) {
                Boolean displayed = clinicalIntelligencePage.isAnnualLabelPresent(drug);
                Assert.assertEquals(displayed, true, "Annual Label is not present for drug: " + drug);
                Reporter.log("Annual label is present is present for drug: " + drug);
            }
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            String patientName = clinicalIntelligencePage.getPatientNameText();
            Reporter.log("Name is displayed on CI Screen: " + patientName);
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    public void validateInventoryOnAddProductPopUp() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (clinicalIntelligencePage.isClinIntelTitleDisplayed()) {
                clinicalIntelligencePage.clickPlusIcon(1);
                clinicalIntelligencePage.handleProductSelectionPopup();
                clinicalIntelligencePage.validateInventoryDescendingOrder();
            } else {
                Assert.fail("Clin Intel screen not displayed");
            }
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Add button pop up not opened in Clin Intel screen" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Verifies that patient details at the top are displayed correctly.
     * Author: Lavanya Torrikonda (vn575up)
     */
    public void verifyPatientDetailsDisplayed() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            patientName = clinicalIntelligencePage.getPatientNameText();
            if (patientName == null || patientName.trim().isEmpty()) {
                Assert.fail("Patient details verification failed: Patient name is empty or null");
            }
            Reporter.log("Patient details verified successfully: " + patientName);
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Failed to verify patient details: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Patient details verification failed: " + e.getMessage(), e);
        }
    }

    /*
     * Validates that the Service Type label and Service Type Product
     * is displayed in the In Progress section for lockIcon Panel.
     * Author: Lavanya Torrikonda (vn575up)
     * */
    public void validateInProgressOrderForLockIconPanel(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Verify In Progress Header
            clinicalIntelligencePage.validateInProgressHeader();
            // Validate Service Type Label and Product in InProgress section for lockIcon Panel
            clinicalIntelligencePage.validateInProgressOrderForLockIconPanel(inputData);
            Reporter.log("Successfully validated Service type and Product in InProgress section for lockIcon Panel");
            Reporter.logScreenShot(Status.INFO, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Failed to validate InProgress order for lockIcon Panel: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("InProgress order validation failed for lockIcon Panel: " + e.getMessage(), e);
        }
    }

    /*
     * Validates complete recommendation details
     * Author: Lavanya Torrikonda (vn575up)
     * */
    public void validateRecommendedSectionWithDetails() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Verify Recommendations Section
            clinicalIntelligencePage.validateRecommendationHeader();
            // Validate complete recommendation details
            clinicalIntelligencePage.validateRecommendedSectionWithDetails();
            Reporter.log("Successfully validated all recommendation details");
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed to verify Recommendations: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Recommended Section validation failed: " + e.getMessage(), e);
        }
    }

    /*
     * Validates History Section
     * Author: Lavanya Torrikonda (vn575up)
     * */
    public void validateHistorySection() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Verify History Section
            clinicalIntelligencePage.validateHistorySection();
            Reporter.log("Verified History sections are displayed correctly");
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed to verify History: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("History validation failed: " + e.getMessage(), e);
        }
    }

    /*
     * add and validate recommended product in In-Progress section
     * for static recommended index 1 and product index 1
     * Author: Lavanya Torrikonda (vn575up)
     * */
    public void addAndValidateRecommendedProductInProgressSection() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Add recommendation product
            clinicalIntelligencePage.addRecommendedProduct(1, 1);
            // Validate the added product in In-Progress section
            clinicalIntelligencePage.validateServiceTypeLabel(1);
            clinicalIntelligencePage.validateServiceTypeProduct(1);
            Reporter.log("Successfully validated recommended product in InProgress section");
            Reporter.logScreenShot(Status.PASS, "addAndValidateRecommendedProduct", clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            clinicalIntelligencePage.clickAcceptBtn();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Failed to validate recommended product in In Progress section: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to validate recommended product in InProgress section: " + e.getMessage(), e);
        }
    }

    /**
     * This method checks if the order is in the EOD work queue
     * and validates history section.
     * Author: Lavanya Torrikonda (vn575up)
     */
    public void checkAndValidateHistoryInEOD() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientId = getPatientId();
        multiRxNbr = connexusAppUtils.getMultiRxNbrFromPatientId(siteId, patientId);
        try {
            for (int i = 0; i < multiRxNbr.size(); i++) {
                rxNbr = String.valueOf(multiRxNbr.get(i));
                Reporter.log("Validating EOD work queue for Rx Number: " + rxNbr);
                if (checkOrderQueueDB(rxNbr, WorkQueueSettings.EOD.getValue(), ConnexusConstants.WAIT_TIMEOUT_30) || checkOrderQueueDB(rxNbr, WorkQueueSettings.IMZReporting.getValue(), ConnexusConstants.WAIT_TIMEOUT_30)) {
                    Reporter.log("Order is in EOD queue, validating history section");
                    // Validate History Section
                    orderSearch.launchOrderSearchScreen();
                    orderSearch.performSearch(rxNbr);
                    orderSearch.clickOnCIButton();
                    this.validateHistorySection();
                } else {
                    Assert.fail("order is not in EOD or IMZREP work queue");
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            clinicalIntelligencePage.clickAcceptBtn();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Test failed at EOD or IMZREP work queue status: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, orderSearch.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to validate history section in EOD work queue: " + e.getMessage(), e);
        }
    }

    /**
     * This method adds a recommendation product to the In-Progress section by index.
     * Validates the added product In-Progress section
     * Author: Lavanya Torrikonda (vn575up)
     */
    public void addRecommendedProductInProgressSection(int recommendedIndex, int productIndex) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Add recommendation product
            clinicalIntelligencePage.addRecommendedProduct(recommendedIndex, productIndex);

            // Validate the added product
            String productName = clinicalIntelligencePage.validateServiceTypeProduct(recommendedIndex, productIndex);
            Reporter.log("Product successfully added: " + productName);

            Reporter.log("Successfully added recommendation product at index " + recommendedIndex + "," + productIndex);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());

            // Click Accept button
            clinicalIntelligencePage.clickAcceptBtn();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Error in addRecommendationByIndex: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,
                    clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to add recommendation by index: " + e.getMessage(), e);
        }
    }

    /*
     * This method adds multiple recommendation products in the In-Progress section.
     * Each pair of product indexes to add product.
     * Author: Lavanya Torrikonda (vn575up)
     */
    public void addMultipleRecommendationProducts(int[][] indexes) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (indexes == null) {
                return;
            }
            // 1-based index of rows in In‑Progress section
            int inProgressRowIndex = 1;

            for (int[] pair : indexes) {
                if (pair != null && pair.length >= 2) {
                    int recommendedIndex = pair[0];
                    int productIndex = pair[1];
                    // Add product from Recommended section
                    clinicalIntelligencePage.addRecommendedProduct(recommendedIndex, productIndex);

                    // Validate all added In‑Progress rows
                    String productName = clinicalIntelligencePage.validateServiceTypeProduct(inProgressRowIndex, productIndex);
                    Reporter.log("Product successfully added: " + productName);

                    inProgressRowIndex++;
                }
            }
            Reporter.log("Successfully added all recommended products for provided indexes");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            clinicalIntelligencePage.clickAcceptBtn();
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Failed to add multiple recommended products: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to add multiple recommended products: " + e.getMessage(), e);
        }
    }

    /**
     * This method adds a recommendation product to the In-Progress section by index
     * and then changes it. Both actions are validated.
     * Author: Lavanya Torrikonda (vn575up)
     */
    public void addAndChangeRecommendedProductInProgressSection(int recommendedIndex, int addProductIndex, int changeProductIndex) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Add recommendation product
            clinicalIntelligencePage.addRecommendedProduct(recommendedIndex, addProductIndex);

            // Validate the added product
            String addProductName = clinicalIntelligencePage.validateServiceTypeProduct(recommendedIndex, addProductIndex);
            Reporter.log("Product successfully added: " + addProductName);
            Reporter.log("Successfully added recommendation product at index " + recommendedIndex + "," + addProductIndex);

            // change recommended product
            clinicalIntelligencePage.changeServiceTypeProduct(recommendedIndex, changeProductIndex);
            // Validate changed product
            String changeProductName = clinicalIntelligencePage.validateServiceTypeProduct(recommendedIndex, changeProductIndex);
            Reporter.log("Product successfully changed: " + changeProductName);

            Reporter.log("Successfully added and changed recommended product in in-progress section at index ="
                    + addProductIndex + ", changeProduct=" + changeProductIndex + " for recommendedIndex=" + recommendedIndex);

            Reporter.logScreenShot(Status.PASS, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());

            // Click Accept button
            clinicalIntelligencePage.clickAcceptBtn();
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to change product: " + e.getMessage());
        }
    }

    /*
     * This method adds and changes multiple recommended products in the In-Progress section.
     * Each pair of product indexes to add and change.
     * Author: Lavanya Torrikonda (vn575up)
     */
    public void addAndChangeMultipleRecommendedProductsInProgressSection(int[][] indexes) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        if (indexes == null) {
            return;
        }
        for (int[] pair : indexes) {
            if (pair != null && pair.length >= 2) {
                int recommendedIndex = pair[0];
                int addProductIndex = pair[1];
                int changeProductIndex = addProductIndex + 1;
                addAndChangeRecommendedProductInProgressSection(recommendedIndex, addProductIndex, changeProductIndex);
            }
        }
        Reporter.log("Successfully added and changed all recommended products for provided indexes");
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
    }

    /**
     * Suppresses a recommendation menu by selecting "Not interested" for the given
     * recommendation row and reason index on the removal popup.
     * @param recommendationIndex
     * @param reasonIndex
     * Author: Lavanya Torrikonda (vn575up)
     */
    public void suppressRecommendationForNotInterested(int recommendationIndex, int reasonIndex) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            clinicalIntelligencePage.click3Dots(recommendationIndex);
            clinicalIntelligencePage.clickNotInterested(recommendationIndex);
            clinicalIntelligencePage.validateRecommendationRemovalPopupTitle();
            clinicalIntelligencePage.clickReasonOnRemovalPopup(reasonIndex);
            clinicalIntelligencePage.clickRemoveButtonOnRemovalPopup();
            // wait for suppression to reflect
            automationManager.performSleep(2);
            Reporter.log("Suppressed recommendation for Not Interested at index " + recommendationIndex + " with reason index " + reasonIndex);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("3-dots Not interested flow failed in Clin Intel screen: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Validates the suppressed recommendation panel details for the recommendation
     * that was last suppressed.
     * Author: Lavanya Torrikonda (vn575up)
     */
    public void validateSuppressedRecommendationPanel() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // get suppressed recommendation index and reason text
            int recommendationIndex = clinicalIntelligencePage.getRecommendationIndexForLastSelectedReason();
            String reasonText = clinicalIntelligencePage.getLastSelectedRemovalReasonText();

            // validate suppressed recommendation details
            clinicalIntelligencePage.validateSuppressedRecommendationGrayedOutWithUserAndDate(recommendationIndex);
            clinicalIntelligencePage.validateRemovedLabelForRecommendation(recommendationIndex);
            clinicalIntelligencePage.validateSuppressedRecommendedServiceTypeMovedToBottom(recommendationIndex);
            clinicalIntelligencePage.validateSuppressedRecommendedReasonMovedToBottom(reasonText);
            Reporter.log("Validated suppressed recommendation for reason '" + reasonText + "' at recommendation index " + recommendationIndex);

            Reporter.logScreenShot(Status.PASS, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            clinicalIntelligencePage.clickAcceptBtn();
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.log("Failed to validate suppressed recommendation state: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to validate suppressed recommendation state: " + e.getMessage(), e);
        }
    }

    public void validateClinicalNoteBtn(Map<String, String> inputData) {
        clinicalIntelligencePage.isAddNoteBtnDisabledIfNoTextEntered();
        clinicalIntelligencePage.isAddNoteBtnEnabledAfterAddingText(inputData);
    }

    public void validateRecommendationNotes() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            clinicalIntelligencePage.click3DotsforNotes(2);
            clinicalIntelligencePage.clickOnAddRecommendationNote();
            Reporter.log("Add RecommendationNotes window opened");
            // Enter Recommendation Notes
            clinicalIntelligencePage.enterRecommendedNotes();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            clinicalIntelligencePage.validateRecommendationNotesWithUserAndDate(2);
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Error in addRecommendation Notes: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Failed to add recommendation Note: " + e.getMessage(), e);
        }
    }

    /**
     * Searches for a different patient using F7 from the Clinical Intelligence screen
     * and opens the Patient Maintenance Screen (PMS) for that patient.
     */
    public void searchDifferentPatientUsingF7AndOpenPMS(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // Using different patient name from input data
            rxLookUp.launchRxLookUpPage();
            rxLookUp.inputSearch(inputData.get("lastName") + "," + inputData.get("firstName"));
            rxLookUp.clickSearch();
            rxLookUp.clickViewPatientInfoBtn();
            title = patientMaintenancePage.getTitle();
            Assert.assertEquals("Patient Maintenance", title, "title did not match");
            Reporter.log("Assert: title matched in Patient Maintenance screen");
            Reporter.logScreenShot(Status.PASS, "openPatientMaintenanceFromF7", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickExit();
            patientMaintenancePage.clickYes();
            Reporter.logScreenShot(Status.PASS, "rxLookupScreen", connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            rxLookUp.closeSearch();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("PMS Screen not found from rx lookup screen" + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Validates that the patient name on the Clinical Intelligence screen
     * remains unchanged after performing an F7 patient search.
     */
    public void validatePatientNameUnchangedOnCIScreen() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            if (patientName == null || patientName.trim().isEmpty()) {
                Assert.fail("Initial CI patient name was not captured. Ensure verifyPatientDetailsDisplayed() is called before validating unchanged patient.");
            }
            String currentPatientName = clinicalIntelligencePage.getPatientNameText();
            Assert.assertNotNull(currentPatientName, "Current CI patient name is null");

            Assert.assertEquals(currentPatientName.trim(), patientName.trim(), "Patient name changed on CI screen after F7 patient search");
            Reporter.log("Validated CI patient name remains unchanged after F7 search. Patient: " + currentPatientName);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            clinicalIntelligencePage.clickAcceptBtn();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Failed to validate patient name unchanged on CI screen: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Adds clinical notes in the Clinical Notes section of the CI screen.
     */
    public void addNotesInClinicalNotesSection() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // open Clinical Notes Section
            clinicalIntelligencePage.openClinicalNotesTab();

            // add New Note text and validate 'Add Note' button enabled
            int noteText = ThreadLocalRandom.current().nextInt(10, 100);
            clinicalNotes = "Test Automation Notes" + noteText;
            clinicalIntelligencePage.enterClinicalNoteText(clinicalNotes);
            Assert.assertTrue(clinicalIntelligencePage.isAddClinicalNoteButtonEnabled(), "Add note button should be enabled after note text is entered");

            // click Add Note button
            clinicalIntelligencePage.clickAddClinicalNoteButton();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Failed to add Clinical Notes in Clinical Intelligence: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Validates the Top Panel Clinical notes details in the Clinical Notes section
     */
    public void validateTopClinicalNotesPanel(int recommendationIndex) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            // validate row header for Clinical Notes
            String clinicalNoteRowHeader = clinicalIntelligencePage.getHeaderForClinicalNotesSectionIndex(recommendationIndex);
            Assert.assertEquals(clinicalNoteRowHeader, "Clinical Note", "Top row header does not contain text");
            // validate clinical Add Notes Text
            String clinicalAddNotesText = clinicalIntelligencePage.getAddTextForClinicalNotesSectionIndex(recommendationIndex);
            Assert.assertEquals(clinicalAddNotesText, clinicalNotes, "Top row does not contain expected add text");
            Reporter.log("validated clinical note row panel details: " + clinicalNoteRowHeader + " | " + clinicalAddNotesText);

            // validate panel details in Clinical Notes section based on index
            validatePanelDetailsInClinicalNotesSection(recommendationIndex);
            Reporter.log("validated top panel Clinical Note details in Clinical Notes section");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());

            // click Accept button
            clinicalIntelligencePage.clickAcceptBtn();
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Failed to validate latest Clinical Notes Panel in Clinical Intelligence: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Validates the Panel Clinical notes/suppressed/restored recommended details
     * Author: Lavanya Torrikonda (vn575up)
     */
    public void validatePanelDetailsInClinicalNotesSection(int recommendationIndex) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String expectedUserId = prop.getProperty("cnx.rph.userName");
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.ENGLISH);
            String expectedDateText = java.time.LocalDate.now().format(formatter);
            String expectedStoreNbr = String.valueOf(siteId);

            String userId = clinicalIntelligencePage.getUserIdForClinicalNotesSectionIndex(recommendationIndex);
            Assert.assertEquals(expectedUserId, userId, "Top row does not contain expected user id");
            Reporter.log("validated userId - Expected: " + expectedUserId + " and Actual: " + userId);

            String storeNbr = clinicalIntelligencePage.getStoreForClinicalNotesSectionIndex(recommendationIndex);
            Assert.assertEquals(expectedStoreNbr, storeNbr, "Top row does not contain expected store number");
            Reporter.log("validated store - Expected: " + expectedStoreNbr + " and Actual: " + storeNbr);

            String date = clinicalIntelligencePage.getDateForClinicalNotesSectionIndex(recommendationIndex);
            Assert.assertEquals(expectedDateText, date, "Top row does not contain expected date");
            Reporter.log("validated date - Expected: " + expectedDateText + " and Actual: " + date);

            Reporter.log("validated clinical notes panel details: " + userId + " | " + storeNbr + " | " + date);
            Reporter.log("Validated Clinical notes/suppressed recommendation details at recommendation index " + recommendationIndex);
        } catch (Exception e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Failed to validate Clinical notes/suppressed recommendation details at recommendation index: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Validates the suppressed recommendation moved to top in Clinical Notes section
     */
    public void validateSuppressedRecommendationMovedToTopInClinicalNotes(int recommendationIndex) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String expectedSuppressedServiceType = clinicalIntelligencePage.getLastRecommendationServiceType();
            String expectedSuppressedText = clinicalIntelligencePage.getLastRecommendationGeneratedText();
            // open Clinical Notes Section
            clinicalIntelligencePage.openClinicalNotesTab();
            // validate row header for Clinical Notes
            String actualServiceType = clinicalIntelligencePage.getHeaderForClinicalNotesSectionIndex(recommendationIndex);
            Assert.assertEquals(actualServiceType, expectedSuppressedServiceType, "Top row header does not contain expected service type");

            // validate clinical Add Notes Text (top/latest row)
            String actualSuppressedText = clinicalIntelligencePage.getAddTextForClinicalNotesSectionIndex(recommendationIndex);
            Assert.assertEquals(actualSuppressedText, expectedSuppressedText, "Top row does not contain expected suppressed text");
            Reporter.log("Validated moved-to-top Recommendation row in Clinical Notes : " + actualServiceType + " | " + actualSuppressedText);

            // validate panel details in Clinical Notes section based on index
            validatePanelDetailsInClinicalNotesSection(recommendationIndex);
            Reporter.log("validated Suppressed Recommendation in Immunization and Clinical Note top panel details in Clinical Notes section");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Failed to validate latest Clinical Notes Panel in Clinical Intelligence: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, connexusStartPage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Validates the prescriber history for the patient
     * currently loaded by performing an F7 search.
     */
    public void validatePrescriptionHistoryInF7(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            String[] name = connexusAppUtils.readPatientNameFromFile();
            rxLookUp.openAndSearchPatientRecordInF7(name[0] + "," + name[1]);
            String prescriber = clinicalIntelligencePage.getPrescriberForRowIndex(0);
            Assert.assertEquals(prescriber, inputData.get("PRESCRIBER_NAME"), "Prescriber name did not match");
            Reporter.log("Validated Prescriber found for patient: " + name[0] + "," + name[1] + ", Prescriber: " + prescriber);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Failed to pull up patient prescription history in Rx Lookup");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /**
     * Checks if the CI button is enabled on the Order Search/RxLoop up screen,
     * clicks it to open the CI screen from Order Search/RxLookUp.
     */
    public void openClinicalIntelligence() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            clinicalIntelligencePage.validateCIBtnEnabled();
            clinicalIntelligencePage.clickOnCIButton();
            Reporter.log("Clinical Intelligence view opened from Order search/RxLook up");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, rxLookUp.takeScreenShot("F6search").getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Failed to open Clinical Intelligence view from Order search/RxLook up");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName,  rxLookUp.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    /*
     * Clicks on Cancel button in CI view from Order search/RxLook up
     * */
    public void clickCancelBtnInCIView() {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            clinicalIntelligencePage.clickCancelBtnInCIView();
            Reporter.log("Navigated back to RxLookup or ConnexusStartPage screen");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
        } catch (Throwable e) {
            isExceptionCaptured = true;
            e.printStackTrace();
            Reporter.log("Failed to click on Cancel button in CI view from Order search/RxLook up");
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, clinicalIntelligencePage.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

}

