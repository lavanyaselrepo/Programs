/// <reference types="Cypress" />

describe("Alerts Demo", () => {

    it.skip("Alerts Demo JS Alert", () => {
        cy.visit("https://the-internet.herokuapp.com/javascript_alerts")

        //JS Alert
        cy.get("button[onclick='jsAlert()']").click()
        cy.on('window:alert', (t) => {
            expect(t).to.contains('I am a JS Alert')
        })
        cy.get('#result').should('have.text','You successfully clicked an alert')
    })

    it.skip("Alerts Demo JS Confirm", () => {
        cy.visit("https://the-internet.herokuapp.com/javascript_alerts")

        //JS Confirm OK
        cy.get("button[onclick='jsConfirm()']").click()
        cy.on('window:alert', (t) => {
            expect(t).to.contains('I am a JS Confirm')
        })
        cy.get('#result').should('have.text','You clicked: Ok')
    })

    it.skip("Alerts Demo JS Confirm", () => {
        cy.visit("https://the-internet.herokuapp.com/javascript_alerts")

        //JS Confirm msg
        cy.get("button[onclick='jsConfirm()']").click()
        cy.on('window:alert', (t) => {
            expect(t).to.contains('I am a JS Confirm')
        })
        //JS Confirm Cancel
        cy.on('window:confirm',()=> false)
        cy.get('#result').should('have.text','You clicked: Cancel')
    })

    it.only("Alerts Demo JS Prompt", () => {
        cy.visit("https://the-internet.herokuapp.com/javascript_alerts")

        cy.window().then((win)=>{
            cy.stub(win,'prompt').returns('welcome to the training')
      })
        //JS Prompt msg
        cy.get("button[onclick='jsPrompt()']").click()
        cy.get('#result').should('have.text','You entered: welcome to the training')
    })

    
})