/// <reference types="Cypress" />

describe('CSS-SELECTORS', () => {
    it('demo using CSS Selectors', () => {
    cy.visit('https://lkmdemoaut.accenture.com/AccenSportz/#/',{failOnStatusCode: false})
    // Launching the application
    cy.get('.button3').click({force : true})
    cy.get('button[value="India vs Pakistan"]').click();
    cy.get('#name').type('Lavanya')
    cy.get('#next1').click()
  })

})