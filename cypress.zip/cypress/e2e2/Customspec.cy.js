/// <reference types="Cypress" />

describe('CSS-SELECTORS', () => {
    it('demo using CSS Selectors', () => {

    })
})