/// <reference types="Cypress" />

describe('My test suite', () => {
    it.skip('Radio buttons and check box', () => {
        // Launch my application 
        cy.visit('https://itera-qa.azurewebsites.net/home/automation')

        //Radio buttons
        cy.get("#female").should('be.visible').click()
        cy.get("#male").should('be.visible').should('not.be.checked')

        //check box
        cy.get("#monday").should('be.visible').check()
        cy.get("#monday").uncheck()
        cy.get("input.form-check-input[type='checkbox']").should('be.visible').check()
        cy.get("input.form-check-input[type='checkbox']").uncheck()
        cy.get("input.form-check-input[type='checkbox']").first().check();
        cy.get("input.form-check-input[type='checkbox']").last().check();
    })

    it.skip('select dropdown values', () => {
        cy.visit('https://www.zoho.com/commerce/free-demo.html')
        cy.get('#zcf_address_country').select('Italy')
    })

    it.skip('select dropdown values and text', () => {
        cy.visit('https://www.dummyticket.com/dummy-ticket-for-visa-application/')
        cy.get('#select2-billing_country-container').click() // locating the dropdown
        cy.get('.select2-search__field').type('Italy').type('{enter}') // selecting the text // enter
    })

    it.only('dropdown values and text', () => {
        cy.visit('https://www.google.com/')
        cy.get('#APjFqb').type('Delhi')
        cy.get('#Alh6id').contains('Delhi University').click()
    })



})