/// <reference types="Cypress" />
/// <reference types="Cypress-xpath" />
const cypress = require("cypress-xpath")

describe('By using Xpath', () => {

    it('Find total no.of options in the page', () => {
        cy.visit('https://lkmdemoaut.accenture.com/AccenSportz/#/',{failOnStatusCode: false})
        cy.title().should('eq','accenSportz')
        cy.xpath("//h1[@id='topText']").should('contain','AccenSportz - Be Better Than You Were Yesterday')

        cy.xpath("//div[@class='c-video-banner -vheight']/div").should('have.length',3)

    })
})