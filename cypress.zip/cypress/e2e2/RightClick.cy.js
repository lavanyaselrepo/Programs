/// <reference types="Cypress" />
require('@4tw/cypress-drag-drop')

describe('Mouse Events', () => {

    it('Right Click action', () => {
        // Approach-1
        cy.visit('http://swisnl.github.io/jQuery-contextMenu/demo.html')
        // cy.get('.context-menu-one').trigger('contextmenu')
        // cy.get('.context-menu-icon-edit').should('be.visible')

        // Approch -2
        cy.get('.context-menu-one').rightclick();
        cy.get('.context-menu-icon-edit').should('be.visible')
    })

    it('Drag and drop action', () => {
        cy.visit('http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html')
        cy.get('#box2').should('be.visible')
        cy.get('#box106').should('be.visible')
        cy.get('#box2').drag('#box106', { force: true })
    })

    it.only('Scroll into view action', () => {
        cy.visit('https://www.countries-ofthe-world.com/flags-of-the-world.html')
        cy.get(':nth-child(1) > tbody > :nth-child(86) > :nth-child(2)').scrollIntoView({ duration: 5000 })
        cy.get(':nth-child(1) > tbody > :nth-child(2) > :nth-child(2)').scrollIntoView({ duration: 5000 })
        cy.get('#footer').scrollIntoView({ duration: 5000 })
    })
})
