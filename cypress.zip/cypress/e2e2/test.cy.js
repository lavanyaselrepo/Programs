
it('Open google page', () => {
    cy.visit('https://google.com')

    //method 1
    cy.get('#APjFqb').type('cypress')
    cy.contains('Google Search').click()

    // //method 2
    // cy.get('#APjFqb34', {timeout:5000}).type('cypress')
    
    // //method 3
    // cy.get('#APjFqb', {timeout:5000}).type('cypress')
    // cy.wait(3000)
    //cy.contains('Google Search').click()
  })