/// <reference types="Cypress" />

describe('My test suite', ()=>{
    it('Verify the title of the page',()=>{
    // Launch my application 
    cy.visit('https://lkmdemoaut.accenture.com/AccenSportz/#/',{failOnStatusCode: false})  
    cy.title().should('eq','accenSportz') 
    })
})