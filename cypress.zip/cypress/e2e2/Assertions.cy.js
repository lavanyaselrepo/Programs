/// <reference types="Cypress" />

describe('Assertions demo', () => {
    it('assertions', () => {

        //Launching the application
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')

        // //method 1
        // cy.url().should('eq','https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        // cy.url().should('contain','orangehrm')

        // //method 2
        // cy.url().should('eq','https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        //         .should('contain','orangehrm')

        // //method 3       
        // cy.url().should('eq','https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
        //         .and('contain','orangehrm')

        //method 4
        cy.url().should('eq','https://opensource-demo.orangehrmlive.com/web/index.php/auth/login') //comparing the actual value is matching to my equal value
                .and('contain','orangehrm')
                .and('not.contain','greenhrm') //negative assertion

            // Launch the page
            // fetch the tile   
            cy.title().should('eq','OrangeHRM').and('contain','OrangeHRM')
            // should be equal to orangehrm
            // should contain HRM

        //fetch the logo and validate logo is visible 
        //visibility : visible on the page or screen
        //exist : Present in the DOM
        cy.get('.orangehrm-login-branding > img').should('be.visible').and('exist')
        
    })
})