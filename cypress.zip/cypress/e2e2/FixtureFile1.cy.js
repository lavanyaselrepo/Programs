/// <reference types="Cypress" />

describe('My test suite', () => {

    let userdata  // declared a global varibale // can be used in all it blocks

    before(() => {
        cy.fixture('orangehrm').then((data) => {   // we have loaded the fixture file and we have stored the json data in a varibale called data and we have equated to a global varibale called userdata
            userdata = data
        })
    })

    it('Fixture Demo Test', () => {
        // Launch my application
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login') // Launch the appli
        cy.get("input[placeholder='Username']").type(userdata.username)   // username
        cy.get("input[placeholder='Password']").type(userdata.password) // password
        cy.get("button[type='submit']").click(); // click on login
        cy.get(':nth-child(2) > .oxd-main-menu-item').should('have.text', userdata.expected) //
    })

    it('Fixture Demo Test 2', () => {
        // Launch my application
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login') // Launch the appli
        cy.get("input[placeholder='Username']").type(userdata.username)   // username
        cy.get("input[placeholder='Password']").type(userdata.password) // password
        cy.get("button[type='submit']").click(); // click on login
        cy.get(':nth-child(2) > .oxd-main-menu-item').should('have.text', userdata.expected) //
    })
})
