/// <reference types="Cypress" />

describe('My test suite', () => {

    it('Fixture Demo Test', () => {
        // Launch my application
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login') // Launch the appli
        cy.fixture('orangehrm').then((data) => {
        cy.get("input[placeholder='Username']").type(data.username)   // username
        cy.get("input[placeholder='Password']").type(data.password) // password
        cy.get("button[type='submit']").click(); // click on login
        cy.get(':nth-child(2) > .oxd-main-menu-item').should('have.text', data.expected) //
        })
    })
})