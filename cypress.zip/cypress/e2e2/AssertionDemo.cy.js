/// <reference types="Cypress" />

describe("Assertions Demo", () => {

    it.skip("Implicit Assertions Demo", () => {
        cy.visit('https://example.cypress.io/')
        cy.contains('get').click()
        cy.get('#query-btn')
            .should('contain', 'Button')
            .and('have.class', 'query-btn')
            .and('be.visible')
            .and('be.enabled')
            .and('attr', 'id').should('equal', 'query-btn')
    })

    it.skip("Explicit Assertions Demo - BDD", () => {
        expect(true).to.be.true
        expect(false).to.be.false
        let name = 'Remi'
        let x = 2
        let arr = { name: 'John', age: 30, salary: 20000 }
        expect(name).to.be.equal('Remi')
        expect(name).to.not.equal('Remiii')
        expect(name).to.be.a('string')
        expect(x).to.be.a('number')
        expect(arr).to.have.any.keys('name')
        expect(arr).to.have.all.keys('name', 'age', 'salary')
        expect(name).to.exist
        expect(10).to.be.greaterThan(5)
    })

    it.skip("Explicit Assertions Demo - TDD", () => {
        assert.equal(3, 3, 'values are equal')
        assert.notequal(3, 4, 'values are not equal')
        assert.isNumber(10, 'value is a number')
        assert.isString('welcome', 'value is a string')
    })

    it.only("Assertions - Practical demo", () => {
        cy.visit('https://juliemr.github.io/protractor-demo/')
        cy.get('h3').invoke('text').then((text1) => {
            expect(text1).to.eq("Super Calculator") //Using BDD Chai Assertion
        })
        cy.get('[ng-model="first"]').type('20')
        cy.get('.span1').select("+")
        cy.get('[ng-model="second"]').type('10')
        cy.get('#gobutton').click()
        cy.wait(3000)
        cy.get('tbody > .ng-scope > :nth-child(3)').invoke('text').then((addResult) => {
            assert.equal(addResult, 20, "Results are as expected") //Using TDD Chai Assertion
        })
    })
})