/// <reference types="Cypress" />

describe("Auth Alerts Demo", () => {

    it("Auth Alerts Demo JS Alert", () => {
        cy.visit('https://the-internet.herokuapp.com/basic_auth',{
            auth:
            {       
                delay: 2000,      
                username: "admin",
                password: "admin"
            }
        })
        cy.get("div[class='example']>p").should('have.contain', "Congratulations! You must have the proper credentials.")
    })

    it.only("Auth Alert login credentials", () => {

        //providing auth login details in url
        cy.visit('https://admin:admin@the-internet.herokuapp.com/basic_auth',{delay:5000})
        cy.get("div[class='example']>p").should('have.contain',"Congratulations! You must have the proper credentials.")  
    })
})