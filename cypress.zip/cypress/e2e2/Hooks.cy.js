describe('My First Test', () => {

    before(() => {
        cy.log("********** LAUNCH THE APPLICTAION ***********")
    })
    after(() => {
        cy.log("********** CLOSE THE APPLICTAION ***********")
    })
    beforeEach(() => {
        cy.log("********** CLICK ON SIGN IN BUTTON ***********")
    })
    afterEach(() => {
        cy.log("********** CLICK ON LOGOUT BUTTON ***********")
    })

    it('verify the credentials of first user', () => {
        cy.log("********** USER 1 LOGGED IN ***********")
    })
    it('verify the credentials of second user', () => {
        cy.log("********** USER 2 LOGGED IN ***********")
    })
    it('verify the credentials of third user', () => {
        cy.log("********** USER 3 LOGGED IN ***********")
    })
})