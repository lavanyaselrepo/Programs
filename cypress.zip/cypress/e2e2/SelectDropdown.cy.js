/// <reference types="Cypress" />

describe('Radio buttons', () => {
    it('Radio buttons', () => {
        cy.visit('https://www.google.com/')
        cy.get('#APjFqb').type('cypress automation ')
        cy.get('div.wM6W7d>span').each(($el, index, $list) => {
            if ($el.text() == 'cypress automation tool') {
                cy.wrap($el).click()
            }
        })
    })
})