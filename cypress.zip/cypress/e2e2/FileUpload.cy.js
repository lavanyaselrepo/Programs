
// 1. npm install --save-dev cypress-file-upload
//   import 'cypress-file-upload'

// 2. Create the test data file inside the fixture folder

/// <reference types="Cypress" />

import 'cypress-file-upload'
import '@4tw/cypress-drag-drop'

describe('File Uploads', () => {

    it('Single File Upload', () => {
        cy.visit('http://the-internet.herokuapp.com/upload')
        cy.get('#file-upload').attachFile('Test1.pdf')
        cy.get('#file-submit').click();
        cy.wait(5000);
        cy.get('h3').should('have.text','File Uploaded!')
    })

    it('File Upload - Rename', () => {
        cy.visit('http://the-internet.herokuapp.com/upload')
        cy.get('#file-upload').attachFile({filePath:'Test1.pdf',fileName:'myfile.pdf'})
        cy.get('#file-submit').click();
        cy.wait(5000);
        cy.get('h3').should('have.text','File Uploaded!')
    })

    it('File Upload - Drag and Drop', () => {
        cy.visit('http://the-internet.herokuapp.com/upload')
        cy.get('#drag-drop-upload').attachFile("Test1.pdf",{subjectType:'drag-n-drop'})
        cy.get('#drag-drop-upload').attachFile(["Test1.pdf", "Test2.pdf"],{subjectType:'drag-n-drop'})
        cy.wait(5000);
    })

    it.only('Multiple files upload', () => {
        cy.visit('https://davidwalsh.name/demo/multiple-file-upload.php')
        cy.get('#filesToUpload').attachFile(['Test1.pdf','Test2.pdf'])
       // cy.wait(5000);
    })
    
})