/// <reference types="Cypress" />

describe('Link Demo', () => {

    it('Link Demo', () => {
     // Launching the application
     cy.visit('https://demo.guru99.com/test/newtours/')
    
     //To get the number of links in webpage
     cy.get('a').then($elements => {
        let countoflinks = $elements.length
        cy.log("Total Links", countoflinks)
     })
     cy.get('a').should('have.length', 61)

     //To print all links
     cy.get('a').each($elt => {
        cy.log($elt.text())
     })
    
     //To click a link
     cy.contains('Hotels').click()
    })
})
