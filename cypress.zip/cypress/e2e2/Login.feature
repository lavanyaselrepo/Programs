Feature: Login to Application

    Scenario: Validate login page
    Given I open login page
    When verify title
    # Then I should see homepage