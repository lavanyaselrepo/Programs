// /// <reference types="Cypress" />

// describe('My test suite', () => {

//   it('Fixture Demo Test', () => {

//     // Launch my application
//     cy.fixture('Orangehrm').then((data) => {
//       cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')

//       data.forEach((userdata) => {
//         cy.get("input[placeholder='Username']").type(userdata.username)   // username
//         cy.get("input[placeholder='Password']").type(userdata.password) // password
//         cy.get("button[type='submit']").click(); // click on login
//         if (userdata.username == 'Admin' && userdata.password == 'admin123') {
//           cy.get(':nth-child(2) > .oxd-main-menu-item').should('have.text', userdata.expected) // checking for successful login
//           cy.get('.oxd-userdropdown-tab > .oxd-icon').click()  // click on dropdown
//           cy.get(':nth-child(4) > .oxd-userdropdown-link').click() // click on logout
//         }
//         else {
//           cy.get('oxd-text.oxd-text--p.oxd-alert-content-text').should('have.text', userdata.expected)
//         }
//       })
//     })
//   })
// })

/// <reference types="Cypress" />




describe("My test suite", () => {

  it("Fixture Demo Test", () => {

    // Launch my application




    // Launch the application




    cy.fixture("Orangehrm").then((data) => {

      cy.visit(

        "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

      );




      data.forEach((userdata) => {

        cy.get("input[placeholder='Username']").type(userdata.username); // username
        cy.get("input[placeholder='Password']").type(userdata.password); // password
        cy.get("button[type='submit']").click(); // click on login

        if (userdata.username == "Admin" && userdata.password == "admin123") {

          cy.get(":nth-child(2) > .oxd-main-menu-item").should(

            "have.text",

            userdata.expected

          ); // checking for successful login




          cy.get(".oxd-userdropdown-tab > .oxd-icon").click(); // click on dropdown




          cy.get(":nth-child(4) > .oxd-userdropdown-link").click(); // click on logout

        } else {

          cy.get(".oxd-alert-content > .oxd-text").should(

            "have.text",

            userdata.expected

          );

        }

      });

    });

  });

});