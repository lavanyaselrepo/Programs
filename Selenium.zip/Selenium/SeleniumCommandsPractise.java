import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumCommandsPractise {
	@SuppressWarnings("deprecation")
	public static void main (String args[]) {
		System.out.println("INto the class file ");
		
		//Initiatise the web driver //IE //FF//Chrome
		
		WebDriver driver = new ChromeDriver();
		
		//Launching the url 
		driver.get("https://www.amazon.in/");
		
//1) Navigation Commands-5 commands
		//1
		driver.get("give some url ");//open theurl in the chrome browser 
		//2
		driver.navigate().back();
		//3
		driver.navigate().forward();
		//4 
		driver.navigate().refresh();
		//5
		driver.navigate().to("url");
//=======================================================================	
		
//2) manipulation /Interaction commands (6)
		 
		//2 steps -->inspect element and find the webelement 
		//using the webelement we can do /perfrom manipulation/ Interaction with UI 
		
		//Locator?- 8 locators 
		//Findelement vs find elements?
		
		//step1
		WebElement searchBox=driver.findElement(By.xpath("//*[@id='twotabsearchtextbox']"));
		
		//step2
		//1) enter a value
		searchBox.sendKeys("AC");
		//2) delete the entered value
		searchBox.clear();		
		//4)  submit button
		searchBox.submit();	
		//6 click on any UI		
		searchBox.click();
		
		//Selecting Items in a Multiple SELECT elements//drop down // 2021[0],2022[1],2023[2]
				driver.get("url");
				Select years = new Select(driver.findElement(By.id(" years ")));
				years.selectByVisibleText("2021");
				years.selectByIndex(1);
				years.selectByValue("2021");
		
		//actions class -java 
		
		
			
//=======================================================================	
		
//3) Synchronication commands (7) --> (wait statement)
		
		
//Synchronization can be classified into two categories:

//1. Unconditional-2
		
	//	Wait() and Thread.Sleep();
		try {
			searchBox.wait(1000);
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//2. Conditional Synchronization- 3
		
	//	1. Implicit Wait.
		
		//syntax
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("url");
		//"daysToSubtract"
		driver.manage().timeouts().getPageLoadTimeout().minusDays(2);
		driver.manage().timeouts().setScriptTimeout(10, TimeUnit.SECONDS);
	
		
		
	//  2.	Explicit Wait:
			 WebDriverWait Exwait = new WebDriverWait(driver, 10);
			 Exwait.until(ExpectedConditions.visibilityOfElementLocated(By.id("searchBox")));
			
			 
	    
	 //3. Fluent Wait:
	    Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
	    		//*timeToWaitInSec*
	    		//Wait for the condition
				.withTimeout(Duration.ofSeconds(50)) 	
				//*TimeToTryinMillisec*
				  // which to check for the condition with interval of 5o m.second
				.pollingEvery(Duration.ofMillis(10)) 
				  //Which will ignore the NoSuchElementException
				.ignoring(NoSuchElementException.class);
	    
	    searchBox.click();
	    
	     //search box 30 sec 
	    //wait until this is visible 5 mins 
	    
	    //30 sec max
	    //5 every sec ignore 
	    //10 sec  ignore 
	    //15 sec  it will come out of the wait statement     
	    
	    //15 sec -another 15 sec is saved 
	    
	 	    
	    
		
		
//=======================================================================			
		
//Inspection / Interrogation commands (22)
	    
	    //locators: 8 // unique always // only 1 result 
	    
	    //2nd  preference is xpath 
	    WebElement xpath= driver.findElement(By.xpath("//*[@id='nav-xshop']/a[1]"));  
	    
	   // customisation xpath :  	if you have text then u can customise the xpath
	  //a[contains(.,'Best Sellers')]
	    
	    //1st preference is id
	    WebElement id=driver.findElement(By.id(""));	    
	    WebElement name=driver.findElement(By.name(""));
	    
	    
	    WebElement className=driver.findElement(By.className(""));
	    WebElement element=driver.findElement(By.cssSelector(""));
	    WebElement elcssSelectorement=driver.findElement(By.tagName(""));
	    WebElement linkText=driver.findElement(By.linkText(""));
	    WebElement partialLinkText=driver.findElement(By.partialLinkText(""));
	
	    
	    
	    //Diff bw findelement VS findelements	
	   driver.findElement(By.id(""));//first instance 
	   List<WebElement>  myname  = driver.findElements(By.id("jenita"));  // take all the instances will be taken 
	   
	   
	    driver.getTitle();
	    driver.getCurrentUrl();
	    driver.getPageSource();
	    
	    
	    searchBox.getText();
	    searchBox.getAttribute("");
	    searchBox.getTagName();
	    
	    searchBox.isDisplayed();
	    searchBox.isEnabled();// 
	    searchBox.isSelected();//Radio button //checkboxes 
	    
	    searchBox.getSize();
	    searchBox.getLocation();
	    searchBox.getCssValue("");   
	    
//=======================================================================			
//Domain commands 
		
	
		
	}

}
	