#!/usr/bin/env python3
"""
Cleanup script to remove globally-registered listeners from XML suite files.
TestNameFilter and Reporter are now auto-loaded via ServiceLoader.
"""

import os
import re
from pathlib import Path

# Listeners to remove (now globally registered)
GLOBAL_LISTENERS = [
    'hwqe.baseframework.utilities.TestNameFilter',
    'hwqe.baseframework.utilities.Reporter',
]

def cleanup_xml_file(filepath: Path) -> bool:
    """Remove global listeners from an XML file. Returns True if modified."""
    content = filepath.read_text()
    original = content
    
    # Remove listener lines for global listeners
    for listener in GLOBAL_LISTENERS:
        # Match the full listener line with any whitespace
        pattern = rf'\s*<listener class-name="{re.escape(listener)}"\s*/?>\s*\n?'
        content = re.sub(pattern, '', content)
    
    # Check if listeners block is now empty
    # Match <listeners> with only whitespace inside </listeners>
    empty_listeners_pattern = r'<listeners>\s*</listeners>\s*\n?'
    content = re.sub(empty_listeners_pattern, '', content)
    
    # Also handle multi-line empty listeners
    empty_listeners_pattern2 = r'<listeners>\n\s*</listeners>\s*\n?'
    content = re.sub(empty_listeners_pattern2, '', content)
    
    # Clean up multiple blank lines
    content = re.sub(r'\n{3,}', '\n\n', content)
    
    if content != original:
        filepath.write_text(content)
        return True
    return False

def main():
    print("🐕 Cleaning up duplicate listener entries from suite XMLs...")
    print("   (TestNameFilter + Reporter are now globally registered via ServiceLoader)")
    print()
    
    # Find all suite XML files
    suite_dirs = [
        'src/test/resources/suites',
        'digitalPharmacy/src/test/resources/suites',
        'foundations/src/test/resources/suites',
        'pharmacy-ui/src/test/resources/suites',
    ]
    
    modified_count = 0
    total_count = 0
    
    for suite_dir in suite_dirs:
        suite_path = Path(suite_dir)
        if not suite_path.exists():
            continue
            
        for xml_file in suite_path.rglob('*.xml'):
            total_count += 1
            if cleanup_xml_file(xml_file):
                print(f"  Cleaned: {xml_file}")
                modified_count += 1
    
    print()
    print(f"✅ Done! Modified {modified_count}/{total_count} files")
    print("🐾 Listeners are now globally registered - no XML entries needed!")

if __name__ == '__main__':
    main()
