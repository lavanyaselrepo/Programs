#!/usr/bin/env python3
"""Orchestrate the complete Excel to JSON migration.

This script runs the entire migration pipeline:
1. Convert all Excel files to JSON
2. Validate the conversion
3. Update Java file references
4. Optionally delete original Excel files
"""
import argparse
import re
import subprocess
import sys
from pathlib import Path

# Allowlist of scripts that can be executed
_ALLOWED_SCRIPTS = frozenset({
    "excel_to_json_converter.py",
    "validate_migration.py", 
    "update_java_references.py",
})


class MigrationOrchestrator:
    """Orchestrates the full Excel to JSON migration."""

    def __init__(
        self,
        project_root: Path,
        dry_run: bool = True,
        verbose: bool = False,
        delete_excel: bool = False,
    ):
        self.project_root = project_root
        self.dry_run = dry_run
        self.verbose = verbose
        self.delete_excel = delete_excel
        self.scripts_dir = project_root / "scripts"

    def _run_script(self, script_name: str, *args) -> bool:
        """Run a migration script and return success status.
        
        Uses an allowlist to prevent command injection attacks.
        """
        # Validate script name against allowlist (prevents command injection)
        if script_name not in _ALLOWED_SCRIPTS:
            raise ValueError(f"Script '{script_name}' is not in the allowed scripts list")
        
        # Validate script name format (defense in depth)
        if not re.match(r'^[a-z_]+\.py$', script_name):
            raise ValueError(f"Invalid script name format: '{script_name}'")
        
        script_path = (self.scripts_dir / script_name).resolve()
        
        # Ensure script exists and is within scripts directory
        if not script_path.exists():
            raise FileNotFoundError(f"Script not found: {script_path}")
        
        try:
            script_path.relative_to(self.scripts_dir.resolve())
        except ValueError:
            raise ValueError(f"Script path escapes scripts directory: {script_path}")
        
        # Sanitize arguments - only allow safe characters
        sanitized_args = []
        for arg in args:
            arg_str = str(arg)
            # Allow alphanumeric, path separators, dots, hyphens, underscores
            if not re.match(r'^[\w.\-/\\:]+$', arg_str):
                raise ValueError(f"Unsafe argument detected: '{arg_str}'")
            sanitized_args.append(arg_str)
        
        cmd = [sys.executable, str(script_path)] + sanitized_args

        if self.verbose:
            print(f"\nRunning: {' '.join(cmd)}")

        # shell=False is set explicitly (not relying on default) so no shell
        # interpolation occurs. Safety chain:
        #   - script_name validated against _ALLOWED_SCRIPTS allowlist + regex
        #   - script_path resolved and verified within scripts_dir via relative_to()
        #   - each arg validated against r'^[\w.\-/\\:]+$' (no shell metacharacters)
        result = subprocess.run(  # nosec B603 B607 # noqa: S603 S607
            cmd, capture_output=False, shell=False
        )
        return result.returncode == 0

    def run_conversion(self) -> bool:
        """Step 1: Convert all Excel files to JSON."""
        print("\n" + "=" * 60)
        print("STEP 1: CONVERTING EXCEL FILES TO JSON")
        print("=" * 60)

        args = [str(self.project_root)]
        if self.verbose:
            args.append("-v")

        return self._run_script("excel_to_json_converter.py", *args)

    def run_validation(self) -> bool:
        """Step 2: Validate the conversion."""
        print("\n" + "=" * 60)
        print("STEP 2: VALIDATING MIGRATION ACCURACY")
        print("=" * 60)

        args = [str(self.project_root)]
        if self.verbose:
            args.append("-v")

        return self._run_script("validate_migration.py", *args)

    def run_reference_update(self) -> bool:
        """Step 3: Update Java file references."""
        print("\n" + "=" * 60)
        print("STEP 3: UPDATING JAVA FILE REFERENCES")
        print("=" * 60)

        args = [str(self.project_root)]
        if not self.dry_run:
            args.append("--apply")
        if self.verbose:
            args.append("-v")
        args.extend(["--report", str(self.project_root / "migration_report.txt")])

        return self._run_script("update_java_references.py", *args)

    def cleanup_excel_files(self) -> int:
        """Step 4: Delete original Excel files (optional)."""
        print("\n" + "=" * 60)
        print("STEP 4: CLEANING UP ORIGINAL EXCEL FILES")
        print("=" * 60)

        deleted = 0
        for xlsx_path in self.project_root.rglob("*.xlsx"):
            # Skip temp files
            if xlsx_path.name.startswith("~$"):
                continue

            json_path = xlsx_path.with_suffix(".json")
            if json_path.exists():
                if self.dry_run:
                    print(f"  Would delete: {xlsx_path}")
                else:
                    xlsx_path.unlink()
                    print(f"  Deleted: {xlsx_path}")
                deleted += 1

        print(f"\n{'Would delete' if self.dry_run else 'Deleted'}: {deleted} Excel files")
        return deleted

    def run(self) -> bool:
        """Run the full migration pipeline."""
        print("\n" + "#" * 60)
        print("# EXCEL TO JSON MIGRATION PIPELINE")
        print("#" * 60)
        print(f"\nProject root: {self.project_root}")
        print(f"Dry run: {self.dry_run}")
        print(f"Delete Excel files after: {self.delete_excel}")

        # Step 1: Convert
        if not self.run_conversion():
            print("\n❌ CONVERSION FAILED - aborting migration")
            return False

        # Step 2: Validate
        if not self.run_validation():
            print("\n❌ VALIDATION FAILED - some conversions may be incorrect")
            print("   Review issues above before proceeding")
            if not self.dry_run:
                response = input("\nContinue anyway? (y/N): ")
                if response.lower() != "y":
                    return False

        # Step 3: Update references
        if not self.run_reference_update():
            print("\n⚠️  REFERENCE UPDATE had issues")

        # Step 4: Cleanup (optional)
        if self.delete_excel:
            self.cleanup_excel_files()

        # Final summary
        print("\n" + "#" * 60)
        print("# MIGRATION COMPLETE")
        print("#" * 60)

        if self.dry_run:
            print("\n⚠️  DRY RUN - No files were actually modified")
            print("   Run with --apply to make real changes")
            print("   Add --delete-excel to remove original files after migration")
        else:
            print("\n✅ Migration completed successfully!")
            print("\nNext steps:")
            print("  1. Review migration_report.txt for all changes")
            print("  2. Update your DataProvider/XlsContext to read JSON")
            print("  3. Run your test suite to verify everything works")
            print("  4. Commit the changes to git")

        return True


def main():
    parser = argparse.ArgumentParser(
        description="Run the complete Excel to JSON migration"
    )
    parser.add_argument(
        "--project-root",
        type=Path,
        default=Path("."),
        help="Project root directory (default: current directory)",
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Actually perform the migration (default is dry-run)",
    )
    parser.add_argument(
        "--delete-excel",
        action="store_true",
        help="Delete original Excel files after successful migration",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output",
    )

    args = parser.parse_args()
    
    # Resolve and validate project root
    project_root = args.project_root.resolve()
    if not project_root.exists():
        print(f"ERROR: Project root does not exist: {args.project_root}", file=sys.stderr)
        sys.exit(1)
    if not project_root.is_dir():
        print(f"ERROR: Project root must be a directory: {args.project_root}", file=sys.stderr)
        sys.exit(1)

    orchestrator = MigrationOrchestrator(
        project_root=project_root,
        dry_run=not args.apply,
        verbose=args.verbose,
        delete_excel=args.delete_excel,
    )

    success = orchestrator.run()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
