#!/usr/bin/env python3
"""Convert Excel (.xlsx) files to JSON format.

Each Excel file becomes a JSON file where:
- Top-level keys are sheet names
- Each sheet is an array of row objects (column headers become keys)
- Handles dates, numbers, and special types gracefully
"""
import argparse
import json
import sys
from datetime import datetime, date
from pathlib import Path
from typing import Any


def _sanitize_path(user_path: Path, base_dir: Path) -> Path:
    """Validate and sanitize a path to prevent path traversal attacks.
    
    Resolves the path and ensures it stays within the base directory.
    Raises ValueError if path traversal is detected.
    """
    resolved_base = base_dir.resolve()
    resolved_path = (base_dir / user_path).resolve() if not user_path.is_absolute() else user_path.resolve()
    
    # Check that resolved path is within the base directory
    try:
        resolved_path.relative_to(resolved_base)
    except ValueError:
        raise ValueError(
            f"Path traversal detected: '{user_path}' escapes base directory '{resolved_base}'"
        )
    
    return resolved_path


try:
    import openpyxl
except ImportError:
    print("ERROR: openpyxl is required. Install with: pip install openpyxl")
    sys.exit(1)


class ExcelToJsonConverter:
    """Converts Excel workbooks to JSON format."""

    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.stats = {
            "total_files": 0,
            "converted": 0,
            "skipped": 0,
            "errors": [],
        }

    def _serialize_value(self, value: Any) -> Any:
        """Serialize a cell value to JSON-compatible format."""
        if value is None:
            return None
        if isinstance(value, (datetime, date)):
            return value.isoformat()
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            # Handle Excel's weird float representations
            if isinstance(value, float) and value.is_integer():
                return int(value)
            return value
        return str(value).strip()

    def _sheet_to_records(self, sheet) -> list[dict]:
        """Convert a worksheet to a list of record dictionaries."""
        rows = list(sheet.iter_rows(values_only=True))
        if not rows:
            return []

        # First row is headers
        headers = [str(h).strip() if h else f"column_{i}" for i, h in enumerate(rows[0])]
        
        # Remove trailing empty columns
        while headers and (headers[-1].startswith("column_") or not headers[-1]):
            headers.pop()

        records = []
        for row in rows[1:]:
            # Skip completely empty rows
            if not any(cell is not None and str(cell).strip() for cell in row):
                continue

            record = {}
            for i, header in enumerate(headers):
                value = row[i] if i < len(row) else None
                record[header] = self._serialize_value(value)
            records.append(record)

        return records

    def convert_workbook(self, excel_path: Path) -> dict:
        """Convert an Excel workbook to a dictionary structure."""
        wb = openpyxl.load_workbook(excel_path, read_only=True, data_only=True)
        result = {}

        for sheet_name in wb.sheetnames:
            sheet = wb[sheet_name]
            records = self._sheet_to_records(sheet)
            result[sheet_name] = records
            if self.verbose:
                print(f"    Sheet '{sheet_name}': {len(records)} records")

        wb.close()
        return result

    def convert_file(
        self, excel_path: Path, output_path: Path | None = None, base_dir: Path | None = None
    ) -> Path | None:
        """Convert a single Excel file to JSON.
        
        Args:
            excel_path: Path to Excel file
            output_path: Optional output path for JSON file
            base_dir: Base directory for path validation (prevents path traversal)
        """
        if base_dir is None:
            base_dir = Path.cwd()
        
        # Sanitize paths to prevent path traversal
        excel_path = _sanitize_path(excel_path, base_dir)
        
        if output_path is None:
            output_path = excel_path.with_suffix(".json")
        else:
            output_path = _sanitize_path(output_path, base_dir)

        self.stats["total_files"] += 1

        # Skip temp files (Excel creates these)
        if excel_path.name.startswith("~$"):
            if self.verbose:
                print(f"SKIP (temp file): {excel_path}")
            self.stats["skipped"] += 1
            return None

        try:
            if self.verbose:
                print(f"Converting: {excel_path}")

            data = self.convert_workbook(excel_path)

            # Write JSON with pretty formatting.
            # Inline path traversal guard: output_path is already resolved by
            # _sanitize_path above, but we repeat the relative_to check here so
            # static analysis tools can verify safety at the point of the open() call.
            resolved_output = output_path.resolve()
            try:
                resolved_output.relative_to(base_dir.resolve())
            except ValueError:
                raise ValueError(
                    f"Output path escapes base directory: {output_path}"
                )
            resolved_output.parent.mkdir(parents=True, exist_ok=True)
            with open(resolved_output, "w", encoding="utf-8") as f:  # nosec B324
                json.dump(data, f, indent=2, ensure_ascii=False)

            self.stats["converted"] += 1
            return output_path

        except Exception as e:
            error_msg = f"{excel_path}: {e}"
            self.stats["errors"].append(error_msg)
            print(f"ERROR: {error_msg}", file=sys.stderr)
            return None

    def convert_directory(self, root_dir: Path, output_dir: Path | None = None) -> list[Path]:
        """Convert all Excel files in a directory tree."""
        converted = []

        # Resolve base directory for path validation
        base_dir = root_dir.resolve()
        output_base = None
        if output_dir:
            output_base = output_dir.resolve()
            # Sanitize output_base to prevent path traversal
            output_base = _sanitize_path(output_base, base_dir)

        for excel_path in root_dir.rglob("*.xlsx"):
            try:
                # Sanitize each path from rglob before processing
                sanitized_excel_path = _sanitize_path(excel_path, base_dir)

                if output_base:
                    # Preserve relative structure
                    rel_path = sanitized_excel_path.relative_to(root_dir)
                    output_path = output_base / rel_path.with_suffix(".json")
                    # Sanitize the constructed output path
                    output_path = _sanitize_path(output_path, base_dir)
                else:
                    output_path = None

                result = self.convert_file(sanitized_excel_path, output_path, base_dir=base_dir)
                if result:
                    converted.append(result)
            except ValueError as e:
                # Skip paths that fail sanitization (shouldn't happen with rglob, but defensive)
                error_msg = f"{excel_path}: Path validation error - {e}"
                self.stats["errors"].append(error_msg)
                print(f"ERROR: {error_msg}", file=sys.stderr)

        return converted

    def print_summary(self):
        """Print conversion statistics."""
        print("\n" + "=" * 50)
        print("CONVERSION SUMMARY")
        print("=" * 50)
        print(f"Total files found:  {self.stats['total_files']}")
        print(f"Successfully converted: {self.stats['converted']}")
        print(f"Skipped (temp files):   {self.stats['skipped']}")
        print(f"Errors:                 {len(self.stats['errors'])}")

        if self.stats["errors"]:
            print("\nErrors:")
            for err in self.stats["errors"]:
                print(f"  - {err}")


def main():
    parser = argparse.ArgumentParser(
        description="Convert Excel (.xlsx) files to JSON format"
    )
    parser.add_argument(
        "input",
        type=Path,
        help="Excel file or directory to convert",
    )
    parser.add_argument(
        "-o", "--output",
        type=Path,
        help="Output file/directory (defaults to same location with .json extension)",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output",
    )
    parser.add_argument(
        "--in-place",
        action="store_true",
        help="Write JSON files next to Excel files (default behavior)",
    )

    args = parser.parse_args()

    # Resolve and validate input path early
    input_path = args.input.resolve()
    if not input_path.exists():
        print(f"ERROR: {args.input} does not exist", file=sys.stderr)
        sys.exit(1)

    # Use current working directory as the safe base directory
    base_dir = Path.cwd().resolve()

    # Sanitize input path to prevent path traversal
    try:
        input_path = _sanitize_path(input_path, base_dir)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    converter = ExcelToJsonConverter(verbose=args.verbose)

    if input_path.is_file():
        output_path = None
        if args.output:
            output_path = args.output.resolve()
            # Sanitize output path to prevent path traversal
            try:
                output_path = _sanitize_path(output_path, base_dir)
            except ValueError as e:
                print(f"ERROR: {e}", file=sys.stderr)
                sys.exit(1)
        result = converter.convert_file(input_path, output_path, base_dir=base_dir)
        if result:
            print(f"Created: {result}")
    else:
        output_dir = None
        if args.output:
            output_dir = args.output.resolve()
            # Sanitize output directory to prevent path traversal
            try:
                output_dir = _sanitize_path(output_dir, base_dir)
            except ValueError as e:
                print(f"ERROR: {e}", file=sys.stderr)
                sys.exit(1)
        results = converter.convert_directory(input_path, output_dir)
        print(f"\nCreated {len(results)} JSON files")

    converter.print_summary()

    if converter.stats["errors"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
