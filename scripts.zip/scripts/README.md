# Excel to JSON Migration Scripts

This directory contains Python scripts to migrate test data from Excel (.xlsx) to JSON format.

## Why JSON?

- **Faster parsing** at compilation/test time (no Excel library overhead)
- **Git-friendly** - see actual data diffs in PRs
- **Smaller memory footprint** - no need to load entire workbook
- **Multi-sheet support** - sheets become JSON keys

## Quick Start

### 1. Install Dependencies

```bash
# Using uv (recommended at Walmart)
uv pip install -r scripts/requirements.txt \
    --index-url https://pypi.ci.artifacts.walmart.com/artifactory/api/pypi/external-pypi/simple \
    --allow-insecure-host pypi.ci.artifacts.walmart.com

# Or with pip
pip install -r scripts/requirements.txt
```

### 2. Run Dry Run (See What Would Happen)

```bash
python scripts/run_migration.py --project-root . --verbose
```

### 3. Run the Actual Migration

```bash
# Convert files and update Java references
python scripts/run_migration.py --project-root . --apply

# Or also delete original Excel files
python scripts/run_migration.py --project-root . --apply --delete-excel
```

## Individual Scripts

### excel_to_json_converter.py

Converts Excel files to JSON format.

```bash
# Convert a single file
python scripts/excel_to_json_converter.py path/to/file.xlsx

# Convert entire directory
python scripts/excel_to_json_converter.py src/test/resources/TestData -v
```

### validate_migration.py

Validates that JSON files match their Excel sources.

```bash
# Validate all conversions
python scripts/validate_migration.py src/test/resources/TestData -v
```

### update_java_references.py

Updates Java files to reference .json instead of .xlsx.

```bash
# Dry run (see what would change)
python scripts/update_java_references.py src/test/java

# Actually apply changes
python scripts/update_java_references.py src/test/java --apply

# Generate detailed report
python scripts/update_java_references.py src/test/java --report changes.txt
```

## JSON Format

Each Excel file becomes a JSON file with this structure:

```json
{
  "Sheet1": [
    {"Column1": "value1", "Column2": "value2"},
    {"Column1": "value3", "Column2": "value4"}
  ],
  "Sheet2": [
    {"ColA": "data1", "ColB": "data2"}
  ]
}
```

- Top-level keys are sheet names
- Each sheet is an array of row objects
- Column headers become object keys
- Dates are ISO 8601 formatted
- Numbers preserve their type (int vs float)

## Java Integration

After migration, you have two options:

### Option 1: Use JsonContext Directly

```java
// Before (Excel)
XlsContext xls = new XlsContext(filePath, "Sheet1");

// After (JSON)
JsonContext json = new JsonContext(filePath, "Sheet1");
// Same API - getColumnValues, getRowValues, getCellValues
```

### Option 2: Use DataContextFactory (Recommended)

```java
// Works with both .xlsx and .json files automatically
DataContextFactory.DataContext ctx = DataContextFactory.create(filePath, "Sheet1");
```

## Rollback

If something goes wrong:

1. JSON files are created alongside Excel files (not replacing them)
2. Use git to revert Java reference changes
3. Delete generated .json files: `find . -name "*.json" -path "*/TestData/*" -delete`

## Notes

- Temp files (~$*.xlsx) are automatically skipped
- Empty rows are filtered out
- Formula cells are evaluated to their calculated values
- The migration is idempotent - running it twice won't break anything
