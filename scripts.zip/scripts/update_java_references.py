#!/usr/bin/env python3
"""Update Java file references from .xlsx to .json.

This script finds all Java files that reference .xlsx files and updates
them to reference .json files instead.
"""
import argparse
import re
import sys
from pathlib import Path
from typing import NamedTuple


class Replacement(NamedTuple):
    """Represents a single file replacement."""
    file_path: Path
    line_number: int
    old_text: str
    new_text: str


class JavaReferenceUpdater:
    """Updates Excel references in Java files to JSON."""

    # Pattern to match .xlsx file references in Java code
    XLSX_PATTERN = re.compile(
        r'(["\'])((?:[^"\'/]*/)*)([^"\'/]+)\.xlsx(["\'])'
    )

    def __init__(self, dry_run: bool = True, verbose: bool = False):
        self.dry_run = dry_run
        self.verbose = verbose
        self.stats = {
            "files_scanned": 0,
            "files_modified": 0,
            "references_updated": 0,
            "replacements": [],
        }

    def _find_replacements(self, content: str, file_path: Path) -> list[tuple[int, str, str]]:
        """Find all .xlsx references in content and return replacement info."""
        replacements = []
        lines = content.split("\n")

        for i, line in enumerate(lines, 1):
            for match in self.XLSX_PATTERN.finditer(line):
                old_text = match.group(0)
                # Replace .xlsx with .json, keeping quotes
                new_text = f"{match.group(1)}{match.group(2)}{match.group(3)}.json{match.group(4)}"
                replacements.append((i, old_text, new_text))

                if self.verbose:
                    print(f"  Line {i}: {old_text} -> {new_text}")

        return replacements

    def update_file(self, java_path: Path) -> bool:
        """Update a single Java file's Excel references."""
        self.stats["files_scanned"] += 1

        try:
            content = java_path.read_text(encoding="utf-8")
        except Exception as e:
            print(f"ERROR reading {java_path}: {e}", file=sys.stderr)
            return False

        replacements = self._find_replacements(content, java_path)

        if not replacements:
            return False

        if self.verbose:
            print(f"\nFile: {java_path}")

        # Apply replacements
        new_content = content
        for line_num, old_text, new_text in replacements:
            new_content = new_content.replace(old_text, new_text)
            self.stats["references_updated"] += 1
            self.stats["replacements"].append(
                Replacement(java_path, line_num, old_text, new_text)
            )

        if not self.dry_run:
            try:
                java_path.write_text(new_content, encoding="utf-8")
                self.stats["files_modified"] += 1
            except Exception as e:
                print(f"ERROR writing {java_path}: {e}", file=sys.stderr)
                return False
        else:
            self.stats["files_modified"] += 1

        return True

    def update_directory(self, root_dir: Path) -> int:
        """Update all Java files in a directory tree."""
        modified_count = 0

        for java_path in root_dir.rglob("*.java"):
            if self.update_file(java_path):
                modified_count += 1

        return modified_count

    def generate_report(self, output_path: Path | None = None):
        """Generate a detailed report of all changes."""
        report_lines = [
            "EXCEL TO JSON REFERENCE UPDATE REPORT",
            "=" * 50,
            f"Files scanned:     {self.stats['files_scanned']}",
            f"Files to modify:   {self.stats['files_modified']}",
            f"References found:  {self.stats['references_updated']}",
            "",
            "DETAILED CHANGES:",
            "-" * 50,
        ]

        # Group by file
        by_file: dict[Path, list[Replacement]] = {}
        for r in self.stats["replacements"]:
            by_file.setdefault(r.file_path, []).append(r)

        for file_path, file_replacements in sorted(by_file.items()):
            report_lines.append(f"\n{file_path}:")
            for r in file_replacements:
                report_lines.append(f"  Line {r.line_number}: {r.old_text} -> {r.new_text}")

        report = "\n".join(report_lines)

        if output_path:
            output_path.write_text(report, encoding="utf-8")
            print(f"Report saved to: {output_path}")

        return report

    def print_summary(self):
        """Print summary statistics."""
        print("\n" + "=" * 50)
        print("REFERENCE UPDATE SUMMARY")
        print("=" * 50)
        print(f"Files scanned:         {self.stats['files_scanned']}")
        print(f"Files to be modified:  {self.stats['files_modified']}")
        print(f"References to update:  {self.stats['references_updated']}")

        if self.dry_run:
            print("\n⚠️  DRY RUN - No files were actually modified")
            print("   Run with --apply to make changes")


def main():
    parser = argparse.ArgumentParser(
        description="Update Java file references from .xlsx to .json"
    )
    parser.add_argument(
        "input",
        type=Path,
        help="Java file or directory to update",
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Actually modify files (default is dry-run)",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output",
    )
    parser.add_argument(
        "--report",
        type=Path,
        help="Write detailed report to file",
    )

    args = parser.parse_args()
    updater = JavaReferenceUpdater(dry_run=not args.apply, verbose=args.verbose)

    if args.input.is_file():
        updater.update_file(args.input)
    elif args.input.is_dir():
        updater.update_directory(args.input)
    else:
        print(f"ERROR: {args.input} does not exist", file=sys.stderr)
        sys.exit(1)

    if args.report:
        updater.generate_report(args.report)

    updater.print_summary()

    # Show sample of changes
    if updater.stats["replacements"] and not args.verbose:
        print("\nSample changes (first 10):")
        for r in updater.stats["replacements"][:10]:
            print(f"  {r.file_path.name}:{r.line_number}: {r.old_text} -> {r.new_text}")


if __name__ == "__main__":
    main()
