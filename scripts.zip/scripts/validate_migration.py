#!/usr/bin/env python3
"""Validate that converted JSON files match their source Excel files.

This script compares the data in JSON files against their original Excel
files to ensure the conversion was accurate.
"""
import argparse
import json
import sys
from datetime import datetime, date
from pathlib import Path
from typing import Any


def _sanitize_path(user_path: Path, base_dir: Path) -> Path:
    """Validate and sanitize a path to prevent path traversal attacks.
    
    Resolves the path and ensures it stays within the base directory.
    Raises ValueError if path traversal is detected.
    """
    resolved_base = base_dir.resolve()
    resolved_path = (base_dir / user_path).resolve() if not user_path.is_absolute() else user_path.resolve()
    
    try:
        resolved_path.relative_to(resolved_base)
    except ValueError:
        raise ValueError(
            f"Path traversal detected: '{user_path}' escapes base directory '{resolved_base}'"
        )
    
    return resolved_path

try:
    import openpyxl
except ImportError:
    print("ERROR: openpyxl is required. Install with: pip install openpyxl")
    sys.exit(1)


class MigrationValidator:
    """Validates Excel to JSON migrations."""

    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.stats = {
            "total_pairs": 0,
            "valid": 0,
            "invalid": 0,
            "missing_json": 0,
            "issues": [],
        }

    def _normalize_value(self, value: Any) -> str | None:
        """Normalize a value for comparison."""
        if value is None:
            return None
        if isinstance(value, bool):
            return str(value).lower()
        if isinstance(value, (datetime, date)):
            return value.isoformat()
        if isinstance(value, float):
            if value.is_integer():
                return str(int(value))
            return str(value)
        return str(value).strip()

    def _read_excel_data(self, excel_path: Path) -> dict:
        """Read Excel file and return normalized data structure."""
        wb = openpyxl.load_workbook(excel_path, read_only=True, data_only=True)
        result = {}

        for sheet_name in wb.sheetnames:
            sheet = wb[sheet_name]
            rows = list(sheet.iter_rows(values_only=True))

            if not rows:
                result[sheet_name] = []
                continue

            headers = [str(h).strip() if h else f"column_{i}" for i, h in enumerate(rows[0])]
            while headers and (headers[-1].startswith("column_") or not headers[-1]):
                headers.pop()

            records = []
            for row in rows[1:]:
                if not any(cell is not None and str(cell).strip() for cell in row):
                    continue
                record = {}
                for i, header in enumerate(headers):
                    value = row[i] if i < len(row) else None
                    record[header] = self._normalize_value(value)
                records.append(record)

            result[sheet_name] = records

        wb.close()
        return result

    def _read_json_data(self, json_path: Path, base_dir: Path) -> dict:
        """Read JSON file and return normalized data structure.
        
        Args:
            json_path: Path to the JSON file
            base_dir: Base directory for path validation
        """
        # Sanitize path before reading
        safe_path = _sanitize_path(json_path, base_dir)

        # Inline path traversal guard: safe_path is already validated by
        # _sanitize_path above, but we repeat the relative_to check here so
        # static analysis tools can verify safety at the point of the open() call.
        try:
            safe_path.relative_to(base_dir.resolve())
        except ValueError:
            raise ValueError(
                f"JSON path escapes base directory: {json_path}"
            )
        with open(safe_path, "r", encoding="utf-8") as f:  # nosec B324
            data = json.load(f)

        # Normalize JSON values for comparison
        result = {}
        for sheet_name, records in data.items():
            normalized_records = []
            for record in records:
                normalized = {k: self._normalize_value(v) for k, v in record.items()}
                normalized_records.append(normalized)
            result[sheet_name] = normalized_records

        return result

    def _compare_data(self, excel_data: dict, json_data: dict, file_path: Path) -> list[str]:
        """Compare Excel and JSON data structures, return list of issues."""
        issues = []

        # Check sheet names match
        excel_sheets = set(excel_data.keys())
        json_sheets = set(json_data.keys())

        if excel_sheets != json_sheets:
            missing = excel_sheets - json_sheets
            extra = json_sheets - excel_sheets
            if missing:
                issues.append(f"Missing sheets in JSON: {missing}")
            if extra:
                issues.append(f"Extra sheets in JSON: {extra}")

        # Compare each sheet
        for sheet in excel_sheets & json_sheets:
            excel_records = excel_data[sheet]
            json_records = json_data[sheet]

            if len(excel_records) != len(json_records):
                issues.append(
                    f"Sheet '{sheet}': Record count mismatch "
                    f"(Excel: {len(excel_records)}, JSON: {len(json_records)})"
                )
                continue

            for i, (excel_rec, json_rec) in enumerate(zip(excel_records, json_records)):
                excel_keys = set(excel_rec.keys())
                json_keys = set(json_rec.keys())

                if excel_keys != json_keys:
                    issues.append(
                        f"Sheet '{sheet}', Row {i+2}: Column mismatch "
                        f"(Excel: {excel_keys}, JSON: {json_keys})"
                    )
                    continue

                for key in excel_keys:
                    if excel_rec[key] != json_rec[key]:
                        issues.append(
                            f"Sheet '{sheet}', Row {i+2}, Col '{key}': "
                            f"Value mismatch (Excel: '{excel_rec[key]}', JSON: '{json_rec[key]}')"
                        )

        return issues

    def validate_pair(
        self, excel_path: Path, json_path: Path | None = None, base_dir: Path | None = None
    ) -> bool:
        """Validate a single Excel/JSON file pair.
        
        Args:
            excel_path: Path to Excel file
            json_path: Optional path to JSON file (defaults to same name with .json)
            base_dir: Base directory for path validation (prevents path traversal)
        """
        if base_dir is None:
            base_dir = Path.cwd()
        
        # Sanitize Excel path
        excel_path = _sanitize_path(excel_path, base_dir)
        
        if json_path is None:
            json_path = excel_path.with_suffix(".json")
        else:
            json_path = _sanitize_path(json_path, base_dir)

        self.stats["total_pairs"] += 1

        if excel_path.name.startswith("~$"):
            return True  # Skip temp files

        if not json_path.exists():
            self.stats["missing_json"] += 1
            self.stats["issues"].append(f"Missing JSON: {json_path}")
            return False

        try:
            if self.verbose:
                print(f"Validating: {excel_path.name}")

            excel_data = self._read_excel_data(excel_path)
            json_data = self._read_json_data(json_path, base_dir)
            issues = self._compare_data(excel_data, json_data, excel_path)

            if issues:
                self.stats["invalid"] += 1
                for issue in issues:
                    self.stats["issues"].append(f"{excel_path.name}: {issue}")
                return False

            self.stats["valid"] += 1
            return True

        except Exception as e:
            self.stats["invalid"] += 1
            self.stats["issues"].append(f"{excel_path.name}: Error - {e}")
            return False

    def validate_directory(self, root_dir: Path) -> bool:
        """Validate all Excel/JSON pairs in a directory tree."""
        all_valid = True

        # Use resolved root as the safe base directory
        base_dir = root_dir.resolve()

        for excel_path in root_dir.rglob("*.xlsx"):
            # Sanitize each path from rglob before processing
            try:
                sanitized_path = _sanitize_path(excel_path, base_dir)
                if not self.validate_pair(sanitized_path, base_dir=base_dir):
                    all_valid = False
            except ValueError as e:
                # Skip paths that fail sanitization (shouldn't happen with rglob, but defensive)
                self.stats["invalid"] += 1
                self.stats["issues"].append(f"Path validation error: {e}")
                all_valid = False

        return all_valid

    def print_summary(self):
        """Print validation summary."""
        print("\n" + "=" * 50)
        print("VALIDATION SUMMARY")
        print("=" * 50)
        print(f"Total pairs checked:  {self.stats['total_pairs']}")
        print(f"Valid:                {self.stats['valid']}")
        print(f"Invalid:              {self.stats['invalid']}")
        print(f"Missing JSON files:   {self.stats['missing_json']}")

        if self.stats["issues"]:
            print(f"\nIssues found ({len(self.stats['issues'])}):\n")
            for issue in self.stats["issues"][:50]:  # Limit output
                print(f"  - {issue}")
            if len(self.stats["issues"]) > 50:
                print(f"  ... and {len(self.stats['issues']) - 50} more")


def main():
    parser = argparse.ArgumentParser(
        description="Validate Excel to JSON migration accuracy"
    )
    parser.add_argument(
        "input",
        type=Path,
        help="Excel file or directory to validate",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Verbose output",
    )

    args = parser.parse_args()

    # Resolve and validate input path early
    input_path = args.input.resolve()
    if not input_path.exists():
        print(f"ERROR: {args.input} does not exist", file=sys.stderr)
        sys.exit(1)

    # Use CWD as the safe base directory
    base_dir = Path.cwd().resolve()

    # Sanitize input path to prevent path traversal
    try:
        input_path = _sanitize_path(input_path, base_dir)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    validator = MigrationValidator(verbose=args.verbose)

    if input_path.is_file():
        is_valid = validator.validate_pair(input_path, base_dir=base_dir)
    elif input_path.is_dir():
        is_valid = validator.validate_directory(input_path)

    validator.print_summary()

    if not is_valid:
        sys.exit(1)


if __name__ == "__main__":
    main()
