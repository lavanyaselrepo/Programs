package RestAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class AuthenticationDemo {
  @Test
  public void testAuthenticationDemo() {
	  
	  RestAssured.given()
		 		 .header("userid", "312843")
		 		 .header("password", "pass12345")
		 		 .when().get("https://lkmdemoaut.accenture.com/AccenSportzRestApi/getBearerToken")
		 		 .then()
		 		 .log().body()
		 		 .statusCode(200);
  }
}
