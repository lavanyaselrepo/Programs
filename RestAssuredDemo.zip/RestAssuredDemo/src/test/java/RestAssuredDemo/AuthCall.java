package RestAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class AuthCall {
  @Test
  public void testAuthCall() {
	  
	  String bearerToken = RestAssured.given()
			  						.header("userid", "312881")
			  						.header("password", "pass12345")
			  						.when().get("https://lkmdemoaut.accenture.com/AccenSportzRestApi/getBearerToken")
	  								.then()
	  								.statusCode(200)
	  								.extract()
	  								.asString();
	  
	  System.out.println("Bearer Token:" + bearerToken);
	  
	  System.out.println("Now doing getAllGames API call using the token retrieved in the previous call");
	  
	  Response response = RestAssured.given()
									 .header("userid", "312881")
									 .header("Authorization", "Bearer " + bearerToken)
									 .when().get("https://lkmdemoaut.accenture.com/AccenSportzRestApi/getAllGames");
	  response.prettyPrint();
	  
  }
}
