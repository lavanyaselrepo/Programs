package RestAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class AuthCalls {
	  
	  String token = "";
	  
	  @Test (priority = 0)
	  public void AuthCall() {
	  Response response = RestAssured.given()
			  						.header("userid", "312844")
			  						.header("password", "pass12345")
			  						.when().get("https://lkmdemoaut.accenture.com/AccenSportzRestApi/getBearerToken");
			  						
	  response.prettyPrint();
	  token = response.getBody().asString();
	  System.out.println("Bearer Token:" + response);
	  System.out.println("Now doing getAllGames API call using the token retrieved in the previous call");
	  
	  }
	  @Test (priority = 1)
	  public void getAllGames() {
	  Response response = RestAssured.given()
									 .header("userid", "312844")
									 .header("Authorization", "Bearer " + token)
									 .when().get("https://lkmdemoaut.accenture.com/AccenSportzRestApi/getAllGames");
	  response.prettyPrint();
	  }
	  
}
