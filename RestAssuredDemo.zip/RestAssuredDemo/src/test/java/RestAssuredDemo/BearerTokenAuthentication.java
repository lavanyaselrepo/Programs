package RestAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class BearerTokenAuthentication {
	
	
  @Test
  public void testBearerTokenAuthentication() {
	  
	  String token = "4A5yZujABTq74Aa2eCUWPeE8cpicRvHbTbEgMBah";
	  
	  Response response = RestAssured.given()
			  						.header("userid", "312843")
			  						.header("Authorization", "Bearer" + token)
			  						.when().get("https://lkmdemoaut.accenture.com/AccenSportzRestApi/getAllGames");
	  
	  response.prettyPrint();

  }
}