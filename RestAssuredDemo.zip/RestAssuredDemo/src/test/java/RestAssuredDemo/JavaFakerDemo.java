package RestAssuredDemo;

import com.github.javafaker.Faker;

public class JavaFakerDemo {
 
	public static void main(String[] args) {
		Faker faker = new Faker();
		
		System.out.println("FirstName: " + faker.name().firstName());
		System.out.println("LastName: " + faker.name().lastName());
		System.out.println("FullName: " + faker.name().fullName());
		System.out.println("Email address: " + faker.internet().emailAddress());
		System.out.println("Cell Number: " + faker.phoneNumber().cellPhone());
		System.out.println("Phone number: " + faker.phoneNumber().phoneNumber());
		System.out.println("City: " + faker.address().cityName());
		System.out.println("State: " + faker.address().state());
		System.out.println("Color: " + faker.color().name());
		
		System.out.println("DOB: " + faker.date().birthday());
		
	}
		
}