package RestAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class PostDemo {
  
	
  @Test
  public void testPostCall() {

	  String registrationDetails = "{\n"
	            + "\"address\":\"Coimbatores\",\n"
	            + "\"age\":29,\n"
	            + "\"dateofBirth\":\"2024-01-30\",\n"
	            + "\"emailId\":\"hariprasad@gmail.com\",\n"
	            + "\"firstName\":\"Hari\",\n"
	            + "\"gender\":\"Male\",\n"
	            + "\"lastName\":\"Prasad\",\n"
	            + "\"password\":\"pass12345\",\n"
	            + "\"phoneNo\":9988776655,\n"
	            + "\"weight\":62,\n"
	            + "\"zipcode\":500006\n"
	            + "}";

	    RestAssured.given()
	            .body(registrationDetails)
	            .contentType(ContentType.JSON)
	            .when()
	            .post("https://lkmdemoaut.accenture.com/AccenSportzRestApi/addNewUser")
	            .then()
	            .log().body()
	            .statusCode(200);
	}
}
