package RestAssuredDemo;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.google.gson.JsonObject;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class PostDemoUsingJavaFakerClass {

	
	@Test
	public void testPostUsingJavaFaker() {
		
		Faker faker = new Faker();
		JsonObject registrationDetails = new JsonObject();
		registrationDetails.addProperty("address", faker.address().city());
		registrationDetails.addProperty("age", faker.number().numberBetween(18, 99));
		
		Date dob = faker.date().birthday(); //Sat Jul 12 01:20:18 IST 1969
	//	System.out.println(dob);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		String formattedDOB = sdf.format(dob); //1965-21-21
	//	System.out.println(formattedDOB);
		
		registrationDetails.addProperty("dateofBirth", formattedDOB);
		registrationDetails.addProperty("emailId", faker.internet().emailAddress());
		registrationDetails.addProperty("firstName", faker.name().firstName());
		registrationDetails.addProperty("lastName", faker.name().lastName());
		registrationDetails.addProperty("gender", "Male");
		registrationDetails.addProperty("password", faker.internet().password());
		registrationDetails.addProperty("phoneNo", faker.numerify("9876543210"));
		registrationDetails.addProperty("weight", faker.number().numberBetween(50, 100));
		registrationDetails.addProperty("zipcode", faker.address().zipCode());
		
		RestAssured.given()
				   .contentType(ContentType.JSON)
				   .log().body()
				   .body(registrationDetails)
				   .when().post("https://lkmdemoaut.accenture.com/AccenSportzRestApi/addNewUser")
				   .then().log().body()
				   .statusCode(200);
	}

}
