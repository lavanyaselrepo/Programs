package RestAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;


public class PathParamsDemo {
	
	private static final String baseUrl = "https://lkmdemoaut.accenture.com/AccenSportzRestApi/";
	String bearerToken = "";
	String gameCategory = "Outdoor";
	
  @Test(priority = 1)
  public void getBearerToken() {
	  
	System.out.println("Now doing getBearerToken call");
	  
	bearerToken = RestAssured.given()
			                 .baseUri(baseUrl)
	  			 			 .header("userid", "312844")
	  			 			 .header("password", "pass12345")
	  			 			 .when().get("getBearerToken")
	  			 			 .then()
	  			 			 .statusCode(200)
	  			 			 .extract().asString();
	
	System.out.println("BearerToken generated is : " + bearerToken);  
  }
  
  @Test(priority = 2)
  public void getGamesCategory() {
	  
	  System.out.println("Now doing getGamesCategory call");
	  
	  Response response = RestAssured.given()
              						 .baseUri(baseUrl)
              						 .header("userid", "312844")
              						 .header("Authorization", "Bearer " + bearerToken)
              						 .log().uri()
              						 .pathParam("gameCategory", gameCategory)
              						 .when().post("getGamesCategory/{gameCategory}");
	  response.prettyPrint();
              						  
  }
}
