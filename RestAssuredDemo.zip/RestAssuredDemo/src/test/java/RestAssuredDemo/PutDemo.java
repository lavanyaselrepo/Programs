package RestAssuredDemo;

import java.util.HashMap;

import org.testng.annotations.Test;

import com.google.gson.Gson;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class PutDemo {

	@Test
    public void testPutCall() {

        HashMap<String, String> updatedRegistrationDetails = new HashMap<>();

        updatedRegistrationDetails.put("address", "Ooty");
        updatedRegistrationDetails.put("age", "29");
        updatedRegistrationDetails.put("dateofBirth", "2024-01-30");
        updatedRegistrationDetails.put("emailId", "hariprasad1@gmail.com");
        updatedRegistrationDetails.put("firstName", "Hari");
        updatedRegistrationDetails.put("gender", "Male");
        updatedRegistrationDetails.put("lastName", "Prasad");
        updatedRegistrationDetails.put("password", "pass12345");
        updatedRegistrationDetails.put("phoneNo", "9988776655");
        updatedRegistrationDetails.put("userID", "312786");
        updatedRegistrationDetails.put("weight", "62");
        updatedRegistrationDetails.put("zipcode", "500006");

        System.out.println("updatedRegistrationDetails are: " + updatedRegistrationDetails);

        String updatedRegistrationDetailsInJsonFormat = new Gson().toJson(updatedRegistrationDetails);

        System.out.println("updatedRegistrationDetailsInJsonFormat are: " + updatedRegistrationDetailsInJsonFormat);

        RestAssured.given()
                .body(updatedRegistrationDetailsInJsonFormat)
                .contentType(ContentType.JSON)
                .when()
                .put("https://lkmdemoaut.accenture.com/AccenSportzRestApi/updateUserDataWithPut")
                .then()
                .log().body()
                .statusCode(200);
    }
}