package RestAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class GetDemo {
  @Test
  public void testgetCall() {
	  
	  RestAssured.given()
	  			 .when().get("https://lkmdemoaut.accenture.com/AccenSportzRestApi/getUserDetails?userid=312740")
	  			 .then().log().body()
	  			 .statusCode(200);
	  
	  }
}
