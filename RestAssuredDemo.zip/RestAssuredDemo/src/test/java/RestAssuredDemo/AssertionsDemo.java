package RestAssuredDemo;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;


public class AssertionsDemo {

	private static final String base_Url = "https://lkmdemoaut.accenture.com/AccenSportzRestApi/";
	int userID = 312832;

	@Test
	public void testAssertionsDemo() {

		Response response = RestAssured.given()
							.baseUri(base_Url)
							.queryParam("userid", userID)
							.log().all().when()
							.get("getUserDetails").then().log().body().extract().response();

		response.prettyPrint();

		long apiResponseTime = response.getTimeIn(TimeUnit.MILLISECONDS);
		System.out.println("apiResponseTime is : " + apiResponseTime);

		// Expected Value: As per user story the api response should be less than 1000
		// mill seconds (with in 1 second)
		// Actual value: apiResponseTime

		Assert.assertTrue(apiResponseTime < 6000);

		Assert.assertEquals(response.getStatusCode(), 200);

		String firstName = response.jsonPath().getString("firstName");
		System.out.println("First Name from api : " + firstName);
		Assert.assertEquals(firstName, "John");

		
		 String lastName = response.jsonPath().getString("lastName");
		 System.out.println("Last Name from api : " + lastName);
		 Assert.assertNotEquals(lastName, "Smith");
		 
	}
}
