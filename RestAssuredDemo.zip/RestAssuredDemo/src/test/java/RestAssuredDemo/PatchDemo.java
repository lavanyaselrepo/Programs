package RestAssuredDemo;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import com.google.gson.Gson;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class PatchDemo {
	
  @Test
  public void testPatchCall() {
	  
	  Map<String, String> updatedRegistrationDetails = new HashMap<>();

      updatedRegistrationDetails.put("address", "Ooty");
      updatedRegistrationDetails.put("userID", "312786");
      updatedRegistrationDetails.put("emailId", "hariprasad1@gmail.com");
      
      String updatedRegistrationDetailsInJsonFormat = new Gson().toJson(updatedRegistrationDetails);

      System.out.println("updatedRegistrationDetailsInJsonFormat are: " + updatedRegistrationDetailsInJsonFormat);
	  
	  RestAssured.given()
      			 .body(updatedRegistrationDetailsInJsonFormat)
      			 .contentType(ContentType.JSON)
      			 .when()
      			 .patch("https://lkmdemoaut.accenture.com/AccenSportzRestApi/updateUserDataWithPatch")
      			 .then()
      			 .log().body()
      			 .statusCode(200);
  }
}
