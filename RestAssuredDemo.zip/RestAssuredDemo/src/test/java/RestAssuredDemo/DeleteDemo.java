package RestAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class DeleteDemo {
  @Test
  public void testDeleteDemo() {
	  
	  String userToDelete = "{\n" + "  \"userID\": 312829\n" + "}";
	  
	  RestAssured.given()
	  			 .contentType(ContentType.JSON)
	  			 .body(userToDelete)
	  			 .when().delete("https://lkmdemoaut.accenture.com/AccenSportzRestApi/deleteUser")
	  			 .then()
     			 .log().body()
     			 .statusCode(200);
  }
}
