package RestAssuredDemo;


import com.github.javafaker.Faker;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
//import org.json.JSONObject;

public class JavaFakerCreateUserTest {
    public static void main(String[] args) {
        // Create Faker instance
        Faker faker = new Faker();

        // Generate random user data
        String name = faker.name().fullName();
        String email = faker.internet().emailAddress();
        String phone = faker.phoneNumber().cellPhone();

        // Create JSON request body
//        JSONObject requestBody = new JSONObject();
//        requestBody.put("name", name);
//        requestBody.put("email", email);
//        requestBody.put("phone", phone);

        // Send POST request
        RestAssured.given()
                .baseUri("https://api.example.com")
                .basePath("/users")
                .contentType(ContentType.JSON)
               // .body(requestBody.toString())
                .when()
                .post()
                .then()
                .statusCode(201) // Expecting HTTP 201 Created
                .log().all();
    }
}

