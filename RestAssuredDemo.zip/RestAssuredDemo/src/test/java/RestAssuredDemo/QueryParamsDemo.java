package RestAssuredDemo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class QueryParamsDemo {
	
	private static final String base_Url = "https://lkmdemoaut.accenture.com/AccenSportzRestApi/";
	int userID = 312832;
	
  @Test
  public void testQueryParamsDemo() {
	  
	  
	  RestAssured.given()
	  			 .baseUri(base_Url)
	  			 .queryParam("userid", userID)
	  			 .log().all()
	  			 .when().get("getUserDetails")
	  			 .then()
	  			 .log().body()
	  			 .statusCode(200);
  }
}
