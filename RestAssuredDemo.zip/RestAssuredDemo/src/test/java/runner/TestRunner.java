package runner;


import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/Features",
       // features = "src/test/resources/Features/GetUserDetails.feature",
        glue = "stepDefinitions",
        plugin = {"pretty", "html:target/cucumber-report.html"},
        monochrome = true
)

/*@CucumberOptions(
        features = "src/test/resources/Features/GetUserInfo.feature",
        glue = {"stepDefinitions", "hooks"},
        plugin = {"pretty", "html:target/report.html"},
        monochrome = true
)*/
public class TestRunner {
}

