package hooks;

import io.cucumber.java.Before;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;

public class Hooks {

    @Before
    public void setUp(Scenario scenario) {
        System.out.println("================================");
        System.out.println("STARTING SCENARIO: " + scenario.getName());
        System.out.println("================================");
    }

    @After
    public void tearDown(Scenario scenario) {
        System.out.println("================================");
        System.out.println("ENDING SCENARIO: " + scenario.getName());
        System.out.println("STATUS: " + scenario.getStatus());
        System.out.println("================================");
    }
}