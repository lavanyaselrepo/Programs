package stepDefinitions;


import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import static org.junit.Assert.assertEquals;

public class GetUserDetailsSteps {

  //  private String baseUrl;
    Response response;

    @Given("The base url is {string}")
    public void the_base_url_is(String baseUrl) {
        RestAssured.baseURI = baseUrl;
    }

    @When("I send a GET request to {string} with userid {string}")
    public void i_send_a_get_request_to_with_userid(String endpoint, String userId) {

        response = RestAssured.given()
        		 			//  .log().all()   //print request
                			  .queryParam("userid", userId)
                			  .when().get(endpoint);
      				 
    }

    @Then("the response status code should be {int}")
    public void the_response_status_code_should_be(Integer expectedStatusCode) {
    	
    	//response.then().log().all();  // prints response
    	response.then().statusCode(expectedStatusCode);
        assertEquals(expectedStatusCode.intValue(), response.getStatusCode());
    }

    @And("the response body should contain firstname {string} and lastname {string}")
    public void the_response_body_should_contain_firstname_and_lastname(String expectedFirstName, String expectedLastName) {
    	
    	
    	String actualFirstName = response.jsonPath().getString("firstName");
    	String actualLastName = response.jsonPath().getString("lastName");
    	
   // 	System.out.println("Expected FirstName: " + expectedFirstName);
  //  	System.out.println("Actual FirstName: " + actualFirstName);
    	
    	System.out.println(response.asPrettyString());

        assertEquals(actualFirstName, expectedFirstName);
        assertEquals(actualLastName, expectedLastName);
    }
    
    @And("the response body should contain emailId {string} and gender {string}")
    public void the_response_body_should_contain_emailId_and_gender(String expectedEmailId, String expectedGender) {
    	
    	
    	String actualEmailId = response.jsonPath().getString("emailId");
    	String actualGender = response.jsonPath().getString("gender");
    	
    	System.out.println(response.asPrettyString());

        assertEquals(actualEmailId, expectedEmailId);
        assertEquals(actualGender, expectedGender);
    }
   
}