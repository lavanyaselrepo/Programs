Feature: Get User Details API Validation

  Scenario: Validate that the Get User Details API returns correct user information for a valid user Id

    Given The base url is "https://lkmdemoaut.accenture.com/AccenSportzRestApi"
    When I send a GET request to "getUserDetails" with userid "312835"
    Then the response status code should be 200
    And the response body should contain firstname "Devika" and lastname "Nayak"
  