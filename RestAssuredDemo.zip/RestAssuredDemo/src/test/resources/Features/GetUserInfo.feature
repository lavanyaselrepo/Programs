Feature: Get User Details API Validation

  Scenario: Validate user first name and last name

    Given The base url is "https://lkmdemoaut.accenture.com/AccenSportzRestApi"
    When I send a GET request to "getUserDetails" with userid "312835"
    Then the response status code should be 200
    And the response body should contain firstname "Devika" and lastname "Nayak"

    
    Scenario: Validate user emailId and gender

    Given The base url is "https://lkmdemoaut.accenture.com/AccenSportzRestApi"
    When I send a GET request to "getUserDetails" with userid "312835"
    Then the response status code should be 200
    And the response body should contain emailId "Devinayak@gmail.com" and gender "Female"