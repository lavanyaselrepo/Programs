package hwqe.baseframework.crypto;

import hwqe.baseframework.utilities.StringUtils;
import hwqe.baseframework.vaults.StratiConfigInitializer;
import io.strati.StratiServiceProvider;
import io.strati.configuration.ConfigType;

public class CloudEncryption {
    private String ccmKey;

    public CloudEncryption(String environment, String appName) {
        // Ensure Strati properties are initialized before using StratiServiceProvider
        StratiConfigInitializer.ensureInitialized();
        
        System.setProperty("runtime.context.appName", appName);
        System.setProperty("runtime.context.environmentType", environment);
        EncryptionConfig encryptionConfig = StratiServiceProvider.getInstance().getConfigurationService().get().getConfiguration(EncryptionConfig.class, ConfigType.SIMPLE);
        this.ccmKey = encryptionConfig.getKeyString();
    }

    public <T> T getJavaObject(Class<T> mapToClass, String cipherText) {
        try {
            AESCrypto aes = new AESCrypto(this.ccmKey);
            return StringUtils.convertJsonToObject(aes.decode(cipherText), mapToClass);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return null;
    }
}

