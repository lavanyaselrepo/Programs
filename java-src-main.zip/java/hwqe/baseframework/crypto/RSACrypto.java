package hwqe.baseframework.crypto;

import hwqe.baseframework.utilities.FileUtils;
import hwqe.baseframework.utilities.PropertyReader;

import javax.crypto.Cipher;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;


public class RSACrypto {
    private PropertyReader prop = PropertyReader.getInstance();

    public boolean generateKeyPair(String directoryPath) {
        try {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
            kpg.initialize(2048);
            KeyPair kp = kpg.generateKeyPair();
            File f = new File(directoryPath);
            if (!f.exists()) {
                f.mkdir();
            }
            FileOutputStream out = new FileOutputStream(directoryPath + "private.key");
            out.write(kp.getPrivate().getEncoded());
            out = new FileOutputStream(directoryPath + "public.pub");
            out.write(kp.getPublic().getEncoded());
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    private PublicKey readPublicKey(String path) {
        try {
            byte[] bytes = Files.readAllBytes(Paths.get(path));
            X509EncodedKeySpec ks = new X509EncodedKeySpec(bytes);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            return kf.generatePublic(ks);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    private PrivateKey readPrivateKey(String path) {
        try {
            byte[] bytes = Files.readAllBytes(Paths.get(path));
            PKCS8EncodedKeySpec ks = new PKCS8EncodedKeySpec(bytes);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            return kf.generatePrivate(ks);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public String encrypt(String plainText, String keyPath) {
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            if (keyPath.endsWith(".pub")) {
                cipher.init(Cipher.ENCRYPT_MODE, readPublicKey(keyPath));
            }
            if (keyPath.endsWith(".key")) {
                cipher.init(Cipher.ENCRYPT_MODE, readPrivateKey(keyPath));
            }
            return Base64.getEncoder().encodeToString(cipher.doFinal(plainText.getBytes()));
        } catch (Exception ex) {
            throw new RuntimeException("Error occured while encrypting");
        }
    }

    public String decrypt(String encryptedText) {
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.DECRYPT_MODE, readPublicKey(FileUtils.getFileFromResources(prop.getProperty("app.public_key")).getAbsolutePath()));
            return new String(cipher.doFinal(Base64.getDecoder().decode(encryptedText.getBytes())));
        } catch (Exception ex) {
            throw new RuntimeException("Error occured while decrypting");
        }
    }

    public String decrypt(String encryptedText, String keyPath) {
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            if (keyPath.endsWith(".pub")) {
                cipher.init(Cipher.DECRYPT_MODE, readPublicKey(keyPath));
            }
            if (keyPath.endsWith(".key")) {
                cipher.init(Cipher.DECRYPT_MODE, readPrivateKey(keyPath));
            }
            return new String(cipher.doFinal(Base64.getDecoder().decode(encryptedText.getBytes())));
        } catch (Exception ex) {
            throw new RuntimeException("Error occured while decrypting");
        }
    }

}
