package hwqe.baseframework.crypto;

import hwqe.baseframework.utilities.PropertyReader;
import io.strati.libs.commons.codec.binary.Hex;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.SecureRandom;
import java.util.Arrays;

public final class AESCrypto {
    // Length of the IV buffer
    private static final int GCM_IV_LENGTH = 12;
    // Length of the authentication tag (in bytes)
    private static final int GCM_TAG_LENGTH = 16;
    // Transformation name passed into Cipher constructor method
    private static final String ALGORITHM = "AES/GCM/NoPadding";
    private String key;
    PropertyReader prop = PropertyReader.getInstance();
    public AESCrypto(String key) {
        this.key = key;
    }
    public AESCrypto() {
        this.key = prop.getProperty("app.aesKey");
    }

    public String encode(String plainText) {
        try {
            // Fetches and decodes the hexadecimal key for encryption
            byte[] keyBytes = Hex.decodeHex(this.key);
            Key derivedKey = new SecretKeySpec(keyBytes, "AES");

            // Create & initialize a randomized IV buffer
            byte[] iv = new byte[GCM_IV_LENGTH];
            new SecureRandom().nextBytes(iv);

            // Create & initialize the Cipher object used for encryption
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            GCMParameterSpec ivSpec = new GCMParameterSpec(GCM_TAG_LENGTH * Byte.SIZE, iv);
            cipher.init(Cipher.ENCRYPT_MODE, derivedKey, ivSpec);

            // Encrypt the message with the cipher object
            byte[] cipherText = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
            byte[] encrypted = new byte[iv.length + cipherText.length];
            // Copy in the IV buffer and encrypted text into encrypted array
            System.arraycopy(iv, 0, encrypted, 0, iv.length);
            System.arraycopy(cipherText, 0, encrypted, iv.length, cipherText.length);

            // Encode into hexadecimal string and return result
            return Hex.encodeHexString(encrypted);
        } catch (Exception e) {
            return String.format(
                    "APP_ERROR: Failed to encode the incoming message: %s%n", e.getMessage());
        }
    }


    public String decode(String cipherText) {
        try {
            // Fetches and decodes the hexadecimal key for decryption
            byte[] keyBytes = Hex.decodeHex(this.key);
            byte[] decoded = Hex.decodeHex(cipherText);
            // Copies IV buffer and encoded text separately
            byte[] iv = Arrays.copyOfRange(decoded, 0, GCM_IV_LENGTH);

            // Creates & initializes the Cipher object used for decryption
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            GCMParameterSpec ivSpec = new GCMParameterSpec(GCM_TAG_LENGTH * Byte.SIZE, iv);
            SecretKeySpec sKey = new SecretKeySpec(keyBytes, "AES");
            cipher.init(Cipher.DECRYPT_MODE, sKey, ivSpec);

            // Decode the message, return the final result
            byte[] plainText = cipher.doFinal(decoded, GCM_IV_LENGTH, decoded.length - GCM_IV_LENGTH);
            return new String(plainText, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return String.format(
                    "APP_ERROR: Failed to decode the incoming message: %s%n", e.getMessage());
        }
    }
}
