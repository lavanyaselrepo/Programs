package hwqe.baseframework.crypto;

import io.strati.configuration.annotation.Configuration;
import io.strati.configuration.annotation.Property;

@Configuration(configName = "encryptionconfig")

public class EncryptionConfig {
    @Property(propertyName = "keyString")
    private String keyString;

    public String getKeyString() {
        return keyString;
    }

    public void setKeyString(String keyString) {
        this.keyString = keyString;
    }
}
