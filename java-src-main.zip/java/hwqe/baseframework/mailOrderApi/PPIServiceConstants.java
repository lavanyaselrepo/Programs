package hwqe.baseframework.mailOrderApi;

public class PPIServiceConstants {
  public static final String EZPAY = "EZPAY";
  public static final String PHARMACY_DETAILS_TYPE = "PHARMACY";
  public static final String PPI_CHECKOUT_CART_COLLECTION_NAME = "checkoutCartDocuments";
  public static final String DIGITAL_WALLET = "DIGITAL_WALLET";
  public static final String ZERO_PAY = "ZEROPAY";
  public static final String REGISTER = "REGISTER";
}
