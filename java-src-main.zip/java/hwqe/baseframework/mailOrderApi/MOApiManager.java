package hwqe.baseframework.mailOrderApi;

import com.microsoft.applicationinsights.core.dependencies.apachecommons.lang3.RandomStringUtils;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.mailOrderApi.dataModels.requests.Dispense.*;
import hwqe.baseframework.mailOrderApi.dataModels.requests.assignBag.AssignBagRequest;
import hwqe.baseframework.mailOrderApi.dataModels.requests.assignBag.Variables;
import hwqe.baseframework.mailOrderApi.dataModels.requests.checkoutCart.CheckoutCartRequest;
import hwqe.baseframework.mailOrderApi.dataModels.requests.checkoutCart.ItemsItem;
import hwqe.baseframework.mailOrderApi.dataModels.requests.checkoutCart.PaymentDetail;
import hwqe.baseframework.mailOrderApi.dataModels.requests.selectForDispenseRequest.SelectInput;
import hwqe.baseframework.mailOrderApi.dataModels.requests.selectForDispenseRequest.SelectfordispenseRequest;
import hwqe.baseframework.mailOrderApi.dataModels.requests.shipping.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class MOApiManager {
    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop;
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;
    public MOApiManager (){
        prop = PropertyReader.getInstance();
        prop.loadCustomProperties("config/MOAPI/");
    }
    public ServiceResponse assignBagNumber(String bagNbr){
        String gqlPayload="query searchByBagNumber($bagNumber: Int!, $include: Include, $exclude: Exclude){    " +
                "searchByBagNumber(bagNumber: $bagNumber, include: $include, exclude: $exclude){        didList        message       " +
                " searchResults{            searchedItemsDetail{                controlSet{                    " +
                "did                    doGroupId                    doGroupCode                    " +
                "userWorkLocation                    estimatePickupTime                    " +
                "initiatedDateTime                    lastModifiedDateTime                    userHomeStoreId                    " +
                "doType                    priority                    orderId                    initiatedStore                    " +
                "requestSeqNbr                    rxFillId                    rxId                    minorVersionNbr                    " +
                "orderSeqNbr                    majorVersionNbr                    companyCode                    currentAction                    " +
                "userWorkstation                    workQueueCode                    assignedUserId                    rxOriginState                    " +
                "rxPrescriberId                    dispenseState                }                dispenseDetails{                   " +
                " rxFillInfo{                        rxFillSeqNbr                        fillTypeDesc                        " +
                "partialFillInd                        fillDate                        fillItemExpDate                        " +
                "fillDaysSupplyQty                        fillItemQty                        fillQty                        " +
                "fillTypeCode                        itemMdsFamId                        earlyFillIndicator                        " +
                "emergencyFillInd                        centralFillFacilityId                        posTs                        " +
                "priceClassCode                        usualPriceAmt                        posDueAmt                        expectedSaleAmt " +
                "                       patientDueAmt                        taxAmt                        initFillOrderSeqNbr                        " +
                "thirdPartyInd                        partialFillQty                        chargeInd                        " +
                "compPriceAmt                        sumOfRemainingFillQty                        counselInfo{                            " +
                "counselNotes                            isCounselNeeded                            counselOptOutReasonCode                            " +
                "isCounselQueNeeded                            counselOptInReasonText                            counselDosageVarianceExceeded                            " +
                "counselOptOutReasonText                            counselOptInReasonCode                            counselOptOutAvailable                            " +
                "counselReasonText                        }                        dispensedItemInfo{                            itemId                            " +
                "productId                            productName                            shortName                            multiSrcCode                            " +
                "ndc                            drugEquivCode                            drugControlCode                            upcNumber                        }                        " +
                "thirdPartyInfo{                            carrierId                            carrierPlanId                            coverageInd " +
                "                           otherPayerAmt                            isTPRestriction                            isMedicareRestriction" +
                "                            phmCompanyNameAbbr                            statusCode                            insPlanRefCode      " +
                "                      txnAmount                            insPlanTypeCode                            coverageExpDate   " +
                "                         coverageCode                            insCarrPlanName                            copayAmt     " +
                "                       txnTypeCode                        }                        partialFillInfo{                      " +
                "      initialFill{                                fillQty                                mailOutInd                    " +
                "            rxfillId                                posTs                                fillDays                      " +
                "          fillExpDate                                chargeInd                            }                            finalFill{     " +
                "                           fillQty                                mailOutInd                                rxfillId               " +
                "                 posTs                                fillDays                                fillExpDate                      " +
                "          chargeInd                            }                        }                        medicaidRestrictionCodes       " +
                "                 isTaxable                        primaryPhmCompanyNameAbbr                        thirdPartyAmount             " +
                "           localThirdPartyAmount                    }                    rxInfo{                        rxNbr                   " +
                "           rxContentType                                          productMdsFamId                        lastRxFillId         " +
                "               remainingQty                        compInd                        rxOriginCode                        initialPrescribedQty   " +
                "                     presProdInfo{                            productQuantity                            gpiCode                         " +
                "   isSuboxone                            drugControlCode                            presProdStrength                          " +
                "  presProdName                            prodShortName                            prodMultiSrcCode                        }          " +
                "              commentInfo{                            subjectTypeCode                            createTs                          " +
                "  alertInd                            commentTxt                            createUserId                            commentId     " +
                "                       commentTypeCode                        }                        compoundId                        fillQty  " +
                "                      isMedicareValidatedRxActivity                    }                    orderInfo{                    " +
                "    omsOrderId                        activeFillSeq                        toteNbr                        nbrOfActiveFills        " +
                "                bagColor                        requestTypeCode                        estPickupTs                      " +
                "  eligibleDispenseTypeList                        petRxInd                        needPickupInd                        dispenseLocationInfo{   " +
                "                         locationRef                            dispenseType                            timestamp                  " +
                "          clientReferenceCode                        }                        commentInfo{                            subjectTypeCode  " +
                "                          createTs                            alertInd                            commentTxt           " +
                "                 createUserId                            commentId                            commentTypeCode                        }    " +
                "                }                    patientInfo{                        comment                        middleName                   " +
                "     patientId                        genderCode                        type                        patientName                      " +
                "  phone                        firstName                        dob                        lastName                      " +
                "  hipaaRefusalCount                        hipaaStatusCode                        patientLastCompletedFillDate                    " +
                "    onlineCustomerId                        signatureInfo{                            patientLastHipaaSignatureRelationshipCode       " +
                "                     patientLastHipaaSignatureCaptureTs                            patientMedicareSigPresent                         " +
                "   hipaaSignatureRefusalTs                        }                        patientCounselNotes                        addressInfo{     " +
                "                       city                            zip                            country                            state         " +
                "                   addressLine2                            addressLine1                        }                        paymentInfo{      " +
                "                      piHash                        }                    }                    derivedAttributes{                      " +
                "  isCSIDRequired                        isControlledSubstance                        isLiquidOrGel                        isDrugOfConcern    " +
                "                    abnRejectPrice                        abnRejectReason                        isWAMedicaidAckNeeded                        " +
                "isAbnRequired                        isCMSFormPrintNeeded                        isMedicareDrugRestriction                    }                   " +
                " pickupCustomerInfo{                        firstName                        lastName                        dob                       " +
                " idNumber                        expirationDate                        pharmacistId                        idType                       " +
                " issueAgencyCode                        relationshipType                        addressInfo{                            city               " +
                "             zipCode                            country                            state                            addressLine2          " +
                "                  addressLine1                        }                    }                    storeParms{                        " +
                "storeType                    }                }                signatureInfo{                    signature{                        " +
                "captureTs                        expirationTs                        createUserId                        centralFileId                        relationshipCode                    }                    signatureType{                        formId                        formVrsnNbr                        signatureTypeCode                        relationshipRequired                    }                }                activityObject{                    rxFillActivity{                        rxFillId                        activitySeqNbr                        activityCode                        activityUserId                     " +
                "   activityStoreNbr                        activityTs                    }                    orderDetailActivity{                        txnNbr                        orderId                        workQueCodeDesc                        activityTs                        companyCode                        sourceTypeCode                        orderSeqNbr                        activityCodeDesc                       " +
                " activitySeqNbr                        userStoreNbr                        rxOriginStoreNbr                        activityCode                        activityUserId                        workstationName                        activityLocation                        workQueCode                    }                }                shippingDetails{                    phmPackageId                    shippingOrderNbr                    shipDate                    ormdHazMatInd                    estimatedDeliveryDate                    shippingCostAmount                    transactionCarrierId                    shippingInstructionText                    deliveryMethodCode                    coldStorageInd                   " +
                " deliveryConfirmInd                    saturdayDeliveryInd                    signatureRequiredInd                    patientShipChargeInd                    phmPaymentAccountId                    paymentResponseId                    shippingStatusCode                    shippingType                    invoicePrintInd                    checkAmount                    paymentMethodCode                    patientShipFeeAmount                    customerSignaturePreferenceInd                    shippingAddress{                        name                        addressLine1                        addressLine2                        addressLine3                        addressLine4                        cityName                        countryName                        stateProvCode                        postalCode                      " +
                "  countryCode                        phoneNbr                    }                }            }        }    }},";
        AssignBagRequest assignBagRequest=AssignBagRequest.builder().query(gqlPayload).variables(Variables.builder().bagNumber(Integer.parseInt(bagNbr)).build()).build();
        req.setRequestPayload(assignBagRequest);
        req.setUrl((prop.getProperty("mo.baseUrl"))+(prop.getProperty("mo.dispenseEndpoint")));
        headers.put("WM_CONSUMER.ID", prop.getProperty("mo.consumer.id"));
        headers.put("WM_SVC.NAME",prop.getProperty("mo.service.name"));
        headers.put("WM_SVC.ENV",prop.getProperty("mo.service.env"));
        headers.put("x-hnw-rx-store-id", prop.getProperty("mo.rx.storeId"));
        headers.put("x-hnw-rx-client-workstation", prop.getProperty("mo.client.workstation"));
        headers.put("x-hnw-rx-client-name", prop.getProperty("mo.client.name"));
        headers.put("x-hnw-graphql-schema-version", prop.getProperty("mo.schema.version"));
        headers.put("x-hnw-rx-req-track-id", prop.getProperty("mo.req.trackId"));
        headers.put("x-hnw-rx-user-id", prop.getProperty("mo.rx.userId"));
        headers.put("content-type","application/json");
        req.setHeaders(headers);
        Reporter.logJSON("AssignBagNumber Request", req);
        resp=am.getRestContext().performPost(req);
        Reporter.logJSON("AssignBagNumber Response", resp.getDataResponse());
        Log.info("AssignBagNumber ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }
    public ServiceResponse selectForDispense(List<String> didList,int patientId){
        String gqlPayload="mutation selectfordispense($selectInput: SelectForDispenseInput!, $override: Boolean){\n    " +
                "selectfordispense(selectInput: $selectInput, override: $override){\n        didList\n        message\n        " +
                "selectedItemsDetail{\n            controlSet{\n                did\n                doGroupId\n                doGroupCode\n                " +
                "userWorkLocation\n                estimatePickupTime\n                initiatedDateTime\n                lastModifiedDateTime\n                " +
                "userHomeStoreId\n                doType\n                priority\n                orderId\n                initiatedStore\n                " +
                "requestSeqNbr\n                rxFillId\n                rxId\n                minorVersionNbr\n                orderSeqNbr\n                " +
                "majorVersionNbr\n                companyCode\n                currentAction\n                userWorkstation\n                workQueueCode\n                " +
                "assignedUserId\n                rxOriginState\n                rxPrescriberId\n                dispenseState\n            }\n            " +
                "dispenseDetails{\n                rxFillInfo{\n                    rxFillSeqNbr\n                    fillTypeDesc\n                    " +
                "partialFillInd\n                    fillDate\n                    fillItemExpDate\n                    fillDaysSupplyQty\n                    " +
                "fillItemQty\n                    fillQty\n                    fillTypeCode\n                    itemMdsFamId\n                    " +
                "earlyFillIndicator\n                    emergencyFillInd\n                    centralFillFacilityId\n                    posTs\n                    " +
                "priceClassCode\n                    usualPriceAmt\n                    posDueAmt\n                    expectedSaleAmt\n                    " +
                "patientDueAmt\n                    taxAmt\n                    initFillOrderSeqNbr\n                    thirdPartyInd\n                    " +
                "partialFillQty\n                    chargeInd\n                    compPriceAmt\n                    sumOfRemainingFillQty\n                    " +
                "counselInfo{\n                        counselNotes\n                        isCounselNeeded\n                        counselOptOutReasonCode\n                        " +
                "isCounselQueNeeded\n                        counselOptInReasonText\n                        counselDosageVarianceExceeded\n                        " +
                "counselOptOutReasonText\n                        counselOptInReasonCode\n                        counselOptOutAvailable\n                        " +
                "counselReasonText\n                    }\n                    dispensedItemInfo{\n                        itemId\n                        " +
                "productId\n                        productName\n                        shortName\n                        multiSrcCode\n                        " +
                "ndc\n                        drugEquivCode\n                        drugControlCode\n                        upcNumber\n                    }\n                    thirdPartyInfo{\n                        carrierId\n                        carrierPlanId\n                        coverageInd\n                        otherPayerAmt\n                        isTPRestriction\n                        isMedicareRestriction\n                        phmCompanyNameAbbr\n                        statusCode\n                        insPlanRefCode\n                        txnAmount\n                        insPlanTypeCode\n                        coverageExpDate\n                        coverageCode\n                        insCarrPlanName\n                        copayAmt\n                        txnTypeCode\n                    }\n                    partialFillInfo{\n                        initialFill{\n                            fillQty\n                            mailOutInd\n                            rxfillId\n                            posTs\n                            fillDays\n                            fillExpDate\n                            chargeInd\n                        }\n                        finalFill{\n                            fillQty\n                            mailOutInd\n                            rxfillId\n                            posTs\n                            fillDays\n                            fillExpDate\n                            chargeInd\n                        }\n                    }\n                    medicaidRestrictionCodes\n                    isTaxable\n                    primaryPhmCompanyNameAbbr\n                    thirdPartyAmount\n                    localThirdPartyAmount\n                }\n                rxInfo{\n                    rxNbr\n                    productMdsFamId\n                    lastRxFillId\n                    remainingQty\n                    compInd\n                    rxOriginCode\n                    initialPrescribedQty\n                    presProdInfo{\n                        productQuantity\n                        gpiCode\n                        isSuboxone\n                        drugControlCode\n                        presProdStrength\n                        presProdName\n                        prodShortName\n                        prodMultiSrcCode\n                    }\n                    commentInfo{\n                        subjectTypeCode\n                        createTs\n                        alertInd\n                        commentTxt\n                        createUserId\n                        commentId\n                        commentTypeCode\n                    }\n                    compoundId\n                    fillQty\n                    isMedicareValidatedRxActivity\n                }\n                orderInfo{\n                    omsOrderId\n                    activeFillSeq\n                    toteNbr\n                    nbrOfActiveFills\n                    bagColor\n                    requestTypeCode\n                    estPickupTs\n                    eligibleDispenseTypeList\n                    petRxInd\n                    needPickupInd\n                    dispenseLocationInfo{\n                        locationRef\n                        dispenseType\n                        timestamp\n                        clientReferenceCode\n                    }\n                    commentInfo{\n                        subjectTypeCode\n                        createTs\n                        alertInd\n                        commentTxt\n                        createUserId\n                        commentId\n                        commentTypeCode\n                    }\n                }\n                patientInfo{\n                    comment\n                    middleName\n                    patientId\n                    genderCode\n                    type\n                    patientName\n                    phone\n                    firstName\n                    dob\n                    lastName\n                    hipaaRefusalCount\n                    hipaaStatusCode\n                    patientLastCompletedFillDate\n                    onlineCustomerId\n                    signatureInfo{\n                        patientLastHipaaSignatureRelationshipCode\n                        patientLastHipaaSignatureCaptureTs\n                        patientMedicareSigPresent\n                        hipaaSignatureRefusalTs\n                    }\n                    patientCounselNotes\n                    addressInfo{\n                        city\n                        zip\n                        country\n                        state\n                        addressLine2\n                        addressLine1\n                    }\n                    paymentInfo{\n                        piHash\n                    }\n                }\n                derivedAttributes{\n                    isCSIDRequired\n                    isControlledSubstance\n                    isLiquidOrGel\n                    isDrugOfConcern\n                    abnRejectPrice\n                    abnRejectReason\n                    isWAMedicaidAckNeeded\n                    isAbnRequired\n                    isCMSFormPrintNeeded\n                    isMedicareDrugRestriction\n                }\n                pickupCustomerInfo{\n                    firstName\n                    lastName\n                    dob\n                    idNumber\n                    expirationDate\n                    pharmacistId\n                    idType\n                    issueAgencyCode\n                    relationshipType\n                    addressInfo{\n                        city\n                        zipCode\n                        country\n                        state\n                        addressLine2\n                        addressLine1\n                    }\n                }\n                storeParms{\n                    storeType\n                }\n            }\n            signatureInfo{\n                signature{\n                    captureTs\n                    expirationTs\n                    createUserId\n                    centralFileId\n                    relationshipCode\n                }\n                signatureType{\n                    formId\n                    formVrsnNbr\n                    signatureTypeCode\n                    relationshipRequired\n                }\n            }\n            activityObject{\n                rxFillActivity{\n                    rxFillId\n                    activitySeqNbr\n                    activityCode\n                    activityUserId\n                    activityStoreNbr\n                    activityTs\n                }\n                orderDetailActivity{\n                    txnNbr\n                    orderId\n                    workQueCodeDesc\n                    activityTs\n                    companyCode\n                    sourceTypeCode\n                    orderSeqNbr\n                    activityCodeDesc\n                    activitySeqNbr\n                    userStoreNbr\n                    rxOriginStoreNbr\n                    activityCode\n                    activityUserId\n                    workstationName\n                    activityLocation\n                    workQueCode\n                }\n            }\n            shippingDetails{\n                phmPackageId\n                shippingOrderNbr\n                shipDate\n                ormdHazMatInd\n                estimatedDeliveryDate\n                shippingCostAmount\n                transactionCarrierId\n                shippingInstructionText\n                deliveryMethodCode\n                coldStorageInd\n                deliveryConfirmInd\n                saturdayDeliveryInd\n                signatureRequiredInd\n                patientShipChargeInd\n                phmPaymentAccountId\n                paymentResponseId\n                shippingStatusCode\n                shippingType\n                invoicePrintInd\n                checkAmount\n                paymentMethodCode\n                patientShipFeeAmount\n                customerSignaturePreferenceInd\n                shippingAddress{\n                    name\n                    addressLine1\n                    addressLine2\n                    addressLine3\n                    addressLine4\n                    cityName\n                    countryName\n                    stateProvCode\n                   " +
                " postalCode\n                    countryCode\n                    phoneNbr\n                }\n            }\n        }\n    }\n}";
        SelectfordispenseRequest selectfordispenseRequest=SelectfordispenseRequest.builder().query(gqlPayload).variables(dispenseVariables(didList,patientId)).build();
        req.setRequestPayload(selectfordispenseRequest);
        req.setUrl((prop.getProperty("mo.baseUrl"))+(prop.getProperty("mo.dispenseEndpoint")));
        headers.put("WM_CONSUMER.ID", prop.getProperty("mo.consumer.id"));
        headers.put("WM_SVC.NAME",prop.getProperty("mo.service.name"));
        headers.put("WM_SVC.ENV",prop.getProperty("mo.service.env"));
        headers.put("x-hnw-rx-store-id", prop.getProperty("mo.rx.storeId"));
        headers.put("x-hnw-rx-client-workstation", prop.getProperty("mo.client.workstation"));
        headers.put("x-hnw-rx-client-name", prop.getProperty("mo.client.name"));
        headers.put("x-hnw-graphql-schema-version", prop.getProperty("mo.schema.version"));
        headers.put("x-hnw-rx-req-track-id", prop.getProperty("mo.req.trackId"));
        headers.put("x-hnw-rx-user-id", prop.getProperty("mo.rx.userId"));
        headers.put("content-type","application/json");
        req.setHeaders(headers);
        Reporter.logJSON("Select for Dispense Request", req);
        resp=am.getRestContext().performPost(req);
        Reporter.logJSON("Select for Dispense Response", resp.getDataResponse());
        Log.info("Select for Dispense ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }
    public hwqe.baseframework.mailOrderApi.dataModels.requests.selectForDispenseRequest.Variables dispenseVariables(List<String> didList,int patientId){
        hwqe.baseframework.mailOrderApi.dataModels.requests.selectForDispenseRequest.Variables dispenseVariables;
        dispenseVariables= hwqe.baseframework.mailOrderApi.dataModels.requests.selectForDispenseRequest.Variables.builder().selectInput(selectInput(didList,patientId)).override(false).build();
        return dispenseVariables;
    }
    public SelectInput selectInput(List<String> didList,int patientId){
        SelectInput selectInput;
        selectInput=SelectInput.builder().didList(didList).searchedPatientId(patientId).build();
        return selectInput;
    }
    public ServiceResponse dispense(String didList,int majorVersionNbr,int minorVersionNbr){
        String gqlPayload="mutation dispense($dispenseInput: DispenseInput!){ dispense(dispenseInput: $dispenseInput){ didList message } }";
        DispenseRequest dispenseRequest=DispenseRequest.builder().query(gqlPayload).variables(variablesDispense(didList,majorVersionNbr,minorVersionNbr)).build();
        req.setRequestPayload(dispenseRequest);
        req.setUrl((prop.getProperty("mo.baseUrl"))+(prop.getProperty("mo.dispenseEndpoint")));
        headers.put("WM_CONSUMER.ID", prop.getProperty("mo.consumer.id"));
        headers.put("WM_SVC.NAME",prop.getProperty("mo.service.name"));
        headers.put("WM_SVC.ENV",prop.getProperty("mo.service.env"));
        headers.put("x-hnw-rx-store-id", prop.getProperty("mo.rx.storeId"));
        headers.put("x-hnw-rx-client-workstation", prop.getProperty("mo.client.workstation"));
        headers.put("x-hnw-rx-client-name", prop.getProperty("mo.client.name"));
        headers.put("x-hnw-graphql-schema-version", prop.getProperty("mo.schema.version"));
        headers.put("x-hnw-rx-req-track-id", prop.getProperty("mo.req.trackId.new"));
        headers.put("x-hnw-rx-user-id", prop.getProperty("mo.rx.userId.new"));
        headers.put("content-type","application/json");
        req.setHeaders(headers);
        resp=am.getRestContext().performPost(req);
        Reporter.logJSON("Dispense Response", resp.getDataResponse());
        Log.info("Dispense ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }
    public VariablesDispense variablesDispense(String didList,int majorVersionNbr,int minorVersionNbr){
        VariablesDispense variablesDispense=VariablesDispense.builder().dispenseInput(dispenseInput(didList,majorVersionNbr,minorVersionNbr)).build();
        return variablesDispense;
    }
    public DispenseInput dispenseInput(String didList, int majorVersionNbr, int minorVersionNbr){
        DispenseInput dispenseInput;
        dispenseInput=DispenseInput.builder().dispensedItemsDetail(dispenseItemDetail(didList,majorVersionNbr,minorVersionNbr)).build();
        return dispenseInput;
    }
    public List<DispensedItemsDetailItem> dispenseItemDetail(String didList, int majorVersionNbr, int minorVersionNbr){
        List<DispensedItemsDetailItem> dispensedItemsDetailItems=new ArrayList<>();
        DispensedItemsDetailItem itemsDetailItem=DispensedItemsDetailItem.builder().controlSet(controlSet(didList,majorVersionNbr,minorVersionNbr)).build();
        dispensedItemsDetailItems.add(itemsDetailItem);
        return dispensedItemsDetailItems;
    }
    public ControlSet controlSet(String didList, int majorVersionNbr, int minorVersionNbr){
        ControlSet controlSet=ControlSet.builder().did(didList).majorVersionNbr(majorVersionNbr).minorVersionNbr(minorVersionNbr).build();
        return controlSet;
    }
    public ServiceResponse shipping(String didListValue,String orderId,String orderSeqNbr,
                                    String fillId,String doGroupCode,String doGroupId,int packageId,int bagNbr,double patientChargedAmt,String rxContentType,String priority,String labelFormat,String address,String city,String phone,String state,
                                    String zip,String name,String country,int packageWeight,int packagingOptionCode){
        req.setUrl(prop.getProperty("mo.baseUrl.shipping"));
        String randomTrackId= RandomStringUtils.randomAlphanumeric(7);
        String gqlPayload="mutation PrepareShipment($prepareShipmentInput: PrepareShipmentInput!) {    " +
                "prepareShipment(prepareShipmentInput: $prepareShipmentInput) {        shipmentId        message        labelDetails {             " +
                "labelData             labelFormat               trackingCode        }         carrierDetails {            " +
                "carrierCode            carrierMethodCode            carrierMethodText             shipDate            estimatedDeliveryDate        }         " +
                "soVersion        lastUpdatedTime    }}";
        ShippingRequest shippingRequest=ShippingRequest.builder().query(gqlPayload).variables(variables(didListValue,orderId,fillId,orderSeqNbr,doGroupCode,
                doGroupId,packageId,bagNbr,patientChargedAmt,rxContentType,
                priority,labelFormat,address,city,phone,state,zip,name,country,packageWeight,packagingOptionCode)).build();
        req.setRequestPayload(shippingRequest);
        headers.put("WM_CONSUMER.ID", prop.getProperty("mo.consumer.id.shipping"));
        headers.put("WM_SVC.NAME",prop.getProperty("mo.service.name.new"));
        headers.put("WM_SVC.ENV",prop.getProperty("mo.service.env.new"));
        headers.put("x-hnw-rx-store-id", prop.getProperty("mo.rx.storeId"));
        headers.put("x-hnw-rx-client-workstation", prop.getProperty("mo.client.workstation.new"));
        headers.put("x-hnw-rx-client-name", prop.getProperty("mo.client.name"));
        headers.put("x-hnw-graphql-schema-version", prop.getProperty("mo.schema.version"));
        headers.put("x-hnw-rx-req-track-id", prop.getProperty("mo.req.trackId.sp")+ randomTrackId);
        headers.put("x-hnw-rx-user-id", prop.getProperty("mo.rx.userId.new"));
        headers.put("x-hnw-rx-client-ip-address", prop.getProperty("mo.ipaddress"));
        headers.put("WM_CONSUMER.INTIMESTAMP", prop.getProperty("mo.consumer.timestamp"));
        headers.put("WM_SEC.KEY_VERSION",prop.getProperty("mo.sec.keyVersion"));
        headers.put("WM_SEC.AUTH_SIGNATURE",prop.getProperty("shipping.auth.key"));
        headers.put("x-hnw-rx-req-id",prop.getProperty("mo.requestId"));
        headers.put("x-hnw-rx-client-hostname", prop.getProperty("mo.client.hostname"));
        headers.put("content-type","application/json");
        req.setHeaders(headers);
        Log.info("Shipping RequestPayload:\n" + req.getRequestPayload());
        resp=am.getRestContext().performPost(req);
        Reporter.logJSON("Shipping Response", resp.getDataResponse());
        Log.info("Shipping ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }
    public Variables1 variables(String didListValue,String orderId,String orderSeqNbr,
                                String fillId,String doGroupCode,String doGroupId,int packageId,int bagNbr,double patientChargedAmt,String rxContentType,String priority,String labelFormat,String address,String city,String phone,String state,
                                String zip,String name,String country,int packageWeight,int packagingOptionCode){
       Variables1 vari=Variables1.builder().prepareShipmentInput(prepareShipment(didListValue,orderId,fillId,orderSeqNbr,doGroupCode,
               doGroupId,packageId,bagNbr,patientChargedAmt,rxContentType,
               priority,labelFormat,address,city,phone,state,zip,name,country,packageWeight,packagingOptionCode)).build();
        return vari;
    }
    public PrepareShipmentInput prepareShipment(String didListValue,String orderId,String orderSeqNbr,
                                                String fillId,String doGroupCode,String doGroupId,int packageId,int bagNbr,double patientChargedAmt,String rxContentType,String priority,String labelFormat,String address,String city,String phone,String state,
                                                String zip,String name,String country,int packageWeight,int packagingOptionCode){
        PrepareShipmentInput prepareShipmentInput=PrepareShipmentInput.builder().rxDetails(rxDetails(didListValue,orderId,fillId,orderSeqNbr,rxContentType))
                .shippingDetails(shippingDetails(doGroupCode,doGroupId,packageId,bagNbr,patientChargedAmt,
                        priority,labelFormat,address,city,phone,state,zip,name,country,packageWeight,packagingOptionCode))
                .override(false).customerSignaturePreferenceInd(false).build();
        return prepareShipmentInput;
    }
    public List<RxDetailsItem> rxDetails(String didListValue,String orderId,String orderSeqNbr,String fillId,String rxContentType){
        List<RxDetailsItem> rxDetailsItems=new ArrayList<>();
        RxDetailsItem rxDetailsItem=RxDetailsItem.builder().rxContentType(rxContentType).orderId(orderId)
                    .roliId(fillId).did(didListValue).orderSeqNbr(orderSeqNbr).restrictionFlags(restrictionFlag()).build();
        rxDetailsItems.add(rxDetailsItem);
        return rxDetailsItems;
    }
    public RestrictionFlags restrictionFlag(){
        RestrictionFlags restrictionFlags=RestrictionFlags.builder().isLqm(false).isGel(false).isCold(false).isDrugsOfConcern(false).isControlledSubstance(false).build();
        return restrictionFlags;
    }
    public ShippingDetails shippingDetails(String doGroupCode,String doGroupId,int packageId,int bagNbr,double patientChargedAmt,String priority,String labelFormat,String address,String city,String phone,String state,
                                           String zip,String name,String country,int packageWeight,int packagingOptionCode){
        ShippingDetails shippingDetails=ShippingDetails.builder().shippingPriority(priority)
                .customerAddress(customerAddress(address,city,phone,state,zip,name,country)).doGroupCode(doGroupCode).doGroupId(doGroupId).labelFormat(labelFormat)
                .packageId(packageId).bagNumber(bagNbr).patientChargedAmount(patientChargedAmt).packageMeasurements(packageMeasurements(packageWeight,packagingOptionCode)).build();
        return shippingDetails;
    }
    public PackageMeasurements packageMeasurements(int packageWeight,int packagingOptionCode){
        PackageMeasurements packageMeasurements=PackageMeasurements.builder().packageWeight(packageWeight).packagingOptionCode(packagingOptionCode).build();
        return packageMeasurements;
    }
    public CustomerAddress customerAddress(String address,String city,String phone,String state,
                                           String zip,String name,String country){
        CustomerAddress customerAddress=CustomerAddress.builder().address1(address).city(city)
                .phone(phone).state(state).zip(zip).name(name).countryCode(country).isResidential(false).build();
        return customerAddress;
    }
    public ServiceResponse checkoutCart(long upcNbr,int fillId,int thirdPartyAmt,double patientDueAmt,int rxNbr,String itemType,
                                        String custPayType,String paymentMethod,String token,String expiryYear,
                                        String expiryMonth,String issuerName,String cardHolderName,String storeType){
        CheckoutCartRequest checkoutCartRequest=CheckoutCartRequest.builder().storeType(storeType)
                .items(items(upcNbr,fillId,thirdPartyAmt,patientDueAmt,rxNbr,itemType,custPayType))
                .paymentDetail(paymentDetail(paymentMethod,token,expiryYear,expiryMonth,issuerName,cardHolderName)).build();
        req.setUrl(prop.getProperty("mo.PPI"));
        req.setRequestPayload(checkoutCartRequest);
        headers.put("WM_CONSUMER.ID", prop.getProperty("mo.consumer.id.PPI"));
        headers.put("WM_SVC.NAME",prop.getProperty("mo.service.name.PPI"));
        headers.put("WM_SVC.ENV",prop.getProperty("mo.service.env.new"));
        headers.put("x-hnw-rx-store-id", prop.getProperty("mo.rx.storeId"));
        headers.put("x-hnw-rx-client-workstation", prop.getProperty("mo.client.workstation.new"));
        headers.put("x-hnw-rx-client-name", prop.getProperty("mo.client.name"));
        headers.put("x-hnw-cpc-token", prop.getProperty("ppi.cpc.token"));
        headers.put("x-hnw-rx-req-track-id", prop.getProperty("mo.req.trackId.ppi"));
        headers.put("x-hnw-rx-user-id", prop.getProperty("mo.rx.userId.new"));
        headers.put("x-hnw-rx-client-ip-address", prop.getProperty("mo.ipaddress.PPI"));
        headers.put("x-hnw-user-id",prop.getProperty("ppi.user.id"));
        headers.put("x-hnw-rx-initiator",prop.getProperty("ppi.rx.initiator"));
        headers.put("x-hnw-rx-client-hostname", prop.getProperty("mo.client.hostname.PPI"));
        headers.put("content-type","application/json");
        req.setHeaders(headers);
        resp=am.getRestContext().performPost(req);
        Reporter.logJSON("Checkout Cart Response", resp.getDataResponse());
        Log.info("Checkout Cart ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }
    public List<ItemsItem> items(long upcNbr,int fillId,int thirdPartyAmt,double patientDueAmt,int rxNbr,String itemType,String custPaytype){
        List<ItemsItem> itemsItems=new ArrayList<>();
        List<Long> upc=new ArrayList<>();
        upc.add(upcNbr);
        ItemsItem items=ItemsItem.builder().itemId(fillId).itemType(itemType).itemUPCs(upc).customerPayType(custPaytype)
                .isTaxable(false).localThirdPartyAmount(thirdPartyAmt).patientDueAmount(patientDueAmt).rxNumber(rxNbr).thirdPartyAmount(thirdPartyAmt).build();
        itemsItems.add(items);
        return itemsItems;
    }
    public PaymentDetail paymentDetail(String paymentMethod,String token,String expiryYear,
                                       String expiryMonth,String issuerName,String cardHolderName) {
        PaymentDetail paymentDetail = PaymentDetail.builder().paymentMode(paymentMethod).token(token)
                .cardExpiryYear(expiryYear).cardExpiryMonth(expiryMonth).cardIssuerName(issuerName).cardHolderName(cardHolderName).build();
        return paymentDetail;
    }

}
