package hwqe.baseframework.mailOrderApi.dataModels.requests.shipping;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RestrictionFlags{
	private boolean isLqm;
	private boolean isControlledSubstance;
	private boolean isDrugsOfConcern;
	private boolean isGel;
	private boolean isCold;
}