package hwqe.baseframework.mailOrderApi.dataModels.requests.shipping;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ShippingDetails{
	private CustomerAddress customerAddress;
	private String doGroupCode;
	private PackageMeasurements packageMeasurements;
	private double patientChargedAmount;
	private int bagNumber;
	private String labelFormat;
	private String shippingPriority;
	private int packageId;
	private String doGroupId;
}