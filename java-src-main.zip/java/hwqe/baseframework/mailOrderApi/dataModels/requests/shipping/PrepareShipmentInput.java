package hwqe.baseframework.mailOrderApi.dataModels.requests.shipping;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PrepareShipmentInput{
	private List<RxDetailsItem> rxDetails;
	private ShippingDetails shippingDetails;
	private boolean customerSignaturePreferenceInd;
	private boolean override;
}