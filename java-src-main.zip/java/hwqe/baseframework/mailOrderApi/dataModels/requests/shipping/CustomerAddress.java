package hwqe.baseframework.mailOrderApi.dataModels.requests.shipping;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CustomerAddress{
	private String zip;
	private String phone;
	private String city;
	private String address1;
	private String countryCode;
	private boolean isResidential;
	private String name;
	private String state;
}