package hwqe.baseframework.mailOrderApi.dataModels.requests.shipping;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ShippingRequest{
	private String query;
	private Variables1 variables;
}