package hwqe.baseframework.mailOrderApi.dataModels.requests.shipping;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Variables1{
	private PrepareShipmentInput prepareShipmentInput;
}