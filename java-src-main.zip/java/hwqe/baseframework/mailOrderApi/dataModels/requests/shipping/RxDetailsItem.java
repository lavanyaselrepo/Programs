package hwqe.baseframework.mailOrderApi.dataModels.requests.shipping;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RxDetailsItem{
	private String orderSeqNbr;
	private String roliId;
	private RestrictionFlags restrictionFlags;
	private String orderId;
	private String rxContentType;
	private String did;
}