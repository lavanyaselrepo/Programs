package hwqe.baseframework.mailOrderApi.dataModels.requests.selectForDispenseRequest;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SelectfordispenseRequest{
	private String query;
	private Variables variables;
}