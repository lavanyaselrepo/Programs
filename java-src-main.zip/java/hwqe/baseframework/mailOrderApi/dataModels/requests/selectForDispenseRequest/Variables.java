package hwqe.baseframework.mailOrderApi.dataModels.requests.selectForDispenseRequest;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Variables {
	private SelectInput selectInput;
	private boolean override;
}