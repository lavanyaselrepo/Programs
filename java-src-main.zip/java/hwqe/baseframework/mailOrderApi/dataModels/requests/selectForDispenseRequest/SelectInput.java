package hwqe.baseframework.mailOrderApi.dataModels.requests.selectForDispenseRequest;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SelectInput{
	private List<String> didList;
	private int searchedPatientId;
}