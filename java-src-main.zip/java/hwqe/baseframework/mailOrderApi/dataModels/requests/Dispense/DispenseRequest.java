package hwqe.baseframework.mailOrderApi.dataModels.requests.Dispense;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DispenseRequest{
	private String query;
	private VariablesDispense variables;
}