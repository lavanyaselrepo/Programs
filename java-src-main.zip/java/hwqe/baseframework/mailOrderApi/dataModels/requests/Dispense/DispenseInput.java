package hwqe.baseframework.mailOrderApi.dataModels.requests.Dispense;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DispenseInput{
	private List<DispensedItemsDetailItem> dispensedItemsDetail;
}