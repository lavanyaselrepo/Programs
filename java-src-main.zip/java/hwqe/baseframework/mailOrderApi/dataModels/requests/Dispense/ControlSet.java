package hwqe.baseframework.mailOrderApi.dataModels.requests.Dispense;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ControlSet{
	private int majorVersionNbr;
	private int minorVersionNbr;
	private String did;
}