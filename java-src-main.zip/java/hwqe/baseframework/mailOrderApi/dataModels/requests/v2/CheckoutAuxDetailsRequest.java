package hwqe.baseframework.mailOrderApi.dataModels.requests.v2;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import hwqe.baseframework.mailOrderApi.PPIServiceConstants;

/** @author Srikanth(s0a0c5o) */
@JsonTypeInfo(
    use = JsonTypeInfo.Id.NAME,
    include = JsonTypeInfo.As.PROPERTY,
    property = "type" // Field in JSON to determine the concrete class
    )
@JsonSubTypes({
  @JsonSubTypes.Type(
      value = CheckoutPharmacyAuxDetailsRequest.class,
      name = PPIServiceConstants.PHARMACY_DETAILS_TYPE)
  // Add other implementations here if needed
})
public interface CheckoutAuxDetailsRequest {}
