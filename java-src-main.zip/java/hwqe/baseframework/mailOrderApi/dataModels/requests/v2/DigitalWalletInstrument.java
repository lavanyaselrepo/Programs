package hwqe.baseframework.mailOrderApi.dataModels.requests.v2;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** @author Srikanth(s0a0c5o) */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DigitalWalletInstrument implements PaymentInstrument {
  @Builder.Default private String method = hwqe.baseframework.mailOrderApi.PPIServiceConstants.DIGITAL_WALLET;
  @NotNull private String ownerCustomerId;
}
