package hwqe.baseframework.mailOrderApi.dataModels.requests.v2;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** @author Srikanth(s0a0c5o) */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardInstrument implements PaymentInstrument {
  @Builder.Default private String method = hwqe.baseframework.mailOrderApi.PPIServiceConstants.EZPAY;
  @NotNull private String issuer;
  @NotNull private String type;
  @NotNull private String cardType;
  private String cardHolderName;
  private String token;
  private String expirationMonth;
  private String expirationYear;
  @Valid private BillingAddress billingAddress;
}
