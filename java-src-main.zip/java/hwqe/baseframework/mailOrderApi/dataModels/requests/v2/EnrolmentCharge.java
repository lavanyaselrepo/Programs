package hwqe.baseframework.mailOrderApi.dataModels.requests.v2;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class EnrolmentCharge {
  private BigDecimal fee;
  private Boolean isTaxable;
}
