package hwqe.baseframework.mailOrderApi.dataModels.requests.v2;

import lombok.Data;

/** @author Srikanth(s0a0c5o) */
@Data
public class BillingAddress {
  private String addressLine1;
  private String addressLine2;
  private String city;
  private String state;
  private String country;
  private String postalCode;
}
