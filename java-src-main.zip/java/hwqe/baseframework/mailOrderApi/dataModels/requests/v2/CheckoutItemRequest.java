package hwqe.baseframework.mailOrderApi.dataModels.requests.v2;

import java.math.BigDecimal;
import java.util.List;
import lombok.Data;

@Data
public class CheckoutItemRequest {
  private Boolean isTaxable;
  private BigDecimal coPayAmount;

  private String thirdPartyCarrier;

  private BigDecimal thirdPartyAmount;

  private BigDecimal localThirdPartyAmount;

  private String customerPayType;

  private String externalId;

  private String cloudItemId;

  private String type;

  private CheckoutAuxDetailsRequest auxDetails;

  private List<Long> upcs;

  private EnrolmentCharge enrolmentCharge;

  private ProcessingCharge processingCharge;
}
