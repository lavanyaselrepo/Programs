package hwqe.baseframework.mailOrderApi.dataModels.requests.v2;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
import lombok.Data;

/** @author Srikanth(s0a0c5o) */
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class ProcessingCharge {
  private BigDecimal fee;
  private Boolean isTaxable;
}
