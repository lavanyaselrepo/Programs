package hwqe.baseframework.mailOrderApi.dataModels.requests.v2;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** @author Srikanth(s0a0c5o) */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentDetailRequest {
  private String referenceId;
  private PaymentInstrument paymentInstrument;
  private BigDecimal chargeAmount;
}
