package hwqe.baseframework.mailOrderApi.dataModels.requests.v2;

import hwqe.baseframework.mailOrderApi.PPIServiceConstants;
import lombok.Data;

@Data
public class CheckoutPharmacyAuxDetailsRequest implements CheckoutAuxDetailsRequest {
  private Integer orderId;
  private Short orderSeqNbr;
  private Integer rxNumber;
  private Object PPIServiceConstants;
  private final String type = hwqe.baseframework.mailOrderApi.PPIServiceConstants.PHARMACY_DETAILS_TYPE;
  private String fillId;
  private Integer workQueCode;
}
