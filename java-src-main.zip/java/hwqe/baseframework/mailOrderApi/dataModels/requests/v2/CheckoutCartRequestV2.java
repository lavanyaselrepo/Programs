package hwqe.baseframework.mailOrderApi.dataModels.requests.v2;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CheckoutCartRequestV2 {
  private String storeType;
  private List<PaymentDetailRequest> paymentDetails;
  private List<CheckoutItemRequest> items;
}
