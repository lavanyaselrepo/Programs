package hwqe.baseframework.mailOrderApi.dataModels.requests.v2;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import hwqe.baseframework.mailOrderApi.PPIServiceConstants;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "method")
@JsonSubTypes({
        @JsonSubTypes.Type(value = CardInstrument.class, name = PPIServiceConstants.EZPAY),
        @JsonSubTypes.Type(
                value = DigitalWalletInstrument.class,
                name = PPIServiceConstants.DIGITAL_WALLET),
        @JsonSubTypes.Type(value = ZeroPayInstrument.class, name = PPIServiceConstants.ZERO_PAY),
        @JsonSubTypes.Type(value = RegisterInstrument.class, name = PPIServiceConstants.REGISTER)
  // Add other implementations as needed
})
public interface PaymentInstrument {}
