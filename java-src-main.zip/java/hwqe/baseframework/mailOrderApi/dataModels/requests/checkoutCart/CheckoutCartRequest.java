package hwqe.baseframework.mailOrderApi.dataModels.requests.checkoutCart;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CheckoutCartRequest{
	private String storeType;
	private PaymentDetail paymentDetail;
	private List<ItemsItem> items;
}