package hwqe.baseframework.mailOrderApi.dataModels.requests.checkoutCart;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PaymentDetail{
	private String cardIssuerName;
	private String paymentMode;
	private String cardHolderName;
	private String cardExpiryYear;
	private String cardExpiryMonth;
	private String token;
}