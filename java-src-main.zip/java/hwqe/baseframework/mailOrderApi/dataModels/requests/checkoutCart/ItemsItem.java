package hwqe.baseframework.mailOrderApi.dataModels.requests.checkoutCart;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ItemsItem{
	private int rxNumber;
	private int itemId;
	private List<Long> itemUPCs;
	private String itemType;
	private String customerPayType;
	private double patientDueAmount;
	private int thirdPartyAmount;
	private boolean isTaxable;
	private int localThirdPartyAmount;
}