package hwqe.baseframework.mailOrderApi.dataModels.requests.assignBag;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Variables{
	private int bagNumber;
}