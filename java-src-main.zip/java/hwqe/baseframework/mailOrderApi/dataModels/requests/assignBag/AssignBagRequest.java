package hwqe.baseframework.mailOrderApi.dataModels.requests.assignBag;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AssignBagRequest{
	private String query;
	private Variables variables;
}