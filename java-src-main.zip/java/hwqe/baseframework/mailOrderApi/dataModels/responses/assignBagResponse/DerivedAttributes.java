package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class DerivedAttributes{
	private boolean isControlledSubstance;
	private Object abnRejectReason;
	private Object isCMSFormPrintNeeded;
	private boolean isCSIDRequired;
	private boolean isDrugOfConcern;
	private Object isMedicareDrugRestriction;
	private Object isWAMedicaidAckNeeded;
	private boolean isLiquidOrGel;
	private Object abnRejectPrice;
	private Object isAbnRequired;
}