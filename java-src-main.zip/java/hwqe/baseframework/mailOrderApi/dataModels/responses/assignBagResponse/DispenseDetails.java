package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class DispenseDetails{
	private DerivedAttributes derivedAttributes;
	private StoreParms storeParms;
	private RxInfo rxInfo;
	private PickupCustomerInfo pickupCustomerInfo;
	private OrderInfo orderInfo;
	private PatientInfo patientInfo;
	private RxFillInfo rxFillInfo;
}