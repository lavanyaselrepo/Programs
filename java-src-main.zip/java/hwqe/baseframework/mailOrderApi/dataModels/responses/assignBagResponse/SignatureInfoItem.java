package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import java.util.List;
import lombok.Data;

@Data
public class SignatureInfoItem{
	private Signature signature;
	private List<Object> signatureType;
}