package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import java.util.List;
import lombok.Data;

@Data
public class RxInfo{
	private Object isMedicareValidatedRxActivity;
	private int rxNbr;
	private int lastRxFillId;
	private int initialPrescribedQty;
	private PresProdInfo presProdInfo;
	private List<CommentInfoItem> commentInfo;
	private int rxOriginCode;
	private int productMdsFamId;
	private boolean compInd;
	private String rxContentType;
	private int remainingQty;
	private Object compoundId;
	private int fillQty;
}