package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class DispensedItemInfoItem{
	private Object drugControlCode;
	private long upcNumber;
	private int itemId;
	private int productId;
	private int multiSrcCode;
	private String drugEquivCode;
	private String shortName;
	private String ndc;
	private String productName;
}