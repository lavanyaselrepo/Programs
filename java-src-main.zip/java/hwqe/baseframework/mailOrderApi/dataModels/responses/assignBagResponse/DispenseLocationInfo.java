package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class DispenseLocationInfo{
	private Object locationRef;
	private int dispenseType;
	private Object timestamp;
	private Object clientReferenceCode;
}