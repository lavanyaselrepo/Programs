package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class assignData {
	private SearchByBagNumber searchByBagNumber;
}