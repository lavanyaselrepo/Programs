package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class PresProdInfo{
	private boolean isSuboxone;
	private int drugControlCode;
	private int prodMultiSrcCode;
	private int productQuantity;
	private String gpiCode;
	private String prodShortName;
	private String presProdStrength;
	private String presProdName;
}