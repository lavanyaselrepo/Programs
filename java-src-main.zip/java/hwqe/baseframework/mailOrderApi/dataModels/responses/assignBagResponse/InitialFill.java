package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class InitialFill{
	private Object fillExpDate;
	private Object fillDays;
	private boolean chargeInd;
	private boolean mailOutInd;
	private Object posTs;
	private Object rxfillId;
	private Object fillQty;
}