package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class CounselInfo{
	private Object counselNotes;
	private Object counselOptInReasonCode;
	private String counselReasonText;
	private boolean isCounselNeeded;
	private Object counselOptOutReasonText;
	private boolean counselOptOutAvailable;
	private boolean isCounselQueNeeded;
	private Object counselOptOutReasonCode;
	private Object counselOptInReasonText;
	private boolean counselDosageVarianceExceeded;
}