package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import java.util.List;
import lombok.Data;

@Data
public class SearchByBagNumber{
	private List<String> didList;
	private String message;
	private SearchResults searchResults;
}