package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class Signature{
	private Object createUserId;
	private Object expirationTs;
	private Object centralFileId;
	private Object relationshipCode;
	private Object captureTs;
}