package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class OrderDetailActivityItem{
	private int companyCode;
	private int sourceTypeCode;
	private String activityUserId;
	private int activitySeqNbr;
	private int orderId;
	private String workstationName;
	private String workQueCodeDesc;
	private String activityCodeDesc;
	private int workQueCode;
	private int orderSeqNbr;
	private int activityCode;
	private Object activityLocation;
	private Object txnNbr;
	private String activityTs;
	private Object userStoreNbr;
	private int rxOriginStoreNbr;
}