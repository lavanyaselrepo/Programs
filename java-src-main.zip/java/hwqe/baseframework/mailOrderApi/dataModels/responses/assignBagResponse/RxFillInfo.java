package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import java.util.List;
import lombok.Data;

@Data
public class RxFillInfo{
	private double posDueAmt;
	private int priceClassCode;
	private double expectedSaleAmt;
	private boolean earlyFillIndicator;
	private String fillItemExpDate;
	private Object partialFillQty;
	private Object initFillOrderSeqNbr;
	private String fillDate;
	private int rxFillSeqNbr;
	private int fillItemQty;
	private int fillTypeCode;
	private double thirdPartyAmount;
	private int fillDaysSupplyQty;
	private List<Object> thirdPartyInfo;
	private boolean chargeInd;
	private double taxAmt;
	private List<Object> medicaidRestrictionCodes;
	private boolean partialFillInd;
	private boolean thirdPartyInd;
	private boolean isTaxable;
	private int compPriceAmt;
	private Object primaryPhmCompanyNameAbbr;
	private List<DispensedItemInfoItem> dispensedItemInfo;
	private Object itemMdsFamId;
	private Object posTs;
	private Object sumOfRemainingFillQty;
	private CounselInfo counselInfo;
	private PartialFillInfo partialFillInfo;
	private boolean emergencyFillInd;
	private double patientDueAmt;
	private int localThirdPartyAmount;
	private double usualPriceAmt;
	private String fillTypeDesc;
	private Object centralFillFacilityId;
	private int fillQty;
}