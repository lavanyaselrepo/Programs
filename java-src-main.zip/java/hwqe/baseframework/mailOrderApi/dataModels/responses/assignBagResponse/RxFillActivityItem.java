package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class RxFillActivityItem{
	private int activityCode;
	private String activityUserId;
	private int activitySeqNbr;
	private Object activityStoreNbr;
	private String activityTs;
	private int rxFillId;
}