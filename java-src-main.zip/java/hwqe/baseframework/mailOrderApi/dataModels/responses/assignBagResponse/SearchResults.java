package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import java.util.List;
import lombok.Data;

@Data
public class SearchResults{
	private List<SearchedItemsDetailItem> searchedItemsDetail;
}