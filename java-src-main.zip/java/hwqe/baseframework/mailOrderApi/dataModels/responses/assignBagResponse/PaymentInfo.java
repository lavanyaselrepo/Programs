package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class PaymentInfo{
	private Object piHash;
}