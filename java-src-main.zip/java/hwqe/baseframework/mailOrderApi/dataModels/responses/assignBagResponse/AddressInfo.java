package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class AddressInfo{
	private String zip;
	private Object country;
	private Object city;
	private Object addressLine1;
	private Object addressLine2;
	private Object state;
	private Object zipCode;
}