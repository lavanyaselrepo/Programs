package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class CommentInfo{
	private Object createUserId;
	private Object commentTxt;
	private Object commentTypeCode;
	private Object subjectTypeCode;
	private Object commentId;
	private Object createTs;
	private boolean alertInd;
}