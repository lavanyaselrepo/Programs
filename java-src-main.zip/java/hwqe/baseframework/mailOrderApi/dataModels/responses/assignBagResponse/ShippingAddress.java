package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class ShippingAddress{
	private String stateProvCode;
	private String phoneNbr;
	private String cityName;
	private String countryCode;
	private String postalCode;
	private String name;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String countryName;
	private String addressLine4;
}