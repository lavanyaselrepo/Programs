package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class SignatureInfo{
	private boolean patientMedicareSigPresent;
	private Object patientLastHipaaSignatureRelationshipCode;
	private Object patientLastHipaaSignatureCaptureTs;
	private Object hipaaSignatureRefusalTs;
}