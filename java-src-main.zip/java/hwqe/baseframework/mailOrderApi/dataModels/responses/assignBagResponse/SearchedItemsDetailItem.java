package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import java.util.List;
import lombok.Data;

@Data
public class SearchedItemsDetailItem{
	private ActivityObject activityObject;
	private List<SignatureInfoItem> signatureInfo;
	private ShippingDetails shippingDetails;
	private DispenseDetails dispenseDetails;
	private ControlSet controlSet;
}