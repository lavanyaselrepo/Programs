package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import java.util.List;
import lombok.Data;

@Data
public class ActivityObject{
	private List<OrderDetailActivityItem> orderDetailActivity;
	private List<RxFillActivityItem> rxFillActivity;
}