package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class PartialFillInfo{
	private InitialFill initialFill;
	private FinalFill finalFill;
}