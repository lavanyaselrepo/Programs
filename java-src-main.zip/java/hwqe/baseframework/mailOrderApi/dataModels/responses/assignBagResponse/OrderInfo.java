package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import java.util.List;
import lombok.Data;

@Data
public class OrderInfo{
	private String estPickupTs;
	private CommentInfo commentInfo;
	private int nbrOfActiveFills;
	private int activeFillSeq;
	private List<Integer> eligibleDispenseTypeList;
	private DispenseLocationInfo dispenseLocationInfo;
	private Object omsOrderId;
	private int toteNbr;
	private String bagColor;
	private Object petRxInd;
	private boolean needPickupInd;
	private int requestTypeCode;
}