package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import java.util.List;
import lombok.Data;

@Data
public class PatientInfo{
	private int hipaaRefusalCount;
	private Object patientName;
	private String lastName;
	private AddressInfo addressInfo;
	private int patientId;
	private String type;
	private String firstName;
	private String genderCode;
	private String patientLastCompletedFillDate;
	private SignatureInfo signatureInfo;
	private List<Object> patientCounselNotes;
	private Object onlineCustomerId;
	private String phone;
	private String dob;
	private int hipaaStatusCode;
	private String comment;
	private String middleName;
	private PaymentInfo paymentInfo;
}