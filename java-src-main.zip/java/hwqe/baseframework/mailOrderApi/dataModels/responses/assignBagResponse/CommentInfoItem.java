package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class CommentInfoItem{
	private String createUserId;
	private String commentTxt;
	private int commentTypeCode;
	private int subjectTypeCode;
	private int commentId;
	private String createTs;
	private boolean alertInd;
}