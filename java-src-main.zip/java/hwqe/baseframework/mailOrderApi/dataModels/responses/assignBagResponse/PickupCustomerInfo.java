package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class PickupCustomerInfo{
	private Object firstName;
	private Object lastName;
	private AddressInfo addressInfo;
	private Object idType;
	private Object relationshipType;
	private Object dob;
	private Object pharmacistId;
	private Object issueAgencyCode;
	private Object idNumber;
	private Object expirationDate;
}