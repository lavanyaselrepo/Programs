package hwqe.baseframework.mailOrderApi.dataModels.responses.assignBagResponse;

import lombok.Data;

@Data
public class ShippingDetails{
	private boolean invoicePrintInd;
	private Object paymentMethodCode;
	private Object saturdayDeliveryInd;
	private Object deliveryConfirmInd;
	private int shippingOrderNbr;
	private int shippingStatusCode;
	private boolean patientShipChargeInd;
	private String shippingType;
	private int shippingCostAmount;
	private String transactionCarrierId;
	private Object shipDate;
	private int phmPackageId;
	private Object estimatedDeliveryDate;
	private String shippingInstructionText;
	private Object patientShipFeeAmount;
	private boolean ormdHazMatInd;
	private int phmPaymentAccountId;
	private Object paymentResponseId;
	private Object checkAmount;
	private Object signatureRequiredInd;
	private boolean customerSignaturePreferenceInd;
	private ShippingAddress shippingAddress;
	private int deliveryMethodCode;
	private boolean coldStorageInd;
}