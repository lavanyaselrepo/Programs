package hwqe.baseframework.mailOrderApi.dataModels.responses.selectForDispense;

import lombok.Data;

@Data
public class dispenseData{
	private Selectfordispense selectfordispense;
}