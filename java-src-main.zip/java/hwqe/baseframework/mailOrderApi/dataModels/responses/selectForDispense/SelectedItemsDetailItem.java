package hwqe.baseframework.mailOrderApi.dataModels.responses.selectForDispense;

import java.util.List;
import lombok.Data;

@Data
public class SelectedItemsDetailItem{
	private ControlSet controlSet;
}