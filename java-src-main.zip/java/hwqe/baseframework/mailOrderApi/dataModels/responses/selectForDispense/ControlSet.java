package hwqe.baseframework.mailOrderApi.dataModels.responses.selectForDispense;

import lombok.Data;

@Data
public class ControlSet{
	private String lastModifiedDateTime;
	private int orderId;
	private String userWorkLocation;
	private String dispenseState;
	private int doType;
	private int orderSeqNbr;
	private String initiatedDateTime;
	private int rxPrescriberId;
	private int requestSeqNbr;
	private String rxOriginState;
	private int currentAction;
	private int companyCode;
	private int priority;
	private int initiatedStore;
	private int majorVersionNbr;
	private Object userHomeStoreId;
	private long doGroupCode;
	private int minorVersionNbr;
	private String userWorkstation;
	private int rxId;
	private int workQueueCode;
	private int rxFillId;
	private int doGroupId;
	private String did;
	private String assignedUserId;
	private String estimatePickupTime;
}