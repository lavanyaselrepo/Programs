package hwqe.baseframework.mailOrderApi.dataModels.responses.selectForDispense;

import java.util.List;
import lombok.Data;

@Data
public class Selectfordispense{
	private List<SelectedItemsDetailItem> selectedItemsDetail;
	private List<String> didList;
	private String message;
}