package hwqe.baseframework.mailOrderApi.dataModels.responses.selectForDispense;

import lombok.Data;

@Data
public class DispenseResponse{
	private dispenseData data;
}