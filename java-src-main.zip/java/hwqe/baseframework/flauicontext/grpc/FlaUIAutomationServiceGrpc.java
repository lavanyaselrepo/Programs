package hwqe.baseframework.flauicontext.grpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.22.3)",
    comments = "Source: flaui_service.proto")
@SuppressWarnings({
        "java:S1128",
})
public final class FlaUIAutomationServiceGrpc {

  private FlaUIAutomationServiceGrpc() {}

  // Disambiguates asyncUnaryCall between ClientCalls and ServerCalls.
  private static <ReqT, RespT> io.grpc.ServerCallHandler<ReqT, RespT> asyncUnaryCall(
      io.grpc.stub.ServerCalls.UnaryMethod<ReqT, RespT> method) {
    return io.grpc.stub.ServerCalls.asyncUnaryCall(method);
  }

  private static <ReqT, RespT> void asyncUnaryCall(
      io.grpc.ClientCall<ReqT, RespT> call,
      ReqT request,
      io.grpc.stub.StreamObserver<RespT> responseObserver) {
    io.grpc.stub.ClientCalls.asyncUnaryCall(call, request, responseObserver);
  }

  public static final String SERVICE_NAME = "flaui.FlaUIAutomationService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionResponse> getCreateSessionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateSession",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionResponse> getCreateSessionMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionResponse> getCreateSessionMethod;
    if ((getCreateSessionMethod = FlaUIAutomationServiceGrpc.getCreateSessionMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getCreateSessionMethod = FlaUIAutomationServiceGrpc.getCreateSessionMethod) == null) {
          FlaUIAutomationServiceGrpc.getCreateSessionMethod = getCreateSessionMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "CreateSession"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("CreateSession"))
                  .build();
          }
        }
     }
     return getCreateSessionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionResponse> getCloseSessionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CloseSession",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionResponse> getCloseSessionMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionResponse> getCloseSessionMethod;
    if ((getCloseSessionMethod = FlaUIAutomationServiceGrpc.getCloseSessionMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getCloseSessionMethod = FlaUIAutomationServiceGrpc.getCloseSessionMethod) == null) {
          FlaUIAutomationServiceGrpc.getCloseSessionMethod = getCloseSessionMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "CloseSession"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("CloseSession"))
                  .build();
          }
        }
     }
     return getCloseSessionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppResponse> getLaunchApplicationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "LaunchApplication",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppResponse> getLaunchApplicationMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppResponse> getLaunchApplicationMethod;
    if ((getLaunchApplicationMethod = FlaUIAutomationServiceGrpc.getLaunchApplicationMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getLaunchApplicationMethod = FlaUIAutomationServiceGrpc.getLaunchApplicationMethod) == null) {
          FlaUIAutomationServiceGrpc.getLaunchApplicationMethod = getLaunchApplicationMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "LaunchApplication"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("LaunchApplication"))
                  .build();
          }
        }
     }
     return getLaunchApplicationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowResponse> getAttachToWindowMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AttachToWindow",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowResponse> getAttachToWindowMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowResponse> getAttachToWindowMethod;
    if ((getAttachToWindowMethod = FlaUIAutomationServiceGrpc.getAttachToWindowMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getAttachToWindowMethod = FlaUIAutomationServiceGrpc.getAttachToWindowMethod) == null) {
          FlaUIAutomationServiceGrpc.getAttachToWindowMethod = getAttachToWindowMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "AttachToWindow"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("AttachToWindow"))
                  .build();
          }
        }
     }
     return getAttachToWindowMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppResponse> getCloseApplicationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CloseApplication",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppResponse> getCloseApplicationMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppResponse> getCloseApplicationMethod;
    if ((getCloseApplicationMethod = FlaUIAutomationServiceGrpc.getCloseApplicationMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getCloseApplicationMethod = FlaUIAutomationServiceGrpc.getCloseApplicationMethod) == null) {
          FlaUIAutomationServiceGrpc.getCloseApplicationMethod = getCloseApplicationMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "CloseApplication"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("CloseApplication"))
                  .build();
          }
        }
     }
     return getCloseApplicationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementResponse> getFindElementMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "FindElement",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementResponse> getFindElementMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementResponse> getFindElementMethod;
    if ((getFindElementMethod = FlaUIAutomationServiceGrpc.getFindElementMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getFindElementMethod = FlaUIAutomationServiceGrpc.getFindElementMethod) == null) {
          FlaUIAutomationServiceGrpc.getFindElementMethod = getFindElementMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "FindElement"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("FindElement"))
                  .build();
          }
        }
     }
     return getFindElementMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementsResponse> getFindElementsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "FindElements",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementsResponse> getFindElementsMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementsResponse> getFindElementsMethod;
    if ((getFindElementsMethod = FlaUIAutomationServiceGrpc.getFindElementsMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getFindElementsMethod = FlaUIAutomationServiceGrpc.getFindElementsMethod) == null) {
          FlaUIAutomationServiceGrpc.getFindElementsMethod = getFindElementsMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "FindElements"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementsResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("FindElements"))
                  .build();
          }
        }
     }
     return getFindElementsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getClickMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Click",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getClickMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getClickMethod;
    if ((getClickMethod = FlaUIAutomationServiceGrpc.getClickMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getClickMethod = FlaUIAutomationServiceGrpc.getClickMethod) == null) {
          FlaUIAutomationServiceGrpc.getClickMethod = getClickMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "Click"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("Click"))
                  .build();
          }
        }
     }
     return getClickMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SendKeysRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getSendKeysMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SendKeys",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.SendKeysRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SendKeysRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getSendKeysMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SendKeysRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getSendKeysMethod;
    if ((getSendKeysMethod = FlaUIAutomationServiceGrpc.getSendKeysMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getSendKeysMethod = FlaUIAutomationServiceGrpc.getSendKeysMethod) == null) {
          FlaUIAutomationServiceGrpc.getSendKeysMethod = getSendKeysMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SendKeysRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "SendKeys"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.SendKeysRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("SendKeys"))
                  .build();
          }
        }
     }
     return getSendKeysMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getClearMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Clear",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getClearMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getClearMethod;
    if ((getClearMethod = FlaUIAutomationServiceGrpc.getClearMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getClearMethod = FlaUIAutomationServiceGrpc.getClearMethod) == null) {
          FlaUIAutomationServiceGrpc.getClearMethod = getClearMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "Clear"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("Clear"))
                  .build();
          }
        }
     }
     return getClearMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetTextResponse> getGetTextMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetText",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetTextResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetTextResponse> getGetTextMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetTextResponse> getGetTextMethod;
    if ((getGetTextMethod = FlaUIAutomationServiceGrpc.getGetTextMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getGetTextMethod = FlaUIAutomationServiceGrpc.getGetTextMethod) == null) {
          FlaUIAutomationServiceGrpc.getGetTextMethod = getGetTextMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetTextResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "GetText"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetTextResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("GetText"))
                  .build();
          }
        }
     }
     return getGetTextMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeResponse> getGetAttributeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetAttribute",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeResponse> getGetAttributeMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeResponse> getGetAttributeMethod;
    if ((getGetAttributeMethod = FlaUIAutomationServiceGrpc.getGetAttributeMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getGetAttributeMethod = FlaUIAutomationServiceGrpc.getGetAttributeMethod) == null) {
          FlaUIAutomationServiceGrpc.getGetAttributeMethod = getGetAttributeMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "GetAttribute"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("GetAttribute"))
                  .build();
          }
        }
     }
     return getGetAttributeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> getIsDisplayedMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "IsDisplayed",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> getIsDisplayedMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> getIsDisplayedMethod;
    if ((getIsDisplayedMethod = FlaUIAutomationServiceGrpc.getIsDisplayedMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getIsDisplayedMethod = FlaUIAutomationServiceGrpc.getIsDisplayedMethod) == null) {
          FlaUIAutomationServiceGrpc.getIsDisplayedMethod = getIsDisplayedMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "IsDisplayed"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("IsDisplayed"))
                  .build();
          }
        }
     }
     return getIsDisplayedMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> getIsEnabledMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "IsEnabled",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> getIsEnabledMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> getIsEnabledMethod;
    if ((getIsEnabledMethod = FlaUIAutomationServiceGrpc.getIsEnabledMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getIsEnabledMethod = FlaUIAutomationServiceGrpc.getIsEnabledMethod) == null) {
          FlaUIAutomationServiceGrpc.getIsEnabledMethod = getIsEnabledMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "IsEnabled"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("IsEnabled"))
                  .build();
          }
        }
     }
     return getIsEnabledMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> getIsSelectedMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "IsSelected",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> getIsSelectedMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> getIsSelectedMethod;
    if ((getIsSelectedMethod = FlaUIAutomationServiceGrpc.getIsSelectedMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getIsSelectedMethod = FlaUIAutomationServiceGrpc.getIsSelectedMethod) == null) {
          FlaUIAutomationServiceGrpc.getIsSelectedMethod = getIsSelectedMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "IsSelected"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("IsSelected"))
                  .build();
          }
        }
     }
     return getIsSelectedMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandleResponse> getGetWindowHandleMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetWindowHandle",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandleResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandleResponse> getGetWindowHandleMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandleResponse> getGetWindowHandleMethod;
    if ((getGetWindowHandleMethod = FlaUIAutomationServiceGrpc.getGetWindowHandleMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getGetWindowHandleMethod = FlaUIAutomationServiceGrpc.getGetWindowHandleMethod) == null) {
          FlaUIAutomationServiceGrpc.getGetWindowHandleMethod = getGetWindowHandleMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandleResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "GetWindowHandle"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandleResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("GetWindowHandle"))
                  .build();
          }
        }
     }
     return getGetWindowHandleMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandlesResponse> getGetWindowHandlesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetWindowHandles",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandlesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandlesResponse> getGetWindowHandlesMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandlesResponse> getGetWindowHandlesMethod;
    if ((getGetWindowHandlesMethod = FlaUIAutomationServiceGrpc.getGetWindowHandlesMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getGetWindowHandlesMethod = FlaUIAutomationServiceGrpc.getGetWindowHandlesMethod) == null) {
          FlaUIAutomationServiceGrpc.getGetWindowHandlesMethod = getGetWindowHandlesMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandlesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "GetWindowHandles"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandlesResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("GetWindowHandles"))
                  .build();
          }
        }
     }
     return getGetWindowHandlesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SwitchWindowRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getSwitchToWindowMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SwitchToWindow",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.SwitchWindowRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SwitchWindowRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getSwitchToWindowMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SwitchWindowRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getSwitchToWindowMethod;
    if ((getSwitchToWindowMethod = FlaUIAutomationServiceGrpc.getSwitchToWindowMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getSwitchToWindowMethod = FlaUIAutomationServiceGrpc.getSwitchToWindowMethod) == null) {
          FlaUIAutomationServiceGrpc.getSwitchToWindowMethod = getSwitchToWindowMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SwitchWindowRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "SwitchToWindow"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.SwitchWindowRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("SwitchToWindow"))
                  .build();
          }
        }
     }
     return getSwitchToWindowMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ScreenshotResponse> getTakeScreenshotMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "TakeScreenshot",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ScreenshotResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ScreenshotResponse> getTakeScreenshotMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ScreenshotResponse> getTakeScreenshotMethod;
    if ((getTakeScreenshotMethod = FlaUIAutomationServiceGrpc.getTakeScreenshotMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getTakeScreenshotMethod = FlaUIAutomationServiceGrpc.getTakeScreenshotMethod) == null) {
          FlaUIAutomationServiceGrpc.getTakeScreenshotMethod = getTakeScreenshotMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ScreenshotResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "TakeScreenshot"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ScreenshotResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("TakeScreenshot"))
                  .build();
          }
        }
     }
     return getTakeScreenshotMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getMouseHoverMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "MouseHover",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getMouseHoverMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getMouseHoverMethod;
    if ((getMouseHoverMethod = FlaUIAutomationServiceGrpc.getMouseHoverMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getMouseHoverMethod = FlaUIAutomationServiceGrpc.getMouseHoverMethod) == null) {
          FlaUIAutomationServiceGrpc.getMouseHoverMethod = getMouseHoverMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "MouseHover"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("MouseHover"))
                  .build();
          }
        }
     }
     return getMouseHoverMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getDoubleClickMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DoubleClick",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getDoubleClickMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getDoubleClickMethod;
    if ((getDoubleClickMethod = FlaUIAutomationServiceGrpc.getDoubleClickMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getDoubleClickMethod = FlaUIAutomationServiceGrpc.getDoubleClickMethod) == null) {
          FlaUIAutomationServiceGrpc.getDoubleClickMethod = getDoubleClickMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "DoubleClick"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("DoubleClick"))
                  .build();
          }
        }
     }
     return getDoubleClickMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getRightClickMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RightClick",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getRightClickMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getRightClickMethod;
    if ((getRightClickMethod = FlaUIAutomationServiceGrpc.getRightClickMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getRightClickMethod = FlaUIAutomationServiceGrpc.getRightClickMethod) == null) {
          FlaUIAutomationServiceGrpc.getRightClickMethod = getRightClickMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "RightClick"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("RightClick"))
                  .build();
          }
        }
     }
     return getRightClickMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.PressKeysRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getPressKeysMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "PressKeys",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.PressKeysRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.PressKeysRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getPressKeysMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.PressKeysRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getPressKeysMethod;
    if ((getPressKeysMethod = FlaUIAutomationServiceGrpc.getPressKeysMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getPressKeysMethod = FlaUIAutomationServiceGrpc.getPressKeysMethod) == null) {
          FlaUIAutomationServiceGrpc.getPressKeysMethod = getPressKeysMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.PressKeysRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "PressKeys"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.PressKeysRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("PressKeys"))
                  .build();
          }
        }
     }
     return getPressKeysMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectItemRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getSelectComboBoxItemMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SelectComboBoxItem",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectItemRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectItemRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getSelectComboBoxItemMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectItemRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getSelectComboBoxItemMethod;
    if ((getSelectComboBoxItemMethod = FlaUIAutomationServiceGrpc.getSelectComboBoxItemMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getSelectComboBoxItemMethod = FlaUIAutomationServiceGrpc.getSelectComboBoxItemMethod) == null) {
          FlaUIAutomationServiceGrpc.getSelectComboBoxItemMethod = getSelectComboBoxItemMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectItemRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "SelectComboBoxItem"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectItemRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("SelectComboBoxItem"))
                  .build();
          }
        }
     }
     return getSelectComboBoxItemMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectListItemRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getSelectListItemMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SelectListItem",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectListItemRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectListItemRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getSelectListItemMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectListItemRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getSelectListItemMethod;
    if ((getSelectListItemMethod = FlaUIAutomationServiceGrpc.getSelectListItemMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getSelectListItemMethod = FlaUIAutomationServiceGrpc.getSelectListItemMethod) == null) {
          FlaUIAutomationServiceGrpc.getSelectListItemMethod = getSelectListItemMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectListItemRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "SelectListItem"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectListItemRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("SelectListItem"))
                  .build();
          }
        }
     }
     return getSelectListItemMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.DismissPopupRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getDismissPopupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DismissPopup",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.DismissPopupRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.DismissPopupRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getDismissPopupMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.DismissPopupRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getDismissPopupMethod;
    if ((getDismissPopupMethod = FlaUIAutomationServiceGrpc.getDismissPopupMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getDismissPopupMethod = FlaUIAutomationServiceGrpc.getDismissPopupMethod) == null) {
          FlaUIAutomationServiceGrpc.getDismissPopupMethod = getDismissPopupMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.DismissPopupRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "DismissPopup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.DismissPopupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("DismissPopup"))
                  .build();
          }
        }
     }
     return getDismissPopupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupResponse> getHandlePopupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "HandlePopup",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupResponse> getHandlePopupMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupResponse> getHandlePopupMethod;
    if ((getHandlePopupMethod = FlaUIAutomationServiceGrpc.getHandlePopupMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getHandlePopupMethod = FlaUIAutomationServiceGrpc.getHandlePopupMethod) == null) {
          FlaUIAutomationServiceGrpc.getHandlePopupMethod = getHandlePopupMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "HandlePopup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("HandlePopup"))
                  .build();
          }
        }
     }
     return getHandlePopupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ClickAndDragRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getClickAndDragMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ClickAndDrag",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ClickAndDragRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ClickAndDragRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getClickAndDragMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ClickAndDragRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getClickAndDragMethod;
    if ((getClickAndDragMethod = FlaUIAutomationServiceGrpc.getClickAndDragMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getClickAndDragMethod = FlaUIAutomationServiceGrpc.getClickAndDragMethod) == null) {
          FlaUIAutomationServiceGrpc.getClickAndDragMethod = getClickAndDragMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ClickAndDragRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "ClickAndDrag"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ClickAndDragRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("ClickAndDrag"))
                  .build();
          }
        }
     }
     return getClickAndDragMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FocusWindowRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getFocusWindowMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "FocusWindow",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.FocusWindowRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FocusWindowRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getFocusWindowMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FocusWindowRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> getFocusWindowMethod;
    if ((getFocusWindowMethod = FlaUIAutomationServiceGrpc.getFocusWindowMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getFocusWindowMethod = FlaUIAutomationServiceGrpc.getFocusWindowMethod) == null) {
          FlaUIAutomationServiceGrpc.getFocusWindowMethod = getFocusWindowMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FocusWindowRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "FocusWindow"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.FocusWindowRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("FocusWindow"))
                  .build();
          }
        }
     }
     return getFocusWindowMethod;
  }

  private static volatile io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingResponse> getPingMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Ping",
      requestType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingRequest.class,
      responseType = hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingRequest,
      hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingResponse> getPingMethod() {
    io.grpc.MethodDescriptor<hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingResponse> getPingMethod;
    if ((getPingMethod = FlaUIAutomationServiceGrpc.getPingMethod) == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        if ((getPingMethod = FlaUIAutomationServiceGrpc.getPingMethod) == null) {
          FlaUIAutomationServiceGrpc.getPingMethod = getPingMethod = 
              io.grpc.MethodDescriptor.<hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingRequest, hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "flaui.FlaUIAutomationService", "Ping"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new FlaUIAutomationServiceMethodDescriptorSupplier("Ping"))
                  .build();
          }
        }
     }
     return getPingMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static FlaUIAutomationServiceStub newStub(io.grpc.Channel channel) {
    return new FlaUIAutomationServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static FlaUIAutomationServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new FlaUIAutomationServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static FlaUIAutomationServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new FlaUIAutomationServiceFutureStub(channel);
  }

  /**
   */
  public static abstract class FlaUIAutomationServiceImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     * --- Session Management ---
     * </pre>
     */
    public void createSession(hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getCreateSessionMethod(), responseObserver);
    }

    /**
     */
    public void closeSession(hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getCloseSessionMethod(), responseObserver);
    }

    /**
     * <pre>
     * --- Application Lifecycle ---
     * </pre>
     */
    public void launchApplication(hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getLaunchApplicationMethod(), responseObserver);
    }

    /**
     */
    public void attachToWindow(hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getAttachToWindowMethod(), responseObserver);
    }

    /**
     */
    public void closeApplication(hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getCloseApplicationMethod(), responseObserver);
    }

    /**
     * <pre>
     * --- Element Discovery ---
     * </pre>
     */
    public void findElement(hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getFindElementMethod(), responseObserver);
    }

    /**
     */
    public void findElements(hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementsResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getFindElementsMethod(), responseObserver);
    }

    /**
     * <pre>
     * --- Element Interactions ---
     * </pre>
     */
    public void click(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getClickMethod(), responseObserver);
    }

    /**
     */
    public void sendKeys(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SendKeysRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getSendKeysMethod(), responseObserver);
    }

    /**
     */
    public void clear(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getClearMethod(), responseObserver);
    }

    /**
     * <pre>
     * --- Element State ---
     * </pre>
     */
    public void getText(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetTextResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getGetTextMethod(), responseObserver);
    }

    /**
     */
    public void getAttribute(hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getGetAttributeMethod(), responseObserver);
    }

    /**
     */
    public void isDisplayed(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getIsDisplayedMethod(), responseObserver);
    }

    /**
     */
    public void isEnabled(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getIsEnabledMethod(), responseObserver);
    }

    /**
     */
    public void isSelected(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getIsSelectedMethod(), responseObserver);
    }

    /**
     * <pre>
     * --- Window Management ---
     * </pre>
     */
    public void getWindowHandle(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandleResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getGetWindowHandleMethod(), responseObserver);
    }

    /**
     */
    public void getWindowHandles(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandlesResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getGetWindowHandlesMethod(), responseObserver);
    }

    /**
     */
    public void switchToWindow(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SwitchWindowRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getSwitchToWindowMethod(), responseObserver);
    }

    /**
     * <pre>
     * --- Screenshot ---
     * </pre>
     */
    public void takeScreenshot(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ScreenshotResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getTakeScreenshotMethod(), responseObserver);
    }

    /**
     * <pre>
     * --- Actions (Mouse / Keyboard) ---
     * </pre>
     */
    public void mouseHover(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getMouseHoverMethod(), responseObserver);
    }

    /**
     */
    public void doubleClick(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getDoubleClickMethod(), responseObserver);
    }

    /**
     */
    public void rightClick(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getRightClickMethod(), responseObserver);
    }

    /**
     */
    public void pressKeys(hwqe.baseframework.flauicontext.grpc.FlaUIProto.PressKeysRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getPressKeysMethod(), responseObserver);
    }

    /**
     * <pre>
     * --- ComboBox / List ---
     * </pre>
     */
    public void selectComboBoxItem(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectItemRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getSelectComboBoxItemMethod(), responseObserver);
    }

    /**
     */
    public void selectListItem(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectListItemRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getSelectListItemMethod(), responseObserver);
    }

    /**
     * <pre>
     * --- Popup / Dialog Handling ---
     * </pre>
     */
    public void dismissPopup(hwqe.baseframework.flauicontext.grpc.FlaUIProto.DismissPopupRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getDismissPopupMethod(), responseObserver);
    }

    /**
     */
    public void handlePopup(hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getHandlePopupMethod(), responseObserver);
    }

    /**
     * <pre>
     * --- Drag &amp; Drop ---
     * </pre>
     */
    public void clickAndDrag(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ClickAndDragRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getClickAndDragMethod(), responseObserver);
    }

    /**
     * <pre>
     * --- Window Focus ---
     * </pre>
     */
    public void focusWindow(hwqe.baseframework.flauicontext.grpc.FlaUIProto.FocusWindowRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getFocusWindowMethod(), responseObserver);
    }

    /**
     * <pre>
     * --- Health Check ---
     * </pre>
     */
    public void ping(hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getPingMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getCreateSessionMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionResponse>(
                  this, METHODID_CREATE_SESSION)))
          .addMethod(
            getCloseSessionMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionResponse>(
                  this, METHODID_CLOSE_SESSION)))
          .addMethod(
            getLaunchApplicationMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppResponse>(
                  this, METHODID_LAUNCH_APPLICATION)))
          .addMethod(
            getAttachToWindowMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowResponse>(
                  this, METHODID_ATTACH_TO_WINDOW)))
          .addMethod(
            getCloseApplicationMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppResponse>(
                  this, METHODID_CLOSE_APPLICATION)))
          .addMethod(
            getFindElementMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementResponse>(
                  this, METHODID_FIND_ELEMENT)))
          .addMethod(
            getFindElementsMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementsResponse>(
                  this, METHODID_FIND_ELEMENTS)))
          .addMethod(
            getClickMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>(
                  this, METHODID_CLICK)))
          .addMethod(
            getSendKeysMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.SendKeysRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>(
                  this, METHODID_SEND_KEYS)))
          .addMethod(
            getClearMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>(
                  this, METHODID_CLEAR)))
          .addMethod(
            getGetTextMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetTextResponse>(
                  this, METHODID_GET_TEXT)))
          .addMethod(
            getGetAttributeMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeResponse>(
                  this, METHODID_GET_ATTRIBUTE)))
          .addMethod(
            getIsDisplayedMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse>(
                  this, METHODID_IS_DISPLAYED)))
          .addMethod(
            getIsEnabledMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse>(
                  this, METHODID_IS_ENABLED)))
          .addMethod(
            getIsSelectedMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse>(
                  this, METHODID_IS_SELECTED)))
          .addMethod(
            getGetWindowHandleMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandleResponse>(
                  this, METHODID_GET_WINDOW_HANDLE)))
          .addMethod(
            getGetWindowHandlesMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandlesResponse>(
                  this, METHODID_GET_WINDOW_HANDLES)))
          .addMethod(
            getSwitchToWindowMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.SwitchWindowRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>(
                  this, METHODID_SWITCH_TO_WINDOW)))
          .addMethod(
            getTakeScreenshotMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ScreenshotResponse>(
                  this, METHODID_TAKE_SCREENSHOT)))
          .addMethod(
            getMouseHoverMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>(
                  this, METHODID_MOUSE_HOVER)))
          .addMethod(
            getDoubleClickMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>(
                  this, METHODID_DOUBLE_CLICK)))
          .addMethod(
            getRightClickMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>(
                  this, METHODID_RIGHT_CLICK)))
          .addMethod(
            getPressKeysMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.PressKeysRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>(
                  this, METHODID_PRESS_KEYS)))
          .addMethod(
            getSelectComboBoxItemMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectItemRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>(
                  this, METHODID_SELECT_COMBO_BOX_ITEM)))
          .addMethod(
            getSelectListItemMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectListItemRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>(
                  this, METHODID_SELECT_LIST_ITEM)))
          .addMethod(
            getDismissPopupMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.DismissPopupRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>(
                  this, METHODID_DISMISS_POPUP)))
          .addMethod(
            getHandlePopupMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupResponse>(
                  this, METHODID_HANDLE_POPUP)))
          .addMethod(
            getClickAndDragMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ClickAndDragRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>(
                  this, METHODID_CLICK_AND_DRAG)))
          .addMethod(
            getFocusWindowMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.FocusWindowRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>(
                  this, METHODID_FOCUS_WINDOW)))
          .addMethod(
            getPingMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingRequest,
                hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingResponse>(
                  this, METHODID_PING)))
          .build();
    }
  }

  /**
   */
  public static final class FlaUIAutomationServiceStub extends io.grpc.stub.AbstractStub<FlaUIAutomationServiceStub> {
    private FlaUIAutomationServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private FlaUIAutomationServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected FlaUIAutomationServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new FlaUIAutomationServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * --- Session Management ---
     * </pre>
     */
    public void createSession(hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getCreateSessionMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void closeSession(hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getCloseSessionMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * --- Application Lifecycle ---
     * </pre>
     */
    public void launchApplication(hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getLaunchApplicationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void attachToWindow(hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getAttachToWindowMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void closeApplication(hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getCloseApplicationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * --- Element Discovery ---
     * </pre>
     */
    public void findElement(hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getFindElementMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void findElements(hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementsResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getFindElementsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * --- Element Interactions ---
     * </pre>
     */
    public void click(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getClickMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void sendKeys(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SendKeysRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getSendKeysMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void clear(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getClearMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * --- Element State ---
     * </pre>
     */
    public void getText(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetTextResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetTextMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getAttribute(hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetAttributeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void isDisplayed(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getIsDisplayedMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void isEnabled(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getIsEnabledMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void isSelected(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getIsSelectedMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * --- Window Management ---
     * </pre>
     */
    public void getWindowHandle(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandleResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetWindowHandleMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getWindowHandles(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandlesResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetWindowHandlesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void switchToWindow(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SwitchWindowRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getSwitchToWindowMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * --- Screenshot ---
     * </pre>
     */
    public void takeScreenshot(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ScreenshotResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getTakeScreenshotMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * --- Actions (Mouse / Keyboard) ---
     * </pre>
     */
    public void mouseHover(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getMouseHoverMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void doubleClick(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getDoubleClickMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void rightClick(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getRightClickMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void pressKeys(hwqe.baseframework.flauicontext.grpc.FlaUIProto.PressKeysRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getPressKeysMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * --- ComboBox / List ---
     * </pre>
     */
    public void selectComboBoxItem(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectItemRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getSelectComboBoxItemMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void selectListItem(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectListItemRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getSelectListItemMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * --- Popup / Dialog Handling ---
     * </pre>
     */
    public void dismissPopup(hwqe.baseframework.flauicontext.grpc.FlaUIProto.DismissPopupRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getDismissPopupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void handlePopup(hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getHandlePopupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * --- Drag &amp; Drop ---
     * </pre>
     */
    public void clickAndDrag(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ClickAndDragRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getClickAndDragMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * --- Window Focus ---
     * </pre>
     */
    public void focusWindow(hwqe.baseframework.flauicontext.grpc.FlaUIProto.FocusWindowRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getFocusWindowMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * --- Health Check ---
     * </pre>
     */
    public void ping(hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingRequest request,
        io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getPingMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class FlaUIAutomationServiceBlockingStub extends io.grpc.stub.AbstractStub<FlaUIAutomationServiceBlockingStub> {
    private FlaUIAutomationServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private FlaUIAutomationServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected FlaUIAutomationServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new FlaUIAutomationServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * --- Session Management ---
     * </pre>
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionResponse createSession(hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionRequest request) {
      return blockingUnaryCall(
          getChannel(), getCreateSessionMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionResponse closeSession(hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionRequest request) {
      return blockingUnaryCall(
          getChannel(), getCloseSessionMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * --- Application Lifecycle ---
     * </pre>
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppResponse launchApplication(hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppRequest request) {
      return blockingUnaryCall(
          getChannel(), getLaunchApplicationMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowResponse attachToWindow(hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowRequest request) {
      return blockingUnaryCall(
          getChannel(), getAttachToWindowMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppResponse closeApplication(hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppRequest request) {
      return blockingUnaryCall(
          getChannel(), getCloseApplicationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * --- Element Discovery ---
     * </pre>
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementResponse findElement(hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest request) {
      return blockingUnaryCall(
          getChannel(), getFindElementMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementsResponse findElements(hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest request) {
      return blockingUnaryCall(
          getChannel(), getFindElementsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * --- Element Interactions ---
     * </pre>
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse click(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return blockingUnaryCall(
          getChannel(), getClickMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse sendKeys(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SendKeysRequest request) {
      return blockingUnaryCall(
          getChannel(), getSendKeysMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse clear(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return blockingUnaryCall(
          getChannel(), getClearMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * --- Element State ---
     * </pre>
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetTextResponse getText(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetTextMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeResponse getAttribute(hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetAttributeMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse isDisplayed(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return blockingUnaryCall(
          getChannel(), getIsDisplayedMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse isEnabled(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return blockingUnaryCall(
          getChannel(), getIsEnabledMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse isSelected(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return blockingUnaryCall(
          getChannel(), getIsSelectedMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * --- Window Management ---
     * </pre>
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandleResponse getWindowHandle(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetWindowHandleMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandlesResponse getWindowHandles(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetWindowHandlesMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse switchToWindow(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SwitchWindowRequest request) {
      return blockingUnaryCall(
          getChannel(), getSwitchToWindowMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * --- Screenshot ---
     * </pre>
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ScreenshotResponse takeScreenshot(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest request) {
      return blockingUnaryCall(
          getChannel(), getTakeScreenshotMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * --- Actions (Mouse / Keyboard) ---
     * </pre>
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse mouseHover(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return blockingUnaryCall(
          getChannel(), getMouseHoverMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse doubleClick(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return blockingUnaryCall(
          getChannel(), getDoubleClickMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse rightClick(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return blockingUnaryCall(
          getChannel(), getRightClickMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse pressKeys(hwqe.baseframework.flauicontext.grpc.FlaUIProto.PressKeysRequest request) {
      return blockingUnaryCall(
          getChannel(), getPressKeysMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * --- ComboBox / List ---
     * </pre>
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse selectComboBoxItem(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectItemRequest request) {
      return blockingUnaryCall(
          getChannel(), getSelectComboBoxItemMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse selectListItem(hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectListItemRequest request) {
      return blockingUnaryCall(
          getChannel(), getSelectListItemMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * --- Popup / Dialog Handling ---
     * </pre>
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse dismissPopup(hwqe.baseframework.flauicontext.grpc.FlaUIProto.DismissPopupRequest request) {
      return blockingUnaryCall(
          getChannel(), getDismissPopupMethod(), getCallOptions(), request);
    }

    /**
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupResponse handlePopup(hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupRequest request) {
      return blockingUnaryCall(
          getChannel(), getHandlePopupMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * --- Drag &amp; Drop ---
     * </pre>
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse clickAndDrag(hwqe.baseframework.flauicontext.grpc.FlaUIProto.ClickAndDragRequest request) {
      return blockingUnaryCall(
          getChannel(), getClickAndDragMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * --- Window Focus ---
     * </pre>
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse focusWindow(hwqe.baseframework.flauicontext.grpc.FlaUIProto.FocusWindowRequest request) {
      return blockingUnaryCall(
          getChannel(), getFocusWindowMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * --- Health Check ---
     * </pre>
     */
    public hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingResponse ping(hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingRequest request) {
      return blockingUnaryCall(
          getChannel(), getPingMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class FlaUIAutomationServiceFutureStub extends io.grpc.stub.AbstractStub<FlaUIAutomationServiceFutureStub> {
    private FlaUIAutomationServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private FlaUIAutomationServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected FlaUIAutomationServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new FlaUIAutomationServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * --- Session Management ---
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionResponse> createSession(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getCreateSessionMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionResponse> closeSession(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getCloseSessionMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * --- Application Lifecycle ---
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppResponse> launchApplication(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getLaunchApplicationMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowResponse> attachToWindow(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getAttachToWindowMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppResponse> closeApplication(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getCloseApplicationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * --- Element Discovery ---
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementResponse> findElement(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getFindElementMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementsResponse> findElements(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getFindElementsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * --- Element Interactions ---
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> click(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getClickMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> sendKeys(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.SendKeysRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getSendKeysMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> clear(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getClearMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * --- Element State ---
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetTextResponse> getText(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetTextMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeResponse> getAttribute(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetAttributeMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> isDisplayed(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getIsDisplayedMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> isEnabled(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getIsEnabledMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse> isSelected(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getIsSelectedMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * --- Window Management ---
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandleResponse> getWindowHandle(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetWindowHandleMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandlesResponse> getWindowHandles(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetWindowHandlesMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> switchToWindow(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.SwitchWindowRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getSwitchToWindowMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * --- Screenshot ---
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ScreenshotResponse> takeScreenshot(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getTakeScreenshotMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * --- Actions (Mouse / Keyboard) ---
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> mouseHover(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getMouseHoverMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> doubleClick(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getDoubleClickMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> rightClick(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getRightClickMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> pressKeys(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.PressKeysRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getPressKeysMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * --- ComboBox / List ---
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> selectComboBoxItem(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectItemRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getSelectComboBoxItemMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> selectListItem(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectListItemRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getSelectListItemMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * --- Popup / Dialog Handling ---
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> dismissPopup(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.DismissPopupRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getDismissPopupMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupResponse> handlePopup(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getHandlePopupMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * --- Drag &amp; Drop ---
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> clickAndDrag(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.ClickAndDragRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getClickAndDragMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * --- Window Focus ---
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse> focusWindow(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.FocusWindowRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getFocusWindowMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * --- Health Check ---
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingResponse> ping(
        hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getPingMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CREATE_SESSION = 0;
  private static final int METHODID_CLOSE_SESSION = 1;
  private static final int METHODID_LAUNCH_APPLICATION = 2;
  private static final int METHODID_ATTACH_TO_WINDOW = 3;
  private static final int METHODID_CLOSE_APPLICATION = 4;
  private static final int METHODID_FIND_ELEMENT = 5;
  private static final int METHODID_FIND_ELEMENTS = 6;
  private static final int METHODID_CLICK = 7;
  private static final int METHODID_SEND_KEYS = 8;
  private static final int METHODID_CLEAR = 9;
  private static final int METHODID_GET_TEXT = 10;
  private static final int METHODID_GET_ATTRIBUTE = 11;
  private static final int METHODID_IS_DISPLAYED = 12;
  private static final int METHODID_IS_ENABLED = 13;
  private static final int METHODID_IS_SELECTED = 14;
  private static final int METHODID_GET_WINDOW_HANDLE = 15;
  private static final int METHODID_GET_WINDOW_HANDLES = 16;
  private static final int METHODID_SWITCH_TO_WINDOW = 17;
  private static final int METHODID_TAKE_SCREENSHOT = 18;
  private static final int METHODID_MOUSE_HOVER = 19;
  private static final int METHODID_DOUBLE_CLICK = 20;
  private static final int METHODID_RIGHT_CLICK = 21;
  private static final int METHODID_PRESS_KEYS = 22;
  private static final int METHODID_SELECT_COMBO_BOX_ITEM = 23;
  private static final int METHODID_SELECT_LIST_ITEM = 24;
  private static final int METHODID_DISMISS_POPUP = 25;
  private static final int METHODID_HANDLE_POPUP = 26;
  private static final int METHODID_CLICK_AND_DRAG = 27;
  private static final int METHODID_FOCUS_WINDOW = 28;
  private static final int METHODID_PING = 29;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final FlaUIAutomationServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(FlaUIAutomationServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_SESSION:
          serviceImpl.createSession((hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CreateSessionResponse>) responseObserver);
          break;
        case METHODID_CLOSE_SESSION:
          serviceImpl.closeSession((hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseSessionResponse>) responseObserver);
          break;
        case METHODID_LAUNCH_APPLICATION:
          serviceImpl.launchApplication((hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.LaunchAppResponse>) responseObserver);
          break;
        case METHODID_ATTACH_TO_WINDOW:
          serviceImpl.attachToWindow((hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.AttachToWindowResponse>) responseObserver);
          break;
        case METHODID_CLOSE_APPLICATION:
          serviceImpl.closeApplication((hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.CloseAppResponse>) responseObserver);
          break;
        case METHODID_FIND_ELEMENT:
          serviceImpl.findElement((hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementResponse>) responseObserver);
          break;
        case METHODID_FIND_ELEMENTS:
          serviceImpl.findElements((hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.FindElementsResponse>) responseObserver);
          break;
        case METHODID_CLICK:
          serviceImpl.click((hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>) responseObserver);
          break;
        case METHODID_SEND_KEYS:
          serviceImpl.sendKeys((hwqe.baseframework.flauicontext.grpc.FlaUIProto.SendKeysRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>) responseObserver);
          break;
        case METHODID_CLEAR:
          serviceImpl.clear((hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>) responseObserver);
          break;
        case METHODID_GET_TEXT:
          serviceImpl.getText((hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetTextResponse>) responseObserver);
          break;
        case METHODID_GET_ATTRIBUTE:
          serviceImpl.getAttribute((hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.GetAttributeResponse>) responseObserver);
          break;
        case METHODID_IS_DISPLAYED:
          serviceImpl.isDisplayed((hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse>) responseObserver);
          break;
        case METHODID_IS_ENABLED:
          serviceImpl.isEnabled((hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse>) responseObserver);
          break;
        case METHODID_IS_SELECTED:
          serviceImpl.isSelected((hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.BoolResponse>) responseObserver);
          break;
        case METHODID_GET_WINDOW_HANDLE:
          serviceImpl.getWindowHandle((hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandleResponse>) responseObserver);
          break;
        case METHODID_GET_WINDOW_HANDLES:
          serviceImpl.getWindowHandles((hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.WindowHandlesResponse>) responseObserver);
          break;
        case METHODID_SWITCH_TO_WINDOW:
          serviceImpl.switchToWindow((hwqe.baseframework.flauicontext.grpc.FlaUIProto.SwitchWindowRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>) responseObserver);
          break;
        case METHODID_TAKE_SCREENSHOT:
          serviceImpl.takeScreenshot((hwqe.baseframework.flauicontext.grpc.FlaUIProto.SessionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ScreenshotResponse>) responseObserver);
          break;
        case METHODID_MOUSE_HOVER:
          serviceImpl.mouseHover((hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>) responseObserver);
          break;
        case METHODID_DOUBLE_CLICK:
          serviceImpl.doubleClick((hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>) responseObserver);
          break;
        case METHODID_RIGHT_CLICK:
          serviceImpl.rightClick((hwqe.baseframework.flauicontext.grpc.FlaUIProto.ElementActionRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>) responseObserver);
          break;
        case METHODID_PRESS_KEYS:
          serviceImpl.pressKeys((hwqe.baseframework.flauicontext.grpc.FlaUIProto.PressKeysRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>) responseObserver);
          break;
        case METHODID_SELECT_COMBO_BOX_ITEM:
          serviceImpl.selectComboBoxItem((hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectItemRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>) responseObserver);
          break;
        case METHODID_SELECT_LIST_ITEM:
          serviceImpl.selectListItem((hwqe.baseframework.flauicontext.grpc.FlaUIProto.SelectListItemRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>) responseObserver);
          break;
        case METHODID_DISMISS_POPUP:
          serviceImpl.dismissPopup((hwqe.baseframework.flauicontext.grpc.FlaUIProto.DismissPopupRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>) responseObserver);
          break;
        case METHODID_HANDLE_POPUP:
          serviceImpl.handlePopup((hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.HandlePopupResponse>) responseObserver);
          break;
        case METHODID_CLICK_AND_DRAG:
          serviceImpl.clickAndDrag((hwqe.baseframework.flauicontext.grpc.FlaUIProto.ClickAndDragRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>) responseObserver);
          break;
        case METHODID_FOCUS_WINDOW:
          serviceImpl.focusWindow((hwqe.baseframework.flauicontext.grpc.FlaUIProto.FocusWindowRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.ActionResponse>) responseObserver);
          break;
        case METHODID_PING:
          serviceImpl.ping((hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingRequest) request,
              (io.grpc.stub.StreamObserver<hwqe.baseframework.flauicontext.grpc.FlaUIProto.PingResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class FlaUIAutomationServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    FlaUIAutomationServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return hwqe.baseframework.flauicontext.grpc.FlaUIProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("FlaUIAutomationService");
    }
  }

  private static final class FlaUIAutomationServiceFileDescriptorSupplier
      extends FlaUIAutomationServiceBaseDescriptorSupplier {
    FlaUIAutomationServiceFileDescriptorSupplier() {}
  }

  private static final class FlaUIAutomationServiceMethodDescriptorSupplier
      extends FlaUIAutomationServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    FlaUIAutomationServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (FlaUIAutomationServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new FlaUIAutomationServiceFileDescriptorSupplier())
              .addMethod(getCreateSessionMethod())
              .addMethod(getCloseSessionMethod())
              .addMethod(getLaunchApplicationMethod())
              .addMethod(getAttachToWindowMethod())
              .addMethod(getCloseApplicationMethod())
              .addMethod(getFindElementMethod())
              .addMethod(getFindElementsMethod())
              .addMethod(getClickMethod())
              .addMethod(getSendKeysMethod())
              .addMethod(getClearMethod())
              .addMethod(getGetTextMethod())
              .addMethod(getGetAttributeMethod())
              .addMethod(getIsDisplayedMethod())
              .addMethod(getIsEnabledMethod())
              .addMethod(getIsSelectedMethod())
              .addMethod(getGetWindowHandleMethod())
              .addMethod(getGetWindowHandlesMethod())
              .addMethod(getSwitchToWindowMethod())
              .addMethod(getTakeScreenshotMethod())
              .addMethod(getMouseHoverMethod())
              .addMethod(getDoubleClickMethod())
              .addMethod(getRightClickMethod())
              .addMethod(getPressKeysMethod())
              .addMethod(getSelectComboBoxItemMethod())
              .addMethod(getSelectListItemMethod())
              .addMethod(getDismissPopupMethod())
              .addMethod(getHandlePopupMethod())
              .addMethod(getClickAndDragMethod())
              .addMethod(getFocusWindowMethod())
              .addMethod(getPingMethod())
              .build();
        }
      }
    }
    return result;
  }
}
