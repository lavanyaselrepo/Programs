package hwqe.baseframework.flauicontext.grpc;

import hwqe.baseframework.utilities.PropertyReader;

/**
 * GrpcConfig — singleton that reads gRPC driver settings from config.properties.
 *
 * <pre>
 *   # config.properties
 *   app.driver.type=winappdriver   # default: existing WinAppDriver behaviour
 *   app.driver.type=grpc           # switch: use FlaUI gRPC server
 *
 *   grpc.server.host=127.0.0.1
 *   grpc.server.port=50051
 *   grpc.deadline.seconds=60
 *   grpc.retry.count=3
 * </pre>
 *
 * Follows Fix #8 from the GCRP migration POC.
 */
@SuppressWarnings({
        "java:S106",
        "java:S3077",
        "java:S6548",
})
public class GrpcConfig {

    private static final Object LOCK = new Object();
    private static volatile GrpcConfig instance;

    private static final String DRIVER_TYPE_GRPC  = "grpc";
    private static final String PROP_DRIVER_TYPE  = "app.driver.type";
    private static final String PROP_GRPC_HOST     = "grpc.server.host";
    private static final String PROP_GRPC_PORT     = "grpc.server.port";
    private static final String PROP_GRPC_DEADLINE = "grpc.deadline.seconds";
    private static final String PROP_GRPC_RETRIES  = "grpc.retry.count";

    private final PropertyReader prop = PropertyReader.getInstance();

    private GrpcConfig() {
        // singleton — use getInstance()
    }

    /** Thread-safe singleton accessor. */
    public static GrpcConfig getInstance() {
        GrpcConfig temp = instance;
        if (temp == null) {
            synchronized (LOCK) {
                temp = instance;
                if (temp == null) {
                    instance = temp = new GrpcConfig();
                }
            }
        }
        return temp;
    }

    // -----------------------------------------------------------------------
    // Driver-mode checks
    // -----------------------------------------------------------------------

    /**
     * Returns {@code true} when {@code app.driver.type=grpc}.
     *
     * <p>Resolution order (same as the main GrpcConfig):
     * <ol>
     *   <li>JVM system property: {@code -Dapp.driver.type=grpc}</li>
     *   <li>config.properties via PropertyReader</li>
     * </ol>
     */
    public boolean isGrpcEnabled() {
        String driverType = resolve(PROP_DRIVER_TYPE);
        return DRIVER_TYPE_GRPC.equalsIgnoreCase(driverType);
    }

    /** Returns {@code true} when NOT in gRPC mode (WinAppDriver default). */
    public boolean isWinAppDriverEnabled() {
        return !isGrpcEnabled();
    }

    // -----------------------------------------------------------------------
    // gRPC connection details
    // -----------------------------------------------------------------------

    public String getHost() {
        String host = resolve(PROP_GRPC_HOST);
        return (host != null && !host.isBlank()) ? host : "127.0.0.1";
    }

    public int getPort() {
        String portStr = resolve(PROP_GRPC_PORT);
        try {
            return (portStr != null) ? Integer.parseInt(portStr.trim()) : 50051;
        } catch (NumberFormatException e) {
            return 50051;
        }
    }

    /** Combined "host:port" convenience accessor for channel creation. */
    public String getTarget() {
        return getHost() + ":" + getPort();
    }

    public int getDeadlineSeconds() {
        String val = resolve(PROP_GRPC_DEADLINE);
        try {
            return (val != null) ? Integer.parseInt(val.trim()) : 60;
        } catch (NumberFormatException e) {
            return 60;
        }
    }

    public int getRetryCount() {
        String val = resolve(PROP_GRPC_RETRIES);
        try {
            return (val != null) ? Integer.parseInt(val.trim()) : 3;
        } catch (NumberFormatException e) {
            return 3;
        }
    }

    // -----------------------------------------------------------------------
    // Internal helper
    // -----------------------------------------------------------------------

    /**
     * Resolve a property using JVM system property first, then config.properties.
     * Passing {@code -Dapp.driver.type=grpc} on the Maven command line MUST work
     * without having to edit any properties file.
     */
    private String resolve(String key) {
        // Priority 1: JVM system property (-Dkey=value on mvn command line)
        String sysProp = System.getProperty(key);
        if (sysProp != null && !sysProp.trim().isEmpty()) {
            return sysProp.trim();
        }
        // Priority 2: config.properties / PropertyReader
        try {
            return prop.getProperty(key);
        } catch (Exception e) {
            return null;
        }
    }

    // -----------------------------------------------------------------------
    // Logging helper
    // -----------------------------------------------------------------------

    /** Prints active mode at startup. */
    public void logActiveMode() {
        if (isGrpcEnabled()) {
            System.out.println("[GrpcConfig] Driver mode: gRPC → target=" + getTarget()
                    + " | deadline=" + getDeadlineSeconds() + "s"
                    + " | retries=" + getRetryCount());
        } else {
            System.out.println("[GrpcConfig] Driver mode: WinAppDriver (default)");
        }
    }
}
