package hwqe.baseframework.flauicontext.grpc;

/**
 * Maps Selenium {@code By} locator types to their gRPC / FlaUI equivalents.
 * Mirrors the LocatorStrategy enum defined in {@code flaui_service.proto}.
 */
public enum LocatorStrategy {
    ACCESSIBILITY_ID,
    NAME,
    XPATH,
    CLASS_NAME,
    ID,
    TAG_NAME,
    AUTOMATION_ID
}
