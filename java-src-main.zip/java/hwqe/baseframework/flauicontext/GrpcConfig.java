package hwqe.baseframework.flauicontext;

import hwqe.baseframework.utilities.PropertyReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Configuration holder for gRPC FlaUI Server connection (Fix #8).
 * <p>
 * Reads all {@code grpc.*} and {@code app.driver.type} properties from
 * {@link PropertyReader} and exposes them as typed, validated fields.
 * <p>
 * Thread-safe singleton — mirrors the PropertyReader pattern used
 * throughout the framework.
 *
 * @see DriverType
 */
@SuppressWarnings({
        "java:S2629",
        "java:S3077",
        "java:S6548",
})
public final class GrpcConfig {

    private static final Logger logger = LoggerFactory.getLogger(GrpcConfig.class);

    // --- Defaults (match config.properties) ---
    private static final String DEFAULT_HOST = "localhost";
    private static final int DEFAULT_PORT = 50051;
    private static final int DEFAULT_TIMEOUT_MS = 30_000;
    private static final int DEFAULT_DEADLINE_MS = 60_000;
    private static final int DEFAULT_KEEPALIVE_TIME_MS = 30_000;
    private static final int DEFAULT_KEEPALIVE_TIMEOUT_MS = 10_000;
    private static final int DEFAULT_MAX_RETRIES = 3;
    private static final int DEFAULT_RETRY_DELAY_MS = 1_000;

    // --- Property keys (single source of truth) ---
    public static final String KEY_DRIVER_TYPE = "app.driver.type";
    public static final String KEY_HOST = "grpc.server.host";
    public static final String KEY_PORT = "grpc.server.port";
    public static final String KEY_TIMEOUT = "grpc.timeout.ms";
    public static final String KEY_DEADLINE = "grpc.deadline.ms";
    public static final String KEY_KEEPALIVE_TIME = "grpc.keepalive.time.ms";
    public static final String KEY_KEEPALIVE_TIMEOUT = "grpc.keepalive.timeout.ms";
    public static final String KEY_MAX_RETRIES = "grpc.max.retries";
    public static final String KEY_RETRY_DELAY = "grpc.retry.delay.ms";

    // --- Singleton ---
    private static volatile GrpcConfig instance;
    private static final Object lock = new Object();

    // --- Config fields ---
    private final DriverType driverType;
    private final String host;
    private final int port;
    private final int timeoutMs;
    private final int deadlineMs;
    private final int keepaliveTimeMs;
    private final int keepaliveTimeoutMs;
    private final int maxRetries;
    private final int retryDelayMs;

    private GrpcConfig() {
        PropertyReader props = PropertyReader.getInstance();

        this.driverType = parseDriverType(props);
        this.host = getStringOrDefault(props, KEY_HOST, DEFAULT_HOST);
        this.port = getIntOrDefault(props, KEY_PORT, DEFAULT_PORT);
        this.timeoutMs = getIntOrDefault(props, KEY_TIMEOUT, DEFAULT_TIMEOUT_MS);
        this.deadlineMs = getIntOrDefault(props, KEY_DEADLINE, DEFAULT_DEADLINE_MS);
        this.keepaliveTimeMs = getIntOrDefault(props, KEY_KEEPALIVE_TIME, DEFAULT_KEEPALIVE_TIME_MS);
        this.keepaliveTimeoutMs = getIntOrDefault(props, KEY_KEEPALIVE_TIMEOUT, DEFAULT_KEEPALIVE_TIMEOUT_MS);
        this.maxRetries = getIntOrDefault(props, KEY_MAX_RETRIES, DEFAULT_MAX_RETRIES);
        this.retryDelayMs = getIntOrDefault(props, KEY_RETRY_DELAY, DEFAULT_RETRY_DELAY_MS);

        logConfiguration();
    }

    /**
     * Get the singleton instance.
     * Thread-safe double-checked locking (same pattern as PropertyReader).
     */
    public static GrpcConfig getInstance() {
        GrpcConfig temp = instance;
        if (temp == null) {
            synchronized (lock) {
                temp = instance;
                if (temp == null) {
                    instance = temp = new GrpcConfig();
                }
            }
        }
        return temp;
    }

    // --- Public Accessors ---

    public DriverType getDriverType() {
        return driverType;
    }

    public boolean isGrpcEnabled() {
        return driverType == DriverType.GRPC;
    }

    public boolean isWinAppDriverEnabled() {
        return driverType == DriverType.WINAPPDRIVER;
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    /** Full gRPC target string for ManagedChannel (e.g. "localhost:50051"). */
    public String getTarget() {
        return host + ":" + port;
    }

    public int getTimeoutMs() {
        return timeoutMs;
    }

    public int getDeadlineMs() {
        return deadlineMs;
    }

    public int getKeepaliveTimeMs() {
        return keepaliveTimeMs;
    }

    public int getKeepaliveTimeoutMs() {
        return keepaliveTimeoutMs;
    }

    public int getMaxRetries() {
        return maxRetries;
    }

    public int getRetryDelayMs() {
        return retryDelayMs;
    }

    // --- Internal Helpers ---

    private DriverType parseDriverType(PropertyReader props) {
        String raw = getStringOrDefault(props, KEY_DRIVER_TYPE, "winappdriver");
        try {
            return DriverType.fromString(raw);
        } catch (IllegalArgumentException e) {
            logger.warn("Invalid app.driver.type='{}'. Falling back to WINAPPDRIVER.", raw);
            return DriverType.WINAPPDRIVER;
        }
    }

    /**
     * Resolve a property value using this priority order:
     * 1. JVM System property  (-Dgrpc.server.host=RXPC...)
     * 2. config.properties via PropertyReader
     * 3. Hardcoded default
     *
     * This lets developers pass -Dgrpc.server.host=RXPC42514513686.US.Wal-Mart.com
     * in IntelliJ VM options without changing config.properties.
     */
    private String getStringOrDefault(PropertyReader props, String key, String defaultValue) {
        // Priority 1: JVM system property
        String sysProp = System.getProperty(key);
        if (sysProp != null && !sysProp.trim().isEmpty()) {
            logger.info("Property '{}' resolved from System property: {}", key, sysProp.trim());
            return sysProp.trim();
        }
        // Priority 2: config.properties
        try {
            String value = props.getProperty(key);
            return (value != null && !value.trim().isEmpty()) ? value.trim() : defaultValue;
        } catch (Exception e) {
            logger.debug("Property '{}' not found, using default: {}", key, defaultValue);
            return defaultValue;
        }
    }

    private int getIntOrDefault(PropertyReader props, String key, int defaultValue) {
        String raw = getStringOrDefault(props, key, String.valueOf(defaultValue));
        try {
            return Integer.parseInt(raw);
        } catch (NumberFormatException e) {
            logger.warn("Invalid integer for '{}': '{}'. Using default: {}", key, raw, defaultValue);
            return defaultValue;
        }
    }

    private void logConfiguration() {
        logger.info("=== Driver Configuration (Fix #8) ===");
        logger.info("  app.driver.type    = {}", driverType.getValue());
        if (isGrpcEnabled()) {
            logger.info("  grpc.target        = {}", getTarget());
            logger.info("  grpc.timeout.ms    = {}", timeoutMs);
            logger.info("  grpc.deadline.ms   = {}", deadlineMs);
            logger.info("  grpc.max.retries   = {}", maxRetries);
        } else {
            logger.info("  WinAppDriver mode  = ACTIVE (gRPC config ignored)");
        }
        logger.info("======================================");
    }

    @Override
    public String toString() {
        return "GrpcConfig{" +
                "driverType=" + driverType +
                ", target='" + getTarget() + '\'' +
                ", timeoutMs=" + timeoutMs +
                ", deadlineMs=" + deadlineMs +
                ", maxRetries=" + maxRetries +
                '}';
    }
}
