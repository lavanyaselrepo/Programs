package hwqe.baseframework.flauicontext;

import hwqe.baseframework.flauicontext.grpc.FlaUIAutomationServiceGrpc;
import hwqe.baseframework.flauicontext.grpc.FlaUIProto;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

/**
 * Manages the gRPC channel lifecycle to the FlaUI Server (Fix #4).
 * <p>
 * Responsibilities:
 * <ul>
 *   <li>Create and configure the {@link ManagedChannel}</li>
 *   <li>Provide a blocking stub with deadline for RPC calls</li>
 *   <li>Health check via Ping RPC</li>
 *   <li>Graceful shutdown</li>
 * </ul>
 * <p>
 * Thread-safe singleton — one channel shared across all test threads.
 *
 * @see GrpcConfig
 * @see GrpcDriver
 */
@SuppressWarnings({
        "java:S3077",
        "java:S6548",
})
public final class GrpcChannelManager {

    private static final Logger logger = LoggerFactory.getLogger(GrpcChannelManager.class);

    private static volatile GrpcChannelManager instance;
    private static final Object lock = new Object();

    private final GrpcConfig config;
    private ManagedChannel channel;
    private boolean connected;

    private GrpcChannelManager() {
        this.config = GrpcConfig.getInstance();
        this.connected = false;
    }

    /**
     * Get the singleton instance.
     */
    public static GrpcChannelManager getInstance() {
        GrpcChannelManager temp = instance;
        if (temp == null) {
            synchronized (lock) {
                temp = instance;
                if (temp == null) {
                    instance = temp = new GrpcChannelManager();
                }
            }
        }
        return temp;
    }

    /**
     * Connect to the gRPC server. Idempotent — safe to call multiple times.
     *
     * @throws IllegalStateException if driver type is not GRPC
     */
    public synchronized void connect() {
        if (connected && channel != null && !channel.isShutdown()) {
            logger.debug("gRPC channel already connected to {}", config.getTarget());
            return;
        }

        if (!config.isGrpcEnabled()) {
            throw new IllegalStateException(
                    "Cannot connect gRPC channel: app.driver.type=" + config.getDriverType().getValue()
                            + ". Set app.driver.type=grpc to use gRPC driver.");
        }

        logger.info("Connecting to gRPC FlaUI Server at {}...", config.getTarget());

        channel = ManagedChannelBuilder
                .forTarget(config.getTarget())
                .usePlaintext() // No TLS for local server
                .keepAliveTime(config.getKeepaliveTimeMs(), TimeUnit.MILLISECONDS)
                .keepAliveTimeout(config.getKeepaliveTimeoutMs(), TimeUnit.MILLISECONDS)
                .keepAliveWithoutCalls(true)
                .build();

        connected = true;
        logger.info("gRPC channel created to {}", config.getTarget());
    }

    /**
     * Get a blocking stub with the configured deadline.
     * Auto-connects if not already connected.
     *
     * @return a blocking stub ready for RPC calls
     */
    public FlaUIAutomationServiceGrpc.FlaUIAutomationServiceBlockingStub getBlockingStub() {
        ensureConnected();
        return FlaUIAutomationServiceGrpc
                .newBlockingStub(channel)
                .withDeadlineAfter(config.getDeadlineMs(), TimeUnit.MILLISECONDS);
    }

    /**
     * Get a blocking stub with a custom deadline (overrides config).
     *
     * @param deadlineMs custom deadline in milliseconds
     * @return a blocking stub with the specified deadline
     */
    public FlaUIAutomationServiceGrpc.FlaUIAutomationServiceBlockingStub getBlockingStub(long deadlineMs) {
        ensureConnected();
        return FlaUIAutomationServiceGrpc
                .newBlockingStub(channel)
                .withDeadlineAfter(deadlineMs, TimeUnit.MILLISECONDS);
    }

    /**
     * Ping the gRPC server to check if it's alive.
     *
     * @return true if the server responds, false otherwise
     */
    public boolean ping() {
        try {
            ensureConnected();
            FlaUIProto.PingResponse response = getBlockingStub(5000)
                    .ping(FlaUIProto.PingRequest.getDefaultInstance());
            logger.info("Ping OK — server v{}, uptime {}s",
                    response.getServerVersion(), response.getUptimeSeconds());
            return response.getAlive();
        } catch (StatusRuntimeException e) {
            logger.error("Ping FAILED: {}", e.getStatus());
            return false;
        } catch (Exception e) {
            logger.error("Ping FAILED: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Check if the channel is currently connected (not shutdown).
     */
    public boolean isConnected() {
        return connected && channel != null && !channel.isShutdown();
    }

    /**
     * Gracefully shut down the gRPC channel.
     * Waits up to 5 seconds for pending RPCs to complete.
     */
    public synchronized void shutdown() {
        if (channel == null || channel.isShutdown()) {
            logger.debug("gRPC channel already shut down.");
            connected = false;
            return;
        }

        logger.info("Shutting down gRPC channel to {}...", config.getTarget());
        try {
            channel.shutdown();
            if (!channel.awaitTermination(5, TimeUnit.SECONDS)) {
                logger.warn("gRPC channel did not terminate in 5s, forcing shutdown.");
                channel.shutdownNow();
            }
            logger.info("gRPC channel shut down successfully.");
        } catch (InterruptedException e) {
            logger.warn("Interrupted during gRPC channel shutdown, forcing.");
            channel.shutdownNow();
            Thread.currentThread().interrupt();
        } finally {
            connected = false;
        }
    }

    /**
     * Auto-connect if not already connected.
     */
    private void ensureConnected() {
        if (!isConnected()) {
            connect();
        }
    }
}
