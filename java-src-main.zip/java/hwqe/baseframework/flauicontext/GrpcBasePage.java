package hwqe.baseframework.flauicontext;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuscontext.ConnexusConstants;
import hwqe.baseframework.flauicontext.LocatorConverter.ParsedLocator;
import hwqe.baseframework.flauicontext.grpc.FlaUIProto;
import hwqe.baseframework.models.pageobjectmodels.Attribute;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.windows.WindowsDriver;
import javafx.util.Pair;
import org.openjdk.tools.sjavac.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.security.SecureRandom;
import javax.imageio.ImageIO;

/**
 * gRPC-based equivalent of {@link hwqe.baseframework.models.pageobjectmodels.WindowsBasePage} (Fix #6).
 * <p>
 * Provides the same method signatures so page objects can extend this instead of
 * WindowsBasePage when running in gRPC mode. Uses {@link GrpcDriver} and
 * {@link LocatorConverter} under the hood.
 * <p>
 * <strong>Strangler Fig Pattern:</strong> This class lives alongside WindowsBasePage.
 * Page objects can be migrated one at a time. When all pages are migrated,
 * WindowsBasePage can be deleted.
 *
 * @see hwqe.baseframework.models.pageobjectmodels.WindowsBasePage
 * @see GrpcDriver
 * @see LocatorConverter
 */
@SuppressWarnings({
        "java:S1068",
        "java:S1104",
        "java:S1128",
        "java:S1168",
        "java:S1172",
        "java:S1481",
        "java:S1854",
        "java:S3776",
        "java:S5993",
})
public abstract class GrpcBasePage {

    private static final Logger log = LoggerFactory.getLogger(GrpcBasePage.class);
    protected final GrpcDriver grpcDriver;
    protected final String sessionId;
    protected final PropertyReader rdr = PropertyReader.getInstance();
    public AutomationManager automationManager = AutomationManager.getInstance();

    // Reduced from 30s — gRPC element discovery is fast, no need for long default waits
    private static final int DEFAULT_TIMEOUT_SECONDS = 15;
    private static final int POLL_INTERVAL_MS = 500;
    private static final int MAX_RETRIES = 3;
    // Threshold (ms) for logging slow gRPC calls — helps detect COM degradation early
    private static final long SLOW_CALL_THRESHOLD_MS = 5000;
    private static final SecureRandom FILE_NAME_RANDOM = new SecureRandom();

    private final By cmbPlan = AppiumBy.accessibilityId("cmbPlan");

    /**
     * Create a GrpcBasePage with gRPC driver and session.
     *
     * @param grpcDriver the gRPC driver instance
     * @param sessionId  the active gRPC session ID
     */
    public GrpcBasePage(GrpcDriver grpcDriver, String sessionId) {
        this.grpcDriver = grpcDriver;
        this.sessionId = sessionId;
    }

    // === WindowsDriver compatibility — returns null in gRPC mode ===

    /**
     * Returns null in gRPC mode. Exists for API compatibility with WindowsBasePage.
     * Use {@link #grpcDriver} for gRPC operations.
     */
    public WindowsDriver getDriver() {
        return null;
    }

    // === Element State Methods ===

    public boolean isElementDisplayed(By elementIdentifier, int waitTimeInSeconds) {
        return pollForElement(elementIdentifier, waitTimeInSeconds, true);
    }

    public boolean isElementDisplayed(By elementIdentifier) {
        return isElementDisplayed(elementIdentifier, DEFAULT_TIMEOUT_SECONDS);
    }

    public boolean isElementEnabled(By elementIdentifier, int waitTimeInSeconds) {
        return pollForElement(elementIdentifier, waitTimeInSeconds, false);
    }

    public boolean isElementEnabled(By elementIdentifier) {
        return isElementEnabled(elementIdentifier, DEFAULT_TIMEOUT_SECONDS);
    }

    public boolean isElementSelected(By elementIdentifier) {
        try {
            String elementId = findElementSafe(elementIdentifier);
            if (elementId != null) {
                return grpcDriver.isSelected(sessionId, elementId);
            }
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return false;
    }

    public boolean isElementNotDisplayed(By elementIdentifier, int waitTimeInSeconds) {
        long deadline = System.currentTimeMillis() + (waitTimeInSeconds * 1000L);
        while (System.currentTimeMillis() < deadline) {
            try {
                String elementId = findElementQuiet(elementIdentifier);
                if (elementId == null || !grpcDriver.isDisplayed(sessionId, elementId)) {
                    return true;
                }
            } catch (Exception e) {
                return true; // element gone = not displayed
            }
            sleep(POLL_INTERVAL_MS);
        }
        return false;
    }

    // === Click Methods ===

    public boolean click(By elementIdentifier) {
        try {
            if (isElementDisplayed(elementIdentifier)) {
                String elementId = findElementSafe(elementIdentifier);
                if (elementId != null) {
                    grpcDriver.click(sessionId, elementId);
                    return true;
                }
            }
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return false;
    }

    public boolean click(By elementIdentifier, int elementIndex) {
        try {
            if (isElementDisplayed(elementIdentifier)) {
                List<FlaUIProto.ElementInfo> elements = findElementsSafe(elementIdentifier);
                if (elements != null && elementIndex < elements.size()) {
                    grpcDriver.click(sessionId, elements.get(elementIndex).getElementId());
                    return true;
                }
            }
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return false;
    }

    public boolean moveToElementAndClick(By elementIdentifier) {
        try {
            if (isElementEnabled(elementIdentifier)) {
                String elementId = findElementSafe(elementIdentifier);
                if (elementId != null) {
                    grpcDriver.click(sessionId, elementId);
                    return true;
                }
            }
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return false;
    }

    public boolean moveToElementAndClick(By elementIdentifier, int waitTimeInSeconds) {
        try {
            if (isElementEnabled(elementIdentifier, waitTimeInSeconds)) {
                String elementId = findElementSafe(elementIdentifier);
                if (elementId != null) {
                    grpcDriver.click(sessionId, elementId);
                    return true;
                }
            }
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return false;
    }

    public boolean doubleClick(By elementIdentifier) {
        try {
            if (isElementDisplayed(elementIdentifier, 10)) {
                String elementId = findElementSafe(elementIdentifier);
                if (elementId != null) {
                    grpcDriver.doubleClick(sessionId, elementId);
                    return true;
                }
            }
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return false;
    }

    public boolean rightClick(By elementIdentifier) {
        try {
            String elementId = findElementSafe(elementIdentifier);
            if (elementId != null) {
                grpcDriver.rightClick(sessionId, elementId);
                return true;
            }
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return false;
    }

    public boolean mouseHoverOnElement(By elementIdentifier, int elementIndex) {
        try {
            List<FlaUIProto.ElementInfo> elements = findElementsSafe(elementIdentifier);
            if (elements != null && elementIndex < elements.size()) {
                grpcDriver.mouseHover(sessionId, elements.get(elementIndex).getElementId());
                return true;
            }
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return false;
    }

    public boolean mouseHoverOnElement(By elementIdentifier) {
        return mouseHoverOnElement(elementIdentifier, 0);
    }

    // === Text Methods ===

    public boolean sendText(By elementIdentifier, String textValue) {
        boolean flag = false;
        int retryCount = 0;
        while (retryCount < MAX_RETRIES && !flag) {
            try {
                if (isElementDisplayed(elementIdentifier, 10)) {
                    String elementId = findElementSafe(elementIdentifier);
                    if (elementId != null) {
                        grpcDriver.sendKeys(sessionId, elementId, textValue, false);
                        flag = true;
                    }
                } else {
                    Reporter.log("Element not ready, retrying... Attempt: " + (retryCount + 1));
                }
            } catch (Exception e) {
                Log.info("sendText failed: " + e.getMessage() + " Attempt: " + (retryCount + 1));
            }
            retryCount++;
        }
        return flag;
    }

    public void sendText(By elementIdentifier, String value, String locatorName) {
        boolean flag = false;
        try {
            String elementId = findElementSafe(elementIdentifier);
            if (elementId != null) {
                grpcDriver.sendKeys(sessionId, elementId, value, false);
                flag = true;
            }
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        Reporter.log("Entered " + value + " in " + locatorName + " field.");
    }

    public boolean sendTextNew(By elementIdentifier, String textValue) {
        boolean flag = false;
        try {
            if (isElementEnabled(elementIdentifier, ConnexusConstants.WAIT_TIMEOUT_60)) {
                String elementId = findElementSafe(elementIdentifier);
                if (elementId != null) {
                    grpcDriver.sendKeys(sessionId, elementId, textValue, true);
                    flag = true;
                }
            }
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return flag;
    }

    public void clearText(By elementIdentifier, String locatorName) {
        boolean flag = false;
        try {
            String elementId = findElementSafe(elementIdentifier);
            if (elementId != null) {
                grpcDriver.clear(sessionId, elementId);
                flag = true;
            }
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        Reporter.log("Text Cleared in " + locatorName);
    }

    public void clearText(By elementIdentifier) {
        if (isElementDisplayed(elementIdentifier, 10)) {
            String elementId = findElementSafe(elementIdentifier);
            if (elementId != null) {
                grpcDriver.clear(sessionId, elementId);
            }
        }
    }

    public String getText(By elementIdentifier) {
        try {
            if (isElementDisplayed(elementIdentifier)) {
                String elementId = findElementSafe(elementIdentifier);
                if (elementId != null) {
                    return grpcDriver.getText(sessionId, elementId);
                }
            }
            return "";
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return null;
    }

    public String getText(By elementIdentifier, int elementIndex) {
        try {
            if (isElementDisplayed(elementIdentifier, 20)) {
                List<FlaUIProto.ElementInfo> elements = findElementsSafe(elementIdentifier);
                if (elements != null && elementIndex < elements.size()) {
                    return grpcDriver.getText(sessionId, elements.get(elementIndex).getElementId());
                }
            }
            return "";
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return null;
    }

    // === Attribute Methods ===

    public String getValueFromAttribute(By elementIdentifier, Attribute attr) {
        String retVal = "";
        try {
            String elementId = findElementSafe(elementIdentifier);
            if (elementId == null) return retVal;

            String attrName = mapAttributeName(attr);
            retVal = grpcDriver.getAttribute(sessionId, elementId, attrName);
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return retVal;
    }

    // === Screenshot Methods ===

    public Pair<String, String> takeScreenShot(String fileName) {
        try {
            // Use Java Robot for full-screen capture
            // (gRPC server's takeScreenshot only captures the app window)
            Robot robot = new Robot();
            Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            BufferedImage capture = robot.createScreenCapture(screenRect);
            String fName = fileName + "_" + FILE_NAME_RANDOM.nextInt(9999) + ".png";
            File savedFile = new File(rdr.getProperty("app.workingfolder_path") + fName);
            ImageIO.write(capture, "png", savedFile);
            return new Pair<>(fName, savedFile.getPath());
        } catch (Exception e) {
            Reporter.log("[Screenshot] Full-screen capture failed: " + e.getClass().getSimpleName()
                    + " - " + e.getMessage());
        }
        return null;
    }

    public String takeScreenShot() {
        try {
            // Use Java Robot for full-screen capture
            Robot robot = new Robot();
            Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            BufferedImage capture = robot.createScreenCapture(screenRect);
            File savedFile = new File(rdr.getProperty("app.workingfolder_path")
                    + java.util.UUID.randomUUID() + ".png");
            ImageIO.write(capture, "png", savedFile);
            return savedFile.getPath();
        } catch (Exception ex) {
            Log.info("Full-screen capture failed: " + ex.getMessage());
        }
        return null;
    }

    // === Window Methods ===

    /**
     * Switch focus to a different window (e.g. the security popup that appears after login).
     * Uses a default timeout of 8 seconds to handle the race condition where the new popup
     * hasn't appeared yet when this method is called immediately after a login action.
     */
    public void switchWindow() {
        switchWindow(8_000);
    }

    /**
     * Switch focus to a different Connexus-owned window, retrying until one appears
     * or the timeout expires.
     * <p>
     * After login, Connexus destroys the login window and spawns a security popup
     * asynchronously. Calling {@code getWindowHandles} immediately after clicking
     * the login button often returns 0 results because the new popup hasn't rendered
     * yet. This method keeps retrying so we don't give up and cause a test failure.
     *
     * @param timeoutMs maximum milliseconds to wait for a new window to appear
     */
    public void switchWindow(int timeoutMs) {
        final int pollIntervalMs = 500;
        long deadline = System.currentTimeMillis() + timeoutMs;
        String currentHandle = null;

        // Resolve the current handle once up-front (best-effort).
        // It may fail if the login window was already destroyed — that's OK,
        // we'll still find the new popup in the loop below.
        try {
            currentHandle = grpcDriver.getWindowHandle(sessionId);
        } catch (Exception ex) {
            log.debug("[GrpcBasePage-switchWindow] Could not get current handle: {}", ex.getMessage());
        }

        log.debug("[GrpcBasePage-switchWindow] Starting window switch. currentHandle={}, timeoutMs={}",
                currentHandle, timeoutMs);

        while (System.currentTimeMillis() < deadline) {
            try {
                List<String> handles = grpcDriver.getWindowHandles(sessionId);

                log.debug("[GrpcBasePage-switchWindow] Current: {} | Available: {} {}",
                        currentHandle, (handles != null ? handles.size() : "null"), handles);

                if (handles != null && !handles.isEmpty()) {
                    // Pick any handle that is different from the one we started on.
                    // This ensures we land on the NEW window (security popup, dialog, etc.).
                    String target = null;
                    for (String handle : handles) {
                        if (!handle.equals(currentHandle)) {
                            target = handle;
                            break;
                        }
                    }

                    if (target != null) {
                        grpcDriver.switchToWindow(sessionId, target);
                        Reporter.log("[GrpcBasePage-switchWindow] SUCCESS: Switched from "
                                + currentHandle + " to " + target);
                        return;
                    }

                    // Only one window and it matches what we already have — the popup
                    // hasn't rendered yet. Fall through to the sleep + retry.
                    log.debug("[GrpcBasePage-switchWindow] Only one window ({}). Waiting for popup...",
                            currentHandle);
                }
            } catch (Exception ex) {
                log.debug("[GrpcBasePage-switchWindow] Poll error (will retry): {}", ex.getMessage());
            }

            try {
                Thread.sleep(pollIntervalMs);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                Reporter.log("[GrpcBasePage-switchWindow] Interrupted while waiting for new window.");
                return;
            }
        }

        Reporter.log("[GrpcBasePage-switchWindow] TIMEOUT: No new window appeared within "
                + timeoutMs + "ms. currentHandle=" + currentHandle + ", session=" + sessionId);
    }

    public boolean focusWindow(String windowName) {
        try {
            grpcDriver.attachToWindow(sessionId, windowName);
            return true;
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
        return false;
    }

    // === Keyboard Methods ===

    public void pressKeys(int... keyEvents) {
        try {
            List<Integer> keyCodes = new ArrayList<>();
            for (int key : keyEvents) {
                keyCodes.add(key);
            }
            grpcDriver.pressKeys(sessionId, keyCodes, null);
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
    }

    public void pressKeys(String keyData) {
        try {
            List<Integer> keyCodes = new ArrayList<>();
            for (char c : keyData.toCharArray()) {
                keyCodes.add((int) c);
            }
            grpcDriver.pressKeys(sessionId, keyCodes, null);
        } catch (Exception e) {
            Log.info(e.getMessage());
        }
    }

    public boolean sendHotKeys(String hotKeys) {
        pressKeys(hotKeys);
        return true;
    }

    public boolean sendHotKeys(String commands, Keys... keys) {
        pressKeys(commands);
        return true;
    }

    public boolean sendHotKeys(Keys... key) {
        pressKeys(Keys.chord(key));
        return true;
    }

    // === List / ComboBox Methods ===

    public void selectFromComboBox(By elementIdentifier, String value) {
        try {
            String elementId = findElementSafe(elementIdentifier);
            if (elementId != null) {
                grpcDriver.selectComboBoxItem(sessionId, elementId, value);
            }
        } catch (Exception e) {
            Reporter.log(e.getMessage());
        }
    }

    public boolean selectListItem(By elementIdentifier, int indexOfValue) {
        try {
            if (isElementDisplayed(elementIdentifier, 20)) {
                String elementId = findElementSafe(elementIdentifier);
                if (elementId != null) {
                    grpcDriver.selectListItem(sessionId, elementId, indexOfValue, null);
                    return true;
                }
            }
        } catch (Exception e) {
            Reporter.log("[GrpcBasePage] selectListItem(index) failed: " + e.getMessage());
        }
        return false;
    }

    public boolean selectListItem(By elementIdentifier, String value) {
        try {
            if (isElementDisplayed(elementIdentifier, 130)) {
                String elementId = findElementSafe(elementIdentifier);
                if (elementId != null) {
                    grpcDriver.selectListItem(sessionId, elementId, -1, value);
                    return true;
                }
            }
        } catch (Exception e) {
            Reporter.log("[GrpcBasePage] selectListItem(value) failed: " + e.getMessage());
        }
        return false;
    }

    // === Popup / Dialog Methods ===

    /**
     * Dismiss a popup by clicking a button (by name or AutomationId).
     *
     * @param buttonName   button text (e.g. "OK", "Yes")
     * @param buttonAutoId or button AutomationId
     * @param timeoutSec   seconds to wait for the popup
     * @return true if popup was dismissed
     */
    public boolean dismissPopup(String buttonName, String buttonAutoId, int timeoutSec) {
        Reporter.log("[GrpcBasePage-dismissPopup] Attempting: buttonName='" + buttonName
                + "' | autoId='" + buttonAutoId + "' | timeout=" + timeoutSec + "s | session=" + sessionId);
        try {
            grpcDriver.dismissPopup(sessionId, buttonName, buttonAutoId, timeoutSec);
            Reporter.log("[GrpcBasePage-dismissPopup] SUCCESS: Popup dismissed.");
            return true;
        } catch (Exception e) {
            Reporter.log("[GrpcBasePage-dismissPopup] FAILED: " + e.getClass().getSimpleName()
                    + " - " + e.getMessage());
            return false;
        }
    }

    public boolean dismissPopup(String buttonName) {
        return dismissPopup(buttonName, "", 5);
    }

    /**
     * Handle a popup — optionally match by title, click an action button.
     *
     * @param expectedTitle optional title to match
     * @param actionButton  button text to click
     * @param timeoutSec    seconds to wait
     * @return true if popup was found and action taken
     */
    public boolean handlePopup(String expectedTitle, String actionButton, int timeoutSec) {
        Reporter.log("[GrpcBasePage-handlePopup] Attempting: title='" + expectedTitle
                + "' | actionButton='" + actionButton + "' | timeout=" + timeoutSec + "s | session=" + sessionId);
        try {
            FlaUIProto.HandlePopupResponse resp =
                    grpcDriver.handlePopup(sessionId, expectedTitle, actionButton, timeoutSec);
            boolean success = resp.getPopupFound() && resp.getActionTaken();
            Reporter.log("[GrpcBasePage-handlePopup] Result: popupFound=" + resp.getPopupFound()
                    + " | popupTitle='" + resp.getPopupTitle() + "'"
                    + " | actionTaken=" + resp.getActionTaken()
                    + " | message='" + resp.getMessage() + "'"
                    + " | outcome=" + (success ? "SUCCESS" : "FAILED"));
            return success;
        } catch (Exception e) {
            Reporter.log("[GrpcBasePage-handlePopup] ERROR: " + e.getClass().getSimpleName()
                    + " - " + e.getMessage());
            return false;
        }
    }

    public boolean handlePopup(String actionButton) {
        return handlePopup("", actionButton, 5);
    }

    // === Drag & Drop Methods ===

    /**
     * Click and drag from one element to another.
     *
     * @param sourceLocator the element to drag from
     * @param targetLocator the element to drag to
     * @return true if drag succeeded
     */
    public boolean clickAndDrag(By sourceLocator, By targetLocator) {
        try {
            String sourceId = findElementSafe(sourceLocator);
            String targetId = findElementSafe(targetLocator);
            if (sourceId != null && targetId != null) {
                grpcDriver.clickAndDrag(sessionId, sourceId, targetId);
                return true;
            }
        } catch (Exception e) {
            Log.info("ClickAndDrag failed: " + e.getMessage());
        }
        return false;
    }

    // === Focus Window Methods ===

    /**
     * Force-focus a window by partial title (uses Win32 ForceForeground trick).
     *
     * @param windowTitle partial window title to match
     * @return true if focus succeeded
     */
    public boolean focusWindowByTitle(String windowTitle) {
        try {
            grpcDriver.focusWindow(sessionId, windowTitle);
            return true;
        } catch (Exception e) {
            Log.info("FocusWindow failed: " + e.getMessage());
            return false;
        }
    }

    // === Wait / Utility Methods ===

    /**
     * Wait for element — returns null in gRPC mode (no WebElement).
     * The element is found via gRPC; this method exists for API compatibility.
     */
    public WebElement waitForElement(By elementIdentifier, String locatorName) {
        // gRPC doesn't return WebElements — poll for visibility instead
        if (!isElementDisplayed(elementIdentifier)) {
            Reporter.log("Unable to locate the element '" + locatorName + "' with " + elementIdentifier);
        }
        return null; // gRPC mode doesn't use WebElements
    }

    // === Internal Helpers ===



    /**
     * Take a screenshot safely, returning null instead of throwing on COM errors.
     * Prevents screenshot failures (e.g., 0x80040201) from slowing down or crashing tests.
     */
    public Pair<String, String> takeScreenShotSafe(String fileName) {
        try {
            return takeScreenShot(fileName);
        } catch (Exception e) {
            Reporter.log("\u26a0\ufe0f [Screenshot] Failed (COM may be degraded): "
                    + e.getClass().getSimpleName() + " \u2014 " + e.getMessage());
            return null;
        }
    }

    /**
     * Poll for an element to become visible (or enabled) within timeout.
     * Includes per-call latency monitoring to detect COM automation degradation.
     */
    private boolean pollForElement(By elementIdentifier, int timeoutSeconds, boolean checkVisible) {
        long deadline = System.currentTimeMillis() + (timeoutSeconds * 1000L);
        while (System.currentTimeMillis() < deadline) {
            try {
                ParsedLocator loc = LocatorConverter.convert(elementIdentifier);
                long callStart = System.currentTimeMillis();
                String elementId = grpcDriver.findElement(sessionId, loc.getStrategy(), loc.getValue());
                long callElapsed = System.currentTimeMillis() - callStart;
                if (callElapsed > SLOW_CALL_THRESHOLD_MS) {
                    Reporter.log("\u26a0\ufe0f [gRPC-SLOW] findElement took " + callElapsed
                            + "ms for " + loc.getStrategy() + "='" + loc.getValue() + "'");
                }
                if (elementId != null) {
                    if (checkVisible) {
                        if (grpcDriver.isDisplayed(sessionId, elementId)) return true;
                    } else {
                        if (grpcDriver.isEnabled(sessionId, elementId)) return true;
                    }
                }
            } catch (Exception ignored) {
                // element not found yet — keep polling
            }
            sleep(POLL_INTERVAL_MS);
        }
        return false;
    }

    /**
     * Find element safely, returning null if not found.
     * Logs a warning when gRPC call latency exceeds threshold.
     */
    protected String findElementSafe(By elementIdentifier) {
        try {
            ParsedLocator loc = LocatorConverter.convert(elementIdentifier);
            long callStart = System.currentTimeMillis();
            String result = grpcDriver.findElement(sessionId, loc.getStrategy(), loc.getValue());
            long callElapsed = System.currentTimeMillis() - callStart;
            if (callElapsed > SLOW_CALL_THRESHOLD_MS) {
                Reporter.log("\u26a0\ufe0f [gRPC-SLOW] findElementSafe took " + callElapsed
                        + "ms for " + loc.getStrategy() + "='" + loc.getValue() + "'");
            }
            return result;
        } catch (Exception e) {
            Log.info("Element not found: " + elementIdentifier + " \u2014 " + e.getMessage());
            return null;
        }
    }

    /**
     * Find element quietly (no logging), returning null if not found.
     */
    private String findElementQuiet(By elementIdentifier) {
        try {
            ParsedLocator loc = LocatorConverter.convert(elementIdentifier);
            return grpcDriver.findElement(sessionId, loc.getStrategy(), loc.getValue());
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Find multiple elements safely.
     */
    protected List<FlaUIProto.ElementInfo> findElementsSafe(By elementIdentifier) {
        try {
            ParsedLocator loc = LocatorConverter.convert(elementIdentifier);
            return grpcDriver.findElements(sessionId, loc.getStrategy(), loc.getValue());
        } catch (Exception e) {
            Log.info("Elements not found: " + elementIdentifier + " — " + e.getMessage());
            return null;
        }
    }

    /**
     * Map {@link Attribute} enum to gRPC attribute name string.
     */
    private String mapAttributeName(Attribute attr) {
        switch (attr) {
            case AutomationId:       return "AutomationId";
            case Name:               return "Name";
            case ClassName:          return "ClassName";
            case IsEnabled:          return "IsEnabled";
            case Value:              return "Value.Value";
            case HasKeyboardFocus:   return "HasKeyboardFocus";
            case IsPassword:         return "IsPassword";
            case IsToggle:           return "Toggle.ToggleState";
            case IsScroll:           return "IsScrollPatternAvailable";
            case HorizontalViewSize: return "Scroll.HorizontalViewSize";
            case VerticalViewSize:   return "Scroll.VerticalViewSize";
            default:                 return attr.name();
        }
    }

    private void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
