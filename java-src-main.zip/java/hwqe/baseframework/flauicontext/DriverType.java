package hwqe.baseframework.flauicontext;

/**
 * Driver type for Windows UI automation (Fix #8 — Strangler Fig Pattern).
 * <p>
 * Controls which automation driver is used at runtime:
 * <ul>
 *   <li>{@link #WINAPPDRIVER} — Existing WinAppDriver/Appium (default, untouched)</li>
 *   <li>{@link #GRPC} — New FlaUI gRPC server for direct native automation</li>
 * </ul>
 * <p>
 * Configured via {@code app.driver.type} in config.properties.
 *
 * @see GrpcConfig
 */
public enum DriverType {

    WINAPPDRIVER("winappdriver"),
    GRPC("grpc");

    private final String value;

    DriverType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    /**
     * Parse a driver type string (case-insensitive).
     *
     * @param text the config value (e.g. "winappdriver" or "grpc")
     * @return the matching DriverType
     * @throws IllegalArgumentException if the value is not recognized
     */
    public static DriverType fromString(String text) {
        if (text == null || text.trim().isEmpty()) {
            return WINAPPDRIVER; // safe default — existing behavior
        }
        for (DriverType type : values()) {
            if (type.value.equalsIgnoreCase(text.trim())) {
                return type;
            }
        }
        throw new IllegalArgumentException(
                "Unknown driver type: '" + text + "'. Valid values: winappdriver, grpc");
    }
}
