package hwqe.baseframework.flauicontext;

/**
 * Exception thrown when a gRPC automation operation fails (Fix #4).
 * <p>
 * Wraps gRPC {@link io.grpc.StatusRuntimeException} and server-side
 * error messages into a clean framework exception.
 *
 * @see GrpcDriver
 */
public class GrpcDriverException extends RuntimeException {

    public GrpcDriverException(String message) {
        super(message);
    }

    public GrpcDriverException(String message, Throwable cause) {
        super(message, cause);
    }
}
