package hwqe.baseframework.flauicontext;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

/**
 * Ensures the FlaUI gRPC server is running before Connexus launch.
 * <p>
 * When the configured host resolves to localhost (127.0.0.1 or the machine's
 * own hostname) this manager will <em>automatically start</em> the C# FlaUI
 * gRPC server from {@code grpc.server.exe.path} if the server is not already
 * listening on the configured port.
 * <p>
 * When the configured host is a <em>remote</em> machine the server must be
 * started manually (or via a deployment script) before the tests run.
 * In that case {@link #ensureServerRunning()} still retries a few times and
 * returns {@code false} with a helpful error message if unreachable.
 */
@SuppressWarnings({
        "java:S3077",
        "java:S6126",
        "java:S6548",
})
public final class GrpcServerManager {

    private static final Logger logger = LoggerFactory.getLogger(GrpcServerManager.class);

    /** Seconds to wait for the server to respond after starting it. */
    private static final int STARTUP_TIMEOUT_SEC  = 30;
    /** Polling interval (ms) while waiting for the server to boot. */
    private static final int STARTUP_POLL_MS      = 2_000;
    /** Max seconds allowed for dotnet publish recovery. */
    private static final int PUBLISH_TIMEOUT_SEC  = 300;
    /** TCP probe wait time per attempt (sec). */
    private static final int PROBE_WAIT_SEC       = 3;
    /** Retries when the server should already be running (remote host). */
    private static final int PING_RETRIES         = 3;
    private static final int PING_RETRY_DELAY_MS  = 2_000;

    /** Preferred fixed machine install path for RXPC-wide setup. */
    private static final String STANDARD_MACHINE_INSTALL_DIR =
            "C:\\HWQE\\FlaUIgRPC";
    /** Preferred fixed machine install path for RXPC-wide setup. */
    private static final String STANDARD_MACHINE_EXE_PATH =
            STANDARD_MACHINE_INSTALL_DIR + "\\FlaUIgRPC.Server.exe";
    /** Source project used for local auto-publish recovery. */
    private static final String SERVER_PROJECT_REL_PATH =
            "grpc-server/FlaUIgRPC.Server/FlaUIgRPC.Server.csproj";
    /** TCP probe wait time per attempt (sec). */

    private static volatile GrpcServerManager instance;
    private static final Object lock = new Object();

    private final GrpcConfig config;
    private volatile Process serverProcess;

    private GrpcServerManager() {
        this.config = GrpcConfig.getInstance();
    }

    public static GrpcServerManager getInstance() {
        GrpcServerManager temp = instance;
        if (temp == null) {
            synchronized (lock) {
                temp = instance;
                if (temp == null) {
                    instance = temp = new GrpcServerManager();
                }
            }
        }
        return temp;
    }

    // ===================================================================
    // Public API
    // ===================================================================

    /**
     * Guarantee the FlaUI gRPC server is running.
     * <p>
     * <ul>
     *   <li>If the server is already reachable → returns {@code true} immediately.</li>
     *   <li>If the host is <b>local</b> and the server is not running →
     *       starts the exe from {@code grpc.server.exe.path}, waits up to
     *       {@value #STARTUP_TIMEOUT_SEC}s for it to come up.</li>
     *   <li>If the host is <b>remote</b> and the server is not running →
     *       retries {@value #PING_RETRIES} times then returns {@code false}.</li>
     * </ul>
     *
     * @return {@code true} when the server is ready, {@code false} otherwise
     */
    public boolean ensureServerRunning() {
        String target = config.getTarget();
        logger.info("[GrpcServerManager] Checking FlaUI gRPC server at {} ...", target);

        // Fast path: already up
        if (isServerReachable(target)) {
            logger.info("[GrpcServerManager] Server already READY at {}", target);
            return true;
        }

        boolean localTarget = isLocalHost(config.getHost());
        logger.info("[GrpcServerManager] Target '{}' resolved as {} host.",
                config.getHost(), localTarget ? "LOCAL" : "REMOTE");

        if (localTarget) {
            return startLocalServer(target);
        } else {
            return waitForRemoteServer(target);
        }
    }

    /**
     * Register a JVM shutdown hook to stop the locally-started server process
     * (no-op when server was not started by this manager).
     */
    public void registerShutdownHook() {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            Process p = serverProcess;
            if (p != null && p.isAlive()) {
                logger.info("[GrpcServerManager] Shutdown hook: stopping FlaUI gRPC server...");
                p.destroyForcibly();
            }
        }, "grpc-server-shutdown"));
    }

    // ===================================================================
    // Local server startup
    // ===================================================================

    private boolean startLocalServer(String target) {
        File exe = ensureLocalServerExecutableAvailable();
        if (exe == null) {
            logger.error("[GrpcServerManager] Cannot auto-start local FlaUI gRPC server for {}.\n"
                            + "  Checked fixed machine install path only: {}\n"
                            + "  Attempted local auto-publish from: {}\n"
                            + "  Recommended permanent install path: {}",
                    target, STANDARD_MACHINE_EXE_PATH, SERVER_PROJECT_REL_PATH, STANDARD_MACHINE_EXE_PATH);
            return false;
        }

        logger.info("[GrpcServerManager] Local target detected. Server not running — starting from: {}",
                exe.getAbsolutePath());
        try {
            ProcessBuilder pb = new ProcessBuilder(exe.getAbsolutePath())
                    .directory(exe.getParentFile())
                    // CRITICAL: inheritIO() lets the child process write directly to the JVM's
                    // stdout/stderr instead of piping through a bounded buffer.
                    // Without this, the C# Serilog startup logs fill the 64 KB Windows pipe buffer
                    // and the server deadlocks waiting to flush — it never opens the gRPC port.
                    .inheritIO();
            // Inherit parent environment so .NET runtime resolves correctly
            pb.environment().put("DOTNET_ENVIRONMENT", "Production");

            serverProcess = pb.start();
            registerShutdownHook();
            logger.info("[GrpcServerManager] Server process started. "
                    + "Waiting up to {}s for it to accept connections...", STARTUP_TIMEOUT_SEC);
        } catch (IOException e) {
            logger.error("[GrpcServerManager] Failed to start server process: {}", e.getMessage(), e);
            return false;
        }

        // Poll until the server is ready or we time out
        long deadline = System.currentTimeMillis() + STARTUP_TIMEOUT_SEC * 1000L;
        int attempt = 0;
        while (System.currentTimeMillis() < deadline) {
            attempt++;
            if (!serverProcess.isAlive()) {
                logger.error("[GrpcServerManager] Server process exited unexpectedly "
                        + "(exit code: {}).", serverProcess.exitValue());
                return false;
            }
            if (isServerReachable(target)) {
                logger.info("[GrpcServerManager] Server READY after ~{}s (attempt {}).",
                        (attempt * STARTUP_POLL_MS / 1000), attempt);
                return true;
            }
            logger.debug("[GrpcServerManager] Still starting (attempt {}), retrying in {}ms...",
                    attempt, STARTUP_POLL_MS);
            sleep(STARTUP_POLL_MS);
        }

        logger.error("[GrpcServerManager] Server did not become ready within {}s.",
                STARTUP_TIMEOUT_SEC);
        return false;
    }

    // ===================================================================
    // Remote server: wait-with-retry
    // ===================================================================

    private boolean waitForRemoteServer(String target) {
        logger.warn("[GrpcServerManager] Remote host detected — cannot auto-start. "
                        + "Ensure the FlaUI gRPC server is installed and running on {}:{}.",
                config.getHost(), config.getPort());

        for (int attempt = 1; attempt <= PING_RETRIES; attempt++) {
            if (isServerReachable(target)) {
                logger.info("[GrpcServerManager] Remote server READY at {} (attempt {})",
                        target, attempt);
                return true;
            }
            if (attempt < PING_RETRIES) {
                logger.warn("[GrpcServerManager] Attempt {}/{}: server not ready, retrying in {}ms...",
                        attempt, PING_RETRIES, PING_RETRY_DELAY_MS);
                sleep(PING_RETRY_DELAY_MS);
            }
        }

        logger.error("[GrpcServerManager] FlaUI gRPC server UNREACHABLE at {} after {} attempts.\n"
                        + "  ACTION: install and auto-run FlaUIgRPC.Server.exe on the RXPC machine.\n"
                        + "  Recommended fixed install path: {}\n"
                        + "  Also verify port {} is open in Windows Firewall.",
                target, PING_RETRIES, STANDARD_MACHINE_EXE_PATH, config.getPort());
        return false;
    }

    // ===================================================================
    // Reachability probe — TCP + brief wait
    // ===================================================================

    /**
     * Open a gRPC probe channel and check its connectivity state.
     * Only {@code READY} (server accepted TCP + HTTP/2 upgrade) counts as up.
     */
    private boolean isServerReachable(String target) {
        ManagedChannel probeChannel = null;
        try {
            probeChannel = ManagedChannelBuilder
                    .forTarget(target)
                    .usePlaintext()
                    .build();

            probeChannel.getState(true); // trigger connection attempt
            Thread.sleep(PROBE_WAIT_SEC * 1000L);

            io.grpc.ConnectivityState state = probeChannel.getState(false);
            // READY = server accepted the connection.
            // IDLE / CONNECTING / TRANSIENT_FAILURE all mean "not up yet".
            boolean ready = (state == io.grpc.ConnectivityState.READY);
            logger.debug("[GrpcServerManager] Probe state: {} → ready={}", state, ready);
            return ready;

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        } catch (Exception e) {
            logger.debug("[GrpcServerManager] Probe exception: {}", e.getMessage());
            return false;
        } finally {
            if (probeChannel != null) {
                try { probeChannel.shutdownNow().awaitTermination(1, TimeUnit.SECONDS); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            }
        }
    }

    // ===================================================================
    // Helpers
    // ===================================================================

    /**
     * Determines if the configured host resolves to this machine
     * (i.e. localhost, 127.0.0.1, or the machine's own hostname/IP).
     */
    private boolean isLocalHost(String host) {
        if (host == null) return false;
        String h = host.trim().toLowerCase();
        if (h.equals("localhost") || h.equals("127.0.0.1") || h.equals("::1")) {
            return true;
        }
        try {
            String localName = InetAddress.getLocalHost().getHostName().toLowerCase();
            String localAddr = InetAddress.getLocalHost().getHostAddress();
            return h.equals(localName) || h.startsWith(localName.split("\\.")[0].toLowerCase())
                    || h.equals(localAddr);
        } catch (Exception e) {
            logger.debug("[GrpcServerManager] Could not resolve local hostname: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Resolve the FlaUI gRPC server exe from the fixed machine install path only.
     */
    private File resolveExePath() {
        File exe = new File(STANDARD_MACHINE_EXE_PATH);
        if (exe.exists() && exe.isFile()) {
            logger.info("[GrpcServerManager] Resolved server exe from fixed machine path: {}",
                    exe.getAbsolutePath());
            return exe;
        }
        return null;
    }

    private File ensureLocalServerExecutableAvailable() {
        File exe = resolveExePath();
        if (exe != null) {
            return exe;
        }

        File projectFile = resolveServerProjectFile();
        if (projectFile == null) {
            logger.warn("[GrpcServerManager] FlaUI gRPC server exe is missing and project file was not found at {}.",
                    SERVER_PROJECT_REL_PATH);
            return null;
        }

        logger.warn("[GrpcServerManager] FlaUI gRPC server exe not found. Attempting local recovery via dotnet publish from {}.",
                projectFile.getAbsolutePath());

        if (!publishLocalServer(projectFile)) {
            return null;
        }

        exe = resolveExePath();
        if (exe == null) {
            logger.error("[GrpcServerManager] dotnet publish completed but no runnable FlaUI gRPC server exe was found.");
        }
        return exe;
    }

    private File resolveServerProjectFile() {
        File projectFile = new File(SERVER_PROJECT_REL_PATH);
        if (!projectFile.isAbsolute()) {
            projectFile = Paths.get(System.getProperty("user.dir"), SERVER_PROJECT_REL_PATH).toFile();
        }
        return (projectFile.exists() && projectFile.isFile()) ? projectFile : null;
    }

    private boolean publishLocalServer(File projectFile) {
        File installDir = new File(STANDARD_MACHINE_INSTALL_DIR);
        if (!installDir.exists() && !installDir.mkdirs()) {
            logger.error("[GrpcServerManager] Failed to create install directory for FlaUI gRPC server: {}",
                    installDir.getAbsolutePath());
            return false;
        }

        Process publishProcess = null;
        try {
            String dotnetExecutable = resolveDotnetExecutable();
            ProcessBuilder pb = new ProcessBuilder(
                    dotnetExecutable,
                    "publish",
                    projectFile.getAbsolutePath(),
                    "-c", "Release",
                    "-r", "win-x64",
                    "--self-contained", "true",
                    "-o", installDir.getAbsolutePath()
            ).directory(projectFile.getParentFile())
                    .inheritIO();

            pb.environment().put("DOTNET_ENVIRONMENT", "Production");

            logger.info("[GrpcServerManager] Running local recovery publish to {} ...", installDir.getAbsolutePath());
            publishProcess = pb.start();

            if (!publishProcess.waitFor(PUBLISH_TIMEOUT_SEC, TimeUnit.SECONDS)) {
                publishProcess.destroyForcibly();
                logger.error("[GrpcServerManager] dotnet publish timed out after {}s.", PUBLISH_TIMEOUT_SEC);
                return false;
            }

            if (publishProcess.exitValue() != 0) {
                logger.error("[GrpcServerManager] dotnet publish failed with exit code {}.", publishProcess.exitValue());
                return false;
            }

            logger.info("[GrpcServerManager] dotnet publish completed successfully.");
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.error("[GrpcServerManager] dotnet publish was interrupted.");
            return false;
        } catch (IOException e) {
            logger.error("[GrpcServerManager] Failed to run dotnet publish: {}", e.getMessage(), e);
            return false;
        }
    }

    private String resolveDotnetExecutable() {
        String configured = System.getProperty("dotnet.executable.path");
        if (configured != null && !configured.trim().isEmpty()) {
            File configuredFile = new File(configured.trim());
            if (configuredFile.exists() && configuredFile.isFile()) {
                return configuredFile.getAbsolutePath();
            }
        }

        String[] candidates = new String[] {
                "C:\\Program Files\\dotnet\\dotnet.exe",
                "C:\\Program Files (x86)\\dotnet\\dotnet.exe"
        };
        for (String candidate : candidates) {
            File exe = new File(candidate);
            if (exe.exists() && exe.isFile()) {
                return exe.getAbsolutePath();
            }
        }

        String dotnetRoot = System.getenv("DOTNET_ROOT");
        if (dotnetRoot != null && !dotnetRoot.trim().isEmpty()) {
            File exe = Paths.get(dotnetRoot.trim(), "dotnet.exe").toFile();
            if (exe.exists() && exe.isFile()) {
                return exe.getAbsolutePath();
            }
        }

        throw new IllegalStateException(
                "dotnet executable not found. Configure with system property 'dotnet.executable.path', "
                        + "set environment variable 'DOTNET_ROOT', or install dotnet under standard Program Files paths. "
                        + "Refusing PATH fallback for security.");
    }

    private void sleep(int ms) {
        try { Thread.sleep(ms); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
