package hwqe.baseframework.flauicontext;

import hwqe.baseframework.flauicontext.grpc.FlaUIProto.LocatorStrategy;
import org.openqa.selenium.By;
import org.openqa.selenium.support.pagefactory.ByChained;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * Converts Selenium/Appium {@link By} locators to gRPC {@link LocatorStrategy} + value (Fix #6).
 * <p>
 * Supports:
 * <ul>
 *   <li>{@code AppiumBy.accessibilityId("id")} → ACCESSIBILITY_ID</li>
 *   <li>{@code AppiumBy.name("name")} → NAME</li>
 *   <li>{@code AppiumBy.xpath("//...")} → XPATH</li>
 *   <li>{@code AppiumBy.className("cls")} → CLASS_NAME</li>
 *   <li>{@code AppiumBy.id("id")} → AUTOMATION_ID</li>
 * </ul>
 *
 * @see GrpcBasePage
 */
@SuppressWarnings({
        "java:S3011",
        "java:S6206",
        "java:S6208",
})
public final class LocatorConverter {

    private LocatorConverter() {
        // utility class — no instantiation
    }

    /**
     * Parsed locator result containing strategy and value.
     */
    public static final class ParsedLocator {
        private final LocatorStrategy strategy;
        private final String value;

        public ParsedLocator(LocatorStrategy strategy, String value) {
            this.strategy = strategy;
            this.value = value;
        }

        public LocatorStrategy getStrategy() { return strategy; }
        public String getValue() { return value; }

        @Override
        public String toString() {
            return strategy + "='" + value + "'";
        }
    }

    /**
     * Check if a {@link By} locator is a {@link ByChained} (compound locator).
     * ByChained locators need special handling — they must be resolved step-by-step
     * (find parent, then find child within parent).
     */
    public static boolean isChained(By by) {
        return by instanceof ByChained;
    }

    /**
     * Extract the individual {@link By} locators from a {@link ByChained} instance.
     * Uses reflection to access the private {@code bys} field.
     *
     * @param chained the ByChained locator
     * @return list of individual By locators in chain order (parent first)
     */
    public static List<ParsedLocator> convertChained(ByChained chained) {
        List<ParsedLocator> result = new ArrayList<>();
        try {
            // ByChained stores its locators in a private By[] field called "bys"
            Field bysField = ByChained.class.getDeclaredField("bys");
            bysField.setAccessible(true);
            By[] bys = (By[]) bysField.get(chained);
            for (By by : bys) {
                result.add(convert(by));
            }
        } catch (Exception e) {
            throw new IllegalArgumentException(
                    "Cannot extract locators from ByChained: " + chained, e);
        }
        return result;
    }

    /**
     * Convert a Selenium {@link By} to a gRPC {@link LocatorStrategy} + value.
     *
     * @param by the Selenium/Appium locator
     * @return parsed locator with strategy and value
     * @throws IllegalArgumentException if the By type is not supported
     */
    public static ParsedLocator convert(By by) {
        if (by == null) {
            throw new IllegalArgumentException("By locator cannot be null");
        }

        String byString = by.toString();
        ParsedTypeAndValue parsed = parseTypeAndValue(byString);
        if (parsed == null) {
            throw new IllegalArgumentException(
                    "Cannot parse By locator: '" + byString + "'");
        }

        String type = parsed.type;
        String value = parsed.value;

        switch (type) {
            case "accessibilityid":
            case "accessibility id":
                return new ParsedLocator(LocatorStrategy.ACCESSIBILITY_ID, value);
            case "name":
                return new ParsedLocator(LocatorStrategy.NAME, value);
            case "xpath":
                return new ParsedLocator(LocatorStrategy.XPATH, value);
            case "classname":
            case "class name":
                return new ParsedLocator(LocatorStrategy.CLASS_NAME, value);
            case "id":
                return new ParsedLocator(LocatorStrategy.AUTOMATION_ID, value);
            default:
                throw new IllegalArgumentException(
                        "Unsupported By type: '" + type + "' from '" + byString + "'");
        }
    }

    /**
     * Parse a Selenium/Appium By.toString() without regex backtracking.
     * Expected shapes:
     * - "By.name: value"
     * - "AppiumBy.accessibilityId: value"
     */
    private static ParsedTypeAndValue parseTypeAndValue(String byString) {
        if (byString == null) return null;

        String working = byString;
        if (working.startsWith("AppiumBy.")) {
            working = working.substring("AppiumBy.".length());
        } else if (working.startsWith("By.")) {
            working = working.substring("By.".length());
        } else {
            return null;
        }

        int sep = working.indexOf(':');
        if (sep < 0) return null;

        String type = working.substring(0, sep).trim().toLowerCase();
        String value = working.substring(sep + 1);
        // Preserve meaningful leading whitespace while tolerating standard ": " formatting.
        if (!value.isEmpty() && value.charAt(0) == ' ') {
            value = value.substring(1);
        }
        return new ParsedTypeAndValue(type, value);
    }

    private static final class ParsedTypeAndValue {
        private final String type;
        private final String value;

        private ParsedTypeAndValue(String type, String value) {
            this.type = type;
            this.value = value;
        }
    }
}
