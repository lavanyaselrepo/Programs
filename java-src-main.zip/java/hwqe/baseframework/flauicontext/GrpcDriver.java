package hwqe.baseframework.flauicontext;

import hwqe.baseframework.flauicontext.grpc.FlaUIAutomationServiceGrpc;
import hwqe.baseframework.flauicontext.grpc.FlaUIProto;
import hwqe.baseframework.flauicontext.grpc.FlaUIProto.*;
import io.grpc.StatusRuntimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

/**
 * Java client wrapper for the FlaUI gRPC Server (Fix #4).
 * <p>
 * Wraps all 26 RPC methods with:
 * <ul>
 *   <li>Automatic retry with configurable attempts and delay</li>
 *   <li>Deadline enforcement via {@link GrpcChannelManager}</li>
 *   <li>Structured error handling and logging</li>
 *   <li>Clean Java API matching {@code WindowsBasePage} semantics</li>
 * </ul>
 * <p>
 * Usage:
 * <pre>
 * GrpcDriver driver = GrpcDriver.getInstance();
 * String sessionId = driver.createSession(capabilities);
 * String elementId = driver.findElement(sessionId, LocatorStrategy.ACCESSIBILITY_ID, "txtUsername");
 * driver.click(sessionId, elementId);
 * driver.sendKeys(sessionId, elementId, "admin", true);
 * driver.closeSession(sessionId);
 * </pre>
 *
 * @see GrpcChannelManager
 * @see GrpcConfig
 */
@SuppressWarnings({
        "java:S1172",
        "java:S3077",
        "java:S6539",
        "java:S6548",
})
public final class GrpcDriver {

    private static final Logger logger = LoggerFactory.getLogger(GrpcDriver.class);

    private static volatile GrpcDriver instance;
    private static final Object lock = new Object();

    private final GrpcChannelManager channelManager;
    private final GrpcConfig config;

    private GrpcDriver() {
        this.channelManager = GrpcChannelManager.getInstance();
        this.config = GrpcConfig.getInstance();
    }

    public static GrpcDriver getInstance() {
        GrpcDriver temp = instance;
        if (temp == null) {
            synchronized (lock) {
                temp = instance;
                if (temp == null) {
                    instance = temp = new GrpcDriver();
                }
            }
        }
        return temp;
    }

    // ================================================================
    // Session Management
    // ================================================================

    /**
     * Create a new automation session on the gRPC server.
     *
     * @param capabilities session capabilities (key-value pairs)
     * @return the session ID assigned by the server
     * @throws GrpcDriverException if session creation fails
     */
    public String createSession(Map<String, String> capabilities) {
        CreateSessionRequest request = CreateSessionRequest.newBuilder()
                .putAllCapabilities(capabilities)
                .build();

        CreateSessionResponse response = executeWithRetry("CreateSession", () ->
                getStub().createSession(request));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("CreateSession failed: " + response.getErrorMessage());
        }

        logger.info("Session created: {}", response.getSessionId());
        return response.getSessionId();
    }

    /**
     * Close an existing session.
     *
     * @param sessionId the session to close
     */
    public void closeSession(String sessionId) {
        CloseSessionRequest request = CloseSessionRequest.newBuilder()
                .setSessionId(sessionId)
                .build();

        CloseSessionResponse response = executeWithRetry("CloseSession", () ->
                getStub().closeSession(request));

        if (!response.getSuccess()) {
            logger.warn("CloseSession warning: {}", response.getErrorMessage());
        } else {
            logger.info("Session closed: {}", sessionId);
        }
    }

    // ================================================================
    // Application Lifecycle
    // ================================================================

    /**
     * Launch an application.
     *
     * @param sessionId the session ID
     * @param appPath   path to the executable
     * @param arguments launch arguments
     * @return the window handle of the launched app
     */
    public String launchApplication(String sessionId, String appPath, Map<String, String> arguments) {
        LaunchAppRequest request = LaunchAppRequest.newBuilder()
                .setSessionId(sessionId)
                .setAppPath(appPath)
                .putAllArguments(arguments)
                .build();

        LaunchAppResponse response = executeWithRetry("LaunchApplication", () ->
                getStub().launchApplication(request));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("LaunchApplication failed: " + response.getErrorMessage());
        }

        logger.info("Application launched: {} (handle: {})", appPath, response.getWindowHandle());
        return response.getWindowHandle();
    }

    /**
     * Attach to an existing window by title.
     *
     * @param sessionId   the session ID
     * @param windowTitle the window title to attach to
     * @return the window handle
     */
    public String attachToWindow(String sessionId, String windowTitle) {
        AttachToWindowRequest request = AttachToWindowRequest.newBuilder()
                .setSessionId(sessionId)
                .setWindowTitle(windowTitle)
                .build();

        AttachToWindowResponse response = executeWithRetry("AttachToWindow", () ->
                getStub().attachToWindow(request));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("AttachToWindow failed: " + response.getErrorMessage());
        }

        logger.info("Attached to window: '{}' (handle: {})", windowTitle, response.getWindowHandle());
        return response.getWindowHandle();
    }

    /**
     * Attach to an existing window by native handle.
     *
     * @param sessionId    the session ID
     * @param windowHandle the hex window handle
     * @return the window handle
     */
    public String attachToWindowByHandle(String sessionId, String windowHandle) {
        AttachToWindowRequest request = AttachToWindowRequest.newBuilder()
                .setSessionId(sessionId)
                .setWindowHandle(windowHandle)
                .build();

        AttachToWindowResponse response = executeWithRetry("AttachToWindow", () ->
                getStub().attachToWindow(request));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("AttachToWindow failed: " + response.getErrorMessage());
        }

        return response.getWindowHandle();
    }

    /**
     * Close the application in the current session.
     */
    public void closeApplication(String sessionId) {
        CloseAppRequest request = CloseAppRequest.newBuilder()
                .setSessionId(sessionId)
                .build();

        CloseAppResponse response = executeWithRetry("CloseApplication", () ->
                getStub().closeApplication(request));

        if (!response.getSuccess()) {
            logger.warn("CloseApplication warning: {}", response.getErrorMessage());
        } else {
            logger.info("Application closed for session: {}", sessionId);
        }
    }

    // ================================================================
    // Element Discovery
    // ================================================================

    /**
     * Find a single element.
     *
     * @param sessionId the session ID
     * @param strategy  locator strategy (e.g. ACCESSIBILITY_ID, NAME, XPATH)
     * @param value     locator value
     * @return the server-side element ID
     */
    public String findElement(String sessionId, FlaUIProto.LocatorStrategy strategy, String value) {
        return findElement(sessionId, strategy, value, "", 0);
    }

    /**
     * Find a single element with parent scope and timeout.
     *
     * @param sessionId       the session ID
     * @param strategy        locator strategy
     * @param value           locator value
     * @param parentElementId optional parent element to search within
     * @param timeoutMs       wait timeout in milliseconds (0 = server default)
     * @return the server-side element ID
     */
    public String findElement(String sessionId, FlaUIProto.LocatorStrategy strategy,
                              String value, String parentElementId, int timeoutMs) {
        FindElementRequest.Builder builder = FindElementRequest.newBuilder()
                .setSessionId(sessionId)
                .setStrategy(strategy)
                .setValue(value);

        if (parentElementId != null && !parentElementId.isEmpty()) {
            builder.setParentElementId(parentElementId);
        }
        if (timeoutMs > 0) {
            builder.setTimeoutMs(timeoutMs);
        }

        FindElementResponse response = executeWithRetry("FindElement", () ->
                getStub().findElement(builder.build()));

        if (!response.getFound()) {
            throw new GrpcDriverException("Element not found: " + strategy + "='" + value + "'"
                    + (response.getErrorMessage().isEmpty() ? "" : " — " + response.getErrorMessage()));
        }

        return response.getElementId();
    }

    /**
     * Find multiple elements from the session root (MainWindow).
     *
     * @return list of element info objects
     */
    public List<FlaUIProto.ElementInfo> findElements(String sessionId,
                                                     FlaUIProto.LocatorStrategy strategy, String value) {
        return findElements(sessionId, strategy, value, null);
    }

    /**
     * Find multiple elements scoped to a specific parent element.
     * Pass {@code parentElementId} to restrict the search to descendants of that element,
     * which avoids matching identically-named elements elsewhere in the window tree.
     *
     * @param parentElementId optional cached element ID to use as search root; null = MainWindow
     * @return list of element info objects
     */
    public List<FlaUIProto.ElementInfo> findElements(String sessionId,
                                                     FlaUIProto.LocatorStrategy strategy, String value,
                                                     String parentElementId) {
        FindElementRequest.Builder builder = FindElementRequest.newBuilder()
                .setSessionId(sessionId)
                .setStrategy(strategy)
                .setValue(value);
        if (parentElementId != null && !parentElementId.isEmpty()) {
            builder.setParentElementId(parentElementId);
        }

        FindElementsResponse response = executeWithRetry("FindElements", () ->
                getStub().findElements(builder.build()));

        return response.getElementsList();
    }

    // ================================================================
    // Element Interactions
    // ================================================================

    /**
     * Click an element.
     */
    public void click(String sessionId, String elementId) {
        executeElementAction("Click", sessionId, elementId,
                stub -> stub.click(elementAction(sessionId, elementId)));
    }

    /**
     * Send keys (type text) into an element.
     *
     * @param clearFirst if true, clears the field before typing
     */
    public void sendKeys(String sessionId, String elementId, String text, boolean clearFirst) {
        SendKeysRequest request = SendKeysRequest.newBuilder()
                .setSessionId(sessionId)
                .setElementId(elementId)
                .setText(text)
                .setClearFirst(clearFirst)
                .build();

        ActionResponse response = executeWithRetry("SendKeys", () ->
                getStub().sendKeys(request));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("SendKeys failed: " + response.getErrorMessage());
        }
    }

    /**
     * Clear an element's text.
     */
    public void clear(String sessionId, String elementId) {
        executeElementAction("Clear", sessionId, elementId,
                stub -> stub.clear(elementAction(sessionId, elementId)));
    }

    // ================================================================
    // Element State
    // ================================================================

    /**
     * Get the text content of an element.
     */
    public String getText(String sessionId, String elementId) {
        GetTextResponse response = executeWithRetry("GetText", () ->
                getStub().getText(elementAction(sessionId, elementId)));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("GetText failed: " + response.getErrorMessage());
        }
        return response.getText();
    }

    /**
     * Get an attribute value of an element.
     */
    public String getAttribute(String sessionId, String elementId, String attributeName) {
        GetAttributeRequest request = GetAttributeRequest.newBuilder()
                .setSessionId(sessionId)
                .setElementId(elementId)
                .setAttributeName(attributeName)
                .build();

        GetAttributeResponse response = executeWithRetry("GetAttribute", () ->
                getStub().getAttribute(request));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("GetAttribute failed: " + response.getErrorMessage());
        }
        return response.getValue();
    }

    /**
     * Check if an element is displayed.
     */
    public boolean isDisplayed(String sessionId, String elementId) {
        return executeBoolAction("IsDisplayed", sessionId, elementId,
                stub -> stub.isDisplayed(elementAction(sessionId, elementId)));
    }

    /**
     * Check if an element is enabled.
     */
    public boolean isEnabled(String sessionId, String elementId) {
        return executeBoolAction("IsEnabled", sessionId, elementId,
                stub -> stub.isEnabled(elementAction(sessionId, elementId)));
    }

    /**
     * Check if an element is selected.
     */
    public boolean isSelected(String sessionId, String elementId) {
        return executeBoolAction("IsSelected", sessionId, elementId,
                stub -> stub.isSelected(elementAction(sessionId, elementId)));
    }

    // ================================================================
    // Window Management
    // ================================================================

    /**
     * Get the current window handle.
     */
    public String getWindowHandle(String sessionId) {
        WindowHandleResponse response = executeWithRetry("GetWindowHandle", () ->
                getStub().getWindowHandle(sessionRequest(sessionId)));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("GetWindowHandle failed: " + response.getErrorMessage());
        }
        return response.getWindowHandle();
    }

    /**
     * Get all window handles.
     */
    public List<String> getWindowHandles(String sessionId) {
        WindowHandlesResponse response = executeWithRetry("GetWindowHandles", () ->
                getStub().getWindowHandles(sessionRequest(sessionId)));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("GetWindowHandles failed: " + response.getErrorMessage());
        }
        return response.getWindowHandlesList();
    }

    /**
     * Switch to a window by handle.
     */
    public void switchToWindow(String sessionId, String windowHandle) {
        SwitchWindowRequest request = SwitchWindowRequest.newBuilder()
                .setSessionId(sessionId)
                .setWindowHandle(windowHandle)
                .build();

        ActionResponse response = executeWithRetry("SwitchToWindow", () ->
                getStub().switchToWindow(request));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("SwitchToWindow failed: " + response.getErrorMessage());
        }
    }

    // ================================================================
    // Screenshot
    // ================================================================

    /**
     * Take a screenshot.
     *
     * @return PNG image bytes
     */
    public byte[] takeScreenshot(String sessionId) {
        ScreenshotResponse response = executeWithRetry("TakeScreenshot", () ->
                getStub().takeScreenshot(sessionRequest(sessionId)));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("TakeScreenshot failed: " + response.getErrorMessage());
        }
        return response.getScreenshotData().toByteArray();
    }

    // ================================================================
    // Mouse / Keyboard Actions
    // ================================================================

    public void mouseHover(String sessionId, String elementId) {
        executeElementAction("MouseHover", sessionId, elementId,
                stub -> stub.mouseHover(elementAction(sessionId, elementId)));
    }

    public void doubleClick(String sessionId, String elementId) {
        executeElementAction("DoubleClick", sessionId, elementId,
                stub -> stub.doubleClick(elementAction(sessionId, elementId)));
    }

    public void rightClick(String sessionId, String elementId) {
        executeElementAction("RightClick", sessionId, elementId,
                stub -> stub.rightClick(elementAction(sessionId, elementId)));
    }

    /**
     * Press key codes.
     *
     * @param keyCodes  Java KeyEvent VK_ codes
     * @param elementId optional target element (empty for global)
     */
    public void pressKeys(String sessionId, List<Integer> keyCodes, String elementId) {
        PressKeysRequest.Builder builder = PressKeysRequest.newBuilder()
                .setSessionId(sessionId)
                .addAllKeyCodes(keyCodes);

        if (elementId != null && !elementId.isEmpty()) {
            builder.setElementId(elementId);
        }

        ActionResponse response = executeWithRetry("PressKeys", () ->
                getStub().pressKeys(builder.build()));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("PressKeys failed: " + response.getErrorMessage());
        }
    }

    // ================================================================
    // ComboBox / List
    // ================================================================

    /**
     * Select an item in a combo box by value.
     */
    public void selectComboBoxItem(String sessionId, String elementId, String value) {
        SelectItemRequest request = SelectItemRequest.newBuilder()
                .setSessionId(sessionId)
                .setElementId(elementId)
                .setValue(value)
                .build();

        ActionResponse response = executeWithRetry("SelectComboBoxItem", () ->
                getStub().selectComboBoxItem(request));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("SelectComboBoxItem failed: " + response.getErrorMessage());
        }
    }

    /**
     * Select a list item by index or value.
     *
     * @param index use -1 to select by value instead
     * @param value use empty string to select by index instead
     */
    public void selectListItem(String sessionId, String elementId, int index, String value) {
        SelectListItemRequest.Builder builder = SelectListItemRequest.newBuilder()
                .setSessionId(sessionId)
                .setElementId(elementId);

        if (index >= 0) {
            builder.setIndex(index);
        }
        if (value != null && !value.isEmpty()) {
            builder.setValue(value);
        }

        ActionResponse response = executeWithRetry("SelectListItem", () ->
                getStub().selectListItem(builder.build()));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("SelectListItem failed: " + response.getErrorMessage());
        }
    }

    // ================================================================
    // Popup / Dialog Handling
    // ================================================================

    /**
     * Dismiss a popup by clicking a button identified by name or AutomationId.
     *
     * @param sessionId      the session ID
     * @param buttonName     button text to click (e.g. "OK", "Yes")
     * @param buttonAutoId   or button AutomationId
     * @param timeoutSeconds how long to wait for the popup
     */
    public void dismissPopup(String sessionId, String buttonName, String buttonAutoId, int timeoutSeconds) {
        DismissPopupRequest.Builder builder = DismissPopupRequest.newBuilder()
                .setSessionId(sessionId)
                .setTimeoutSeconds(timeoutSeconds);

        if (buttonName != null && !buttonName.isEmpty()) {
            builder.setButtonName(buttonName);
        }
        if (buttonAutoId != null && !buttonAutoId.isEmpty()) {
            builder.setButtonAutoId(buttonAutoId);
        }

        ActionResponse response = executeWithRetry("DismissPopup", () ->
                getStub().dismissPopup(builder.build()));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("DismissPopup failed: " + response.getErrorMessage());
        }
        logger.info("Popup dismissed (button: '{}' / autoId: '{}')", buttonName, buttonAutoId);
    }

    /**
     * Handle a popup by matching title and clicking an action button.
     *
     * @param sessionId      the session ID
     * @param expectedTitle  optional popup title to match
     * @param actionButton   button text to click in the popup
     * @param timeoutSeconds how long to wait for the popup
     * @return response with popup details and whether action was taken
     */
    public HandlePopupResponse handlePopup(String sessionId, String expectedTitle,
                                           String actionButton, int timeoutSeconds) {
        HandlePopupRequest.Builder builder = HandlePopupRequest.newBuilder()
                .setSessionId(sessionId)
                .setTimeoutSeconds(timeoutSeconds);

        if (expectedTitle != null && !expectedTitle.isEmpty()) {
            builder.setExpectedTitle(expectedTitle);
        }
        if (actionButton != null && !actionButton.isEmpty()) {
            builder.setActionButton(actionButton);
        }

        HandlePopupResponse response = executeWithRetry("HandlePopup", () ->
                getStub().handlePopup(builder.build()));

        logger.info("HandlePopup result: found={}, title='{}', actionTaken={}",
                response.getPopupFound(), response.getPopupTitle(), response.getActionTaken());
        return response;
    }

    // ================================================================
    // Drag & Drop
    // ================================================================

    /**
     * Click and drag from source element to target element.
     *
     * @param sessionId       the session ID
     * @param sourceElementId element to drag from
     * @param targetElementId element to drag to
     */
    public void clickAndDrag(String sessionId, String sourceElementId, String targetElementId) {
        ClickAndDragRequest request = ClickAndDragRequest.newBuilder()
                .setSessionId(sessionId)
                .setSourceElementId(sourceElementId)
                .setTargetElementId(targetElementId)
                .build();

        ActionResponse response = executeWithRetry("ClickAndDrag", () ->
                getStub().clickAndDrag(request));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("ClickAndDrag failed: " + response.getErrorMessage());
        }
        logger.info("Dragged element '{}' to '{}'", sourceElementId, targetElementId);
    }

    // ================================================================
    // Window Focus
    // ================================================================

    /**
     * Force-focus a window by partial title match.
     * Uses the Win32 ForceForeground trick on the server side.
     *
     * @param sessionId   the session ID
     * @param windowTitle partial window title to match
     */
    public void focusWindow(String sessionId, String windowTitle) {
        FocusWindowRequest request = FocusWindowRequest.newBuilder()
                .setSessionId(sessionId)
                .setWindowTitle(windowTitle)
                .build();

        ActionResponse response = executeWithRetry("FocusWindow", () ->
                getStub().focusWindow(request));

        if (!response.getSuccess()) {
            throw new GrpcDriverException("FocusWindow failed: " + response.getErrorMessage());
        }
        logger.info("Focused window: '{}'", windowTitle);
    }

    // ================================================================
    // Health Check
    // ================================================================

    /**
     * Ping the server.
     *
     * @return true if server is alive
     */
    public boolean ping() {
        return channelManager.ping();
    }

    /**
     * Shut down the gRPC channel.
     */
    public void shutdown() {
        channelManager.shutdown();
    }

    // ================================================================
    // Internal Helpers
    // ================================================================

    private FlaUIAutomationServiceGrpc.FlaUIAutomationServiceBlockingStub getStub() {
        return channelManager.getBlockingStub();
    }

    /** Build an ElementActionRequest (reused by click, clear, getText, etc.) */
    private ElementActionRequest elementAction(String sessionId, String elementId) {
        return ElementActionRequest.newBuilder()
                .setSessionId(sessionId)
                .setElementId(elementId)
                .build();
    }

    /** Build a SessionRequest (reused by getWindowHandle, takeScreenshot, etc.) */
    private SessionRequest sessionRequest(String sessionId) {
        return SessionRequest.newBuilder()
                .setSessionId(sessionId)
                .build();
    }

    /** Execute an element action RPC that returns ActionResponse. */
    private void executeElementAction(String rpcName, String sessionId, String elementId,
                                      StubCall<ActionResponse> call) {
        ActionResponse response = executeWithRetry(rpcName, () -> call.execute(getStub()));

        if (!response.getSuccess()) {
            String msg = response.getErrorMessage();
            if (msg != null && msg.contains("Connexus Application Error")) {
                throw new AssertionError("[CAE] " + msg);
            }
            throw new GrpcDriverException(rpcName + " failed on element '" + elementId
                    + "': " + msg);
        }
    }

    /** Execute a boolean state RPC (isDisplayed, isEnabled, isSelected). */
    private boolean executeBoolAction(String rpcName, String sessionId, String elementId,
                                      StubCall<BoolResponse> call) {
        BoolResponse response = executeWithRetry(rpcName, () -> call.execute(getStub()));

        if (!response.getSuccess()) {
            logger.warn("{} check failed on element '{}': {}", rpcName, elementId, response.getErrorMessage());
            return false;
        }
        return response.getResult();
    }

    /**
     * Execute an RPC call with retry logic.
     *
     * @param rpcName   name for logging
     * @param rpcCall   the actual RPC invocation
     * @param <T>       response type
     * @return the RPC response
     * @throws GrpcDriverException if all retries fail
     */
    private <T> T executeWithRetry(String rpcName, RpcCall<T> rpcCall) {
        int maxRetries = config.getMaxRetries();
        int retryDelay = config.getRetryDelayMs();

        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                return rpcCall.execute();
            } catch (StatusRuntimeException e) {
                logger.warn("RPC '{}' attempt {}/{} failed: {}",
                        rpcName, attempt, maxRetries, e.getStatus());

                if (attempt == maxRetries) {
                    throw new GrpcDriverException(
                            "RPC '" + rpcName + "' failed after " + maxRetries + " attempts: " + e.getStatus(), e);
                }

                sleep(retryDelay);
            }
        }

        // Unreachable, but compiler needs it
        throw new GrpcDriverException("RPC '" + rpcName + "' failed unexpectedly.");
    }

    private void sleep(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    // ================================================================
    // Functional Interfaces for RPC Calls
    // ================================================================

    @FunctionalInterface
    private interface RpcCall<T> {
        T execute();
    }

    @FunctionalInterface
    private interface StubCall<T> {
        T execute(FlaUIAutomationServiceGrpc.FlaUIAutomationServiceBlockingStub stub);
    }
}
