package hwqe.baseframework.curbsideDispense;

import hwqe.baseframework.interfaces.IAndroidApp;
import hwqe.baseframework.interfaces.IMobileApp;
import hwqe.baseframework.utilities.PropertyReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class CurbsideManager implements IAndroidApp {
    AndroidDriver driver;
    PropertyReader rdr = PropertyReader.getInstance();
    URL url = new URL("http://127.0.0.1:4723/wd/hub");

    public CurbsideManager() throws MalformedURLException {
    }

    @Override
    public AndroidDriver getDriver() {
        return driver;
    }

    @Override
    public boolean launchMobileApp() {
        try {
            String apkFilePath = "C:\\Users\\n0v01bo\\Downloads\\latest.apk";

            DesiredCapabilities cap = new DesiredCapabilities();
            cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Device");
            cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 5000);
            cap.setCapability(MobileCapabilityType.APP, apkFilePath);
            driver = new AndroidDriver(url, cap);
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            return true;

        } catch (
                Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    @Override
    public String takeScreenShot(String fileName) {
        try {
            Random r = new Random();
            File savedFile = new File(rdr.getProperty("app.workingfolder_path") + fileName + "_" + r.nextInt(9999) + ".png");
            FileUtils.copyFile(this.driver.getScreenshotAs(OutputType.FILE), savedFile);
            return savedFile.getPath();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean closeMobileApp() {
        return false;
    }

    @Override
    public void switchWindow() {

    }


}
