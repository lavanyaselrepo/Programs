package hwqe.baseframework.blobcontext;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.blob.models.BlobHttpHeaders;
import com.azure.storage.blob.models.BlobItem;
import com.azure.storage.blob.models.ListBlobsOptions;
import com.azure.storage.blob.sas.BlobContainerSasPermission;
import com.azure.storage.blob.sas.BlobServiceSasSignatureValues;
import hwqe.baseframework.utilities.FileUtils;
import org.apache.commons.io.IOUtils;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

public class AzureBlobClient {
    private BlobServiceClient service;
    private BlobContainerClient container;
    private String connectionString;
    private String containerName;

    public AzureBlobClient(String connectionString, String containerName) {
        this.connectionString = connectionString;
        this.containerName = containerName;
    }

    public boolean connect() {
        try {
            service = new BlobServiceClientBuilder().connectionString(this.connectionString).buildClient();
            container = service.getBlobContainerClient(this.containerName);
            return true;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return false;
    }

    public List<String> listBlobs(int limit) {
        List<String> retVal = new ArrayList<>();
        int counter = 0;
        for (BlobItem blobItem : container.listBlobs()) {
            retVal.add(blobItem.getName());
            counter++;
            if (counter >= limit) {
                break;
            }
        }
        return retVal;
    }

    public List<String> listBlobs(String prefix, int limit) {
        List<String> retVal = new ArrayList<>();
        ListBlobsOptions options = new ListBlobsOptions();
        options.setPrefix(prefix);
        int counter = 0;
        for (BlobItem blobItem : container.listBlobs(options, Duration.ofSeconds(15))) {
            retVal.add(blobItem.getName());
            counter++;
            if (counter >= limit) {
                break;
            }
        }
        return retVal;
    }

    public BlobItem getBlobInfo(String blobName) {
        ListBlobsOptions options = new ListBlobsOptions();
        options.setPrefix(blobName);
        for (BlobItem blobItem : container.listBlobs(options, null)) {
            if (blobItem.getName().equalsIgnoreCase(blobName)) {
                return blobItem;
            }
        }
        return null;
    }

    public boolean doesBlobExist(String blobName) {
        BlobClient blobClient = container.getBlobClient(blobName);
        return blobClient.exists();

    }

    public void deleteBlob(String blobName) {
        BlobClient blobClient = container.getBlobClient(blobName);
        blobClient.delete();
    }

    public boolean downloadBlob(String blobName, String downloadPath) {
        try {
            BlobClient blobClient = container.getBlobClient(blobName);
            blobClient.downloadToFile(downloadPath);
            return true;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return false;
    }

    public String downloadBlob(String blobName) {
        try {
            BlobClient blobClient = container.getBlobClient(blobName);
            InputStream input = blobClient.openInputStream();
            InputStreamReader inr = new InputStreamReader(input);
            return IOUtils.toString(inr);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return "";
    }

    /**
     * Uploads a file to blob storage with a random UUID filename.
     * Each call creates a NEW blob - use uploadBlob(path, blobName, overwrite) for updates.
     */
    public String uploadBlob(String path) {
        String fileName = java.util.UUID.randomUUID() + "." + FileUtils.getFileExtension(path);
        return uploadBlob(path, fileName, false);
    }

    /**
     * Uploads a file to a specific blob path in the container.
     * When blobPathInContainer is null/blank, fallback remains random UUID behavior.
     */
    public String uploadBlob(String localFilePath, String blobPathInContainer) {
        String fileName = (blobPathInContainer != null && !blobPathInContainer.trim().isEmpty())
                ? blobPathInContainer.trim()
                : java.util.UUID.randomUUID() + "." + FileUtils.getFileExtension(localFilePath);
        return uploadBlob(localFilePath, fileName, false);
    }

    /**
     * Uploads a file to blob storage with a specific blob name.
     * If overwrite is true, replaces any existing blob with the same name.
     * 
     * @param path Local file path to upload
     * @param blobName Name to use for the blob (e.g., "my-report.html")
     * @param overwrite If true, overwrites existing blob; if false, fails if blob exists
     * @return The blob URL with SAS token for access
     */
    public String uploadBlob(String path, String blobName, boolean overwrite) {
        if (container == null) {
            throw new IllegalStateException("BlobContainerClient is not initialized. Ensure 'connect()' is called successfully before using this method.");
        }
        BlobClient blobClient = container.getBlobClient(blobName);
        BlobHttpHeaders headers = new BlobHttpHeaders();
        switch (FileUtils.getFileExtension(path)) {
            case "html":
                headers.setContentType("text/html");
                break;
            case "txt":
                headers.setContentType("text/plain");
                break;
            case "json":
                headers.setContentType("application/json");
                break;
            default:
                headers.setContentType("application/octet-stream");
        }
        // Delete existing blob if overwrite is requested
        if (overwrite && blobClient.exists()) {
            blobClient.delete();
        }
        blobClient.uploadFromFile(path, null, headers, null, null, null, null);
        BlobContainerSasPermission permission = new BlobContainerSasPermission();
        permission.setReadPermission(true);
        BlobServiceSasSignatureValues sas = new BlobServiceSasSignatureValues(OffsetDateTime.now().plusMonths(6), permission);
        String base = blobClient.getBlobUrl();
        // SDK may encode hierarchical path slashes as %2F; normalize returned URL for readability.
        int q = base.indexOf('?');
        String pathPart = q >= 0 ? base.substring(0, q) : base;
        String prefixQuery = q >= 0 ? base.substring(q) : "";
        pathPart = pathPart.replace("%2F", "/").replace("%2f", "/");
        String sasQs = blobClient.getBlockBlobClient().generateSas(sas);
        if (prefixQuery.isEmpty()) {
            return pathPart + "?" + sasQs;
        }
        return pathPart + prefixQuery + "&" + sasQs;
    }
}