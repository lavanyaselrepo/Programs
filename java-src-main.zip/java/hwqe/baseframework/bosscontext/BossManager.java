package hwqe.baseframework.bosscontext;

import hwqe.baseframework.interfaces.IBoss;
import hwqe.baseframework.utilities.PropertyReader;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.MobileBy;
import io.appium.java_client.windows.WindowsDriver;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.net.URL;


public class BossManager implements IBoss {
    PropertyReader prop = PropertyReader.getInstance();
    private WindowsDriver windowsDriver = null;

    private String checkSessionExists() {
        try {
            DesiredCapabilities appCapabilities = new DesiredCapabilities();
            appCapabilities.setCapability("app", "Root");
            WindowsDriver desktop = new WindowsDriver(new URL(prop.getProperty("app.winAppServer")), appCapabilities);
            if (!desktop.findElements(AppiumBy.accessibilityId("Shell")).isEmpty()) {
                return Integer.toHexString(Integer.parseInt(desktop.findElement(AppiumBy.accessibilityId("Shell")).getAttribute("NativeWindowHandle"))).toUpperCase();
            }
            /* Not checking for login and warning screens
            *******
            if (desktop.findElements(MobileBy.AccessibilityId("65535")).size() >= 1) {
                return Integer.toHexString(Integer.parseInt(desktop.findElement(MobileBy.AccessibilityId("65535")).getAttribute("NativeWindowHandle"))).toUpperCase();
            }
            if (desktop.findElements(MobileBy.AccessibilityId("chkHOUser")).size() >= 1) {
                return Integer.toHexString(Integer.parseInt(desktop.findElementByName("Connexus © 2000   WAL* MART").getAttribute("NativeWindowHandle"))).toUpperCase();
            }
            */
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    @Override
    public boolean launchBoss() {
        try {
            String sessionExists = checkSessionExists();
            DesiredCapabilities capabilities = new DesiredCapabilities();

            if (sessionExists == null) {
                capabilities.setCapability("app", prop.getProperty("app.bossExecutable"));
            } else {
                capabilities.setCapability("appTopLevelWindow", sessionExists);
            }
            windowsDriver = new WindowsDriver(new URL(prop.getProperty("app.winAppServer")), capabilities);
            System.out.println("loaded windows driver");
            Thread.sleep(3000);
            this.switchWindow();
            /*if (windowsDriver.findElements(By.name("_OK")).size() > 0) {
                windowsDriver.findElement(By.name("_OK")).click();
                this.switchWindow();
            }*/
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    @Override
    public boolean closeBoss() {
        if (!windowsDriver.equals(null)) {
            windowsDriver.closeApp();
            return true;
        }
        return false;
    }


    @Override
    public WindowsDriver getDriver() {
        return this.windowsDriver;
    }

    @Override
    public void switchWindow() {
        String winHandleBefore = windowsDriver.getWindowHandle();
        for (String winHandle : windowsDriver.getWindowHandles()) {
            if (!winHandle.equals(winHandleBefore)) {
                windowsDriver.switchTo().window(winHandle);
            }
        }
    }

    @Override
    public String takeScreenShot() {
        try {
            File savedFile = new File(prop.getProperty("app.workingfolder_path") + java.util.UUID.randomUUID() + ".png");
            FileUtils.copyFile(this.windowsDriver.getScreenshotAs(OutputType.FILE), savedFile);
            return savedFile.getPath();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

}
