package hwqe.baseframework.bosscontext;

public enum SearchType {
    Patient("Patient"),
    Provider("Provider"),
    Order("Order ID"),
    Tray("Tray Number"),
    Insurance("Insurance"),
    Frame("Frame"),
    Lens("Lens"),
    ContactLens("Contact Lens"),
    AddOns("Add-ons");
    private String searchType;

    SearchType(String type) {
        this.searchType = type;
    }

    public String getSearchType() {
        return searchType;
    }
}
