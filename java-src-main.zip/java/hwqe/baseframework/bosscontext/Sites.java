package hwqe.baseframework.bosscontext;

public enum Sites {
    US("US"), CA("CA");
    private String site;

    Sites(String type) {
        this.site = type;
    }

    public String getSite() {
        return site;
    }
}
