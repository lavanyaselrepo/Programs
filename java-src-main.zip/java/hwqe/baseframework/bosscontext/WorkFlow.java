package hwqe.baseframework.bosscontext;

import hwqe.baseframework.models.pageobjectmodels.WindowsBasePage;
import hwqe.baseframework.models.pageobjectmodels.boss.Login;

public class WorkFlow extends WindowsBasePage {
    private BossManager bossManager;

    public WorkFlow(BossManager bossManager) {
        super(bossManager.getDriver());
        this.bossManager = bossManager;
    }

    public boolean performLogin(String username, String password) {
        Login l = new Login();
        return l.performLoginForHO(username, password);
    }
}
