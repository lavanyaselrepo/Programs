package hwqe.baseframework.digitalPharmacyapicontext;

import com.google.gson.*;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.PrescriptionsLookupFilterOptions;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.PrescriptionsLookupRequest;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.PrescriptionsLookupResponse;
import com.walmart.pharmacy.dp.rx.orchestrator.restclient.model.PrescriptionsLookupSortOptions;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.enums.PatientType;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.GsonLocalDateAdapter;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.astro.CreatePharmacyAccount;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.astro.CustomerAccount;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.astro.MoveRx;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.astro.PostalAddressModel;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.ca.*;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.cpr.CentralPatientSearchRequest;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.dpaccentity.CustomerInfo;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.dpaccentity.CustomerInfoRequestPayload;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.dpaccentity.PharmacyAccountLinkDPPayload;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.dpaccentity.SmsOtpAuthBypassPayload;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.iam.AuthCredentialsPayload;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.iam.IamGenerateSecondaryAuthRequest;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.phamacyqaservices.ClearCacheModel;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.phamacyqaservices.PharmacyqaservicesMainPayload;
import hwqe.baseframework.digitalPharmacyapicontext.datamodels.pyxis.*;
import hwqe.baseframework.digitalPharmacyapicontext.utils.SignGen;
import hwqe.baseframework.signaturegenerator.SignatureGenerator;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.apache.commons.lang.RandomStringUtils;
import org.eclipse.jetty.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.openjdk.tools.sjavac.Log;
import org.testng.asserts.SoftAssert;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.*;

import static hwqe.baseframework.utilities.FileUtils.readFileToString;

public class DigitalPharmacyAPIManager {
    private AutomationManager am = AutomationManager.getInstance();
    private PropertyReader prop = PropertyReader.getInstance();
    private PropertyReader vaultKeys = PropertyReader.getInstance();
    private DocumentContext jsonDoc;
    private String firstName, todayDate, inputPickupDate, inputRxExpDate;
    private int patientId;
    private ConnexusAPIManager connexusAPIManager = new ConnexusAPIManager();
    private SoftAssert softAssert = new SoftAssert();

    public DigitalPharmacyAPIManager() {
        prop.loadCustomProperties("config/sharedconfigproperties/");
    }


    /*
    ISAC flow to Create a Pharmacy connected Account
    Create a store Patient Account - Use Wrapper Add Patient API
    Use CPR’s Patient Central Search API to get PatientID / Use the Wrapper Get Patient API

    Create a new Walmart online account via www-e16.walmart.com or www-teflon.walmart.com - Uses Astro API

    Use CA API to get the customerID by emailID - this is the cid

    ISAC steps:
     - Use ISAC /createOnlineAccount to create an online Walmart account. Get the STG id
     - In the request payload, no need to change any values for the field "photoId". Leave as it is.
     - Use ISAC /createPharmacyAccount to link the online acc with Pharmacy account

     - Go to www-e16.walmart.com/pharmacy/dashboard web and set the PIN
     */
    public ServiceResponse createDotComAccount(String email, String password, String phoneNumber, String firstName, String lastName) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        CustomerAccount newDotComAccount = new CustomerAccount();
        newDotComAccount.setEmailAddress(email);
        newDotComAccount.setPassword(password);
        newDotComAccount.setFirstName(firstName);
        newDotComAccount.setLastName(lastName);
        List<String> pm = new ArrayList<>();
        pm.add("VISA");
        newDotComAccount.setPaymentMethods(pm);
        newDotComAccount.setPhoneNumber(phoneNumber);
        PostalAddressModel postalAddress = new PostalAddressModel();
        postalAddress.setAddress("2730 E McKellips Rd");
        postalAddress.setCity("Mesa");
        postalAddress.setState("AZ");
        postalAddress.setCountry("USA");
        postalAddress.setPostalCode("85213");
        newDotComAccount.setPostalAddress(postalAddress);
        req.setRequestPayloadWithNulls(newDotComAccount);
        req.setUrl(prop.getProperty("astro.service.base.url"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("dotCom Acc Creation Request endpoint: " + req.getUrl());
        Reporter.logJSON("dotCom Acc Creation Request", req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("DotCom Account Creation API Response", resp.getDataResponse());
        return resp;
    }

    public ServiceResponse createPharmacyAccount_Astro(String email, String pwd,String firstName, String lastName, String pin, String siteId, String dob, boolean hasInsurance, Object insuranceType) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        CreatePharmacyAccount createPharmacyAccount = CreatePharmacyAccount.builder().firstName(firstName).lastName(lastName)
                .pin(pin).password(pwd).siteId(siteId).dateOfBirth(dob).hasInsurance(hasInsurance).insuranceType(insuranceType).build();
        req.setRequestPayloadWithNulls(createPharmacyAccount);
        req.setUrl(prop.getProperty("astro.service.base.url.create.pharmacy.account.url").replace("{mailId}",email));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("Pharmacy Acc Creation Request endpoint: " + req.getUrl());
        Reporter.logJSON("Pharmacy Acc Creation Request", req.getRequestPayload());
        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("DotCom Account Creation API Response", resp.getDataResponse());
        return resp;
    }

    public String getOTPForEmail(String emailId) {
        String otp = null;
        try {
            HashMap<String, String> headers = new HashMap<>();
            ServiceRequest req = new ServiceRequest();
            ServiceResponse resp = new ServiceResponse();
            headers.put("content-type", "application/json");
            headers.put("accept", "application/json");
            req.setUrl(prop.getProperty("astro.base.service") + "v3/teflon/customer/" + emailId + "/otp");
            req.setHeaders(headers);
            resp = am.getRestContext().performGet(req);
            Reporter.log("Response For OTP Email: " + resp.getDataResponse());
            otp = resp.getJsonElement("astroDetails.passcode");
        } catch (Exception e) {
            Reporter.log("Exception while getting OTP from email API :: " + e);
        }
        return otp;
    }


    public String getOTPForPhone(String emailId, String phoneNo) {

        am.performSleep(15);
        String otp = null;
        try {
            HashMap<String, String> headers = new HashMap<>();
            ServiceRequest req = new ServiceRequest();
            ServiceResponse resp = new ServiceResponse();
            headers.put("content-type", "application/json");
            headers.put("accept", "application/json");
            req.setUrl(prop.getProperty("astro.base.service") + "v2/teflon/customer/" + emailId + "/otp?phone=1" + phoneNo);
            req.setHeaders(headers);
            resp = am.getRestContext().performGet(req);
            Reporter.log("Response For OTP Phone: " + resp.getDataResponse());
            otp = resp.getJsonElement("astroDetails.passcode");
        } catch (Exception e) {
            Reporter.log("Exception while getting OTP from phone API :: " + e);
        }
        return otp;
    }

    public void unlinkPharmacyAccount(String email) {
        String cId = getCidFromEmail(email);
        String secAuthToken = generateSecondaryAuth(email, "Test@1234");
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        headers.clear();
        headers.put("content-type", "application/json");
        headers.put("WM_CONSUMER.ID", prop.getProperty("pyxis.prescription.wm.consumer.id"));
        headers.put("WM_QOS.CORRELATION_ID", prop.getProperty("pyxis.wm.qos.correlation.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("pyxis.wm.svc.name"));
        headers.put("WM_SVC.version", prop.getProperty("pyxis.wm.svc.version"));
        headers.put("WM_SVC.ENV", prop.getProperty("pyxis.wm.svc.env"));
        headers.put("WM_SEC.KEY_VERSION", prop.getProperty("pyxis.wm.sec.key.version"));
        headers.put("TENANT_ID", prop.getProperty("pyxis.tenant.id"));
        headers.put("SourceId", prop.getProperty("pyxis.src.id"));
        headers.put("WM_SEC.AUTH_TOKEN", secAuthToken);
        headers.put("appId", "1234");
        req.setUrl(prop.getProperty("pharm.customer.service.base.url") + cId);
        req.setHeaders(headers);
        resp = am.getRestContext().performDelete(req);
        Reporter.log("Response For unLink Pharmacy: " + resp.getDataResponse());
        String status = resp.getJsonElement("status");
        Assert.assertEquals(status, "OK", "Unlink pharmacy account failed");
    }


    public ServiceResponse signUpAPI(String email, String password, String firstName, String lastName) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        PersonName personName = new PersonName();
        personName.setLastName(lastName);
        personName.setFirstName(firstName);
        Names name = new Names();
        name.setPersonName(personName);
        List<Names> names = new ArrayList<>();
        names.add(name);
        Accounts account = new Accounts();
        account.setEmailAddress(email);
        List<Accounts> accounts = new ArrayList<>();
        accounts.add(account);
        Person person = new Person();
        person.setAccounts(accounts);
        person.setNames(names);
        Payload payload = new Payload();
        payload.setPassword(password);
        payload.setPerson(person);

        CaSignUpRequestModel caSignUpRequestModel = new CaSignUpRequestModel();

        caSignUpRequestModel.setPayload(payload);

        req.setRequestPayloadWithNulls(caSignUpRequestModel);
        req.setUrl(prop.getProperty("ca.service.sign.up.url"));
        headers.put("content-type", "application/json");
        headers.put("WM_CONSUMER.ID", prop.getProperty("ca.service.consent.wm.consumer.id"));
        headers.put("WM_QOS.CORRELATION_ID", prop.getProperty("ca.service.consent.wm.qos.correlation.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("ca.service.consent.wm.svc.name"));
        headers.put("WM_SVC.version", prop.getProperty("ca.service.consent.wm.svc.version"));
        headers.put("WM_SVC.ENV", prop.getProperty("ca.service.consent.wm.svc.env"));
        headers.put("Cookie", prop.getProperty("ca.cookie"));

        req.setHeaders(headers);
        Reporter.log("signUp api Request endpoint: " + req.getUrl());
        Reporter.logJSON("signUp API Creation Request", req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("signUp API Response", resp.getDataResponse());
        return resp;
    }

    public String getCidFromEmail(String email) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        headers.clear();
        headers.put("wm_consumer.id", prop.getProperty("ca.service.wm.consumer.id"));
        headers.put("content-type", "application/json");
        headers.put("wm_qos.correlation_id", prop.getProperty("ca.service.wm.qos.correlation.id"));
        headers.put("wm_svc.env", prop.getProperty("ca.service.wm.svc.env"));
        headers.put("wm_svc.name", prop.getProperty("ca.service.wm.svc.name"));
        headers.put("wm_svc.version", prop.getProperty("ca.service.wm.svc.version"));
        req.setHeaders(headers);
        req.setUrl(prop.getProperty("ca.service.base.url") + "/ca-app/services/customers/emails/" + email);
        String cid = "";
        resp = am.getRestContext().performGet(req);
        try{
            Assert.assertEquals(resp.getStatusCode(), HttpStatus.OK_200, "CA API to Get CID By Email Failed, Please Check");
            cid = resp.getJsonElement("payload.persons[0].accounts[0].customerAccountId");
            Reporter.log("CID For Email: " + email + " is : '" + cid + "'");
        } catch (Exception e){
            e.printStackTrace();
            Assert.fail("API call to CA failed to get cid by email, returning blank cid, please report the issue or check your data");
        }
        return cid;
    }


    public String getCidFromEmailUsingAstro(String email) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        headers.clear();
        headers.put("Accept", "*/*");
        headers.put("temp","true");
        headers.put("tenant-id","elh9ie");
        req.setHeaders(headers);
        req.setUrl(prop.getProperty("ca.astro.base.url") + "/api/v2/teflon/customer/" + email);
        String cid = "";
        resp = am.getRestContext().performGet(req);
        try{
            Assert.assertEquals(resp.getStatusCode(), HttpStatus.OK_200, "CA API to Get CID By Email Failed, Please Check");
            cid = resp.getJsonElement("astroDetails.customerDetails.customerAccountId");
            Reporter.log("CID For Email: " + email + " is : '" + cid + "'");
        } catch (Exception e){
            e.printStackTrace();
            Assert.fail("API call to CA failed to get cid by email, returning blank cid, please report the issue or check your data");
        }
        return cid;
    }

    public int getStorePatientIdFromCPR(String firstName, String lastName, String dob, String storeNumber) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        headers.clear();
        headers.put("Authorization", vaultKeys.getProperty("cpr.static.auth"));
        headers.put("WM_SVC.NAME", prop.getProperty("cpr.wm.svc.name"));
        headers.put("WM_SVC.ENV", prop.getProperty("cpr.wm.svc.env"));
        headers.put("WM_CONSUMER.ID", prop.getProperty("cpr.wm.consumer.id"));
        headers.put("content-type", "application/json");
        req.setUrl(prop.getProperty("cpr.base.url") + "patient/centralSearch");
        req.setHeaders(headers);
        CentralPatientSearchRequest cprreq = new CentralPatientSearchRequest();
        cprreq.setStoreNbr(storeNumber);
        cprreq.setFirstName(firstName);
        cprreq.setLastName(lastName);
        cprreq.setBirthDate(dob);
        req.setRequestPayload(cprreq);
        Reporter.logJSON("CPR Get PatientID request Payload: ", req.getRequestPayload());
        Log.info("CPR Get PatientID Request Payload: " + req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("CPR Get PatientID Response Payload: ", resp.getDataResponse());
        try{
            patientId = resp.getJsonElement("patients[0].patientId");
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.log("CPR API Call Failed");
        }
        Reporter.log("patientId=" + patientId);
        return patientId;
    }

    public String generateSecondaryAuth(String email, String password) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        headers.clear();
        headers.put("WM_CONSUMER.ID", prop.getProperty("iam.auth.token.generation.wm.consumer.id"));
        headers.put("WM_QOS.CORRELATION_ID", prop.getProperty("iam.auth.token.generation.wm.qos.correlation.id"));
        headers.put("WM_SVC.ENV", prop.getProperty("iam.auth.token.generation.wm.svc.env"));
        headers.put("WM_SVC.VERSION", prop.getProperty("iam.auth.token.generation.wm.svc.version"));
        headers.put("WM_SVC.NAME", prop.getProperty("iam.auth.token.generation.wm.svc.name"));
        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/json");
        req.setHeaders(headers);
        req.setUrl(prop.getProperty("iam.auth.token.generation.base.url") + "authnService");
        IamGenerateSecondaryAuthRequest iamRequest = new IamGenerateSecondaryAuthRequest();
        AuthCredentialsPayload credentialsPayload = new AuthCredentialsPayload();
        credentialsPayload.setUserId(email);
        credentialsPayload.setPassword(password);
        iamRequest.setPayload(credentialsPayload);
        req.setRequestPayload(iamRequest);
        resp = am.getRestContext().performPost(req);
        String secondaryAuthToken = resp.getJsonElement("payload.authenticationToken.authToken");
        Reporter.log("secondaryAuthToken: " + secondaryAuthToken);
        return secondaryAuthToken;
    }

    public String createIsacNewOnlineAccount(String email, String dob, String firstName, String lastName, String storeNumber, int storePatientId, String secAuthToken) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        headers.clear();
        headers.put("SourceId", prop.getProperty("pyxis.src.id"));
        headers.put("TENANT_ID", prop.getProperty("pyxis.tenant.id"));
        headers.put("WM_CONSUMER.ID", prop.getProperty("pyxis.wm.consumer.id"));
        headers.put("WM_CONSUMER.INTIMESTAMP", prop.getProperty("pyxis.wm.consumer.intimestamp"));
        headers.put("WM_QOS.CORRELATION_ID", prop.getProperty("pyxis.wm.qos.correlation.id"));
        headers.put("WM_SEC.AUTH_TOKEN", secAuthToken);
        headers.put("WM_SEC.KEY_VERSION", prop.getProperty("pyxis.wm.sec.key.version"));
        headers.put("WM_SVC.ENV", prop.getProperty("pyxis.wm.svc.env"));
        headers.put("WM_SVC.NAME", prop.getProperty("pyxis.wm.svc.name"));
        headers.put("WM_SVC.VERSION", prop.getProperty("pyxis.wm.svc.version"));
        headers.put("ACCEPT", "application/json");
        headers.put("Content-Type", "application/json");
        headers.put("cache-control", "no-cache,no-cache,no-cache");
        req.setHeaders(headers);
        req.setUrl(prop.getProperty("pyxis.base.url") + "v3/pharmacy/inStore/createOnlineAccount");
        AddressModel address = new AddressModel();
        InStoreOnlineAccountPayload inStoreOnlineAccountPayload = new InStoreOnlineAccountPayload();
        PhotoIdModel photoIdModel = new PhotoIdModel();
        CreateOnlineAccountRequest mainpayload = new CreateOnlineAccountRequest();
        StoreId storeId = new StoreId();
        storeId.setUSStoreId(storeNumber);
        photoIdModel.setPhotoIdType("DRV");
        photoIdModel.setPhotoIdNumber("90808567456567");
        photoIdModel.setPhotoIdState("CA");
        photoIdModel.setPhotoIdCountry("US");
        photoIdModel.setPhotoIdExpirationDate("06-22-2027");
        address.setAddressLineOne("805 Moberly ln");
        address.setAddressLineTwo("");
        address.setCity("Bentonville");
        address.setCountryCode("US");
        address.setPostalCode("72716");
        inStoreOnlineAccountPayload.setCustomerDOB(dob);
        inStoreOnlineAccountPayload.setFirstName(firstName);
        inStoreOnlineAccountPayload.setLastName(lastName);
        inStoreOnlineAccountPayload.setCustomerEmailId(email);
        inStoreOnlineAccountPayload.setStorePatientId(String.valueOf(storePatientId));
        inStoreOnlineAccountPayload.setStoreNumber(storeId);
        inStoreOnlineAccountPayload.setPostalAddress(address);
        inStoreOnlineAccountPayload.setPhotoId(photoIdModel);
        mainpayload.setPayload(inStoreOnlineAccountPayload);
        req.setRequestPayload(mainpayload);
        Reporter.logJSON("CreateIssacOnlineAccount Req Payload: ", req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("CreateIssacOnlineAccount resp Payload: ", resp.getDataResponse());
        String stgId = resp.getJsonElement("payload.stgId");
        Reporter.log("stgId: " + stgId);
        System.out.println("ISAC Account Service Response: " + resp.getDataResponse());
        //{"status":"OK","payload":{"entityErrors":[],"customerEmailId":"testacchw@walmart.com","stgId":"b1cf4e78-036e-4633-9f4a-0fa4adce97c9"}}
        return stgId;
    }

    public void createPharmacyAccount(String cid, String secAuthToken, String stgId, String dob) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        CreatePharmacyAccountRequest mainPayload = new CreatePharmacyAccountRequest();
        PharmacyAccountLinkPayload payload = new PharmacyAccountLinkPayload();
        payload.setStgId(stgId);
        payload.setCustomerAccountId(cid);
        payload.setCustomerDOB(dob);
        payload.setTAndCPolicyLanguage("EN");
        mainPayload.setPayload(payload);
        req.setRequestPayload(mainPayload);
        headers.clear();
        headers.put("SourceId", prop.getProperty("pyxis.src.id"));
        headers.put("TENANT_ID", prop.getProperty("pyxis.tenant.id"));
        headers.put("WM_CONSUMER.ID", prop.getProperty("pyxis.wm.consumer.id"));
        headers.put("WM_CONSUMER.INTIMESTAMP", prop.getProperty("pyxis.wm.consumer.intimestamp"));
        headers.put("WM_QOS.CORRELATION_ID", prop.getProperty("pyxis.wm.qos.correlation.id"));
        headers.put("WM_SEC.AUTH_TOKEN", secAuthToken);
        headers.put("WM_SEC.KEY_VERSION", prop.getProperty("pyxis.wm.sec.key.version"));
        headers.put("WM_SVC.ENV", prop.getProperty("pyxis.wm.svc.env"));
        headers.put("WM_SVC.NAME", prop.getProperty("pyxis.wm.svc.name"));
        headers.put("WM_SVC.VERSION", prop.getProperty("pyxis.wm.svc.version"));
        headers.put("ACCEPT", "application/json");
        headers.put("Content-Type", "application/json");
        headers.put("cache-control", "no-cache");
        req.setHeaders(headers);
        req.setUrl(prop.getProperty("pyxis.base.url") + "v3/pharmacy/inStore/createPharmacyAccount");
        resp = am.getRestContext().performPost(req);
        System.out.println("Create Pharmacy Account Response: " + resp.getDataResponse());
    }


    public boolean clearAccountsCache(String[] cids) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        headers.clear();
        headers.put("WM_CONSUMER.ID", prop.getProperty("pharm.customer.service.wm.consumer.id"));
        headers.put("WM_QOS.CORRELATION_ID", prop.getProperty("pharm.customer.service.wm.qos.correlation.id"));
        headers.put("WM_SVC.ENV", prop.getProperty("pharm.customer.service.wm.svc.env"));
        headers.put("WM_SVC.VERSION", prop.getProperty("pharm.customer.service.wm.svc.version"));
        headers.put("WM_SVC.NAME", prop.getProperty("pharm.customer.service.wm.svc.name"));
        headers.put("TENANT_ID", prop.getProperty("pharm.customer.service.tenant.id"));
        headers.put("sourceid", prop.getProperty("pharm.customer.service.sourceid"));
        headers.put("WM_CONSUMER.INTIMESTAMP", prop.getProperty("pharm.customer.service.wm.consumer.intimestamp"));
        headers.put("WM_SEC.KEY_VERSION", prop.getProperty("pharm.customer.service.wm.sec.key.version"));
        headers.put("WM_SEC.AUTH_SIGNATURE", prop.getProperty("pharm.customer.service.wm.sec.auth.signature"));
        headers.put("WM_SEC.AUTH_TOKEN", prop.getProperty("pharm.customer.service.wm.sec.auth.token"));
        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/json");
        req.setHeaders(headers);
        req.setUrl(prop.getProperty("pharm.customer.service.base.url") + "clearcache");
        ClearCacheModel clearCacheModelRequestPayload = new ClearCacheModel();
        PharmacyqaservicesMainPayload payload = new PharmacyqaservicesMainPayload();
        payload.setCustomerAccountIds(cids);
        clearCacheModelRequestPayload.setPayload(payload);
        req.setRequestPayload(clearCacheModelRequestPayload);
        resp = am.getRestContext().performPost(req);
        Reporter.log("Cache Clear req endpoint: " + req.getUrl());
        Reporter.logJSON("Cache clear req payload", req.getRequestPayload());
        Reporter.log("Cache clear response status" + resp.getStatusCode());
        if (resp.getStatusCode() == 200) {
            Reporter.logJSON("clear Cache Response", resp.getDataResponse());
            return true;
        } else {
            return false;
        }
    }

    public boolean createPharmacyConnectedAccount(String cid, String storeNbr, String dob, String storePatientId) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        headers.clear();
        SignGen generateSign = new SignGen();
        HashMap<String, String> authSign = generateSign.generateTimeBasedSign(prop.getProperty("dp.acc.entity.service.wm.consumer.id"));
        headers.put("WM_CONSUMER.ID", prop.getProperty("dp.acc.entity.service.wm.consumer.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("dp.acc.entity.service.wm.svc.name"));
        headers.put("WM_SVC.ENV", prop.getProperty("dp.acc.entity.service.wm.svc.env"));
        headers.put("Content-Type", "application/json");
        headers.put("WM_SEC.KEY_VERSION", prop.getProperty("dp.acc.entity.service.wm.sec.key.version"));
        headers.put("WM_CONSUMER.INTIMESTAMP", authSign.get("Intimestamp"));
        headers.put("WM_SEC.AUTH_SIGNATURE", authSign.get("Signature"));
        req.setHeaders(headers);

        req.setUrl(prop.getProperty("dp.acc.entity.service.base.url") + "v1/account/" + cid + "/domain/WM-PHARMACY/patient-id");
        CustomerInfoRequestPayload dpCust = new CustomerInfoRequestPayload();
        dpCust.setDob(dob);
        dpCust.setPatientId(storePatientId);
        dpCust.setStoreNbr(storeNbr);
        SmsOtpAuthBypassPayload accConnPayload = new SmsOtpAuthBypassPayload();
        accConnPayload.setCustomerInfo(dpCust);
        accConnPayload.setAccountCreationSource("smsOtpVerification");
        req.setRequestPayload(accConnPayload);
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("SMS All bypass Connect account: ", resp.getDataResponse());
        return resp.getStatusCode() == 200;
    }

    public ServiceResponse getPrescriptionsList(String cid) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        headers.clear();
        headers.put("SourceId", prop.getProperty("pyxis.src.id"));
        headers.put("TENANT_ID", prop.getProperty("pyxis.tenant.id"));
        headers.put("WM_CONSUMER.ID", prop.getProperty("pyxis.prescription.wm.consumer.id"));
        headers.put("WM_QOS.CORRELATION_ID", prop.getProperty("pyxis.wm.qos.correlation.id"));
        headers.put("WM_SEC.KEY_VERSION", prop.getProperty("pyxis.wm.sec.key.version"));
        headers.put("WM_SVC.ENV", prop.getProperty("pyxis.wm.svc.env"));
        headers.put("WM_SVC.NAME", prop.getProperty("pyxis.wm.svc.name"));
        headers.put("WM_SVC.VERSION", prop.getProperty("pyxis.wm.svc.version"));
        headers.put("ACCEPT", "application/json");
        headers.put("Content-Type", "application/json");
        req.setHeaders(headers);
        req.setUrl(prop.getProperty("pyxis.base.url") + "v1/pharmacy/customers/" + cid + "/prescriptions?getForDependents=true");
        resp = am.getRestContext().performGet(req);
        Reporter.logJSON("GetPrescriptions API Response: ", resp.getDataResponse());
        if (resp.getStatusCode() == 200 && "OK".equals(resp.getJsonElement("status"))) {
            Reporter.log("Successfully Fetched Prescriptions");
        } else {
            Reporter.log("Error Occurred In Fetching Prescriptions");
        }
        return resp;
    }

    public boolean isRxReadyForRefill(String cid, String Rx) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        resp = this.getPrescriptionsList(cid);
        Gson gson = new Gson();
        JsonObject rxListJsonResponse = gson.fromJson(resp.getDataResponse(), JsonObject.class);
        JsonArray rxList = rxListJsonResponse.getAsJsonObject("payload").getAsJsonArray("customerPrescriptions").get(0).getAsJsonObject().getAsJsonArray("prescriptionList");
        for (int i = 0; i < rxList.size(); i++) {
            JsonElement currRx = rxList.get(i);
            if (currRx.getAsJsonObject().get("rxNumber").getAsString().equals(Rx)) {
                if ("PICKED UP".equals(currRx.getAsJsonObject().get("latestFillStatus").getAsString())) {
                    Reporter.log("Rx is Ready for Refill");
                    return true;
                } else {
                    Reporter.log("Rx is Not Ready for Refill");
                    return false;
                }
            } else {
                if (i == rxList.size() - 1) {
                    Reporter.log("RxNumber Not found");
                }
            }
        }
        return false;
    }


    @Test
    public void createPharmacyAccount_DP(String cid, String patientId, String dob) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        PharmacyAccountLinkDPPayload payload = new PharmacyAccountLinkDPPayload();
        CustomerInfo customerInfo = new CustomerInfo();
        customerInfo.setDob(dob);
        customerInfo.setPatientId(patientId);
        payload.setCustomerInfo(customerInfo);

        req.setRequestPayload(payload);
        SignGen generateSign = new SignGen();
        HashMap<String, String> authSign = generateSign.generateTimeBasedSign(prop.getProperty("dp.account.orchestrator.consumer.id"));

        headers.clear();

        headers.put("WM_CONSUMER.ID", prop.getProperty("dp.account.entity.service.consumer.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("dp.account.entity.service.name"));
        headers.put("WM_SVC.ENV", prop.getProperty("dp.account.entity.service.env"));
        headers.put("WM_CONSUMER.INTIMESTAMP", authSign.get("Intimestamp"));
        headers.put("WM_SEC.AUTH_SIGNATURE", authSign.get("Signature"));
        headers.put("WM_SEC.KEY_VERSION", "1");
        headers.put("Content-Type", "application/json");
        headers.put("ACCEPT", "application/json");
        headers.put("cache-control", "no-cache");

        req.setHeaders(headers);
        String url = prop.getProperty("dp.account.entity.service.base.url") + "/v1/account/{cid}/domain/WM-PHARMACY/patient-id";
        url = url.replace("{cid}", cid);
        req.setUrl(url);
        resp = am.getRestContext().performPost(req);
        System.out.println("Create Pharmacy Account Response: " + resp.getDataResponse());
    }

    @Test
    public void createPharmacyAccount_DPStg(String cid, String patientId, String dob, String storeNo) {
        Reporter.log("createPharmacyAccount_DPStg started");
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();

        PharmacyAccountLinkDPPayload payload = new PharmacyAccountLinkDPPayload();
        CustomerInfo customerInfo = new CustomerInfo();
        customerInfo.setDob(dob);
        customerInfo.setStoreNbr(storeNo);
        customerInfo.setPatientId(patientId);
        payload.setCustomerInfo(customerInfo);

        req.setRequestPayload(payload);
        SignGen generateSign = new SignGen();
        HashMap<String, String> authSign = generateSign.generateTimeBasedSign("74dda87f-5549-4510-a9a0-247420a35523");//prop.getProperty("dp.account.orchestrator.consumer.id")

        headers.clear();

        headers.put("WM_CONSUMER.ID", prop.getProperty("dp.account.entity.service.consumer.id.stg"));
        headers.put("WM_SVC.NAME", prop.getProperty("dp.account.entity.service.name"));
        headers.put("WM_SVC.ENV", prop.getProperty("dp.account.entity.service.env.stg"));
        headers.put("WM_CONSUMER.INTIMESTAMP", authSign.get("Intimestamp"));
        headers.put("WM_SEC.AUTH_SIGNATURE", authSign.get("Signature"));
        headers.put("WM_SEC.KEY_VERSION", "1");
        headers.put("Content-Type", "application/json");
        headers.put("ACCEPT", "application/json");
        headers.put("cache-control", "no-cache");

        req.setHeaders(headers);
        String url = prop.getProperty("dp.account.entity.service.base.url.stg") + "/v1/account/{cid}/domain/WM-PHARMACY/patient-id";
        url = url.replace("{cid}", cid);
        Reporter.log("URL createPharmacyAccount_DPStg is "+url);
        req.setUrl(url);
        resp = am.getRestContext().performPost(req);
        Reporter.log("Response code of createPharmacyAccount_DPStg is "+resp.getStatusCode());
        Assert.assertEquals(resp.getStatusCode(), 200);
        Reporter.log("Response of createPharmacyAccount_DPStg is "+resp.getDataResponse());
        Reporter.log("Response of createPharmacyAccount_DPStg is "+resp.getDataResponse());
        System.out.println("Create Pharmacy Account Response: " + resp.getDataResponse());
    }

    public void validateSecondaryAuth(String cid, String sec_auth, String dob) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        headers.clear();
        headers.put("WM_CONSUMER.ID", prop.getProperty("pyxis.va.wm.consumer.id"));
        headers.put("WM_QOS.CORRELATION_ID", prop.getProperty("pyxis.wm.svc.name"));
        headers.put("WM_SVC.NAME", prop.getProperty("pyxis.wm.svc.name"));
        headers.put("WM_SVC.VERSION", prop.getProperty("pyxis.wm.svc.version"));
        headers.put("WM_SVC.ENV", prop.getProperty("pyxis.wm.svc.env"));
        headers.put("TENANT_ID", prop.getProperty("pyxis.tenant.id"));
        headers.put("sourceid", prop.getProperty("pyxis.src.id"));
        headers.put("WM_SEC.KEY_VERSION", prop.getProperty("pyxis.wm.sec.key.version"));
        headers.put("WM_SEC.AUTH_SIGNATURE", vaultKeys.getProperty("pyxis.wm.sec.auth.signature"));
        headers.put("WM_SEC.AUTH_TOKEN", sec_auth);
        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/json");
        req.setHeaders(headers);
        req.setUrl(prop.getProperty("pyxis.base.url") + "v1/pharmacy/customers/authenticate");
        JSONObject reqBody = new JSONObject();
        JSONObject payloadBody = new JSONObject();
        payloadBody.put("customerAccountId", cid);
        payloadBody.put("customerDOB", dob);
        reqBody.put("payload", payloadBody);
        req.setRequestPayload(reqBody.toString());
        System.out.println(req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        System.out.println(resp.getDataResponse());
        Reporter.logJSON("Validate Secondary Auth API Response: ", resp.getDataResponse());
    }

    //Used only to place Rxs Orders for a Particular Store
    public void refillBatchRxs(String dotcomemail, String dotcompass, String patientDob, String patientFirstName, String patientLastName, List<String> rxNumbers, int storeNb) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        String cid = getCidFromEmail(dotcomemail);
        String auth_gen = generateSecondaryAuth(dotcomemail, dotcompass);
        validateSecondaryAuth(cid, auth_gen, patientDob);
        headers.clear();
        headers.put("WM_CONSUMER.ID", "pyxis.wm.consumer.id");
        headers.put("WM_QOS.CORRELATION_ID", prop.getProperty("pyxis.wm.qos.correlation.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("pyxis.wm.svc.name"));
        headers.put("WM_SVC.VERSION", prop.getProperty("pyxis.wm.svc.version"));
        headers.put("WM_SVC.ENV", prop.getProperty("pyxis.wm.svc.env"));
        headers.put("TENANT_ID", prop.getProperty("pyxis.tenant.id"));
        headers.put("SourceId", prop.getProperty("pyxis.src.id"));
        headers.put("WM_SEC.AUTH_TOKEN", auth_gen);
        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/json");

        try {
            String file = readFileToString(prop.getProperty("pyxis.v3.refill.order.filepath"));
            DocumentContext jsonToParse = JsonPath.parse(file);
            jsonToParse.set("$.payload.pickupDateTime.pickupDate", new SimpleDateFormat("MMddyyyy").format(new Date()));
            jsonToParse.set("$.payload.customerAccountId", cid);
            jsonToParse.set("$.payload.pickupDateTime.pickupStoreNumber.USStoreId", storeNb);
            JSONArray rxArray = new JSONArray();
            for (String i : rxNumbers) {
                JSONObject rxBody = new JSONObject();
                rxBody.put("rxNumber", i);
                JSONObject storeBody = new JSONObject();
                storeBody.put("USStoreId", storeNb);
                rxBody.put("storeNumber", storeBody);
                rxArray.put(rxBody);
            }
            System.out.println(rxArray);
            List<Object> jsonObjects = rxArray.toList();
            jsonToParse.put("$.payload", "prescriptionList", jsonObjects);
            jsonToParse.set("$.payload.contactInformation.name.firstName", patientFirstName);
            jsonToParse.set("$.payload.contactInformation.name.lastName", patientLastName);

            req.setHeaders(headers);
            req.setUrl(prop.getProperty("pyxis.base.url") + "v3/pharmacy/refills");
            req.setRequestPayload(jsonToParse.jsonString());
            System.out.println("Req Payload: " + req.getRequestPayload());
            resp = am.getRestContext().performPut(req);
            System.out.println("Response For Refill: " + resp.getDataResponse());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void refillBatchRxsWithInsurance(String dotcomemail, String dotcompass, String patientDob, String patientFirstName, String patientLastName, List<String> rxNumbers, int storeNb, String payload, Boolean isZeroCoPayInsurance) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        String cid = getCidFromEmail(dotcomemail);
        String auth_gen = generateSecondaryAuth(dotcomemail, dotcompass);
        validateSecondaryAuth(cid, auth_gen, patientDob);
        headers.clear();
        headers.put("WM_CONSUMER.ID", "pyxis.wm.consumer.id");
        headers.put("WM_QOS.CORRELATION_ID", prop.getProperty("pyxis.wm.qos.correlation.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("pyxis.wm.svc.name"));
        headers.put("WM_SVC.VERSION", prop.getProperty("pyxis.wm.svc.version"));
        headers.put("WM_SVC.ENV", prop.getProperty("pyxis.wm.svc.env"));
        headers.put("TENANT_ID", prop.getProperty("pyxis.tenant.id"));
        headers.put("SourceId", prop.getProperty("pyxis.src.id"));
        headers.put("WM_SEC.AUTH_TOKEN", auth_gen);
        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/json");
        String file;

        try {
            if (isZeroCoPayInsurance) {
                file = readFileToString(prop.getProperty("pyxis.v3.refillInsurance.order.zeroCoPay"));
            } else {
                file = readFileToString(prop.getProperty("pyxis.v3.refillInsurance.order.filepath"));

            }
            DocumentContext jsonToParse = JsonPath.parse(file);
            jsonToParse.set("$.payload.pickupDateTime.pickupDate", new SimpleDateFormat("MMddyyyy").format(new Date()));
            jsonToParse.set("$.payload.customerAccountId", cid);
            jsonToParse.set("$.payload.pickupDateTime.pickupStoreNumber.USStoreId", storeNb);
            JSONArray rxArray = new JSONArray();
            for (String i : rxNumbers) {
                JSONObject rxBody = new JSONObject();
                rxBody.put("rxNumber", i);
                JSONObject storeBody = new JSONObject();
                storeBody.put("USStoreId", storeNb);
                rxBody.put("storeNumber", storeBody);

                JSONObject payloadJson = new JSONObject(payload);
                JSONArray insuranceInfoArray = payloadJson.optJSONArray("insuranceInfo");
                JSONObject insurancePayload = insuranceInfoArray.getJSONObject(0);
                JSONObject insuranceInfoObject = new JSONObject();
                insuranceInfoObject.put("carrierId", insurancePayload.get("carrierId"));
                insuranceInfoObject.put("planId", insurancePayload.get("planId"));
                insuranceInfoObject.put("cardHolderID", insurancePayload.get("cardholderId"));
                insuranceInfoObject.put("cardHolderFirstName", insurancePayload.get("cardholderFirstName"));
                insuranceInfoObject.put("cardHolderLastName", insurancePayload.get("cardholderLastName"));
                insuranceInfoObject.put("relation", insurancePayload.get("relation"));
                insuranceInfoObject.put("category", "1004");

                rxBody.put("insuranceInfo", insuranceInfoObject);
                rxArray.put(rxBody);
            }
            System.out.println(rxArray);
            List<Object> jsonObjects = rxArray.toList();
            jsonToParse.put("$.payload", "prescriptionList", jsonObjects);
            jsonToParse.set("$.payload.contactInformation.name.firstName", patientFirstName);
            jsonToParse.set("$.payload.contactInformation.name.lastName", patientLastName);

            req.setHeaders(headers);
            req.setUrl(prop.getProperty("pyxis.base.url") + "v3/pharmacy/refills");
            req.setRequestPayload(jsonToParse.jsonString());
            System.out.println("Req Payload: " + req.getRequestPayload());
            resp = am.getRestContext().performPut(req);
            System.out.println("Response For Refill: " + resp.getDataResponse());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<String> getEligibleRxsForRefillWithSameStore(String cid, int storeNumber) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        List<String> rxNumberList = new ArrayList<>();
        resp = this.getPrescriptionsList(cid);
        System.out.println(resp.getDataResponse());
        Gson gson = new Gson();
        JsonObject temp = gson.fromJson(resp.getDataResponse(), JsonObject.class);
        for (int j = 0; j < temp.getAsJsonObject("payload").getAsJsonArray("customerPrescriptions").getAsJsonArray().size(); j++) {
            JsonArray rxList = temp.getAsJsonObject("payload").getAsJsonArray("customerPrescriptions").getAsJsonArray().get(j).getAsJsonObject().getAsJsonArray("prescriptionList");
            for (int i = 0; i < rxList.size(); i++) {
                JsonElement currRx = rxList.get(i);
                try {
                    if (currRx.getAsJsonObject().get("storeNumber").getAsJsonObject().get("storeId").getAsString().equals("" + storeNumber)
                            && "PICKED UP".equals(currRx.getAsJsonObject().get("latestFillStatus").getAsString())) {
                        if (currRx.getAsJsonObject().get("storeNumber").getAsJsonObject().get("storeId").getAsString().equals("" + storeNumber)
                                && "PICKED UP".equals(currRx.getAsJsonObject().get("latestFillStatus").getAsString())) {
                            rxNumberList.add(currRx.getAsJsonObject().get("rxNumber").getAsString());
                        }
                    }
                } catch (Exception e) {
                    System.out.println("A Param was missing in Pyxis Response, please check for currRx: " + currRx.toString());
                    e.printStackTrace();
                }
            }
        }
        System.out.println(rxNumberList);
        return rxNumberList;
    }

    public List<String> getEligibleRxsInFillWithSameStore(String cid, int storeNumber) {
        ServiceResponse resp = new ServiceResponse();
        List<String> rxNumberList = new ArrayList<>();
        resp = this.getPrescriptionsList(cid);
        System.out.println(resp.getDataResponse());
        Gson gson = new Gson();
        JsonObject temp = gson.fromJson(resp.getDataResponse(), JsonObject.class);
        JsonArray rxList = temp.getAsJsonObject("payload").getAsJsonArray("customerPrescriptions").get(0).getAsJsonObject().getAsJsonArray("prescriptionList");
        for (int i = 0; i < rxList.size(); i++) {
            JsonElement currRx = rxList.get(i);
            if (currRx.getAsJsonObject().get("storeNumber").getAsJsonObject().get("storeId").getAsString().equals("" + storeNumber)
                    && "ACKNOWLEDGED".equals(currRx.getAsJsonObject().get("latestFillStatus").getAsString())) {
                rxNumberList.add(currRx.getAsJsonObject().get("rxNumber").getAsString());
            }
        }
        System.out.println(rxNumberList);
        return rxNumberList;
    }

    public String getNdcForRx(String cid, String rxNbr) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        resp = this.getPrescriptionsList(cid);
        System.out.println(resp.getDataResponse());
        Gson gson = new Gson();
        JsonObject temp = gson.fromJson(resp.getDataResponse(), JsonObject.class);
        JsonArray customerRxList = temp.getAsJsonObject("payload").getAsJsonArray("customerPrescriptions").get(0).getAsJsonObject().getAsJsonArray("prescriptionList");
        for (JsonElement currentRx : customerRxList) {
            if (currentRx.getAsJsonObject().get("rxNumber").getAsString().equals(rxNbr)) {
                return currentRx.getAsJsonObject().get("ndcNumber").getAsString();
            }
        }
        System.out.println("Rx Not in List");
        return "";
    }

    public PrescriptionResponse getRxData(String cid, String rxNbr) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        PrescriptionResponse rxData = new PrescriptionResponse();
        resp = this.getPrescriptionsList(cid);
        Gson gson = new Gson();
        JsonObject temp = gson.fromJson(resp.getDataResponse(), JsonObject.class);
        JsonArray customerRxList = temp.getAsJsonObject("payload").getAsJsonArray("customerPrescriptions").get(0).getAsJsonObject().getAsJsonArray("prescriptionList");
        for (int j = 0; j < temp.getAsJsonObject("payload").getAsJsonArray("customerPrescriptions").getAsJsonArray().size(); j++) {
            JsonArray rxList = temp.getAsJsonObject("payload").getAsJsonArray("customerPrescriptions").getAsJsonArray().get(j).getAsJsonObject().getAsJsonArray("prescriptionList");
            for (int i = 0; i < rxList.size(); i++) {
                JsonElement currRx = rxList.get(i);
                if (currRx.getAsJsonObject().get("rxNumber").getAsString().equals(rxNbr)) {
                    rxData = gson.fromJson(currRx.getAsJsonObject().toString(), PrescriptionResponse.class);
                    return rxData;
                }
            }
        }
        System.out.println("Rx Not in List");
        return rxData;
    }

    public void placeOrderForRefill(int storeId, String patientFn, String patientLn, String patientDob, String email, String password) {
        try {
            String cid = getCidFromEmail(email);
            List<String> rxNumbers = getEligibleRxsForRefillWithSameStore(cid, storeId);
            refillBatchRxs(email, password, patientDob, patientFn, patientLn, rxNumbers.subList(0, 2), storeId);
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public void triggerReadyForRefillNotif(String storeNbr, String patientId, String rxNbr, String rxDrugName) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        headers.clear();
        headers.put("WMT-API-KEY", vaultKeys.getProperty("wmt.api.key"));
        headers.put("WMT-API-SECRET", vaultKeys.getProperty("wmt.api.secret"));
        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/json");
        try {
            String file = readFileToString(prop.getProperty("pharma.trigger.notif.refills.due.filepath"));
            DocumentContext jsonToParse = JsonPath.parse(file);
            jsonToParse.set("$.notificationInfo.sourceTime", new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + "T02:24:20CDT");
            jsonToParse.set("$.notificationInfo.storeNbr", storeNbr);
            jsonToParse.set("$.notificationInfo.patientId", patientId);
            jsonToParse.set("$.notificationInfo.rxNbrs[0].rxNbr", rxNbr);
            jsonToParse.set("$.notificationInfo.rxNbrs[0].rxDrug", rxDrugName);
            req.setHeaders(headers);
            req.setUrl(prop.getProperty("pharmacy.notification.base.url"));
            req.setRequestPayload(jsonToParse.jsonString());
            System.out.println("Req Payload: " + req.getRequestPayload());
            resp = am.getRestContext().performPost(req);
            System.out.println("Response For Refill: " + resp.getDataResponse());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void postPreferenceForUser(String patientId, String storeId, String phoneNumber) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        headers.clear();
        String enrollment_status_code = "26805";
        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/json");
        headers.put("WM_SVC.ENV", prop.getProperty("dm.preference.service.env"));
        headers.put("WM_SVC.NAME", "COMM-PREFERENCE-SVC");
        headers.put("WM_CONSUMER.ID", prop.getProperty("dm.preference.service.consumer.id"));
        req.setHeaders(headers);
        req.setUrl(prop.getProperty("dm.preference.service.base.url") + "/postPreferences");

        JSONObject reqBody = getPostPreferenceReqBody(patientId, storeId, phoneNumber, enrollment_status_code);
        req.setRequestPayload(reqBody.toString());
        resp = am.getRestContext().performPost(req);

        Assert.assertEquals(resp.getStatusCode(), 200, "Post Preferences Request Failed - Please Report");
        Reporter.logJSON("Post Preferences Response: ", resp.getDataResponse());
        System.out.println(resp.getDataResponse());
    }

    public void postPreferenceForUser_ConsentPreferenceSvc(String patientId, String storeId, String phoneNumber) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp;
        String enrollment_status_code = "26802";
        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/json");
        headers.put("WM_SVC.ENV", prop.getProperty("dm.consent.preference.service.env"));
        headers.put("WM_SVC.NAME", "COMM-PREFERENCE-SVC");
        headers.put("WM_CONSUMER.ID", prop.getProperty("dm.consent.preference.service.consumer.id"));
        req.setHeaders(headers);
        req.setUrl(prop.getProperty("dm.consent.preference.service.base.url") + "/postPreferences");

        JSONObject reqBody = getPostPreferenceReqBody(patientId, storeId, phoneNumber, enrollment_status_code);
        req.setRequestPayload(reqBody.toString());
        resp = am.getRestContext().performPost(req);

        Assert.assertEquals(resp.getStatusCode(), 200, "Post Preferences Request Failed - Please Report");
        Reporter.logJSON("Post Preferences Response: ", resp.getDataResponse());
        System.out.println(resp.getDataResponse());
    }

    private JSONObject getPostPreferenceReqBody(String patientId, String storeId, String phoneNumber, String enrollment_status_code) {
        JSONObject reqBody = new JSONObject();
        JSONArray preferencesArray = new JSONArray();
        JSONObject preferenceBody = new JSONObject();
        reqBody.put("storeNbr", storeId);
        reqBody.put("zipCode","96898");
        reqBody.put("userId", "SIGPAD");
        reqBody.put("storePhone","8009666546");
        reqBody.put("patientId", patientId);
        reqBody.put("timeStamp", new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + "T02:24:20CDT");
        reqBody.put("language", "101");

        preferenceBody.put("notification_type", "1");
        preferenceBody.put("notification_val", phoneNumber);
        preferenceBody.put("short_code_type_id", "1");
        preferenceBody.put("enrollment_status_code", enrollment_status_code);

        preferencesArray.put(preferenceBody);

        reqBody.put("preferences", preferencesArray);
        return reqBody;
    }

    public ServiceResponse getSmsEnrolledProfilesForPatient(String cid) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        SignatureGenerator signatureGenerator = new SignatureGenerator();
        String wmTimestamp = Long.toString(Instant.now().toEpochMilli());
        String wmAuthSignature = signatureGenerator.generateSig(prop.getProperty("dp.account.orchestrator.private.key"), prop.getProperty("dp.account.orchestrator.consumer.id"), prop.getProperty("dp.account.orchestrator.key.version"), wmTimestamp);
        headers.clear();
        headers.put("WM_CONSUMER.ID", prop.getProperty("dp.account.orchestrator.consumer.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("dp.account.orchestrator.service.name"));
        headers.put("WM_SVC.ENV", "dev".equalsIgnoreCase(prop.getEnvironment().toString().toLowerCase().trim()) ? "stg" : prop.getProperty("dp.account.orchestrator.service.env"));
        headers.put("WM_CONSUMER.INTIMESTAMP", wmTimestamp);
        headers.put("WM_SEC.AUTH_SIGNATURE", wmAuthSignature);

        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/json");
        String Url = prop.getProperty("dp.account.orchestrator.sms.enrolled.profile.list.endpoint");
        Url = Url.replace("{customerAccountId}", cid);
        req.setUrl("dev".equalsIgnoreCase(prop.getEnvironment().toString().toLowerCase().trim()) ? (prop.getProperty("dp.account.orchestrator.base.url") + Url + "?type=MINOR%2CPET%2CADULT").replace("dev", "stg") : prop.getProperty("dp.account.orchestrator.base.url") + Url + "?type=MINOR%2CPET%2CADULT");
        req.setHeaders(headers);
        resp = am.getRestContext().performGet(req);

        Assert.assertEquals(resp.getStatusCode(), 200, "Request Failed - Please Report");
        return resp;
    }

    public String getValidationTokenForSmsEnrolledDependent(String cid, String dependentPatientId) {
        ServiceResponse resp = new ServiceResponse();
        resp = this.getSmsEnrolledProfilesForPatient(cid);
        Gson gson = new Gson();
        JsonObject jsonResponse = gson.fromJson(resp.getDataResponse(), JsonObject.class);
        JsonArray payloadArray = jsonResponse.getAsJsonArray("payload");
        String validationToken = "";
        for (JsonElement currUserPreference : payloadArray) {
            if (currUserPreference.getAsJsonObject().get("customerInfo").getAsJsonObject().get("patientId").getAsString().equals(dependentPatientId)) {
                validationToken = currUserPreference.getAsJsonObject().get("validationToken").getAsString();
                Reporter.log("Sms Enrolled dependent found");
                break;
            }
        }
        if ("".equals(validationToken)) {
            Reporter.log("dependent is not sms enrolled");
        }
        return validationToken;
    }

    public void addDependent(String caregiverCid, String validationToken, String patientId, String dob,
                             String storeNumber, String dependentType, String email, boolean isLinkageComplete) {
        ServiceRequest newReq = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        SignatureGenerator signatureGenerator = new SignatureGenerator();
        String wmTimestamp = Long.toString(Instant.now().toEpochMilli());
        String wmAuthSignature = signatureGenerator.generateSig(prop.getProperty("dp.account.orchestrator.private.key"), prop.getProperty("dp.account.orchestrator.consumer.id"), prop.getProperty("dp.account.orchestrator.key.version"), wmTimestamp);
        headers.clear();
        headers.put("WM_CONSUMER.ID", prop.getProperty("dp.account.orchestrator.consumer.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("dp.account.orchestrator.service.name"));
        headers.put("WM_SVC.ENV", "dev".equalsIgnoreCase(prop.getEnvironment().toString().toLowerCase().trim()) ? "stg" : prop.getProperty("dp.account.orchestrator.service.env"));
        headers.put("request_tracking_id", RandomStringUtils.randomAlphanumeric(7).toUpperCase() + prop.getProperty("dp.account.orchestrator.random.tracker") + RandomStringUtils.randomAlphanumeric(7).toUpperCase());
        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/json");
        headers.put("WM_CONSUMER.INTIMESTAMP", wmTimestamp);
        headers.put("WM_SEC.AUTH_SIGNATURE", wmAuthSignature);
        newReq.setHeaders(headers);
        String Url = prop.getProperty("dp.account.orchestrator.fam.extended.endpoint");
        Url = Url.replace("{customerAccountId}", caregiverCid);
        newReq.setUrl("dev".equalsIgnoreCase(prop.getEnvironment().toString().toLowerCase().trim()) ? (prop.getProperty("dp.account.orchestrator.base.url") + Url + "/dependent/patient-id").replace("dev", "stg") : prop.getProperty("dp.account.orchestrator.base.url") + Url + "/dependent/patient-id");
        JSONObject reqBody = new JSONObject();
        JSONArray dependentsInfoArray = new JSONArray();
        JSONObject dependentsInfoObject = new JSONObject();
        dependentsInfoObject.put("validationToken", validationToken);
        dependentsInfoObject.put("patientId", patientId);
        dependentsInfoObject.put("storeNbr", storeNumber);
        dependentsInfoObject.put("dob", dob);
        dependentsInfoObject.put("type", dependentType.toUpperCase());

        if (dependentType == PatientType.PET.getValue()) {
            JSONObject consentObject = new JSONObject();
            consentObject.put("type", "PET_DEPENDENT");
            consentObject.put("value", "TRUE");
            dependentsInfoObject.put("consent", consentObject);
        }

        if (dependentType == PatientType.ADULT.getValue()) {
            dependentsInfoObject.put("emailId", email);
        }

        dependentsInfoObject.put("tAndCPolicyLanguage", "EN");

        dependentsInfoArray.put(dependentsInfoObject);
        reqBody.put("dependentsInfo", dependentsInfoArray);
        newReq.setRequestPayload(reqBody.toString());
        ServiceResponse resp = new ServiceResponse();
        resp = am.getRestContext().performPost(newReq);

        if (dependentType == PatientType.ADULT.getValue()) {
            Assert.assertEquals(resp.getStatusCode(), 201, "Request Failed - Please Report");
        } else {
            Assert.assertEquals(resp.getStatusCode(), 200, "Request Failed - Please Report");
        }

        Reporter.logJSON("Add Dependent Response: ", resp.getDataResponse());

        if (dependentType == PatientType.ADULT.getValue() && isLinkageComplete) {
            am.performSleep(3);
            this.approveAddDependentRequest(caregiverCid, this.getCidFromEmailUsingAstro(email));
        }
    }

    public void approveAddDependentRequest(String caregiverCid, String dependentCid) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        SignatureGenerator signatureGenerator = new SignatureGenerator();
        String wmTimestamp = Long.toString(Instant.now().toEpochMilli());
        String wmAuthSignature = signatureGenerator.generateSig(prop.getProperty("dp.account.orchestrator.private.key"), prop.getProperty("dp.account.orchestrator.consumer.id"), prop.getProperty("dp.account.orchestrator.key.version"), wmTimestamp);
        headers.clear();
        headers.put("WM_CONSUMER.ID", prop.getProperty("dp.account.orchestrator.consumer.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("dp.account.orchestrator.service.name"));
        headers.put("WM_SVC.ENV", "dev".equalsIgnoreCase(prop.getEnvironment().toString().toLowerCase().trim()) ? "stg" : prop.getProperty("dp.account.orchestrator.service.env"));
        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/json");
        headers.put("WM_CONSUMER.INTIMESTAMP", wmTimestamp);
        headers.put("WM_SEC.AUTH_SIGNATURE", wmAuthSignature);
        req.setHeaders(headers);
        String Url = prop.getProperty("dp.account.orchestrator.fam.extended.endpoint.plural");
        Url = Url.replace("{customerAccountId}", dependentCid);
        req.setUrl("dev".equalsIgnoreCase(prop.getEnvironment().toString().toLowerCase().trim()) ? (prop.getProperty("dp.account.orchestrator.base.url") + Url + "/adult/consent").replace("dev", "stg") : prop.getProperty("dp.account.orchestrator.base.url") + Url + "/adult/consent");
        JSONObject reqBody = new JSONObject();
        reqBody.put("caregiverCustomerAccountId", caregiverCid);
        reqBody.put("approvalStatus", "APPROVED");
        req.setRequestPayload(reqBody.toString());
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("Dependent approval response", resp.getDataResponse());

        Assert.assertEquals(resp.getStatusCode(), 200, "Request Failed - Please Report");
    }

    public ServiceResponse moveRxAPI_Astro(int fillId, int siteId, String state) {
        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        MoveRx moveRx = MoveRx.builder().fillId(String.valueOf(fillId)).siteId(String.valueOf(siteId)).state(state).build();
        req.setRequestPayloadWithNulls(moveRx);
        req.setUrl(prop.getProperty("astro.moveRx.url"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("Move Rx Request endpoint: " + req.getUrl());
        Reporter.logJSON("Move Rx Request", req.getRequestPayload());
        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("Move Rx '"+state+"' API Response", resp.getDataResponse());
        return resp;
    }

    public ServiceResponse moveRxToPickupAPI_Astro(int fillId, int siteId) {
        return moveRxAPI_Astro(fillId, siteId, "ReadyForPickup");
    }

    public ServiceResponse moveRxToEODAPI_Astro(int fillId, int siteId) {
        return moveRxAPI_Astro(fillId, siteId, "EOD");
    }

    public ServiceResponse createTeflonSession(String email, String password) {
        ServiceRequest req = new ServiceRequest();
        ServiceResponse response = new ServiceResponse();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("x-o-segment", prop.getProperty("ce.xo.segment"));
        headers.put("x-o-platform-version", prop.getProperty("ce.x.o.platform.version"));
        headers.put("x-o-platform", prop.getProperty("ce.x.o.platform"));
        headers.put("x-apollo-operation-name", prop.getProperty("ce.apollo.operation.name"));
        headers.put("x-o-correlation-id", prop.getProperty("ce.x.o.correlation.id"));
        headers.put("ess_skip", prop.getProperty("ce.ess.skip"));
        headers.put("cookie", prop.getProperty("ce.cookie"));

        req.setUrl(prop.getProperty("ce.orchestration.graphql.url"));

        String gqlPayload = "{\n" +
                "    \"query\": \"mutation SignIn {signIn(input: {email:\\\"$email\\\", password:\\\"$password\\\"}) {auth{loginId identityToken}errors {code message}}}\",\n" +
                "    \"variables\": {}\n" +
                "}";
        gqlPayload = gqlPayload.replace("$email", email).replace("$password", password);
        req.setRequestPayload(gqlPayload);
        req.setHeaders(headers);
        Reporter.log("Teflon Session Creation Request: " + req.getRequestPayload());
        response = am.getRestContext().performPost(req);
        Reporter.log("Teflon Session Creation Response: " + response.getDataResponse());
        return response;
    }

    public ServiceResponse createPharmacyPin(String email, String password, String pharmacyPin){
        ServiceRequest req = new ServiceRequest();
        ServiceResponse response = new ServiceResponse();
        HashMap<String, String> headers = new HashMap<>();
        ServiceResponse sessionServiceResponse = createTeflonSession(email, password);
        Assert.assertEquals(sessionServiceResponse.getStatusCode(), 200, "Teflon Session Creation Failed");
        String identityToken = sessionServiceResponse.getJsonElement("data.signIn.auth.identityToken").toString();
        String spid = identityToken.split("\\|")[0];
        String cid = identityToken.split("\\|")[1];
        String pattern = "auth=[^;]+";
        Pattern compiledPattern = Pattern.compile(pattern);
        Matcher matcher = compiledPattern.matcher(sessionServiceResponse.getHeaders().get("set-cookie").toString());
        String authToken = matcher.find() ? matcher.group().split("auth=")[1] : "";
        if ("".equalsIgnoreCase(authToken)) {
            throw new RuntimeException("Auth Token not found in Session Response, Please Report");
        }

        headers.put("cid", cid);
        headers.put("spid", spid);
        headers.put("WM_SEC.AUTH_TOKEN", authToken);
        headers.put("WM_CONSUMER.ID", prop.getProperty("wellnessplus.consumer.id"));
        headers.put("content-type", "application/json");
        headers.put("Cookie", "CID="+cid+"; SPID="+spid+";"+prop.getProperty("wellnessplus.cookie"));

        String gqlPayload = "{\n" +
                "    \"query\": \"query createPin {\\n            createPin( where: {pin:\\\"$pin\\\", isSensitive:false}) {\\n                valid\\n                pinToken\\n            }\\n        }\",\n" +
                "    \"variables\": {}\n" +
                "}";
        gqlPayload = gqlPayload.replace("$pin", pharmacyPin);
        req.setRequestPayload(gqlPayload);
        req.setHeaders(headers);
        req.setUrl(prop.getProperty("wellnessplus.graphql.base.url"));
        Reporter.log("Create Pharmacy Pin Request: " + req.getRequestPayload());
        response = am.getRestContext().performPost(req);
        Reporter.log("Create Pharmacy Pin Response: " + response.getDataResponse());
        System.out.println("Create Pharmacy Pin Response: " + response.getDataResponse());
        return response;
    }

    public PrescriptionsLookupResponse getPrescriptionLookupResponse(String patientEmail) {

        HashMap<String, String> headers = new HashMap<>();
        ServiceRequest req = new ServiceRequest();
        ServiceResponse resp = new ServiceResponse();
        headers.clear();
        SignGen generateSign = new SignGen();
        HashMap<String, String> authSign = generateSign.generateTimeBasedSign(prop.getProperty("dp.rx.orchestrator.consumer.id"));
        headers.put("WM_CONSUMER.INTIMESTAMP", authSign.get("Intimestamp"));
        headers.put("WM_SEC.AUTH_SIGNATURE", authSign.get("Signature"));
        headers.put("WM_CONSUMER.ID", prop.getProperty("dp.rx.orchestrator.consumer.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("dp.rx.orchestrator.service.name"));
        headers.put("WM_SVC.ENV", prop.getProperty("dp.rx.orchestrator.service.env"));
        headers.put("Accept", "application/json");
        headers.put("Content-Type", "application/json");
        req.setHeaders(headers);

        String requestTrackingId = RandomStringUtils.randomAlphanumeric(7).toUpperCase() + prop.getProperty("dp.account.orchestrator.random.tracker") + RandomStringUtils.randomAlphanumeric(7).toUpperCase();
        String requestId = "req-id-" + requestTrackingId;
        PrescriptionsLookupRequest request = new PrescriptionsLookupRequest();
        PrescriptionsLookupFilterOptions filterOptions = new PrescriptionsLookupFilterOptions();
        filterOptions.setIncludeDependents(true);
        filterOptions.setIncludeFills(false);
        filterOptions.setRxStatus(Arrays.asList(PrescriptionsLookupFilterOptions.RxStatusEnum.ACTIVE));
        filterOptions.setRxType(Arrays.asList(PrescriptionsLookupFilterOptions.RxTypeEnum.PHARMACY));
        PrescriptionsLookupSortOptions sortOptions = new PrescriptionsLookupSortOptions();
        sortOptions.setRxSortBy(Arrays.asList(PrescriptionsLookupSortOptions.RxSortByEnum.LAST_FILL_DATE));
        request.setSortOptions(sortOptions);
        request.setFilterOptions(filterOptions);

        String cid = getCidFromEmailUsingAstro(patientEmail);
        String Url = prop.getProperty("dp.rx.orchestrator.lookup.uri");
        Url = Url.replace("{cid}", cid);
        req.setUrl(Url);
        req.setRequestPayload(request);
        PrescriptionsLookupResponse lookupResponse = new PrescriptionsLookupResponse();

        try {
            resp = am.getRestContext().performPost(req);

            Gson gson = new GsonBuilder()
                    .registerTypeAdapter(LocalDate.class, new GsonLocalDateAdapter())
                    .create();

            JsonObject jsonResponse = gson.fromJson(resp.getDataResponse(), JsonObject.class);
            lookupResponse = gson.fromJson(jsonResponse, PrescriptionsLookupResponse.class);

            String lookUpResponseJson = gson.toJson(lookupResponse);
            Reporter.logJSON("Lookup response deserialized is: ", lookUpResponseJson);

        } catch (Exception e) {
            e.printStackTrace();
            softAssert.fail("Rx Lookup API Failed, We're unable to verify data", e.getCause());
        }

        softAssert.assertEquals(resp.getStatusCode(), 200, "Request Failed - Please Report");

        return lookupResponse;
    }
}