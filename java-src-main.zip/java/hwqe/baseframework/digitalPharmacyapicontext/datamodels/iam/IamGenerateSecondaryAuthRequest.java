package hwqe.baseframework.digitalPharmacyapicontext.datamodels.iam;

@lombok.Getter
@lombok.Setter
public class IamGenerateSecondaryAuthRequest {
    public AuthCredentialsPayload payload;
}
