package hwqe.baseframework.digitalPharmacyapicontext.datamodels.iam;

@lombok.Getter
@lombok.Setter
public class AuthCredentialsPayload {
    // Not slated to Change
    public String realmId = "WALMART.COM";
    // Not Slated to Change
    public String tenantId = "WALMART.COM";
    // dotcom email Id
    public String userId;
    // dotcom password
    public String password;
}
