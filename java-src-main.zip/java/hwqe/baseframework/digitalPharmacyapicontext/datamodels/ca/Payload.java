package hwqe.baseframework.digitalPharmacyapicontext.datamodels.ca;

@lombok.Setter
@lombok.Getter
public class Payload {

    String tenantId="WALMART.COM";
    String realmId="WALMART.COM";
    Person person;
    String password;


}
