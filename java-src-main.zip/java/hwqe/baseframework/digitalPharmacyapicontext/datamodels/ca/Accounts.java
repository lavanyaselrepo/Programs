package hwqe.baseframework.digitalPharmacyapicontext.datamodels.ca;

@lombok.Setter
@lombok.Getter
public class Accounts {

    String emailAddress;
    String accountType="INDIVIDUAL";



}
