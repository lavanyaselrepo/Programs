package hwqe.baseframework.digitalPharmacyapicontext.datamodels.ca;

import java.util.List;

@lombok.Setter
@lombok.Getter
public class Person {

    String customerType="INDIVIDUAL";
    List<Names> names;
    List<Accounts> accounts;



}
