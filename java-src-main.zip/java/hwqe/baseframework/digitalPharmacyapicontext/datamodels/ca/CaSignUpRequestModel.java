package hwqe.baseframework.digitalPharmacyapicontext.datamodels.ca;

@lombok.Setter
@lombok.Getter
public class CaSignUpRequestModel {

    Payload payload;

}
