package hwqe.baseframework.digitalPharmacyapicontext.datamodels.dpaccentity;

@lombok.Getter
@lombok.Setter
public class CustomerInfoRequestPayload {
    public String storeNbr;
    public String patientId;
    public String dob;
}
