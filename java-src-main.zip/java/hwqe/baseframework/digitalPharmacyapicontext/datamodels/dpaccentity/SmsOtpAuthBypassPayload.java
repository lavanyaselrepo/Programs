package hwqe.baseframework.digitalPharmacyapicontext.datamodels.dpaccentity;

@lombok.Getter
@lombok.Setter
public class SmsOtpAuthBypassPayload {
    public CustomerInfoRequestPayload customerInfo;
    public String accountCreationSource;
}
