package hwqe.baseframework.digitalPharmacyapicontext.datamodels.dpaccentity;

@lombok.Getter
@lombok.Setter
public class PharmacyAccountLinkDPPayload {

    public CustomerInfo customerInfo;
    public String accountCreationSource="smsOtpVerification";
}
