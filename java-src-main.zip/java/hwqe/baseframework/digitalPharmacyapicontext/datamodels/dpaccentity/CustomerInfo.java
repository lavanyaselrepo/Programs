package hwqe.baseframework.digitalPharmacyapicontext.datamodels.dpaccentity;
@lombok.Getter
@lombok.Setter
public class CustomerInfo {

    private String phoneNumber;
    private String storeNbr;
    private String patientId;
    private String dob;

}
