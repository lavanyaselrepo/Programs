package hwqe.baseframework.digitalPharmacyapicontext.datamodels.astro;

@lombok.Getter
@lombok.Setter
public class PostalAddressModel {

    private String address;
    private String city;
    private String country;
    private String postalCode;
    private String state;
            /*"address": "2730 E McKellips Rd",
            "city": "Mesa",
            "country": "USA",
            "postalCode": "85213",
            "state": "AZ"*/
}
