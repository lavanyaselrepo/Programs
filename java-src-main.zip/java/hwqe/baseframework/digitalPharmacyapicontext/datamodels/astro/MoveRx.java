package hwqe.baseframework.digitalPharmacyapicontext.datamodels.astro;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MoveRx {
    private String fillId;
    private String siteId;
    private String state;
}
