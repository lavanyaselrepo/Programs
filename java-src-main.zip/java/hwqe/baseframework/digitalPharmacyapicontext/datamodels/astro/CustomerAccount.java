package hwqe.baseframework.digitalPharmacyapicontext.datamodels.astro;

import java.util.List;

@lombok.Getter
@lombok.Setter
public class CustomerAccount {
    private String firstName;
    private String lastName;
    private String emailAddress;
    private String phoneNumber;
    private String password;
    private List<String> paymentMethods;
    private PostalAddressModel postalAddress;
}
