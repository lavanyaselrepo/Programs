package hwqe.baseframework.digitalPharmacyapicontext.datamodels.astro;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreatePharmacyAccount {
    private String firstName;
    private String lastName;
    private String pin;
    private String password;
    private String siteId;
    private String dateOfBirth;
    private Boolean hasInsurance;
    private Object insuranceType;
}
