package hwqe.baseframework.digitalPharmacyapicontext.datamodels.cpr;
@lombok.Getter
@lombok.Setter
public class CentralPatientSearchRequest {
    public String birthDate;
    public String firstName;
    public String lastName;
    public String storeNbr;
/*    {
        "birthDate": "1931-01-01",
            "firstName": "Cassandra",
            "lastName": "Singleton",
            "storeNbr": "5597"
    }*/
}
