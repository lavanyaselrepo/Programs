package hwqe.baseframework.digitalPharmacyapicontext.datamodels.pyxis;

@lombok.Getter
@lombok.Setter
public class RxResponseDrug {
    private String drugName;
    private String drugType;
}
