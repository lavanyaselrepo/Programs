package hwqe.baseframework.digitalPharmacyapicontext.datamodels.pyxis;

@lombok.Getter
@lombok.Setter
public class PrescriptionResponse {
    public String rxNumber;
    public RxResponseStoreNumber rxResponseStoreNumber;
    public boolean rxOnlineRefillable;
    public boolean compoundRx;
    public int numOfRemainingReFills;
    public String lastRefillDate;
    public RxResponseDrug[] drug;
    public String expirationDate;
    public boolean autoRefillable;
    public int storePatientId;
    public String prescriber;
    public boolean rxAutoRefillOn;
    public boolean isIMZPrescription;
    public Object fillCount;
    public String prescribedDate;
    public Object fillCost;
    public String latestFillStatus;
    public Object lastDispensedDate;
    public Object[] entityErrors;
    public long lastFillDaysSupplyQty;
    public String ndcNumber;
}
