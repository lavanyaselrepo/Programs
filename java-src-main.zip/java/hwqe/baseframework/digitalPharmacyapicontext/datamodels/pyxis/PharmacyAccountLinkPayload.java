package hwqe.baseframework.digitalPharmacyapicontext.datamodels.pyxis;

@lombok.Getter
@lombok.Setter
public class PharmacyAccountLinkPayload {
/*    "stgId" : "379e001e-8d93-47f1-a03b-2d605eac807b",
            "customerDOB": "01011924",
            "tAndCPolicyLanguage": "EN",
            "customerAccountId" : "{{cid}}"*/
    public String stgId;
    public String customerDOB;
    public String tAndCPolicyLanguage;
    public String customerAccountId;
}
