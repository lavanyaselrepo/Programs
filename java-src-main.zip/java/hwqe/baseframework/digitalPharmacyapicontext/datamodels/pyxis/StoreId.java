package hwqe.baseframework.digitalPharmacyapicontext.datamodels.pyxis;

@lombok.Getter
@lombok.Setter
public class StoreId {
    public String USStoreId;
}
