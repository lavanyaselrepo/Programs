package hwqe.baseframework.digitalPharmacyapicontext.datamodels.pyxis;

@lombok.Getter
@lombok.Setter
public class CreatePharmacyAccountRequest {
    public PharmacyAccountLinkPayload payload;
}
