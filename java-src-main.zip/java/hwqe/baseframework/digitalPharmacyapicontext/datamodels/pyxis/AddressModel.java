package hwqe.baseframework.digitalPharmacyapicontext.datamodels.pyxis;

@lombok.Getter
@lombok.Setter
public class AddressModel {
    public String addressLineOne;
    public String addressLineTwo;
    public String city;
    public String countryCode;
    public String postalCode;
}
