package hwqe.baseframework.digitalPharmacyapicontext.datamodels.pyxis;

@lombok.Getter
@lombok.Setter
public class RxResponseStoreNumber {
    public String storeID;
    public boolean onlineStoreFront;
    public int usStoreID;
}
