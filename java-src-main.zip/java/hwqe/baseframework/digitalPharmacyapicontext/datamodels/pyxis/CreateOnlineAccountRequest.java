package hwqe.baseframework.digitalPharmacyapicontext.datamodels.pyxis;

@lombok.Getter
@lombok.Setter
public class CreateOnlineAccountRequest {
    public InStoreOnlineAccountPayload payload;
}
