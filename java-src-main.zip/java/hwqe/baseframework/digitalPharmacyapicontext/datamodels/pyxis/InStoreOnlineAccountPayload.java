package hwqe.baseframework.digitalPharmacyapicontext.datamodels.pyxis;

@lombok.Getter
@lombok.Setter
public class InStoreOnlineAccountPayload {
/*    {
            "payload": {
            "customerEmailId": "testacc4hw@walmart.com",
                    "customerDOB": "1998-01-01",
                    "firstName": "Tim",
                    "lastName": "Budheseim",
                    "storeNumber": {
                "USStoreId": "5597"
            },
            "storePatientId": "132910",
                    "idValidated": true,
                    "postalAddress": {
                "addressLineOne": "805 Moberly ln",
                        "addressLineTwo": "",
                        "city": "Bentonville",
                        "countryCode": "US",
                        "postalCode": "72716"
            },
            "photoId": {
                "photoIdType": "DRV",
                        "photoIdNumber": "90808567456567",
                        "photoIdState": "CA",
                        "photoIdCountry": "US",
                        "photoIdExpirationDate": "06-22-2025"
            }
        }
    }*/
    public String customerEmailId;
    // Format Mandatory YYYY-MM-DD
    public String customerDOB;
    public String firstName;
    public String lastName;
    public StoreId storeNumber;
    public String storePatientId;
    public boolean isValidated;
    public AddressModel postalAddress;
    public PhotoIdModel photoId;
}
