package hwqe.baseframework.digitalPharmacyapicontext.datamodels.pyxis;

@lombok.Getter
@lombok.Setter
public class PhotoIdModel {
    public String photoIdType;
    public String photoIdNumber;
    public String photoIdState;
    public String photoIdCountry;
    public String photoIdExpirationDate;
}
