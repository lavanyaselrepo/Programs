package hwqe.baseframework.digitalPharmacyapicontext.datamodels.enums;

/**
 * Enum representing different workqueue statuses for prescriptions in the Digital Pharmacy system
 */
public enum RxWorkqueueStatus {
    /**
     * Ready For Pickup - Prescription is filled and ready for customer pickup
     */
    RFP("RFP", "Ready For Pickup"),
    
    /**
     * End of Day - Prescription moved to end of day processing
     */
    EOD("EOD", "End Of Day"),
    
    /**
     * In Filling - Prescription is currently being filled
     */
    FILLING("FILLING", "In Filling");
    
    private final String code;
    private final String displayName;
    
    RxWorkqueueStatus(String code, String displayName) {
        this.code = code;
        this.displayName = displayName;
    }
    
    /**
     * Get the code value of the Rx workqueue status
     * @return String code representation of the status
     */
    public String getCode() {
        return code;
    }
    
    /**
     * Get the display name of the Rx workqueue status
     * @return String display name of the status
     */
    public String getDisplayName() {
        return displayName;
    }
    
    /**
     * Get RxWorkqueueStatus from code value
     * @param code String code to convert
     * @return Corresponding RxWorkqueueStatus enum
     * @throws IllegalArgumentException if code is not recognized
     */
    public static RxWorkqueueStatus fromCode(String code) {
        for (RxWorkqueueStatus status : RxWorkqueueStatus.values()) {
            if (status.getCode().equalsIgnoreCase(code)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Unknown Rx workqueue status code: " + code);
    }
    
    @Override
    public String toString() {
        return code;
    }
}
