package hwqe.baseframework.digitalPharmacyapicontext.datamodels.enums;

/**
 * Enum representing different types of patients in the Digital Pharmacy system
 */
public enum PatientType {
    /**
     * Adult patient (18+ years old)
     */
    ADULT("ADULT"),
    
    /**
     * Minor patient (under 18 years old)
     */
    MINOR("MINOR"),
    
    /**
     * Pet patient
     */
    PET("PET");
    
    private final String value;
    
    PatientType(String value) {
        this.value = value;
    }
    
    /**
     * Get the string value of the patient type
     * @return String representation of the patient type
     */
    public String getValue() {
        return value;
    }
    
    /**
     * Get PatientType from string value
     * @param value String value to convert
     * @return Corresponding PatientType enum
     * @throws IllegalArgumentException if value is not recognized
     */
    public static PatientType fromValue(String value) {
        for (PatientType type : PatientType.values()) {
            if (type.getValue().equalsIgnoreCase(value)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown patient type: " + value);
    }
    
    @Override
    public String toString() {
        return value;
    }
}
