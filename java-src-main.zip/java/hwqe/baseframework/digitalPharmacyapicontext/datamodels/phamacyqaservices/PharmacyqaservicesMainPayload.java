package hwqe.baseframework.digitalPharmacyapicontext.datamodels.phamacyqaservices;

@lombok.Setter
@lombok.Getter
public class PharmacyqaservicesMainPayload {
    public String[] customerAccountIds;
}
