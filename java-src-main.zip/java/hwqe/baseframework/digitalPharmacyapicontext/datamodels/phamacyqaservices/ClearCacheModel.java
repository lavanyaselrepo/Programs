package hwqe.baseframework.digitalPharmacyapicontext.datamodels.phamacyqaservices;

@lombok.Setter
@lombok.Getter
public class ClearCacheModel {
    public PharmacyqaservicesMainPayload payload;
}
