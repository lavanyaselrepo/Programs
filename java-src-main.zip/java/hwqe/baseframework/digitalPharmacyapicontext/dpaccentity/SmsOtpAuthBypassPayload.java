package hwqe.baseframework.digitalPharmacyapicontext.dpaccentity;

import hwqe.baseframework.digitalPharmacyapicontext.datamodels.dpaccentity.CustomerInfoRequestPayload;

@lombok.Getter
@lombok.Setter
public class SmsOtpAuthBypassPayload {
    public CustomerInfoRequestPayload customerInfo;
    public String accountCreationSource;
}
