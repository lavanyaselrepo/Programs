package hwqe.baseframework.digitalPharmacyapicontext.dpaccentity;
@lombok.Getter
@lombok.Setter
public class CustomerInfo {

    public String storeNbr="5522";
    public String patientId;
    public String dob;

}
