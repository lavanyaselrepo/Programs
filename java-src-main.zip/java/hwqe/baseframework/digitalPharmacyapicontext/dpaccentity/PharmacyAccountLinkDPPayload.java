package hwqe.baseframework.digitalPharmacyapicontext.dpaccentity;

import hwqe.baseframework.digitalPharmacyapicontext.datamodels.dpaccentity.CustomerInfo;

@lombok.Getter
@lombok.Setter
public class PharmacyAccountLinkDPPayload {

    public CustomerInfo customerInfo;
    public String accountCreationSource="smsOtpVerification";
}
