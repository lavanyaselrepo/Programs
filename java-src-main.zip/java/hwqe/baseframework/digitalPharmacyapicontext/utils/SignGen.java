package hwqe.baseframework.digitalPharmacyapicontext.utils;

import hwqe.baseframework.utilities.PropertyReader;

import java.io.ObjectStreamException;
import java.security.KeyRep;
import java.security.PrivateKey;
import java.security.Signature;
import java.util.*;

public class SignGen {

    PropertyReader prop = PropertyReader.getInstance();
    public SignGen(){}

    public HashMap<String, String> generateTimeBasedSign(String consumerId, String privateKey){
        {
            HashMap<String, String> returnValues = new HashMap<>();
            SignGen generator = new SignGen();

            String privateKeyVersion = "1";

            long inTimestamp = System.currentTimeMillis();

            Map<String, String> map = new HashMap<>();
            map.put("WM_CONSUMER.ID", consumerId);
            map.put("WM_CONSUMER.INTIMESTAMP", Long.toString(inTimestamp));
            map.put("WM_SEC.KEY_VERSION", privateKeyVersion);

            String[] array = canonicalize(map);

            String data = null;

            try {
                data = generator.generateSignature(privateKey, array[1]);
            } catch(Exception e) {
                e.printStackTrace();
            }
            returnValues.put("Intimestamp", inTimestamp+"");
            returnValues.put("Signature", data);
            return returnValues;
        }
    }

    public HashMap<String, String> generateTimeBasedSign(String consumerId){
        {
            return generateTimeBasedSign(consumerId, prop.getProperty("dp.account.orchestrator.service.private.key"));
        }
    }

    public HashMap<String, String> generateTimeBasedSignValidateDOB(String consumerId) {
        {
            HashMap<String, String> returnValues = new HashMap<>();
            SignGen generator = new SignGen();
            String key = prop.getProperty("dp.account.orchestrator.service.private.key");
            //String consumerId = "74dda87f-5549-4510-a9a0-247420a35523";

            String privateKeyVersion = "1";

            String privateKey = key;

            long inTimestamp = System.currentTimeMillis();

            Map<String, String> map = new HashMap<>();
            map.put("WM_CONSUMER.ID", consumerId);
            map.put("WM_CONSUMER.INTIMESTAMP", Long.toString(inTimestamp));
            map.put("WM_SEC.KEY_VERSION", privateKeyVersion);

            String[] array = canonicalize(map);

            String data = null;

            try {
                data = generator.generateSignature(privateKey, array[1]);
            } catch (Exception e) {
                e.printStackTrace();
            }
            returnValues.put("Intimestamp", inTimestamp + "");
            returnValues.put("Signature", data);
            return returnValues;
        }
    }

    public String generateSignature(String key, String stringToSign) throws Exception {
        Signature signatureInstance = Signature.getInstance("SHA256WithRSA");

        ServiceKeyRep keyRep = new ServiceKeyRep(KeyRep.Type.PRIVATE, "RSA", "PKCS#8", Base64.getDecoder().decode(key));

        PrivateKey resolvedPrivateKey = (PrivateKey) keyRep.readResolve();

        signatureInstance.initSign(resolvedPrivateKey);

        byte[] bytesToSign = stringToSign.getBytes("UTF-8");
        signatureInstance.update(bytesToSign);
        byte[] signatureBytes = signatureInstance.sign();

        String signatureString = Base64.getEncoder().encodeToString(signatureBytes);

        return signatureString;
    }

    protected static String[] canonicalize(Map<String, String> headersToSign) {
        StringBuffer canonicalizedStrBuffer=new StringBuffer();
        StringBuffer parameterNamesBuffer=new StringBuffer();
        Set<String> keySet=headersToSign.keySet();

        // Create sorted key set to enforce order on the key names
        SortedSet<String> sortedKeySet=new TreeSet<>(keySet);
        for (String key :sortedKeySet) {
            Object val=headersToSign.get(key);
            parameterNamesBuffer.append(key.trim()).append(";");
            canonicalizedStrBuffer.append(val.toString().trim()).append("\n");
        }

        return new String[] {parameterNamesBuffer.toString(), canonicalizedStrBuffer.toString()};
    }

    class ServiceKeyRep extends KeyRep	{
        private static final long serialVersionUID = -7213340660431987616L;

        public ServiceKeyRep(Type type, String algorithm, String format, byte[] encoded) {
            super(type, algorithm, format, encoded);
        }

        protected Object readResolve() throws ObjectStreamException {
            return super.readResolve();
        }
    }

    public HashMap<String, String> generateTimeBasedSignForCart(String consumerId){
        {
            HashMap<String, String> returnValues = new HashMap<>();
            SignGen generator = new SignGen();
            String key = prop.getProperty("cart.account.orchestrator.service.private.key");

            String privateKeyVersion = "1";

            String privateKey = key;

            long inTimestamp = System.currentTimeMillis();

            Map<String, String> map = new HashMap<>();
            map.put("WM_CONSUMER.ID", consumerId);
            map.put("WM_CONSUMER.INTIMESTAMP", Long.toString(inTimestamp));
            map.put("WM_SEC.KEY_VERSION", privateKeyVersion);

            String[] array = canonicalize(map);

            String data = null;

            try {
                data = generator.generateSignature(privateKey, array[1]);
            } catch(Exception e) {
                e.printStackTrace();
            }
            returnValues.put("Intimestamp", inTimestamp+"");
            returnValues.put("Signature", data);
            return returnValues;
        }
    }


}