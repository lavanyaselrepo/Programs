package hwqe.baseframework.imzappcontext;

import hwqe.baseframework.interfaces.IMobileApp;
import hwqe.baseframework.utilities.PropertyReader;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.net.URL;
import java.util.Random;

public class ImzAppManager implements IMobileApp {
    AndroidDriver appDriver;
    PropertyReader rdr = PropertyReader.getInstance();

    @Override
    public AndroidDriver getDriver() {
        return appDriver;
    }

    @Override
    public boolean launchMobileApp() {
        rdr.loadCustomProperties("config/imzapp/");
        launchMobileApp(rdr.getProperty("imzapp.udid"));
        return true;
    }

    public boolean launchMobileApp(String udid) {
        try {
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("noReset", true);
            capabilities.setCapability("platformVersion", rdr.getProperty("imzapp.android_version"));
            capabilities.setCapability("deviceName", rdr.getProperty("imzapp.device_name"));
            capabilities.setCapability("udid", udid);
            capabilities.setCapability("automationName", "UiAutomator2");
            capabilities.setCapability("platformName", rdr.getProperty("imzapp.platform_name"));
            capabilities.setCapability("appPackage", rdr.getProperty("imzapp.package_name"));
            capabilities.setCapability("appActivity", rdr.getProperty("imzapp.main_activity"));
            appDriver = new AndroidDriver(new URL(rdr.getProperty("app.appiumServer")), capabilities);
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    @Override
    public String takeScreenShot(String fileName) {
        try {
            Random r = new Random();
            File savedFile = new File(rdr.getProperty("app.workingfolder_path") + fileName + "_" + r.nextInt(9999) + ".png");
            FileUtils.copyFile(this.appDriver.getScreenshotAs(OutputType.FILE), savedFile);
            return savedFile.getPath();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean closeMobileApp() {
        return false;
    }

    @Override
    public void switchWindow() {

    }
}
