package hwqe.baseframework.models.datamodels;

public class Rx {
    private int rx_nbr;
    private int rx_fill_id;

    public int getRx_fill_id() {
        return rx_fill_id;
    }

    public void setRx_fill_id(int rx_fill_id) {
        this.rx_fill_id = rx_fill_id;
    }


    public int getRx_nbr() {
        return rx_nbr;
    }

    public void setRx_nbr(int rx_nbr) {
        this.rx_nbr = rx_nbr;
    }

    public String getRxNbrAsString() {
        return Integer.toString(rx_nbr);
    }

}
