package hwqe.baseframework.models.datamodels;

import lombok.Data;
import lombok.Getter;

@Data
public class TestResults {
    public int skippedTests = 0;
    public int failedTests = 0;
    // Getter for passedTests
    @Getter
    public int passedTests = 0;
    public int abortedTests = 0;

    public String getPassPercentage() {
        return String.format("%.2f", ((float) passedTests / (float) (failedTests + passedTests)) * (float) 100);
    }

    public int getTotalTests() {
        return skippedTests + failedTests + passedTests + abortedTests;
    }



}
