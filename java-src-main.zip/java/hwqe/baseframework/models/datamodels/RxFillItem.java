package hwqe.baseframework.models.datamodels;

public class RxFillItem {
    private int rx_fill_id;
    private int item_mds_fam_id;
    private double usual_cost_amt;
    private double actual_cost_amt;
    private int fill_item_qty;
    private int item_seq_nbr;

    public int getRx_fill_id() {
        return rx_fill_id;
    }

    public void setRx_fill_id(int rx_fill_id) {
        this.rx_fill_id = rx_fill_id;
    }

    public int getItem_mds_fam_id() {
        return item_mds_fam_id;
    }

    public void setItem_mds_fam_id(int item_mds_fam_id) {
        this.item_mds_fam_id = item_mds_fam_id;
    }

    public double getUsual_cost_amt() {
        return usual_cost_amt;
    }

    public void setUsual_cost_amt(double usual_cost_amt) {
        this.usual_cost_amt = usual_cost_amt;
    }

    public double getActual_cost_amt() {
        return actual_cost_amt;
    }

    public void setActual_cost_amt(double actual_cost_amt) {
        this.actual_cost_amt = actual_cost_amt;
    }

    public int getFill_item_qty() {
        return fill_item_qty;
    }

    public void setFill_item_qty(int fill_item_qty) {
        this.fill_item_qty = fill_item_qty;
    }

    public int getItem_seq_nbr() {
        return item_seq_nbr;
    }

    public void setItem_seq_nbr(int item_seq_nbr) {
        this.item_seq_nbr = item_seq_nbr;
    }
}
