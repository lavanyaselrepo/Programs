package hwqe.baseframework.models.datamodels.vaults;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Metadata {
    private String username;

}
