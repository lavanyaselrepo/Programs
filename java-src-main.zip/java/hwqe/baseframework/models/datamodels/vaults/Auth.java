package hwqe.baseframework.models.datamodels.vaults;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
public class Auth {
    private String client_token;
    private String accessor;
    private List<String> policies;
    private List<String> token_policies;
    private Metadata metadata;
    private int lease_duration;
    private boolean renewable;
    private String entity_id;
    private String token_type;
    private boolean orphan;
    private Object mfa_requirement;
    private int num_uses;
}
