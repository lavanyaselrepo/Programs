package hwqe.baseframework.models.datamodels.vaults;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LDAPAuthResponse {
    private String request_id;
    private String lease_id;
    private boolean renewable;
    private int lease_duration;
    private Object data;
    private Object wrap_info;
    private Object warnings;
    private Auth auth;
}
