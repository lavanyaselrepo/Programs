package hwqe.baseframework.models.datamodels;

public class IntWrapper {
    private int value;

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

}
