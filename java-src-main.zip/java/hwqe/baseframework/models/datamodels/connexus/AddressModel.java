package hwqe.baseframework.models.datamodels.connexus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddressModel {
    private String patientAddressLine1;
    private String patientAddressLine2;
    private String patientCity;
    private String patientState;
    private String patientZipCode;
    private String patientCountry;
}
