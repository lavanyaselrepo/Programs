package hwqe.baseframework.models.datamodels.connexus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactModel {
    private String patientPhoneNumber1;
    private String patientPhoneNumber2;
    private String patientPhoneNumber3;
    private String patientPrimaryNumber;
    private String patientAlternateNumber;
    private String patientMessagingNumber;
    private String clinicalServicesNumber;
    private PreferredPhoneNumber preferredPhoneNumber;

    public enum PreferredPhoneNumber {
        PHONE_NUMBER1,
        PHONE_NUMBER2,
        PHONE_NUMBER3,
        PRIMARY_NUMBER,
        ALTERNATE_NUMBER,
        MESSAGING_NUMBER,
        CLINICAL_SERVICE_NUMBER
    }
}
