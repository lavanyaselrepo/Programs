package hwqe.baseframework.models.datamodels.connexus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ImzEventModel {
    private String imzEventName;
    private String imzOrganizationName;
    private String phoneNumber;
    private String imzDob;
    private AddressInfo Address;

}
