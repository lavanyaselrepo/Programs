package hwqe.baseframework.models.datamodels.connexus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PrescriberModel {
    private String prescriberFirstName;
    private String prescriberLastName;
    private String prescriberMiddleName;
    private String prescriberLabelName;
}
