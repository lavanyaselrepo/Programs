package hwqe.baseframework.models.datamodels.connexus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RxModel {
    private String patientFirstName;
    private String patientLastName;
    private String ndc;
    private String prescribedQty;
    private String sigCode;
    private String noOfRefills;
    private String prescriberName;
    private String prescriberDeaType;
    private String dxCode;
    private String rxComment;
    private String expandedSig;
    private String days;
    private String compoundDrugName;
    private boolean isCompoundDrug;
}
