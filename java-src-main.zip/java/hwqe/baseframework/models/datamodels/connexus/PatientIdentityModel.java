package hwqe.baseframework.models.datamodels.connexus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PatientIdentityModel {
    private String patientDrivingLicenseNumber;
    private String patientDrivingLicenseState;
    private String drivingLicenseExpiryDate;
    private long patientSSNNumber;
}
