package hwqe.baseframework.models.datamodels.connexus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductApiPayLoadModel {
    private String productName;
    private String ndcNbr;
    private String genericName;
    private String gpi;
    private String strength;
    private String upcNumber;
    private String itemNumber;
    private String singleLikeFlag;
}
