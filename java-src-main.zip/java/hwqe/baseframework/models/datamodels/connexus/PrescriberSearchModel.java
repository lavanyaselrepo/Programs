package hwqe.baseframework.models.datamodels.connexus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PrescriberSearchModel {
    private String prescriberName;
    private String prescriberNPI;
    private String prescriberDEA;
    private String prescriberDegree;
    private String prescriberPhoneNumber;
    private String prescriberState;
    private String prescriberFax;


    public enum PrescriberInputValues {
        PRESCRIBER_NAME,
        PRESCRIBER_NPI,
        PRESCRIBER_DEA,
        PRESCRIBER_PHONE,
        PRESCRIBER_FAX,
        PRESCRIBER_DEGREE,
        PRESCRIBER_STATE,
        PRESCRIBER_NAMEANDSTATE,
        PRESCRIBER_NPIANDSTATE,
        PRESCRIBER_DEAANDSTATE,
        PRESCRIBER_NAMEANDDEGREE,
        PRESCRIBER_NPIANDDEGREE,
        PRESCRIBER_DEAANDDEREE,
        SearchPrescriber_enter3LetterforLNFNMN,
        SearchPrescriber_enter1LetterforMN,
        SearchPrescriber_enter2LetterforMN,
        SearchPrescriber_enter3LetterforMN,
        SearchPrescriber_enter3LetterforOnlyLNFN,
        SearchPrescriber_enterFullNameforLNFN,
        SearchPrescriber_enter3LetterforLNFN,
        SearchPrescriber_enterFullName,
        SearchPrescriber_enter3LNFNand1MN,
        SearchPrescriber_enter3LNFNand2MN
    }
}
