package hwqe.baseframework.models.datamodels.connexus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductApiResponseModel {
    private String productMdsFamId;
    private String shortName;
    private String genericDrugName;
    private String innerPackQty;
    private String ndcNbr;
    private String upcNbr;
    private String itemNbr;
    private String gpiCode;
    private String drugStrengthCode;
    private String itemExpDate;
    private String itemEffDate;
}
