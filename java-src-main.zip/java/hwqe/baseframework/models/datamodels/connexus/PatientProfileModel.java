package hwqe.baseframework.models.datamodels.connexus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PatientProfileModel {
    private String patientFirstName;
    private String patientLastName;
    private String patientMiddleName;
    private String patientDob;
    private String patientInsulinInd;
    private String patientAllergy;
    private String patientMedicalCondition;
    private AddressModel patientAddress;
    private ThirdPartyModel patientTp;
    private PatientType patientType;
    private PetLiveStockInfo petLiveStockInfo;
    private PatientGender patientGender;
    private ContactModel patientContact;
    private PatientIdentityModel patientIdentityModel;
    private PatientMedicalConditionModel patientMedicalConditionModel;

    public enum PatientGender {
        MALE,
        FEMALE
    }

    public enum PatientType {
        HUMAN,
        PET,
        LIVESTOCK
    }

    public enum PetLiveStockInfo {
        CANINE,
        FALINE,
        EQUINE,
        BOVINE,
        OTHER
    }
}
