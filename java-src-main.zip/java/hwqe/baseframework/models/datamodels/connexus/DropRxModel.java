package hwqe.baseframework.models.datamodels.connexus;

import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuscontext.RxOriginType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DropRxModel {
    private String patientFirstName;
    private String patientLastName;
    private int noOfRx;
    private Priority priority;
    private RxOriginType rxOriginType;
    private String orderComment;
    private String dob;
}


