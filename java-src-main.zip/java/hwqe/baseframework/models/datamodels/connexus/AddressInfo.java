package hwqe.baseframework.models.datamodels.connexus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddressInfo {

    private String AddressLine1;
    private String City;
    private String State;
    private String ZipCode;
    private String Country;

}
