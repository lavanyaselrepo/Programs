package hwqe.baseframework.models.datamodels.connexus;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PatientMedicalConditionModel {
    private Allergies allergies;
    private MedicalCondition medicalCondition;

    public enum Allergies {
        YES,
        NO,
        PATIENT_NOT_PRESENT
    }

    public enum MedicalCondition {
        YES,
        NO,
        PATIENT_NOT_PRESENT
    }
}


