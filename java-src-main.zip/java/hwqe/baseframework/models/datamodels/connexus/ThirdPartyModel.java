package hwqe.baseframework.models.datamodels.connexus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ThirdPartyModel {
    private String carrierBin;
    private String plan;
    private String cardId;
    private String carrierBin2;
    private String plan2;
    private String cardId2;
    private String carrierBin3;
    private String plan3;
    private String cardId3;
}
