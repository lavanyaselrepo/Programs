package hwqe.baseframework.models.datamodels.curbsideDispense;


public class PatientProfileModel {

    private String legalLastName;
    private String legalFirstName;
    private String gender;
    private String dob;
    private String homeAddress;
    private String postalCode;
    private String city;
    private String country;
    private String state;
    private String id;
    private String idType;
    private String primaryPhone;
    private String carType;
    private String carColor;
    private String rx;
    private String pickupPerson;

    public String getLegalLastName() {
        return legalLastName;
    }

    public void setLegalLastName(String legalLastName) {
        this.legalLastName = legalLastName;
    }

    public String getLegalFirstName() {
        return legalFirstName;
    }

    public void setLegalFirstName(String legalFirstName) {
        this.legalFirstName = legalFirstName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getHomeAddress() {
        return homeAddress;
    }

    public void setHomeAddress(String homeAddress) {
        this.homeAddress = homeAddress;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPrimaryPhone() {
        return primaryPhone;
    }

    public void setPrimaryPhone(String primaryPhone) {
        this.primaryPhone = primaryPhone;
    }

    public String getCarColor() {
        return carColor;
    }

    public void setCarColor(String _carColor) {
        this.carColor = _carColor;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String _carType) {
        this.carType = _carType;
    }

    public String getRx() {
        return rx;
    }

    public void setRx(String _rx) {
        this.rx = _rx;
    }

    public String getPickupPerson() {
        return pickupPerson;
    }

    public void setPickupPerson(String _pickupPerson) {
        this.pickupPerson = _pickupPerson;
    }
}
