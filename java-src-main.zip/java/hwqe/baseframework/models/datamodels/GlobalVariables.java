package hwqe.baseframework.models.datamodels;

import java.io.File;

public class GlobalVariables {
    public static  final String executionconfigpath = "config"+File.separator+"executionconfig"+File.separator;
    private static  String browserversion;
    private static String browserName;
    private static String browserType;
    public void setBrowserversion(String browserversion) {
        this.browserversion = browserversion;
    }
    public void setBrowserName(String browserName) {
        this.browserName = browserName;
    }
    public String getBrowserversion(){
        return browserversion;
    }
    public String getBrowserName(){
        return browserName;
    }
    public void setBrowserType(String browserType){
        this.browserType = browserType;
    }
    public String getBrowserType(){
        return  browserType;
    }
}
