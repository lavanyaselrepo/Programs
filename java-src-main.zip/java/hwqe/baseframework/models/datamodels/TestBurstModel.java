package hwqe.baseframework.models.datamodels;

import java.time.Duration;

@lombok.Setter
@lombok.Getter
public class TestBurstModel {
    String runId;
    String testId;
    String testCaseName;
    String testDescription;
    String testSuite;
    String testCategory;

    String business;
    String domain;
    String appName;
    String testType;

    Long startMillis;
    Long endMillis;

    public String getDuration() {
        return Duration.ofMillis(endMillis - startMillis).getSeconds() + " sec";
    }

    public String getTestId() {
        return String.valueOf(System.currentTimeMillis());
    }
}
