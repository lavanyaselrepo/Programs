package hwqe.baseframework.models.datamodels;

public enum Environment {
    DEV,
    QE,
    QA,
    STG,
    UAT,
    PROD
}
