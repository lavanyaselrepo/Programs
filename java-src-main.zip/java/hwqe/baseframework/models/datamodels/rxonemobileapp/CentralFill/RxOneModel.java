package hwqe.baseframework.models.datamodels.rxonemobileapp.CentralFill;

public class RxOneModel {
    private String bagNo;

    private String asnNo;

    public String getBagNo() {
        return bagNo;
    }

    public String getAsnNo() {
        return asnNo;
    }


    public void setBagNo(String bagNum) {
        this.bagNo = bagNum;
    }

    public void setAsnNo(String asnNum) {
        this.asnNo = asnNum;
    }

}


