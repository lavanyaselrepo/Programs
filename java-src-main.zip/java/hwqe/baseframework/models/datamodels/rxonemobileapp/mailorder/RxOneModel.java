package hwqe.baseframework.models.datamodels.rxonemobileapp.mailorder;

public class RxOneModel {
    private String bagNo;
    private String ndcNumber;
    private String printerName;
    private String trackingNumber;
    private String asnNo;

    public String getBagNo() {
        return bagNo;
    }
    public String getAsnNo() {
        return asnNo;
    }
    public String getTrackingNo(){
        return trackingNumber;
    }
    public void setTrackingNumber(String trackingNumber) { this.bagNo = trackingNumber; }

    public void setBagNo(String bagNum) { this.bagNo = bagNum; }

    public void setAsnNo(String asnNum) { this.asnNo = asnNum; }

    public String getNdcNumber() {
        return ndcNumber;
    }

    public void setNdcNumber(String ndcNumber) { this.ndcNumber = ndcNumber; }

    public String getPrinterName() {
        return printerName;
    }

    public void setPrinterName(String printerName) { this.printerName = printerName; }
}
