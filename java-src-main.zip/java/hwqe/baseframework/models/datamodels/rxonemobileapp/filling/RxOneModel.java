package hwqe.baseframework.models.datamodels.rxonemobileapp.filling;

public class RxOneModel {
    private String bagNo;
    private String ndcNumber;
    private String printerName;

    public String getBagNo() {
        return bagNo;
    }

    public void setBagNo(String bagNo) { this.bagNo = bagNo; }

    public String getNdcNumber() {
        return ndcNumber;
    }

    public void setNdcNumber(String ndcNumber) { this.ndcNumber = ndcNumber; }

    public String getPrinterName() {
        return printerName;
    }

    public void setPrinterName(String printerName) { this.printerName = printerName; }
}
