package hwqe.baseframework.models.datamodels.cosmos;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Builder
@Data
public class TestRecord {
    private String id;
    private Integer totalTests;
    private Integer passedTests;
    private Integer skippedTests;
    private Integer failedTests;
    private String userId;
    private String cnxVersion;
    private Integer runNumber;
    private String reportLink;
    private String parentId;
    private long startTime;
    private String suiteName;
    private String suiteStatus;
    private Integer siteId;
    private Integer passPercentage;
    private String targetRXPC;
    private long _ts;
    private List<String> failedTestCase;
    private List<String> passTestCase;
    private String xmlPath;
    private String targetConfigEnv;
    
    // Indicates whether automationMetadataJson was provided via CLI (true) or auto-generated (false)
    private Boolean isMetadataGiven;

    // URL to maven output log file stored in Azure Blob Storage (set by cnx-wrapper after upload)
    private String logFileUrl;
}
