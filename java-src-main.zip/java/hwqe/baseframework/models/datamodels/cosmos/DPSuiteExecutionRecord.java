package hwqe.baseframework.models.datamodels.cosmos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DPSuiteExecutionRecord {
    private String id;
    private String suiteName;
    private List<DPSuiteExecutionResults> testCases;
}
