package hwqe.baseframework.models.datamodels.cosmos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DPSuiteExecutionResults {
    private String methodName;
    private String className;
    private String status;
}
