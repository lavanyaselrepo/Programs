package hwqe.baseframework.models.datamodels.enums;

import java.util.Optional;

public enum VaccineGroup {
    DTaP_Tdap_Td("DTaP/Tdap/Td"),
    HepB("HepB"),
    Pneumococcal("Pneumococcal"),
    Zoster("Zoster"),
    Influenza("Influenza"),
    COVID_19("COVID-19"),
    RSV("RSV"),
    Polio("Polio"),
    HepA("HepA"),
    MMR("MMR"),
    Varicella("Varicella"),
    HPV("HPV"),
    Meningococcal("Meningococcal"),
    Meningococcal_B("Meningococcal B");

    private final String value;

    VaccineGroup(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
    public static Optional<VaccineGroup> fromValue(String value) {
        for (VaccineGroup vaccineGroup : VaccineGroup.values()) {
            if (vaccineGroup.getValue().equalsIgnoreCase(value)) {
                return Optional.of(vaccineGroup);
            }
        }
        return Optional.empty();
    }
}