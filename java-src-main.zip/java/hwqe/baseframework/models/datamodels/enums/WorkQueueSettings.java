package hwqe.baseframework.models.datamodels.enums;

import java.util.HashMap;

public enum WorkQueueSettings {

    NoStations(-1),
    DropOff(1),
    Input(2),
    Counseling(3),
    MobileCounseling(44),
    WorkQueueFill(4),
    wm4PointCheck(5),
    Pickup(6),
    TroubleShooting(7),
    ThirdParty(8),
    DrugUtilization(9),
    VisualVerify(10),
    ModifyDetail(11),
    CheckDUR(12),
    reprint(13),
    TroubleShootingEdit(25),
    TroubleShootingNonEdit(26),
    RxLookup(50),
    ModifyTPExtraInfo(70),
    POS(15),
    EOD(16),
    Report(71),
    DoubleCheck4Point(17),
    WillCallBinRecon(26),
    DownTimeReversal(27),
    ElectronicRequest(18),
    TroubleShootingSTS(29),
    CanadaPaperBillBatch(19),
    NetworkDUR(30),
    OrderDetail(77),
    Bagging(28),
    CashOnNetwork(31),
    ServiceAdministration(22),
    ClinicalIntelligence(21),
    IMZReporting(23),
    NameChange(131),
    DecisionRx(24),
    CFEligCheck(32),
    ReturnToStock(20),
    BeaconPickup(78),
    Filling(4);

    private final int value;

    private static HashMap<Integer, WorkQueueSettings> workQueueSettingMap = new HashMap<>();

    static{
        for(WorkQueueSettings wq : WorkQueueSettings.values()){
            workQueueSettingMap.put(wq.value, wq);
        }
    }

    public static WorkQueueSettings valueOf(int value){
        if (workQueueSettingMap.containsKey(value)) {
            return workQueueSettingMap.get(value);
        } else {
            throw new IllegalArgumentException("Invalid numeric value for WorkQueue Enum: " + value);
        }
    }

    WorkQueueSettings(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
