package hwqe.baseframework.models.pageobjectmodels;

/*
 * *********************************************************************************************************************************************************
 * Page Name - AndroidBasePage
 * Description: This class, AndroidBasePage, serves as an abstract base for Android test automation, providing common utility methods for interacting with mobile elements, handling gestures, taking screenshots, performing actions like clicks or text input,
 *  scrolling, and managing element states in an Android app using Appium.
 * Author: Neeharika Verma
 * *********************************************************************************************************************************************************
 */
import hwqe.baseframework.utilities.PropertyReader;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.MobileBy;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import javafx.util.Pair;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public abstract class AndroidBasePage {
    PropertyReader prop = PropertyReader.getInstance();
    private AndroidDriver androidDriver;
    private WebDriverWait webWait;
    private Actions action;

    public AndroidBasePage(AndroidDriver androidDriver) {
        this.androidDriver = androidDriver;
        this.webWait = new WebDriverWait(this.androidDriver, Duration.ofMinutes(Integer.parseInt(prop.getProperty("app.mobile_wait"))));
        this.action = new Actions(this.androidDriver);
    }

    public boolean isElementDisplayed(By elementIdentifier, int waitTimeInSeconds) {
        try {
            new WebDriverWait(this.androidDriver, Duration.ofMinutes(waitTimeInSeconds)).until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public boolean isElementDisplayed(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public Pair<String, String> takeScreenShot(String fileName) {
        try {
            Random r = new Random();
            String fName = fileName + "_" + r.nextInt(9999) + ".png";
            File savedFile = new File(prop.getProperty("app.workingfolder_path") + fName);
            FileUtils.copyFile(this.androidDriver.getScreenshotAs(OutputType.FILE), savedFile);
            return new Pair<>(fName, savedFile.getPath());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public String takeScreenShot() {
        try {
            File savedFile = new File(prop.getProperty("app.workingfolder_path") + java.util.UUID.randomUUID() + ".png");
            FileUtils.copyFile(this.androidDriver.getScreenshotAs(OutputType.FILE), savedFile);
            return savedFile.getPath();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public boolean sendHotKeys(String hotKeys) {
        return this.performHotKey(hotKeys);
    }

    public boolean sendHotKeys(String commands, Keys... key) {
        commands += Keys.chord(key);
        return this.performHotKey(commands);
    }

    public WebElement getNthListElement(By list, By seekElement, int n, ListOrientation orientation) {
        List<WebElement> foundElements = androidDriver.findElements(seekElement);
        Rectangle listRect = androidDriver.findElements(list).get(0).getRect();
        while (foundElements.size() < n) {
            if (orientation == ListOrientation.Horizontal) {
                swipeLeft(listRect);
            } else {
                swipeUp(listRect);
            }
            for (WebElement e : androidDriver.findElements(seekElement)) {
                if (!foundElements.stream().map(WebElement::getText).collect(Collectors.toList()).contains(e.getText())) {
                    foundElements.add(e);
                }
            }
        }
        return foundElements.get(n - 1);
    }

    private void swipeUp(Rectangle scrollInside) {
        int centre = scrollInside.x + (scrollInside.width / 2);
        int startPoint = scrollInside.y + scrollInside.height - 1;
        int endPoint = scrollInside.y;
        performSwipe(centre, startPoint, centre, endPoint);
    }

    private void swipeRight(Rectangle scrollInside) {
        int centre = scrollInside.y + (scrollInside.height / 2);
        int startPoint = scrollInside.x;
        int endPoint = scrollInside.x + scrollInside.width - 1;
        performSwipe(startPoint, centre, endPoint, centre);
    }

    private void swipeDown(Rectangle scrollInside) {
        int centre = scrollInside.x + (scrollInside.width / 2);
        int startPoint = scrollInside.y;
        int endPoint = scrollInside.y + scrollInside.height - 1;
        performSwipe(centre, startPoint, centre, endPoint);
    }

    private void swipeLeft(Rectangle scrollInside) {
        int centre = scrollInside.y + (scrollInside.height / 2);
        int startPoint = scrollInside.x + scrollInside.width - 1;
        int endPoint = scrollInside.x;
        performSwipe(startPoint, centre, endPoint, centre);
    }

    private void performSwipe(int startX, int startY, int endX, int endY) {
        TouchAction touchAction = new TouchAction(androidDriver);
        touchAction.press(PointOption.point(startX, startY))
                .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
                .moveTo(PointOption.point(endX, endY))
                .release()
                .perform();
    }

    public boolean sendHotKeys(Keys... key) {
        return this.performHotKey(Keys.chord(key));
    }

    private boolean performHotKey(String command) {
        try {
            action.sendKeys(command).build().perform();
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public boolean sendText(By elementIdentifier, String textValue) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            androidDriver.findElement(elementIdentifier).sendKeys(textValue);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public String getText(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            return androidDriver.findElement(elementIdentifier).getText();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    public boolean click(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            androidDriver.findElement(elementIdentifier).click();
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public boolean selectListItem(By elementIdentifier, int indexOfValue) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            androidDriver.findElement(elementIdentifier).click();
            String keys = "";
            for (int i = 0;i < indexOfValue;i++) {
                keys = keys + Keys.ARROW_DOWN;
            }
            keys = keys + Keys.ENTER;
            performHotKey(keys);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public String getValueFromAttribute(By elementIdentifier, Attribute attr) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            switch (attr) {
                case AutomationId:
                    return androidDriver.findElement(elementIdentifier).getAttribute("AutomationId");
                case Name:
                    return androidDriver.findElement(elementIdentifier).getAttribute("Name");
                case ClassName:
                    return androidDriver.findElement(elementIdentifier).getAttribute("ClassName");
                case IsEnabled:
                    return androidDriver.findElement(elementIdentifier).getAttribute("IsEnabled");
                case Enabled:
                    return androidDriver.findElement(elementIdentifier).getAttribute("Enabled");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    public boolean selectListItem(By elementIdentifier, String value) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            androidDriver.findElement(elementIdentifier).click();
            androidDriver.findElement(elementIdentifier).findElement(By.name(value)).click();
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }


    public boolean selectListItem(By parent, By target) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(parent));
            List<WebElement> lstElements = androidDriver.findElements(parent);
            for (WebElement ele : lstElements) {
                ele.findElement(target).click();
            }
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public boolean selectListItem(By parent, By targetSelector, By conditionalSelector, String conditionalValue) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(parent));
            List<WebElement> lstElements = androidDriver.findElements(parent);
            for (WebElement ele : lstElements) {
                if (ele.findElement(conditionalSelector).getText().equalsIgnoreCase(conditionalValue)) {
                    ele.findElement(targetSelector).click();
                    break;
                }
            }
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    /**
     * Function Name - getCount()
     * Description: This method is to get the count from the list of a an element
     * Inputs : elementIdentifier
     * returns: count in Int
     */

    public int getCount(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            return androidDriver.findElements(elementIdentifier).size();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return 0;

    }

    /**
     * Method to Scoll the page to the text
     * @param text   value to scroll to
     * @return Element with text value
     */
    public WebElement scrollToText(String text) {

        try {
            return androidDriver.findElement(new AppiumBy.ByAndroidUIAutomator(
                    "new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text(\"" + text + "\"))"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    /**
     * Method to clear text from textbox
     *
     * @param elementIdentifier
     */
    public void clearText(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            androidDriver.findElement(elementIdentifier).clear();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Method to find out if the element is selected
     *
     * @param elementIdentifier
     * @return true/false - if Element is selected
     */
    public boolean isElementSelected(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            return androidDriver.findElement(elementIdentifier).isSelected();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    /**
     * Method to draw a line in Signature box (to sign)
     *
     * @param elementIdentifier
     * @param start_xOffset     Start x offset
     * @param start_yOffset     Start y offset
     * @param end_xOffset       End x offset
     * @param end_yOffset       End y offset.
     */
    public void drawSignature(By elementIdentifier, int start_xOffset, int start_yOffset, int end_xOffset, int end_yOffset) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            if (isClickable(elementIdentifier)) {
                click(elementIdentifier);
                WebElement signatureElement = androidDriver.findElement(elementIdentifier);
                Actions builder = new Actions(androidDriver);
                Action drawAction = builder.moveToElement(signatureElement, start_xOffset, start_yOffset)
                        //signatureElement is the element that holds the signature element you have in the DOM
                        .clickAndHold(signatureElement)
                        .moveByOffset(end_xOffset, end_yOffset)
                        .release()
                        .build();
                drawAction.perform();
            }
            else {
                System.out.println("Element" + elementIdentifier.toString() +  " is not clickable.");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Method to checkid element is enabled
     * @param elementIdentifier
     * @return
     */
    public boolean isEnabled(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            androidDriver.findElement(elementIdentifier).isEnabled();
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    /**
     * Method to check is element is clickable
     * @param elementIdentifier
     * @return
     */
    public boolean isClickable(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.elementToBeClickable(elementIdentifier));
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    /**
     * Method to Scoll the page to the text
     * @param maxSwipes maximum number of swipes
     */
    public void scrollToTop(int maxSwipes) {
        try {
            androidDriver.findElement(MobileBy.AndroidUIAutomator(
                    "new UiScrollable(new UiSelector().scrollable(true)).scrollToBeginning(" + maxSwipes +")"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public String getText(By parentSelector, By ChildSelector){
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(parentSelector));
            WebElement parent = androidDriver.findElement(parentSelector);
            return parent.findElement(ChildSelector).getText();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - getList()
     * Description: This method is to get the list of similar object
     * Inputs : elementIdentifier
     * returns: count in Int
     * Author: Deepti Gupta
     * *********************************************************************************************************************************************************
     */
    public List<WebElement> getList(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            return androidDriver.findElements(elementIdentifier);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return null;
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - getListOfTexts()
     * Description: This method is to get the list of similar object
     * Inputs : elementIdentifier
     * returns: count in Int
     * Author: Neeharika Verma
     * *********************************************************************************************************************************************************
     */
    public List<String> getListOfTexts(By elementIdentifier) {
        try {
            List<String> textList = new ArrayList<>();
            List<WebElement> elementList =  getList(elementIdentifier);
            for (WebElement ae : elementList)
            {
                if (ae.getText() != null) {
                    textList.add(ae.getText());
                }
            }
            return textList;

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return null;
    }
}
