package hwqe.baseframework.models.pageobjectmodels.boss;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.models.datamodels.boss.PatientProfileModel;
import hwqe.baseframework.models.pageobjectmodels.WindowsBasePage;
import hwqe.baseframework.utilities.Reporter;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.pagefactory.ByChained;

public class PatientProfile extends WindowsBasePage {
    By legalLastName = MobileBy.AccessibilityId("txtLegalLastName");
    By legalFirstName = MobileBy.AccessibilityId("txtLegalFirstName");
    By genderDropdown = MobileBy.AccessibilityId("cboGender");
    By dob = MobileBy.AccessibilityId("txtDateOfBirth");
    By statusDropdown = MobileBy.AccessibilityId("cboStatus");
    By homeAddress = MobileBy.AccessibilityId("txtHomeAddress1");
    By postalCode = MobileBy.AccessibilityId("txtPostalCode");
    By suggestedAddressDG = MobileBy.AccessibilityId("dgSuggestedAddress");
    By enteredAddressDG = MobileBy.AccessibilityId("dgOriginalAddress");
    By city = MobileBy.AccessibilityId("CityTextBox");
    By countryDropdown = MobileBy.AccessibilityId("cboCountry");
    By primaryPhone = MobileBy.AccessibilityId("txtPrimaryPhone");
    By primaryPhoneTypeDropdown = MobileBy.AccessibilityId("cboPrimaryPhoneType");
    By allowFollowUp = MobileBy.AccessibilityId("Allow Follow-Up");
    By allowFollowUpYes = MobileBy.AccessibilityId("rdbAllowFollowUpYes");
    By allowFollowUpNo = MobileBy.AccessibilityId("rdbAllowFollowUpNo");
    By btnCLose = MobileBy.name("_Close");
    By btnApply = MobileBy.AccessibilityId("btnApply");
    By chkLastName = MobileBy.AccessibilityId("chkVerifyLastName");
    By chkFirstName = MobileBy.AccessibilityId("chkVerifyFirstName");
    By chkDOB = MobileBy.AccessibilityId("chkVerifyDOB");
    By btnEdit = MobileBy.AccessibilityId("btnEdit");
    By btnSave = MobileBy.AccessibilityId("btnSave");
    By txtLastVerified = MobileBy.AccessibilityId("txbLastVerifiedBy");
    By btnOkay = MobileBy.AccessibilityId("btnOkay");


    public PatientProfile() {
        super(AutomationManager.getInstance().getBoss().getDriver());
    }

    public boolean fillInPatientInformation(PatientProfileModel patientProfile) {
        switchWindow();
        sendText(legalLastName, patientProfile.getLegalLastName());
        sendText(legalFirstName, patientProfile.getLegalFirstName());
        selectListItem(genderDropdown, patientProfile.getGender());
        sendText(dob, patientProfile.getDob());
        selectListItem(statusDropdown, patientProfile.getStatus());
        sendText(homeAddress, patientProfile.getHomeAddress());
        sendText(postalCode, patientProfile.getPostalCode() + Keys.TAB);
        selectSuggestedAddressIfApplicable();
        sendText(city, patientProfile.getCity());
        selectListItem(countryDropdown, patientProfile.getCountry());
        sendText(primaryPhone, patientProfile.getPrimaryPhone());
        selectListItem(primaryPhoneTypeDropdown, patientProfile.getPrimaryPhoneType());
        chooseFollowUpOption(patientProfile.getAllowFollowUp());
        checkMarkVerificationBoxesIfPresent();
        clickSave();
        handleInformationPopup();
        boolean status = clickOkOnProfileUpdate();
        Reporter.logScreenShot("After filling in the fields", this.takeScreenShot());
        close();
        switchWindow();
        return status;
    }

    public boolean selectSuggestedAddressIfApplicable() {
        if (isElementDisplayed(By.name("Validate Postal Code"))) {
            click(new ByChained(suggestedAddressDG, By.className("RadioButton")));
            return moveToElementAndClick(btnApply);
        } else {
            return true;
        }
    }

    public boolean chooseFollowUpOption(String allowFollowUpVal) {
        if ("Yes".equals(allowFollowUpVal.trim())) {
            return click(allowFollowUpYes);
        } else if ("No".equals(allowFollowUpVal.trim())) {
            return click(allowFollowUpNo);
        } else {
            return false;
        }
    }

    public boolean handleInformationPopup() {
        if (isElementDisplayed(By.name("Yes"))) {
            return click(By.name("Yes"));
        } else {
            return true;
        }
    }

    public boolean checkMarkVerificationBoxesIfPresent() {
        if (isElementDisplayed(chkLastName) && isElementDisplayed(chkFirstName) && isElementDisplayed(chkDOB)) {
            return click(chkLastName) && click(chkFirstName) && click(chkDOB);
        } else {
            return true;
        }
    }

    public boolean checkMarkVerificationBoxes() {
        return click(chkLastName) && click(chkFirstName) && click(chkDOB);
    }

    public String getLastVerifiedMessage() {
        return getText(txtLastVerified);
    }

    public boolean clickEdit() {
        return click(btnEdit);
    }

    public boolean clickSave() {
        return click(btnSave);
    }

    public boolean clickOkOnProfileUpdate() {
        return click(btnOkay);
    }

    public boolean close() {
        return click(btnCLose);
    }
}
