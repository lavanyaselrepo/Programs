package hwqe.baseframework.models.pageobjectmodels.boss;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.models.pageobjectmodels.WindowsBasePage;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;
import org.openqa.selenium.support.pagefactory.ByChained;

public class Search extends WindowsBasePage {
    By txtSearch = MobileBy.AccessibilityId("txtSearchQuery");
    By imgSearch = MobileBy.AccessibilityId("imgSearchIcon");
    By drpDwnSearch = MobileBy.AccessibilityId("cboSearchCriteria");
    By lstPatient = new ByChained(drpDwnSearch, MobileBy.name("Patient"));
    By lstOrder = new ByChained(drpDwnSearch, MobileBy.name("Order ID"));
    By lstTray = new ByChained(drpDwnSearch, MobileBy.name("Tray Number"));
    By lstProvider = new ByChained(drpDwnSearch, MobileBy.name("Provider"));
    By lstInsurance = new ByChained(drpDwnSearch, MobileBy.name("Insurance"));
    By lstFrame = new ByChained(drpDwnSearch, MobileBy.name("Frame"));
    By lstLens = new ByChained(drpDwnSearch, MobileBy.name("Lens"));
    By lstContacts = new ByChained(drpDwnSearch, MobileBy.name("Contact Lens"));
    By lstAddOns = new ByChained(drpDwnSearch, MobileBy.name("Add-ons"));


    public Search() {
        super(AutomationManager.getInstance().getBoss().getDriver());
    }

    public boolean setSearch(String searchInput) {
        return sendText(txtSearch, searchInput);
    }

    public boolean clickSearch() {
        return click(imgSearch);
    }

    private boolean setDropDown(SearchAttribute attr) {
        click(drpDwnSearch);
        switch (attr) {
            case Patient:
                return click(lstPatient);
            case OrderId:
                return click(lstOrder);
            case TrayNumber:
                return click(lstTray);
            case Provider:
                return click(lstProvider);
            case Insurance:
                return click(lstInsurance);
            case Frame:
                return click(lstFrame);
            case Lens:
                return click(lstLens);
            case ContactLens:
                return click(lstContacts);
            case AddOns:
                return click(lstAddOns);
        }
        return false;
    }

    public boolean performSearch(SearchAttribute attr, String searchInput) {
        if (attr == SearchAttribute.Patient || attr == SearchAttribute.OrderId || attr == SearchAttribute.TrayNumber) {
            setDropDown(attr);
            sendText(txtSearch, searchInput);
            return click(imgSearch);
        } else {
            return setDropDown(attr);
        }
    }
}
