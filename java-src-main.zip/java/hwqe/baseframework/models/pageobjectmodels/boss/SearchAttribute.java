package hwqe.baseframework.models.pageobjectmodels.boss;

public enum SearchAttribute {
    Patient,
    OrderId,
    TrayNumber,
    Provider,
    Insurance,
    Frame,
    Lens,
    ContactLens,
    AddOns
}
