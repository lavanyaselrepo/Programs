package hwqe.baseframework.models.pageobjectmodels.boss;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.bosscontext.Sites;
import hwqe.baseframework.models.pageobjectmodels.WindowsBasePage;
import hwqe.baseframework.utilities.PropertyReader;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

public class SiteSelection extends WindowsBasePage {
    By siteID = MobileBy.AccessibilityId("txtSiteId");
    By countryDropDown = MobileBy.AccessibilityId("cboCountryCode");
    By btnOkay = MobileBy.AccessibilityId("btnOkay");
    By btnCancel = MobileBy.AccessibilityId("btnCancel");
    PropertyReader prop = PropertyReader.getInstance();

    public SiteSelection() {
        super(AutomationManager.getInstance().getBoss().getDriver());
    }

    public void setStore() {
        sendHotKeys(Keys.CONTROL + "s");
        sendHotKeys(Keys.BACK_SPACE);
        sendText(siteID, prop.getBossStoreNo());
    }

    public boolean clickOkay() {
        return click(btnOkay);
    }

    public void setCountry() {
        switch (prop.getBossStoreCountry().toLowerCase()) {
            case "us":
                selectListItem(countryDropDown, Sites.US.getSite());
                break;
            case "ca":
                selectListItem(countryDropDown, Sites.CA.getSite());
                break;
        }
    }
}
