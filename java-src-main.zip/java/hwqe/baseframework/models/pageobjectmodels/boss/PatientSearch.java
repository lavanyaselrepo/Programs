package hwqe.baseframework.models.pageobjectmodels.boss;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.models.pageobjectmodels.WindowsBasePage;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;
import org.openqa.selenium.support.pagefactory.ByChained;

public class PatientSearch extends WindowsBasePage {

    By lblTitle = MobileBy.AccessibilityId("txbTitle");
    By txtName = MobileBy.AccessibilityId("txtName");
    By txtDob = MobileBy.AccessibilityId("txtDateOfBirth");
    By txtPhone = MobileBy.AccessibilityId("txtPhone");
    By btnCLose = MobileBy.AccessibilityId("btnClose");
    By btnSearch = MobileBy.AccessibilityId("btnSearch");
    By btnOkay = MobileBy.AccessibilityId("btnOkay");
    By btnCreateNewPatient = MobileBy.AccessibilityId("btnCreateNewPatient");
    By dataGrid = MobileBy.AccessibilityId("dgFind");

    public PatientSearch() {
        super(AutomationManager.getInstance().getBoss().getDriver());
    }

    public boolean setName(String firstName, String lastName) {
        return this.sendText(txtName, lastName + "," + firstName);
    }

    public boolean close() {
        return this.click(btnCLose);
    }

    public boolean handleSearchValidationPopup() {
        if (isElementDisplayed(By.name("Search Validation"))) {
            return this.click(btnOkay);
        } else {
            return true;
        }
    }

    public boolean clickCreatePatient() {
        this.switchWindow();
        return this.click(btnCreateNewPatient);
    }

    public boolean performSearch(String firstName, String lastName) {
        this.sendText(txtName, lastName + ", " + firstName);
        return this.click(btnSearch);
    }

    public boolean selectPatient(String firstName, String lastName) {
        return this.click(new ByChained(dataGrid, By.name(lastName + ", " + firstName)));
    }
}
