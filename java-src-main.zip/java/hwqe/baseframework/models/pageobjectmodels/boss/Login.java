package hwqe.baseframework.models.pageobjectmodels.boss;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.models.pageobjectmodels.WindowsBasePage;
import io.appium.java_client.MobileBy;
import org.openqa.selenium.By;

public class Login extends WindowsBasePage {
    By homeOfficeUser = MobileBy.AccessibilityId("chkHomeOfficeUser");
    By txtUserName = MobileBy.AccessibilityId("txtUserName");
    By txtPassword = MobileBy.AccessibilityId("pwbPassword");
    By btnLogin = MobileBy.AccessibilityId("btnSubmit");
    By btnSecurityYes = MobileBy.AccessibilityId("btnYes");
    By imgIcon = MobileBy.AccessibilityId("imgIcon");

    public Login() {
        super(AutomationManager.getInstance().getBoss().getDriver());
    }

    public boolean performLoginForHO(String userName, String password) {
        switchWindow();
        click(homeOfficeUser);
        sendText(txtUserName, userName);
        sendText(txtPassword, password);
        click(btnLogin);
        switchWindow();
        if (this.isElementDisplayed(btnSecurityYes)) {
            return click(btnSecurityYes);
        }
        return false;
    }
}
