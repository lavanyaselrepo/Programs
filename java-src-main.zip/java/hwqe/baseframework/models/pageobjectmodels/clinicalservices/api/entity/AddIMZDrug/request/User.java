package hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.AddIMZDrug.request;

import com.google.gson.annotations.SerializedName;

@lombok.Getter
@lombok.Setter
@lombok.Value
public class User {

    @SerializedName("assigned_userid")
    public String assignedUserid;
    @SerializedName("siteid")
    public Integer siteid;
    @SerializedName("wrkstatn_host_name")
    public String wrkstatnHostName;

}
