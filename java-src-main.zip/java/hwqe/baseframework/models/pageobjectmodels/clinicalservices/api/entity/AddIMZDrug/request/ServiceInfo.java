package hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.AddIMZDrug.request;

import com.google.gson.annotations.SerializedName;

@lombok.Getter
@lombok.Setter
@lombok.Value
public class ServiceInfo {

    @SerializedName("ProductMdsFamId")
    public Long productMdsFamId;
    @SerializedName("patient_id")
    public Integer patientId;
}
