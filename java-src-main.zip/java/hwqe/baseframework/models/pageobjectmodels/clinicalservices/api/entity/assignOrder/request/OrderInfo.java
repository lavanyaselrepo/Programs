package hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.assignOrder.request;

import com.google.gson.annotations.SerializedName;

@lombok.Getter
@lombok.Setter
@lombok.Value
public class OrderInfo {

    @SerializedName("order_id")
    public Integer orderId;
    @SerializedName("order_seq_nbr")
    public Integer orderSeqNbr;

}