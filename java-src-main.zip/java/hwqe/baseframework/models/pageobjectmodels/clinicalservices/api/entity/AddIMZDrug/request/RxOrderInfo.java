package hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.AddIMZDrug.request;

import com.google.gson.annotations.SerializedName;

@lombok.Getter
@lombok.Setter
@lombok.Value
public class RxOrderInfo {

    @SerializedName("order_id")
    public Integer orderId;
}
