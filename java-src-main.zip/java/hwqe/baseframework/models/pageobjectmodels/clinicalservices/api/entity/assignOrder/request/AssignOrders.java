package hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.assignOrder.request;

import com.google.gson.annotations.SerializedName;

import java.util.List;

@lombok.Getter
@lombok.Setter
@lombok.Value
public class AssignOrders {

    @SerializedName("order_info")
    public List<OrderInfo> orderInfo;

}