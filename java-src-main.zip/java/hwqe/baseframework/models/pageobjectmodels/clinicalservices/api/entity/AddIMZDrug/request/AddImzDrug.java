package hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.AddIMZDrug.request;

import com.google.gson.annotations.SerializedName;

import java.util.Collections;
import java.util.List;

@lombok.Getter
@lombok.Setter
@lombok.Value
public class AddImzDrug {

    @SerializedName("rxorderinfo")
    public RxOrderInfo rxOrderInfo;
    @SerializedName("serviceinfo")
    public List<ServiceInfo> serviceInfo;
    @SerializedName("user")
    public User user;

    public static AddImzDrug build(int orderId, Long productMdsFamId, int patientId, String assignedUserid,int siteid, String wrkstatnHostName) {
        RxOrderInfo rxOrderInfo = new RxOrderInfo(orderId);
        List<ServiceInfo> serviceInfo = Collections.singletonList(new ServiceInfo(productMdsFamId, patientId));
        User user = new User(assignedUserid, siteid, wrkstatnHostName);
        return new AddImzDrug(rxOrderInfo, serviceInfo, user);
    }
}
