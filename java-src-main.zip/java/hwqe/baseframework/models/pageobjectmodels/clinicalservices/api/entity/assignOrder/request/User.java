package hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.assignOrder.request;

import com.google.gson.annotations.SerializedName;

@lombok.Getter
@lombok.Setter
@lombok.Value
public class User {

    @SerializedName("siteid")
    public Integer siteid;
    @SerializedName("assigned_userid")
    public String assignedUserid;
    @SerializedName("wrkstatn_host_name")
    public String wrkstatnHostName;

}