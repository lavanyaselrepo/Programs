package hwqe.baseframework.models.pageobjectmodels.clinicalservices.api.entity.assignOrder.request;

import com.google.gson.annotations.SerializedName;

import java.util.List;

@lombok.Getter
@lombok.Setter
@lombok.Value
public class AssignOrdersReq {

    @SerializedName("user")
    public User user;
    @SerializedName("assign_orders")
    public AssignOrders assignOrders;

    public static AssignOrdersReq build(int siteid, String assignedUserid, String wrkstatnHostName, List<OrderInfo> orderInfo) {
        User user = new User(siteid, assignedUserid, wrkstatnHostName);
        AssignOrders assignOrders = new AssignOrders(orderInfo);
        return new AssignOrdersReq(user, assignOrders);
    }
}
