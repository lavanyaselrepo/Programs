package hwqe.baseframework.models.pageobjectmodels.ASUI;

import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

import static java.time.Duration.ofMillis;
import static java.time.Duration.ofSeconds;

public class ASUIBasePage {

    protected final RemoteWebDriver webDriver;
    public final WebDriverWait webWait;
    public final Actions action;
    public String PATIENT_FIRST_NAME;
    public String PATIENT_LAST_NAME;
    public String PATIENT2_FIRST_NAME;
    public String PATIENT2_LAST_NAME;

    ASUIBasePage(RemoteWebDriver driver, Properties props) {
        this.webDriver = driver;
        int waitMillis;
        String waitProp = props.getProperty("app.asui.wait");
        if (waitProp != null && !waitProp.trim().isEmpty()) {
            waitMillis = Integer.parseInt(waitProp.trim());
        } else {
            waitMillis = 30000;
        }
        this.webWait = new WebDriverWait(this.webDriver, ofMillis(waitMillis));
        this.action  = new Actions(this.webDriver);
    }

    public boolean isElementEnabled(By locator, int waitTimeInSeconds) {
        try {
            new WebDriverWait(this.webDriver, ofSeconds(waitTimeInSeconds))
                    .until(ExpectedConditions.elementToBeClickable(locator));
            return true;
        } catch (Exception e) {
            Reporter.log("isElementEnabled failed for locator [" + locator + "]: " + e.getMessage());
            return false;
        }
    }

    public boolean sendText(By elementIdentifier, String textValue) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            this.webDriver.findElement(elementIdentifier).sendKeys(textValue);
            return true;
        } catch (Exception e) {
            Reporter.log(e.getMessage());
        }
        return false;
    }

    public boolean clickElement(By elementIdentifier) {
        try {
            webWait.until(ExpectedConditions.elementToBeClickable(elementIdentifier));
            this.webDriver.findElement(elementIdentifier).click();
            return true;
        } catch (Exception e) {
            Reporter.log(e.getMessage());
        }
        return false;
    }

    public boolean clickElementWithJavaScript(By locator) {
        try {
            WebElement el = webDriver.findElement(locator);
            ((JavascriptExecutor) webDriver).executeScript("arguments[0].click();", el);
            return true;
        } catch (Exception e) {
            Reporter.log("clickElementWithJavaScript failed for locator [" + locator + "]: " + e.getClass().getSimpleName() + " - " + e.getMessage());
            return false;
        }
    }

    public boolean isElementDisplayed(By elementIdentifier, int waitTimeInSeconds) {
        try {
            new WebDriverWait(this.webDriver, ofSeconds(waitTimeInSeconds)).until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            return true;
        } catch (Exception e) {
            Reporter.log(e.getMessage());
        }
        return false;
    }

    public String getText(By elementIdentifier) {
        try {
            if (isElementDisplayed(elementIdentifier, 10)) {
                return this.webDriver.findElement(elementIdentifier).getAttribute("value");
            }
        } catch (Exception e) {
            Reporter.log(e.getMessage());
        }
        return null;
    }

    public boolean verifyText(By elementIdentifier, String textToVerify) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(elementIdentifier));
            return this.webDriver.findElement(elementIdentifier).getText().contains(textToVerify);
        } catch (Exception e) {
            Reporter.log(e.getMessage());
        }
        return false;
    }

    public void scrollDown() {
        try {
            action.sendKeys(Keys.PAGE_DOWN).build().perform();
        } catch (Exception e) {
            Reporter.log(e.getMessage());
        }
    }

    public boolean scrolltoElement(By elementIdentifier) {
        try {
            action.scrollToElement(this.webDriver.findElement(elementIdentifier)).perform();
            return true;
        } catch (Exception e) {
            Reporter.log(e.getMessage());
        }
        return false;
    }

    public String getURL() {
        try {
            return webDriver.getCurrentUrl();
        } catch (Exception e) {
            Reporter.log("getURL failed: " + e.getClass().getSimpleName() + " - " + e.getMessage());
            return "unknown";
        }
    }

    public String getPageTitle() {
        try {
            return webDriver.getTitle();
        } catch (Exception e) {
            Reporter.log("getPageTitle failed: " + e.getClass().getSimpleName() + " - " + e.getMessage());
            return "unknown";
        }
    }

    /** First 800 chars of page source — enough to see what kind of page we landed on. */
    public String getPageSourceSnippet() {
        try {
            String src = webDriver.getPageSource();
            return src == null ? "<null>" : src.substring(0, Math.min(800, src.length()));
        } catch (Exception e) {
            return "<error: " + e.getMessage() + ">";
        }
    }

    public void navigateToUrl(String url) {
        webDriver.get(url);
    }

    public String takeScreenShot() {
        try {
            PropertyReader rdr = PropertyReader.getInstance();
            File saved = new File(rdr.getProperty("app.workingfolder_path") +
                                  java.util.UUID.randomUUID() + ".png");
            FileUtils.copyFile(webDriver.getScreenshotAs(OutputType.FILE), saved);
            return saved.getPath();
        } catch (Exception e) {
            Reporter.log("Failed to capture screenshot: " + e.getMessage());
            return null;
        }
    }

    public String inputDateForDose(String doseCount) {
        LocalDate date = LocalDate.now();
        String dateFormatter = "MM/dd/yyyy";
        return switch (doseCount) {
            case "2_0" -> date.minusMonths(1).format(DateTimeFormatter.ofPattern(dateFormatter));
            case "3_0" -> date.minusMonths(6).format(DateTimeFormatter.ofPattern(dateFormatter));
            case "3_1" -> date.minusMonths(5).format(DateTimeFormatter.ofPattern(dateFormatter));
            default -> date.format(DateTimeFormatter.ofPattern(dateFormatter));
        };
    }

    public void clearSession() {
        try {
            webDriver.manage().deleteAllCookies();
            webDriver.executeScript("window.sessionStorage.clear();");
            webDriver.executeScript("window.localStorage.clear();");
        } catch (Exception e) {
            Reporter.log("clearSession failed: " + e.getClass().getSimpleName() + " - " + e.getMessage());
        }
    }

    protected void refreshPage() {
        webDriver.navigate().refresh();
    }

    /**
     * Waits up to {@code timeoutSeconds} for ANY of the given locators to become visible.
     */
    protected boolean waitForAny(int timeoutSeconds, By... locators) {
        try {
            org.openqa.selenium.support.ui.ExpectedCondition<?>[] conditions =
                    java.util.Arrays.stream(locators)
                            .map(ExpectedConditions::visibilityOfElementLocated)
                            .toArray(org.openqa.selenium.support.ui.ExpectedCondition[]::new);
            new WebDriverWait(webDriver, ofSeconds(timeoutSeconds))
                    .until(ExpectedConditions.or(conditions));
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
