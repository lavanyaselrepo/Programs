package hwqe.baseframework.models.pageobjectmodels.ASUI;

import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StringUtils;
import hwqe.baseframework.utilities.DateUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.testng.Assert;

public class ClinicalServiceAppointmentsPage extends ASUIBasePage {
    private final StringUtils stringUtils = new StringUtils();
    private static final String DATE_FORMAT = "MM/dd/yyyy";
    private static final String ADD_NEW_PATIENT = "Add a new patient";
    private static final String DATE_OF_DOSE_1 = "Date of Dose #1";
    private static final String ONLINE_SLOTS = "Online slots";
    private static final String CANCELED_TAB_NOT_FOUND = "Canceled tab not found";
    private static final String NAV_TO_CANCELED_TAB = "Navigating to Canceled tab";
    private static final String NAV_TO_ADMINISTERED_TAB = "Navigating to Administered tab";
    private static final String ADMINISTERED_TAB_NOT_FOUND = "Administered tab not found";

    // Date filter dropdown error messages (S1192 - duplicate literals)
    private static final String ERROR_REGULAR_CLICK_FAILED_RETRY = "Regular click failed — retrying with JS click";
    private static final String ERROR_DROPDOWN_NOT_CLICKABLE = "ERROR - Choose-a-date dropdown trigger not clickable";
    private static final String ERROR_MENU_NOT_VISIBLE = "Menu not yet visible — re-clicking dropdown trigger once";
    private static final String ERROR_OPTION_NOT_VISIBLE = "ERROR - Option not visible: ";
    private static final String ERROR_DATE_FILTER_NOT_VISIBLE = "Date-filter option not visible in dropdown: ";
    private static final String ERROR_REGULAR_CLICK_FAILED_FOR = "Regular click failed for [";
    private static final String ERROR_RETRY_JS_CLICK = "] — retrying with JS click";
    private static final String ERROR_OPTION_NOT_CLICKABLE = "ERROR - Option not clickable: ";
    private static final String AFTER_SELECTING = "After selecting [";
    private static final String DATE_FILTER = "Date filter [";

    // LAI scheduling flow constants (S1192 - duplicate literals)
    private static final String FAILED_CLICK_SELECT_SERVICES = "Failed to click Select Services button";
    private static final String ACTUAL_RENDERED_LABEL = "  Actual rendered  : \"";
    private static final String ACTUAL_RENDERED_LABEL_ALT = "  Actual rendered : \"";

    public By patientLastname = By.cssSelector("[aria-label=\"Last Name\"]");
    public By patientFirstName = By.cssSelector("[aria-label=\"First Name\"]");
    public By patientMonth = By.cssSelector("[aria-label=\"Month\"]");
    public By patientDay = By.cssSelector("[aria-label=\"Day\"]");
    public By patientYear = By.cssSelector("[aria-label=\"Year\"]");
    public By patientPhoneNbr = By.xpath("//input[@aria-label=\"Phone Number\"]");
    public By searchBtn = By.xpath("//*[text()=\"Search\"]");
    public By selectPatientBtn = By.xpath("//*[text()=\"Select Patient\"]");
    static final By addPatient = By.xpath("//*[text()=\"" + ADD_NEW_PATIENT + "\"]");
    static final By addPatient2 = By.xpath("//*[text()=\"Add a patient\"]");
    public By selectServicesBtn = By.xpath("//*[text()=\"Select services\"]");
    protected By searchExistingPatients = By.xpath("//*[text()=\"Search existing patients\"]");
    protected By appointmentScheduled = By.xpath("//*[text()=\"Appointment scheduled!\"]");
    public By continueBtn = By.xpath("//*[text()=\"Continue\"]");
    protected By scheduleAppointmentBtn = By.xpath("//*[text()=\"Schedule an Appointment\"]");
    protected By returnToAppointmentsBtn = By.xpath("//*[text()=\"Return to appointments\"]");
    public By findAppointment = By.xpath("//*[text()='Find an appointment']");
    public By onlineSlots = By.xpath("//*[text()=\"Online slots\"]");
    public By patientNameVerify = By.xpath("//*[text()=\"DACH\"]");
    public By threeDoseOption = By.xpath("//*[@aria-label='Three-dose series button']");
    public By selectTimeSlot = By.xpath("//*[@aria-label='slot-0']");
    public By patientPrimaryContact = By.xpath("//*[text()=\"Primary contact information\"]");
    public By noAppointments = By.xpath("//*[contains(text(),\"all appointments are currently booked\")]");
    public By todaySelect = By.xpath("//*[contains(text(),\"Today\")]");
    public By weekSelect = By.xpath("//*[contains(text(),\"This week\")]");
    public By threeDotsSelection = By.xpath("(//*[contains(@aria-label,\"Reschedule or cancel appointment\")])[1]");
    public By quickFilter = By.xpath("//input[@placeholder=\"Filter by name, date of birth, service... etc\"]");
    public By cancelAppointment = By.xpath("//*[text()=\"Cancel Appointment\"]");
    public By cancelOptions = By.xpath("//*[text()=\"Select Cancellation Reason...\"]");
    public By cancelReason = By.xpath("//*[contains(text(), \"Patient no longer\")]");
    public By checkBoxVer = By.xpath("//*[contains(text(),\"I have verified\")]");
    public By cancelAppointmentBtn = By.xpath("//*[text()=\"Cancel appointment\"]");
    public By cancelledTab = By.xpath("//*[text()=\"Canceled\"]");
    public By rescheduleAppointmentBtn = By.xpath("//*[text()=\"Reschedule Appointment\"]");
    protected By reviewAppointment = By.xpath("//*[text()=\"Review appointment\"]");
    protected By rescheduleConfirm = By.xpath("//*[text()=\"Reschedule appointment\"]");
    public By doseNeeded = By.xpath("//*[text()=\"Which dose is needed:\"]");
    public By selectDose2 = By.xpath("//*[@aria-label=\"Dose #2 button\"]");
    public By selectDose3 = By.xpath("//*[@aria-label=\"Dose #3 button\"]");
    public By inputDose2Text = By.xpath("//*[@class=\"css-1dbjc4n r-bnwqim\"]");
    public By inputDateDose2 = By.xpath("//input[@aria-label=\"Date of Dose #1\"]");
    public By inputDateDose3 = By.xpath("//input[@aria-label=\"Date of Dose #2\"]");
    public By inputDose3Text = By.xpath("//*[text()=\"Date of Dose #2\"]");
    public By finalizeAppointment = By.xpath("//*[text()=\"Schedule appointment\"]");
    protected By rsvDrug = By.xpath("//span[@aria-label=\"RSV\"]");
    protected By covidDrug = By.xpath("//span[@aria-label=\"COVID\"]");
    protected By hepatitisABDrug = By.xpath("//span[@aria-label=\"HEP_A_B\"]");
    public By hepatitisB = By.xpath("//span[@aria-label=\"HEP_B\"]");
    public By pneumonia = By.xpath("//span[@aria-label=\"PNEUMONIA\"]");
    /**
     * Flu (Influenza) drug tile on the "Select services" page.
     *
     * <p>Permissive {@code aria-label} match across the casing variants observed
     * across stage / production builds — matches whichever is rendered without
     * needing pom-level conditional logic.
     */
    static final By fluDrug = By.xpath(
        "//span[@aria-label='FLU' or @aria-label='Flu' or @aria-label='INFLUENZA']"
    );

    /**
     * Vaccine title — appears on the FLU drug-detail page once the patient is
     * selected and the FLU tile has been clicked. Pattern:
     * <em>"Let's find the right Flu vaccine for &lt;patient name&gt;"</em>.
     *
     * <p>Matched by both {@code Let's find the right} prefix and {@code vaccine}
     * suffix so the locator survives variation in patient-name interpolation
     * without needing the patient name as input.
     */
    static final By fluVaccineTitle = By.xpath(
        "//*[@dir='auto'][contains(text(),\"Let's find the right\") " +
        "and contains(text(),'vaccine')]"
    );

    /**
     * Flu vaccine info line — appears on the FLU drug-detail page beneath the
     * vaccine title. Matches any flu vaccine variant (Flublok, Fluzone, etc.)
     * by anchoring on the stable prefix {@code "Review this information about"},
     * which is present regardless of which specific flu vaccine is recommended.
     */
    static final By fluFlublokInfo = By.xpath(
        "//*[@dir='auto'][contains(text(),'Review this information about')]"
    );

    /**
     * "Patient eligibility:" label — appears on the eligibility page after
     * the user advances past the FLU drug-detail page (Continue).
     *
     * <p>Equality match (not {@code contains}) because the live label is
     * exactly {@code "Patient eligibility:"} with no suffix.
     */
    static final By fluPatientEligibilityLabel = By.xpath(
        "//*[@dir='auto'][text()='Patient eligibility:']"
    );

    /**
     * Eligibility bullet text — appears beneath the {@code Patient eligibility:}
     * label and reads <em>"All patients may be eligible to receive a flu
     * vaccination..."</em>. {@code contains} match tolerates trailing text
     * variation across page builds.
     */
    static final By fluEligibilityBullet = By.xpath(
        "//*[@dir='auto'][contains(text()," +
        "'All patients may be eligible to receive a flu vaccination')]"
    );

    // ── COVID-19 vaccine dose-selection page (/services/immunizationDoseSelection) ──

    /**
     * Vaccine heading — <em>"Let's find the right COVID-19 vaccine for &lt;patient&gt;"</em>.
     * Uses {@code contains()} because the patient name is appended at runtime.
     */
    static final By covidVaccineHeading = By.xpath(
        "//*[contains(text(),\"Let's find the right COVID-19 vaccine for\")]"
    );

    /**
     * Brand subheading — <em>"Review this information about &lt;vaccine&gt;:"</em>.
     * Uses {@code contains()} because the vaccine brand (Moderna / mNEXSPIKE / etc.)
     * is dynamic.
     */
    static final By covidVaccineBrandSubheading = By.xpath(
        "//*[contains(text(),'Review this information about')]"
    );

    /**
     * Eligibility bullet 1 — anchored on the distinctive
     * <em>"Everyone 3 years and older may be eligible"</em> phrase.
     */
    static final By covidEligibilityBullet1 = By.xpath(
        "//*[contains(text(),'Everyone 3 years and older may be eligible')]"
    );

    /**
     * Eligibility bullet 2 — <em>"Certain Immunocompromised patients may have the option..."</em>.
     */
    static final By covidEligibilityBullet2 = By.xpath(
        "//*[contains(text(),'Certain Immunocompromised patients may have the option')]"
    );

    // ── LAI (Long Acting Injectable) service-selection locators ──────────────
    // Confirmed live via QA Kitten against https://imz-assoc-app.stage.walmart.com/
    protected By clinicalServicesRadio  = By.cssSelector("input[value='clinicalServices']");
    protected By laiVisitCheckbox       = By.xpath("//span[@aria-label='LAI_VISIT']//input[@type='checkbox']");
    // Universal footer action button: used for every primary CTA in the LAI flow
    // (Continue page-1, Continue page-2, and the post-slot-selection Continue)
    protected By footerPrimaryActionBtn = By.cssSelector("div[aria-label='Footer Primary'][role='button']");

    // ── Immunization Dose Selection page (/services/immunizationDoseSelection) ─
    // Shown after service selection; presents vaccine brand eligibility info
    // before the patient continues to pick a date/time slot.
    /** Top-left «X» that exits the entire scheduling flow. */
    static final By exitSchedulingBtn        = By.cssSelector("[aria-label='Exit Scheduling Appointment']");
    /** Walmart Rx | Clinical Service Appointments h1 banner. */
    static final By clinicalServicesHeader   = By.cssSelector("h1[aria-label='Walmart Rx | Clinical Service Appointments']");
    /** Avatar + name + store chip in the top-right corner. */
    static final By userInfoBtn              = By.cssSelector("[aria-label='userInfoButton']");
    // ── Step-progress labels (stepper across the top of the card) ────────────
    static final By stepPatientsAndServices  = By.xpath("//*[text()='Patients & Services']");
    static final By stepAppointmentDateTime  = By.xpath("//*[text()='Appointment Day & Time']");
    static final By stepPatientInformation   = By.xpath("//*[text()='Patient Information']");
    static final By stepReviewAndSchedule    = By.xpath("//*[text()='Review & Schedule']");
    // ── Main content ─────────────────────────────────────────────────────────
    /**
     * Dynamic heading: "Let's find the right COVID-19 vaccine for Age".
     * Uses {@code contains} because the trailing age qualifier is runtime-specific.
     */
    static final By doseSelectionHeading     = By.xpath("//*[contains(text(),\"Let\u2019s find the right COVID-19 vaccine\")]");
    /** "Review this information about <VaccineName>:" sub-heading. */
    public By vaccineReviewHeading(String vaccineName) {
        return By.xpath("//*[contains(text(),'Review this information about " + vaccineName + "')]");
    }
    /**
     * Eligibility bullet: everyone 3+ years eligible (2-month gap rule).
     * Uses {@code contains} to tolerate minor UI copy tweaks.
     */
    static final By eligibilityCriteriaAllAges =
        By.xpath("//*[contains(text(),'Everyone 3 years and older may be eligible')]");
    /** Eligibility bullet: immunocompromised patients may receive additional doses. */
    static final By eligibilityCriteriaImmunocompromised =
        By.xpath("//*[contains(text(),'Certain Immunocompromised patients')]");
    // ── Footer navigation (dose-selection page) ───────────────────────────────
    /** Back arrow / «Previous» button — navigates one step back in the wizard. */
    static final By previousBtn              = By.cssSelector("[aria-label='Previous button']");
    // NOTE: continueBtn and footerPrimaryActionBtn are already declared above
    //       and serve as the «Continue» CTA on this page too.
    public By primaryContact = By.xpath("//*[contains(text(),\"Provide the primary contact\")]");
    public By patientEligibility = By.xpath("//*[text()=\"Patient eligibility:\"]");
    public By confirmPatientInfo = By.xpath("//*[contains(text(),\"Enter patient information\")]");
    protected By verifyPatientAddedTextPopup = By.xpath("//*[@id='animatedComponent' and contains(., 'has been added to the patient group')]");
    public By genderDropdown = By.cssSelector("[aria-label='Gender']");
    public By genderDropdownOptions(String gender) {
        return By.xpath("//*[@aria-label='dropdownMenuItem']//*[normalize-space()=" + xpathLiteral(gender) + "]");
    }

    /**
     * Safely wraps a runtime value for use inside an XPath expression, preventing
     * XPath injection (Sonar S2076).
     * <ul>
     *   <li>No single-quote in value → wrap in single quotes.</li>
     *   <li>No double-quote in value → wrap in double quotes.</li>
     *   <li>Both quotes present → emit {@code concat()} so neither quote type
     *       is used as the string delimiter.</li>
     * </ul>
     */
    private static String xpathLiteral(String value) {
        if (!value.contains("'")) {
            return "'" + value + "'";
        }
        if (!value.contains("\"")) {
            return "\"" + value + "\"";
        }
        // Value contains both ' and " — split on single-quotes and reassemble
        // using XPath concat() so no character acts as its own delimiter.
        return "concat('" + value.replace("'", "',\"'\",'") + "')";
    }
    public By streetAddress = By.xpath("//input[@aria-label='Street Address 1']");
    public By zipCode = By.xpath("//input[@aria-label='Zip code']");
    public By inputDose1Text1 = By.xpath("(//*[contains(@class,\"css-1dbjc4n r-z2wwpe\")])[1]");
    public By inputDose2Text2 = By.xpath("(//*[contains(@class,\"css-1dbjc4n r-z2wwpe\")])[2]");
    protected By rescheduleOrCancelAppointmentEllipsis = By.xpath("//*[contains(@aria-label,'Reschedule or cancel appointment')]");
    public By markAsAdministeredLink = By.xpath("//li[@aria-label='Mark as administered']");
    public By markGroupAsAdministeredLink = By.xpath("//li[@aria-label='Mark group as administered']");
    public By confirmButton = By.xpath("//*[normalize-space()='Confirm']");
    public By administeredTab = By.xpath("//*[@aria-label='Administered']");
    protected By noAppointmentsTxt = By.xpath("//*[contains(text(),'sorry, all appointments are currently booked. Please ask patient to check back tomorrow.')]");
    public By administeredByPatientName(String patientName) {
        return By.xpath("(//*[normalize-space()=" + xpathLiteral(patientName) + "])[1]");
    }

    /**
     * Clickable trigger for the "Choose a date (mm/dd/yyyy)" dropdown on the
     * <b>Appointment tab</b>.
     *
     * <p>Uses {@code aria-label='Time Period Dropdown Menu'} — the attribute present
     * on the Appointment tab's dropdown trigger in the current UI build.
     *
     * <p><b>Do NOT use for Cancelled or Administered tabs</b> — those tabs render a
     * different DOM structure (no {@code aria-label} on the trigger) and must use
     * {@link #historicalTabDateDropdown} instead.
     */
    private By chooseDateDropdown = By.xpath(
        "//*[@aria-label='Time Period Dropdown Menu']"
    );

    /**
     * Clickable trigger for the "Choose a date (mm/dd/yyyy)" dropdown on the
     * <b>Cancelled</b> and <b>Administered</b> tabs.
     *
     * <p>Navigates the DOM relationally from the visible "Choose a date" label text
     * to its sibling trigger element. The {@code @role='button' or @tabindex='0'}
     * union covers both attribute patterns observed across builds, and the position
     * predicate {@code [1]} ensures exactly the trigger div is clicked — not an
     * option row wrapper that also carries {@code tabindex='0'} once the menu opens.
     *
     * <p>This is the <em>original</em> locator that was in place before PR #6860
     * changed {@link #chooseDateDropdown} to an {@code aria-label} match suited
     * only for the Appointment tab.
     */
    private final By historicalTabDateDropdown = By.xpath(
        "(//div[contains(text(),'Choose a date')]/following-sibling::div//div[@role='button' or @tabindex='0'])[1]"
    );

    /**
     * Readiness guard: waits for at least one {@code dropdownMenuItem} to appear
     * <em>inside the Canceled Appointments List section</em>.
     *
     * <p>Scoping to {@code aria-label='Canceled Appointments List'} prevents a
     * false-positive match against {@code dropdownMenuItem} elements from other
     * components (e.g. the gender picker) that may already be visible on the page.
     * A false positive would make {@link #openDateFilterDropdown()} believe the menu
     * was open, skip the re-click guard, and proceed — even when the menu is still closed.
     */
    private final By dateFilterListbox = By.xpath(
        "//div[@aria-label='Canceled Appointments List']//div[@aria-label='dropdownMenuItem']"
    );

    /**
     * Post-filter validation anchor: confirms the Canceled Appointments List container
     * is still rendered after a date-range filter option is selected.
     *
     * <p>Preferred over checking the tab label text, which is too broad and can match
     * unrelated "Canceled" strings elsewhere on the page.
     */
    private final By canceledListContainer = By.xpath(
        "//div[@aria-label='Canceled Appointments List']"
    );

    /**
     * Returns a locator for a named option in the open date-filter menu.
     *
     * <h3>Why {@code contains(text(), label)} on the inner child div?</h3>
     * <p>React Native Web renders each option as a two-level structure:
     * <pre>
     *   &lt;div aria-label="dropdownMenuItem"&gt;         ← outer row
     *     &lt;div dir="auto"&gt;Today, Apr 26 2026&lt;/div&gt;  ← text lives HERE
     *   &lt;/div&gt;
     * </pre>
     * XPath's {@code text()} node-set function only checks <em>direct</em> text nodes,
     * so {@code contains(text(), 'Today')} on the outer div never matches (the outer div
     * has no direct text nodes — only child elements). Targeting the descendant div that
     * actually holds the text is the correct approach and matches the Google AI reference
     * implementation.
     *
     * <p>The UI always appends a live date-range suffix
     * (e.g. {@code "Today, Apr 26 2026"}), so {@code contains} is used rather than
     * an exact equality match — which would fail as soon as the calendar date rolls over.
     *
     * @param label the prefix of the visible option text:
     *              {@code "Today"} | {@code "This week"} | {@code "Last week"} |
     *              {@code "Last 4 weeks"}
     */
    public By dateFilterOption(String label) {
        // xpathLiteral() prevents XPath injection (Sonar S2076) even though these
        // values are currently known constants — defensive programming is free here.
        String lit = xpathLiteral(label);
        // Target the INNER div that holds the direct text node.
        // The outer div[@aria-label='dropdownMenuItem'] has no direct text — only
        // a child element — so contains(text(),...) must be applied to the child.
        return By.xpath(
            "//div[@aria-label='dropdownMenuItem']//div[contains(text(), " + lit + ")]"
        );
    }

    public ClinicalServiceAppointmentsPage(RemoteWebDriver driver, Properties props){
        super(driver,props);
    }

    public void fillPatientInfo(){
        PATIENT_FIRST_NAME = "Deon";
        PATIENT_LAST_NAME  = "Dach";
        Reporter.log("Searching for existing patient: Dach, Deon");
        try {
            performPatientSearch();
            String currentUrl = getURL();
            if (currentUrl.contains("/findPatient") && !currentUrl.contains("/findPatient/")) {
                captureAndLog("ERROR - Still On Search Page");
                throw new IllegalStateException("Navigation failed - still on patient search page");
            }
            waitForLoadingIndicator();
            boolean primaryContactVisible = isElementDisplayed(primaryContact, 10);
            By workingPhoneSelector = findWorkingPhoneSelector();
            if (!primaryContactVisible && workingPhoneSelector == null) {
                captureAndLog("ERROR - Contact Form Not Found");
                throw new AssertionError("Contact form not found at: " + getURL());
            }
            if (workingPhoneSelector != null) {
                patientPhoneNbr = workingPhoneSelector;
            }
            Reporter.log("Entering contact phone: 5555555555");
            if (!clickElement(patientPhoneNbr) || !sendText(patientPhoneNbr, "5555555555")) {
                throw new IllegalStateException("Failed to enter phone number");
            }
            Reporter.log("Patient information completed");
        } catch (org.openqa.selenium.TimeoutException | org.openqa.selenium.NoSuchElementException e) {
            captureAndLog("ERROR - Element Not Found");
            throw new IllegalStateException("Element not found during patient selection", e);
        } catch (AssertionError e) {
            captureAndLog("ERROR - Assertion Failed");
            throw new IllegalStateException(e.getMessage(), e);
        }
    }

    /**
     * Searches for an existing patient by last name, first name, and date of
     * birth, then selects them so the caller can proceed with the appointment
     * booking flow.
     *
     * <p><b>Pre-condition:</b> the appointments list page is loaded
     * (i.e. {@link Homepage#navigateToAppointments()} has run).
     *
     * <p><b>DOB format:</b> {@code MM/dd/yyyy} — e.g. {@code "01/02/1991"}.
     *
     * @param lastName  patient's last name (matched case-insensitively against
     *                  the uppercased result row in the search grid)
     * @param firstName patient's first name
     * @param dob       date of birth in {@code MM/dd/yyyy} format
     */
    public void searchAndSelectExistingPatient(String lastName, String firstName, String dob) {
        Reporter.log("Searching for existing patient: " + lastName + ", " + firstName + " DOB: " + dob);
        Assert.assertTrue(clickElement(scheduleAppointmentBtn),
                "Failed to click 'Schedule an Appointment' button");

        if (!verifyText(addPatient, ADD_NEW_PATIENT)
                || !verifyText(searchExistingPatients, "Search existing patients")) {
            captureAndLog("ERROR — Patient selection page did not load");
            throw new IllegalStateException(
                    "Patient selection page not loaded — both patient options must be visible");
        }

        String[] dobParts = dob.split("/");
        sendText(patientLastname,  lastName);
        sendText(patientFirstName, firstName);
        sendText(patientMonth,     dobParts[0]);
        sendText(patientDay,       dobParts[1]);
        sendText(patientYear,      dobParts[2]);
        clickElement(searchBtn);

        By patientRow = By.xpath("//*[text()='" + lastName.toUpperCase() + "']");
        isElementDisplayed(patientRow, 10);
        scrollDown();
        captureAndLog("Patient search results — " + lastName.toUpperCase());

        Assert.assertTrue(
                verifyText(patientRow, lastName.toUpperCase()),
                "Patient '" + lastName.toUpperCase() + "' not found in search results");

        clickElement(patientRow);

        boolean patientSelected = clickElement(selectPatientBtn);
        if (!patientSelected) {
            patientSelected = clickElementWithJavaScript(selectPatientBtn);
        }
        Assert.assertTrue(patientSelected, "Failed to click 'Select Patient' button");
        isElementDisplayed(scheduleAppointmentBtn, 5);
        captureAndLog("Patient selected — " + firstName + " " + lastName);

        // ── Contact form: enter primary phone for the selected patient ──────────
        // Mirrors the phone-entry tail of fillPatientInfo() — required because
        // selecting an existing patient lands on a contact form that gates the
        // Schedule-Appointment CTA until a phone number is captured.
        enterPrimaryPhoneForSelectedPatient();
    }

    /**
     * Enters a primary contact phone number for the patient that has just been
     * selected (either via {@link #fillPatientInfo()} or
     * {@link #searchAndSelectExistingPatient(String, String, String)}).
     *
     * <p>Tries {@link #patientPhoneNbr} first, then falls back to alternative
     * selectors via {@link #findWorkingPhoneSelector()} to tolerate small DOM
     * variations across builds. Throws {@link IllegalStateException} when the
     * contact form is missing entirely or the phone field cannot be filled —
     * both conditions indicate a real test-blocking regression.
     */
    private void enterPrimaryPhoneForSelectedPatient() {
        waitForLoadingIndicator();
        boolean primaryContactVisible = isElementDisplayed(primaryContact, 10);
        By workingPhoneSelector = findWorkingPhoneSelector();
        if (!primaryContactVisible && workingPhoneSelector == null) {
            captureAndLog("ERROR — Contact form not found after patient selection");
            throw new IllegalStateException("Contact form not found at: " + getURL());
        }
        if (workingPhoneSelector != null) {
            patientPhoneNbr = workingPhoneSelector;
        }
        Reporter.log("Entering contact phone: 5555555555");
        if (!clickElement(patientPhoneNbr) || !sendText(patientPhoneNbr, "5555555555")) {
            captureAndLog("ERROR — Failed to enter phone number for selected patient");
            throw new IllegalStateException("Failed to enter phone number for selected patient");
        }
        captureAndLog("Phone entered for selected patient");
    }

    /** Captures a screenshot and logs it — eliminates repetitive null-check boilerplate. */
    private void captureAndLog(String label) {
        String screenshot = takeScreenShot();
        if (screenshot != null) {
            Reporter.logScreenShot(label, screenshot);
        }
    }

    /** Clicks the schedule button, verifies the patient search page, searches, and selects the patient. */
    private void performPatientSearch() {
        if (!clickElement(scheduleAppointmentBtn)) {
            throw new IllegalStateException("Schedule appointment button not found");
        }
        if (!verifyText(addPatient, ADD_NEW_PATIENT) || !verifyText(searchExistingPatients, "Search existing patients")) {
            throw new IllegalStateException("Patient selection page not loaded");
        }
        if (!patientRecordsData(searchBtn)) {
            throw new IllegalStateException("Patient search failed");
        }
        Reporter.log("Patient found - selecting patient");
        boolean patientSelected = clickElement(selectPatientBtn);
        if (!patientSelected) {
            patientSelected = clickElementWithJavaScript(selectPatientBtn);
        }
        Assert.assertTrue(patientSelected, "Failed to click Select Patient button");
        isElementDisplayed(scheduleAppointmentBtn, 5);
        captureAndLog("After Patient Selection");
    }

    /** Waits for any loading/spinner overlay to disappear; silently continues if none is found. */
    private void waitForLoadingIndicator() {
        try {
            By loadingIndicator = By.xpath("//*[contains(@class, 'loading') or contains(@class, 'spinner')]");
            webWait.until(ExpectedConditions.invisibilityOfElementLocated(loadingIndicator));
        } catch (org.openqa.selenium.TimeoutException e) {
            Reporter.log("Loading indicator not found or already gone: " + e.getMessage());
        }
    }

    /** Returns the first visible phone-number input selector, or {@code null} if none is found. */
    private By findWorkingPhoneSelector() {
        By[] phoneSelectors = {
            patientPhoneNbr,
            By.xpath("//input[@aria-label='Phone Number']"),
            By.cssSelector("input[type='tel']")
        };
        for (By selector : phoneSelectors) {
            if (isElementDisplayed(selector, 3)) {
                return selector;
            }
        }
        return null;
    }

    private boolean patientRecordsData(By searchBtn) {
        sendText(patientLastname, "Dach");
        sendText(patientFirstName, "Deon");
        sendText(patientMonth,"12");
        sendText(patientDay,"31");
        sendText(patientYear,"1969");
        
        clickElement(searchBtn);
        
        isElementDisplayed(patientNameVerify, 10);
        
        scrollDown();
        
        String searchResultsScreenshot = takeScreenShot();
        if (searchResultsScreenshot != null) {
            Reporter.logScreenShot("Patient Search - Deon Dach", searchResultsScreenshot);
        }
        
        boolean patientFound = verifyText(patientNameVerify,"DACH");
        
        if (!patientFound) {
            String notFoundScreenshot = takeScreenShot();
            if (notFoundScreenshot != null) {
                Reporter.logScreenShot("ERROR - Patient Not Found", notFoundScreenshot);
            }
        }
        
        Assert.assertTrue(patientFound, "Patient 'DACH' not found in search results");
        
        // Click on patient row to select it
        boolean patientRowClicked = clickElement(patientNameVerify);
        
        if (patientRowClicked) {
            isElementDisplayed(patientNameVerify, 5);
        }
        
        return true;
    }

    public void createPatient(){
        Reporter.log("Creating new patient");
        clickElement(scheduleAppointmentBtn);
        if (!verifyText(addPatient, ADD_NEW_PATIENT)) {
            Reporter.log("ERROR: '" + ADD_NEW_PATIENT + "' button not found or text mismatch");
        }
        clickElement(addPatient);

        PATIENT_FIRST_NAME = stringUtils.firstNameGenerator();
        PATIENT_LAST_NAME = stringUtils.lastNameGenerator();
        Reporter.log("Entering patient name: " + PATIENT_FIRST_NAME + " " + PATIENT_LAST_NAME);

        if (!sendText(patientLastname, PATIENT_LAST_NAME)) {
            Reporter.log("ERROR: Failed to send text for patient last name");
        }
        if (!sendText(patientFirstName, PATIENT_FIRST_NAME)) {
            Reporter.log("ERROR: Failed to send text for patient first name");
        }

        String dob = DateUtils.birthdayGeneratorWithGivenFormat(DATE_FORMAT);
        sendText(patientMonth, dob.split("/")[0]);
        sendText(patientDay,   dob.split("/")[1]);
        sendText(patientYear,  dob.split("/")[2]);

        if (!sendText(patientPhoneNbr, StringUtils.phoneNumberGenerator())) {
            Reporter.log("ERROR: Failed to send text for patient phone number");
        }
        if (!clickElement(continueBtn)) {
            Reporter.log("ERROR: Failed to click continue button");
        }
        isElementDisplayed(scheduleAppointmentBtn, 10);
        Reporter.log("New patient created");
    }

    public void addPatient2(){
        if (!verifyText(addPatient2, "Add a patient")) {
            Reporter.log("ERROR: 'Add a patient' button not found or text mismatch");
        }
        clickElement(addPatient2);
        if (!verifyText(addPatient, ADD_NEW_PATIENT)) {
            Reporter.log("ERROR: 'Add a new patient' button not found or text mismatch");
        }
        clickElement(addPatient);

        PATIENT2_FIRST_NAME = stringUtils.firstNameGenerator();
        PATIENT2_LAST_NAME = stringUtils.lastNameGenerator();
        Reporter.log("Entering patient 2 name: " + PATIENT2_FIRST_NAME + " " + PATIENT2_LAST_NAME);

        if (!sendText(patientLastname, PATIENT2_LAST_NAME)) {
            Reporter.log("ERROR: Failed to send text for patient 2 last name");
        }
        if (!sendText(patientFirstName, PATIENT2_FIRST_NAME)) {
            Reporter.log("ERROR: Failed to send text for patient 2 first name");
        }

        String dob = DateUtils.birthdayGeneratorWithGivenFormat(DATE_FORMAT);
        sendText(patientMonth, dob.split("/")[0]);
        sendText(patientDay,   dob.split("/")[1]);
        sendText(patientYear,  dob.split("/")[2]);
    }

    public void clickSelectServices(){
        Assert.assertTrue(clickElement(selectServicesBtn));
    }

    public void selectDrugPatientServices(String drugInfo) {
        scrollDown();
        clickElement(selectDrug(drugInfo));
        Assert.assertTrue(clickElement(continueBtn));
    }

    public void clickThreeDoseSeries() {
        Assert.assertTrue(clickElement(threeDoseOption));
    }

    public void selectPatientServices(String drugInfo) {
        scrollDown();
        Assert.assertTrue(clickElement(selectDrug(drugInfo)));
        Assert.assertTrue(clickElement(continueBtn));
        Assert.assertTrue(verifyText(patientEligibility, "Patient eligibility:"));
        Assert.assertTrue(clickElement(continueBtn));
        webWait.until(ExpectedConditions.visibilityOfElementLocated(verifyPatientAddedTextPopup));
        webWait.until(ExpectedConditions.invisibilityOfElementLocated(verifyPatientAddedTextPopup));
        Assert.assertTrue(clickElement(findAppointment));
        scrollDown();
        Assert.assertTrue(verifyText(onlineSlots, ONLINE_SLOTS));
        scrolltoElement(noAppointmentsTxt);
        Assert.assertTrue(clickElement(selectTimeSlot));
        Assert.assertTrue(clickElement(continueBtn));
    }

    public void selectPatientServicesWithDose(String drugInfo, int doseCount) {
        scrollDown();
        Assert.assertTrue(clickElement(selectDrug(drugInfo)));
        Assert.assertTrue(clickElement(continueBtn));
        Assert.assertTrue(verifyText(doseNeeded, "Which dose is needed:"));
        if (doseCount == 2) {
            clickElement(selectDose2);
            Assert.assertTrue(verifyText(inputDose2Text, DATE_OF_DOSE_1));
            clickElement(inputDose2Text);
            sendText(inputDateDose2, inputDateForDose(doseCount + "_0"));
        } else {
            clickElement(selectDose3);
            Assert.assertTrue(verifyText(inputDose2Text, DATE_OF_DOSE_1));
            Assert.assertTrue(verifyText(inputDose3Text, "Date of Dose #2"));
            clickElement(inputDose1Text1);
            sendText(inputDateDose2, inputDateForDose(doseCount + "_0"));
            clickElement(inputDose2Text2);
            sendText(inputDateDose3, inputDateForDose(doseCount + "_1"));
        }
        Assert.assertTrue(clickElement(continueBtn));
        webWait.until(ExpectedConditions.visibilityOfElementLocated(verifyPatientAddedTextPopup));
        webWait.until(ExpectedConditions.invisibilityOfElementLocated(verifyPatientAddedTextPopup));
        Assert.assertTrue(clickElement(findAppointment));
        scrollDown();
        Assert.assertTrue(verifyText(onlineSlots, ONLINE_SLOTS));
        selectTimeStamp();
        Assert.assertTrue(clickElement(continueBtn));
    }

    public void selectPatientServicesBasedonDosecount(int doseCount) {
        if(doseCount == 2){
            clickElement(selectDose2);
            Assert.assertTrue(verifyText(inputDose2Text,DATE_OF_DOSE_1));
            clickElement(inputDose2Text);
            sendText(inputDateDose2,inputDateForDose(doseCount+"_0"));
        }else {
            clickElement(selectDose3);
            Assert.assertTrue(verifyText(inputDose2Text,DATE_OF_DOSE_1));
            Assert.assertTrue(verifyText(inputDose3Text,"Date of Dose #2"));
            clickElement(inputDose1Text1);
            sendText(inputDateDose2,inputDateForDose(doseCount+"_0"));
            clickElement(inputDose2Text2);
            sendText(inputDateDose3,inputDateForDose(doseCount+"_1"));
        }
        Assert.assertTrue(clickElement(continueBtn));
        webWait.until(ExpectedConditions.visibilityOfElementLocated(verifyPatientAddedTextPopup));
        webWait.until(ExpectedConditions.invisibilityOfElementLocated(verifyPatientAddedTextPopup));
        Assert.assertTrue(clickElement(findAppointment));
        scrollDown();
        Assert.assertTrue(verifyText(onlineSlots, ONLINE_SLOTS));
        selectTimeStamp();
        Assert.assertTrue(clickElement(continueBtn));
    }

    private void selectTimeStamp() {
        if(verifyText(noAppointments,"all appointments are currently booked")) {
            LocalDate date = LocalDate.now();
            int currentDate = date.getDayOfMonth();
            clickElement(By.xpath("//*[text()=" + xpathLiteral(String.valueOf(currentDate + 1)) + "]"));
        }
        clickElement(selectTimeSlot);
    }

    public void patientInformation(){
        Assert.assertTrue(verifyText(confirmPatientInfo, "Enter patient information"));
        Reporter.logScreenShot("Patient Information Page", takeScreenShot());
        clickElement(continueBtn);
        Reporter.logScreenShot("Patient Information Confirmed", takeScreenShot());
    }

    public void patientInformationForNewPatient(){
        try {
            Assert.assertTrue(verifyText(confirmPatientInfo, "Enter patient information"));
            Assert.assertTrue(clickElement(genderDropdown));
            Assert.assertTrue(clickElement(genderDropdownOptions("Male")));
            sendText(streetAddress, "123 Main St");
            sendText(zipCode, "76010");
            clickElement(patientPhoneNbr);
            Assert.assertTrue(sendText(patientPhoneNbr,StringUtils.phoneNumberGenerator()));
            Assert.assertTrue(scrolltoElement(continueBtn));
            Assert.assertTrue(clickElement(continueBtn));
        }
        catch (org.openqa.selenium.WebDriverException | AssertionError e) {
            Reporter.log("Exception in entering patient information: " + e.getMessage());
        }
    }
    public void reviewAndSchedule(){
        try {
            if (!verifyText(patientPrimaryContact,"Primary contact information")) {
                throw new IllegalStateException("Review page not loaded");
            }
            
            String reviewScreenshot = takeScreenShot();
            if (reviewScreenshot != null) {
                Reporter.logScreenShot("Review Page", reviewScreenshot);
            }
            
            scrollDown();
            
            if (!clickElement(finalizeAppointment)) {
                throw new IllegalStateException("Schedule button not found");
            }
            
            if (!verifyText(appointmentScheduled,"Appointment scheduled!")) {
                throw new IllegalStateException("Appointment confirmation not shown");
            }
            
            String confirmScreenshot = takeScreenShot();
            if (confirmScreenshot != null) {
                Reporter.logScreenShot("Appointment Confirmed", confirmScreenshot);
            }
            
            scrollDown();
            
            if (!clickElement(returnToAppointmentsBtn)) {
                throw new IllegalStateException("Return button not found");
            }
            
            isElementDisplayed(scheduleAppointmentBtn, 10);
            
        } catch (org.openqa.selenium.TimeoutException | org.openqa.selenium.NoSuchElementException e) {
            String screenshot = takeScreenShot();
            if (screenshot != null) {
                Reporter.logScreenShot("ERROR - Review And Schedule Failed", screenshot);
            }
            throw new IllegalStateException("Review and schedule failed - element not found", e);
        }
    }

    public void cancelAppointment() {
        Reporter.log("Cancelling appointment for patient: " + PATIENT_LAST_NAME);
        
        try {
            appointmentListbypatient();
            Reporter.logScreenShot("Cancel - Appointment Menu Opened", takeScreenShot());

            if (!clickElement(cancelAppointment)) {
                throw new IllegalStateException("Cancel option not found");
            }
            Reporter.logScreenShot("Cancel - Cancel Appointment Clicked", takeScreenShot());

            if (!clickElement(cancelOptions)) {
                throw new IllegalStateException("Dropdown not found");
            }
            Reporter.logScreenShot("Cancel - Cancellation Reason Dropdown", takeScreenShot());

            if (!clickElement(cancelReason)) {
                throw new IllegalStateException("Reason not found");
            }
            Reporter.logScreenShot("Cancel - Reason Selected", takeScreenShot());

            if (!clickElement(checkBoxVer)) {
                throw new IllegalStateException("Checkbox not found");
            }
            Reporter.logScreenShot("Cancel - Verification Checkbox Checked", takeScreenShot());

            if (!clickElement(cancelAppointmentBtn)) {
                throw new IllegalStateException("Cancel button not found");
            }
            Reporter.logScreenShot("Cancel - Appointment Cancelled", takeScreenShot());
            
            Reporter.log("Appointment cancelled successfully");
            
        } catch (org.openqa.selenium.TimeoutException | org.openqa.selenium.NoSuchElementException e) {
            String screenshot = takeScreenShot();
            if (screenshot != null) {
                Reporter.logScreenShot("ERROR - Cancel Failed", screenshot);
            }
            throw new IllegalStateException("Cancel appointment failed", e);
        }
    }

    public void administerCancelledAppointment() {
        try {
            Reporter.log(NAV_TO_CANCELED_TAB);
            if (!clickElement(cancelledTab)) {
                throw new IllegalStateException(CANCELED_TAB_NOT_FOUND);
            }
            isElementDisplayed(rescheduleOrCancelAppointmentEllipsis, 10);
            Reporter.log("Clicking reschedule/cancel ellipsis");
            if (!clickElement(rescheduleOrCancelAppointmentEllipsis)) {
                captureAndLog("ERROR - Ellipsis Not Found in Canceled");
                throw new IllegalStateException("Reschedule/cancel ellipsis not found in canceled tab");
            }
            isElementDisplayed(markAsAdministeredLink, 10);
            Reporter.log("Clicking Mark as Administered");
            if (!clickElement(markAsAdministeredLink)) {
                throw new IllegalStateException("Mark as administered option not found");
            }
            isElementDisplayed(confirmButton, 10);
            Reporter.log("Confirming administration");
            if (!clickElement(confirmButton)) {
                throw new IllegalStateException("Confirm button not found");
            }
            isElementDisplayed(administeredTab, 10);
            Reporter.log(NAV_TO_ADMINISTERED_TAB);
            if (!clickElement(administeredTab)) {
                throw new IllegalStateException(ADMINISTERED_TAB_NOT_FOUND);
            }
            isElementDisplayed(rescheduleOrCancelAppointmentEllipsis, 10);
            String patientFullName = PATIENT_LAST_NAME + ", " + PATIENT_FIRST_NAME;
            String patientNameLower = PATIENT_LAST_NAME.toLowerCase() + ", " + PATIENT_FIRST_NAME.toLowerCase();
            Reporter.log("Looking for patient in Administered tab: " + patientFullName);
            logPatientAdministeredResult(patientFullName, patientNameLower);
            captureAndLog("Administered Tab");
        } catch (org.openqa.selenium.WebDriverException e) {
            captureAndLog("ERROR - Administer Failed");
            throw new IllegalStateException("Failed to administer cancelled appointment: " + e.getMessage(), e);
        }
    }

    /** Verifies a single patient appears in the Administered tab and logs the outcome. */
    private void logPatientAdministeredResult(String patientFullName, String patientNameLower) {
        boolean found = false;
        if (isElementDisplayed(administeredByPatientName(patientNameLower), 5)) {
            found = verifyText(administeredByPatientName(patientNameLower), patientFullName);
        }
        if (!found && isElementDisplayed(administeredByPatientName(patientFullName), 5)) {
            found = verifyText(administeredByPatientName(patientFullName), patientFullName);
        }
        if (!found) {
            captureAndLog("ERROR - Patient Not Found in Administered");
            Reporter.log("Patient not found in administered tab: " + patientFullName);
        } else {
            Reporter.log("Patient successfully marked as administered");
        }
    }

    public void administerGroupCancelledAppointment() {
        try {
            Reporter.log(NAV_TO_CANCELED_TAB);
            if (!clickElement(cancelledTab)) {
                throw new IllegalStateException(CANCELED_TAB_NOT_FOUND);
            }
            isElementDisplayed(quickFilter, 10);
            Reporter.log("Filtering by patient name: " + PATIENT_LAST_NAME);
            if (!sendText(quickFilter, PATIENT_LAST_NAME)) {
                throw new IllegalStateException("Failed to enter filter");
            }
            isElementDisplayed(rescheduleOrCancelAppointmentEllipsis, 10);
            Reporter.log("Clicking reschedule/cancel ellipsis");
            if (!clickElement(rescheduleOrCancelAppointmentEllipsis)) {
                throw new IllegalStateException("Reschedule/cancel ellipsis not found");
            }
            isElementDisplayed(markGroupAsAdministeredLink, 10);
            Reporter.log("Clicking Mark Group as Administered");
            if (!clickElement(markGroupAsAdministeredLink)) {
                throw new IllegalStateException("Mark group as administered option not found");
            }
            isElementDisplayed(confirmButton, 10);
            Reporter.log("Confirming administration");
            if (!clickElement(confirmButton)) {
                throw new IllegalStateException("Confirm button not found");
            }
            isElementDisplayed(administeredTab, 10);
            Reporter.log(NAV_TO_ADMINISTERED_TAB);
            if (!clickElement(administeredTab)) {
                throw new IllegalStateException(ADMINISTERED_TAB_NOT_FOUND);
            }
            isElementDisplayed(rescheduleOrCancelAppointmentEllipsis, 10);
            String patient1FullName = PATIENT_LAST_NAME + ", " + PATIENT_FIRST_NAME;
            String patient1NameLower = PATIENT_LAST_NAME.toLowerCase() + ", " + PATIENT_FIRST_NAME.toLowerCase();
            String patient2FullName = PATIENT2_LAST_NAME + ", " + PATIENT2_FIRST_NAME;
            String patient2NameLower = PATIENT2_LAST_NAME.toLowerCase() + ", " + PATIENT2_FIRST_NAME.toLowerCase();
            Reporter.log("Looking for patients in Administered tab");
            logGroupPatientsAdministeredResult(patient1FullName, patient1NameLower, patient2FullName, patient2NameLower);
            captureAndLog("Group Administered Tab");
        } catch (org.openqa.selenium.WebDriverException e) {
            captureAndLog("ERROR - Group Administer Failed");
            throw new IllegalStateException("Failed to administer group cancelled appointment: " + e.getMessage(), e);
        }
    }

    /** Verifies both group patients appear in the Administered tab and logs the outcome. */
    private void logGroupPatientsAdministeredResult(
            String p1Full, String p1Lower, String p2Full, String p2Lower) {
        boolean found1 = verifyText(administeredByPatientName(p1Lower), p1Full)
                      || verifyText(administeredByPatientName(p1Full), p1Full);
        boolean found2 = verifyText(administeredByPatientName(p2Lower), p2Full)
                      || verifyText(administeredByPatientName(p2Full), p2Full);
        if (!found1 || !found2) {
            captureAndLog("ERROR - Patients Not Found in Administered");
            Reporter.log("Patients verification failed");
        } else {
            Reporter.log("Both patients successfully marked as administered");
        }
    }

    private void appointmentList() {
        Assert.assertTrue(clickElement(todaySelect));
        Assert.assertTrue(clickElement(weekSelect));
        Assert.assertTrue(sendText(quickFilter,"dach"));
        Assert.assertTrue(clickElement(threeDotsSelection));
    }

    private void appointmentListbypatient() {
        if (PATIENT_LAST_NAME == null || PATIENT_LAST_NAME.isEmpty()) {
            String errorScreenshot = takeScreenShot();
            if (errorScreenshot != null) {
                Reporter.logScreenShot("ERROR - PATIENT_LAST_NAME Null", errorScreenshot);
            }
            throw new IllegalStateException("PATIENT_LAST_NAME is null");
        }
        
        Reporter.log("Filtering appointments for: " + PATIENT_LAST_NAME);
        
        try {
            if (!clickElement(todaySelect)) {
                throw new IllegalStateException("Today filter not found");
            }
            if (!clickElement(weekSelect)) {
                throw new IllegalStateException("Week filter not found");
            }
            
            boolean textEntered = sendText(quickFilter, PATIENT_LAST_NAME);
            
            if (!textEntered) {
                String errorScreenshot = takeScreenShot();
                if (errorScreenshot != null) {
                    Reporter.logScreenShot("ERROR - Filter Input Failed", errorScreenshot);
                }
                throw new IllegalStateException("Failed to enter filter text");
            }

            if (!clickElement(threeDotsSelection)) {
                throw new IllegalStateException("Menu not found");
            }
            
        } catch (org.openqa.selenium.TimeoutException | org.openqa.selenium.NoSuchElementException e) {
            String screenshot = takeScreenShot();
            if (screenshot != null) {
                Reporter.logScreenShot("ERROR - Appointment List Failed", screenshot);
            }
            throw new IllegalStateException("Appointment list operation failed", e);
        }
    }

    public void rescheduleCancelledAppointment() {
        Reporter.log("Rescheduling cancelled appointment for patient: " + PATIENT_LAST_NAME);

        if (!clickElement(cancelledTab)) {
            throw new IllegalStateException(CANCELED_TAB_NOT_FOUND);
        }
        Reporter.logScreenShot("Reschedule - Canceled Tab", takeScreenShot());

        appointmentList();
        Reporter.logScreenShot("Reschedule - Appointment Menu Opened", takeScreenShot());

        if (!clickElement(rescheduleAppointmentBtn)) {
            throw new IllegalStateException("Reschedule Appointment button not found");
        }
        Reporter.logScreenShot("Reschedule - Time Slot Selection", takeScreenShot());

        selectTimeStamp();
        Reporter.logScreenShot("Reschedule - Time Slot Selected", takeScreenShot());

        if (!clickElement(reviewAppointment)) {
            throw new IllegalStateException("Review appointment button not found");
        }
        Reporter.logScreenShot("Reschedule - Review Page", takeScreenShot());

        if (!clickElement(rescheduleConfirm)) {
            throw new IllegalStateException("Reschedule confirm button not found");
        }
        Reporter.logScreenShot("Reschedule - Appointment Rescheduled", takeScreenShot());

        Reporter.log("Appointment rescheduled successfully");
    }

    public void selectServicesAndSchedule(String drugName) {
        Reporter.log("Selecting services: " + drugName);
        Assert.assertTrue(clickElement(selectServicesBtn), "Failed to click select services");
        
        selectPatientServices(drugName);
        patientInformation();
        reviewAndSchedule();
        
        Reporter.log("Appointment scheduled successfully");
    }

    /**
     * End-to-end COVID immunization scheduling flow, starting from the point
     * where the patient has already been selected on the appointments list page.
     *
     * <p>Flow (mirrors {@link #selectServicesAndScheduleLAI()}, adapted for the
     * COVID vaccine wizard steps):</p>
     * <ol>
     *   <li>Click "Select services"</li>
     *   <li>Scroll down and select the COVID vaccine chip</li>
     *   <li>Continue → lands on the Dose Selection page</li>
     *   <li>Verify the Dose Selection page is rendered (uses {@link #verifyDoseSelectionPage})</li>
     *   <li>Continue → patient is added to the appointment group (popup appears + disappears)</li>
     *   <li>Click "Find an appointment" → pick a time slot → Continue</li>
     *   <li>Confirm patient information</li>
     *   <li>Review &amp; finalise the booking</li>
     * </ol>
     *
     * @param vaccineName the brand name shown on the Dose Selection page
     *                    (e.g. {@code "Moderna"}, {@code "Pfizer"}); used only
     *                    for the vaccine-heading assertion in
     *                    {@link #verifyDoseSelectionPage}. Pass {@code null}
     *                    to skip the brand check.
     */
    public void selectServicesAndScheduleCovid(String vaccineName) {
        Reporter.log("Starting COVID immunization appointment scheduling flow");

        Assert.assertTrue(clickElement(selectServicesBtn),
            "Failed to click 'Select services' button");
        Reporter.logScreenShot("COVID - Select Services clicked", takeScreenShot());

        // ── Service selection step: pick the COVID vaccine chip ────────────
        scrollDown();
        Assert.assertTrue(clickElement(covidDrug),
            "Failed to select COVID vaccine");
        Reporter.logScreenShot("COVID - Vaccine chip selected", takeScreenShot());

        Assert.assertTrue(clickElement(footerPrimaryActionBtn),
            "Failed to click Continue after vaccine selection");

        // ── Dose Selection page: verify eligibility info is rendered ────────
        verifyDoseSelectionPage(vaccineName);
        Reporter.logScreenShot("COVID - Dose Selection page verified", takeScreenShot());

        Assert.assertTrue(clickElement(footerPrimaryActionBtn),
            "Failed to click Continue on Dose Selection page");

        // ── Wait for the patient-added confirmation to flash ───────────────
        webWait.until(ExpectedConditions.visibilityOfElementLocated(verifyPatientAddedTextPopup));
        webWait.until(ExpectedConditions.invisibilityOfElementLocated(verifyPatientAddedTextPopup));

        // ── Slot selection ─────────────────────────────────────────────────
        Assert.assertTrue(clickElement(findAppointment),
            "Failed to click 'Find an appointment'");
        scrollDown();
        Assert.assertTrue(verifyText(onlineSlots, ONLINE_SLOTS),
            "'Online slots' header not found on slot-selection page");
        selectTimeStamp();   // advances to next day automatically if today is fully booked
        Assert.assertTrue(clickElement(footerPrimaryActionBtn),
            "Failed to click Continue after slot selection");
        Reporter.logScreenShot("COVID - Slot selected and continued", takeScreenShot());

        // ── Patient info + review ───────────────────────────────────────────
        patientInformation();
        reviewAndSchedule();

        Reporter.log("COVID immunization appointment scheduled successfully.");
    }

    public void findAndScheduleAppointment() {
        clickElement(findAppointment);
        scrollDown();
        Assert.assertTrue(verifyText(onlineSlots, ONLINE_SLOTS));
        selectTimeStamp();
        clickElement(continueBtn);
    }

    public void selectServices(String drugName) {
        clickElement(selectServicesBtn);
        selectDrugPatientServices(drugName);
        Assert.assertTrue(verifyText(patientEligibility, "Patient eligibility:"));
        clickElement(continueBtn);
        webWait.until(ExpectedConditions.visibilityOfElementLocated(verifyPatientAddedTextPopup));
        webWait.until(ExpectedConditions.invisibilityOfElementLocated(verifyPatientAddedTextPopup));
    }

    public void selectServicesAndReschedule(String drugName) {
        Reporter.log("Starting reschedule flow for drug: " + drugName);

        if (!clickElement(selectServicesBtn)) {
            throw new IllegalStateException("Select Services button not found");
        }
        Reporter.logScreenShot("Step 1 - Select Services", takeScreenShot());

        selectPatientServices(drugName);
        Reporter.logScreenShot("Step 2 - Drug Selected: " + drugName, takeScreenShot());

        patientInformation();

        reviewAndSchedule();

        Reporter.logScreenShot("Step 3 - Appointment Scheduled (before cancel)", takeScreenShot());
        cancelAppointment();

        Reporter.logScreenShot("Step 4 - Appointment Cancelled (before reschedule)", takeScreenShot());
        rescheduleCancelledAppointment();

        Reporter.logScreenShot("Step 5 - Reschedule Complete", takeScreenShot());
    }

    public void selectServicesAndScheduleWithDose(String drugName, int doseCount) {
        clickElement(selectServicesBtn);
        selectPatientServicesWithDose(drugName, doseCount);
        patientInformation();
        reviewAndSchedule();
    }

    // ── LAI scheduling flow ─────────────────────────────────────────────────

    /**
     * Full end-to-end LAI scheduling flow, mirroring {@code selectServicesAndSchedule}
     * for immunizations.
     * <p>Flow:</p>
     * <ol>
     *   <li>Click "Select services"</li>
     *   <li>Select Clinical Services radio → check LAI_VISIT → Continue (×2)</li>
     *   <li>Click "Find an appointment" on the 'Who is getting service?' page</li>
     *   <li>Pick a time slot → Continue</li>
     *   <li>Confirm patient information</li>
     *   <li>Review and finalise the booking</li>
     * </ol>
     */
    public void selectServicesAndScheduleLAI() {
        Reporter.log("Starting LAI (Long Acting Injectable) appointment scheduling flow");
        Assert.assertTrue(clickElement(selectServicesBtn), FAILED_CLICK_SELECT_SERVICES);
        Reporter.logScreenShot("LAI - Select Services clicked", takeScreenShot());

        selectLAIServices();

        // ── Slot selection — identical to the immunization flow from here ─────
        scrollDown();
        Assert.assertTrue(verifyText(onlineSlots, ONLINE_SLOTS));
        selectTimeStamp();   // handles 'fully booked today' by advancing to next day
        Assert.assertTrue(clickElement(footerPrimaryActionBtn), "Failed to click Continue after slot selection");
        Reporter.logScreenShot("LAI - Slot selected and continued", takeScreenShot());

        patientInformation();
        reviewAndSchedule();

        Reporter.log("LAI appointment scheduled successfully.");
    }

    /**
     * Full end-to-end LAI reschedule flow.
     *
     * <p>Flow:</p>
     * <ol>
     *   <li>Schedule a LAI appointment via {@link #selectServicesAndScheduleLAI()}.</li>
     *   <li>Cancel that appointment via {@link #cancelAppointment()}.</li>
     *   <li>Reschedule from the Canceled tab via {@link #rescheduleCancelledAppointment()}.</li>
     * </ol>
     *
     * <p>Mirrors {@code selectServicesAndReschedule()} for immunizations — the cancel
     * and reschedule steps are intentionally reused (DRY); only the scheduling step
     * is LAI-specific.</p>
     */
    public void selectServicesAndRescheduleLAI() {
        Reporter.log("Starting LAI reschedule flow");
        selectServicesAndScheduleLAI();
        Reporter.logScreenShot("LAI Reschedule - Step 1: Appointment scheduled", takeScreenShot());

        cancelAppointment();
        Reporter.logScreenShot("LAI Reschedule - Step 2: Appointment cancelled", takeScreenShot());

        rescheduleCancelledAppointment();
        Reporter.logScreenShot("LAI Reschedule - Step 3: Appointment rescheduled", takeScreenShot());

        Reporter.log("LAI appointment rescheduled successfully.");
    }

    /**
     * Handles the LAI-specific service selection steps after the services page loads.
     *
     * <h4>Why JS clicks for the radio and checkbox?</h4>
     * MUI renders both {@code <input type="radio">} and {@code <input type="checkbox">}
     * as zero-opacity overlays inside a styled {@code <span>} parent. Selenium's
     * {@code elementToBeClickable()} calls {@code visibilityOfElementLocated()} internally,
     * which fails on opacity-0 inputs and causes the AssertionError seen in the stack trace.
     * {@code clickElementWithJavaScript()} bypasses the visibility check entirely.
     *
     * <h4>Why {@code presenceOfElementLocated} for page-load guards?</h4>
     * After a React-driven page transition, the hidden MUI inputs are in the DOM
     * immediately but are never "visible" in the CSS sense — so {@code visibilityOfElementLocated}
     * would time out even on a fully loaded page. {@code presenceOfElementLocated} just
     * checks the DOM, which is what we actually need here.
     */
    private void selectLAIServices() {
        // ── Guard: wait for /services page to finish rendering ─────────────────
        // Wait for the Clinical Services radio itself — the element we actually
        // click in Step 1 — rather than an unrelated 'immunizations' sentinel.
        // This is more DRY (reuses clinicalServicesRadio) and more resilient:
        // the guard now fails fast with a meaningful message if the UI changes the
        // clinicalServices radio, rather than silently timing out on an element
        // that belongs to a different service type and may no longer be present.
        Reporter.log("LAI Step 0 — waiting for /services page to finish rendering (clinicalServices radio)");
        try {
            webWait.until(ExpectedConditions.presenceOfElementLocated(clinicalServicesRadio));
        } catch (org.openqa.selenium.TimeoutException e) {
            Reporter.logScreenShot("LAI ERROR — /services page did not load", takeScreenShot());
            throw new IllegalStateException(
                    "Services page did not render within the configured wait timeout", e);
        }
        Reporter.logScreenShot("LAI Step 0 - Services page ready", takeScreenShot());

        // ── Step 1: Clinical Services radio ─────────────────────────────────────
        // scrolltoElement brings the MUI container into the viewport before clicking.
        // JS click is required because the actual <input> has opacity:0 — Selenium's
        // standard click throws ElementNotInteractableException on such inputs.
        Reporter.log("LAI Step 1 — selecting Clinical Services radio");
        scrolltoElement(clinicalServicesRadio);
        Assert.assertTrue(clickElementWithJavaScript(clinicalServicesRadio), "Clinical Services radio not clickable — JS click failed");
        Reporter.logScreenShot("LAI Step 1 - Clinical Services selected", takeScreenShot());

        // ── Step 2: LAI_VISIT checkbox ──────────────────────────────────────────
        // Selecting Clinical Services triggers React to reveal the LAI_VISIT option.
        // Wait for the hidden input to be present in the DOM, then JS-click it.
        Reporter.log("LAI Step 2 — waiting for LAI_VISIT checkbox to appear in DOM");
        try {
            webWait.until(ExpectedConditions.presenceOfElementLocated(laiVisitCheckbox));
        } catch (org.openqa.selenium.TimeoutException e) {
            Reporter.logScreenShot("LAI ERROR — LAI_VISIT checkbox not found", takeScreenShot());
            throw new IllegalStateException(
                    "LAI_VISIT checkbox did not appear after selecting Clinical Services", e);
        }
        scrolltoElement(laiVisitCheckbox);
        Assert.assertTrue(clickElementWithJavaScript(laiVisitCheckbox), "LAI_VISIT checkbox not clickable — JS click failed");
        Reporter.logScreenShot("LAI Step 2 - LAI_VISIT checked", takeScreenShot());

        // ── Step 3: Continue — service selection page ───────────────────────────
        // The footer button is a fully-visible div[role='button']; regular click works.
        Reporter.log("LAI Step 3 — Continue (service selection page)");
        Assert.assertTrue(clickElement(footerPrimaryActionBtn), "First Continue button not clickable");
        Reporter.logScreenShot("LAI Step 3 - After first Continue", takeScreenShot());

        // ── Step 4: Continue — dose / eligibility page ──────────────────────────
        Reporter.log("LAI Step 4 — Continue (dose / eligibility page)");
        Assert.assertTrue(clickElement(footerPrimaryActionBtn), "Second Continue button not clickable");
        Reporter.logScreenShot("LAI Step 4 - After second Continue", takeScreenShot());

        // ── Step 5: Find an appointment — /patientgroup page ─────────────────
        // WHY NOT patientNameVerify ("DACH")?
        //   • /findPatient search-results table has CSS text-transform:uppercase →
        //     the DOM text is "Dach" but renders as "DACH". XPath text() reads the
        //     raw DOM value, so //*[text()='DACH'] never matches on /patientgroup
        //     where the DOM stores "Deon Dach" (Title Case, no CSS transform).
        //
        // WHY isElementDisplayed(findAppointment) as the guard?
        //   • QA Kitten confirmed: on /patientgroup the ONLY button is
        //     "Find an appointment" (aria-label="Footer Primary"). Waiting for
        //     it to be visible is simultaneously the page-load guard AND the
        //     pre-click readiness check — one wait does both jobs (DRY).
        Reporter.log("LAI Step 5 — waiting for /patientgroup 'Find an appointment' button");
        if (!isElementDisplayed(findAppointment, 20)) {
            Reporter.logScreenShot("LAI ERROR — /patientgroup did not load", takeScreenShot());
            throw new IllegalStateException(
                    "'/patientgroup' page did not render — 'Find an appointment' button" +
                    " not visible after 20 s. Current URL: " + getURL());
        }
        Reporter.logScreenShot("LAI Step 5 - patientgroup ready, clicking Find an appointment",
                               takeScreenShot());

        boolean findApptClicked = clickElement(findAppointment);
        if (!findApptClicked) {
            Reporter.log("LAI Step 5 — regular click failed, retrying with JS click");
            findApptClicked = clickElementWithJavaScript(findAppointment);
        }
        Assert.assertTrue(findApptClicked, "'Find an appointment' button not clickable after regular + JS attempts");
        Reporter.logScreenShot("LAI Step 5 - Find an appointment clicked", takeScreenShot());
    }

    private By selectDrug(String drugInfo) {
        return switch (drugInfo) {
            case "rsv_drug"         -> rsvDrug;
            case "covid_drug"       -> covidDrug;
            case "flu_drug"         -> fluDrug;
            case "hepatitisA_B_drug"-> hepatitisABDrug;
            case "hepatitisB"       -> hepatitisB;
            case "pneumonia"        -> pneumonia;
            default                 -> By.xpath("");
        };
    }

    // ── Canceled tab date-filter public API ────────────────────────────────

    /**
     * Clicks the Canceled tab and waits for the date-range dropdown trigger to be
     * present — confirming the tab content has fully rendered.
     */
    public void goToCancelledTab() {
        Reporter.log(NAV_TO_CANCELED_TAB);
        if (!clickElement(cancelledTab)) {
            captureAndLog("ERROR - Canceled tab not clickable");
            throw new IllegalStateException(CANCELED_TAB_NOT_FOUND);
        }
        // Wait for the Canceled Appointments List container, which is the canonical
        // signal that the tab has fully rendered its content.
        boolean listVisible = isElementDisplayed(canceledListContainer, 15);
        captureAndLog("Canceled tab loaded (list container visible=" + listVisible + ")");
        Reporter.log("Canceled tab ready, list container visible: " + listVisible);
    }

    /**
     * Opens the "Choose a date (mm/dd/yyyy)" dropdown on the Canceled tab and waits
     * until a {@code dropdownMenuItem} appears inside the Canceled Appointments List
     * section — confirming the menu has fully rendered before the caller selects an option.
     *
     * <h3>Why scope the listbox guard to the Canceled list?</h3>
     * <p>Other components on the page (e.g. the gender picker) also render divs with
     * {@code aria-label="dropdownMenuItem"}. An unscoped wait would match those and
     * return {@code true} even when the date-filter menu is still closed, causing
     * the re-click guard to fire and <em>close</em> the dropdown again.
     *
     * <h3>Re-click guard</h3>
     * <p>Some React builds toggle the dropdown closed on the first click if the element
     * receives the event before the overlay is fully painted. A single retry is safe.
     */
    public void openDateFilterDropdown() {
        Reporter.log("Opening Choose-a-date dropdown");
        boolean opened = clickElement(historicalTabDateDropdown);
        if (!opened) {
            Reporter.log(ERROR_REGULAR_CLICK_FAILED_RETRY);
            opened = clickElementWithJavaScript(historicalTabDateDropdown);
        }
        if (!opened) {
            captureAndLog(ERROR_DROPDOWN_NOT_CLICKABLE);
            throw new IllegalStateException("Choose-a-date dropdown could not be opened");
        }

        // Guard: wait for a scoped dropdownMenuItem inside Canceled list — confirms
        // the menu opened. Only re-click if the menu genuinely did not open.
        boolean listboxReady = isElementDisplayed(dateFilterListbox, 8);
        if (!listboxReady) {
            Reporter.log(ERROR_MENU_NOT_VISIBLE);
            clickElementWithJavaScript(historicalTabDateDropdown);
            listboxReady = isElementDisplayed(dateFilterListbox, 5);
        }
        captureAndLog("Dropdown opened — scoped menu ready: " + listboxReady);
        Reporter.log("Choose-a-date dropdown opened. Scoped menu visible: " + listboxReady);
        if (!listboxReady) {
            captureAndLog("ERROR - dropdown menu did not render after two click attempts");
            throw new IllegalStateException(
                "Date-filter dropdown menu did not open. " +
                "No dropdownMenuItem visible inside Canceled Appointments List after 13 s."
            );
        }
    }

    /**
     * Selects one option from the open date-filter dropdown and validates that the
     * Canceled Appointments List container is still rendered after the selection.
     *
     * <h3>Validation target</h3>
     * <p>We check for {@code //div[@aria-label='Canceled Appointments List']} rather than
     * the tab label text, which is too broad and can match unrelated elements.</p>
     *
     * @param label the prefix of the visible option text:
     *              {@code "Today"} | {@code "This week"} | {@code "Last week"} |
     *              {@code "Last 4 weeks"}
     * @return {@code true} when the Canceled list container is still visible after
     *         selection (page did not crash or navigate away)
     */
    public boolean selectDateFilterAndValidate(String label) {
        Reporter.log("Selecting date-filter option: [" + label + "]");
        By optionLocator = dateFilterOption(label);

        if (!isElementDisplayed(optionLocator, 10)) {
            captureAndLog(ERROR_OPTION_NOT_VISIBLE + label);
            throw new IllegalStateException(ERROR_DATE_FILTER_NOT_VISIBLE + label);
        }

        boolean clicked = clickElement(optionLocator);
        if (!clicked) {
            Reporter.log(ERROR_REGULAR_CLICK_FAILED_FOR + label + ERROR_RETRY_JS_CLICK);
            clicked = clickElementWithJavaScript(optionLocator);
        }
        if (!clicked) {
            captureAndLog(ERROR_OPTION_NOT_CLICKABLE + label);
            throw new IllegalStateException("Date-filter option not clickable: " + label);
        }

        // Validate: the Canceled Appointments List container must still be present
        // after the filter is applied, confirming the page reloaded without crashing.
        boolean listStillVisible = isElementDisplayed(canceledListContainer, 10);
        captureAndLog(AFTER_SELECTING + label + "] — Canceled list visible: " + listStillVisible);
        Reporter.log(DATE_FILTER + label + "] applied. Canceled list visible: " + listStillVisible);
        return listStillVisible;
    }

    // ── Administered tab — date-range filter ──────────────────────────────────
    //
    // DOM structure confirmed via live DOM inspector run against
    // https://imz-assoc-app.stage.walmart.com/ (store 32115, 2026-04-26):
    //
    //   Tab button:  <div aria-label='Administered' role='tab'>
    //   List container: <div aria-label='Administered Appointments List'>
    //   Date trigger: <div tabindex='0'> text='Today, Apr 26 2026'  (same shape as Cancelled)
    //   Menu options: 4 × <div aria-label='dropdownMenuItem'> — identical label set
    //
    // The trigger XPath (chooseDateDropdown) is REUSED — only one "Choose a date"
    // label is in the DOM at a time (React conditionally renders tab content).
    // The scoped listbox guard and list-container validator use the Administered
    // section's own aria-label to avoid any cross-tab false-positive matches.

    /**
     * Readiness guard: waits for at least one {@code dropdownMenuItem} inside the
     * <em>Administered Appointments List</em> section — confirms the date-filter
     * menu has opened on the Administered tab.
     *
     * <p>Scoped to {@code aria-label='Administered Appointments List'} so that
     * other components that may render {@code dropdownMenuItem} divs (e.g. the
     * gender picker) cannot produce a false-positive match.
     */
    private final By administeredDateFilterListbox = By.xpath(
        "//div[@aria-label='Administered Appointments List']//div[@aria-label='dropdownMenuItem']"
    );

    /**
     * Post-filter validation anchor: confirms the Administered Appointments List
     * container is still rendered after a date-range filter option is selected.
     */
    private final By administeredListContainer = By.xpath(
        "//div[@aria-label='Administered Appointments List']"
    );

    /**
     * Clicks the Administered tab and waits for the list container to appear,
     * confirming the tab content has fully rendered.
     */
    public void goToAdministeredTab() {
        Reporter.log(NAV_TO_ADMINISTERED_TAB);
        if (!clickElement(administeredTab)) {
            captureAndLog("ERROR - Administered tab not clickable");
            throw new IllegalStateException(ADMINISTERED_TAB_NOT_FOUND);
        }
        boolean listVisible = isElementDisplayed(administeredListContainer, 15);
        captureAndLog("Administered tab loaded (list container visible=" + listVisible + ")");
        Reporter.log("Administered tab ready, list container visible: " + listVisible);
    }

    /**
     * Opens the "Choose a date (mm/dd/yyyy)" dropdown on the Administered tab.
     *
     * <p>Reuses {@link #chooseDateDropdown} — safe because React renders only the
     * active tab's content, so exactly one "Choose a date" label exists in the DOM.
     * The readiness guard is scoped to the Administered list to prevent false
     * positives from other components on the page.
     */
    public void openAdministeredDateFilterDropdown() {
        Reporter.log("Opening Choose-a-date dropdown on Administered tab");
        boolean opened = clickElement(historicalTabDateDropdown);
        if (!opened) {
            Reporter.log(ERROR_REGULAR_CLICK_FAILED_RETRY);
            opened = clickElementWithJavaScript(historicalTabDateDropdown);
        }
        if (!opened) {
            captureAndLog(ERROR_DROPDOWN_NOT_CLICKABLE);
            throw new IllegalStateException("Choose-a-date dropdown could not be opened on Administered tab");
        }

        boolean listboxReady = isElementDisplayed(administeredDateFilterListbox, 8);
        if (!listboxReady) {
            Reporter.log(ERROR_MENU_NOT_VISIBLE);
            clickElementWithJavaScript(historicalTabDateDropdown);
            listboxReady = isElementDisplayed(administeredDateFilterListbox, 5);
        }
        captureAndLog("Administered dropdown opened — scoped menu ready: " + listboxReady);
        Reporter.log("Choose-a-date dropdown opened on Administered tab. Scoped menu visible: " + listboxReady);
        if (!listboxReady) {
            captureAndLog("ERROR - Administered dropdown menu did not render after two click attempts");
            throw new IllegalStateException(
                "Date-filter dropdown menu did not open on Administered tab. " +
                "No dropdownMenuItem visible inside Administered Appointments List after 13 s."
            );
        }
    }

    /**
     * Selects one option from the open date-filter dropdown on the Administered tab
     * and validates that the Administered Appointments List container remains visible.
     *
     * <p>Reuses {@link #dateFilterOption(String)} — the option DOM structure is
     * identical across both Cancelled and Administered tabs.
     *
     * @param label the prefix of the visible option text:
     *              {@code "Today"} | {@code "This week"} | {@code "Last week"} |
     *              {@code "Last 4 weeks"}
     * @return {@code true} when the Administered list container is still visible
     *         after selection (page did not crash or navigate away)
     */
    public boolean selectAdministeredDateFilterAndValidate(String label) {
        Reporter.log("Selecting date-filter option on Administered tab: [" + label + "]");
        By optionLocator = dateFilterOption(label);

        if (!isElementDisplayed(optionLocator, 10)) {
            captureAndLog(ERROR_OPTION_NOT_VISIBLE + label);
            throw new IllegalStateException(ERROR_DATE_FILTER_NOT_VISIBLE + label);
        }

        boolean clicked = clickElement(optionLocator);
        if (!clicked) {
            Reporter.log(ERROR_REGULAR_CLICK_FAILED_FOR + label + ERROR_RETRY_JS_CLICK);
            clicked = clickElementWithJavaScript(optionLocator);
        }
        if (!clicked) {
            captureAndLog(ERROR_OPTION_NOT_CLICKABLE + label);
            throw new IllegalStateException("Date-filter option not clickable on Administered tab: " + label);
        }

        boolean listStillVisible = isElementDisplayed(administeredListContainer, 10);
        captureAndLog(AFTER_SELECTING + label + "] — Administered list visible: " + listStillVisible);
        Reporter.log(DATE_FILTER + label + "] applied on Administered tab. List visible: " + listStillVisible);
        return listStillVisible;
    }

    // ── Appointment tab (default Booked/Upcoming list) — date-range filter ────
    //
    // The Appointment tab is the DEFAULT tab on the Appointments page — landing
    // on the page automatically lands you on this tab. Its date-filter dropdown
    // is forward-looking (Today, This week, Next week, Next 4 weeks, Specific
    // date) — versus the backward-looking Cancelled/Administered tabs.
    //
    // Locator strategy mirrors the Cancelled/Administered counterparts but uses
    // a permissive aria-label match that EXCLUDES "Canceled" and "Administered"
    // — this avoids hard-coding the exact aria-label (which has been observed
    // as one of: "Booked Appointments List", "Scheduled Appointments List",
    // "Upcoming Appointments List", "Appointments List") while still scoping
    // tightly enough to prevent cross-tab false positives.

    /**
     * Default Appointment tab button (forward-looking list of upcoming /
     * booked appointments). The tab is normally already active when the page
     * loads, so {@link #goToAppointmentTab()} only clicks it when the list
     * container isn't already visible.
     *
     * <p>Permissive aria-label match keeps the locator working across the
     * label variants observed on stage ("Appointment", "Appointments",
     * "Upcoming", "Booked").
     */
    private static final By appointmentTab = By.xpath(
        "//*[@role='tab' and (" +
        "@aria-label='Appointment' or @aria-label='Appointments' or " +
        "@aria-label='Upcoming' or @aria-label='Booked')]"
    );

    /**
     * Readiness guard: waits for at least one {@code dropdownMenuItem} inside
     * the Appointment tab's list section, confirming the date-filter menu has
     * fully opened. Scope explicitly excludes the Canceled / Administered
     * lists so a stray rendered tab cannot produce a false positive.
     */
    private final By appointmentDateFilterListbox = By.xpath(
        "//div[@aria-label='dropdownMenuItem']"
    );

    /**
     * Post-filter validation anchor: confirms the Appointment tab list
     * container is still rendered after a date-range filter is applied
     * (i.e. the page did not crash or navigate away).
     */
    private final By appointmentListContainer = By.xpath(
        "//div[@aria-label='Table Row']"
    );

    /**
     * Date input revealed by the "Specific date" filter option. Used by the
     * HCI-15478 ("Validate appointment tab specific date") flow to confirm
     * the date picker is rendered after the option is selected.
     *
     * <p>Permissive match across known patterns: aria-label, placeholder, or
     * the "mm/dd/yyyy" hint text — any one of which signals the picker.
     */
    private final By specificDateInput = By.xpath(
        "//input[contains(translate(@aria-label,'DATE','date'),'date') " +
        "or contains(@placeholder,'mm/dd/yyyy') " +
        "or contains(@placeholder,'MM/DD/YYYY')]"
    );

    /**
     * Readiness signal used by {@link #goToAppointmentTab()} and
     * {@link #selectAppointmentDateFilterAndValidate(String)} when the
     * appointment list container's exact {@code aria-label} can't be relied
     * upon. The "Choose a date" dropdown trigger is rendered on every
     * date-filterable tab, so its presence is a stable proof-of-life signal
     * even when the list container's aria-label varies between environments.
     */
    private boolean isAppointmentTabHealthy(int timeoutSec) {
        return isElementDisplayed(appointmentListContainer, 1)
            || isElementDisplayed(chooseDateDropdown, timeoutSec);
    }

    /**
     * Ensures the default Appointment tab is the active tab. Idempotent —
     * a no-op (apart from logging) when the tab is already active.
     *
     * <p>Readiness is verified via {@link #isAppointmentTabHealthy(int)},
     * which accepts EITHER the appointment list container OR the
     * "Choose a date" dropdown trigger as proof the tab has fully rendered.
     * This avoids hard-coding an exact list-container aria-label that has
     * been observed to vary across stage / production builds.
     */
    public void goToAppointmentTab() {
        if (isAppointmentTabHealthy(3)) {
            Reporter.log("Already on Appointment tab");
            return;
        }
        Reporter.log("Navigating to Appointment tab");
        if (!clickElement(appointmentTab)) {
            // Already-active tab is not always a clickable element — fall back
            // to verifying readiness via the dropdown trigger.
            Reporter.log("Appointment tab not clickable — verifying default-tab state");
        }
        boolean ready = isAppointmentTabHealthy(15);
        captureAndLog("Appointment tab loaded (ready=" + ready + ")");
        Reporter.log("Appointment tab ready: " + ready);
        if (!ready) {
            throw new IllegalStateException(
                "Appointment tab did not become ready — neither the list container " +
                "nor the Choose-a-date dropdown trigger was visible. Page may have " +
                "failed to load."
            );
        }
    }

    /**
     * Opens the "Choose a date (mm/dd/yyyy)" dropdown on the Appointment tab.
     *
     * <p>Reuses {@link #chooseDateDropdown} — safe because React renders only
     * the active tab's content, so exactly one "Choose a date" label is in
     * the DOM at any time. Readiness guard is scoped to the Appointment list
     * to avoid false positives from other components.
     */
    public void openAppointmentDateFilterDropdown() {
        Reporter.log("Opening Choose-a-date dropdown on Appointment tab");
        boolean opened = clickElement(chooseDateDropdown);
        if (!opened) {
            Reporter.log(ERROR_REGULAR_CLICK_FAILED_RETRY);
            opened = clickElementWithJavaScript(chooseDateDropdown);
        }
        if (!opened) {
            captureAndLog(ERROR_DROPDOWN_NOT_CLICKABLE);
            throw new IllegalStateException("Choose-a-date dropdown could not be opened on Appointment tab");
        }

        boolean listboxReady = isElementDisplayed(appointmentDateFilterListbox, 8);
        if (!listboxReady) {
            Reporter.log(ERROR_MENU_NOT_VISIBLE);
            clickElementWithJavaScript(chooseDateDropdown);
            listboxReady = isElementDisplayed(appointmentDateFilterListbox, 5);
        }
        captureAndLog("Appointment dropdown opened — scoped menu ready: " + listboxReady);
        Reporter.log("Choose-a-date dropdown opened on Appointment tab. Scoped menu visible: " + listboxReady);
        if (!listboxReady) {
            captureAndLog("ERROR - Appointment dropdown menu did not render after two click attempts");
            throw new IllegalStateException(
                "Date-filter dropdown menu did not open on Appointment tab. " +
                "No dropdownMenuItem visible inside the Appointment list after 13 s."
            );
        }
    }

    /**
     * Selects one option from the open date-filter dropdown on the Appointment
     * tab and validates that the Appointment list container is still rendered
     * after the selection.
     *
     * <p>Use this for {@code "Today"} / {@code "This week"} / {@code "Next week"}
     * / {@code "Next 4 weeks"} — for the {@code "Specific date"} option, use
     * {@link #selectAppointmentSpecificDateOption()} instead, since that path
     * surfaces a date picker rather than reloading the list directly.
     *
     * @param label option-text prefix (matches via {@code contains})
     * @return {@code true} if the appointment list container is still visible
     *         after the selection (page did not crash or navigate away)
     */
    public boolean selectAppointmentDateFilterAndValidate(String label) {
        Reporter.log("Selecting date-filter option on Appointment tab: [" + label + "]");
        By optionLocator = dateFilterOption(label);

        if (!isElementDisplayed(optionLocator, 10)) {
            captureAndLog(ERROR_OPTION_NOT_VISIBLE + label);
            throw new IllegalStateException(ERROR_DATE_FILTER_NOT_VISIBLE + label);
        }

        boolean clicked = clickElement(optionLocator);
        if (!clicked) {
            Reporter.log(ERROR_REGULAR_CLICK_FAILED_FOR + label + ERROR_RETRY_JS_CLICK);
            clicked = clickElementWithJavaScript(optionLocator);
        }
        if (!clicked) {
            captureAndLog(ERROR_OPTION_NOT_CLICKABLE + label);
            throw new IllegalStateException("Date-filter option not clickable on Appointment tab: " + label);
        }

        boolean stillHealthy = isAppointmentTabHealthy(10);
        captureAndLog(AFTER_SELECTING + label + "] — Appointment tab healthy: " + stillHealthy);
        Reporter.log(DATE_FILTER + label + "] applied on Appointment tab. Healthy: " + stillHealthy);
        return stillHealthy;
    }

    /**
     * Selects the "Specific Date" option on the Appointment tab and validates
     * that the date-picker input is rendered. Acceptance is permissive: either
     * a date input becomes visible OR the tab remains healthy — both confirm
     * the page reacted to the selection without crashing.
     *
     * <p>Note the exact label casing: {@code "Specific Date"} (capital D).
     * The other date-filter labels match by prefix because the live UI
     * appends a date suffix (e.g. {@code "Today, Apr 27 2026"}), but
     * "Specific Date" has no suffix, so an equality match is also valid.
     *
     * @return {@code true} if the page is still in a healthy state after
     *         selecting "Specific Date" (date input visible OR appointment
     *         tab still healthy)
     */
    public boolean selectAppointmentSpecificDateOption() {
        final String label = "Specific Date";
        Reporter.log("Selecting Specific Date option on Appointment tab");
        By optionLocator = dateFilterOption(label);

        if (!isElementDisplayed(optionLocator, 10)) {
            captureAndLog("ERROR - Option not visible: " + label);
            throw new IllegalStateException("Date-filter option not visible in dropdown: " + label);
        }

        boolean clicked = clickElement(optionLocator);
        if (!clicked) {
            Reporter.log("Regular click failed for [" + label + "] — retrying with JS click");
            clicked = clickElementWithJavaScript(optionLocator);
        }
        if (!clicked) {
            captureAndLog("ERROR - Option not clickable: " + label);
            throw new IllegalStateException("Date-filter option not clickable on Appointment tab: " + label);
        }

        boolean dateInputVisible = isElementDisplayed(specificDateInput, 8);
        boolean stillHealthy = isAppointmentTabHealthy(5);
        boolean ok = dateInputVisible || stillHealthy;
        captureAndLog(
            AFTER_SELECTING + label + "] — date input visible: " + dateInputVisible +
            ", tab healthy: " + stillHealthy
        );
        Reporter.log(
            "Specific date option applied. Date input visible: " + dateInputVisible +
            ", tab still healthy: " + stillHealthy
        );
        return ok;
    }
    // ── Immunization Dose Selection page helpers ────────────────────────────

    /**
     * Asserts that the Immunization Dose Selection page is fully rendered.
     * Verifies the header banner, all four stepper labels, the main COVID-19
     * heading, and both footer buttons.
     *
     * @param vaccineName the brand name displayed in the page
     *                    (e.g. {@code "Moderna"}, {@code "Pfizer"});
     *                    pass {@code null} to skip the brand-heading check.
     */
    public ClinicalServiceAppointmentsPage verifyDoseSelectionPage(String vaccineName) {
        Assert.assertTrue(
            isElementDisplayed(clinicalServicesHeader, 10),
            "Clinical Services header not displayed on dose-selection page");
        Assert.assertTrue(
            isElementDisplayed(stepPatientsAndServices, 5),
            "Step label 'Patients & Services' not displayed");
        Assert.assertTrue(
            isElementDisplayed(stepAppointmentDateTime, 5),
            "Step label 'Appointment Day & Time' not displayed");
        Assert.assertTrue(
            isElementDisplayed(stepPatientInformation, 5),
            "Step label 'Patient Information' not displayed");
        Assert.assertTrue(
            isElementDisplayed(stepReviewAndSchedule, 5),
            "Step label 'Review & Schedule' not displayed");
        Assert.assertTrue(
            isElementDisplayed(doseSelectionHeading, 5),
            "Dose selection main heading not displayed");
        if (vaccineName != null) {
            Assert.assertTrue(
                isElementDisplayed(vaccineReviewHeading(vaccineName), 5),
                "Vaccine review heading for '" + vaccineName + "' not displayed");
        }
        Assert.assertTrue(
            isElementDisplayed(patientEligibility, 5),
            "'Patient eligibility:' heading not displayed");
        Assert.assertTrue(
            isElementDisplayed(previousBtn, 5),
            "'Previous' button not displayed");
        Assert.assertTrue(
            isElementDisplayed(footerPrimaryActionBtn, 5),
            "'Continue' (footer primary) button not displayed");
        Reporter.log("Dose Selection page verified" +
            (vaccineName != null ? " — vaccine: " + vaccineName : ""));
        return this;
    }

    /**
     * Map keys returned by {@link #validateFluBookingCopyTexts()}. Short,
     * placeholder-free labels — the actual rendered copy is logged separately
     * by {@link #recordFluCopyTexts(Map, String)} so reports show real text
     * (with patient names / vaccine brands) instead of {@code "..."}.
     */
    public static final String FLU_KEY_TITLE       = "Vaccine title heading";
    public static final String FLU_KEY_FLUBLOK     = "Flu vaccine info subheading";
    public static final String FLU_KEY_ELIG_LABEL  = "Patient eligibility label";
    public static final String FLU_KEY_ELIG_BULLET = "Eligibility bullet";

    /**
     * Expected FLU copy texts validated in {@link #recordFluCopyTexts}.
     * <p><b>Title</b> &amp; <b>Flublok info</b> have a dynamic suffix
     * (vaccine sub-type / patient name / brand name), so only the constant
     * prefix is asserted. <b>Patient eligibility label</b> and
     * <b>Eligibility bullet</b> are fully constant — the entire expected
     * string must be present (whitespace-normalized).
     */
    private static final String EXPECTED_FLU_TITLE_PREFIX     = "Let's find the right";
    private static final String EXPECTED_FLU_TITLE_TAIL       = "vaccine";
    private static final String EXPECTED_FLU_FLUBLOK_PREFIX   = "Review this information about";
    private static final String EXPECTED_FLU_ELIG_LABEL_FULL  = "Patient eligibility:";
    private static final String EXPECTED_FLU_ELIG_BULLET_FULL =
            "All patients may be eligible to receive a flu vaccination "
            + "every season for their protection and the protection of "
            + "others around them.";

    /**
     * Drives the FLU booking flow far enough to validate the four static copy
     * texts called out by HCI-15515, then returns a map of {@code label →
     * found?} so the caller can report all four assertions in a single
     * {@code SoftAssert#assertAll()}.
     *
     * <p><b>Pre-condition:</b> patient information has been entered (i.e.
     * {@link #fillPatientInfo()} has run, leaving the "Schedule an
     * Appointment" button visible).
     *
     * <p><b>Flow:</b>
     * <ol>
     *   <li>Click <i>Select services</i></li>
     *   <li>Scroll into view and click the FLU drug tile</li>
     *   <li>Capture screenshot — drug-detail page</li>
     *   <li>Check vaccine title and Flublok info on the drug-detail page</li>
     *   <li>Click <i>Continue</i> to advance to the eligibility page (only
     *       when the button is visible — older builds inline eligibility
     *       copy on the drug-detail page itself, so a missing Continue is
     *       not fatal)</li>
     *   <li>Capture screenshot — eligibility page</li>
     *   <li>Re-check all four texts on this page (each label is tracked as
     *       "ever seen" — once true, it stays true)</li>
     * </ol>
     *
     * @return ordered map of copy-text label → visible. Every key listed in
     *         the {@code FLU_KEY_*} constants is guaranteed to be present.
     */
    public Map<String, Boolean> validateFluBookingCopyTexts() {
        Map<String, Boolean> results = new LinkedHashMap<>();
        results.put(FLU_KEY_TITLE,       false);
        results.put(FLU_KEY_FLUBLOK,     false);
        results.put(FLU_KEY_ELIG_LABEL,  false);
        results.put(FLU_KEY_ELIG_BULLET, false);

        Reporter.log("=== FLU copy-text validation — Phase 1: drug-detail page ===");
        Assert.assertTrue(clickElement(selectServicesBtn), FAILED_CLICK_SELECT_SERVICES);
        scrollDown();
        Assert.assertTrue(clickElement(fluDrug),
            "FLU drug tile not clickable — verify aria-label matches one of: FLU / Flu / INFLUENZA");
        captureAndLog("FLU drug-detail page");

        recordFluCopyTexts(results, "Phase 1 (drug-detail)");

        Reporter.log("=== FLU copy-text validation — Phase 2: eligibility page ===");
        if (isElementDisplayed(continueBtn, 5)) {
            clickElement(continueBtn);
            captureAndLog("FLU eligibility page");
            recordFluCopyTexts(results, "Phase 2 (eligibility)");
        } else {
            Reporter.log("Continue button not visible — copy may be inlined on the detail page");
        }

        Reporter.log("FLU copy-text final results: " + results);
        return results;
    }

    /**
     * Helper for {@link #validateFluBookingCopyTexts()} — checks each of the
     * four locators against the current DOM and updates the results map only
     * when a label was not previously found ("ever seen" semantics).
     *
     * <p>This tolerance is what allows the validation to survive UI variants
     * where copy moves between the drug-detail page and the eligibility
     * page across builds.
     */
    private void recordFluCopyTexts(Map<String, Boolean> results, String phase) {
        validateFluElement(results, FLU_KEY_TITLE, fluVaccineTitle, 5, phase,
            EXPECTED_FLU_TITLE_PREFIX, EXPECTED_FLU_TITLE_TAIL);

        validateFluElement(results, FLU_KEY_FLUBLOK, fluFlublokInfo, 3, phase,
            EXPECTED_FLU_FLUBLOK_PREFIX, null);

        validateFluElement(results, FLU_KEY_ELIG_LABEL, fluPatientEligibilityLabel, 3, phase,
            EXPECTED_FLU_ELIG_LABEL_FULL, null);

        validateFluElement(results, FLU_KEY_ELIG_BULLET, fluEligibilityBullet, 3, phase,
            EXPECTED_FLU_ELIG_BULLET_FULL, null);
    }

    private void validateFluElement(Map<String, Boolean> results, String key, By locator,
                                    int timeoutSec, String phase, String expected1, String expected2) {
        if (results.get(key).booleanValue() || !isElementDisplayed(locator, timeoutSec)) {
            return;
        }
        String actual = getNormalizedText(locator);
        if (actual == null) {
            return;
        }
        boolean textMatch = validateFluMatch(actual, key, expected1, expected2);
        results.put(key, textMatch);
        logFluValidation(phase, key, actual, expected1, expected2);
    }

    private boolean validateFluMatch(String actual, String key, String expected1, String expected2) {
        if (FLU_KEY_ELIG_LABEL.equals(key)) {
            return actual.equals(expected1);
        }
        if (FLU_KEY_ELIG_BULLET.equals(key)) {
            return actual.contains(normalize(expected1));
        }
        boolean match = actual.contains(expected1);
        return expected2 != null ? match && actual.contains(expected2) : match;
    }

    private void logFluValidation(String phase, String key, String actual, String expected1, String expected2) {
        Reporter.log(phase + " — " + key);
        if (FLU_KEY_TITLE.equals(key)) {
            Reporter.log("  Expected pattern : \"" + expected1 + " <vaccine type / patient name> " + expected2 + "\"");
            Reporter.log(ACTUAL_RENDERED_LABEL + actual + "\"");
            Reporter.log("  Dynamic portion  : \"" + stripPrefix(actual, expected1) + "\"");
        } else if (FLU_KEY_FLUBLOK.equals(key)) {
            Reporter.log("  Expected prefix  : \"" + expected1 + " <vaccine name>\"");
            Reporter.log(ACTUAL_RENDERED_LABEL + actual + "\"");
            Reporter.log("  Vaccine name     : \"" + stripPrefix(actual, expected1) + "\"");
        } else {
            String expectedText = getFluExpectedText(key, expected1);
            Reporter.log("  Expected text    : \"" + expectedText + "\"");
            Reporter.log(ACTUAL_RENDERED_LABEL + actual + "\"");
        }
        String matchType = getFluMatchType(key);
        Reporter.log("  " + matchType + " match    : true");
    }

    private String getFluExpectedText(String key, String expected) {
        return FLU_KEY_ELIG_BULLET.equals(key) ? normalize(expected) : expected;
    }

    private String getFluMatchType(String key) {
        if (FLU_KEY_TITLE.equals(key)) {
            return "Pattern";
        }
        if (FLU_KEY_ELIG_LABEL.equals(key)) {
            return "Exact";
        }
        return "Full text";
    }

    // ── COVID-19 vaccine booking — copy-text validation orchestration ────────

    /**
     * Map keys returned by {@link #validateCovidBookingCopyTexts()}. Short,
     * placeholder-free labels — the actual rendered copy is logged separately
     * by {@link #recordCovidCopyTexts(Map, String)} so reports show real text
     * (with patient names / vaccine brands) instead of {@code "..."}.
     */
    public static final String COVID_KEY_TITLE         = "Vaccine title heading";
    public static final String COVID_KEY_BRAND         = "Vaccine brand subheading";
    public static final String COVID_KEY_ELIG_BULLET_1 = "Eligibility bullet 1";
    public static final String COVID_KEY_ELIG_BULLET_2 = "Eligibility bullet 2";

    /**
     * Expected COVID-19 copy texts, validated in {@link #recordCovidCopyTexts}.
     * <p>The two bullets are fully constant — the entire string must be present.
     * The heading/subheading have a dynamic suffix (patient name and vaccine
     * brand respectively), so only the constant prefix is asserted.
     */
    private static final String EXPECTED_COVID_HEADING_PREFIX = "Let's find the right COVID-19 vaccine for";
    private static final String EXPECTED_COVID_BRAND_PREFIX   = "Review this information about";
    private static final String EXPECTED_COVID_BULLET_1_FULL  =
            "Everyone 3 years and older may be eligible to receive an updated COVID-19 vaccine "
            + "as long as it has been 2 months since the last dose of any COVID-19 vaccine. "
            + "Note: mNEXSPIKE may be administered at least 3 months after last COVID-19 dose.";
    private static final String EXPECTED_COVID_BULLET_2_FULL  =
            "Certain Immunocompromised patients may have the option to receive additional vaccine doses.";

    /**
     * Collapses every run of whitespace (including newlines) in {@code s}
     * into a single space and trims leading/trailing whitespace.
     *
     * <p>Extracted from the six call-sites that previously inlined
     * {@code s.replaceAll("\\s+", " ").trim()} — eliminates S1192 duplicate
     * string-literal violations and gives the normalization step a name.
     *
     * @param s the string to normalize; {@code null} is treated as {@code ""}
     * @return whitespace-normalized string, never {@code null}
     */
    private static String normalize(String s) {
        if (s == null) {
            return "";
        }
        return s.replaceAll("\\s+", " ").trim();
    }

    /**
     * Reads the element's visible text and collapses every run of whitespace
     * (including newlines) into single spaces via {@link #normalize(String)}.
     * Returns an empty string if the element cannot be found within the wait
     * window.
     *
     * <p>Whitespace normalization is required because the UI wraps long copy
     * across multiple lines and {@link org.openqa.selenium.WebElement#getText()}
     * preserves those line breaks — without normalization a downstream
     * {@code .contains()} check would fail even when the rendered copy is
     * correct.
     *
     * @param locator element to read from
     * @return the element's normalized visible text, or "" on lookup failure
     */
    private String getNormalizedText(By locator) {
        try {
            webWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
            String raw = webDriver.findElement(locator).getText();
            return normalize(raw);
        } catch (TimeoutException | NoSuchElementException e) {
            Reporter.log("getNormalizedText failed for " + locator + ": " + e.getMessage());
            return "";
        }
    }

    /**
     * Drives the COVID-19 booking flow far enough to validate the four static
     * copy texts called out by HCI-15516, then returns a map of
     * {@code label → found?} so the caller can report all four assertions in
     * a single {@code SoftAssert#assertAll()}.
     *
     * <p><b>Pre-condition:</b> patient information has been entered (i.e.
     * {@link #fillPatientInfo()} has run, leaving the "Schedule an
     * Appointment" button visible).
     *
     * <p><b>Flow:</b>
     * <ol>
     *   <li>Click <i>Select services</i></li>
     *   <li>Scroll into view and click the COVID drug tile</li>
     *   <li>Capture screenshot — drug-detail page</li>
     *   <li>Check vaccine heading and brand subheading on the drug-detail page</li>
     *   <li>Click <i>Continue</i> to advance to the eligibility page (only
     *       when the button is visible — older builds inline the eligibility
     *       copy on the drug-detail page itself, so a missing Continue is
     *       not fatal)</li>
     *   <li>Capture screenshot — eligibility page</li>
     *   <li>Re-check all four texts on this page (each label is tracked as
     *       "ever seen" — once true, it stays true)</li>
     * </ol>
     *
     * @return ordered map of copy-text label → visible. Every key listed in
     *         the {@code COVID_KEY_*} constants is guaranteed to be present.
     */
    public Map<String, Boolean> validateCovidBookingCopyTexts() {
        Map<String, Boolean> results = new LinkedHashMap<>();
        results.put(COVID_KEY_TITLE,         false);
        results.put(COVID_KEY_BRAND,         false);
        results.put(COVID_KEY_ELIG_BULLET_1, false);
        results.put(COVID_KEY_ELIG_BULLET_2, false);

        Reporter.log("=== COVID copy-text validation — Phase 1: drug-detail page ===");
        Assert.assertTrue(clickElement(selectServicesBtn), FAILED_CLICK_SELECT_SERVICES);
        scrollDown();
        Assert.assertTrue(clickElement(covidDrug),
            "COVID drug tile not clickable — verify aria-label matches 'COVID'");
        captureAndLog("COVID drug-detail page");

        recordCovidCopyTexts(results, "Phase 1 (drug-detail)");

        Reporter.log("=== COVID copy-text validation — Phase 2: eligibility page ===");
        if (isElementDisplayed(continueBtn, 5)) {
            clickElement(continueBtn);
            captureAndLog("COVID eligibility page");
            recordCovidCopyTexts(results, "Phase 2 (eligibility)");
        } else {
            Reporter.log("Continue button not visible — copy may be inlined on the detail page");
        }

        Reporter.log("COVID copy-text final results: " + results);
        return results;
    }

    /**
     * Helper for {@link #validateCovidBookingCopyTexts()} — checks each of the
     * four locators against the current DOM and updates the results map only
     * when a label was not previously found ("ever seen" semantics).
     *
     * <p>Validation rules per element:
     * <ul>
     *   <li><b>Heading</b> & <b>brand subheading</b> — the trailing portion
     *       (patient name / vaccine brand) is dynamic, so only the constant
     *       prefix is asserted via {@link #verifyTextNormalized}.</li>
     *   <li><b>Eligibility bullet 1</b> & <b>bullet 2</b> — fully constant
     *       copy, so the entire expected string must be present (after
     *       whitespace normalization to handle line wrapping).</li>
     * </ul>
     *
     * <p>Mirrors {@link #recordFluCopyTexts(Map, String)}.
     */
    private void recordCovidCopyTexts(Map<String, Boolean> results, String phase) {
        validateCovidElement(results, COVID_KEY_TITLE, covidVaccineHeading, 5, phase,
            EXPECTED_COVID_HEADING_PREFIX);

        validateCovidElement(results, COVID_KEY_BRAND, covidVaccineBrandSubheading, 3, phase,
            EXPECTED_COVID_BRAND_PREFIX);

        validateCovidElement(results, COVID_KEY_ELIG_BULLET_1, covidEligibilityBullet1, 3, phase,
            EXPECTED_COVID_BULLET_1_FULL);

        validateCovidElement(results, COVID_KEY_ELIG_BULLET_2, covidEligibilityBullet2, 3, phase,
            EXPECTED_COVID_BULLET_2_FULL);
    }

    private void validateCovidElement(Map<String, Boolean> results, String key, By locator,
                                      int timeoutSec, String phase, String expected) {
        if (results.get(key).booleanValue() || !isElementDisplayed(locator, timeoutSec)) {
            return;
        }
        String actual = getNormalizedText(locator);
        if (actual == null) {
            return;
        }
        boolean textMatch = validateCovidMatch(actual, key, expected);
        results.put(key, textMatch);
        logCovidValidation(phase, key, actual, expected);
    }

    private boolean validateCovidMatch(String actual, String key, String expected) {
        if (COVID_KEY_ELIG_BULLET_1.equals(key) || COVID_KEY_ELIG_BULLET_2.equals(key)) {
            return actual.contains(normalize(expected));
        }
        return actual.contains(expected);
    }

    private void logCovidValidation(String phase, String key, String actual, String expected) {
        Reporter.log(phase + " — " + key);
        if (COVID_KEY_TITLE.equals(key)) {
            Reporter.log("  Expected prefix : \"" + expected + " <patient first name>\"");
            Reporter.log(ACTUAL_RENDERED_LABEL_ALT + actual + "\"");
            Reporter.log("  Patient name    : \"" + stripPrefix(actual, expected) + "\"");
        } else if (COVID_KEY_BRAND.equals(key)) {
            Reporter.log("  Expected prefix : \"" + expected + " <vaccine name>\"");
            Reporter.log(ACTUAL_RENDERED_LABEL_ALT + actual + "\"");
            Reporter.log("  Vaccine name    : \"" + stripPrefix(actual, expected) + "\"");
        } else {
            Reporter.log("  Expected text   : \"" + normalize(expected) + "\"");
            Reporter.log(ACTUAL_RENDERED_LABEL_ALT + actual + "\"");
        }
        String matchType = getCovidMatchType(key);
        Reporter.log("  " + matchType + " match : true");
    }

    private String getCovidMatchType(String key) {
        return (COVID_KEY_TITLE.equals(key) || COVID_KEY_BRAND.equals(key)) ? "Prefix" : "Full text";
    }

    /**
     * Returns the portion of {@code actual} that follows the constant
     * {@code prefix}, trimmed. If {@code actual} does not start with
     * {@code prefix} (after whitespace normalization on both sides), returns
     * {@code "(prefix not found)"} so the log makes the mismatch obvious
     * instead of silently emitting an empty string.
     *
     * <p>Used to pull the dynamic patient name out of the COVID vaccine
     * heading and the vaccine brand out of the brand subheading for clear
     * test-report logging.
     */
    private static String stripPrefix(String actual, String prefix) {
        if (actual == null) {
            return "(no text)";
        }
        String normalizedActual  = normalize(actual);
        String normalizedPrefix = normalize(prefix);
        int idx = normalizedActual.indexOf(normalizedPrefix);
        if (idx < 0) {
            return "(prefix not found)";
        }
        return normalizedActual.substring(idx + normalizedPrefix.length()).trim();
    }

}
