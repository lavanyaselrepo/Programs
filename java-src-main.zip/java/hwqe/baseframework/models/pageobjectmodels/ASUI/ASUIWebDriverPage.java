package hwqe.baseframework.models.pageobjectmodels.ASUI;

import hwqe.baseframework.interfaces.IWebSite;
import hwqe.baseframework.utilities.FileUtils;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.webcontext.BrowserType;
import hwqe.baseframework.webcontext.WebSiteManager;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeSuite;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ASUIWebDriverPage {

    private static final PropertyReader prop = PropertyReader.getInstance();
    protected RemoteWebDriver driver;
    public LoginPage loginPage;
    public Homepage homePage;
    public ClinicalServiceAppointmentsPage clinicalServiceAppointmentsPage;

    protected static final Properties props = new Properties();
    private IWebSite asuiApp;

    @BeforeSuite(alwaysRun = true)
    public void loadProperties() {
        try {
            String envFile = "config/cs/ASUIWebApp/" + prop.getEnvironment().toString().toLowerCase() + ".properties";
            props.load(FileUtils.getStreamFromResources(envFile));
            PropertyReader.getInstance().loadCustomProperties("config/cs/ASUIWebApp/");
        } catch (Exception e) {
            throw new RuntimeException("Failed to load ASUI properties: " + e.getMessage(), e);
        }
    }

    protected void createFreshBrowser() {
        try {
            String asuiUrl  = props.getProperty("web.asui_url");
            String platform = props.getProperty("platform", "Windows 11");
            String version  = props.getProperty("version", "latest");

            if (isRunOnSauce()) {
                driver = createWebDriver(platform, version, this.getClass().getSimpleName());
                sout("[ASUI] Navigating to: " + asuiUrl);
                driver.get(asuiUrl);
                sout("[ASUI] After get() — URL: " + driver.getCurrentUrl());
                driver.navigate().refresh();
                sout("[ASUI] After refresh() — URL: " + driver.getCurrentUrl());
            } else {
                asuiApp = new WebSiteManager();
                asuiApp.launchWebsite(asuiUrl, BrowserType.Chrome);
                driver = asuiApp.getDriver();
            }

            loginPage = new LoginPage(driver, props);
            homePage  = new Homepage(driver, props);
            clinicalServiceAppointmentsPage = new ClinicalServiceAppointmentsPage(driver, props);

        } catch (Exception e) {
            throw new RuntimeException("Failed to create browser: " + e.getMessage(), e);
        }
    }

    protected void closeBrowser() {
        try {
            if (isRunOnSauce() && driver != null) {
                driver.executeScript("sauce:job-result=" + (Reporter.didAllTestsPass() ? "passed" : "failed"));
                driver.quit();
            } else {
                if (driver != null) {
                    driver.quit();
                }
                if (asuiApp != null && asuiApp.getDriver() != null) {
                    asuiApp.getDriver().quit();
                }
            }
        } catch (Exception e) {
            sout("WARNING: Error closing browser: " + e.getMessage());
        } finally {
            driver  = null;
            asuiApp = null;
        }
    }

    /**
     * Whether to use Sauce Labs for this run.
     * Checks the JVM system property {@code asui.run.on.sauce} first (set by the
     * {@code asui-tests} Maven profile), then falls back to {@code stg.properties}.
     * Default is {@code false} so local dev uses a plain Chrome driver.
     */
    private static boolean isRunOnSauce() {
        String sysProp = System.getProperty("asui.run.on.sauce");
        if (sysProp != null) {
            return Boolean.parseBoolean(sysProp);
        }
        return Boolean.parseBoolean(props.getProperty("asui.run.on.sauce", "false"));
    }

    private static RemoteWebDriver createWebDriver(String platform, String version, String testName) {
        // Walmart corporate proxy — required to reach Sauce Labs and Akeyless from the Walmart network
        System.setProperty("http.proxyHost",  "sysproxy.wal-mart.com");
        System.setProperty("http.proxyPort",  "8080");
        System.setProperty("https.proxyHost", "sysproxy.wal-mart.com");
        System.setProperty("https.proxyPort", "8080");

        ChromeOptions browserOptions = new ChromeOptions();
        browserOptions.setPlatformName(platform);
        browserOptions.setBrowserVersion(version);
        // Do NOT add --proxy-bypass-list for pfed.wal-mart.com.
        // pfed is an internal Walmart host; it must be reached via the Sauce Connect
        // PAC proxy (which tunnels *.wal-mart.com through the corporate network).
        // Bypassing the PAC forces Chrome to go DIRECT from the Sauce Labs VM,
        // which fails with ERR_TUNNEL_CONNECTION_FAILED — exactly what RTF tests
        // avoid by not having a bypass list at all.

        String slUsername  = prop.getProperty("z.run.sl.un");
        String slAccessKey = prop.getProperty("z.run.sl.ak");
        String tunnelName  = resolve("sauce.tunnel.name");
        String tunnelOwner = resolve("sauce.tunnel.owner");
        // For centralized (shared) tunnels owned by another team, we cannot query
        // that team's tunnel list using our own credentials. Skip the API readiness
        // check and trust that the infra team keeps their tunnel alive.
        // For tunnels owned by this account (tunnelOwner == null or == slUsername)
        // we do a quick readiness check and auto-select a fallback if needed.
        boolean isCentralizedTunnel = tunnelOwner != null && !tunnelOwner.equalsIgnoreCase(slUsername);
        if (!isCentralizedTunnel) {
            tunnelName = resolveActiveTunnel(tunnelName, slUsername, slAccessKey);
        }

        sout("[ASUI] SauceLabs — user=" + slUsername
                + " tunnel=" + tunnelName + " owner=" + tunnelOwner);

        Map<String, Object> sauceOptions = new HashMap<>();
        if (tunnelName != null) {
            sauceOptions.put("tunnelName", tunnelName);
        }
        if (tunnelOwner != null) {
            sauceOptions.put("tunnelOwner", tunnelOwner);
        }
        sauceOptions.put("name", testName);
        browserOptions.setCapability("sauce:options", sauceOptions);

        URL url;
        try {
            url = new URL("https://" + slUsername + ":" + slAccessKey
                    + "@ondemand.us-west-1.saucelabs.com:443/wd/hub");
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
        return new RemoteWebDriver(url, browserOptions);
    }

    /**
     * Queries the Sauce Labs REST API to find an active tunnel.
     * Uses {@code preferred} if it is currently running; otherwise auto-selects
     * the first available tunnel visible to the account.
     */
    private static String resolveActiveTunnel(String preferred, String username, String accessKey) {
        if (username == null || accessKey == null) {
            return preferred;
        }
        try {
            String auth = Base64.getEncoder()
                    .encodeToString((username + ":" + accessKey).getBytes(StandardCharsets.UTF_8));
            HttpURLConnection conn = (HttpURLConnection)
                    new URL("https://api.us-west-1.saucelabs.com/rest/v1/" + username + "/tunnels?full=true")
                            .openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Basic " + auth);
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);

            if (conn.getResponseCode() == 200) {
                StringBuilder sb = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                    String line;
                    while ((line = r.readLine()) != null) {
                        sb.append(line);
                    }
                }
                String body = sb.toString();
                sout("[ASUI] Active tunnels: " + body.substring(0, Math.min(600, body.length())));

                if (preferred != null && body.contains("\"" + preferred + "\"")) {
                    sout("[ASUI] Tunnel '" + preferred + "' is active");
                    return preferred;
                }

                Matcher m = Pattern.compile("\"tunnel_identifier\"\\s*:\\s*\"([^\"]+)\"").matcher(body);
                if (m.find()) {
                    String found = m.group(1);
                    sout("[ASUI] '" + preferred + "' not active — using: " + found);
                    return found;
                }
                sout("[ASUI] WARNING: No active Sauce Connect tunnels found for '" + username + "'");
            }
        } catch (Exception e) {
            sout("[ASUI] Tunnels API query failed: " + e.getMessage());
        }
        return preferred;
    }

    private static void sout(String msg) {
        Reporter.log(msg);
    }

    /** Read a property from stg.properties first; fall back to the shared PropertyReader (Akeyless/CCM). */
    private static String resolve(String key) {
        String val = props.getProperty(key);
        return val != null && !val.trim().isEmpty() ? val.trim() : prop.getProperty(key);
    }
}
