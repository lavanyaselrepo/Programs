package hwqe.baseframework.models.pageobjectmodels.ASUI;

import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.vaults.ServiceAccountPassword;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.IOException;
import java.util.Properties;

import static org.junit.Assert.assertTrue;

public class LoginPage extends ASUIBasePage {

    public By userIdTxt   = By.id("username1");
    public By passwordTxt = By.id("password");
    public By signInBtn   = By.xpath("//*[@title='Sign In']");

    public LoginPage(RemoteWebDriver driver, Properties props) throws IOException {
        super(driver, props);
    }

    public void setUserName(String userName) {
        assertTrue("Failed to enter username", sendText(userIdTxt, userName));
    }

    public void setPassword(String password) {
        assertTrue("Failed to enter password", sendText(passwordTxt, password));
        Reporter.log("Entered ************* in password field.");
    }

    public void clickOnSignInBtn() {
        assertTrue("Failed to click Sign In button", clickElement(signInBtn));
        Reporter.log("Clicked on SignIn button in Login page.");
    }

    public void login() {
        sout("[ASUI-LOGIN] ========== login() START ==========");
        sout("[ASUI-LOGIN] URL before login: " + getURL());
        Reporter.logScreenShot("[ASUI-LOGIN] 5. Before entering credentials", takeScreenShot());
        try {
            ServiceAccountPassword serviceAccount = new ServiceAccountPassword();
            String username = "SVCJiraUserHWQE";
            String password = serviceAccount.returnPassword();

            if (password == null || password.isEmpty()) {
                throw new RuntimeException("ServiceAccountPassword returned empty password — Akeyless may be unreachable");
            }
            sout("[ASUI-LOGIN] Akeyless password retrieved (length=" + password.length() + ")");

            sout("[ASUI-LOGIN] Entering username: " + username);
            setUserName(username);
            Reporter.logScreenShot("[ASUI-LOGIN] 6. Username entered", takeScreenShot());

            sout("[ASUI-LOGIN] Entering password...");
            setPassword(password);
            Reporter.logScreenShot("[ASUI-LOGIN] 7. Password entered", takeScreenShot());

            sout("[ASUI-LOGIN] Clicking Sign In...");
            clickOnSignInBtn();
            pause(3_000);
            sout("[ASUI-LOGIN] URL after Sign In: " + getURL());
            sout("[ASUI-LOGIN] Title after Sign In: " + getPageTitle());
            Reporter.logScreenShot("[ASUI-LOGIN] 8. After Sign In click", takeScreenShot());

        } catch (Exception e) {
            Reporter.logScreenShot("[ASUI-LOGIN] ERROR in login()", takeScreenShot());
            throw new RuntimeException("Login failed: " + e.getMessage(), e);
        }
    }

    /**
     *
     *   0. ASUI landing page may show a "Sign In" button — click it to start SSO.
     *   1. pfedcert.wal-mart.com  — no Walmart PKI cert on Sauce VMs; rewrite to pfed.
     *   2. Ping authorization/consent page  — click the postOk() allow button.
     *   3. Credential form (username1 / password)  — ready to type credentials.
     *
     * All steps emit System.out.println so the current URL + page title is visible
     * in the console output even when Reporter HTML is not accessible.
     */
    public boolean isASUIPageLaunched() {
        sout("[ASUI-LOGIN] ========== isASUIPageLaunched START ==========");
        sout("[ASUI-LOGIN] URL  : " + getURL());
        sout("[ASUI-LOGIN] Title: " + getPageTitle());
        Reporter.logScreenShot("[ASUI-LOGIN] 1. Browser after navigate+refresh", takeScreenShot());

        // Wait 3s for SPA to hydrate / redirect to start
        pause(3_000);
        String url = getURL();
        sout("[ASUI-LOGIN] URL at t=3s : " + url);
        sout("[ASUI-LOGIN] Title at t=3s: " + getPageTitle());
        Reporter.logScreenShot("[ASUI-LOGIN] 2. After 3s wait", takeScreenShot());

        // If still on ASUI landing page, click the sign-in button (id=animatedComponent)
        if (url != null && url.contains("imz-assoc-app")) {
            sout("[ASUI-LOGIN] Still on ASUI domain — checking for sign-in button (animatedComponent)...");
            if (isElementDisplayed(By.id("animatedComponent"), 5)) {
                sout("[ASUI-LOGIN] Found animatedComponent — clicking to trigger SSO redirect");
                clickElement(By.id("animatedComponent"));
                pause(3_000);
                sout("[ASUI-LOGIN] URL after sign-in click: " + getURL());
                Reporter.logScreenShot("[ASUI-LOGIN] 3. After sign-in button click", takeScreenShot());
            } else {
                sout("[ASUI-LOGIN] animatedComponent not found — app is auto-redirecting");
                Reporter.logScreenShot("[ASUI-LOGIN] 3. No sign-in button (auto-redirect)", takeScreenShot());
            }
        } else {
            sout("[ASUI-LOGIN] Already left ASUI domain — redirect in progress");
            Reporter.logScreenShot("[ASUI-LOGIN] 3. Already redirected", takeScreenShot());
        }

        // Poll every 5s (up to 60s) for the pfed credential form, logging URL each time
        // so we can see the full redirect chain in Sauce Labs console/report
        sout("[ASUI-LOGIN] Polling for pfed credential form (username1 / password)...");
        boolean formFound = false;
        long deadline = System.currentTimeMillis() + 60_000L;
        int tick = 0;
        while (System.currentTimeMillis() < deadline) {
            if (isElementDisplayed(By.id("username1"), 1) || isElementDisplayed(By.id("password"), 1)) {
                formFound = true;
                break;
            }
            tick += 5;
            pause(5_000);
            sout("[ASUI-LOGIN] t=" + tick + "s  URL: " + getURL() + "  title: " + getPageTitle());
            if (tick % 15 == 0) {
                Reporter.logScreenShot("[ASUI-LOGIN] Waiting t=" + tick + "s", takeScreenShot());
            }
        }

        sout("[ASUI-LOGIN] Form found: " + formFound);
        sout("[ASUI-LOGIN] Final URL  : " + getURL());
        sout("[ASUI-LOGIN] Final Title: " + getPageTitle());
        Reporter.logScreenShot("[ASUI-LOGIN] 4. Final state (form found=" + formFound + ")", takeScreenShot());
        return formFound;
    }

    private static void sout(String msg) {
        System.out.println(msg);
        Reporter.log(msg);
    }

    private static void pause(long millis) {
        try { Thread.sleep(millis); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
    }

    public void logout() {
        try {
            Reporter.log("Logging out - clearing session");
            clearSession();
            webWait.until(d -> "complete".equals(((org.openqa.selenium.JavascriptExecutor) d)
                    .executeScript("return document.readyState")));
            Reporter.logScreenShot("Logged Out - Session Cleared", takeScreenShot());
            Reporter.log("Logout complete");
        } catch (Exception e) {
            Reporter.log("Logout completed");
        }
    }
}
