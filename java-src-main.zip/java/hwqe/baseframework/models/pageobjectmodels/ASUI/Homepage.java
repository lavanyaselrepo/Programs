package hwqe.baseframework.models.pageobjectmodels.ASUI;

import hwqe.baseframework.utilities.Reporter;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Properties;

import static java.time.Duration.ofSeconds;
import static org.junit.Assert.assertTrue;

public class Homepage extends ASUIBasePage {

    public By storeCheckText  = By.cssSelector(".css-901oao.r-15zivkp");
    public By storeNbrInput   = By.cssSelector(".css-11aywtz.r-11wrixw.r-1yzf0co.r-13qz1uu");
    public By submitBtn       = By.xpath("//*[text()=\"Submit\"]");
    public By appointmentsText = By.xpath("//*[text()=\"Schedule an Appointment\"]");
    public By addPatient      = By.xpath("//*[text()=\"Add a new patient\"]");
    public By patientFirstName = By.cssSelector("[aria-label=\"First Name\"]");
    public By continueBtn     = By.xpath("//*[text()=\"Continue\"]");
    public final By printScheduleButton = By.xpath("//div[@role='button'][.//div[text()='Print Schedule']]");

    private final String storeNbr;

    public Homepage(RemoteWebDriver driver, Properties props) {
        super(driver, props);
        storeNbr = props.getProperty("app.asui.storeNbr");
        if (storeNbr == null || storeNbr.isEmpty()) {
            throw new RuntimeException("Store number not configured");
        }
    }

    public void isHomePageDisplayed() {
        Reporter.logScreenShot("Homepage Check", takeScreenShot());

        boolean displayed = isElementDisplayed(storeCheckText, 20)
                || isElementDisplayed(storeNbrInput, 10)
                || isElementDisplayed(appointmentsText, 5);

        if (!displayed) {
            Reporter.logScreenShot("ERROR - Homepage Not Displayed", takeScreenShot());
            throw new RuntimeException("Homepage not displayed");
        }
    }
    /**
     * Verifies that the Print Schedule button is visible on the home page.
     *
     * @param waitSeconds maximum seconds to wait for the button to appear
     * @return {@code true} if the button is visible within the timeout; {@code false} otherwise
     */
    public boolean isPrintScheduleButtonVisible(int waitSeconds) {
        return isElementDisplayed(printScheduleButton, waitSeconds);
    }

    /**
     * Checks whether the Print Schedule button is clickable (visible + enabled)
     * within the given timeout.
     *
     * <p>Uses {@code ExpectedConditions.elementToBeClickable} internally, which
     * confirms the element is both present in the DOM and not disabled.
     *
     * @param waitSeconds maximum seconds to wait for the button to become clickable
     * @return {@code true} if the button is clickable within the timeout; {@code false} otherwise
     */
    public boolean isPrintScheduleButtonClickable(int waitSeconds) {
        return isElementEnabled(printScheduleButton, waitSeconds);
    }

    public void navigateToAppointments() {
        Reporter.log("Navigating to appointments for store: " + storeNbr);

        // Already on appointments page — nothing to do
        if (isElementDisplayed(appointmentsText, 3)) {
            Reporter.log("Already on appointments page");
            return;
        }

        // Wait for store input and enter store number
        if (!isElementDisplayed(storeNbrInput, 20)) {
            Reporter.logScreenShot("ERROR - Store Input Not Found", takeScreenShot());
            throw new RuntimeException("Store input field not found");
        }
        assertTrue("Failed to enter store number", sendText(storeNbrInput, storeNbr));

        // Wait for submit button to be enabled then click it
        assertTrue("Submit button not found or not enabled", isElementEnabled(submitBtn, 10));
        assertTrue("Failed to click Submit", clickElement(submitBtn));

        // Wait for appointments page to load
        new WebDriverWait(webDriver, ofSeconds(20))
                .until(ExpectedConditions.visibilityOfElementLocated(appointmentsText));

        Reporter.logScreenShot("Appointments Page - Store " + storeNbr, takeScreenShot());
        Reporter.log("Navigated to appointments successfully");
    }
}
