package hwqe.baseframework.models.pageobjectmodels;

public enum Attribute {
    Name,
    IsEnabled,
    Enabled,
    Disabled,
    AutomationId,
    ClassName,
    Value,
    HasKeyboardFocus,
    IsPassword,
    IsToggle,
    HorizontalViewSize,
    VerticalViewSize,
    IsScroll,
    ContentDesc,
    innerText
}
