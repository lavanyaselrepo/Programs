package hwqe.baseframework.dispenseappcontext;

import hwqe.baseframework.interfaces.IMobileApp;
import hwqe.baseframework.utilities.PropertyReader;
import io.appium.java_client.android.AndroidDriver;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.net.URL;
import java.util.Random;

public class DispenseAppManager implements IMobileApp {
    AndroidDriver driver;
    PropertyReader rdr = PropertyReader.getInstance();

    @Override
    public AndroidDriver getDriver() {
        return driver;
    }

    @Override
    public boolean launchMobileApp() {
        try {
            DesiredCapabilities capabilities = new DesiredCapabilities();
            rdr.loadCustomProperties("config/dispenseapp/");
            capabilities.setCapability("noReset", true);
            capabilities.setCapability("BROWSER_NAME", rdr.getProperty("dispenseapp.app_browser"));
            capabilities.setCapability("VERSION", rdr.getProperty("dispenseapp.android_version"));
            capabilities.setCapability("deviceName", rdr.getProperty("dispenseapp.device_name"));
            capabilities.setCapability("platformName", rdr.getProperty("dispenseapp.platform_name"));
            capabilities.setCapability("appPackage", rdr.getProperty("dispenseapp.package_name"));
            capabilities.setCapability("appActivity", rdr.getProperty("dispenseapp.main_activity"));
            driver = new AndroidDriver(new URL(rdr.getProperty("app.appiumServer")), capabilities);
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    @Override
    public String takeScreenShot(String fileName) {
        try {
            Random r = new Random();
            File savedFile = new File(rdr.getProperty("app.workingfolder_path") + fileName + "_" + r.nextInt(9999) + ".png");
            FileUtils.copyFile(this.driver.getScreenshotAs(OutputType.FILE), savedFile);
            return savedFile.getPath();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean closeMobileApp() {
        return false;
    }

    @Override
    public void switchWindow() {

    }
}
