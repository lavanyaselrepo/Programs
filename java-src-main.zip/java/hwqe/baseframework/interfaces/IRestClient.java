package hwqe.baseframework.interfaces;

import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;

public interface IRestClient {
    ServiceResponse performGet(ServiceRequest request);

    ServiceResponse performPost(ServiceRequest request);

    ServiceResponse performPost(ServiceRequest request, int connectionTimeOut, int requestTimeOut);

    ServiceResponse uploadFile(ServiceRequest request);

    ServiceResponse performPut(ServiceRequest request);

    ServiceResponse postFormData(ServiceRequest request);

    ServiceResponse performPatch(ServiceRequest request);

    ServiceResponse performDelete(ServiceRequest request);

    ServiceResponse performPost(ServiceRequest request, int retryCount);

    ServiceResponse performHead(ServiceRequest request);
}
