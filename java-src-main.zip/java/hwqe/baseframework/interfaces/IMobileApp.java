package hwqe.baseframework.interfaces;

import io.appium.java_client.android.AndroidDriver;

public interface IMobileApp {
    boolean launchMobileApp();

    boolean closeMobileApp();

    void switchWindow();

    AndroidDriver getDriver();

    String takeScreenShot(String fileName);
}
