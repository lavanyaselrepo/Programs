package hwqe.baseframework.interfaces;

import io.appium.java_client.windows.WindowsDriver;

public interface IConnexus {
    boolean launchConnexus();

    boolean closeConnexus();

    void switchWindow();

    WindowsDriver getDriver();

    String takeScreenShot();

    /**
     * COM Health Check (Fix10) — verifies gRPC COM automation responsiveness.
     * Returns latency in ms, or -1 on failure. Default returns 0 (WinAppDriver: no-op).
     */
    default long checkComHealth() {
        return 0;
    }

    /**
     * Warm up the COM automation cache (Fix11).
     * Makes lightweight gRPC calls to pre-heat FlaUI's UI Automation element cache.
     * Default is no-op (WinAppDriver doesn't need warm-up).
     */
    default void warmUpComCache() {
        // no-op for WinAppDriver
    }
}
