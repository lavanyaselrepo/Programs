package hwqe.baseframework.interfaces;

import io.appium.java_client.windows.WindowsDriver;

public interface IBoss {
    boolean launchBoss();

    boolean closeBoss();

    void switchWindow();

    WindowsDriver getDriver();

    String takeScreenShot();
}
