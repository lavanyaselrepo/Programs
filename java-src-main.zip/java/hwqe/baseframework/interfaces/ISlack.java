package hwqe.baseframework.interfaces;

public interface ISlack {
    boolean postToSlack(String message);
}
