/**
 * ICommonDriver is the blueprint for establishing driver and driver related functionalities according to a platform type.
 * Usage : Implementation of this interface happens from DigitalPharmacyTestBase.
 *
 * @Author: Saloni Sharma
 *
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */
package hwqe.baseframework.interfaces;

import org.openqa.selenium.remote.RemoteWebDriver;

public interface ICommonDriver {

    RemoteWebDriver getDriver();

    public RemoteWebDriver launchPlatformApp(String testName);

    public void quitDriver();

    public void getSessionInformation();
}
