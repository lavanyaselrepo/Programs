package hwqe.baseframework.interfaces;

import java.util.List;
import java.util.Map;

import hwqe.baseframework.datacontext.DataTable;

public interface IDatabaseContext {
    <T> List<T> executeQueryForList(String sql, Class<T> mappedClass);

    <T> T executeQuery(String sql, Class<T> mappedClass);

    DataTable getDataTable(String sql);

    <E, T> Map<E, T> executeQuery(String sql, String keyColumn, Class<T> mappedClass);

    <T> T getScalar(String sql, Class<T> mappedClass);

    Map<String, Object> executeQuery(String sql);

    List<Map<String, Object>> executeQueryForList(String sql);

    int executeUpdateQuery(String sql);

    int executeInsertQuery(String sql);
}
