package hwqe.baseframework.interfaces;

import java.awt.*;
import java.util.List;
import java.util.Map;

import hwqe.baseframework.connexuscontext.Priority;
import hwqe.baseframework.connexuscontext.SearchType;
import hwqe.baseframework.connexuscontext.WorkQueue;
import hwqe.baseframework.models.datamodels.connexus.DropRxModel;
import hwqe.baseframework.models.datamodels.connexus.ImzEventModel;
import hwqe.baseframework.models.datamodels.connexus.PatientProfileModel;
import hwqe.baseframework.models.datamodels.connexus.RxModel;

public interface IWorkFlow {
    void performLogin(String userName, String password);

    void performSearch(String value, SearchType type);

    void checkAndClickWarning();

    void checkAndPerformCheckDUR(String rxNumber);

    void checkAndPerformCheckDUR(
            String rxNumber,
            Map<String, String> inputData,
            boolean counselRequiredCheck,
            boolean counselReasonRequired);

    void openCheckDURScreen(String rxNumber);

    String performFourPoint(String patNameOrRxNbr);

    String performFourPoint(String patNameOrRxNbr, Map<String, String> inputData, boolean counselRequiredCheck);

    String performFourPoint(
            String patNameOrRxNbr, Map<String, String> inputData, boolean counselRequiredCheck, boolean paymentCheck);

    String performFourPointWithOnHold(String patNameOrRxNbr);

    String performFourPointForControlledDrug(String patNameOrRxNbr, String productName);

    String performFourPointForControlledDrug(String patNameOrRxNbr, String productName, boolean flagDUR);

    boolean checkRxWorkQue(String rxNbr, WorkQueue queue);

    boolean completeFilling(String rxNbr);

    void completePartialFilling(String rxNbr);

    PatientProfileModel searchAndCreatePatient(boolean isAllFieldRequire, PatientProfileModel patientProfile);

    PatientProfileModel searchAndCreatePatientForNullPhonenumberCheck(
            boolean isAllFieldRequire, PatientProfileModel patientProfile);

    PatientProfileModel createNewPatient(boolean thirdParty, PatientProfileModel patientProfile);

    void createNewPrescriber(Map<String, String> inputData);

    void performDropRx(DropRxModel dropRxModel);

    void performDropRx(DropRxModel dropRxModel, int noOfFutureDays);

    void performDropRx(DropRxModel dropRxModel, int noOfFutureDays, boolean isTamperResistant);

    void performDropOffBasedOnRxOriginType(DropRxModel dropRxModel);

    void performDropRx(String patientName, Priority priority, int noOfRx, String pickupTime);

    void performDropRx(
            String patientName,
            Priority priority,
            int noOfRx,
            String pickupTime,
            String orderComment,
            int noOfFutureDays);

    void performInput(RxModel rxModel);

    void performInput(RxModel rxModel, String inputType);

    void performInputWithBlankTMCode(RxModel rxModel);

    void performInputWithDAW1(RxModel rxModel);

    void performInputWithWrittenDateLessThanSixMonths(RxModel rxModel);

    void performIMZDropOff(DropRxModel dropRxModel) throws AWTException;

    void existingPatientDropOff(DropRxModel dropRxModel);

    void performDoubleFourPoint(String patNameOrRxNbr);

    void enterRxComments(String rxNotes, String phamacyNotes, String counsellingNotes);

    void performNaloxoneDropRx(DropRxModel dropRxModel);

    void performNaloxoneDropRxForPatient(DropRxModel dropRxModel) throws AWTException;

    void performInput(
            String patientName,
            String ndc,
            String prescribedQty,
            String sigCode,
            String refills,
            String prescriberName);

    void completeVisualVerify(String rxNbr);

    void completeVisualVerify(String rxNbr, Map<String, String> inputData);

    boolean completeBagging(String rxNbr);

    void completePickup(String firstName, String lastName, String dob, String rxNbr);

    void completePickup(String firstName, String lastName, String dob, String rxNbr, boolean counselRequiredCheck);

    void completePickup(
            String firstName,
            String lastName,
            String dob,
            String rxNbr,
            boolean counselRequiredCheck,
            boolean tascoCheck);

    void completeCounsel(String rxNbr);

    void completeCounsel(String rxNbr, Map<String, String> inputData, boolean counselRequiredCheck);

    void completeOfflineSale(String rxNbr);

    void completeResolution(String rxNbr);

    void completeResolutionForRefills(String rxNbr, String refills, String approvingPrescriber);

    void completeResolutionForEarlyRefill(String rxNbr);

    void completeMultiRxPickup(String firstName, String lastName, String dob, List<String> rxNbr, String siteId);

    void checkAndPerformCheckDURResolved(String rxNumber);

    void completePickupWithSSNValidation(String firstName, String lastName, String dob, String rxNbr, String siteId);

    void completePickupWithOutSSN(String firstName, String lastName, String dob, String rxNber, String siteId);

    PatientProfileModel searchAndCreatePatientForPetAndLiveStock(
            boolean isAllFieldRequire, PatientProfileModel patientProfile);

    PatientProfileModel createNewPatientFromResolutionPage(boolean thirdParty, PatientProfileModel patientProfile);

    void performRphManualResolution(String rxNbrOrName);

    void performCovidTestingKitDropRx(DropRxModel dropRxModel, String prescriberName);

    void navigateToRxNotes(String rxNbr, String textUser, String drugName, String rxNotes);

    void navigateToRxImage(String rxNbr);

    void performMultiRxInput(RxModel rxModel, int index);

    void performMultiRxInput(Map<String, String> inputData, RxModel rxModel, int index);

    void performpickupforWrongScanRX(String firstName, String lastName, String dob, String rxNbr, int fillId);

    void completePickupWithPaymentValidation(
            String firstName, String lastName, String dob, String rxNbr, String siteId, String fillId);

    void completeMultiRxPickupWithPaymentValidation(
            String firstName, String lastName, String dob, List<String> rxNbr, String siteId);

    void completeResolutionForMultiRx(String rxNbr) throws AWTException;

    void performCheckDurForMultiRx(String rxNumber);

    void performRphManualResolutionForAdditionalAction(String rxNbrOrName, String prescriber);

    void navigateToRxNotesAndPerformValidation(String rxNbr, String vaccineName, String user, String notes);

    void performNaloxoneDropOffRx(DropRxModel dropRxModel, String drug, String prescriberName);

    void performIMZDropOffForSingleDrug(DropRxModel dropRxModel, String drug, String prescriberName);

    void performIMZDropOffForMultiDrug(DropRxModel dropRxModel, List<String> drugList, String prescriberName);

    void completeMultiRxPickupWithIndividualRx(
            String firstName, String lastName, String dob, List<String> rxNbr, String siteId);

    void performAutoFillDropOffForC2Drug(DropRxModel dropRxModel);

    void performCovidTestingKitForMultiDrug(DropRxModel dropRxModel, List<String> drugList, String prescriberName);

    void performDropOffForMultiDrugs(DropRxModel dropRxModel, List<String> drugList);

    void performNaloxoneStatePartnershipDropOff(
            DropRxModel dropRxModel,
            String drug,
            int qtyEvenNum,
            int qtyOddNum,
            int minRangeEvenNum,
            int maxRangeEvenNum,
            int minRangeOddNum,
            int maxRangeOddNum);

    ImzEventModel createNewIMZEvent(
            ImzEventModel imzEvent,
            List<String> drugList,
            String lotNbr,
            String expireDate,
            List<String> ndcList,
            String prescriberRph,
            String prescriberSo,
            String groupName,
            String invalidNdc);

    void performImzEventDropOff(
            DropRxModel dropRxModel,
            String dob,
            String imzEventName,
            String raceValue,
            String ethnicityValue,
            String imzEventDrug);
}
