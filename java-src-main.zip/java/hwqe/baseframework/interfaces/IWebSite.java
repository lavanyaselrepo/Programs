package hwqe.baseframework.interfaces;

import hwqe.baseframework.webcontext.BrowserType;
import org.openqa.selenium.remote.RemoteWebDriver;

public interface IWebSite {
    boolean launchWebsite(String url, BrowserType browserType);

    boolean quitWebsite();

    RemoteWebDriver getDriver();

    void bringToFront();
}
