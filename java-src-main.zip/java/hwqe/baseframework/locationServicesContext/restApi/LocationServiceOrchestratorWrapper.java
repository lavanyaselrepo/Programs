package hwqe.baseframework.locationServicesContext.restApi;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;

import java.util.HashMap;

public class LocationServiceOrchestratorWrapper {

    private AutomationManager am = AutomationManager.getInstance();
    private PropertyReader prop = PropertyReader.getInstance();

    public LocationServiceOrchestratorWrapper() {
        prop.loadCustomProperties("config/locationService/");
    }

    private HashMap<String, String> getHeaders() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("WM_CONSUMER.ID", prop.getProperty("location.service.consumer.id"));
        headers.put("WM_SVC.NAME", prop.getProperty("location.service.name"));
        headers.put("WM_SVC.ENV", prop.getProperty("location.service.env"));
        headers.put("subscription-id", prop.getProperty("location.service.subscription.id"));
        headers.put("use-transform", prop.getProperty("location.service.use.transform"));

        return headers;
    }

    public ServiceResponse getPharmacyStoreInfo(String storeId){
        HashMap<String, String> headers = this.getHeaders();
        HashMap<String, String> queryParams = new HashMap<>();
        queryParams.put("country", prop.getProperty("location.service.country"));
        queryParams.put("number", storeId);
        queryParams.put("serviceTypes", prop.getProperty("location.service.services.type"));
        queryParams.put("accessTypes", prop.getProperty("location.service.access.types"));
        ServiceRequest request = new ServiceRequest();

        request.setUrl(prop.getProperty("location.service.base.url"), queryParams);
        request.setHeaders(headers);

        ServiceResponse response = am.getRestContext().performGet(request);
        Reporter.logJSON("Location Service Raw Response", response.getDataResponse());
        Assert.assertEquals(response.getStatusCode(), 200, "Location Service API Failed, please report");
        return response;
    }
}
