package hwqe.baseframework.locationServicesContext.utils;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.locationServicesContext.restApi.LocationServiceOrchestratorWrapper;
import hwqe.baseframework.utilities.PropertyReader;

public class LocationServiceUtils {
    private AutomationManager am = AutomationManager.getInstance();
    private PropertyReader prop = PropertyReader.getInstance();
    private LocationServiceOrchestratorWrapper locationServiceOrchestratorWrapper = new LocationServiceOrchestratorWrapper();

    public LocationServiceUtils() {
        prop.loadCustomProperties("config/locationService/");
    }

    public String getStoreZipCode(String storeId){
        ServiceResponse response = locationServiceOrchestratorWrapper.getPharmacyStoreInfo(storeId);
        return response.getJsonElement("payload.address.postalCode");
    }
}
