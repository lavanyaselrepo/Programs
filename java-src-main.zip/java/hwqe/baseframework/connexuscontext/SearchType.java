package hwqe.baseframework.connexuscontext;

public enum SearchType {
    VisualVerify(6, "Visual Verify"),
    PatientRx(0, "Patient/Rx"),
    BagNumber(1, "Bag Number"),
    ChkDur(26, "Chk DUR"),
    FourPoint(3, "4 Point"),
    Filling(5, "Filling"),
    Input(2, "Input"),
    Bagging(5, "Bagging"),
    PickUp(7, "Pick Up"),
    Pos(9, "POS"),
    ClinicalIntelligence(12, "Clinical Intelligence"),
    Eod(10, "EOD");

    private int searchType;
    private String searchTypeName;

    SearchType(int type, String name) {
        this.searchType = type;
        this.searchTypeName = name;
    }

    public int getSearchType() {
        return searchType;
    }

    public String getSearchTypeName() {
        return searchTypeName;
    }
}
