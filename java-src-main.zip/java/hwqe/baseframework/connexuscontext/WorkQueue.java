package hwqe.baseframework.connexuscontext;

public enum WorkQueue {
    FILLING("filling"),
    FOUR_POINT("4 Point"),
    CASH("cash"),
    PICKUP("pickup"),
    STORING("storing"),
    BAGGING("bagging"),
    VISUAL_VERIFY("vis ver"),
    INPUT("input"),
    RESOLVE("resolve"),
    DUR("dur"),
    CHK_DUR("ChkDUR"),
    POS("pos"),
    COUNSEL("counsel"),
    TP("tp"),
    CANCELRX("CancelRx"),
    EOD("eod"),
    SVC_ADMIN("svc admn"),
    IMZRep("imz rep"),
    MODIFYDETAILS("modify details");

    private final String queue;

    WorkQueue(String queue) {
        this.queue = queue;
    }

    public String getWorkQueue() {
        return queue;
    }
}
