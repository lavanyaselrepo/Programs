package hwqe.baseframework.connexuscontext;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.interfaces.IConnexus;
import hwqe.baseframework.utilities.PropertyReader;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.windows.WindowsDriver;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.net.URI;



public class ConnexusManager implements IConnexus {
    private static final Logger log = LoggerFactory.getLogger(ConnexusManager.class);
    private static final String APPIUM_NEW_COMMAND_TIMEOUT = "appium:newCommandTimeout";
    PropertyReader prop = PropertyReader.getInstance();
    private WindowsDriver windowsDriver = null;
    private ConnexusManager cnxManager;

    /** Best-effort quit — swallows exceptions to avoid masking the real failure. */
    private void safeQuit(WindowsDriver driver) {
        if (driver != null) {
            try { driver.quit(); } catch (Exception ignore) { /* best-effort cleanup */ }
        }
    }

    private String checkSessionExists() {
        String winAppServerUrl = prop.getProperty("app.winAppServer");
        log.info("[APPIUM_DEBUG] checkSessionExists - Connecting to WinAppDriver at: {}", winAppServerUrl);
        WindowsDriver probeDriver = null;
        try {
            DesiredCapabilities appCapabilities = new DesiredCapabilities();
            appCapabilities.setCapability("app", "Root");
            // Short-lived probe — 30 s is more than enough; quit() below guarantees cleanup.
            appCapabilities.setCapability(APPIUM_NEW_COMMAND_TIMEOUT, 30);
            log.info("[APPIUM_DEBUG] Creating Root probe session to check for existing Connexus window...");

            probeDriver = new WindowsDriver(URI.create(winAppServerUrl).toURL(), appCapabilities);
            log.info("[APPIUM_DEBUG] Root probe session created. Session ID: {}", probeDriver.getSessionId());

            if (!probeDriver.findElements(AppiumBy.accessibilityId("ShellForm")).isEmpty()) {
                String windowHandle = Integer.toHexString(Integer.parseInt(
                        probeDriver.findElement(AppiumBy.accessibilityId("ShellForm"))
                                .getAttribute("NativeWindowHandle"))).toUpperCase();
                log.info("[APPIUM_DEBUG] Found existing Connexus ShellForm window. Handle: {}", windowHandle);
                return windowHandle;
            }
            log.info("[APPIUM_DEBUG] No existing Connexus ShellForm window found");
        } catch (Exception ex) {
            log.error("[APPIUM_DEBUG] Error in checkSessionExists: {} - {}",
                    ex.getClass().getSimpleName(), ex.getMessage());
            log.error("[APPIUM_DEBUG] WinAppDriver URL was: {}", winAppServerUrl);
        } finally {
            // Always release the probe session — never let it idle until Appium force-kills it.
            safeQuit(probeDriver);
        }
        return null;
    }

    private String checkLoginScreenExists() {
        String winAppServerUrl = prop.getProperty("app.winAppServer");
        log.info("[APPIUM_DEBUG] checkLoginScreenExists - Checking for login screen...");
        WindowsDriver probeDriver = null;
        try {
            DesiredCapabilities appCapabilities = new DesiredCapabilities();
            appCapabilities.setCapability("app", "Root");
            appCapabilities.setCapability(APPIUM_NEW_COMMAND_TIMEOUT, 30);

            probeDriver = new WindowsDriver(URI.create(winAppServerUrl).toURL(), appCapabilities);

            if (!probeDriver.findElements(AppiumBy.accessibilityId("txtUsername")).isEmpty()) {
                String windowHandle = Integer.toHexString(Integer.parseInt(
                        probeDriver.findElement(AppiumBy.accessibilityId("txtUsername"))
                                .getAttribute("NativeWindowHandle"))).toUpperCase();
                log.info("[APPIUM_DEBUG] Found login screen. Handle: {}", windowHandle);
                return windowHandle;
            }
            log.info("[APPIUM_DEBUG] No login screen found");
        } catch (Exception ex) {
            log.error("[APPIUM_DEBUG] Error in checkLoginScreenExists: {} - {}",
                    ex.getClass().getSimpleName(), ex.getMessage());
        } finally {
            safeQuit(probeDriver);
        }
        return null;
    }

    @Override
    public boolean launchConnexus() {
        String winAppServerUrl = prop.getProperty("app.winAppServer");
        String connexusExe = prop.getProperty("app.connexusExecutable");
        
        log.info("[APPIUM_DEBUG] ========== LAUNCHING CONNEXUS ==========");
        log.info("[APPIUM_DEBUG] WinAppDriver URL: {}", winAppServerUrl);
        log.info("[APPIUM_DEBUG] Connexus executable: {}", connexusExe);
        
        try {
            String sessionExists = checkSessionExists();
            DesiredCapabilities capabilities = new DesiredCapabilities();

            if (sessionExists == null) {
                log.info("[APPIUM_DEBUG] No existing session, launching fresh Connexus app");
                capabilities.setCapability("app", connexusExe);
            } else {
                log.info("[APPIUM_DEBUG] Attaching to existing session window: {}", sessionExists);
                capabilities.setCapability("appTopLevelWindow", sessionExists);
            }

            // Tests do significant API/DB work between UI steps — 300 s prevents Appium
            // from auto-killing the session on the default 60 s newCommandTimeout.
            capabilities.setCapability(APPIUM_NEW_COMMAND_TIMEOUT, 300);
            log.info("[APPIUM_DEBUG] Creating WindowsDriver with capabilities: {}", capabilities);
            windowsDriver = new WindowsDriver(URI.create(winAppServerUrl).toURL(), capabilities);
            log.info("[APPIUM_DEBUG] WindowsDriver created. Session ID: {}", windowsDriver.getSessionId());
            
            AutomationManager.getInstance().performSleep(20);
            int counter = 3;
            while (!windowsDriver.findElements(AppiumBy.accessibilityId("2")).isEmpty()) {
                log.info("[APPIUM_DEBUG] Found dialog with ID '2', clicking to dismiss (attempt {})", counter);
                windowsDriver.findElement(AppiumBy.accessibilityId("2")).click();
                AutomationManager.getInstance().performSleep(5);
                String loginScreen = checkLoginScreenExists();
                if (loginScreen != null) {
                    // Attach to the login window that just appeared by creating a new session.
                    safeQuit(windowsDriver);

                    DesiredCapabilities attachCaps = new DesiredCapabilities();
                    attachCaps.setCapability("appTopLevelWindow", loginScreen);
                    attachCaps.setCapability(APPIUM_NEW_COMMAND_TIMEOUT, 300);

                    windowsDriver = new WindowsDriver(URI.create(winAppServerUrl).toURL(), attachCaps);
                    log.info("[APPIUM_DEBUG] Re-attached to login window. Session ID: {}", windowsDriver.getSessionId());
                }
                counter++;
                if (counter > 5) {
                    break;
                }
            }
            
            String windowTitle = windowsDriver.getTitle();
            log.info("[APPIUM_DEBUG] Current window title: {}", windowTitle);
            
            if(windowTitle.contains("Please wait")) {
                log.info("[APPIUM_DEBUG] 'Please wait' dialog detected, waiting 15 seconds...");
                AutomationManager.getInstance().performSleep(15);
            }
            
            log.info("[APPIUM_DEBUG] Connexus launch completed successfully");
            return true;
        } catch (Exception e) {
            log.error("[APPIUM_DEBUG] ========== CONNEXUS LAUNCH FAILED ==========");
            log.error("[APPIUM_DEBUG] Exception: {} - {}", e.getClass().getSimpleName(), e.getMessage());
            log.error("[APPIUM_DEBUG] WinAppDriver URL was: {}", winAppServerUrl);
            log.error("[APPIUM_DEBUG] Connexus executable was: {}", connexusExe);
            log.error("[APPIUM_DEBUG] Full stack trace:", e);
        }
        return false;
    }

    @Override
    public boolean closeConnexus() {
        try {
            //  getConnexus().closeConnexus(); // leads to App CAE!
            //getConnexus().closeConnexus(); // leads to App CAE!
            Runtime.getRuntime().exec("TASKKILL /F /IM connexus.exe");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }


    @Override
    public WindowsDriver getDriver() {
        return this.windowsDriver;
    }

    @Override
    public void switchWindow() {
        String winHandleBefore = windowsDriver.getWindowHandle();
        for (String winHandle : windowsDriver.getWindowHandles()) {
            if (!winHandle.equals(winHandleBefore)) {
                windowsDriver.switchTo().window(winHandle);
            }
        }
    }

    @Override
    public String takeScreenShot() {
        try {
            File savedFile = new File(prop.getProperty("app.workingfolder_path") + java.util.UUID.randomUUID() + ".png");
            FileUtils.copyFile(this.windowsDriver.getScreenshotAs(OutputType.FILE), savedFile);
            return savedFile.getPath();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }
}
