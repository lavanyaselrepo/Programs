package hwqe.baseframework.connexuscontext;

public enum ActionName {
    ARROW_DOWN_COUNT,
    MENU_NAVIGATION,
    SEARCH_TEXT,
    SHORTCUT_COMBO_KEY1,
    SHORTCUT_COMBO_KEY2,
    TAB_COUNT
}
