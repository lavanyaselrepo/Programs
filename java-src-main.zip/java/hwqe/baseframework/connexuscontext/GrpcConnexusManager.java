package hwqe.baseframework.connexuscontext;

import hwqe.baseframework.flauicontext.GrpcConfig;
import hwqe.baseframework.flauicontext.GrpcDriver;
import hwqe.baseframework.flauicontext.GrpcDriverException;
import hwqe.baseframework.flauicontext.GrpcServerManager;
import hwqe.baseframework.flauicontext.grpc.FlaUIProto;
import hwqe.baseframework.interfaces.IConnexus;
import hwqe.baseframework.utilities.PropertyReader;
import io.appium.java_client.windows.WindowsDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * gRPC-based ConnexusManager (Fix #5 — Strangler Fig Pattern).
 * <p>
 * Drop-in replacement for {@link ConnexusManager} when {@code app.driver.type=grpc}.
 * Uses {@link GrpcDriver} to launch, control, and close Connexus via the FlaUI gRPC Server
 * instead of WinAppDriver/Appium.
 * <p>
 * <strong>Note:</strong> {@link #getDriver()} returns {@code null} in gRPC mode.
 * Use {@link #getGrpcDriver()} and {@link #getSessionId()} instead.
 * Page object compatibility is handled in Fix #6 (GrpcBasePage).
 *
 * @see ConnexusManager
 * @see GrpcDriver
 */
@SuppressWarnings({
        "java:S108",
        "java:S1128",
        "java:S1141",
        "java:S1161",
        "java:S3776",
})
public class GrpcConnexusManager implements IConnexus {

    private static final Logger logger = LoggerFactory.getLogger(GrpcConnexusManager.class);

    private final PropertyReader prop = PropertyReader.getInstance();
    private final GrpcDriver grpcDriver;
    private final GrpcConfig grpcConfig;
    private String sessionId;
    private String windowHandle;
    private LoginAs.userType currentLoginType;

    public GrpcConnexusManager() {
        this.grpcConfig = GrpcConfig.getInstance();
        this.grpcDriver = GrpcDriver.getInstance();
    }

    // ================================================================
    // IConnexus Implementation
    // ================================================================

    /** Max seconds to wait for Connexus window to appear after a service restart. */
    private static final int WINDOW_DISCOVERY_TIMEOUT_SEC = 8;
    /** How long to sleep between window-discovery retries (ms). */
    private static final int WINDOW_DISCOVERY_RETRY_MS = 2000;

    @Override
    public boolean launchConnexus() {
        try {
            // 0. Auto-start gRPC server if not running (Fix #11)
            GrpcServerManager serverManager = GrpcServerManager.getInstance();
            if (!serverManager.ensureServerRunning()) {
                logger.error("gRPC FlaUI Server could not be started at {}", grpcConfig.getTarget());
                return false;
            }

            // 2. Create session with capabilities
            Map<String, String> capabilities = new HashMap<>();
            capabilities.put("app", prop.getProperty("app.connexusExecutable"));
            capabilities.put("platform", "Windows");

            // 3. Try to find an existing Connexus window, retrying for WINDOW_DISCOVERY_TIMEOUT_SEC
            //    seconds.  After restartConnexusService() the app may still be loading its UI.
            String existingHandle = findExistingConnexusWindowWithRetry();

            if (existingHandle != null) {
                logger.info("Found existing Connexus window, attaching via handle: {}", existingHandle);
                capabilities.put("appTopLevelWindow", existingHandle);
                sessionId = grpcDriver.createSession(capabilities);
                windowHandle = existingHandle;
            } else {
                // No usable Connexus window found (app may be stuck on login/security popup
                // from a prior run). Kill any stale process BEFORE launching fresh — otherwise
                // the new instance will show a "duplicate instance" dialog that blocks the
                // login form from ever appearing and wastes the full 30s splash timeout.
                killStaleConnexusInstances();
                logger.info("No existing Connexus window found after {}s, launching fresh...",
                        WINDOW_DISCOVERY_TIMEOUT_SEC);
                sessionId = grpcDriver.createSession(capabilities);
                windowHandle = grpcDriver.launchApplication(
                        sessionId,
                        prop.getProperty("app.connexusExecutable"),
                        new HashMap<>()
                );
            }

            logger.info("Connexus launched via gRPC (session: {}, handle: {})", sessionId, windowHandle);

            // 4. Dismiss unexpected startup popups BEFORE waiting for the login screen.
            //    Running this first prevents a "second instance" or third-party popup
            //    from blocking handleSplashScreen's 30-second login-field wait.
            dismissStartupPopups();

            // 5. Handle "Please wait" splash screen / wait for login fields
            handleSplashScreen();

            // 6. Warm up COM automation cache (Fix #11)
            //    First run after server restart is slow due to cold COM cache.
            //    This pre-heats it so actual test steps get "warm" performance.
            warmUpComCache();

            return true;
        } catch (GrpcDriverException e) {
            logger.error("Failed to launch Connexus via gRPC: {}", e.getMessage(), e);
            return false;
        } catch (Exception e) {
            logger.error("Unexpected error launching Connexus: {}", e.getMessage(), e);
            return false;
        }
    }

    @Override
    public boolean closeConnexus() {
        try {
            if (sessionId != null) {
                grpcDriver.closeApplication(sessionId);
                grpcDriver.closeSession(sessionId);
                logger.info("Connexus closed via gRPC (session: {})", sessionId);
                sessionId = null;
                windowHandle = null;
            }
        } catch (GrpcDriverException e) {
            logger.warn("gRPC close failed, falling back to TASKKILL: {}", e.getMessage());
            forceKillConnexus();
        }
        return true;
    }

    /** Default timeout (ms) to wait for a new window to appear during window switches. */
    private static final int SWITCH_WINDOW_TIMEOUT_MS  = 8_000;
    /** How long to sleep between window-switch polling attempts (ms). */
    private static final int SWITCH_WINDOW_POLL_MS     = 500;

    @Override
    public void switchWindow() {
        long deadline = System.currentTimeMillis() + SWITCH_WINDOW_TIMEOUT_MS;
        String currentHandle = null;

        // Best-effort: get the handle we're currently on.
        // May throw if the active window was just destroyed (e.g. login → popup transition).
        try {
            currentHandle = grpcDriver.getWindowHandle(sessionId);
        } catch (GrpcDriverException ex) {
            logger.debug("[switchWindow] Could not read current handle (window likely destroyed): {}",
                    ex.getMessage());
        }

        logger.debug("[switchWindow] Starting. currentHandle={}, timeout={}ms",
                currentHandle, SWITCH_WINDOW_TIMEOUT_MS);

        while (System.currentTimeMillis() < deadline) {
            try {
                List<String> handles = grpcDriver.getWindowHandles(sessionId);

                if (handles != null && !handles.isEmpty()) {
                    String target = null;
                    for (String handle : handles) {
                        if (!handle.equals(currentHandle)) {
                            target = handle;
                            break;
                        }
                    }

                    if (target != null) {
                        grpcDriver.switchToWindow(sessionId, target);
                        windowHandle = target;
                        logger.info("[switchWindow] Switched from {} to {}", currentHandle, target);
                        return;
                    }

                    // Only window is the same one we started on — popup not visible yet.
                    logger.debug("[switchWindow] Only one window ({}). Waiting for popup...",
                            currentHandle);
                }
            } catch (GrpcDriverException ex) {
                logger.debug("[switchWindow] Poll error (will retry): {}", ex.getMessage());
            }

            try {
                Thread.sleep(SWITCH_WINDOW_POLL_MS);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                logger.warn("[switchWindow] Interrupted while waiting for new window.");
                return;
            }
        }

        logger.warn("[switchWindow] TIMEOUT ({}ms): No new window appeared. currentHandle={}",
                SWITCH_WINDOW_TIMEOUT_MS, currentHandle);
    }

    /**
     * Returns {@code null} in gRPC mode.
     * <p>
     * gRPC mode does not use WinAppDriver, so there is no {@link WindowsDriver}.
     * Use {@link #getGrpcDriver()} and {@link #getSessionId()} instead.
     * Page object compatibility is handled in Fix #6 (GrpcBasePage).
     *
     * @return always {@code null}
     */
    @Override
    public WindowsDriver getDriver() {
        logger.warn("getDriver() called in gRPC mode — returns null. "
                + "Use getGrpcDriver() + getSessionId() instead.");
        return null;
    }

    @Override
    public String takeScreenShot() {
        try {
            byte[] pngBytes = grpcDriver.takeScreenshot(sessionId);
            File savedFile = new File(
                    prop.getProperty("app.workingfolder_path") + UUID.randomUUID() + ".png");
            Files.write(savedFile.toPath(), pngBytes);
            return savedFile.getPath();
        } catch (GrpcDriverException e) {
            logger.error("Screenshot failed: {}", e.getMessage());
        } catch (IOException e) {
            logger.error("Failed to save screenshot file: {}", e.getMessage());
        }
        return null;
    }

    // ================================================================
    // gRPC-Specific Accessors
    // ================================================================

    /**
     * Get the underlying gRPC driver for direct RPC calls.
     *
     * @return the GrpcDriver singleton
     */
    public GrpcDriver getGrpcDriver() {
        return grpcDriver;
    }

    /**
     * Get the current gRPC session ID.
     *
     * @return the session ID, or null if no session is active
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * Get the current window handle.
     *
     * @return the window handle hex string
     */
    public String getWindowHandle() {
        return windowHandle;
    }

    /**
     * Check if a gRPC session is currently active.
     */
    public boolean isSessionActive() {
        return sessionId != null;
    }

    /**
     * Returns the login type used for the current active session.
     * Null if no session is active yet.
     */
    public LoginAs.userType getCurrentLoginType() {
        return currentLoginType;
    }

    /**
     * Records the login type after a successful login so subsequent TCs
     * can detect when a different user type requires a fresh login.
     */
    public void setCurrentLoginType(LoginAs.userType loginType) {
        this.currentLoginType = loginType;
        logger.info("[gRPC] Active login type set to: {}", loginType);
    }

    /**
     * COM Health Check (Fix10) — pings the gRPC server to verify COM automation responsiveness.
     * Returns round-trip latency in ms, or -1 if the check fails.
     */
    @Override
    public long checkComHealth() {
        logger.info("[COM-HealthCheck] Pinging gRPC server to verify COM automation responsiveness...");
        try {
            long start = System.currentTimeMillis();
            grpcDriver.getWindowHandle(sessionId);
            long elapsed = System.currentTimeMillis() - start;
            if (elapsed > 5000) {
                logger.warn("[COM-HealthCheck] WARNING: gRPC COM response SLOW ({}ms). "
                        + "COM automation may be degraded on RXPC. Consider restarting gRPC server.", elapsed);
            } else {
                logger.info("[COM-HealthCheck] OK \u2014 response time: {}ms", elapsed);
            }
            return elapsed;
        } catch (Exception e) {
            logger.error("[COM-HealthCheck] FAILED: {} \u2014 {}. COM automation may be broken on RXPC!",
                    e.getClass().getSimpleName(), e.getMessage());
            return -1;
        }
    }

    /**
     * Warm up the gRPC server's COM automation cache (Fix #11).
     * <p>
     * After a fresh server start, the first few COM automation calls are slow
     * because FlaUI needs to build its UI Automation element tree cache.
     * This method makes several lightweight gRPC calls to pre-heat that cache
     * BEFORE the actual test starts, so test execution gets "warm" performance.
     * <p>
     * Called automatically after {@link #launchConnexus()} completes.
     *
     * @param warmupCalls number of warm-up iterations (default: 3)
     */
    public void warmUpComCache(int warmupCalls) {
        if (sessionId == null) {
            logger.warn("[WarmUp] Skipped — no active session");
            return;
        }
        logger.info("[WarmUp] Warming up COM automation cache with {} iterations...", warmupCalls);
        long totalStart = System.currentTimeMillis();

        for (int i = 1; i <= warmupCalls; i++) {
            long callStart = System.currentTimeMillis();
            try {
                // Lightweight calls that exercise the COM automation path:
                // 1. getWindowHandle — touches the window management layer
                grpcDriver.getWindowHandle(sessionId);
                // 2. getWindowHandles — enumerates all automation windows
                grpcDriver.getWindowHandles(sessionId);
                // 3. takeScreenshot — exercises the visual capture pipeline
                grpcDriver.takeScreenshot(sessionId);

                long callElapsed = System.currentTimeMillis() - callStart;
                logger.info("[WarmUp] Iteration {}/{} completed in {}ms", i, warmupCalls, callElapsed);
            } catch (Exception e) {
                long callElapsed = System.currentTimeMillis() - callStart;
                logger.warn("[WarmUp] Iteration {}/{} failed after {}ms: {}",
                        i, warmupCalls, callElapsed, e.getMessage());
            }
        }

        long totalElapsed = System.currentTimeMillis() - totalStart;
        logger.info("[WarmUp] COM cache warm-up complete in {}ms (avg: {}ms per iteration)",
                totalElapsed, warmupCalls > 0 ? totalElapsed / warmupCalls : 0);
    }

    /**
     * Warm up with default 3 iterations.
     */
    public void warmUpComCache() {
        int configuredCalls = 3;
        try {
            String val = prop.getProperty("grpc.warmup.iterations");
            if (val != null && !val.trim().isEmpty()) {
                configuredCalls = Integer.parseInt(val.trim());
            }
        } catch (Exception ignored) { /* use default */ }
        warmUpComCache(configuredCalls);
    }

    // ================================================================
    // Internal Helpers
    // ================================================================

    /**
     * Try to find an existing Connexus window (ShellForm) via a root session,
     * retrying for up to {@link #WINDOW_DISCOVERY_TIMEOUT_SEC} seconds.
     * <p>
     * This handles the race condition where {@code restartConnexusService()} has
     * returned but the Connexus UI (ShellForm) has not fully rendered yet.
     *
     * @return the hex window handle if found within the timeout, null otherwise
     */
    private String findExistingConnexusWindowWithRetry() {
        long deadline = System.currentTimeMillis() + WINDOW_DISCOVERY_TIMEOUT_SEC * 1000L;
        int attempt = 0;
        while (System.currentTimeMillis() < deadline) {
            attempt++;
            String handle = findExistingConnexusWindow();
            if (handle != null) {
                if (attempt > 1) {
                    logger.info("Connexus window found on attempt #{} after waiting.", attempt);
                }
                return handle;
            }
            logger.debug("Connexus ShellForm not ready yet (attempt {}), retrying in {}ms...",
                    attempt, WINDOW_DISCOVERY_RETRY_MS);
            try {
                Thread.sleep(WINDOW_DISCOVERY_RETRY_MS);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                return null;
            }
        }
        logger.warn("Connexus window not found after {}s ({} attempts).",
                WINDOW_DISCOVERY_TIMEOUT_SEC, attempt);
        return null;
    }

    /**
     * Single-attempt lookup of an existing Connexus window (ShellForm) via a root session.
     *
     * @return the hex window handle if found, null otherwise
     */
    private String findExistingConnexusWindow() {
        String rootSessionId = null;
        try {
            Map<String, String> rootCaps = new HashMap<>();
            rootCaps.put("app", "Root");
            rootSessionId = grpcDriver.createSession(rootCaps);

            String shellElement = grpcDriver.findElement(
                    rootSessionId,
                    FlaUIProto.LocatorStrategy.ACCESSIBILITY_ID,
                    "ShellForm"
            );

            String nativeHandle = grpcDriver.getAttribute(rootSessionId, shellElement, "NativeWindowHandle");
            return Integer.toHexString(Integer.parseInt(nativeHandle)).toUpperCase();

        } catch (GrpcDriverException e) {
            logger.debug("No existing Connexus window found: {}", e.getMessage());
            return null;
        } finally {
            if (rootSessionId != null) {
                try {
                    grpcDriver.closeSession(rootSessionId);
                } catch (Exception ignored) {
                    // best-effort cleanup
                }
            }
        }
    }

    /**
     * Handle the "Please wait" splash screen.
     * <p>
     * Instead of waiting for the splash to DISAPPEAR (fragile negative-poll),
     * we wait for the login element to APPEAR — exits the moment the app is ready.
     */
    private void handleSplashScreen() {
        logger.info("[handleSplashScreen] Waiting for login screen to appear...");
        String[] loginLocators = { "txtUserName", "txtUsername" };
        int maxWaitSeconds = 30;
        long deadline = System.currentTimeMillis() + (maxWaitSeconds * 1000L);
        int pollCycle = 0;
        while (System.currentTimeMillis() < deadline) {
            pollCycle++;
            // 1. Try the current session window (fast path)
            for (String locator : loginLocators) {
                try {
                    String elementId = grpcDriver.findElement(
                            sessionId,
                            FlaUIProto.LocatorStrategy.ACCESSIBILITY_ID,
                            locator,
                            "",
                            500
                    );
                    if (elementId != null) {
                        logger.info("[handleSplashScreen] Login screen ready in current window (found '{}').", locator);
                        return;
                    }
                } catch (Exception ignored) { /* keep polling */ }
            }

            // 2. Login form may appear in a NEW window (e.g. splash → login transition).
            //    Scan evew owned by this process for the login element.
            try {
                List<String> handles = grpcDriver.getWindowHandles(sessionId);
                if (handles != null) {
                    for (String handle : handles) {
                        try {
                            grpcDriver.switchToWindow(sessionId, handle);
                            for (String locator : loginLocators) {
                                try {
                                    String elementId = grpcDriver.findElement(
                                            sessionId,
                                            FlaUIProto.LocatorStrategy.ACCESSIBILITY_ID,
                                            locator,
                                            "",
                                            500
                                    );
                                    if (elementId != null) {
                                        logger.info("[handleSplashScreen] Login screen found in window {} ('{}')."
                                                + " Switched session to login window.", handle, locator);
                                        windowHandle = handle;
                                        return;
                                    }
                                } catch (Exception ignored) { /* try next locator */ }
                            }
                        } catch (Exception ignored) { /* try next handle */ }
                    }
                }
            } catch (Exception ignored) { /* window enumeration not yet stable, keep polling */ }

            // 3. Every ~4s, try to dismiss any popup that may be blocking the login form
            //    (defense-in-depth: covers late-arriving second-instance dialogs).
            if (pollCycle % 16 == 0) {
                // Do NOT auto-click "Close" here: on some hosts it closes the Connexus
                // main/login shell itself and leaves zero windows to attach.
                String[] blockingBtns = { "OK", "Yes", "2" };
                for (String btn : blockingBtns) {
                    try {
                        var resp = grpcDriver.handlePopup(sessionId, "", btn, 1);
                        if (resp.getPopupFound() && resp.getActionTaken()) {
                            logger.info("[handleSplashScreen] Dismissed blocking popup '{}' (btn='{}') during login wait.",
                                    resp.getPopupTitle(), btn);
                            break;
                        }
                    } catch (Exception ignored) { }
                }
            }

            try { Thread.sleep(250); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
        }
        logger.warn("[handleSplashScreen] Login screen not found after {}s, proceeding anyway.", maxWaitSeconds);
    }

    /**
     * Fallback: force kill Connexus process via TASKKILL.
     */
    private void forceKillConnexus() {
        try {
            new ProcessBuilder(
                    resolveWindowsSystemCommand("taskkill"),
                    "/F",
                    "/IM",
                    "connexus.exe"
            ).start();
            sessionId = null;
            windowHandle = null;
        } catch (IOException e) {
            logger.error("TASKKILL failed: {}", e.getMessage());
        }
    }

    /**
     * Kill any running Connexus.exe processes before launching a fresh instance.
     * <p>
     * When a prior test leaves Connexus stuck on a login or security popup,
     * {@link #findExistingConnexusWindowWithRetry()} cannot attach to it (only
     * ShellForm = usable). Launching fresh without killing the stale process
     * triggers a "duplicate instance" dialog that blocks the login form.
     */
    private void killStaleConnexusInstances() {
        try {
            // Check if connexus.exe is running
            Process check = new ProcessBuilder(
                    resolveWindowsSystemCommand("tasklist"),
                    "/FI", "IMAGENAME eq Connexus.exe", "/NH", "/FO", "CSV")
                    .redirectErrorStream(true).start();
            String output = new String(check.getInputStream().readAllBytes()).toLowerCase();
            check.waitFor();

            if (output.contains("connexus.exe")) {
                logger.warn("[killStaleConnexus] Stale Connexus.exe detected. Terminating before fresh launch...");
                Process kill = new ProcessBuilder(
                        resolveWindowsSystemCommand("taskkill"),
                        "/F", "/IM", "Connexus.exe", "/T")
                        .redirectErrorStream(true).start();
                kill.waitFor();
                logger.info("[killStaleConnexus] Stale Connexus process terminated. Allowing OS cleanup...");
                Thread.sleep(2000); // wait for handles/ports to be released
            } else {
                logger.debug("[killStaleConnexus] No stale Connexus process running.");
            }
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            logger.warn("[killStaleConnexus] Could not check/kill stale Connexus: {}", e.getMessage());
        }
    }

    /**
     * Dismiss unexpected third-party popups that appear during Connexus startup.
     * <p>
     * Known popups:
     * <ul>
     *   <li><b>PixTools/EMC Captiva licensing warning</b> — "Warning: Unregistered or
     *       Development Version". Has an OK button. Harmless; just needs dismissing.</li>
     * </ul>
     * <p>
     * Uses the gRPC server's native HandlePopup which searches modal windows and
     * all top-level application windows. Retries a few times with a short delay
     * because the popup may appear with a slight delay after the splash screen clears.
     */
    private void dismissStartupPopups() {
        logger.info("[dismissStartupPopups] Checking for unexpected startup popups...");
        // Button labels tried in order: covers both generic Win32 dialogs (OK/2) and
        // Do NOT auto-click "Close" here: on some hosts it closes Connexus itself.
        // Keep startup dismissal limited to safe confirmations.
        String[] buttonLabels = { "OK", "Yes", "2" };
        int maxAttempts = 4;
        int dismissedCount = 0;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            boolean dismissed = false;
            for (String btn : buttonLabels) {
                try {
                    var resp = grpcDriver.handlePopup(sessionId, "", btn, 2);
                    if (resp.getPopupFound() && resp.getActionTaken()) {
                        dismissedCount++;
                        logger.info("[dismissStartupPopups] Attempt {}: Dismissed popup '{}' via button '{}'",
                                attempt, resp.getPopupTitle(), btn);
                        dismissed = true;
                        break; // popup dismissed — check for next stacked popup
                    } else if (resp.getPopupFound()) {
                        logger.debug("[dismissStartupPopups] Attempt {}: Popup '{}' found but button '{}' didn't work, trying next.",
                                attempt, resp.getPopupTitle(), btn);
                    }
                } catch (GrpcDriverException e) {
                    logger.debug("[dismissStartupPopups] Attempt {} btn='{}': {}", attempt, btn, e.getMessage());
                } catch (Exception e) {
                    logger.warn("[dismissStartupPopups] Attempt {} btn='{}' error: {} - {}",
                            attempt, btn, e.getClass().getSimpleName(), e.getMessage());
                }
            }

            if (!dismissed) {
                // No popup found with any button label — clear to proceed
                logger.info("[dismissStartupPopups] Attempt {}: No dismissible popup found. Clear to proceed.", attempt);
                break;
            }

            // Brief pause: a second popup may appear immediately after the first is dismissed
            try { Thread.sleep(500); } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                return;
            }
        }

        if (dismissedCount > 0) {
            logger.info("[dismissStartupPopups] Dismissed {} startup popup(s) total.", dismissedCount);
        }
    }

    private String resolveWindowsSystemCommand(String commandName) {
        String systemRoot = System.getenv("SystemRoot");
        if (systemRoot != null && !systemRoot.trim().isEmpty()) {
            String candidate = Paths.get(systemRoot, "System32", commandName + ".exe").toString();
            File exe = new File(candidate);
            if (exe.exists() && exe.isFile()) {
                return exe.getAbsolutePath();
            }
        }
        throw new IllegalStateException(
                "Windows system command '" + commandName + "' not found under SystemRoot/System32. "
                        + "Refusing PATH fallback for security.");
    }
}