package hwqe.baseframework.connexuscontext;

public enum WorkQueueCode {
    DROPOFF(1),
    INPUT(2),
    COUNSEL(3),
    FILLING(4),
    FOURPOINT(5),
    PICKUP(6),
    RESOLVE(7),
    TP(8),
    DUR(9),
    VISUALVERIFY(10),
    MODIFYDETAILS(11),
    CHKDUR(12),
    REPRINT(13),
    CALLDR(14),
    POS(15),
    EOD(16),
    CASH(31);


    private final int queue;

    WorkQueueCode(int queue) {
        this.queue = queue;
    }

    public int getWorkQueueCode() {
        return queue;
    }
}
