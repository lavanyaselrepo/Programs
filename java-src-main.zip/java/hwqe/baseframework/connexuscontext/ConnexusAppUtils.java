package hwqe.baseframework.connexuscontext;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexusharnessapicontext.apimanager.CacheServiceManager;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.connexus.PrescriberModel;
import hwqe.baseframework.utilities.FileUtils;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StringUtils;
import io.strati.libs.joda.time.DateTime;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.*;
import java.util.stream.Collectors;
import org.json.JSONArray;
import org.json.JSONObject;

public class ConnexusAppUtils {
    static File file, fileWithFullName;
    static File services;
    FileWriter fileWriter;
    Desktop desktop;
    AutomationManager automationManager;
    PropertyReader prop = PropertyReader.getInstance();
    Date date = new Date();
    GregorianCalendar cal = new GregorianCalendar();
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat();

    HashMap<String, String> headers = new HashMap<>();
    ServiceRequest req = new ServiceRequest();
    ServiceResponse resp = new ServiceResponse();
    CacheServiceManager cacheManager = new CacheServiceManager();
    int siteId, prescriberId, orderId;
    String stateId, query, licenseNbr;
    Long productMdsFamId;
    List<String> licenseTypeCodes = new ArrayList<>();
    static int rxId;
    public Boolean isTaskOrderCreated = false;
    PropertyReader propertyReader=PropertyReader.getInstance();

    public ConnexusAppUtils() {
        prop.loadCustomProperties("config/connexus/");
        automationManager = AutomationManager.getInstance();
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
    }

    /*
     * This method read flag value from test date excel sheet and site db, then
     * compare its value, if values are different it will update flag value or
     * just print if both the flags are same
     *
     * Author:Ashok(vn50h3h)
     *
     * This method Take "<flagCode>=<FlagValue>" pair as parameter and return
     * nothing
     */
    public boolean readAndUpdateFlag(String flagCode, String flagValue) {
        List<Map<String, Object>> resultSet = readFlagValue(flagCode);
        assert resultSet != null;
        if (resultSet.size() == 1 && !resultSet.get(0).get("phm_parm_value").toString().trim().equalsIgnoreCase(flagValue)) {
            if (updateFlagValue(flagCode, flagValue) > 0) {
                Reporter.log("Flag Code \t\t:" + flagCode + " And Updated Value to \t\t:" + flagValue);
                return true;
            } else {
                Reporter.log("Update flag status\t\t:" + "flag update failed! for "+ flagCode);
                return false;
            }
        } else {
            return false;
        }
    }

    public String getReasonCode(String denialReason){
        String query ="select code_key from reason_code where code_description = \"" + denialReason + "\"" + "limit 1";
        Log.info(query);
        String reasonCode = automationManager.getConnexusDB(siteId).getScalar
                (query, String.class);
        Reporter.log("Reason Code:" + reasonCode);
        return reasonCode.trim();
    }

    /*
     * this method read the flag value for give flag code from the site db
     *
     * Author:Ashok(vn50h3h)
     *
     * This method takes flagCode as input and returns "<flagCode>=<flagValue>"
     * as whole string
     */
    public List<Map<String, Object>> readFlagValue(String flagCode) {
        try {
            String selectQuery = "select * from bu_phm_parm where phm_parm_code = " + flagCode;
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB().executeQueryForList(selectQuery);
            if (resultSet != null) {
                return resultSet;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean isFlagEnabled(String flagCode) {
        try {
            String selectQuery = "select phm_parm_value from bu_phm_parm where phm_parm_code = " + flagCode;
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB().executeQueryForList(selectQuery);
            if (resultSet != null && !resultSet.isEmpty() && resultSet.get(0) != null) {
                Object value = resultSet.get(0).get("phm_parm_value");
                if (value != null && "TRUE".equalsIgnoreCase(value.toString().trim())) {
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean isFlagEnabledbyStore(String flagCode, int storeId) {
        try {
            String selectQuery = "select phm_parm_value from bu_phm_parm where phm_parm_code = " + flagCode;
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB(storeId).executeQueryForList(selectQuery);
            if (resultSet != null && !resultSet.isEmpty() && resultSet.get(0) != null) {
                Object value = resultSet.get(0).get("phm_parm_value");
                if (value != null && "TRUE".equalsIgnoreCase(value.toString().trim())) {
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Map<String, Object>> verifyActivityCode(String rxnbr) {
        try {
            String selectQuery = "select * from rx_Activity where rx_id in (select rx_id from rx where rx_nbr in (\"" + rxnbr + "\")) and activity_code in (15237)";
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB().executeQueryForList(selectQuery);
            if (resultSet != null) {
                return resultSet;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Map<String, Object>> verifySubQueTypeCode(String rxnbr) {
        try {
            String selectQuery = "select * from rx_order_detail where rx_id in(select rx_id from rx where rx_nbr in (\"" + rxnbr + "\"))";
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB().executeQueryForList(selectQuery);
            if (resultSet != null) {
                return resultSet;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Map<String, Object>> getTransTypeAndStatusCOdeByFillId(String FillId) {
        try {
            String selectQuery = "select * from cf_msg_xfer where rx_fill_id=" + FillId;
            Reporter.log("Executing query :- "+selectQuery);
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB().executeQueryForList(selectQuery);
            if (resultSet != null) {
                return resultSet;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }

    public int getOrderId(String rxNbr) {
        String query = "select max(order_id) as order_id from  rx_order_detail where rx_id =(select rx_id from rx where rx_nbr=\"" + rxNbr + "\")";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        int orderId = Integer.parseInt(rxInfo.get("order_id").toString());
        return orderId;
    }

    public void readFlagAndUpdateBasedOnFillId(String flagCode, String flagValue) {
        List<Map<String, Object>> resultSet = readFlagValue(flagCode);
        assert resultSet != null;
        if (resultSet.size() == 1) {
            String currentFlagValue = resultSet.get(0).get("phm_parm_value").toString().trim();
            if (currentFlagValue.equalsIgnoreCase(flagValue)) {
                Reporter.log("No flag update required");
            } else {
                readAndUpdateFlag(flagCode, flagValue);
                String siteId = prop.getProperty("cnx.store");
                callFlushCacheAPI(siteId);
            }
        }
    }

    public void callFlushCacheAPI(String siteID) {
        String serviceEndPointURL = StoreIDManager.createEndPointURL(siteID, prop.getProperty("connexustestharness.common.portNo"),
                prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexustestharness.flushCacheEndPoint"));
        req.setUrl(serviceEndPointURL);
        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        resp = automationManager.getRestContext().performPost(req);
        Assert.assertEquals(resp.getStatusCode(), 200, "Flush Cache not Successful");
        Log.info("Flush Cache Successful");
    }

    public int getFillId(String rxNbr) {
        String query = "select max(rx_fill_id) as rx_fill_id  from  rx_order_detail where rx_id =(select rx_id from rx where rx_nbr=\"" + rxNbr + "\")";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        int fillId = Integer.parseInt(rxInfo.get("rx_fill_id").toString());
        return fillId;
    }

    public String getStoreTranIdForFillId(int siteId, int fillId) {
        Map<String, Object> result = automationManager
                .getConnexusDB(siteId)
                .executeQuery("select store_tran_id from cf_msg_xfer where rx_fill_id=" + fillId + " and trans_type_code=1");
        if (result == null || result.get("store_tran_id") == null) {
            Assert.fail("No store_tran_id found in cf_msg_xfer for fillId: " + fillId);
            return null;
        }
        return result.get("store_tran_id").toString();
    }


    public String readFillIdFromTheDb() {
        String query = "select first 1 rx_fill_id from rx_fill order by rx_id desc";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        String fillId = rxInfo.get("rx_fill_id").toString();
        Log.info(fillId);
        return fillId;
    }

    /*
     * This method update flag value for given flag code into the site db
     *
     * Author:Ashok(vn50h3h)
     *
     * This method will take flag code and flag value as parameter and returns
     * nothing
     */
    public int updateFlagValue(String flagCode, String flagValue) {
        String updateQuery = "update bu_phm_parm set phm_parm_value = \"" + flagValue + "\" where phm_parm_code = \""
                + flagCode + "\" and phm_bu_id = \"" + prop.getProperty("cnx.store") + "\"";
        try {
            return automationManager.getConnexusDB().executeUpdateQuery(updateQuery);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /*
     * This method updates State value of Store into the site db
     *
     * Author:Lakshmi Priya (vn510nm)
     *
     * This method will take State value as parameter and returns
     * nothing
     */
    public boolean updateStateValue(String stateValue) {
        String updateQuery = "update bus_unit_addr set state =\"" + stateValue + "\" where bu_nbr=\"" + prop.getProperty("cnx.store") + "\"";
        try {
            String resultSet = Integer.toString(automationManager.getConnexusDB().executeUpdateQuery(updateQuery));
            if (resultSet != null) {
                return true;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void switchLoginScreen(LoginAs.userType userType) {
        switch (userType) {
            case HOMEOFFICE_ADFlagOn:
                readAndUpdateFlag("28750", "TRUE");
                break;
            case HOMEOFFICE_ADFlagOff:
                readAndUpdateFlag("28750", "FALSE");
                break;
            case PHARMACIST_ADFlagOff:
                readAndUpdateFlag("28750", "FALSE");
                break;
            case TECHNICIAN_ADFlagOff:
                readAndUpdateFlag("28750", "FALSE");
                break;
            default:
        }
    }

    public String randomName() {
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        int length = 4;
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(alphabet.length());
            char randomChar = alphabet.charAt(index);
            sb.append(randomChar);
        }
        sb.append(1 + new Random().nextInt(9999));
        return sb.toString();
    }

    /**
     * This method will generate 6 digit random number.
     *
     * @return
     */
    public int randomNumber() {
        Random random = new Random();
        return 100000 + random.nextInt(900000);
    }

    public void addRandomNamesInFile() {
        file = FileUtils.createTempFile("temp.txt", StringUtils.uniqueFirstName() + "," + StringUtils.uniqueLastName());
    }

    public void addRandomNamesInFile(String lastName, String firstName) {
        file = FileUtils.createTempFile("temp.txt", lastName + "," + firstName);
    }

    public String[] readPatientNameFromFile() {
        return Objects.requireNonNull(FileUtils.readLineFromFile(file, 0)).split(",");
    }

    public void addRandomNameInFile() {
        file = FileUtils.createTempFile("temp.txt", StringUtils.uniqueFirstName());
    }

    public String readNameFromFile() {
        return Objects.requireNonNull(FileUtils.readLineFromFile(file, 0));
    }

    public PrescriberModel selectPrescriberFromDb() {
        PrescriberModel prescriberModel = new PrescriberModel();
        String query = "select last_name,first_name,middle_name,trim(prescbr_label_name) as prescriber_label_name\n" +
                "from prescriber p, subject_address sa , prescriber_clinic pc\n" +
                "where p.status_code=20100\n" +
                "and p.prescriber_id =  pc.prescriber_id\n" +
                "and pc.primary_clinic_ind = 'Y'\n" +
                "and pc.active_ind = 'Y'\n" +
                "and pc.clinic_id = sa.subject_id\n" +
                "and subject_type_code = 303\n" +
                "and p.middle_name is not null and p.last_name is not null and p.prescbr_label_name is not null and p.first_name is not null\n" +
                "order by p.last_change_ts desc limit 1";
        Map<String, Object> prescriber = automationManager.getConnexusDB().executeQuery(query);
        prescriberModel.setPrescriberFirstName(prescriber.get("first_name").toString().trim());
        prescriberModel.setPrescriberMiddleName(prescriber.get("middle_name").toString().trim());
        prescriberModel.setPrescriberLastName(prescriber.get("last_name").toString().trim());
        prescriberModel.setPrescriberLabelName(prescriber.get("prescriber_label_name").toString().trim());
        return prescriberModel;
    }

    public String getRandomRxFromStoreDb() {
        try {
            String selectQuery =
                    "select * from rx as rx inner join\n" +
                            "(select max(rx_written_date) as LatestDate, rx_nbr from rx group by rx_nbr order by 1 desc) SubMax on \n" +
                            "rx.rx_written_date = SubMax.LatestDate and \n" +
                            "rx.rx_nbr = SubMax.rx_nbr and \n" +
                            "rx.status_code = 20604\n" +
                            "limit 1;";
            Map<String, Object> resultSet;
            resultSet = automationManager.getConnexusDB().executeQuery(selectQuery);
            if (resultSet != null) {
                return resultSet.get("rx_nbr").toString().trim();
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }

    /*
     * method generates and returns random number from 0 to 2999 inclusive
     * The number generated is assigned as bag number for a order in rx_order_detail table
     * in Filling WorkQueue; Returns Integer
     *
     * Author: Lakshmi Priya(vn510nm)
     * */
    public int getAvailableToteNbr() {
        Random r = new Random();
        int toteNbr = 0;
        while (true) {
            toteNbr = r.nextInt(2999);
            int retVal = automationManager.getConnexusDB().getScalar("select count(order_id) from rx_order_detail where tote_nbr=" + toteNbr, Integer.class);
            if (retVal == 0) {
                break;
            }
        }
        return toteNbr;
    }

    public Map<String, Object> getRandomPatientFromStoreDb() {
        try {
            // Query to get patients with valid alphabetic names (no numbers in first_name or last_name)
            // Using regex MATCHES to exclude names containing digits
            String selectQuery = "Select rx.* from rx inner join ( "
                    + "Select max(rx_exp_date) as LatestDate, rx_nbr from rx Group by rx_nbr ) SubMax "
                    + "on rx.rx_written_date = SubMax.LatestDate and rx.rx_nbr = SubMax.rx_nbr "
                    + "inner join informix.patient p on rx.patient_id = p.patient_id "
                    + "and rx.status_code = 20604 "
                    + "where p.first_name NOT MATCHES '*[0-9]*' "
                    + "and p.last_name NOT MATCHES '*[0-9]*' "
                    + "order by 1 desc limit 1;";
            Map<String, Object> resultSet;
            resultSet = automationManager.getConnexusDB().executeQuery(selectQuery);
            if (resultSet != null) {
                // Sanitize patient_id to prevent SQL injection
                Object patientIdObj = resultSet.get("patient_id");
                long patientIdValue;
                if (patientIdObj instanceof Number) {
                    patientIdValue = ((Number) patientIdObj).longValue();
                } else {
                    try {
                        patientIdValue = Long.parseLong(patientIdObj.toString().trim());
                    } catch (NumberFormatException e) {
                        Log.info("Invalid patient_id value: " + patientIdObj);
                        return null;
                    }
                }
                
                String selectQuery2 = "select * from informix.patient where "
                        + "patient_id = " + patientIdValue
                        + " limit 1;";
                resultSet = automationManager.getConnexusDB().executeQuery(selectQuery2);
                if (resultSet != null) {
                    return resultSet;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /*----------------------------------------------------------------------------------------------------------
    * The below method fetches the patient_id from patient table when first name and last name are provided as input.
    * Author: Tarun(vn510o1)
    ----------------------------------------------------------------------------------------------------------*/
    public String getPatientId(String lastName, String firstName) {
        AutomationManager automationManager = AutomationManager.getInstance();
        String patLastname = lastName.toUpperCase();
        String patFirstname = firstName.toUpperCase();
        String query = "select * from patient where last_name = \""
                + patLastname + "\" and first_name = \"" + patFirstname + "\"" + ";";
        Map<String, Object> patient = automationManager.getConnexusDB().executeQuery(query);
        return patient.get("patient_id").toString();
    }

    /*----------------------------------------------------------------------------------------------------------
    * The below method fetches the timestamp from patient demolog table
    * Author: Tarun(vn510o1)
    ----------------------------------------------------------------------------------------------------------*/
    public String getTimeStampFromPatientDemogTable(String patientId) {
        String query = "select demog_ts from patient_demog where patient_id= \""
                + patientId + "\"";
        Map<String, Object> patient = automationManager.getConnexusDB().executeQuery(query);
        return patient.get("demog_ts").toString();
    }

    /*
     * Method to set the headers for API request
     *
     * Author: Keerthana Jayaraman(vn82865)
     * */
    public HashMap<String, String> getHeaders() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        return headers;
    }

    /*----------------------------------------------------------------------------------------------------------
        * This method fetches Non-38 product details  such as product name,qty etc from the database and return
        * the first row from the database
        *
        * Author: Sugapriya S(vn510of)
    ----------------------------------------------------------------------------------------------------------*/
    public Map<String, Object> getNonD38ProductDetailsFromDb() {
        String selectQuery1 = "select * from pharmacy_offering:pharmacy_item as pi " +
                "join pharmacy_offering:pharmacy_product as pp on pi.product_mds_fam_id = pp.product_mds_fam_id  where " +
                "pi.on_hand_qty > 500 and pi.dept_nbr != 38 limit 1";
        Map<String, Object> resultSet = automationManager.getConnexusDB().executeQuery(selectQuery1);
        return resultSet;
    }

    /*----------------------------------------------------------------------------------------------------------
         * The below method updates the state of the store to the provided Pre condition state.
         * Author: Tarun(vn510o1)
     ----------------------------------------------------------------------------------------------------------*/
    public void updateStoreState(String state) {
        String query = "update bus_unit_addr set state = \"" + state + "\" where bu_nbr =  \"" + prop.getProperty("cnx.store") + "\"";
        int presLoclastupdatedts = automationManager.getConnexusDB().executeUpdateQuery(query);
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * Method to update the store state to the given state
     * Author: John vinothkumar
     */
    public boolean readAndUpdateStoreState(String state) {
        String currentState = getCurrentStoreState();
        if (currentState != null && !currentState.equalsIgnoreCase(state)) {
            updateStoreState(state);
            Reporter.log("Store state has been set to " + state);
            return true;
        } else {
            Reporter.log("Store state is already set to " + currentState);
            return false;
        }
    }

    /**
     * ----------------------------------------------------------------------------------------------------------
     * Method to move an RX to Cancel queue from the given queue
     * Author: Srinivas(vn50jui)
     * ----------------------------------------------------------------------------------------------------------
     */
    public void clearDataInQueue(int workQueueCode) {
        String query = "update rx_order_detail set status_code = 20503 where next_work_que_code = " + workQueueCode + " ; ";
        automationManager.getConnexusDB().executeUpdateQuery(query);
    }

    /*----------------------------------------------------------------------------------------------------------
     * The below method fetches the issue agency code of Pre condition state.
     * Author: Tarun(vn510o1)
     ----------------------------------------------------------------------------------------------------------*/
    public String fetchIssueAgencyCodeOfState(String state) {
        String query = " select * from issuing_agency where state_prov_code = \""
                + state + "\"";
        Map<String, Object> stateCode = automationManager.getConnexusDB().executeQuery(query);
        return stateCode.get("issue_agency_code").toString();

    }

    /*----------------------------------------------------------------------------------------------------------
     * The below method fetches TP details for given Rx
     * Author: Tarun(vn510o1)
     ----------------------------------------------------------------------------------------------------------*/
    public String fetchTPFillDetails(String rxNbr, String getColumnValue, Boolean refill) {
        Log.info("Test nmbr ++ " + rxNbr);
        String query1 = "select rx_fill_id from rx_fill where rx_id =(select rx_id from rx where rx_nbr=\"" + rxNbr + "\")";
        if (refill) {
            query1 = query1 + "and rx_fill_seq_nbr = 2";
        }
        Map<String, Object> rxid = automationManager.getConnexusDB().executeQuery(query1);

        // Sanitize rx_fill_id to prevent SQL injection
        Object rxFillIdObj = rxid.get("rx_fill_id");
        String rxFillIdValue;
        if (rxFillIdObj instanceof Number) {
            rxFillIdValue = String.valueOf(((Number) rxFillIdObj).longValue());
        } else {
            try {
                rxFillIdValue = String.valueOf(Long.parseLong(rxFillIdObj.toString().trim()));
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid rx_fill_id value: " + rxFillIdObj, e);
            }
        }

        String query = "SELECT count(rx_fill_id) as rx_fill_id from clm_override_addtn WHERE addtn_class_code = 23232 and rx_fill_id=\"" + rxFillIdValue + "\"";
        Map<String, Object> stateCode = automationManager.getConnexusDB().executeQuery(query);
        return stateCode.get(getColumnValue).toString();
    }

    public String fetchAllergyCode(String patientId, String getColumnValue) {

        String query = "select * from patient_allergy where patient_id=\"" + patientId + "\"";
        Map<String, Object> result = automationManager.getConnexusDB().executeQuery(query);
        return result.get(getColumnValue).toString();
    }

    public String fetchDiseaseCode(String patientId, String getColumnValue) {

        String query = "select * from patient_disease where patient_id=\"" + patientId + "\"";
        Map<String, Object> result = automationManager.getConnexusDB().executeQuery(query);
        return result.get(getColumnValue).toString();
    }

    public String fetchTPFillDetailsWithValue(String rxNbr, String getColumnValue, Boolean refill) {
        Log.info("Test nmbr ++ " + rxNbr);
        String query1 = "select rx_fill_id from rx_fill where rx_id =(select rx_id from rx where rx_nbr=\"" + rxNbr + "\")";
        if (refill) {
            query1 = query1 + "and rx_fill_seq_nbr = 2";
        }
        Map<String, Object> rxid = automationManager.getConnexusDB().executeQuery(query1);
        
        // Sanitize rx_fill_id to prevent SQL injection
        Object rxFillIdObj = rxid.get("rx_fill_id");
        String rxFillIdValue;
        if (rxFillIdObj instanceof Number) {
            rxFillIdValue = String.valueOf(((Number) rxFillIdObj).longValue());
        } else {
            try {
                rxFillIdValue = String.valueOf(Long.parseLong(rxFillIdObj.toString().trim()));
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid rx_fill_id value: " + rxFillIdObj, e);
            }
        }
        
        String query = "SELECT * from clm_override_addtn WHERE addtn_class_code = 23232 and rx_fill_id=\"" + rxFillIdValue + "\"";
        Log.info("supply fill id " + "" + rxFillIdValue);
        Map<String, Object> stateCode = automationManager.getConnexusDB().executeQuery(query);
        if (stateCode != null) {
            Log.info("supply" + " " + stateCode.get(getColumnValue).toString());
            return stateCode.get(getColumnValue).toString();
        } else {
            return "";
        }
    }


    public String fetchMaxDose(String rxNbr, String getColumnValue) {
        Log.info("Test rx_nbr ++ " + rxNbr);
        String query1 = "select rx_id from rx where rx_nbr=\"" + rxNbr + "\"";

        Map<String, Object> rxid = automationManager.getConnexusDB().executeQuery(query1);
        
        // Sanitize rx_id to prevent SQL injection
        Object rxIdObj = rxid.get("rx_id");
        String rxIdValue;
        if (rxIdObj instanceof Number) {
            rxIdValue = String.valueOf(((Number) rxIdObj).longValue());
        } else {
            try {
                rxIdValue = String.valueOf(Long.parseLong(rxIdObj.toString().trim()));
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid rx_id value: " + rxIdObj, e);
            }
        }
        
        Log.info("rxid" + " " + rxIdValue);
        String query = "select * from comment_line where comment_id =(select comment_id from comment where comment_subj_code=32742 and comment_id " +
                "in (select comment_id from rx_comment where rx_id =\"" + rxIdValue + "\"))";
        Map<String, Object> maxDose = automationManager.getConnexusDB().executeQuery(query);
        Log.info("maxDose" + "" + maxDose.get(getColumnValue).toString());
        return maxDose.get(getColumnValue).toString();

    }

    /*----------------------------------------------------------------------------------------------------------
     * The below method updates the issue_agency_code with respective code of the state provided and sets the restrict type code to 'M' ,Dxcode control flag code.
     * Author: Tarun(vn510o1)
     ----------------------------------------------------------------------------------------------------------*/
    public void updateDxCodeFlagRestriction(String issueAgencyCode) {
        String query = "update agcy_cls_rqmt_parm set restrict_type_val='M' where restrict_type_code = 15094 and issue_agency_code=  \"" + issueAgencyCode + "\"";
        int presLoclastupdatedts = automationManager.getConnexusDB().executeUpdateQuery(query);
    }

    public void updateAgencyRequirementParmTable(String restrictTypeValue, String restrictTypeCode, String issueAgencyCode) {
        String query = "update agency_rqmt_parm set restrict_type_val=\"" + restrictTypeValue + "\" where restrict_type_code=\"" + restrictTypeCode + "\"  and issue_agency_code= \"" + issueAgencyCode + "\"";
        int presLoclastupdatedts = automationManager.getConnexusDB().executeUpdateQuery(query);
        Reporter.log("Agency_rqmt_parm for restrict_type_val is set to " + restrictTypeValue + " where restrict_type_code is " + restrictTypeCode + " and issue_agency_code is " + issueAgencyCode);
        Reporter.log("Flag Code \t\t:" + restrictTypeCode + " And It's Value \t\t:" + restrictTypeValue + " And It's Agency Code \t\t:" + issueAgencyCode);
    }

    public void selectAgencyClassParmTable(String restrictTypeValue, String restrictTypeCode, String drugControlCode, String issueAgencyCode) {
        String query = "select * from agcy_cls_rqmt_parm where restrict_type_cod=\"" + restrictTypeCode + "\" and issue_agency_code= \"" + issueAgencyCode + "\"";
        Map<String, Object> result = automationManager.getConnexusDB().executeQuery(query);
        Reporter.log("Agency_rqmt_parm for restrict_type_code is " + restrictTypeCode + " and issue_agency_code is " + issueAgencyCode);
        // Update if value is different
        boolean needsUpdate = result != null && result.containsKey("restrict_type_val")
                && !result.get("restrict_type_val").toString().trim().equalsIgnoreCase(restrictTypeValue);

        if (needsUpdate) {
            String updateQuery = "update agcy_cls_rqmt_parm set restrict_type_val=\"" + restrictTypeValue
                    + "\" where restrict_type_code=\"" + restrictTypeCode + "\" and drug_control_code=\"" + drugControlCode + "\"";

            int rowsAffected = automationManager.getConnexusDB().executeUpdateQuery(updateQuery);
            if (rowsAffected <= 0) {
                String errorMsg = String.format(
                        "Failed to update agency_cls_rqmt_parm table for restrict_type_code=%s, drug_control_code=%s",
                        restrictTypeCode, drugControlCode);
                Reporter.log("ERROR: " + errorMsg);
                throw new RuntimeException(errorMsg);
            }
            Reporter.log("Flag Code: " + restrictTypeCode + " | Updated Value to: " + restrictTypeValue);
        } else {
            Reporter.log("Flag Code: " + restrictTypeCode + " | Already set to: " + restrictTypeValue);
        }
    }

    public boolean updateAgencyClassParmTable(String restrictTypeValue, String restrictTypeCode, String issueAgencyCode) {
        String query = "update agcy_cls_rqmt_parm  set restrict_type_val=\"" + restrictTypeValue + "\" where restrict_type_code=\"" + restrictTypeCode + "\"  and issue_agency_code= \"" + issueAgencyCode + "\"";
        int rowsAffected = automationManager.getConnexusDB().executeUpdateQuery(query);
        Reporter.log("Agency_cls_parm for restrict_type_val is set to " + restrictTypeValue + " where restrict_type_code is " + restrictTypeCode + " and issue_agency_code is " + issueAgencyCode);
        Reporter.log("Flag Code \t\t:" + restrictTypeCode + " And It's Value \t\t:" + restrictTypeValue + " And It's Agency Code \t\t:" + issueAgencyCode);
        return rowsAffected > 0;

    }

    /**
     * Updates agency requirement parameter table and fetches pharmacy code description
     * @return true if update was successful, false otherwise
     */
    public boolean updateAgencyRequirementParmTbl(String restrictTypeValue, String restrictTypeCode, String issueAgencyCode) {
        try {
            // Check current value
            String selectQuery = "select restrict_type_val from agency_rqmt_parm where restrict_type_code=\""
                    + restrictTypeCode + "\" and issue_agency_code=\"" + issueAgencyCode + "\"";
            Map<String, Object> result = automationManager.getConnexusDB().executeQuery(selectQuery);

            // Update if value is different
            boolean needsUpdate = result != null && result.containsKey("restrict_type_val")
                    && !result.get("restrict_type_val").toString().trim().equalsIgnoreCase(restrictTypeValue);

            if (needsUpdate) {
                String updateQuery = "update agency_rqmt_parm set restrict_type_val=\"" + restrictTypeValue
                        + "\" where restrict_type_code=\"" + restrictTypeCode + "\" and issue_agency_code=\"" + issueAgencyCode + "\"";

                int rowsAffected = automationManager.getConnexusDB().executeUpdateQuery(updateQuery);
                if (rowsAffected <= 0) {
                    String errorMsg = String.format(
                            "Failed to update agency_rqmt_parm table for restrict_type_code=%s, issue_agency_code=%s",
                            restrictTypeCode, issueAgencyCode);
                    Reporter.log("ERROR: " + errorMsg);
                    throw new RuntimeException(errorMsg);
                }
                Reporter.log("Flag Code: " + restrictTypeCode + " | Updated Value to: " + restrictTypeValue);
            } else {
                Reporter.log("Flag Code: " + restrictTypeCode + " | Already set to: " + restrictTypeValue);
            }
            // Log pharmacy code description
            String pharmacyQuery = "select code_desc from pharmacy_code_txt where code_id=\"" + restrictTypeCode + "\"";
            List<Map<String, Object>> pharmacyResult = automationManager.getConnexusDB().executeQueryForList(pharmacyQuery);
            if (pharmacyResult != null && !pharmacyResult.isEmpty()) {
                Reporter.log("Flag Code: " + restrictTypeCode + " | Description: " + pharmacyResult.get(0).get("code_desc"));
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            String errorMsg = "Exception in updateAgencyRequirementParmTbl: " + e.getMessage();
            Reporter.log("ERROR: " + errorMsg);
            throw new RuntimeException(errorMsg, e);
        }
    }

    /*
     * Method to get the Current Store state
     *
     * Author: Preetha(vn50myr)
     * */
    public String getCurrentStoreState() {
        String query = "select state from bus_unit_addr where bu_nbr =  \"" + prop.getProperty("cnx.store") + "\"";
        Map<String, Object> Stateinfo = automationManager.getConnexusDB().executeQuery(query);
        if (Stateinfo != null) {
            String state = Stateinfo.get("state").toString();
            return state;
        }
        return null;
    }

    /*
     * Method to get Check current state and Update Store state
     *
     * Author: Preetha(vn50myr)
     * */
    public void checkCurrentStateAndupdateStoreState(String state) {
        String previousState = getCurrentStoreState();
        if (!previousState.equalsIgnoreCase(state)) {
            String query = "update bus_unit_addr set state = \"" + state + "\" where bu_nbr =  \"" + prop.getProperty("cnx.store") + "\"";
            int presLoclastupdatedts = automationManager.getConnexusDB().executeUpdateQuery(query);
        }
        Reporter.log("Store state has been set to " + state);
    }

    /*----------------------------------------------------------------------------------------------------------
  * The below method modifies the date to the past value from teh current date
  * Author: Tarun(vn510o1)
  ----------------------------------------------------------------------------------------------------------*/
    public String modifyDateToPast(String dateFormat, int days) {
        simpleDateFormat = new SimpleDateFormat(dateFormat);
        cal.setTime(date);
        cal.add(Calendar.DATE, -days);
        Date newdate = cal.getTime();
        String modifieddate = simpleDateFormat.format(newdate);
        return modifieddate;
    }

    /*----------------------------------------------------------------------------------------------------------
  * The below method provides the future date value from the Date which is provided and returns the updated future date
  * Author: Tarun(vn510o1)
  ----------------------------------------------------------------------------------------------------------*/
    public String getFutureDateFromProvidedDate(String date, String dateFormat, int numberOfDays) {
        try {
            simpleDateFormat = new SimpleDateFormat(dateFormat);
            Date date1 = new SimpleDateFormat(dateFormat).parse(date);
            cal.setTime(date1);
            cal.add(Calendar.DATE, numberOfDays);
            Date newDate = cal.getTime();
            String modifieddate = simpleDateFormat.format(newDate);
            return modifieddate;
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method updates the restrict type value to 'Y' for restrict type code 15179 which is of TM code field from agency_rqmt_parm set table of particular state
   * according to the input of issue agency code of the state.
   * Author: Tarun(vn510o1)
   ----------------------------------------------------------------------------------------------------------*/
    public void updateTmCodeFlagRestriction(String issueAgencyCode) {
        String query = "update agency_rqmt_parm set restrict_type_val='Y' where restrict_type_code = 15179 and issue_agency_code=  \"" + issueAgencyCode + "\"";
        int presLoclastupdatedts = automationManager.getConnexusDB().executeUpdateQuery(query);
    }

    public String random12DigitNumber() {
        long min = 100000000000L;
        long max = 1000000000000L;
        Random random = new Random();
        long num = min + ((long) (random.nextDouble() * (max - min)));
        String value = String.valueOf(num);
        return value;
    }

    /*----------------------------------------------------------------------------------------------------------
   * The below method creates a new notepad file and writes 'NO' and looks for any operation completion; post
   * which the file is saved and deleted
   *
   * Author: Tarun(vn510o1)
   ----------------------------------------------------------------------------------------------------------*/
    public void restartServices() {
        try {
            services = new File("services.txt");
            services.createNewFile();
            fileWriter = new FileWriter(services);
            fileWriter.write("Yes");
            fileWriter.close();
            desktop = Desktop.getDesktop();
            desktop.open(services);
            while (true) {
                String value = Objects.requireNonNull(FileUtils.readLineFromFile(services, 0));
                if ("Yes".equalsIgnoreCase(value)) {
                    Runtime.getRuntime().exec("taskkill /F /IM notepad.exe");
                    services.delete();
                    break;
                } else {
                    continue;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*----------------------------------------------------------------------------------------------------------
     * This method gets the opioid drug ndc number from db. The query is taken for drug having quantity above 100
     * in inventory store so that the drug is processed without out of stock
     *
     * input: drug_control_code: 2300 for c2, 2301 for c3, 2302 for c4 ,2303 for c5 drug
     * returns: drug ndc number
     *
     * Author: Lakshmi Priya(vn510nm)
     ----------------------------------------------------------------------------------------------------------*/
    public String getOpioidControlledDrugNames(String deaClass) {
        //The below query retrieves any class (C2/C3/C4/C5) of Controlled drug having opioid (14150) as product restrict type from inventory with drug quantity more than 100 nos
        Map<String, Object> drugDetailsFromDb = automationManager.getConnexusDB().executeQuery("select pi.ndc_nbr,pp.short_name,pp.product_name,pp.drug_control_code,dc.drug_control_abbr, on_hand_qty \n" +
                "from pharmacy_offering:genc_prod_restrict gen, pharmacy_offering:product_gpi_xref xref, pharmacy_offering:pharmacy_product   pp,  \n" +
                "pharmacy_offering:pharmacy_item pi, pharmacy_offering: drug_control_text dc   \n" +
                "where gen.restrict_type_code in (14150) and gen.restriction_value='Y' \n" +
                "and pi.product_mds_fam_id = pp.product_mds_fam_id and pi.product_mds_fam_id = xref.product_mds_fam_id \n" +
                "and xref.gpi_code=gen.gpi_code and pp.drug_control_code=" + deaClass + " and pp.drug_control_code = dc.drug_control_code\n" +
                "and on_hand_qty>100 limit 1");
        String drugNdcNumber = drugDetailsFromDb.get("ndc_nbr").toString().trim();
        String drugClass = drugDetailsFromDb.get("drug_control_abbr").toString().trim();
        String drugName = drugDetailsFromDb.get("product_name").toString().trim();
        //Reporter.log("C" + drugClass + " Controlled Opioid Drug: " + drugName + " is processed for patient");
        return drugNdcNumber;
    }

    /*----------------------------------------------------------------------------------------------------------
  * Below method retrieves the fill type code of the active fill Id's for an order.
  *
  * Author: Aayushi(a0s0fqj)
  ----------------------------------------------------------------------------------------------------------*/
    public String getFillTypeCodeFromDB(String rxNbr, String getColumnValue) {
        try {
            String selectQuery =
                    "SELECT fill_type_code FROM rx_fill WHERE rx_id IN\n" +
                            "(SELECT rx_id FROM rx WHERE rx_nbr = \"" + rxNbr + "\") and status_code = 20401 \n" +
                            "GROUP BY fill_type_code ORDER BY fill_type_code desc;";
            Map<String, Object> resultSet;
            resultSet = automationManager.getConnexusDB().executeQuery(selectQuery);
            if (resultSet != null) {
                return resultSet.get(getColumnValue).toString().trim();
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }

    /*----------------------------------------------------------------------------------------------------------
     * The below method fetches the issue agency code of Pre condition state.
     * Author: Tarun(vn510o1)
     ----------------------------------------------------------------------------------------------------------*/
    public String verifyPrescriberDetails(String lastName, String firstName) {
        String query = " select * from prescriber where last_name = \"" + lastName + "\" and first_name = \"" + firstName + "\"";
        Map<String, Object> stateCode = automationManager.getConnexusDB().executeQuery(query);
        String query1 = "select * from prescriber_license where prescriber_id= \"" + stateCode.get("prescriber_id").toString() + "\"";
        Map<String, Object> stateCode2 = automationManager.getConnexusDB().executeQuery(query1);
        Log.info("Licence from DB:" + stateCode2.get("license_nbr").toString());
        return stateCode2.get("license_nbr").toString();
    }

    /*----------------------------------------------------------------------------------------------------------
     * The below method fetches the query to check the record count in subject_comm for the given patient Id
     * Author: Ilangeeran(i0k00hp)
     ----------------------------------------------------------------------------------------------------------*/
    public String getContactInfoQuery(String patientId) {
        return "select count(1) as RecordCount from subject_comm where comm_seq_nbr=1 and subject_id=" + patientId;
    }

    /*----------------------------------------------------------------------------------------------------------
     * The below method fetches the query to update seq number in subject_comm for the given patient Id
     * Author: Ilangeeran(i0k00hp)
     ----------------------------------------------------------------------------------------------------------*/
    public String getUpdateSeqNbrQuery(String patientId) {
        return "update subject_comm set comm_seq_nbr=0 where subject_id=" + patientId + " and comm_seq_nbr=1";
    }

    /*----------------------------------------------------------------------------------------------------------
     * The below method fetches the query to get timestamp in patient for the given patient Id
     * Author: Ilangeeran(i0k00hp)
     ----------------------------------------------------------------------------------------------------------*/
    public String getTimeStampQuery(String patientId) {
        return "select last_change_ts as CurrentTimeStamp from patient where patient_id=" + patientId;
    }

    /*----------------------------------------------------------------------------------------------------------
     * The below method fetches the query to update the primary messaging contact in subject_comm for the given patient Id
     * Author: Ilangeeran(i0k00hp)
     ----------------------------------------------------------------------------------------------------------*/
    public String getUpdatePrimaryContactMessagingQuery(String timestamp, String patientId) {
        return "update subject_comm set comm_seq_nbr=21, last_change_ts='" + timestamp + "' where subject_id=" + patientId + " and comm_seq_nbr=1";
    }

    public void addRandomNamesInFileWithFullName() {
        fileWithFullName = FileUtils.createTempFile("temp.txt", StringUtils.uniqueFirstName() + "," + StringUtils.uniqueLastName() + " " + StringUtils.uniqueMiddleName());
    }

    public String[] readPatientNameFromFileWithFullName() {
        return Objects.requireNonNull(FileUtils.readLineFromFile(fileWithFullName, 0)).split(",| ");
    }

    public String random6DigitNumber() {
        long min = 100000L;
        long max = 1000000L;
        Random random = new Random();
        long num = min + ((long) (random.nextDouble() * (max - min)));
        String value = String.valueOf(num);
        return value;
    }

    public boolean updateFlagValueBasedOnCode(String flagCode, String flagValue) {
        String updateQuery = "update bu_phm_parm set phm_parm_value =\"" + flagValue + "\" where phm_bu_id=\"" + prop.getProperty("cnx.store") + "\" and phm_parm_code=\"" + flagCode + "\"";
        try {
            String resultSet = Integer.toString(automationManager.getConnexusDB().executeUpdateQuery(updateQuery));
            if (resultSet != null) {
                return true;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateFlagValueBasedOnCodebyStore(String flagCode, String flagValue, int storeId) {
        String updateQuery = "update bu_phm_parm set phm_parm_value =\"" + flagValue + "\" where phm_bu_id=\"" + storeId + "\" and phm_parm_code=\"" + flagCode + "\"";
        try {
            String resultSet = Integer.toString(automationManager.getConnexusDB(storeId).executeUpdateQuery(updateQuery));
            if (resultSet != null) {
                return true;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return false;
    }

    public String selectAgencyRequirementParmTable(String restrictTypeCode, String issueAgencyCode) {
        String querystatecode = "select * from informix.issuing_agency where state_prov_code = \"" + issueAgencyCode + "\"";
        Map<String, Object> result = automationManager.getConnexusDB().executeQuery(querystatecode);
        String code = result.get("issue_agency_code").toString();
        String query = "select * from agcy_cls_rqmt_parm where restrict_type_code=\"" + restrictTypeCode + "\"  and issue_agency_code= \"" + code + "\"";
        List<Map<String, Object>> resultSet = automationManager.getConnexusDB().executeQueryForList(query);
        return resultSet.get(0).get("restrict_type_val").toString();
    }

    public String selectAgencyRequirementParm(String restrictTypeCode, String issueAgencyCode) {
        String querystatecode = "select * from informix.issuing_agency where state_prov_code = \"" + issueAgencyCode + "\"";
        Map<String, Object> result = automationManager.getConnexusDB().executeQuery(querystatecode);
        String code = result.get("issue_agency_code").toString();
        String query = "select * from agcy_cls_rqmt_parm where restrict_type_code=\"" + restrictTypeCode + "\"  and issue_agency_code= \"" + code + "\"";
        List<Map<String, Object>> resultSet = automationManager.getConnexusDB().executeQueryForList(query);
        Reporter.log("Query 1: " + querystatecode);
        Reporter.log("Query 2: " + query);
        if (resultSet == null || resultSet.isEmpty()) {
            Reporter.log("Values are null as expected.");
            return null;
        }
        String restrictTypeVal = resultSet.get(0).get("restrict_type_val").toString();
        Reporter.log("Unexpected Data Found: " + restrictTypeVal);
        return restrictTypeVal;
    }


    public void updateAgencyRequirementParmTableForDestinationStore(String restrictTypeValue, String restrictTypeCode, String issueAgencyCode, int storeNum) {
        String query = "update agency_rqmt_parm set restrict_type_val=\"" + restrictTypeValue + "\" where restrict_type_code=\"" + restrictTypeCode + "\"  and issue_agency_code= \"" + issueAgencyCode + "\"";
        int presLoclastupdatedts = automationManager.getConnexusDB(storeNum).executeUpdateQuery(query);
    }

    public void verifyAgencyRequirementsRestrictTypeValue(String restrictTypeCode, String value) {
        String query = "select * from agcy_cls_rqmt_parm where restrict_type_code = " + restrictTypeCode;
        List<Map<String, Object>> resultSet = automationManager.getConnexusDB().executeQueryForList(query);
        Reporter.log("Result for " + query + "is " + resultSet.get(0).get("restrict_type_val").toString());
        Assert.assertNotEquals(resultSet.get(0).get("restrict_type_val").toString(), value);
        resultSet.get(0).get("restrict_type_val").toString();
    }

    public void startAppiumServer() {
        try {
            automationManager.performSleep(5); // Short wait before starting when multiple classes in same XML
            // Check if Appium is already running
            if (isAppiumServerRunning()) {
                Log.info("Appium server is already running on port 4723");
                return;
            }

            //killAppiumByPort(); // alternate to kill existing Appium first always

            // Start fresh server
            Log.info("Starting fresh Appium server...");
            Runtime.getRuntime().exec("cmd.exe /c start cmd.exe /k \"appium\"");

            // Wait for server to start
            waitForAppiumServerToStart();
            Log.info("Appium server started successfully");
        } catch (Exception e) {
            Log.info("Failed to start Appium server: " + e.getMessage());
            throw new RuntimeException("Failed to start Appium server", e);
        }
    }

    /**
     * Kill Appium by finding process using port 4723 - more reliable than window title
     */
    private void killAppiumByPort() {
        try {
            // Find process using port 4723
            ProcessBuilder netstatBuilder = new ProcessBuilder("netstat", "-ano");
            Process netstatProcess = netstatBuilder.start();

            try (java.io.BufferedReader reader = new java.io.BufferedReader(
                    new java.io.InputStreamReader(netstatProcess.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.contains(":4723") && line.contains("LISTENING")) {
                        // Extract PID (last column)
                        String[] parts = line.trim().split("\\s+");
                        if (parts.length > 0) {
                            String pid = parts[parts.length - 1];
                            Log.info("Found Appium process with PID: " + pid);

                            // Kill the specific PID
                            new ProcessBuilder("TASKKILL", "/F", "/PID", pid)
                                    .start()
                                    .waitFor(5, java.util.concurrent.TimeUnit.SECONDS);

                            Log.info("Killed Appium process PID: " + pid);
                            break;
                        }
                    }
                }
            } // BufferedReader automatically closed here
            netstatProcess.waitFor();
        } catch (Exception e) {
            Log.info("Warning: Failed to kill Appium by port: " + e.getMessage());
            // Fallback: kill all node.exe (less safe but effective)
            try {
                Process fallbackProcess = new ProcessBuilder("TASKKILL", "/F", "/IM", "node.exe").start();
                boolean fallbackCompleted = fallbackProcess.waitFor(5, java.util.concurrent.TimeUnit.SECONDS);

                if (fallbackCompleted) {
                    int exitCode = fallbackProcess.exitValue();
                    if (exitCode == 0) {
                        Log.info("Fallback: Successfully killed all node.exe processes");
                    } else {
                        Log.info("Fallback: TASKKILL completed with exit code: " + exitCode);
                    }
                } else {
                    Log.info("Warning: Fallback kill command timed out after 5 seconds");
                    // Force destroy the hanging process to prevent resource leaks
                    fallbackProcess.destroyForcibly();
                }
            } catch (Exception fallbackException) {
                Log.info("Fallback kill failed with exception: " + fallbackException.getMessage());
            }
        }
    }

    private void waitForAppiumServerToStart() {
        int maxWaitTime = 60; // Maximum wait time in seconds
        int checkInterval = 2; // Check every 2 seconds
        int elapsedTime = 0;
        Log.info("Waiting for Appium server to start...");

        while (elapsedTime < maxWaitTime) {
            try {
                Thread.sleep(checkInterval * 1000); // Convert to milliseconds
                elapsedTime += checkInterval;

                if (isAppiumServerRunning() && isWindowsDriverCapabilityReady()) {
                    Log.info("Appium server started successfully after " + elapsedTime + " seconds");
                    return;
                }

                Log.info("Checking Appium server status... (" + elapsedTime + "s elapsed)");

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException("Thread interrupted while waiting for Appium server", e);
            }
        }

        // If we reach here, server didn't start within the timeout
        throw new RuntimeException("Appium server failed to start within " + maxWaitTime + " seconds");
    }

    private boolean isAppiumServerRunning() {
        try {
            java.net.Socket socket = new java.net.Socket();
            socket.connect(new java.net.InetSocketAddress("localhost", 4723), 5000);
            socket.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * Tests if Appium server can create Windows driver sessions by attempting a minimal Root session
     * This ensures the server is fully ready for Windows automation, not just HTTP requests
     */
    private boolean isWindowsDriverCapabilityReady() {
        int maxRetries = 5; // Increased from 3 to 5 for slower environments
        int retryDelay = 3000; // Increased from 2 to 3 seconds between retries

        for (int i = 0; i < maxRetries; i++) {
            io.appium.java_client.windows.WindowsDriver testDriver = null;
            try {
                Log.info("Testing Windows driver capability... (attempt " + (i + 1) + "/" + maxRetries + ")");

                org.openqa.selenium.remote.DesiredCapabilities testCapabilities = new org.openqa.selenium.remote.DesiredCapabilities();
                testCapabilities.setCapability("app", "Root");
                testCapabilities.setCapability("ms:waitForAppLaunch", "10"); // Increased timeout
                testCapabilities.setCapability("ms:uiAutomation", true); // Enable UI Automation
                testCapabilities.setCapability("newCommandTimeout", "60"); // Add command timeout

                // Create a minimal test session with timeout
                testDriver = new io.appium.java_client.windows.WindowsDriver(
                        new java.net.URL(prop.getProperty("app.winAppServer")), testCapabilities);

                // Additional validation: try to perform a basic operation
                String sessionId = testDriver.getSessionId().toString();
                if (sessionId != null && !sessionId.isEmpty()) {
                    // Test basic functionality by getting window handles
                    testDriver.getWindowHandles();
                    Log.info("Windows driver capability confirmed - Session ID: " + sessionId);
                    return true;
                }

            } catch (org.openqa.selenium.SessionNotCreatedException e) {
                Log.info("Windows driver test attempt " + (i + 1) + " failed - Session creation error: " + e.getMessage());
                // This usually means WinAppDriver is not ready yet
            } catch (org.openqa.selenium.WebDriverException e) {
                Log.info("Windows driver test attempt " + (i + 1) + " failed - WebDriver error: " + e.getMessage());
                // This could be connection issues or driver not ready
            } catch (Exception e) {
                Log.info("Windows driver test attempt " + (i + 1) + " failed: " + e.getMessage());
            } finally {
                // Always clean up the test session
                if (testDriver != null) {
                    try {
                        testDriver.quit();
                    } catch (Exception cleanupEx) {
                        // Ignore cleanup errors but log them
                        Log.info("Test driver cleanup warning: " + cleanupEx.getMessage());
                    }
                }
            }

            // Wait before retry with exponential backoff for later attempts
            if (i < maxRetries - 1) {
                int currentDelay = retryDelay + (i * 1000); // Add 1 second for each retry
                Log.info("Waiting " + (currentDelay/1000) + " seconds before next attempt...");
                try {
                    Thread.sleep(currentDelay);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    Log.info("Windows driver readiness check interrupted");
                    return false;
                }
            }
        }

        Log.info("Windows driver capability not ready after " + maxRetries + " attempts");
        return false;
    }

    public void stopAppiumServer() {
        Runtime runtime = Runtime.getRuntime();
        try {
            Runtime.getRuntime().exec("TASKKILL /F /IM node.exe");
            Runtime.getRuntime().exec("TASKKILL /F /IM cmd.exe");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void killtheAppiumAndConnexusAndStartAppium() {
        Runtime runtime = Runtime.getRuntime();
        try {
            Runtime.getRuntime().exec("TASKKILL /F /IM node.exe");
            Runtime.getRuntime().exec("TASKKILL /F /IM cmd.exe");
            Runtime.getRuntime().exec("TASKKILL /F /IM connexus.exe");
            runtime.exec("cmd.exe /c start cmd.exe /k \"appium");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void updateAgencyClsRequirementParmTable(String restrictTypeValue, String restrictTypeCode, String drugControlCode, String issueAgencyCode) {
        String query = "update agcy_cls_rqmt_parm set restrict_type_val=\"" + restrictTypeValue + "\" where restrict_type_code=\"" + restrictTypeCode +
                "\"  and drug_control_code= \"" + drugControlCode + "\" and issue_agency_code= \"" + issueAgencyCode + "\"";
        int presLoclastupdatedts = automationManager.getConnexusDB().executeUpdateQuery(query);
        Log.info("presLoclastupdatedts:" + presLoclastupdatedts);
        Reporter.log("updateAgencyClsRequirementParmTable query " + query);
    }

    public String getPatientFN(int storeNumber, int patientId) {
        String query = "select * from informix.patient where patient_id = " + patientId + ";";
        Map<String, Object> patientDetails = automationManager.getConnexusDB(storeNumber).executeQuery(query);
        Object firstName = patientDetails.get("first_name");
        return (String) firstName;
    }

    public String getPatientLN(int storeNumber, int patientId) {
        String query = "select  * from informix.patient where patient_id = " + patientId + ";";
        Map<String, Object> patientDetails = automationManager.getConnexusDB(storeNumber).executeQuery(query);
        Object lastName = patientDetails.get("last_name");
        return (String) lastName;
    }

    public int getRxId(int storeNumber, String rxNbr) {
        String query = "select * from rx where rx_nbr =\"" + rxNbr + "\"";
        Map<String, Object> rxDbDetails = automationManager.getConnexusDB(storeNumber).executeQuery(query);
        Object rxIdObj = rxDbDetails.get("rx_id");
        int rxId;
        if (rxIdObj == null) {
            Log.info("rxIdObj is null, returning 0");
            return 0;
        }
        try {
            if (rxIdObj instanceof Integer) {
                rxId = (Integer) rxIdObj;
            } else if (rxIdObj instanceof Number) {
                rxId = ((Number) rxIdObj).intValue();
            } else {
                Log.info("unexpected type for orderSeqNbr:" + rxIdObj.getClass().getName());
                return 0;
            }
        } catch (ClassCastException e) {
            Log.info("ClassCastException:" + e.getMessage());
            return 0;
        }
        return rxId;
    }

    public int getRxFillIdTableInfo(int storeNumber, String rxNbr) {
        String query = "select * from rx where rx_nbr =\"" + rxNbr + "\"";
        Map<String, Object> rxDbDetails = automationManager.getConnexusDB(storeNumber).executeQuery(query);
        Object rxId = rxDbDetails.get("rx_id");

        // Sanitize rxId to prevent SQL injection
        if (rxId == null) {
            throw new IllegalArgumentException("rx_id not found for rxNbr: " + rxNbr);
        }

        // Convert to numeric value to ensure it's safe
        long rxIdValue;
        if (rxId instanceof Number) {
            rxIdValue = ((Number) rxId).longValue();
        } else {
            try {
                rxIdValue = Long.parseLong(rxId.toString().trim());
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid rx_id value: " + rxId, e);
            }
        }

        // get order details - now using sanitized numeric value
        String query1 = "select * from rx_order_detail where rx_id=" + rxIdValue + ";";
        rxDbDetails = automationManager.getConnexusDB(storeNumber).executeQuery(query1);
        Object rxFillIdObj = rxDbDetails.get("rx_fill_id");
        int rxFillId = 0;
        if (rxFillIdObj instanceof Integer) {
            rxFillId = (Integer) rxFillIdObj;
        } else if (rxFillIdObj instanceof Number) {
            rxFillId = ((Number) rxFillIdObj).intValue();
        }
        return rxFillId;
    }

    public int verifyEntryInAuditActivityTable(int rxFillId) {
        IDatabaseContext cnx = automationManager.getConnexusDB(Integer.parseInt(prop.getProperty("cnx.store")));
        String query = "select * from error_and_audit:appl_activity where task_id= 134 and error_id = 1006 and activity_value=" + rxFillId;
        DataTable agencyClassDetails = cnx.getDataTable(query);
        int value = agencyClassDetails.getRowCount();
        if (value > 0) {
            Reporter.log("Expected Entry found in DB for rxFillId:" + rxFillId + " " + "Row count: " + value);
            return value;
        } else {
            Reporter.log("No entry found in DB for rxFillId:" + rxFillId);
            return 0;
        }
    }

    public int getRxFillId(int storeNumber, String rxNbr) {
        String query = "select * from rx where rx_nbr =\"" + rxNbr + "\"";
        Map<String, Object> rxDbDetails = automationManager.getConnexusDB(storeNumber).executeQuery(query);
        Object rxId = rxDbDetails.get("rx_id");

        // Sanitize rxId to prevent SQL injection
        if (rxId == null) {
            Log.info("rx_id is null for rxNbr: " + rxNbr);
            return 0;
        }

        long rxIdValue;
        if (rxId instanceof Number) {
            rxIdValue = ((Number) rxId).longValue();
        } else {
            try {
                rxIdValue = Long.parseLong(rxId.toString().trim());
            } catch (NumberFormatException e) {
                Log.info("Invalid rx_id value: " + rxId);
                return 0;
            }
        }

        // get order details - now using sanitized numeric value
        String query1 = "select * from rx_order_detail where rx_id=" + rxIdValue + ";";
        rxDbDetails = automationManager.getConnexusDB(storeNumber).executeQuery(query1);
        Object rxFillIdObj = rxDbDetails.get("rx_fill_id");
        int rxFillId;
        if (rxFillIdObj == null) {
            Log.info("orderSeqNbrObj is null, returning 0");
            return 0;
        }
        try {
            if (rxFillIdObj instanceof Integer) {
                rxFillId = (Integer) rxFillIdObj;
            } else if (rxFillIdObj instanceof Number) {
                rxFillId = ((Number) rxFillIdObj).intValue();
            } else {
                Log.info("unexpected type for rxFillId:" + rxFillIdObj.getClass().getName());
                return 0;
            }
        } catch (ClassCastException e) {
            Log.info("ClassCastException:" + e.getMessage());
            return 0;
        }
        return rxFillId;
    }

    public boolean verifyNoEntryInAuditActivityTable(int rxFillId) {
        IDatabaseContext cnx = automationManager.getConnexusDB(Integer.parseInt(prop.getProperty("cnx.store")));
        String query = "select * from error_and_audit:appl_activity where task_id= 134 and error_id = 1006 and activity_value=" + rxFillId;
        DataTable agencyClassDetails = cnx.getDataTable(query);
        int rowCount = agencyClassDetails.getRowCount();
        Reporter.log("Expected no entry found in audit table in DB for rxFillId:" + rxFillId);
        return rowCount == 0;
    }

    public int getRxOrderIdFromTable(int storeNumber, String rxNbr) {
        automationManager = AutomationManager.getInstance();
        String query1="select rxd.order_id from rx rx,rx_order_detail rxd "+
                " where rx.rx_nbr = "+rxNbr+  "  and rx.rx_id=rxd.rx_id;";
        Map<String, Object> rxDbDetails = automationManager.getConnexusDB(storeNumber).executeQuery(query1);
        Object orderIdObj = rxDbDetails.get("order_id");
        int orderId = 0;
        if (orderIdObj instanceof Integer) {
            orderId = (Integer) orderIdObj;
        } else if (orderIdObj instanceof Number) {
            orderId = ((Number) orderIdObj).intValue();
        }
        return orderId;
    }

    public int getorderSeqNbr(int storeNumber, String rxNbr) {
        String query = "select * from rx where rx_nbr =\"" + rxNbr + "\"";
        Map<String, Object> rxDbDetails = automationManager.getConnexusDB(storeNumber).executeQuery(query);
        Object rxId = rxDbDetails.get("rx_id");

        // Sanitize rxId to prevent SQL injection
        if (rxId == null) {
            Log.info("rx_id is null for rxNbr: " + rxNbr);
            return 0;
        }

        long rxIdValue;
        if (rxId instanceof Number) {
            rxIdValue = ((Number) rxId).longValue();
        } else {
            try {
                rxIdValue = Long.parseLong(rxId.toString().trim());
            } catch (NumberFormatException e) {
                Log.info("Invalid rx_id value: " + rxId);
                return 0;
            }
        }

        // get order details - now using sanitized numeric value
        String query1 = "select * from rx_order_detail where rx_id=" + rxIdValue + ";";
        rxDbDetails = automationManager.getConnexusDB(storeNumber).executeQuery(query1);
        Object orderSeqNbrObj = rxDbDetails.get("order_seq_nbr");
        int orderSeqNbr;
        if (orderSeqNbrObj == null) {
            Log.info("orderSeqNbrObj is null, returning 0");
            return 0;
        }
        try {
            if (orderSeqNbrObj instanceof Integer) {
                orderSeqNbr = (Integer) orderSeqNbrObj;
            } else if (orderSeqNbrObj instanceof Number) {
                orderSeqNbr = ((Number) orderSeqNbrObj).intValue();
            } else {
                Log.info("unexpected type for orderSeqNbr:" + orderSeqNbrObj.getClass().getName());
                return 0;
            }
        } catch (ClassCastException e) {
            Log.info("ClassCastException:" + e.getMessage());
            return 0;
        }
        return orderSeqNbr;
    }

    public Map<String, Object> getPatientFirstNameAndLastName(int siteId, int patientId) {
        String query = "select * from informix.patient where patient_id = " + patientId + ";";
        Map<String, Object> map = automationManager.getConnexusDB(siteId).executeQuery(query);
        return map;
    }

    public Map<String, Integer> getRxIdAndRxFillIdAndOrderSeqNbr(int siteId, String rxNbr) {
        // Note: rxIdValue is already an Integer from getScalar, so it's type-safe
        int rxIdValue = automationManager.getConnexusDB(siteId).getScalar("select rx_id from rx where rx_nbr =" + rxNbr, Integer.class);
        // rxIdValue is already validated as Integer, safe to use in queries
        int rxFillIdValue = automationManager.getConnexusDB(siteId).getScalar("select rx_fill_id from rx_order_detail where rx_id=" + rxIdValue, Integer.class);
        int orderSeqNbrValue = automationManager.getConnexusDB(siteId).getScalar("select order_seq_nbr from rx_order_detail where rx_id=" + rxIdValue, Integer.class);
        orderId = this.getRxOrderIdFromTable(siteId, rxNbr);
        Map<String, Integer> map = new HashMap<>();
        map.put("rxId", rxIdValue);
        map.put("rxFillId", rxFillIdValue);
        map.put("orderSeqNbr", orderSeqNbrValue);
        map.put("orderId",orderId);
        return map;
    }

    public String random9DigitNumber() {
        long min = 1000000000L;
        long max = 10000000000L;
        Random random = new Random();
        long num = min + ((long) (random.nextDouble() * (max - min)));
        String value = String.valueOf(num);
        return value;
    }

    public String verifyAllergyClassCode(int patientId) {
        return "select allerg_class_code  as allergyClassCode from patient_allergy where patient_id\"" + patientId + "\"";
    }

    public String verifyReactionTxt(int patientId) {
        return "select reaction_txt  as reactionTxt from patient_allergy where patient_id\"" + patientId + "\"";
    }

    public String verifyallergyClassType(int patientId) {
        return "select allergy_class_type_cd  as allergyClassType from patient_allergy where patient_id\"" + patientId + "\"";
    }

    public void getlogSiteIdAndState(Map<String, String> inputData) {
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        stateId = inputData.get("STATE");
        Reporter.log("Logged in store:" + siteId);
        Reporter.log("State:" + stateId);
    }

    /*
     * Getting storeID and printing in report.
     *
     * */
    public int getStoreId(){
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        Reporter.log("Logged in store:" + siteId);
        return siteId;
    }

    public void writeTextToFile(String currentStage, String executionStatus, String filename, int percentage, DateTime currentTime) {
        try {
            FileWriter fileWriter = new FileWriter("src/test/resources/config/connexus/" + filename, true);
            String testData = "Current stage=" + currentStage + " ,Execution status=" + executionStatus + ", StoreNbr=" + prop.getProperty("cnx.store") + " , percentage of completion =" + percentage + " , " +
                    "Current Time=" + currentTime + " , State=" + prop.getProperty("cnx.state");
            fileWriter.append(testData + "\r\n");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addBlankLine(String filename) {
        try {
            FileWriter fileWriter = new FileWriter("src/test/resources/config/connexus/" + filename, true);
            fileWriter.append("\r\n");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void clearFile(String filename) {
        try {
            Formatter f = new Formatter("src/test/resources/config/connexus/" + filename);
            Scanner s = new Scanner("src/test/resources/config/connexus/" + filename);
            f.format(" ");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Integer> getMultiRxNbrFromPatientId(int siteId, int patientId) {
        List<Integer> rxNbrList = new ArrayList<>();
        String query = "select rx_nbr from rx where patient_id = " + patientId + " and rx_nbr is not null";
        List<Map<String, Object>> resultSet;
        resultSet = automationManager.getConnexusDB(siteId).executeQueryForList(query);
        if (resultSet != null) {
            for (Map<String, Object> row : resultSet) {
                int rxNbr = (int) row.get("rx_nbr");
                rxNbrList.add(rxNbr);
            }
        }
        return rxNbrList;
    }

    public void updateP2PeTokenValueHasNull(int patientID) {
        String query = "select * from patient_payment where patient_id =" + patientID;
        Map<String, Object> db = automationManager.getConnexusDB().executeQuery(query);
        Object phm_pymt_acct_id = db.get("phm_pymt_acct_id");
        Log.info("phm_pymt_acct_id:" + phm_pymt_acct_id);
        String updateQuery = "update phm_pymt_acct set p2pe_token = null where phm_pymt_acct_id=" + phm_pymt_acct_id;
        Reporter.log("updateP2PeTokenValueHasNull: " + updateQuery);
        try {
            automationManager.getConnexusDB().executeUpdateQuery(updateQuery);
            Log.info("row updated");
        } catch (Exception e) {
            Log.info("Error during update:" + e.getMessage());
            e.printStackTrace();
        }
        String query2 = "select * from phm_pymt_acct where phm_pymt_acct_id =" + phm_pymt_acct_id;
        Map<String, Object> dbValue = automationManager.getConnexusDB().executeQuery(query2);
        Object p2peTokenValue = dbValue.get("p2pe_token");
        Log.info("p2peTokenValue:" + p2peTokenValue);
    }

    public String getRequestDesc(String rxNbr) {
        String SelectQueryforReq = "select dur_request_desc from pharmacy_message:dur_audit where rx_id in (select rx_id from rx where rx_nbr = \"" + rxNbr + "\")";
        Map<String, Object> resultReq = automationManager.getConnexusDB().executeQuery(SelectQueryforReq);
        String dbRequestDesc = resultReq.toString();
        Reporter.log("dur_req_desc for RX" + "" + dbRequestDesc);
        String selectQuery = "select trim(both '\"' from substring(dur_request_desc from instr(dur_request_desc, '\"weight\":') + 10 for 9)) as weight_value from pharmacy_message:dur_audit\n" +
                "where rx_id in (select rx_id from rx where rx_nbr = \"" + rxNbr + "\");";
        Log.info(selectQuery);
        Map<String, Object> resultSet = automationManager.getConnexusDB().executeQuery(selectQuery);
        String weight = resultSet.toString();
        Log.info("" + resultSet);
        return weight;
    }

    public int getPrescriberIdFromName(String prescriberName, int prescriberId) {
        String names[] = prescriberName.split(",");
        String firstName[] = names[1].split(" ");
        String query = "select prescriber_id from prescriber where first_name= " + "'" + firstName[1].toUpperCase().trim() + "'" + " and last_name = " + "'" + names[0].toUpperCase().trim() + "' and prescriber_id=" + prescriberId + ";";
        Log.info(query);
        int prescriberID = automationManager.getConnexusDB(siteId).getScalar
                (query, Integer.class);
        Reporter.log("PrescriberId from Name:" + prescriberID);
        return prescriberID;
    }

    public String getCurrentDate(String pattern) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        Log.info(simpleDateFormat.format(new Date()));
        return simpleDateFormat.format(new Date());
    }

    public String getVisPubFromDB() {
        String query = "select vis.vis_publish_date from imz_product ip join\n" +
                "vaccine_info_sheet vis on ip.vis_id = vis.vis_id\n" +
                "where ip.product_mds_fam_id in ( " + "'" + productMdsFamId + "');";
        Reporter.log("To get VISPublish From Db: " + query);
        String visPubDate = automationManager.getConnexusDB(siteId).getScalar
                (query, String.class);
        Reporter.log("VisPublishDate from DB:" + visPubDate);
        return visPubDate;
    }

    public String dateConversion(String dateFormat) {
        String formattedDate = "";
        // Define the input format
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
        // Define the output format
        SimpleDateFormat outputFormat = new SimpleDateFormat("MM/dd/yyyy");
        try {
            // Parse the date string into a Date object
            Date parsedDate = inputFormat.parse(dateFormat);

            // Format the Date object to the desired output format
            formattedDate = outputFormat.format(parsedDate);

            Log.info("Formatted date: " + formattedDate);
        } catch (Exception e) {
            Log.info("Error: " + e);
        }
        return formattedDate;
    }

    public String getStatusCodeFromDB(String rxNbr, String getColumnValue) {
        String selectQuery = "select * from rx_autofill_enrollment where rx_id = (select rx_id from rx where rx_nbr = \"" + rxNbr + "\")";
        Map<String, Object> resultSet = executeQueryWithRetry(selectQuery, 3, 10);

        if (resultSet != null && !resultSet.isEmpty()) {
            return resultSet.get(getColumnValue).toString().trim();
        }
        return null;
    }

    // Helper method (add this to your class)
    private Map<String, Object> executeQueryWithRetry(String query, int maxRetries, int waitSeconds) {
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                Map<String, Object> result = automationManager.getConnexusDB().executeQuery(query);

                if (result != null) {
                    return result;
                }

                Log.info("Query returned null. Attempt " + attempt + " of " + maxRetries);

                if (attempt < maxRetries) {
                    Thread.sleep((long) waitSeconds * 1000);
                }

            } catch (Exception e) {
                Log.info("Query failed on attempt " + attempt + ": " + e.getMessage());

                if (attempt < maxRetries) {
                    try {
                        Thread.sleep((long) waitSeconds * 1000);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        return Collections.emptyMap();
                    }
                }
            }
        }

        Log.info("All " + maxRetries + " attempts failed for query: " + query);
        return null;
    }

    public int updateC2DrugFlagValue() {
        try {
            String query = "SELECT count(pip.mds_fam_id) FROM pharmacy_offering:pharmacy_item pi, pharmacy_offering:pharmacy_product pp, pharmacy_offering:phm_item_problem pip WHERE pi.product_mds_fam_id = pp.product_mds_fam_id AND pip.mds_fam_id = pi.mds_fam_id AND pip.problem_type_code = 9001 AND pip.problem_stat_code in (6320, 6322) AND pp.drug_control_code = 2300 AND pip.count_reason_code in (2011, 2012, 2013) AND pip.count_role_code = 3030";
            Map<String, Object> c2DrugCount = automationManager.getConnexusDB().executeQuery(query);
            int count = Integer.parseInt(c2DrugCount.get("(count)").toString());
            if (count > 0) {
                String updateQuery = "update pharmacy_offering:phm_item_problem set problem_stat_code = 9999 where mds_fam_id in ( SELECT pip.mds_fam_id FROM pharmacy_offering:pharmacy_item pi, pharmacy_offering:pharmacy_product pp, pharmacy_offering:phm_item_problem pip WHERE pi.product_mds_fam_id = pp.product_mds_fam_id AND pip.mds_fam_id = pi.mds_fam_id AND pip.problem_type_code = 9001 AND pip.problem_stat_code in (6320, 6322) AND pp.drug_control_code = 2300 AND pip.count_reason_code in (2011, 2012, 2013) AND pip.count_role_code = 3030)";
                return automationManager.getConnexusDB().executeUpdateQuery(updateQuery);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int updateStatusCode(String statusCode, String rxNbr) {
        String query = "select rx_id from rx where rx_nbr =" + rxNbr;
        Map<String, Object> rxIdValue;
        rxIdValue = automationManager.getConnexusDB().executeQuery(query);
        String updateQuery = "update rx_autofill_enrollment set status_code = \"" + statusCode + "\" where rx_id = \""
                + rxIdValue;
        Log.info("updateQuery:" + updateQuery);
        try {
            return automationManager.getConnexusDB().executeUpdateQuery(updateQuery);

        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public Map<String, Object> fetchNarxPatientTableDetails(String patientId) {
        String query = "Select * from narx_patient_request where patient_id =" + patientId + " order by score_request_ts desc limit 1";
        Map<String, Object> result = automationManager.getConnexusDB().executeQuery(query);
        String narxPatientDetails = result.toString();
        Reporter.log("Result for query:" + query + "" + narxPatientDetails);
        int svc_rqst_status_code = automationManager.getConnexusDB().getScalar("Select svc_rqst_status_code from narx_patient_request where patient_id =" + patientId + " order by score_request_ts desc limit 1", Integer.class);
        String error_message_txt = automationManager.getConnexusDB().getScalar("Select error_message_txt from narx_patient_request where patient_id = " + patientId + " order by score_request_ts desc limit 1", String.class);
        Map<String, Object> map = new HashMap<>();
        map.put("svc_rqst_status_code", svc_rqst_status_code);
        map.put("error_message_txt", error_message_txt);
        return map;
    }

    public String getPastDateFromProvidedDate(String date, String dateFormat, int numberOfDays) {
        try {
            simpleDateFormat = new SimpleDateFormat(dateFormat);
            Date date1 = new SimpleDateFormat(dateFormat).parse(date);
            cal.setTime(date1);
            cal.add(Calendar.DATE, -numberOfDays);
            Date newDate = cal.getTime();
            String modifieddate = simpleDateFormat.format(newDate);
            return modifieddate;
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    public void updateInventoryQuantity(String ndc) {
        Date currentDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedDate = dateFormat.format(currentDate);
        String query = "update pharmacy_offering:pharmacy_item set on_hand_qty = 10000, last_change_ts = '" + formattedDate + "' where ndc_nbr in (" + ndc + ")";
        automationManager.getConnexusDB().executeUpdateQuery(query);
    }

    public int getPrescriberIdFromName(String prescriberName) {
        String names[] = prescriberName.split(",");
        String firstName[] = names[1].split(" ");
        String query = "select prescriber_id from prescriber where first_name= " + "'" + firstName[1].toUpperCase().trim() + "'" + " and last_name = " + "'" + names[0].toUpperCase().trim() + "'" + "limit 1;";
        Log.info(query);
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        DataTable dt = cnx.getDataTable(query);
        DataRow row = dt.getDataRows().get(0);
        Assert.assertEquals(dt.getRowCount(), 1, "Prescriber details not found in informix DB");
        int prescriberId = row.getValue("prescriber_id");
        Reporter.log("PrescriberId from Name:" + prescriberId);
        return prescriberId;
    }

    public Map<String, Object> fetchLatestUser(int StoreNbr) {
        String FetchUserQuery = "select first 1 userid from phm_appl_security:system_user order by security_id desc;";
        Map<String, Object> userdata = new HashMap<>();
        try {
            userdata = automationManager.getConnexusDB(StoreNbr).executeQuery(FetchUserQuery);
            Reporter.log("Running query \"" + FetchUserQuery + "\"" + " to fetch latest userid available database.\nLatest userdetails: " + userdata);
        } catch (Throwable e) {
            e.printStackTrace();
            Assert.fail("Issue while fetching user details from database");
        }
        return userdata;


    }

    public void fetchPharmacyCodeTxt(String restrictTypeCode) {
        String query = "select * from pharmacy_code_txt where code_id=\"" + restrictTypeCode + "\"";
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        String currentFlagDesc = result.get(0).get("code_desc").toString();
        Reporter.log("Flag Code \t\t:" + restrictTypeCode + " And It's desc \t\t:" + currentFlagDesc);
    }

    public List<Map<String, Object>> readPharmacyCode(String flagCode) {
        try {
            String selectQuery = "select * from pharmacy_code_txt where code_id = " + flagCode;
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB().executeQueryForList(selectQuery);
            if (resultSet != null) {
                return resultSet;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean fetchPharmacyCodeTxt(String flagCode, String flagValue) {
        List<Map<String, Object>> resultSet = readPharmacyCode(flagCode);
        assert resultSet != null;
        if (resultSet.size() == 1) {
            String currentFlagCode = resultSet.get(0).get("code_id").toString();
            String currentFlagDesc = resultSet.get(0).get("code_desc").toString().trim();
            if (updateFlagValue(flagCode, flagValue) > 0) {
                Reporter.log("Flag Code \t\t:" + currentFlagCode + " And It's desc \t\t:" + currentFlagDesc);
                return true;
            } else {
                Reporter.log("Update flag status\t\t:" + "flag update failed!");
                return false;
            }
        } else {
            return false;
        }
    }

    public void fetchlogSiteIdAndState(String State){
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        stateId = State;
        Reporter.log("Logged in store:" + siteId);
        Reporter.log("State:" + stateId);
    }

    public String getVerifyPickUpDate(int orderId) {
        String pickUpDate = automationManager.getConnexusDB().getScalar("select substr(est_pickup_ts,1,19) from svc_order_detail where order_id =" + orderId + "limit 1", String.class);
        return pickUpDate;
    }

    public String getSQQuery(String rxFillId) {
        String query = " select sub_que_type_code from rx_order_detail where rx_fill_id = " + rxFillId;
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        String subque = rxInfo.get("sub_que_type_cd").toString();
        return subque;
    }

    public String getPCPFaxId(int rxFillId) {
        String query = "select * from imz_thd_party_rpt where rx_fill_id=" + rxFillId;
        Reporter.log("To get pcp_fax_id From Db: " + query);
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        String pcpFaxId = result.get(0).get("pcp_fax_id").toString();
        return pcpFaxId;
    }

    public int getPCPFaxIdCount(String faxId) {
        String query = "select * from pharmacy_fax where fax_id in ( " + "'" + faxId + "');";
        Reporter.log("PCPFaxId from DB: " + query);
        IDatabaseContext cnx = automationManager.getConnexusDB(Integer.parseInt(prop.getProperty("cnx.store")));
        DataTable pcpFaxId = cnx.getDataTable(query);
        int rowCount = pcpFaxId.getRowCount();
        return rowCount;
    }

    public String getFaxIdInPharmacyTable(String faxId) {
        String query = "select * from pharmacy_fax where fax_id in ( " + "'" + faxId + "');";
        Reporter.log("PCPFaxId from pharmacy table: " + query);
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        String faxIdPharmacyTbl = result.get(0).get("fax_id").toString();
        Reporter.log("faxId from pharmacy table:" + faxIdPharmacyTbl);
        return faxIdPharmacyTbl;
    }

    public String getServiceId(int siteId, String rxNbr) {
        int orderId = this.getRxOrderIdFromTable(siteId, rxNbr);
        String query = "select * from svc_order_detail where order_id in ( " + "'" + orderId + "');";
        Reporter.log("service order details: " + query);
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        return result.get(0).get("service_id").toString();
    }

    public int getServiceIdCount(String serviceId, int activityCode) {
        query = "select * from service_activty where activity_code = " + activityCode + " and service_id = " + serviceId;
        Reporter.log("service activity details: " + query);
        IDatabaseContext cnx = automationManager.getConnexusDB(Integer.parseInt(prop.getProperty("cnx.store")));
        DataTable pcpserviceId = cnx.getDataTable(query);
        int rowCount = pcpserviceId.getRowCount();
        return rowCount;
    }

    //Getting status code from svc order details table
    public String getStatusCode(int siteId, String rxNbr) {
        int orderId = this.getRxOrderIdFromTable(siteId, rxNbr);
        String query = "select * from svc_order_detail where order_id =" + orderId;
        Map<String, Object> result = automationManager.getConnexusDB().executeQuery(query);
        return result.get("status_code").toString();
    }

    //Getting status code desc from pharmacy code txt table
    public String getCodeDesc(String typeCode) {
        String query = "SELECT CASE" +
                " WHEN code_id = 20503 THEN 'Canceled' " +
                " WHEN code_id = 20501 THEN 'Active'" +
                " END AS code_desc FROM pharmacy_code_txt where code_id =" + typeCode;
        Map<String, Object> result = automationManager.getConnexusDB().executeQuery(query);
        String codeDesc = result.get("code_desc").toString();
        return codeDesc;
    }

    public String getNDCFromRx(String rxNbr) {
        String query = "select pi.ndc_nbr from rx, rx_fill rf, rx_fill_item rfi,pharmacy_offering:pharmacy_item pi\n" +
                "where rx.rx_id = rf.rx_id\n" +
                "and rf.rx_fill_id = rfi.rx_fill_id\n" +
                "and rfi.item_mds_fam_id = pi.mds_fam_id\n" +
                "and rx.rx_nbr =" + rxNbr;
        automationManager.getConnexusDB().executeQuery(query);
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        DataTable dt = cnx.getDataTable(query);
        DataRow row = dt.getDataRows().get(0);
        Assert.assertEquals(dt.getRowCount(), 1, "NDC number not found in informix DB");
        String NDC = row.getValue("ndc_nbr");
        Reporter.log("NDC from rxNbr:" + NDC);
        return NDC.trim();
    }

    /**
     * Get on hand quantity from DB.
     *
     * @param ndc
     * @return
     */
    public String getOnHandQuantity(String ndc) {
        String query = "select on_hand_qty from pharmacy_offering:pharmacy_item where ndc_nbr = " + ndc;
        Reporter.log(query);
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1, "on hand qty not found in informix DB");
        DataRow row = dt.getDataRows().get(0);
        return row.getValue("on_hand_qty").toString();
    }

    /**
     * Get Inner pack quantity from DB.
     *
     * @param ndc
     * @return
     */
    public String getInnerPackQuantity(String ndc) {
        String query = "select inner_pack_qty from pharmacy_offering:pharmacy_item where ndc_nbr = " + ndc;
        IDatabaseContext cnx = automationManager.getConnexusDB(siteId);
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1, "on hand qty not found in informix DB");
        DataRow row = dt.getDataRows().get(0);
        return row.getValue("inner_pack_qty").toString();
    }

    /**
     * Update on hand quantity in DB.
     *
     * @param ndc
     * @return
     */
    public int updateOnhandQuantity(String ndc) {
        int packQuantity = (int) Double.parseDouble(getInnerPackQuantity(ndc)) * 4;
        String updateQuery = "update pharmacy_offering:pharmacy_item set on_hand_qty = " + packQuantity + "  where ndc_nbr=" + ndc;
        try {
            return automationManager.getConnexusDB().executeUpdateQuery(updateQuery);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public void getState(Map<String, String> inputData) {
        stateId = inputData.get("STATE_UPDATE");
        Reporter.log("State:" + stateId);
    }

    public String modifyDateToFuture(String dateFormat, int days) {
        simpleDateFormat = new SimpleDateFormat(dateFormat);
        cal.setTime(date);
        cal.add(Calendar.DATE, days);
        Date newdate = cal.getTime();
        String modifieddate = simpleDateFormat.format(newdate);
        return modifieddate;
    }


    /**
     * This Method will get the insurancePlanTypeCode from DB and return.
     *
     * @param name
     * @return
     */
    public int getInsurancePlanTypeCodeFromName(String name) {
        String query = "select ins_plan_type_code from insurance_card where cardholder_name = '" + name + "';";
        Log.info(query);
        int insurancePlanTypeCode = automationManager.getConnexusDB(siteId).getScalar
                (query, Integer.class);
        Reporter.log("insurancePlanTypeCode for Patient:" + insurancePlanTypeCode);
        return insurancePlanTypeCode;
    }

    /**
     * Ths method will return current UTC time stamp.
     *
     * @return
     */
    public static String getCurrentTimestamp(String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }

    //Getting all activity codes from rx order detail activity table
    public List<String> getActivityCodesFromOrderDtlTbl(int siteId, String rxNbr, List<Integer> expectedCodes) {
        List<String> activityCodes = new ArrayList<>();
        try {
            int orderId = getRxOrderIdFromTable(siteId, rxNbr);
            String codesStr = expectedCodes.stream().map(String::valueOf).collect(Collectors.joining(","));

            String query = "select distinct activity_code from rx_ord_dtl_activty " +
                    "where order_id = " + orderId + " " +
                    "and activity_code in (" + codesStr + ")";

            Reporter.log("Fetch activity codes: " + query);
            List<Map<String, Object>> results = automationManager.getConnexusDB().executeQueryForList(query);

            for (Map<String, Object> result : results) {
                String activityCode = result.get("activity_code").toString();
                activityCodes.add(activityCode);
            }
            Reporter.log("Found activity codes from order detail: " + activityCodes);

        } catch (Exception e) {
            e.printStackTrace();
            Reporter.log("Failed to fetch activity codes: " + e.getMessage());
        }
        return activityCodes.stream().distinct().collect(Collectors.toList());
    }

    //Fetch activity codes from activity text table
    public List<String> fetchActivityCodesFromText(List<Integer> activityCodes) {
        List<String> activityTextCodes = new ArrayList<>();
        try {
            String codesStr = activityCodes.stream().map(String::valueOf).collect(Collectors.joining(","));

            String query = "select activity_code, activity_text from activity_text where activity_code in (" + codesStr + ")";
            Reporter.log("Fetch activity codes from activity text: " + query);

            List<Map<String, Object>> results = automationManager.getConnexusDB().executeQueryForList(query);

            for (Map<String, Object> result : results) {
                String activityCode = result.get("activity_code").toString();
                activityTextCodes.add(activityCode);
            }
            Reporter.log("Found activity codes from activity text: " + activityTextCodes);
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.log("Failed to fetch activity codes: " + e.getMessage());
        }
        return activityTextCodes;
    }

    //Getting pre-auth-id value from service preauth table
    public int getServicePreAuthId() {
        String query = "select * from service_pre_auth where pre_auth_type_cd = 104 order by pre_auth_eff_date desc;";
        Reporter.log("service_pre_auth details: " + query);
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        int preAuthId = Integer.parseInt(result.get(0).get("pre_auth_id").toString());
        return preAuthId;
    }

    /**
     * This Method will get the ndc_nbr, on_hand_qty,mds_fam_id from DB and return as map
     *
     * @param NDC
     * @return
     */
    public Map<String, Map<String, Object>> getOnHandQtyAndFillIdForNDC(String NDC) {
        String query = "select ndc_nbr, on_hand_qty,mds_fam_id from pharmacy_offering:pharmacy_item where ndc_nbr in (" + NDC + ");";
        Log.info(query);
        List<Map<String, Object>> rows = automationManager.getConnexusDB(siteId).executeQueryForList
                (query);
        Map<String, Map<String, Object>> getDrugInfo = new HashMap<>();
        for (Map<String, Object> row : rows) {
            String ndcNumber = (String) row.get("ndc_nbr");
            Map<String, Object> innerMap = new HashMap<>();
            Number qty = (Number) row.get("on_hand_qty");
            innerMap.put("onHandQty", qty != null ? qty.intValue() : 0);
            innerMap.put("famId", row.get("mds_fam_id"));
            getDrugInfo.put(ndcNumber.trim(), innerMap);
        }
        return getDrugInfo;
    }

    /**
     * This method will return the adjustment occurrence
     *
     * @param ndcNumber
     * @return
     */

    public String getAdjustmentoccurrence(String ndcNumber) {
        String adjustmentOccurance;
        String query = "select\n" +
                "\tcase\n" +
                "\t\twhen pp.drug_control_code = 2300 then cast(\n" +
                "\t\t\t(\n" +
                "\t\t\t\tselect\n" +
                "\t\t\t\t\tcase\n" +
                "\t\t\t\t\t\twhen count( * ) > 1 then 1\n" +
                "\t\t\t\t\t\twhen count( * ) = 1 then 0\n" +
                "\t\t\t\t\t\telse null\n" +
                "\t\t\t\t\tend\n" +
                "\t\t\t\tfrom\n" +
                "\t\t\t\t\tpharmacy_offering:phm_item_problem pip\n" +
                "\t\t\t\twhere\n" +
                "\t\t\t\t\tpip.mds_fam_id = pi.mds_fam_id\n" +
                "\t\t\t\t\tand pip.create_ts >= mdy( month( TODAY ), 1, year( TODAY ) )\n" +
                "\t\t\t\t\tand pip.create_ts < mdy( month( TODAY ) + 1, 1, year( TODAY ) )\n" +
                "\t\t\t) as varchar(255)\n" +
                "\t\t)\n" +
                "\t\telse 'The ndc_nbr you passed has the drug_control_code as ' || cast(\n" +
                "\t\t\tpp.drug_control_code as varchar(255)\n" +
                "\t\t) || '. This is not a Controlled Substance Drug of Drug Control Code 2300.'\n" +
                "\tend as result\n" +
                "from\n" +
                "\tpharmacy_offering:pharmacy_item pi join pharmacy_offering:pharmacy_product pp on\n" +
                "\tpi.product_mds_fam_id = pp.product_mds_fam_id join pharmacy_offering:phm_item_upc piu on\n" +
                "\tpi.upc_nbr = piu.upc_nbr join pharmacy_offering:labeler_txt lt on\n" +
                "\tpi.labeler_id = lt.labeler_id\n" +
                "where\n" +
                "\tpi.status_code = 20909\n" +
                "\tand pi.dept_nbr = 38\n" +
                "\tand pi.rx_reqd_ind = 'Y'\n" +
                "\tand piu.scan_ind is not null\n" +
                "\tand piu.scan_ind in('N')\n" +
                "\tand pi.labeler_id is not null\n" +
                "\tand pi.ndc_nbr = '" + ndcNumber + "';";
        adjustmentOccurance = automationManager.getConnexusDB(siteId).getScalar(query, String.class);
        return adjustmentOccurance;

    }

    /**
     * This Method wil get the Adjustment Type Code
     *
     * @param famId
     * @return
     */
    public int getAdjmtTypeCode(String famId) {
        String query = "select FIRST 1 adjmt_type_code from pharmacy_offering:phm_item_inv_adjmt where mds_fam_id = '" + famId + "' order by adjmt_ts desc;";
        Log.info(query);
        int adjmt_type_code = automationManager.getConnexusDB(siteId).getScalar(query, Integer.class);
        return adjmt_type_code;
    }

    //This method will return license number from prescriber
    public List<String> getLicenseDetailsFromPrescriber(String prescriberName) {
        try {
            prescriberId = getPrescriberIdFromName(prescriberName);
            query = "select license_nbr from prescriber_license where prescriber_id = " + prescriberId;
            Reporter.log("Prescriber license Details Query: " + query);
            List<Map<String, Object>> results = automationManager.getConnexusDB().executeQueryForList(query);
            for (Map<String, Object> result : results) {
                String licenseNbr = result.get("license_nbr").toString();
                licenseTypeCodes.add(licenseNbr);
            }
            Reporter.log("Found state license details from DB: " + licenseTypeCodes);
        } catch (Exception e) {
            e.printStackTrace();
            Reporter.log("Failed to fetch license details from prescriber id: " + e.getMessage());
        }
        return licenseTypeCodes;
    }

    //This method will return licenseNbr from PrescriberId
    public String getLicenseNbr(String prescriberName) {
        prescriberId = getPrescriberIdFromName(prescriberName);
        query = "select * from prescriber_license where license_type_code = 801 and prescriber_id =" + prescriberId + "limit 1;";
        Map<String, Object> result = automationManager.getConnexusDB().executeQuery(query);
        Object licenseCode = result.get("license_nbr");
        licenseNbr = licenseCode != null ? licenseCode.toString() : null;
        return licenseNbr;
    }

    //This Method will return so fax id
    public String getSOPFaxId(int rxFillId) {
        query = "select * from imz_thd_party_rpt where rx_fill_id=" + rxFillId;
        Reporter.log("To get pcp_fax_id From Db: " + query);
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        Reporter.log("SOFaxId from DB:" + result);
        String soFaxId = result.get(0).get("so_fax_id").toString();
        return soFaxId;
    }

    //This method will return service id from order id
    public List<String> getServiceIds(int siteId, String rxNbr) {
        orderId = this.getRxOrderIdFromTable(siteId, rxNbr);
        query = "select * from svc_order_detail where order_id in ( '" + orderId + "');";
        Reporter.log("service order details: " + query);
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        List<String> serviceIds = new ArrayList<>();
        for (Map<String, Object> row : result) {
            serviceIds.add(row.get("service_id").toString());
        }
        return serviceIds;
    }


    /**
     * This Methd will get the NDC number and thos NDC number you can pass in the API
     * to get it added in Cycle Count Report Page
     * @return
     */
    public  List<String> getOnNDCNumberToAddInCycleCount() {
        String query = "SELECT \n" +
                "    ndc_nbr\n" +
                "FROM (\n" +
                "    SELECT \n" +
                "        pi.ndc_nbr, \n" +
                "        ROW_NUMBER() OVER (PARTITION BY pp.drug_control_code ORDER BY pi.ndc_nbr) AS rn\n" +
                "    FROM \n" +
                "        pharmacy_offering:pharmacy_item pi \n" +
                "    JOIN \n" +
                "        pharmacy_offering:pharmacy_product pp \n" +
                "        ON pi.product_mds_fam_id = pp.product_mds_fam_id \n" +
                "    JOIN \n" +
                "        pharmacy_offering:phm_item_upc piu \n" +
                "        ON pi.upc_nbr = piu.upc_nbr \n" +
                "    WHERE \n" +
                "        pi.status_code = 20909 \n" +
                "        AND ( \n" +
                "            (pi.dept_nbr = 38 AND pi.rx_reqd_ind = 'Y' AND piu.scan_ind = 'N') \n" +
                "            OR (pi.dept_nbr = 38 AND pi.rx_reqd_ind = 'N' AND piu.scan_ind = 'Y') \n" +
                "            OR (pi.dept_nbr = 40 AND pi.rx_reqd_ind = 'N' AND piu.scan_ind = 'Y') \n" +
                "        )\n" +
                ") AS RankedItems\n" +
                "WHERE rn <= 4;";
        Log.info(query);
        List<Map<String,Object>> rows = automationManager.getConnexusDB(siteId).executeQueryForList(query);
        List<String>ndcNumbers=new ArrayList<>();
        for(Map<String,Object>row:rows){
            String ndcNumber = (String) row.get("ndc_nbr");
            ndcNumbers.add(ndcNumber);
        }
        return ndcNumbers;
    }

    /**
     * Thi Method will resolve all the ndc which has date<today
     */
    public void resolveAllBackdatedNdc(){
        String query = "UPDATE pharmacy_offering:phm_item_problem\n" +
                "SET problem_stat_code = 6321\n" +
                "WHERE problem_stat_code = 6320\n" +
                "AND CAST(create_ts AS DATE) < TODAY\n" +
                "AND NOT EXISTS (\n" +
                "    SELECT 1\n" +
                "    FROM pharmacy_offering:phm_item_problem\n" +
                "    WHERE problem_stat_code = 6320\n" +
                "    AND CAST(create_ts AS DATE) = TODAY\n" +
                ");";
        Log.info(query);
        automationManager.getConnexusDB(siteId).getScalar(query, String.class);
    }

    /**
     * This will get the shipment id
     * @input fillId
     * @return
     */
    public List<Map<String, Object>>  getShipMentId(String fillId) {
        try {
            String selectQuery = "select * from rx_espn_fill where rx_fill_id in("+fillId+");";
            Reporter.log("Executing query: "+selectQuery);
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB().executeQueryForList(selectQuery);
            if (resultSet != null) {
                return resultSet;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * To get ASN number from DB.
     * @param shipmentId
     * @return
     */
    public String getAsnNumber(long shipmentId) {
        String query = "select vndr_shpmt_id from rx_espn where cf_shipment_id = " + shipmentId;
        Reporter.log("Executing query:"+query);
        String asnNumber=automationManager.getConnexusDB(siteId).getScalar(query, String.class);
        return asnNumber;
    }

    /**
     * To get ASN number from DB.
     * @param asnNumber
     * @return
     */
    public String getASNStatusCode(long asnNumber) {
        String query = "select ho_espn_stat_code from rx_espn where vndr_shpmt_id = " + asnNumber;
        String statusCode=automationManager.getConnexusDB(siteId).getScalar(query, String.class);
        return statusCode;
    }

    /**
     * To get Workstation host name from DB.
     * @param rxNbr
     * @return
     */
    public String getWorkStationName(String rxNbr) {
        String query = "select wrkstatn_host_name from rx_order_detail where rx_id in(select rx_id from rx where rx_nbr in ("+rxNbr+"))";
        String workStationName=automationManager.getConnexusDB(siteId).getScalar(query, String.class);
        return workStationName;
    }

    /**
     * This method is a polymorphism of random number this will ask for random number based on Argument .
     * @return
     */
    public long randomNumber( int length) {
        long lowerBound = (long) Math.pow(10, length - 1);
        long upperBound = (long) Math.pow(10, length) - 1;
        return lowerBound + (long) (Math.random() * (upperBound - lowerBound + 1));
    }

    /**
     * To get Random alpha numeric in UUID format.
     * @return
     */
    public String randomAlphaNumeric(){
        String alphaNumeric = UUID.randomUUID().toString().toUpperCase();
        return alphaNumeric;
    }

    /**
     * To validate Activity code.
     * @param orderId
     * @return
     */
    public boolean validateActivityCode(int orderId) {
        try {
            String selectQuery = "select * from rx_ord_dtl_activty where order_id="+orderId+" and activity_code in (10000, 16136);";
            List<Map<String, Object>> resultSet;
            List<String> activityCodes = new ArrayList<>();
            resultSet = automationManager.getConnexusDB().executeQueryForList(selectQuery);
            if (resultSet != null) {
                for (Map<String, Object> result : resultSet) {
                    String activityCode = result.get("activity_code").toString();
                    activityCodes.add(activityCode);
                }
                Reporter.log("Found activity codes from order detail: " + activityCodes);
                return true;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return false;
    }

    //This method will return pharma imz event details
    public Map<String, String> getImzEventDetails(String eventDesc) {
        Map<String, String> eventDetails = new HashMap<>();
        String query = "select event_desc, event_date, expiration_date FROM informix.phm_event where event_desc ='" + eventDesc + "' limit 1;";
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        if (result != null && !result.isEmpty()) {
            Map<String, Object> row = result.get(0);
            eventDetails.put("imzEventDesc", row.get("event_desc").toString());
            eventDetails.put("eventStartDate", row.get("event_date").toString());
            eventDetails.put("eventExpirationDate", row.get("expiration_date").toString());
        }
        return eventDetails;
    }

    //Convert Date Format from 24 hours to 12 hours
    public static String convertDateFormat(String inputFormat, String outputFormat, String inputDateString) {
        String outputDateString = null;
        SimpleDateFormat inputDateFormat = new SimpleDateFormat(inputFormat);
        SimpleDateFormat outputDateFormat = new SimpleDateFormat(outputFormat);
        try {
            Date date = inputDateFormat.parse(inputDateString);
            outputDateString = outputDateFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return outputDateString;
    }

    public void validateProductCountofPatient(int patientid) {
        IDatabaseContext cnx = automationManager.getConnexusDB(Integer.parseInt(prop.getProperty("cnx.store")));
        query = "select * from phm_service where patient_id=" + patientid;
        DataTable dt = cnx.getDataTable(query);
        int patientID_rowCount = dt.getRowCount();
        Assert.assertEquals(patientID_rowCount, 2, "Expected entry in DB is: " + patientID_rowCount);
        Reporter.log("Assert: Entry found in DB for patient_ids:" + patientid + "  " + "Row count: " + patientID_rowCount);
    }
    public void validateOrderSeqcountofOrder(int orderId) {
        IDatabaseContext cnx = automationManager.getConnexusDB(Integer.parseInt(prop.getProperty("cnx.store")));
        query = "select distinct order_seq_nbr from rx_ord_dtl_activty where order_id="+orderId;
        DataTable dt = cnx.getDataTable(query);
        int orderID_rowCount = dt.getRowCount();
        Assert.assertEquals(orderID_rowCount, 2, "Expected entry in DB is: " + orderID_rowCount);
        Reporter.log("Assert: Entry found in DB for OrderSeqCount:" + orderId + "  " + "Row count: " + orderID_rowCount);

    }

    public Map<String, Object> getFaxIdForRx(String rxNbr) {
        return automationManager.getConnexusDB().executeQuery("select fax_id from informix.pharmacy_fax where related_rx_id = ( select rx_id from rx where rx_nbr = " + rxNbr +")" );
    }

    public int completeRxOrder(int orderId,int orderSeqNo) {
        return automationManager.getConnexusDB(siteId).executeUpdateQuery("update rx_order_detail set rx_response_id = null, status_code = 20502, next_work_que_code = null, work_que_stat_code = null where order_id =" + orderId + " and order_seq_nbr =" + orderSeqNo);
    }

    /**
     * This method will handle multiple date formats.
     * @return The current date formatted in the first valid format.
     */
    public String getFormattedDate() {
        String[] formats = {"M/d/yyyy", "MM/dd/yyyy"};
        for (String format : formats) {
            try {
                return this.getCurrentDate(format);
            } catch (IllegalArgumentException e) {
                Reporter.log("Invalid date format: " + format);
            }
        }
        throw new RuntimeException("No valid date format found.");
    }

    /**
     * update pick up date to future/past time stamp based on no of days.
     * @param orderId
     * @param noOfDays
     */
    public void updateTimeStampToFutureDate(int orderId,int noOfDays) {
        String timeStamp=getPastOrFutureTimestamp("yyyy-MM-dd",noOfDays);
        String query = "update rx_order_detail set est_pickup_ts ='"+timeStamp+" 00:01:00' where order_id=" + orderId + "";
        automationManager.getConnexusDB().executeUpdateQuery(query);
    }

    /**
     * Ths method will return past or Future UTC time stamp.
     *
     * @return
     */
    public static String getPastOrFutureTimestamp(String format, int noOfFutureDays) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, noOfFutureDays);
        return sdf.format(c.getTime());
    }

    /**
     * This method fetches the pre_auth_id from service_pre_auth table
     * based on the provided pre_auth_id.
     * @param pre_auth_id
     * @return preAuthId value
     */
    public int getPreAuthId(String pre_auth_id) {
        String query = "select * from service_pre_auth where pre_auth_id = " + pre_auth_id + " order by pre_auth_eff_date desc;";
        Log.info("service_pre_auth details: " + query);
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        int preAuthId = Integer.parseInt(result.get(0).get("pre_auth_id").toString());
        return preAuthId;
    }

    /**
     * This method fetches the pharmacy product drug names based on the provided product mds ids.
     * @param productMdsFamIdList
     * @return products short name
     */
    public List<String> getPharmacyProductDrugName(List<Integer> productMdsFamIdList) {
        List<String> shortNames = new ArrayList<>();
        try {
            String productMdsFamId = productMdsFamIdList.stream().map(String::valueOf).collect(Collectors.joining(","));
            String selectQuery = "SELECT short_name FROM pharmacy_offering:pharmacy_product WHERE product_mds_fam_id IN (" + productMdsFamId + ")";
            List<Map<String, Object>> resultSet = automationManager.getConnexusDB().executeQueryForList(selectQuery);

            if (resultSet != null && !resultSet.isEmpty()) {
                shortNames = resultSet.stream()
                        .map(row -> (String) row.get("short_name"))
                        .map(s -> s.trim().replaceAll("\\s+", " "))
                        .collect(Collectors.toList());
            } else {
                Reporter.log("No records found for productMdsFamIdList: " + productMdsFamIdList);
            }
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Error while fetching pharmacy product drug names: " + e.getMessage());
        }
        return shortNames;
    }

    public void validateSeverity(int rxFillId, int expectedSeverity) {
        String durquery = "SELECT dur_log_id , dur_response_desc FROM pharmacy_message:dur_audit WHERE rx_fill_id = " + rxFillId + " ORDER BY 1 desc";
        Map<String, Object> dur_audit = automationManager.getConnexusDB().executeQuery(durquery);
        String durResponse = dur_audit.get("dur_response_desc").toString();
        Reporter.log("Dur response code and value :" + durResponse);
        String jsonString = durResponse.substring(durResponse.indexOf("{"));
        JSONObject json = new JSONObject(jsonString);
        JSONObject alertInfo;
        if (json.get("alertSeverityInfo") instanceof JSONArray) {
            JSONArray alertArray = json.getJSONArray("alertSeverityInfo");
            alertInfo = alertArray.getJSONObject(0);
        } else {
            alertInfo = json.getJSONObject("alertSeverityInfo");
        }
        int severity = alertInfo.getInt("severity");
        Assert.assertEquals(severity, expectedSeverity, "Severity should be " + expectedSeverity + " but was " + severity);

        Reporter.log("Validate the Severity Level : " + severity);
    }

    public List<Map<String, Object>> getLatestTransTypeByUsingTimeStamp() {
        try {
            String selectQuery = "select xfer_att_cnt ,* from cf_msg_xfer where trans_type_code =20 order by create_ts desc";
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB().executeQueryForList(selectQuery);
            if (resultSet != null) {
                return resultSet;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String getHostName() {
        try {
            String selectQuery = "SELECT dbinfo('dbhostname') FROM rx21c:informix.pharmacy_bu";
            String hostName = automationManager.getConnexusDB(siteId).getScalar(selectQuery, String.class);
            if (hostName != null && !hostName.isEmpty()) {
                return hostName;
            }
        } catch (Throwable e) {
            e.printStackTrace();
            Reporter.log("Error while fetching dbinfo('dbhostname'): " + e.getMessage());
        }
        return "";
    }

    public void insertRequestTypeCode(String rxNbr, String code, String userID) {
        try {
            String query = "select rx_id from rx where rx_nbr =" + rxNbr;
            Reporter.log("Query to get RX ID: " + query);
            Map<String, Object> rxIdValue;
            rxIdValue = automationManager.getConnexusDB().executeQuery(query);
            if (rxIdValue == null || rxIdValue.isEmpty()) {
                Reporter.log("No RX ID found for RX Number: " + rxNbr);
                Assert.fail("No RX ID found for RX Number: " + rxNbr);
            }
            Object rxId = rxIdValue.get("rx_id");
            Reporter.log("RX ID Value: " + rxId);
            String insertQuery = "INSERT INTO rx_restrict (rx_id, rx_version_seq_nbr, restrict_type_code, effective_ts, create_userid, last_change_userid) " +
                    "VALUES (" + rxId + ", 1, " + code + ", '2025-02-27 09:00:0', '" + userID + "', '" + userID + "');";
            Reporter.log("Insert query: " + insertQuery);
            automationManager.getConnexusDB().executeUpdateQuery(insertQuery);
            Reporter.log("Code inserted successfully.");
        } catch (Exception e) {
            Reporter.log("Error inserting code: " + e.getMessage());
        }

    }
    /**
     * Method to get the Rx ID from the database based on the patient ID.
     * Author: Naveen (vn58o0j)
     * @return
     */
    public int getRxIdByUsingPatientId(int patientId) {
        String query = "select max(rx_id) as rx_id from RX where patient_id=" + patientId + " order by rx_id desc";
        Map<String, Object> rx = automationManager.getConnexusDB(siteId).executeQuery(query);
        rxId = Integer.parseInt(rx.get("rx_id").toString());
        Reporter.log("rx_Id:" + rxId);
        return rxId;
    }

    /**
     * Method to retrieve comment type codes and comment texts for a specific Rx ID.
     * Author: Naveen (vn58o0j)
     * @return
     */
    public List<Map<String, Object>> getCommentTypeCodeAndCommentText() {
        String query = "select c.comment_id ,c.comment_type_code ,c.create_ts ,c.create_userid, " +
                "c.comment_subj_code, c.alert_ind, cl.comment_text " +
                "from rx_comment r " +
                "join comment c on r.comment_id=c.comment_id " +
                "join comment_line cl on c.comment_id =cl.comment_id " +
                "where r.rx_id =" + rxId;
        try {
            return automationManager.getConnexusDB(siteId).executeQueryForList(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Collections.emptyList();
    }
    public void updateWorkstationToShipped(String rxFillId) {
        String query = "update rx_order_detail set wrkstatn_host_name=\"CentralFill-SHIPD\" where rx_fill_id="+rxFillId;
        automationManager.getConnexusDB().executeUpdateQuery(query);
    }

    public Map<String, Integer> getRxOrderDetailsBasedOnNextWorkQueCode(int siteId, String rxNbr) {

        if (rxNbr == null || rxNbr.trim().isEmpty()) {
            throw new IllegalArgumentException("rxNbr cannot be null or empty");
        }
        List<Map<String, Object>> rows = automationManager.getConnexusDB(siteId).executeQueryForList(
                String.format("SELECT * FROM rx_order_detail WHERE rx_id IN (SELECT rx_id FROM rx WHERE rx_nbr = '%s')", rxNbr));
        Map<String, Integer> result = new HashMap<>();
        if (rows != null && !rows.isEmpty()) {
            Map<String, Object> rowValues = rows.get(0);
            Object nextWorkQueCode = rowValues.get("next_work_que_code");
            if (nextWorkQueCode == null && rows.size() > 1) {
                rowValues = rows.get(1);
                nextWorkQueCode = rowValues.get("next_work_que_code");
            }
            // Fetch values from the row
            fetchValues(result, rowValues, nextWorkQueCode);
        }
        return result;
    }

    //fetch values from the row
    private void fetchValues(Map<String, Integer> result, Map<String, Object> row, Object nextWorkQueCode) {
        result.put("rxId", ((Number) row.get("rx_id")).intValue());
        result.put("rxFillId", ((Number) row.get("rx_fill_id")).intValue());
        result.put("orderSeqNbr", ((Number) row.get("order_seq_nbr")).intValue());
        result.put("orderId", ((Number) row.get("order_id")).intValue());
        result.put("nextWorkQueCode", nextWorkQueCode != null ? Integer.valueOf(nextWorkQueCode.toString()) : null);
    }

    /**
     * Method to verify patient record is present in Work Flow Request Table and to get the order id and work flow request id
     * Author: Diya (vn58o0i)
     */
    public boolean validatePatientRecordInWorkFlowRequestTable(String rxNbr) {
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery("select first 1 order_id,order_seq_nbr,rx_fill_id from rx_order_detail rod " +
                "left join rx rx on rx.rx_id=rod.rx_id " +
                "where rx.rx_nbr=" + rxNbr + " order by order_seq_nbr");

        if (rxInfo != null && StringUtils.isNotNullOrEmpty(rxInfo.get("order_id").toString())) {
            // Sanitize order_id to prevent SQL injection
            Object orderIdObj = rxInfo.get("order_id");
            long orderIdValue;
            if (orderIdObj instanceof Number) {
                orderIdValue = ((Number) orderIdObj).longValue();
            } else {
                try {
                    orderIdValue = Long.parseLong(orderIdObj.toString().trim());
                } catch (NumberFormatException e) {
                    Reporter.log("Invalid order_id value: " + orderIdObj);
                    return false;
                }
            }

            String Query = "select first 1 order_id, wf_rqst_id from workflow_rqst_trnsf  where order_id= " + orderIdValue;
            Map<String, Object> wf = automationManager.getConnexusDB().executeQuery(Query);
            if (wf != null && StringUtils.isNotNullOrEmpty(wf.get("wf_rqst_id").toString())) {
                Reporter.log("Executed query for getting the workflow request id and order id: "+Query);
                Reporter.log("Workflow request id: " + wf.get("wf_rqst_id").toString());
                Reporter.log("Order id: " + orderIdValue);
                return true;
            }
        }return false;
    }

    public void getServicePreAuthId(String  pre_auth_type_cd) {
        String query = "select * from service_pre_auth" + " where pre_auth_type_cd = " + pre_auth_type_cd + " order by pre_auth_eff_date desc limit 1";
        Reporter.log("service_pre_auth details: " + query);
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        int preAuthId=Integer.parseInt(result.get(0).get("pre_auth_id").toString());
        Reporter.log("service_pre_auth_Id: " + preAuthId);
        int preAuthTypeCd = Integer.parseInt(result.get(0).get("pre_auth_type_cd").toString());
        Reporter.log("service_pre_auth_type_cd: " + preAuthTypeCd);
        String pre_auth_eff_date= result.get(0).get("pre_auth_eff_date").toString();
        Reporter.log("service_pre_auth_eff_date: " + pre_auth_eff_date);
        String pre_auth_expir_date=result.get(0).get("pre_auth_expir_date").toString();
        Reporter.log("service_pre_auth_expir_date: " + pre_auth_expir_date);
        String todayDate = getCurrentDate("yyyy-MM-dd");
        String expireDate= LocalDate.now().plusDays(1).format(DateTimeFormatter.ISO_DATE);
        Assert.assertEquals(pre_auth_eff_date, todayDate, "preauth effective date is mismatching");
        Assert.assertEquals(pre_auth_expir_date, expireDate, "preauth expire date is mismatching");
    }

    public  boolean updateDispenseSlotStart(String purchaseOrderId){
        String updateQuery = "update dispense_po_tracking set dispense_slot_start=CURRENT - 120 UNITS minute where purchase_order_id= '" + purchaseOrderId +"'";
        try{
            int rowsUpdated = automationManager.getConnexusDB().executeUpdateQuery(updateQuery);
            if(rowsUpdated > 0){
                return  true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;

    }

    public Map<String, String> getOmsAndPOrderId() {
        Map<String, String> eventDetails = new HashMap<>();
        String query = "select oms_order_id,purchase_order_id from dispense_po_tracking order by last_update_ts desc limit 1";
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        if (result != null && !result.isEmpty()) {
            Map<String, Object> row = result.get(0);
            eventDetails.put("omsOrderId", row.get("oms_order_id").toString());
            eventDetails.put("poNumber", row.get("purchase_order_id").toString());
        }
        return eventDetails;
    }

    public int getFillIdFromDispenseFillTrackingTable() {
        String query = "select rx_fill_id from dispense_fill_tracking order by last_update_ts desc limit 1";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        int fillId = Integer.parseInt(rxInfo.get("rx_fill_id").toString());
        return fillId;
    }

    public int getStatusCodeFromDispensePoTrackingTable(String poNumber){
        String query = "select status_code from informix.dispense_po_tracking where purchase_order_id = '" + poNumber + "'";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        int status_Code = Integer.parseInt(rxInfo.get("status_code").toString());
        return status_Code;
    }

    public int getStatusCodeFromDispenseToteTrackingTable(String poNumber){
        String query = "select status_code from dispense_tote_tracking where purchase_order_id='" + poNumber + "'";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        int status_Code = Integer.parseInt(rxInfo.get("status_code").toString());
        return status_Code;
    }

    public String getFillDateFromRxFillTable(int rxFillId) {
        String query = "select fill_date from rx_fill where rx_fill_id ="+rxFillId;
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        String fill_date = rxInfo.get("fill_date").toString();
        return fill_date;
    }

    public int updateFillDateInRxFillTable(String fillDate,int rxFillId) {
        String query= "update rx_fill set fill_date ='"+fillDate+"' where rx_fill_id ="+rxFillId;
        int updatedrecord=automationManager.getConnexusDB().executeUpdateQuery(query);
        return updatedrecord;
    }

    public void getLogSiteIdAndState(Map<String, String> inputData) {
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        stateId = inputData.get("PHARMACY_STATE");
        Reporter.log("Logged in store:" + siteId);
        Reporter.log("State:" + stateId);
    }

    /**
     * Get pharmacy item quantities from database
     * @param ndcNbr - NDC number
     * @return on_hand_qty and allocated_fill_qty
     */
    public Map<String, Integer> getPharmacyItemQuantities(String ndcNbr) {
        try {
            String query = "select on_hand_qty, allocated_fill_qty from pharmacy_offering:pharmacy_item where ndc_nbr = '" + ndcNbr + "'";
            Map<String, Object> result = automationManager.getConnexusDB().executeQuery(query);

            int onHandQty = (int) Double.parseDouble(result.get("on_hand_qty").toString());
            int allocatedQty = (int) Double.parseDouble(result.get("allocated_fill_qty").toString());

            Map<String, Integer> quantities = new HashMap<>();
            quantities.put("on_hand_qty", onHandQty);
            quantities.put("allocated_fill_qty", allocatedQty);

            Reporter.log("<---Fetching pharmacy item quantities for NDC:---> " + ndcNbr);
            Reporter.log("NDC " + ndcNbr + " - on_hand_qty: " + onHandQty + ", allocated_fill_qty: " + allocatedQty);
            return quantities;
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Failed to get quantities for NDC " + ndcNbr + ": " + e.getMessage());
            Reporter.log("Error while fetching pharmacy item quantities: " + e.getMessage());
            return null;
        }
    }

    /**
     * Validate that quantities changed from previous values and return new values
     * @param ndcNbr - NDC number
     * @param previousQuantities - Previous quantities to compare against
     * @return Current quantities after validation
     */
    public Map<String, Integer> validateAndGetQuantities(String ndcNbr, Map<String, Integer> previousQuantities) {
        try {
            Map<String, Integer> current = getPharmacyItemQuantities(ndcNbr);

            int prevOnHand = previousQuantities.get("on_hand_qty");
            int currOnHand = current.get("on_hand_qty");
            int prevAllocated = previousQuantities.get("allocated_fill_qty");
            int currAllocated = current.get("allocated_fill_qty");

            Reporter.log("Previous: on_hand_qty=" + prevOnHand + ", allocated_fill_qty=" + prevAllocated);
            Reporter.log("Current: on_hand_qty=" + currOnHand + ", allocated_fill_qty=" + currAllocated);

            boolean onHandChanged = currOnHand != prevOnHand;
            boolean allocatedChanged = currAllocated != prevAllocated;

            if (onHandChanged) {
                Reporter.log("on_hand_qty changed by " + (currOnHand - prevOnHand));
            }
            if (allocatedChanged) {
                Reporter.log("allocated_fill_qty changed by " + (currAllocated - prevAllocated));
            }
            if (!onHandChanged && !allocatedChanged) {
                Reporter.log("INFO: No change in quantities for NDC " + ndcNbr);
            } else {
                Reporter.log("Validation passed - Quantities changed");
            }
            return current;
        } catch (Exception e) {
            Assert.fail("Validation failed for NDC " + ndcNbr + ": " + e.getMessage());
            return null;
        }
    }

    public int updateRxFillDate(int fillID, int NumberOfDays) {
        LocalDate newDate = LocalDate.now().minusDays(NumberOfDays);
        String updateQuery = "UPDATE rx_fill SET fill_date='" + newDate + "' WHERE rx_fill_id=" +fillID;
        try {
            return automationManager.getConnexusDB().executeUpdateQuery(updateQuery);
        }
        catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return 0;
    }



    public String getOrderDetails(String rxNbr) {

        String query = "select rx_fill_id from rx_order_detail where status_code != 20503 and rx_id in (select rx_id from rx where rx_nbr  = " + rxNbr +")";
        Map<String, Object> rxOrderInfo = automationManager.getConnexusDB().executeQuery(query);
        return rxOrderInfo.get("rx_fill_id").toString();
    }


    public boolean updateNarxCareRequirementParmTable(String restrictTypeValue, String restrictTypeCode, String issueAgencyCode) {
        String selectQuery = "select restrict_type_val from agency_rqmt_parm where restrict_type_code=\"" + restrictTypeCode + "\" and issue_agency_code=\"" + issueAgencyCode + "\"";
        Map<String, Object> result = automationManager.getConnexusDB().executeQuery(selectQuery);
        if (result != null && result.containsKey("restrict_type_val") && !result.get("restrict_type_val").toString().trim().equalsIgnoreCase(restrictTypeValue)) {
            String updateQuery = "update agency_rqmt_parm set restrict_type_val=\"" + restrictTypeValue + "\" where restrict_type_code=\"" + restrictTypeCode + "\" and issue_agency_code=\"" + issueAgencyCode + "\"";
            int rowsUpdated = automationManager.getConnexusDB().executeUpdateQuery(updateQuery);
            Reporter.log("Agency_rqmt_parm for restrict_type_val is set to " + restrictTypeValue + " where restrict_type_code is " + restrictTypeCode + " and issue_agency_code is " + issueAgencyCode);
            return rowsUpdated > 0;
        } else {
            return false;
        }
    }

    public Map<String, String> getErxXferResponseByPatientName(String lastName, String firstName) {
        Map<String, String> eventDetails = new HashMap<>();
        String query = "select rx_id, rx_response_id " +
                "from erx_xfer_request where patient_last_name = '" + lastName + "' and patient_first_name = '" + firstName + "'"+
                "order by create_ts desc limit 1";
        Reporter.log("query: " + query);
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        automationManager.performSleep(10);
        if (result != null && !result.isEmpty()) {
            Map<String, Object> row = result.get(0);
            eventDetails.put("rx_id", row.get("rx_id").toString());
            eventDetails.put("rx_response_id", row.get("rx_response_id").toString());
        }
        return eventDetails;
    }

    public String verifyRXTransfer(String response_ID){
        String query = "select rx_resp_type_code from raw_eltnc_rx_resp where rx_response_id=" + response_ID;
        Map<String, Object> rxOrderInfo = automationManager.getConnexusDB().executeQuery(query);
        return rxOrderInfo.get("rx_resp_type_code").toString();
    }

    public Map<String,String> verifyLoggedRXTransfer(String RX_ID){
        Map<String, String> eventDetails = new HashMap<>();
        String query = "select erx_xfer_msg_type, status_code from erx_xfer_request where rx_id=" + RX_ID + "order by create_ts desc limit 1";
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        if (result != null && !result.isEmpty()) {
            Map<String, Object> row = result.get(0);
            eventDetails.put("erx_xfer_msg_type", row.get("erx_xfer_msg_type").toString());
            automationManager.performSleep(10);
            eventDetails.put("status_code", row.get("status_code").toString());
        }
        return eventDetails;
    }


    public String verifyRXOrderDetail(String RX_ID){
        // Sanitize RX_ID parameter to prevent SQL injection
        long rxIdValue;
        try {
            rxIdValue = Long.parseLong(RX_ID.trim());
        } catch (NumberFormatException e) {
            Log.info("Invalid RX_ID parameter: " + RX_ID);
            throw new IllegalArgumentException("Invalid RX_ID value: " + RX_ID, e);
        }

        String query = "select next_work_que_code from rx_order_detail where rx_id=" + rxIdValue;
        Map<String, Object> rxOrderInfo = automationManager.getConnexusDB().executeQuery(query);
        return rxOrderInfo.get("next_work_que_code").toString();
    }

    public Map<String, String> getErxXferRequestByPatientName(String lastName, String firstName) {
        Map<String, String> eventDetails = new HashMap<>();
        String query = "select rx_id, rx_request_id"  + " from erx_xfer_request where patient_last_name = '" + lastName + "' and patient_first_name = '" + firstName + "'" +
                "order by create_ts desc limit 1";
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        if (result != null && !result.isEmpty()) {
            Map<String, Object> row = result.get(0);
            eventDetails.put("rx_id", row.get("rx_id").toString());
            eventDetails.put("rx_request_id", row.get("rx_request_id").toString());
        }
        return eventDetails;
    }

    public String verifyelthncRxrequest(String request_id){
        String query = "select rx_rqst_type_code from eltnc_rx_request where rx_request_id=" + request_id;
        Map<String, Object> rxOrderInfo = automationManager.getConnexusDB().executeQuery(query);
        return rxOrderInfo.get("rx_rqst_type_code").toString();
    }

    public String verifyRXOrderDetails(String RX_ID) {
        // Sanitize RX_ID parameter to prevent SQL injection
        long rxIdValue;
        try {
            rxIdValue = Long.parseLong(RX_ID.trim());
        } catch (NumberFormatException e) {
            Log.info("Invalid RX_ID parameter: " + RX_ID);
            throw new IllegalArgumentException("Invalid RX_ID value: " + RX_ID, e);
        }

        String query = "select order_id from rx_order_detail where rx_id=" + rxIdValue;
        Map<String, Object> rxOrderInfo = automationManager.getConnexusDB().executeQuery(query);
        return rxOrderInfo.get("order_id").toString();
    }

    public Map<String,String> verifyRXProblemCodeandStatus(String order_id) {
        Map<String, String> eventDetails = new HashMap<>();
        String query = "select phm_problem_code, problem_stat_code from rx_ord_dtl_problem where order_id="+ order_id + "order by create_ts desc limit 1";
        List<Map<String, Object>> result = automationManager.getConnexusDB().executeQueryForList(query);
        if (result != null && !result.isEmpty()) {
            Map<String, Object> row = result.get(0);
            eventDetails.put("phm_problem_code", row.get("phm_problem_code").toString());
            eventDetails.put("problem_stat_code", row.get("problem_stat_code").toString());
        }
        return eventDetails;
    }

    public List<Integer> getErxRxRequestIdsByPatientName(String lastName, String firstName) {
        List<Map<String, Object>> rows = getErxXferRequestsByPatientName(lastName, firstName);
        List<Integer> rxRequestIds = new ArrayList<>();
        if (rows != null) {
            for (Map<String, Object> row : rows) {
                Object val = row.get("rx_request_id");
                if (val instanceof Number) {
                    rxRequestIds.add(((Number) val).intValue());
                } else if (val != null) {
                    try {
                        rxRequestIds.add(Integer.parseInt(val.toString()));
                    } catch (NumberFormatException ignored) {
                        // skip non-numeric values
                    }
                }
            }
        }
        return rxRequestIds;
    }

    public List<Map<String, Object>> getErxXferRequestsByPatientName(String lastName, String firstName) {
        try {
            String ln = lastName.toUpperCase();
            String fn = firstName.toUpperCase();
            String query = "select rx_id, rx_request_id, erx_xfer_msg_type, phm_name, drug_description " + "from erx_xfer_request where patient_last_name = '" + ln + "' and patient_first_name = '" + fn + "' and rx_request_id is not null";
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB().executeQueryForList(query);
            if (resultSet != null) {
                return resultSet;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Map<String, Object>> getRxRequestTextByIds(List<Integer> rxrequestIds) {
        if (rxrequestIds == null || rxrequestIds.isEmpty()) {
            return new ArrayList<>();
        }
        String ids = rxrequestIds.stream()
                .map(String::valueOf)
                .collect(Collectors.joining(","));
        String query = "select rx_request_id,rx_request_txt " + "FROM raw_eltnc_rx_rqst " + "WHERE rx_request_id IN (" + ids + ")";
        return automationManager.getConnexusDB().executeQueryForList(query);
    }

    public int getRackNumber(int orderId) {
        String query = "select rack_nbr from customer_order where order_id=\"" + orderId + "\"";
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
        if (rxInfo == null || !rxInfo.containsKey("rack_nbr")) {
            return 0; // Default value when no record found
        }
        Object rackNbrObj = rxInfo.get("rack_nbr");
        if (rackNbrObj == null) {
            return 0; // Default value when value is null
        }
        return Integer.parseInt(rackNbrObj.toString());
    }

    /**
     * Gets device name from workstation_setting table.
     * Query: select wrkstatn_host_name from workstation_setting where setting_code_id in (13018);
     * @return device name or null if not found
     */
    public String getDeviceNameFromWorkstationSetting() {
        try {
            String query = "select wrkstatn_host_name from workstation_setting where setting_code_id in (13018)";
            String deviceName = automationManager.getConnexusDB(siteId).getScalar(query, String.class);
            if (deviceName != null && !deviceName.trim().isEmpty()) {
                Reporter.log("Device name fetched from database: " + deviceName.trim());
                return deviceName.trim();
            }
        } catch (Exception e) {
            Reporter.log("Failed to fetch device name from database: " + e.getMessage());
        }
        return null;
    }

    /**
     * Assigns a WCF bag to an order by updating rx_2t_informix_rx_order_detail table
     * @param storeId - Store number
     * @param rxFillId - Rx Fill ID
     * @param bagNumber - Bag number to assign
     * @param userName - User ID performing the assignment
     * @param deviceName - Device/workstation name
     * @return number of rows updated
     * Author: Pranav (vn58m66)
     */
    public int assignWCFBagToOrder(int storeId, int rxFillId, int bagNumber, String userName, String deviceName) {
        String updateQuery = String.format(
                "UPDATE rx21c:informix.rx_order_detail SET " +
                        "tote_nbr = %d, " +
                        "wrkstatn_host_name = '%s', " +
                        "assigned_userid = '%s' " +
                        "WHERE rx_fill_id = %d",
                bagNumber, deviceName, userName, rxFillId
        );

        Reporter.log("Executing update query: " + updateQuery);
        try {
            int rowsUpdated = automationManager.getConnexusDB(storeId).executeUpdateQuery(updateQuery);
            if (rowsUpdated > 0) {
                Reporter.log("Successfully assigned bag " + bagNumber + " to rxFillId " + rxFillId);
                Reporter.log("DB update successful - Rows affected: " + rowsUpdated);
            } else {
                Reporter.log("Failed to assign bag - No rows updated");
            }
            return rowsUpdated;
        } catch (Exception e) {
            Reporter.log("Failed to assign WCF bag: " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
    }

    public List<Map<String, Object>> getRxOrderDetailProblem(String orderId) {
        String query = "select problem_stat_code, phm_problem_code, problem_comment from rx_ord_dtl_problem where order_id = '" + orderId + "'";
        return automationManager.getConnexusDB().executeQueryForList(query);
    }

    public List<Integer> getRxOrderStatCode(String orderId) {
        List<Map<String, Object>> rows = getRxOrderDetailProblem(orderId);
        List<Integer> problemStatCode = new ArrayList<>();
        if (rows != null) {
            for (Map<String, Object> row : rows) {
                Object val = row.get("problem_stat_code");
                if (val != null) {
                    try {
                        problemStatCode.add(Integer.parseInt(val.toString()));
                    } catch (NumberFormatException ignored) {
                        // skip non-numeric values
                    }
                }
            }
        }
        return problemStatCode;
    }

    public List<String> getProblemComment(String orderId) {
        List<Map<String, Object>> rows = getRxOrderDetailProblem(orderId);
        List<String> problemSComment = new ArrayList<>();
        if (rows != null) {
            for (Map<String, Object> row : rows) {
                Object val = row.get("problem_comment");
                if (val != null) {
                    try {
                        problemSComment.add(((String)val).toString());
                    } catch (NumberFormatException ignored) {
                        // skip non-numeric values
                    }
                }
            }
        }
        return problemSComment;
    }

    public List<Integer> getRxOrderProblemCode(String orderId) {
        List<Map<String, Object>> rows = getRxOrderDetailProblem(orderId);
        List<Integer> problemCode = new ArrayList<>();
        if (rows != null) {
            for (Map<String, Object> row : rows) {
                Object val = row.get("phm_problem_code");
                if (val != null) {
                    try {
                        problemCode.add(Integer.parseInt(val.toString()));
                    } catch (NumberFormatException ignored) {
                        // skip non-numeric values
                    }
                }
            }
        }
        return problemCode;
    }

    public List<Map<String, Object>> reponseId(String lastname, String firstname) {
        String query = "select rx_response_id from erx_xfer_request where patient_last_name = '" + lastname + "' and patient_first_name = '" + firstname + "' and rx_response_id is not null";
        Reporter.log("Query " + query);
        return automationManager.getConnexusDB().executeQueryForList(query);
    }

    public List<Integer> getResponseIdByName(String lastname, String firstname) {
        List<Map<String, Object>> rows = reponseId(lastname, firstname);
        List<Integer> reponseIds = new ArrayList<>();
        if (rows != null) {
            for (Map<String, Object> row : rows) {
                Object val = row.get("rx_response_id");
                if (val != null) {
                    try {
                        reponseIds.add(Integer.parseInt(val.toString()));
                    } catch (NumberFormatException ignored) {
                        // skip non-numeric values
                    }
                }
            }
        }
        return reponseIds;
    }

    public Map<String, Object> getRawEtlnRxResp(int storeNumber, int rx_response_id) {
        String query = "select rx_resp_type_code, response_stat_code from raw_eltnc_rx_resp where rx_response_id = '" + rx_response_id + "';";
        return automationManager.getConnexusDB(storeNumber).executeQuery(query);
    }

    public List<Map<String, Object>> getErxXferReqByRxId(String rx_Id) {
        try {
            String selectQuery = "select erx_xfer_msg_type, status_code from erx_xfer_request where rx_id = '" + rx_Id + "' and erx_xfer_msg_type is not null;";
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB().executeQueryForList(selectQuery);
            if (resultSet != null) {
                return resultSet;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }


    public List<Integer> getErxXferReqMsgType(String rx_Id) {
        List<Map<String, Object>> rows = getErxXferReqByRxId(rx_Id);
        List<Integer> xfer_msg_type = new ArrayList<>();
        if (rows != null) {
            for (Map<String, Object> row : rows) {
                Object val = row.get("erx_xfer_msg_type");
                if (val != null) {
                    try {
                        xfer_msg_type.add(Integer.parseInt(val.toString()));
                    } catch (NumberFormatException ignored) {
                        // skip non-numeric values
                    }
                }
            }
        }
        return xfer_msg_type;
    }

    public List<Integer> getErxXferReqMStatusMsg(String rx_Id) {
        List<Map<String, Object>> rows = getErxXferReqByRxId(rx_Id);
        List<Integer> xfer_status_code = new ArrayList<>();
        if (rows != null) {
            for (Map<String, Object> row : rows) {
                Object val = row.get("status_code");
                if (val != null) {
                    try {
                        xfer_status_code.add(Integer.parseInt(val.toString()));
                    } catch (NumberFormatException ignored) {
                        // skip non-numeric values
                    }
                }
            }
        }
        return xfer_status_code;
    }

    public List<Map<String, Object>> getOrderDetailsByOrderId(String orderId) {
        try {
            String query = "select status_code from rx_order_detail where order_id=" + orderId + ";";
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB().executeQueryForList(query);
            if (resultSet != null) {
                return resultSet;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Integer> orderDetailsStatMutliRx(String orderId) {
        List<Map<String, Object>> rows = getOrderDetailsByOrderId(orderId);
        List<Integer> stat_Code = new ArrayList<>();
        if (rows != null) {
            for (Map<String, Object> row : rows) {
                Object val = row.get("status_code");
                if (val != null) {
                    try {
                        stat_Code.add(Integer.parseInt(val.toString()));
                    } catch (NumberFormatException ignored) {
                        // skip non-numeric values
                    }
                }
            }
        }
        return stat_Code;
    }

    public boolean isManualMTRItemFilled()
    {
        try {
            String selectQuery = "SELECT min(Date(piia.adjmt_ts)) mtr_date\n" +
                    " FROM pharmacy_offering:phm_item_inv_adjmt piia, pharmacy_offering:pharmacy_item pi\n" +
                    " WHERE piia.adjmt_type_code IN (6603, 6606)\n" +
                    " AND piia.adjmt_status_code IN (6701, 6705)\n" +
                    " AND (piia.adjmt_qty / (pi.inner_pack_qty * pi.outer_pack_qty)) >= 1.0\n" +
                    " AND pi.mds_fam_id = piia.mds_fam_id\n" +
                    " AND pi.dept_nbr != 38\n" +
                    " AND Date(piia.adjmt_ts) = Date(CURRENT) - 1 UNITS DAY\n" +
                    " AND piia.adjmt_ref_nbr IS NULL" ;
            List<Map<String, Object>> resultSet;
            resultSet = automationManager.getConnexusDB().executeQueryForList(selectQuery);
            if (resultSet != null && !resultSet.isEmpty() && (resultSet.get(0).get("mtr_date") != null)) {
                isTaskOrderCreated=false;
                Reporter.log("Manual MTR items is filled");
            }
            else
            {
                String userid=propertyReader.getProperty("cnx.ho.userName");
                String eventTaskDesc="Print Need to MTR report and complete manual MTR";
                String createMTRQuery ="call CreateTaskOrder(214,201,0, \"" + userid + "\" , \"" + eventTaskDesc + "\")";
                automationManager.getConnexusDB().executeUpdateQuery(createMTRQuery);
                isTaskOrderCreated=true;
            }
            return true;
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Queries the token_mapping table using fulfillmentId as token
     * and returns the related_id which is the new rxFillId
     * @param fulfillmentId - The originalFulfillmentId (token) to query
     * @return int - The related_id (new rxFillId) from token_mapping table
     */
    public int getRelatedFillIdFromTokenMapping(String fulfillmentId) {
        String query = "SELECT related_id FROM token_mapping WHERE token = '" + fulfillmentId + "'";
        Reporter.log("Executing token_mapping query: " + query);
        Map<String, Object> result = automationManager.getConnexusDB().executeQuery(query);
        if (result != null && result.get("related_id") != null) {
            int relatedFillId = Integer.parseInt(result.get("related_id").toString());
            Reporter.log("Found related_id from token_mapping: " + relatedFillId);
            return relatedFillId;
        }
        throw new RuntimeException("No related_id found in token_mapping for token: " + fulfillmentId);
    }

    /**
     * Gets both fill ID and order ID in a single query for better performance
     * @param rxNbr - Prescription number
     * @return Map containing both rx_fill_id and order_id
     */
    public Map<String, Object> getFillAndOrderIds(String rxNbr) {
        String query = "select max(rx_fill_id) as rx_fill_id, max(order_id) as order_id " +
                "from rx_order_detail where rx_id =(select rx_id from rx where rx_nbr=\"" + rxNbr + "\")";
        Map<String, Object> result = automationManager.getConnexusDB().executeQuery(query);
        return result;
    }

    public List<Map<String, Object>> getRecentCreateRecords() {
        try {
            String query = "SELECT * FROM rx_transfer_fill ORDER BY transfer_ts DESC limit 2";
            return automationManager.getConnexusDB().executeQueryForList(query);
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    /*
     * Fetches the second rx_fill_id for the given rxNbr
     * @return second rx_fill_id
     **/
    public Integer fetchSecondRxFillId(int siteId, String rxNbr) {
        int rxId = automationManager.getConnexusDB(siteId).getScalar("select rx_id from rx where rx_nbr = " + rxNbr, Integer.class);
        Assert.assertTrue(rxId > 0, "rx_id not found for rxNbr: " + rxNbr);
        Integer secondRxFillId = automationManager.getConnexusDB(siteId).getScalar(
                "select rx_fill_id from rx_order_detail where rx_id = " + rxId + " order by rx_fill_id desc limit 1", Integer.class);
        Assert.assertNotNull(secondRxFillId, "Second rx_fill_id not found for rxNbr: " + rxNbr);
        return secondRxFillId;
    }

    /*
     * Method to get the latest rx_request_id from eltnc_rx_request table
     * */
    public int getRxRequestId() {
        siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        String query = "select first 1 rx_request_id from eltnc_rx_request order by rx_request_id desc;";
        Map<String, Object> result = automationManager.getConnexusDB(siteId).executeQuery(query);
        if (result != null && result.get("rx_request_id") != null) {
            int requestId = Integer.parseInt(result.get("rx_request_id").toString());
            return requestId;
        }
        return 0;
    }

}

