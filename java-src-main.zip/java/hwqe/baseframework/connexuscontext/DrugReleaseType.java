package hwqe.baseframework.connexuscontext;

public enum DrugReleaseType {
    NONE(1), CD(2), CR(3), DR(4), EC(5),
    ER(6), EX(7), SR(8), XL(9), XR(10), XS(11);

    private int drugReleaseType;

    DrugReleaseType(int type) {
        this.drugReleaseType = type;
    }

    public int getDrugReleaseType() {
        return drugReleaseType;
    }

}
