package hwqe.baseframework.connexuscontext;

import lombok.Getter;
import lombok.Setter;
import org.openqa.selenium.Keys;

@Getter
@Setter
public class ActionCommand {
    private String text;
    private Keys[] keys;

    public ActionCommand(String name, Keys... keys) {
        this.text = name;
        this.keys = keys;
    }

    public ActionCommand(String text) {
        this.text = text;
    }

    public ActionCommand(Keys... keys) {
        this.keys = keys;
    }
}
