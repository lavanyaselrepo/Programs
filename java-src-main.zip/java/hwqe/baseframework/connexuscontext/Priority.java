package hwqe.baseframework.connexuscontext;

public enum Priority {
    InStore("In-Store"),
    DRCallIn("Dr Call In"),
    DriveThru("Drive Thru"),
    Future("Future"),
    Critical("Critical"),
    Today("Today");

    private String priority;

    Priority(String priority) {
        this.priority = priority;
    }

    public String getPriority() {
        return this.priority;
    }
}
