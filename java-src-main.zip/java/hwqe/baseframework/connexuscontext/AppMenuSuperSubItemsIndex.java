package hwqe.baseframework.connexuscontext;


public enum AppMenuSuperSubItemsIndex {

    //Reports --> Inventory reports -->CII Reports
    CII_DIGITAL_LOGBOOK(0),
    CII_DRUG_SUMMARY(1),
    CII_MONTHLY_AUDIT(2),
    RETURN_TO_INMAR_MCKES(3),
    CII_ADJUSTMENTS(4),

    //Reports --> Inventory reports -->Drug Movement
    BY_DRUG_SCHEDULE(0),
    BY_NDC_NAMES(1),
    BY_GPI(2),
    COMP_DRUG_MOVEMENT(3),
    TOP_BOTTOM_DRUG(4),

    //Reports --> Inventory reports -->Replenishment reports
    REPLENISHMENT_AVAILABLE_REPORT(0),
    REPLENISHMENT_UNAVAILABLE_REPORT(1),

    //Reports --> Inventory reports -->Return to stack reports
    AMBER_VIAL_INVENTORY(0),
    AMBER_VIAL_ACTIVE_INVENTORY(1),
    AMBER_VIAL_EXPIRED_INVENTORY(2),
    AMBER_VIAL_DEACTIVATED_VIALS(3),

    //Reports --> Pickup/POS reports -->Daily register reports
    LOCAL_TP_AND_CHARGE_BY_REG_ACCT(0),
    TP_RECEIVABLES_BYREG_ACCT(1);

    private final int appMenu;

    AppMenuSuperSubItemsIndex(int appMenu) {
        this.appMenu = appMenu;
    }

    public int getAppMenu() {
        return appMenu;
    }
}
