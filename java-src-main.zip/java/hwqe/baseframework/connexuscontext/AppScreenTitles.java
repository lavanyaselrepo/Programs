package hwqe.baseframework.connexuscontext;

public enum AppScreenTitles {
    CONNEXUS_HOME_SCREEN("Wal-Mart Stores, Inc Connexus [USA]"),
    DROPOFF("Wal*Mart Connexus - [Drop-Off]"),
    CONTACT_CUSTOMER_RESOLUTION("Contact Customer"),
    CONTACT_PRESCRIBER_RESOLUTION("Contact Prescriber"),
    MANUAL_RESOLUTION("Manual"),
    ILLEGIBLE_IMAGE("Illegible"),
    RX_LOOKUP("Wal*Mart Connexus - [Rx LookUp]");

    private final String connexusScreenTitle;

    AppScreenTitles(String connexusScreenTitle) {
        this.connexusScreenTitle = connexusScreenTitle;
    }

    public String getScreenTitle() {
        return connexusScreenTitle;
    }
}
