package hwqe.baseframework.connexuscontext;

public enum RxOriginType {
    OriginalRx("ORIGINAL RX"),
    Phone("PHONE (Prescriber Only)"),
    Fax("FAX (Prescriber Only)"),
    Pharmacy("PHARMACY (RPH NPI)"),
    Transfer("TRANSFER"),
    Erx_transfer("ERX RXTRANSFER"),
    No_associated_prescription("NO ASSOCIATED PRESCRIPTION");

    private String rxOriginType;

    RxOriginType(String rxOriginType) {
        this.rxOriginType = rxOriginType;
    }

    public String getRxOriginType() {
        return this.rxOriginType;
    }
}