package hwqe.baseframework.connexuscontext;

public enum AppApiEndPoints {
    PRODUCT_SEARCH("https://qa.psdruginformation.prod.us.walmart.net/v1/searchandlookup/lookup/");

    private final String url;

    AppApiEndPoints(String url) {
        this.url = url;
    }

    public String getAppApiEndPoints() {
        return url;
    }
}
