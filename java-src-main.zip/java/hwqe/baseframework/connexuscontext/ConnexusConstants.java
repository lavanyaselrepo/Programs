package hwqe.baseframework.connexuscontext;

public class ConnexusConstants {

    public static final String TECHNINICIAN_USER_NAME = "cnx.tech.userName";
    public static final String TECHNINICIAN_P = "cnx.tech.p";
    public static final String HOME_OFFICE_USER_NAME = "cnx.ho.userName";
    public static final String HOME_OFFICE_P = "cnx.ho.p";
    public static final String RPH_USER_NAME = "cnx.rph.userName";
    public static final String RPH_P = "cnx.rph.p";


    // properties constants
    public static final String CHANGE_STORE_NUMBER_SITE_ID = "cnx.changeStore";
    public static final String CHANGE_STORE_RPH_USER_NAME = "cnx.changeStore.userName";
    public static final String CHANGE_STORE_RPH_P = "cnx.changeStore.p";

    // Test Data constants
    public static final String PATIENT_FIRST_NAME = "PATIENT_FIRST_NAME";
    public static final String PATIENT_LAST_NAME = "PATIENT_LAST_NAME";
    public static final String PRESCRIBER_FIRST_NAME = "PRESCRIBER_FIRST_NAME";
    public static final String PRESCRIBER_LAST_NAME = "PRESCRIBER_LAST_NAME";
    public static final String PRODUCT_NAME = "PRODUCT_NAME";
    public static final String COMPOUND_NAME = "COMPOUND_NAME";
    public static final String PHARMACY_NAME = "PHARMACY_NAME";
    public static final String RX_NAME_OR_NUMBER = "RX_NAME_OR_NUMBER";
    public static final String PLAN_NAME_OR_CARRER = "PLAN_NAME_OR_CARRER";
    public static final String IMZ_EVENT = "IMZ_EVENT";
    public static final String FACILITY_NAME="FACILITY001";
    public static final String FACILITY_ID="98765421";

    public static final String APP_CONSTANT_DURCHECK_NAME = "Check DUR";
    public static final String APP_CONSTANT_INPUT_QUICK_ACCESS_ICON = "2";
    public static final String APP_CONSTANT_4POINT_QUICK_ACCESS_ICON = "3";
    public static final String APP_CONSTANT_RESOLUTION_QUICK_ACCESS_ICON = "4";
    public static final String APP_CONSTANT_VISUALLYVERIFY_QUICK_ACCESS_ICON = "5";

    //Constants for WAIT TIME in seconds and MAX Count.
    public static final int WAIT_TIMEOUT_5 = 5;
    public static final int WAIT_TIMEOUT_10 = 10;
    public static final int WAIT_TIMEOUT_20 = 20;
    public static final int WAIT_TIMEOUT_30 = 30;
    public static final int WAIT_TIMEOUT_40 = 40;
    public static final int WAIT_TIMEOUT_50 = 50;
    public static final int WAIT_TIMEOUT_60 = 60;
    public static final int WAIT_TIMEOUT_120 = 120;
    public static final int MAX_COUNT_2 = 2;
    public static final int MAX_COUNT_3 = 3;
    public static final int MAX_COUNT_4 = 4;
    public static final int MAX_COUNT_5 = 5;
    public static final int IMAGE_COUNT = 8;
    public static final String PATIENTEDUCATIONTEXTDETAILS = "Read this medicine information sheet carefully each time you get this medicine filled. You must carefully read the \"Consumer Information Use and Disclaimer\" below in order to understand and correctly use this information.";
}
