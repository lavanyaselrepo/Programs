package hwqe.baseframework.connexuscontext;

import io.appium.java_client.android.nativekey.PressesKey;
import org.openqa.selenium.Keys;

import java.awt.event.KeyEvent;

public enum AppShortcuts {
    DROP_OFF(new ActionCommand("d", Keys.CONTROL)),
    PRINT(new ActionCommand("p", Keys.CONTROL)),
    EXIT(new ActionCommand(Keys.F4, Keys.ALT)),
    CHECK_WORK_QUEUE(new ActionCommand(Keys.F5)),
    PICKUP(new ActionCommand(Keys.F11)),
    QUICK_QUOTE(new ActionCommand(Keys.F8)),
    MODIFY_DETAILS(new ActionCommand(Keys.F9)),
    FAX_INBOX(new ActionCommand("x", Keys.CONTROL)),
    FAX_ERROR(new ActionCommand("o", Keys.CONTROL)),
    FAX_OUTBOX(new ActionCommand("o", Keys.CONTROL)),
    TASKS(new ActionCommand("t", Keys.CONTROL)),
    FOUR_POINT(new ActionCommand("4", Keys.CONTROL)),
    VISUAL_VERIFY(new ActionCommand("y", Keys.CONTROL)),
    COUNSELING(new ActionCommand("g", Keys.CONTROL)),
    INPUT(new ActionCommand("i", Keys.CONTROL)),
    RESOLUTION(new ActionCommand("r", Keys.CONTROL)),
    PATIENT_SEARCH(new ActionCommand("p", Keys.CONTROL, Keys.SHIFT)),
    PRODUCT(new ActionCommand("d", Keys.CONTROL, Keys.SHIFT)),
    COMPOUND(new ActionCommand("c", Keys.CONTROL, Keys.SHIFT)),
    PHARMACY(new ActionCommand("h", Keys.CONTROL, Keys.SHIFT)),
    RX(new ActionCommand("r", Keys.CONTROL, Keys.SHIFT)),
    ORDER(new ActionCommand("o", Keys.CONTROL, Keys.SHIFT)),
    PLAN(new ActionCommand("n", Keys.CONTROL, Keys.SHIFT)),
    CLAIM(new ActionCommand("l", Keys.CONTROL, Keys.SHIFT)),
    IMZ_EVENT(new ActionCommand("i", Keys.CONTROL, Keys.SHIFT)),
    PATIENT_ELIGIBILITY(new ActionCommand("e", Keys.CONTROL, Keys.SHIFT)),
    PRESCRIBER(new ActionCommand("b", Keys.CONTROL, Keys.SHIFT)),
    NEW_COMPOUND(new ActionCommand("c", Keys.ALT, Keys.SHIFT)),
    NEW_PHARMACY(new ActionCommand("h", Keys.ALT, Keys.SHIFT)),
    NEW_IMZ_EVENT(new ActionCommand("i", Keys.ALT, Keys.SHIFT)),
    NEW_PRESCRIBER(new ActionCommand("b", Keys.ALT, Keys.SHIFT)),
    EXIT_PMS(new ActionCommand("e", Keys.ALT)),
    RX_LOOKUP(new ActionCommand("r", Keys.CONTROL, Keys.SHIFT));


    private final ActionCommand appShortcuts;

    AppShortcuts(ActionCommand appShortcuts) {
        this.appShortcuts = appShortcuts;
    }

    public ActionCommand getAppShortcuts() {
        return appShortcuts;
    }

    public ActionCommand getPrimaryAppShortcuts() {
        if ("RX".equals(this.name())) {
            return new ActionCommand(Keys.F7);
        } else if ("ORDER".equals(this.name())) {
            return new ActionCommand(Keys.F6);
        }
        return appShortcuts;
    }
}
