package hwqe.baseframework.connexuscontext;

import org.openqa.selenium.Keys;

import java.util.HashMap;
import java.util.Map;

public enum SearchItem {
    PATIENT("Patient"),
    PRESCRIBER("Prescriber"),
    NEW_PRESCRIBER("Prescriber"),
    PRODUCT("Product"),
    COMPOUND("Compound"),
    NEW_COMPOUND("Compound"),
    PHARMACY("Pharmacy"),
    NEW_PHARMACY("Pharmacy"),
    RX("Rx"),
    ORDER("Order"),
    PLAN("Plan"),
    CLAIM("Claim"),
    PATIENT_ELIGIBILITY("PatientEligibility"),
    IMZ_EVENT("Event"),
    NEW_IMZ_EVENT("Event"),
    PRINT_SETUP("Print"),
    CHECK_WORK_QUEUE("Check Work"),
    EXPLAIN_DRUG_SUB("Drug Selection"),
    QUICK_QUOTE("Quick Quote"),
    NEW_PRESCRIPTION("New Prescription"),
    TRANSFER_REQUEST("Transfer Request"),
    STORE_SETTINGS("Store Settings"),
    IMMUNIZATION_SETTINGS("Immunization Settings"),
    NALOXONE_SETTINGS("Naloxone Settings"),
    RESOLUTION_SETTINGS("Resolution Option"),
    BEEPER_MAINTENANCE("Assign Beeper Number"),
    DRUG_INTERACTION("Interaction Check"),
    QUICK_KEYS("Quick Key Setup"),
    SIGNATURE_IMAGE("Scan Signature Slip"),
    POS_ORDERS("POS Orders"),
    REPLENISHMENT_REVIEW("Replenishment Review"),
    C2_DRUG_ORDER_APPLY("Unapplied C2 Orders"),
    PRINT_PAYROLL_WORKSHEET("Payroll WorkSheet"),
    TEMP_USER_SETUP("Add Temporary User"),
    URGENT_MESSAGES("Pharmacy Immediate Action  Messages"),
    PRINT("Print"),
    CYCLE_COUNT("Cycle Count Report"),
    PHARMACY_MESSAGES("Pharmacy Immediate Action  Messages"),
    ABOUT("About Connexus"),

    DRUG_MOVEMENT_BY_DRUG_SCHEDULE("Drug Movement Schedule - Detailed Report"),
    REPLENISHMENT_UNAVAILABLE_REPORT("Replenishment UnAvailable Report"),
    REPLENISHMENT_AVAILABLE_REPORT("Replenishment Available Report"),
    DRUG_MOVEMENT_TOP_BOTTOM_DRUG("Top/Bottom Drug Summary Report"),
    DRUG_MOVEMENT_COMP_DRUG("Competitive Drug Movement Report"),
    DRUG_MOVEMENT_BY_GPI("Drug Movement GPI - Detailed Report"),
    DRUG_MOVEMENT_BY_NDC_NAME("Drug Movement - Detailed Report"),
    AMBER_VIAL_INVENTORY("AMBER VIAL INVENTORY"),
    AMBER_VIAL_ACTIVE_INVENTORY("Amber Vial Active Inventory"),
    AMBER_VIAL_DEACTIVATED_INVENTORY("Deactivated  Amber Vials Date Selection"),
    AMBER_VIAL_EXPIRED_INVENTORY("Amber Vials Near Expiration"),
    HUNDRED_DAY_DRUG_NOT_USED("100 Day Drugs Not Used"),
    COMP_DRUG_PRICING("Competititve Drug Price Report"),
    CURRENT_ONHAND_INVENTORY("OnHand Inventory - Detailed Report"),
    DRUGS_GREATERTHAN_$1000("Drugs Greater Than $1000"),
    DRUG_RECALL("Drug ReCall Report"),
    INVENTORY_ADJUSTMENT("OnHand Changes Report"),
    CONTROLLED_SUBSTANCE_INVENTORY("Controlled Substance Inventory Report"),
    VIEW_DRUG_ORDER("View Drug Order"),
    EASY_PAY_PATIENT_SUMMARY("Easy Pay Report"),
    EASY_PAY_STORE_SUMMARY("Easy Pay Report"),
    DAILY_AUDIT_LISTING("Daily Audit Listing"),
    MISSED_OPPORTUNITIES_REPORT("Missed Opportunities Report"),
    PHARMACY_BUSINESS_SUMMARY("Pharmacy Business Summary"),
    ORDER_COMPLETION_PERFORMANCE("Order Completion Performance"),
    LOG_COPY_LABEL_ACTIVITY("Log Copy Label Activity Report"),
    LOG_COPY_LABEL_STATUS("Log Copy Label Status Report"),
    REPRINT_FILE_LABEL("Reprint File Label"),
    HIPAA_ACCOUNTING_OF_DISCLOSURE("HIPAA - Accounting Of Disclosure"),
    HIPAA_DESIGNATED_RECORDSET_REPORT("HIPAA - Designated Record Set"),
    HIPAA_INSPECTION_LOG("HIPAA Inspection Log - Manual"),
    HIPAA_INSURANCE_AUDITING("Insurance Auditing"),
    HIPAA_MEDICAL_EXPENSE_SUMMARY("Medical Expense"),
    HIPAA_RECORDS_REQUEST("HIPAA - Records Request"),
    DAILY_4POINT_CHECK("Daily 4Pt Check Report"),
    DAILY_VISUALVERIFY_CHECK("Daily Visual Verify Check Report"),
    ONLINE_INCIDENT_REPORTING("Order Completion Performance"),
    PHARMACIST_REPORTS_COUNSELING("Patient Counsel"),
    INPUT_INCORRECT_ENTRIES("Input - Incorrect Entries and Corrections"),
    FOURPOINT_RPH_CORRECTIONS("RPh 4PT Correction"),
    USER_NAME_AND_ID("User Name and ID Report"),
    REGULATORY_PATIENT_PROFILE_REPORT("Regulatory Patient Profile Report"),
    PHARMACIST_ACTIVITY_REPORT("Pharmacist Activity Report"),
    AUTO_CAPTURE_AUTO_CANCEL("Auto Capture- Auto Cancel Report  "),
    WILL_CALL_BIN_REPORT("Will Call Bin - Detail Report"),
    BAGGING_DETAILS_REPORT("Bagging Detail Report"),
    POS_PENDING_ACTION_REPORT("PENDING ACTION REPORT"),
    POS_DISCREPANCY("POS Discrepancy Report Dialog "),
    LOCAL_TP_AND_CHARGE_BY_REG_ACCT_XXX("Third Party Receivables"),
    TP_RECEIVABLE_BY_REG_ACCT_XXX("Third Party Receivables"),
    CANCEL_FILL_REPORT("Cancel Fill Report"),
    RX_SHIPMENT_TRACKING("Rx Shipment Tracking"),
    AUTO_FILL_REPORT("Auto Refill Utilization Report"),
    COMPLIANCE_REPORT("Compliance Report"),
    DUR_OVERRIDE_SUMMARY("DUR Override Report"),
    ON_HOLD_REPORT("Rx On Hold Report"),
    WAIT_FOR_DRUG_ORDER_REPORT("Wait For Drug Order Report"),
    PARTIAL_FILL_REPORT("Partial Fill Detailed Report"),
    TRANSFER_REPORT("Transfer Reports"),
    TRANSFER_HISTORY_REPORT("Transfer History"),
    OVERRIDE_REPORT("Override Report - POS and Modify Details"),
    PRICE_BELOW_COST_REPORT("Price Below Cost Report"),
    RX_ACTIVITY_REPORT("Activity Report"),
    CONTROLLED_SUBSTANCE_PICKUP_REPORT("Controlled Substance Pickup Report"),
    PATIENT_LANGUAGE_REPORT("Patient Language Report"),
    LEAFLET_COVER_SHEET_PRINTED_BY_LANGUAGE("Leaflet Cover Sheet Print By Language"),
    EMERGENCY_C2_FILLS_REPORT("Emergency C2 Fills Report"),
    EARLY_REFILL_FOR_CONTROLLED_DRUG_REPORT("Early Refills For Controlled Drugs Report"),
    EMERGENCY_FILL_REPORT("Emergency Fill Detailed Report"),
    XDEA_NUMBER_REPORT("XDEA Number Report"),
    PRESCRIPTION_IMAGE("PRINT IMAGES - RX IMAGE"),
    HIPAA_SIGNATURE("PRINT IMAGES - HIPAA SIGNATURES"),
    THIRD_PARTY_SIGNATURE("PRINT IMAGES - TP SIGNATURES"),
    EASY_PAY_SIGNATURE("Print Images - Easy Pay Signatures"),
    PSEUDOEPHEDRINE_SIGNATURE("PRINT IMAGES - PSEUDOEPHEDRINE SIGNATURES"),
    MEDICARE_AOB_SIGNATURE("PRINT IMAGES - MEDICARE AOB SIGNATURES"),
    CASH_PAYMENT_SIGNATURE("PRINT IMAGES - CASH PAYMENT SIGNATURES"),
    CONTROLLED_SUBSTANCE_PICKUP__SIGNATURE("PRINT IMAGES - CONTROLLED SUBSTANCE PICKUP SIGNATURES"),
    ANB_SIGNATURE("PRINT IMAGES - ABN SIGNATURES"),
    PATIENT_SUMMARY("Pseudoephedrine Report"),
    STORE_SUMMARY("Pseudoephedrine Report"),
    PRODUCT_SUMMAR("Pseudoephedrine Report"),
    MEDICARE_B_AUDIT_REPORT("MedicareB Audit"),
    OFLILNE_REVERSAL_REPORT("Offline Reversal Report"),
    TIRD_PARTY_SALSE_REPORT("Third Party Sales Analysis"),
    US_PAPERBILL_REPORT("US Paper Reports Main Menu"),
    PAPER_BILL_EXCEPTON_REPORT("Paper Bill Exception Report"),
    ROR_EXTERNAL_REPORT("PRINT IMAGES - TP SIGNATURES"),
    INTERNAL_ORDER_REPORT("Print Images - Easy Pay Signatures"),
    CONTROLLED_SUBSTANCE_ERX("PRINT IMAGES - PSEUDOEPHEDRINE SIGNATURES"),
    TEMP_USER_LOG("Temp User Report"),
    CONTROLLED_SEBSTANCE_RX_DETAILS("Controlled Substance Rx Details Report"),
    RX_MODIFICATION_LOG("Rx Modification Log Report"),
    ADUIT_INTERFERENCE_LOG("Audit Interference Log Report"),
    CONTROLLED_SUBSTANCE_ERX_LANDING_TIME_REPORT("Ctrl Subs ERx Landing Time Report"),
    AUTO_REFILL_ENROLLMENT_REPORT("Auto Refill Enrollment Report");


    private final String searchItem;

    SearchItem(String searchItem) {
        this.searchItem = searchItem;
    }

    public String getSearchItem() {
        return this.searchItem;
    }

    public static Map<ActionName, ActionCommand> getSearchItem(SearchItem searchFor, Map<String, String> inputData) {
        Map<ActionName, ActionCommand> searchItemConst = new HashMap<>();
        switch (searchFor) {
            case PATIENT:
                searchItemConst.put(ActionName.SEARCH_TEXT, new ActionCommand(inputData.get(ConnexusConstants.PATIENT_LAST_NAME)
                        + "," + inputData.get(ConnexusConstants.PATIENT_FIRST_NAME)));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("1"));
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY1, AppShortcuts.PATIENT_SEARCH.getAppShortcuts());
                break;
            case PRESCRIBER:
                searchItemConst.put(ActionName.SEARCH_TEXT, new ActionCommand(inputData.get(ConnexusConstants.PRESCRIBER_LAST_NAME)
                        + "," + inputData.get(ConnexusConstants.PRESCRIBER_FIRST_NAME)));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("2"));
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY1, AppShortcuts.PRESCRIBER.getAppShortcuts());
                break;
            case NEW_PRESCRIBER:
                searchItemConst.put(ActionName.TAB_COUNT, new ActionCommand("2"));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("1"));
                break;
            case PRODUCT:
                searchItemConst.put(ActionName.SEARCH_TEXT, new ActionCommand(inputData.get(ConnexusConstants.PRODUCT_NAME)));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("3"));
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY1, AppShortcuts.PRODUCT.getAppShortcuts());
                break;
            case COMPOUND:
                searchItemConst.put(ActionName.SEARCH_TEXT, new ActionCommand(inputData.get(ConnexusConstants.COMPOUND_NAME)));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("4"));
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY1, AppShortcuts.COMPOUND.getAppShortcuts());
                break;
            case NEW_COMPOUND:
                searchItemConst.put(ActionName.TAB_COUNT, new ActionCommand("2"));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("2"));
                break;
            case PHARMACY:
                searchItemConst.put(ActionName.SEARCH_TEXT, new ActionCommand(inputData.get(ConnexusConstants.PHARMACY_NAME)));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("5"));
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY1, AppShortcuts.PHARMACY.getAppShortcuts());
                break;
            case NEW_PHARMACY:
                searchItemConst.put(ActionName.TAB_COUNT, new ActionCommand("2"));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("3"));
                break;
            case RX:
                searchItemConst.put(ActionName.SEARCH_TEXT, new ActionCommand(new ConnexusAppUtils().getRandomRxFromStoreDb()));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("6"));
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY1, AppShortcuts.RX.getAppShortcuts());
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY2, new ActionCommand(Keys.F7));
                break;
            case ORDER:
                searchItemConst.put(ActionName.SEARCH_TEXT, new ActionCommand(new ConnexusAppUtils().getRandomRxFromStoreDb()));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("7"));
                searchItemConst.put(ActionName.MENU_NAVIGATION, new ActionCommand(AppMenu.ORDER.getAppMenu()));
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY1, AppShortcuts.ORDER.getAppShortcuts());
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY2, new ActionCommand(Keys.F6));
                break;
            case PLAN:
                searchItemConst.put(ActionName.SEARCH_TEXT, new ActionCommand(inputData.get(ConnexusConstants.PLAN_NAME_OR_CARRER)));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("8"));
                searchItemConst.put(ActionName.MENU_NAVIGATION, new ActionCommand(AppMenu.PLAN.getAppMenu()));
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY1, AppShortcuts.PLAN.getAppShortcuts());
                break;
            case CLAIM:
                searchItemConst.put(ActionName.SEARCH_TEXT, new ActionCommand(inputData.get(ConnexusConstants.PATIENT_LAST_NAME)
                        + "," + inputData.get(ConnexusConstants.PATIENT_FIRST_NAME)));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("9"));
                searchItemConst.put(ActionName.MENU_NAVIGATION, new ActionCommand(AppMenu.CLAIM.getAppMenu()));
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY1, AppShortcuts.CLAIM.getAppShortcuts());
                break;
            case PATIENT_ELIGIBILITY:
                searchItemConst.put(ActionName.SEARCH_TEXT, new ActionCommand(inputData.get(ConnexusConstants.PATIENT_LAST_NAME)
                        + "," + inputData.get(ConnexusConstants.PATIENT_FIRST_NAME)));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("10"));
                searchItemConst.put(ActionName.MENU_NAVIGATION, new ActionCommand(AppMenu.PATIENT_ELIGIBILITY.getAppMenu()));
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY1, AppShortcuts.PATIENT_ELIGIBILITY.getAppShortcuts());
                break;
            case IMZ_EVENT:
                searchItemConst.put(ActionName.SEARCH_TEXT, new ActionCommand(inputData.get(ConnexusConstants.IMZ_EVENT)));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("11"));
                searchItemConst.put(ActionName.MENU_NAVIGATION, new ActionCommand(AppMenu.IMZ_EVENT.getAppMenu()));
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY1, AppShortcuts.IMZ_EVENT.getAppShortcuts());
                break;
            case CHECK_WORK_QUEUE:
                searchItemConst.put(ActionName.SHORTCUT_COMBO_KEY2, AppShortcuts.CHECK_WORK_QUEUE.getAppShortcuts());
                searchItemConst.put(ActionName.MENU_NAVIGATION, new ActionCommand(AppMenu.CHECK_WORK_QUEUE.getAppMenu()));
                searchItemConst.put(ActionName.TAB_COUNT, new ActionCommand("7"));
                break;
            case NEW_IMZ_EVENT:
                searchItemConst.put(ActionName.TAB_COUNT, new ActionCommand("2"));
                searchItemConst.put(ActionName.ARROW_DOWN_COUNT, new ActionCommand("4"));
                break;
            case PRINT:
                searchItemConst.put(ActionName.TAB_COUNT, new ActionCommand("2"));
                break;
            default:
        }
        return searchItemConst;
    }
}
