package hwqe.baseframework.connexuscontext;

public enum LeftBarWorkQueues {
        DROP_OFF_ICON("Drop-Off"),
        INPUT_ICON("Input"),

        RESOLUTION_ICON("Resolution"),

        RESOLUTION_TITLE("Third Party Rejection/Failure"),
        FOUR_POINT_ICON("4 Point Check"),
        FILL_ICON("Fill"),
        VISUAL_VERIFY_ICON("Visual Verify"),
        BAGGING_ICON("Bagging"),
        COUNSELING_ICON("Counseling"),
        SERVICE_ADMIN_ICON("Service Admin"),
        ACTION_ITEM_ICON("Action Items"),
        URGENT_MESSAGES_ICON("Urgent Messages");

        private final String leftBarWorkQueue;

        LeftBarWorkQueues(String leftBarWorkQueue) {
            this.leftBarWorkQueue = leftBarWorkQueue;
        }

        public String getLeftBarWorkQueues() {
            return leftBarWorkQueue;
        }
    }
