package hwqe.baseframework.connexuscontext;

public enum DispenseType {
    CounterPickup("Counter Pickup"),
    CurbsidePickup("Curbside Pickup"),
    MailDelivery("Mail Delivery");

    private final String dispenseType;

    DispenseType(String dispenseType) {
        this.dispenseType = dispenseType;
    }

    public String getDispenseType() {
        return this.dispenseType;
    }
}
