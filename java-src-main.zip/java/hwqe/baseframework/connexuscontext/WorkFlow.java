package hwqe.baseframework.connexuscontext;

import com.aventstack.extentreports.Status;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexusharnessapicontext.apimanager.CacheServiceManager;
import hwqe.baseframework.interfaces.IWorkFlow;
import hwqe.baseframework.models.datamodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.WindowsBasePage;
import hwqe.baseframework.models.pageobjectmodels.connexus.*;
import hwqe.baseframework.models.pageobjectmodels.connexus.MenuBar;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StackUtils;
import hwqe.baseframework.utilities.StringUtils;
import io.appium.java_client.AppiumBy;
import org.openjdk.tools.sjavac.Log;
import org.openqa.selenium.By;
import org.testng.Assert;
import java.awt.event.KeyEvent;
import java.awt.*;
import java.util.List;
import java.util.Map;

import static hwqe.baseframework.connexuswrapperapicontext.ConnexusAPIManager.scanPickUpCodeForCF;

@SuppressWarnings({
        "java:S1066",
        "java:S1192",
        "java:S3776",
})
public class WorkFlow extends WindowsBasePage implements IWorkFlow {
    //private final ConnexusManager cnxManager;
    private final By ok = AppiumBy.accessibilityId("2");
    public AutomationManager automationManager = AutomationManager.getInstance();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    PatientSearchPage patientSearchPage = new PatientSearchPage();
    PatientMaintenancePage patientMaintenancePage;
    InputPage inputPage = new InputPage();
    String rxNbr, txtUser, compoundDrugName, preAuthId, rxNbrFromRxNotes,rxOrigin;
    MenuBar menuBar = new MenuBar();
    ConsolidatedNotesPage consolidatedNotesPage = new ConsolidatedNotesPage();
    PrescriberSearchPage prescriberSearchPage = new PrescriberSearchPage();

    ImzEventPage imzEventPage = new ImzEventPage();
    CacheServiceManager cacheManager = new CacheServiceManager();
    EODPage eod = new EODPage();
    F6Search rxSearch = new F6Search();
    DropOffPage dropOff = new DropOffPage();
    Boolean rxImage;

    PropertyReader prop = PropertyReader.getInstance();

    public WorkFlow() {
        /*super(cnxManager.getDriver());
        this.cnxManager = cnxManager;*/
        super(AutomationManager.getInstance().getConnexus().getDriver());
    }

    @Override
    public void performSearch(String Value, SearchType type) {
        F6Search search = new F6Search();
        search.performSearch(Value, type);
    }

    @Override
    public void performLogin(String userName, String password) {
        sendText(AppiumBy.accessibilityId("txtUsername"), userName);
        sendText(AppiumBy.accessibilityId("txtPassword"), password);
        click(AppiumBy.accessibilityId("chkHOUser"));
        click(AppiumBy.accessibilityId("btnAccept"));
        Reporter.log("[performLogin] Login submitted. Waiting up to 35s for security acceptance popup...");

        // Primary: use the gRPC server's native modal/popup detection.
        // HandlePopup searches all top-level & modal windows for a button matching
        // 'BtnAccept' — far more reliable than manual window switching.
        boolean accepted = handlePopup("", "BtnAccept", 35);

        if (!accepted) {
            // Fallback for WinAppDriver mode or if HandlePopup couldn't find the popup.
            // switchWindow(30s) waits long enough for the slow-loading security screen.
            Reporter.log("[performLogin] handlePopup did not accept. Falling back to manual switchWindow...");
            this.switchWindow(30_000);
            boolean clicked = false;
            for (int attempt = 1; attempt <= 5; attempt++) {
                if (isElementDisplayed(AppiumBy.accessibilityId("BtnAccept"), 10)) {
                    if (click(AppiumBy.accessibilityId("BtnAccept"))) {
                        Reporter.log("[performLogin] BtnAccept clicked (attempt " + attempt + ").");
                        clicked = true;
                        break; // stop the loop — fall through to shell-wait below
                    }
                }
                if (attempt < 5) {
                    Reporter.log("[performLogin] Attempt " + attempt + " failed. Retrying switchWindow...");
                    this.switchWindow(5_000);
                }
            }
            if (!clicked) {
                Reporter.log("[performLogin] WARNING: Could not click security BtnAccept after all attempts.");
            }
        }

        // After the security popup is dismissed, Connexus exits the auth launcher
        // and spawns the main shell (ShellForm) in a NEW process (process-handoff
        // pattern). The gRPC session was bound to the dead launcher PID, so we must
        // wait here for the new shell window to appear before returning — otherwise
        // checkAndClickWarning() / any subsequent step will fail immediately.
        // The C# GetWindowHandles falls back to a desktop-wide ShellForm scan when
        // the tracked PID has 0 windows, so this switchWindow call will resolve to
        // the shell as soon as it becomes visible (typically 10-25s after auth).
        Reporter.log("[performLogin] Security popup handled. Waiting up to 40s for main shell (ShellForm) to appear...");
        this.switchWindow(40_000);
        Reporter.log("[performLogin] Login complete — shell window acquired.");
    }

    @Override
    public void checkAndClickWarning() {
        for (int i = 0; i <= 3; i++) {
            if (!isElementDisplayed(ok, 5)) {
                this.switchWindow();
            } else {
                if (moveToElementAndClick(ok)) {
                    break;
                }
            }
        }
    }

    @Override
    public void checkAndPerformCheckDUR(String rxNumber) {
        checkAndPerformCheckDUR(rxNumber, null, false, false);
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - checkAndPerformCheckDUR()
     * Description: This method is to perform checkDUR, if Rx moves to check DUR queue after completing 4-point
     * Inputs : Rx Number
     * returns: - -
     * Author: Shalini Devaraj
     * *********************************************************************************************************************************************************
     */
    @Override
    public void checkAndPerformCheckDUR(String rxNumber, Map<String, String> inputData, boolean counselRequiredCheck, boolean counselReasonRequired) {
        ChkDur dur = new ChkDur();
        if (dur.isCheckDUREligible(rxNumber)) {
            rxSearch.launchOrderSearchScreen();
            rxSearch.performSearch(rxNumber);
            rxSearch.openFirstPatientRecord();
            if (!rxSearch.isCheckDURPageDisplayed()) {
                captureUnExpectedResults(StackUtils.getCurrentMethodName(), "ChkDUR page - failed to open");
            }
            performCheckDur(inputData, counselRequiredCheck, counselReasonRequired);
        } else {
            Reporter.log("Rx not in ChkDUR Queue");
        }
    }

    public void performCheckDur(Map<String, String> inputData, boolean counselRequiredCheck, boolean counselReasonRequired) {
        ChkDur dur = new ChkDur();
        if (counselRequiredCheck) {
            Reporter.log("Rx has reached chkDUR queue");
            String counselReason = dur.getCounselReason();
            Assert.assertEquals(dur.getCounselToggleState(), "1");
            Assert.assertTrue(counselReason.contains(inputData.get("COUNSEL_REASON")), "Counsel reason is " + counselReason);
            Reporter.log("ChkDUR - Validated that Counsel required checkbox is checked and disabled.");
            Reporter.log("Counsel reason is " + counselReason);
        }

        if (dur.clickRedFlagsBtn()) {
            dur.selectResolvedCheckBoxes();
            dur.clickDurBtn();
        }
        if (!dur.clickClearConflictsBtn()) {
            dur.selectAllCheckBoxes();
        }
        if (dur.isElementDisplayed(dur.narxcare_grid, 30)) {
            dur.clickCounsellingNotes();
            dur.exitFromDur();
            dur.clickViewNarxcareReportButtonOnDUR();
            rxSearch.closeSearch();
            dur.clickApprovedFillRadioButton();
        }
        dur.clickNarxCareCheckBox();
        if (counselReasonRequired) {
            dur.selectReason("0", inputData.get("MESSAGE"));
            dur.clickOkInEarlyRefillPopUp();
        }
        Reporter.logScreenShot(Status.PASS, "performCheckDur", dur.takeScreenShot("ChkDUR").getValue());
        if (dur.clickAccept()) {
            dur.clickConnexusOk();
            if (checkForCAE()) {
                Assert.fail("CAE - Connexus Application Error - Check Dur");
            }
            Reporter.log("ChkDUR completed");
        } else {
            captureUnExpectedResults(StackUtils.getCurrentMethodName(), "ChkDUR page - failed while clicking Accept");
        }
    }

    /*
     * perform dropoff without adding comments
     *
     * Author: Achyut(vn50v7w)
     */
    @Override
    public void performDropRx(String patientName, Priority priority, int noOfRx, String pickupTime) {
        performDropRx(patientName, priority, noOfRx, pickupTime, "defaultValue", 1);
    }

    public void performDropRx(String patientName, Priority priority, int noOfRx, String pickupTime, boolean isTamperResistant) {
        performDropRx(patientName, priority, noOfRx, pickupTime, "defaultValue", 1, false);
    }

    @Override
    public void performDropRx(DropRxModel dropRxModel) {
        int defaultNoOfFutureDays = 1;
        performDropRx(dropRxModel, defaultNoOfFutureDays);
    }

    @Override
    public void performDropRx(DropRxModel dropRxModel, int noOfFutureDays) {
        if (dropRxModel.getOrderComment() == null) {
            performDropRx(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", "defaultValue", noOfFutureDays);
        } else {
            performDropRx(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", dropRxModel.getOrderComment(), noOfFutureDays);
        }
    }

    @Override
    public void performDropRx(DropRxModel dropRxModel, int noOfFutureDays, boolean isTamperResistant) {
        if (dropRxModel.getOrderComment() == null) {
            performDropRx(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", "defaultValue", noOfFutureDays, isTamperResistant);
        } else {
            performDropRx(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", dropRxModel.getOrderComment(), noOfFutureDays, isTamperResistant);
        }
    }


    @Override
    public void performNaloxoneDropRx(DropRxModel dropRxModel) {
        if (dropRxModel.getOrderComment() == null) {
            performNoloxoneDropRx(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", "defaultValue");
        } else {
            performNoloxoneDropRx(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", dropRxModel.getOrderComment());
        }
    }

    @Override
    public void performNaloxoneDropRxForPatient(DropRxModel dropRxModel) throws AWTException {
        if (dropRxModel.getOrderComment() == null) {
            performNoloxoneDropRxOrder(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", "defaultValue");
        } else {
            performNoloxoneDropRxOrder(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", dropRxModel.getOrderComment());
        }
    }

    @Override
    public void performIMZDropOff(DropRxModel dropRxModel) throws AWTException {
        if (dropRxModel.getOrderComment() == null) {
            performIMZDropOff(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", "defaultValue");
        } else {
            performIMZDropOff(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", dropRxModel.getOrderComment());
        }
    }

    @Override
    public void performDropOffForMultiDrugs(DropRxModel dropRxModel, List<String> drug) {
        if (dropRxModel.getOrderComment() == null) {
            performDropOffForMultiDrugs(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getDob(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", "defaultValue", drug);
        } else {
            performDropOffForMultiDrugs(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getDob(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", dropRxModel.getOrderComment(), drug);
        }
    }

    @Override
    public void existingPatientDropOff(DropRxModel dropRxModel) {
        if (dropRxModel.getOrderComment() == null) {
            performDropRxForExistingPatient(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getDob(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", "defaultValue");
        } else {
            performDropRxForExistingPatient(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getDob(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", dropRxModel.getOrderComment());
        }
    }

    @Override
    public void performCovidTestingKitDropRx(DropRxModel dropRxModel, String prescriberName) {
        if (dropRxModel.getOrderComment() == null) {
            performCovidTestingKitDropRx(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", "defaultValue", prescriberName);
        } else {
            performCovidTestingKitDropRx(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", dropRxModel.getOrderComment(), prescriberName);
        }
    }

    @Override
    public void performCovidTestingKitForMultiDrug(DropRxModel dropRxModel, List<String> drugList, String prescriberName) {
        if (dropRxModel.getOrderComment() == null) {
            performCovidTestingKitForMultiDrug(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), "", "defaultValue", drugList, prescriberName);
        } else {
            performCovidTestingKitForMultiDrug(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), "", dropRxModel.getOrderComment(), drugList, prescriberName);
        }
    }

    @Override
    public void performNaloxoneDropOffRx(DropRxModel dropRxModel, String drug, String prescriberName) {
        if (dropRxModel.getOrderComment() == null) {
            performNaloxoneDropOffRx(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), "", "defaultValue", drug, prescriberName);
        } else {
            performNaloxoneDropOffRx(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), "", dropRxModel.getOrderComment(), drug, prescriberName);
        }
    }

    @Override
    public void performNaloxoneStatePartnershipDropOff(DropRxModel dropRxModel, String drug, int qtyEvenNum, int qtyOddNum, int minRangeEvenNum, int maxRangeEvenNum, int minRangeOddNum, int maxRangeOddNum) {
        if (dropRxModel.getOrderComment() == null) {
            performNaloxoneStatePartnershipDropOff(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), "", "defaultValue", drug, qtyEvenNum, qtyOddNum, minRangeEvenNum, maxRangeEvenNum, minRangeOddNum, maxRangeOddNum);
        } else {
            performNaloxoneStatePartnershipDropOff(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), "", dropRxModel.getOrderComment(), drug, qtyEvenNum, qtyOddNum, minRangeEvenNum, maxRangeEvenNum, minRangeOddNum, maxRangeOddNum);
        }
    }

    @Override
    public void performIMZDropOffForSingleDrug(DropRxModel dropRxModel, String drug, String prescriberName) {
        if (dropRxModel.getOrderComment() == null) {
            performIMZDropOffForSingleDrug(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), "", "defaultValue", drug, prescriberName);
        } else {
            performIMZDropOffForSingleDrug(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), "", dropRxModel.getOrderComment(), drug, prescriberName);
        }
    }

    @Override
    public void performIMZDropOffForMultiDrug(DropRxModel dropRxModel, List<String> drugList, String prescriberName) {
        if (dropRxModel.getOrderComment() == null) {
            performIMZDropOffForMultiDrug(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), "", "defaultValue",
                    drugList, prescriberName);
        } else {
            performIMZDropOffForMultiDrug(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), "", dropRxModel.getOrderComment(),
                    drugList, prescriberName);
        }
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - performDropRx()
     * Description: This method is to drop a new fill
     * Inputs : patientName, priority, pickupTime
     * returns: --
     * Author: Shalini Devaraj* *********************************************************************************************************************************************************
     */
    @Override
    public void performDropRx(String patientName, Priority priority, int noOfRx, String pickupTime, String orderComment, int noOfFutureDays) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        if (!rxSearch.isDropOffDisplayed()) {
            captureUnExpectedResults(currentStepMethodName, "DropOff page - failed to load");
        }
        dropOff.enterPatientName(patientName);
        dropOff.clickPatientSearch();
        dropOff.handleAnnualValidatePatInfoPopUp();
        dropOff.clickScanNewRx();
        String barCode = dropOff.generateRxBarCode();
        dropOff.enterBarCode(barCode);
        dropOff.clickBtnAccept();
        dropOff.clickVerifyBarCode();
        dropOff.selectListItemfromRxOriginType();
        dropOff.clickchkBoxTamperResistant();
        dropOff.clickBtnAccept();
        if (noOfRx > 1) {
            dropOff.addNoOfRx(barCode, noOfRx);
        }
        dropOff.selectPriority(priority.getPriority());
        if (priority == Priority.InStore) {
            dropOff.getReadyByTime();
        }
        if (priority == Priority.Critical) {
            dropOff.getReadyByTime();
        }
        if (priority == Priority.DRCallIn) {
            dropOff.getReadyByTimeDrCallIn();
        }
        if (priority == Priority.DriveThru) {
            dropOff.getReadyByTimeDriveThru();
        }

        if (priority == Priority.Future) {
            if (noOfFutureDays > 1) {
                //By default, it will take 1 future date, so we are subtracting one day.
                dropOff.dropOffFutureDateSelection(noOfFutureDays - 1);
                Reporter.log(noOfFutureDays + " Days Added to the Current Date");
            }
            dropOff.selectReadyByTimeNew();
        }
        if (priority == Priority.Today) {
            dropOff.selectReadyByTimeNew();
        }
        if (!"defaultValue".equals(orderComment)) {
            dropOff.enterOrderComment(orderComment);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        dropOff.clickBtnAccept();
        dropOff.handleStorePickupTimePopup();
        dropOff.checkAndClickDropOffStation();
        Reporter.log("Drop-Off completed");
    }

    public void performDropRx(String patientName, Priority priority, int noOfRx, String pickupTime, String orderComment, int noOfFutureDays, boolean isTamperResistant) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        if (!rxSearch.isDropOffDisplayed()) {
            captureUnExpectedResults(currentStepMethodName, "DropOff page - failed to load");
        }
        dropOff.enterPatientName(patientName);
        dropOff.clickPatientSearch();
        dropOff.handleAnnualValidatePatInfoPopUp();
        dropOff.clickScanNewRx();
        String barCode = dropOff.generateRxBarCode();
        dropOff.enterBarCode(barCode);
        dropOff.clickBtnAccept();
        dropOff.clickVerifyBarCode();
        dropOff.selectListItemfromRxOriginType();
        if (isTamperResistant) {
            dropOff.clickchkBoxTamperResistant();
        } else {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Need not click on TamperResistant Checkbox");
        }
        dropOff.clickBtnAccept();
        if (noOfRx > 1) {
            dropOff.addNoOfRx(barCode, noOfRx);
        }
        dropOff.selectPriority(priority.getPriority());
        if (priority == Priority.InStore) {
            dropOff.getReadyByTime();
        }
        if (priority == Priority.Critical) {
            dropOff.getReadyByTime();
        }
        if (priority == Priority.DRCallIn) {
            dropOff.getReadyByTimeDrCallIn();
        }
        if (priority == Priority.DriveThru) {
            dropOff.getReadyByTimeDriveThru();
        }

        if (priority == Priority.Future) {
            if (noOfFutureDays > 1) {
                //By default, it will take 1 future date, so we are subtracting one day.
                dropOff.dropOffFutureDateSelection(noOfFutureDays - 1);
                Reporter.log(noOfFutureDays + " Days Added to the Current Date");
            }
            dropOff.selectReadyByTimeNew();
        }
        if (priority == Priority.Today) {
            dropOff.selectReadyByTimeNew();
        }
        if (!"defaultValue".equals(orderComment)) {
            dropOff.enterOrderComment(orderComment);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        dropOff.clickBtnAccept();
        dropOff.handleStorePickupTimePopup();
        dropOff.checkAndClickDropOffStation();
        Reporter.log("Drop-Off completed");
    }

    public void performDropRxForExistingPatient(
            String patientName, String dob, Priority priority, int noOfRx, String pickupTime, String orderComment) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        dropOff.clickPatientSearch();
        patientSearchPage.inputPatientName(patientName);
        patientSearchPage.inputPatientDob(dob);
        patientSearchPage.clickSearchNow();
        patientSearchPage.doubleClickOnSearchGridRowforPatient(0);
        dropOff.handleAnnualValidatePatInfoPopUp();
        dropOff.clickScanNewRx();
        String barCode = dropOff.generateRxBarCode();
        dropOff.enterBarCode(barCode);
        Reporter.log("New barcode entered " + barCode);
        dropOff.clickBtnAccept();
        dropOff.clickVerifyBarCode();
        dropOff.selectListItemfromRxOriginType();
        dropOff.clickBtnAccept();
        dropOff.addNoOfRx(barCode, noOfRx);
        dropOff.selectPriority(priority.getPriority());
        if (priority == Priority.InStore) {
            dropOff.getReadyByTime();
        }
        if (priority == Priority.Critical) {
            dropOff.getReadyByTime();
        }
        if (priority == Priority.DRCallIn) {
            dropOff.getReadyByTimeDrCallIn();
        }
        if (priority == Priority.DriveThru) {
            dropOff.getReadyByTimeDriveThru();
        }

        if (priority == Priority.Future) {
            dropOff.selectPickupTime(pickupTime);
        }
        if (priority == Priority.Today) {
            dropOff.selectPickupTime(pickupTime);
        }
        if (!"defaultValue".equals(orderComment)) {
            dropOff.enterOrderComment(orderComment);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        dropOff.clickBtnAccept();
        dropOff.handleStorePickupTimePopup();
        Reporter.log("Drop-Off completed");
    }

    public void performNoloxoneDropRx(String patientName, Priority priority, int noOfRx, String pickupTime, String orderComment) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        dropOff.clickorderType();
        dropOff.clicknaloxoneInStore();
        dropOff.enterPatientName(patientName);
        dropOff.clickPatientSearch();
        dropOff.handleAnnualValidatePatInfoPopUp();
        dropOff.clickDrugDropDown();
        System.out.println(dropOff.getDrugName());
        dropOff.selectNaloxoneDrug();
        dropOff.selectPriority(priority.getPriority());
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        if (priority == Priority.Future) {
            dropOff.selectPickupTime(pickupTime);
        }
        if (!"defaultValue".equals(orderComment)) {
            dropOff.enterOrderComment(orderComment);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        dropOff.addToOrder();
        dropOff.clickOutOFFStock();
        dropOff.selectdispenseType(DispenseType.CounterPickup.getDispenseType());
        dropOff.clickBtnAccept();
        dropOff.handleStorePickupTimePopup();
        Reporter.log("Drop-Off completed");

    }

    public void performNoloxoneDropRxOrder(String patientName, Priority priority, int noOfRx, String pickupTime, String orderComment) throws AWTException {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        dropOff.clickorderType();
        dropOff.clicknaloxoneInStore();
        dropOff.enterPatientName(patientName);
        dropOff.clickPatientSearch();
        dropOff.handleAnnualValidatePatInfoPopUp();
        dropOff.clickDrugDropDownForNalaxoneDrug();
        //System.out.println(dropOff.getDrugName());
        //dropOff.selectNaloxoneDrug();
        dropOff.authRPh();
        dropOff.clickAuthRPh();
        dropOff.clickNotFound();
        dropOff.setRPh("Thomas,Walden");
        dropOff.clickOnthreeDotsIInSetRPh(1);
        dropOff.addToOrder();
        dropOff.selectPriority(priority.getPriority());
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        if (priority == Priority.Future) {
            dropOff.selectPickupTime(pickupTime);
        }
        if (!"defaultValue".equals(orderComment)) {
            dropOff.enterOrderComment(orderComment);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        // dropOff.addToOrder();
        dropOff.clickOutOFFStock();
        dropOff.selectdispenseType(DispenseType.CounterPickup.getDispenseType());
        dropOff.clickBtnAccept();
        dropOff.handleStorePickupTimePopup();
        Reporter.log("Drop-Off completed");

    }

    public void performIMZDropOff(String patientName, Priority priority, int noOfRx, String pickupTime, String orderComment) throws AWTException {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        automationManager.performSleep(5);
        dropOff.clickorderType();
        dropOff.clickIMZInStore();
        automationManager.performSleep(5);
        dropOff.enterPatientName(patientName);
        dropOff.clickPatientSearch();
        dropOff.handleAnnualValidatePatInfoPopUp();
        automationManager.performSleep(5);
        dropOff.clickDrugDropDownForNalaxoneDrug();
        automationManager.performSleep(5);
        dropOff.selectIMZDrug();
        if (dropOff.authRPh()) {
            dropOff.clickAuthRPh();
            dropOff.clickNotFound();
            dropOff.setRPh("Thomas,Walden");
            prescriberSearchPage.doubleClickOnSearchGridRow(0);
        }

        dropOff.addToOrder();
        dropOff.selectPriority(priority.getPriority());
        if (priority == Priority.Future) {
            dropOff.selectReadyByTimeFuture();
        }
        if (!"defaultValue".equals(orderComment)) {
            dropOff.enterOrderComment(orderComment);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        dropOff.clickOutOFFStock();
        dropOff.selectdispenseType(DispenseType.CounterPickup.getDispenseType());
        dropOff.clickBtnAccept();
        dropOff.handleStorePickupTimePopup();
        Reporter.log("Drop-Off completed");
    }


    @Override
    public void performInput(RxModel rxModel) {
        if (rxModel.getPrescriberDeaType() == null) {
            performInput(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxModel.getNdc(), rxModel.getPrescribedQty(), rxModel.getSigCode(), rxModel.getNoOfRefills(), rxModel.getPrescriberName());
        } else {
            performInput(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxModel.getNdc(), rxModel.getPrescribedQty(), rxModel.getSigCode(), rxModel.getNoOfRefills(), rxModel.getPrescriberDeaType());
        }
    }

    @Override
    public void performInput(RxModel rxModel, String inputType) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName());
        rxSearch.openFirstPatientRecord();
        if (!rxSearch.isInputPageDisplayed()) {
            captureUnExpectedResults(currentStepMethodName, "Input page - failed to load");
        }

        inputPage.isAddressValidationViewPopupDisplayed();
        // Handle compound drug vs regular drug
        if (rxModel.isCompoundDrug()) {
            inputPage.enterNDCInProductName("COMPOUND");
            String compoundName = rxModel.getCompoundDrugName();
            inputPage.setCompoundDrug(compoundName);
        } else {
            inputPage.enterNdc(rxModel.getNdc());
            inputPage.clickProductSearch3Dots();
        }
        inputPage.enterPrescribedQty(rxModel.getPrescribedQty());
        inputPage.enterSigCode(rxModel.getSigCode());

        // Only enter expanded SIG when SIG value is "FF"
        String sigCode = rxModel.getSigCode();
        if (sigCode != null && "FF".equalsIgnoreCase(sigCode.trim())) {
            inputPage.enterExpandedSig(rxModel.getExpandedSig());
            inputPage.enterDaysSupply(rxModel.getDays());
        }
        inputPage.enterRefillQty(rxModel.getNoOfRefills());
        if (rxModel.getPrescriberDeaType() == null) {
            inputPage.enterPrescriber(rxModel.getPrescriberName());
        } else {
            inputPage.enterPrescriber(rxModel.getPrescriberDeaType());
        }

        switch (inputType) {
            case "BlankTMCode":
                inputPage.clickOkOnValidateRxPopUp();
                if (!inputPage.isTMCodeDisplayed()) {
                    captureUnExpectedResults(currentStepMethodName, "TM code Field Not displayed");
                }
                break;
            case "DAW1":
                inputPage.selectDAW(1);
                if (inputPage.isTMCodeDisplayed()) {
                    inputPage.selectTmCodeField(2);
                }
                break;
            default:
                inputPage.clickOkOnValidateRxPopUp();
                if (inputPage.isTMCodeDisplayed()) {
                    inputPage.selectTmCodeField(2);
                }
        }

        if (inputPage.isDxCodeDisplayed()) {
            inputPage.inputRandomDXCode();
        }
        if (inputPage.isTriplicateDisplayed()) {
            inputPage.inputTriplicateNumber();
        }
        String rxComment = rxModel.getRxComment();
        if (rxComment != null && !rxComment.isEmpty()) {
            inputPage.enterRxComment(rxModel.getRxComment());
        }

        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());

        inputPage.clickAcceptSmart();
        boolean handledPostAcceptPopup = false;
        handledPostAcceptPopup |= inputPage.clickYesOnValidateRxPopUpIfPresent();
        handledPostAcceptPopup |= inputPage.clickOnOutofStockPopupOkIfPresent();
        handledPostAcceptPopup |= inputPage.clickYesOnValidateRxPopUpIfPresent();
        handledPostAcceptPopup |= inputPage.clickPartialPopupIfPresent();
        if (!isGrpcMode() || handledPostAcceptPopup || inputPage.isInputAcceptDisplayedQuick()) {
            inputPage.clickAcceptSmart(5, 1000);
        }
        inputPage.clickOnOutofStockPopupOkIfPresent();
        if (checkForCAE()) {
            Assert.fail("CAE - Connexus Application Error - Input");
        }
        Reporter.log("Input completed");
    }

    @Override
    public void performInputWithBlankTMCode(RxModel rxModel) {
        if (rxModel.getPrescriberDeaType() == null) {
            performInputWithBlankTMCode(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxModel.getNdc(), rxModel.getPrescribedQty(), rxModel.getSigCode(), rxModel.getNoOfRefills(), rxModel.getPrescriberName());
        } else {
            performInputWithBlankTMCode(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxModel.getNdc(), rxModel.getPrescribedQty(), rxModel.getSigCode(), rxModel.getNoOfRefills(), rxModel.getPrescriberDeaType());
        }
    }

    @Override
    public void performInputWithWrittenDateLessThanSixMonths(RxModel rxModel) {
        if (rxModel.getPrescriberDeaType() == null) {
            performInputWithWrittenDateLessThanSixMonths(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxModel.getNdc(), rxModel.getPrescribedQty(), rxModel.getSigCode(), rxModel.getNoOfRefills(), rxModel.getPrescriberName());
        } else {
            performInputWithWrittenDateLessThanSixMonths(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxModel.getNdc(), rxModel.getPrescribedQty(), rxModel.getSigCode(), rxModel.getNoOfRefills(), rxModel.getPrescriberDeaType());
        }
    }

    /**
     * Perform Dropoff with rx origin type
     *
     * @param dropRxModel
     */
    @Override
    public void performDropOffBasedOnRxOriginType(DropRxModel dropRxModel) {
        if (dropRxModel.getOrderComment() == null) {
            performDropOffBasedOnRxOriginType(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getRxOriginType(), dropRxModel.getNoOfRx(), "", "defaultValue");
        } else {
            performDropOffBasedOnRxOriginType(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getRxOriginType(), dropRxModel.getNoOfRx(), "", dropRxModel.getOrderComment());
        }
    }

    @Override
    public void performInputWithDAW1(RxModel rxModel) {
        if (rxModel.getPrescriberDeaType() == null) {
            performInputWithDAW1(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxModel.getNdc(), rxModel.getPrescribedQty(), rxModel.getSigCode(), rxModel.getNoOfRefills(), rxModel.getPrescriberName());
        } else {
            performInputWithDAW1(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxModel.getNdc(), rxModel.getPrescribedQty(), rxModel.getSigCode(), rxModel.getNoOfRefills(), rxModel.getPrescriberDeaType());
        }
    }

    @Override
    public void performMultiRxInput(RxModel rxModel, int index) {
        if (rxModel.getPrescriberDeaType() == null) {
            performMultiRxInput(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxModel.getNdc(), rxModel.getPrescribedQty(), rxModel.getSigCode(), rxModel.getNoOfRefills(), rxModel.getPrescriberName(), index);
        } else {
            performMultiRxInput(rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxModel.getNdc(), rxModel.getPrescribedQty(), rxModel.getSigCode(), rxModel.getNoOfRefills(), rxModel.getPrescriberDeaType(), index);
        }
    }

    @Override
    public void performMultiRxInput(Map<String, String> inputData, RxModel rxModel, int index) {
        if (rxModel.getPrescriberDeaType() == null) {
            performMultiRxInput(inputData,rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxModel.getNdc(), rxModel.getPrescribedQty(), rxModel.getSigCode(), rxModel.getNoOfRefills(), rxModel.getPrescriberName(), index);
        } else {
            performMultiRxInput(inputData,rxModel.getPatientLastName() + "," + rxModel.getPatientFirstName(), rxModel.getNdc(), rxModel.getPrescribedQty(), rxModel.getSigCode(), rxModel.getNoOfRefills(), rxModel.getPrescriberDeaType(), index);
        }
    }

    @Override
    public void performImzEventDropOff(DropRxModel dropRxModel, String dob, String imzEventName, String raceValue, String ethnicityValue, String imzEventDrug) {
        if (dropRxModel.getOrderComment() == null) {
            performImzEventDropOff(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), "defaultValue", dob, imzEventName, raceValue, ethnicityValue, imzEventDrug);
        } else {
            performImzEventDropOff(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getOrderComment(), dob, imzEventName, raceValue, ethnicityValue, imzEventDrug);
        }
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - performInput()
     * Description: This method is to perform Input for an Rx
     * Inputs : patientName, ndc, prescribedQty,sigCode,refills,prescriberName
     * returns: --
     * Author: Shalini Devaraj
     * *********************************************************************************************************************************************************
     */
    @Override
    public void performInput(String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(patientName);
        rxSearch.openFirstPatientRecord();
        inputPage.isAddressValidationViewPopupDisplayed();
        inputPage.enterNdc(ndc);
        inputPage.clickProductSearch3Dots();
        inputPage.enterPrescribedQty(prescribedQty);
        inputPage.enterSigCode(sigCode);
        inputPage.enterRefillQty(refills);
        inputPage.enterPrescriber(prescriberName);
        inputPage.clickOkOnValidateRxPopUp();
        if (inputPage.isTMCodeDisplayed()) {
            inputPage.selectTmCodeField(2);
        }
        if (inputPage.isDxCodeDisplayed()) {
            inputPage.inputRandomDXCode();
        }
        if (inputPage.isTriplicateDisplayed()) {
            inputPage.inputTriplicateNumber();
        }
        Reporter.log("drug_name " + ndc);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        inputPage.clickAcceptSmart();
        //inputPage.rxExpDateSelection();
        boolean handledPostAcceptPopup = false;
        handledPostAcceptPopup |= inputPage.clickYesOnValidateRxPopUpIfPresent();
        handledPostAcceptPopup |= inputPage.clickOnOutofStockPopupOkIfPresent();
        handledPostAcceptPopup |= inputPage.clickYesOnValidateRxPopUpIfPresent();
        handledPostAcceptPopup |= inputPage.clickPartialPopupIfPresent();
        if (!isGrpcMode() || handledPostAcceptPopup || inputPage.isInputAcceptDisplayedQuick()) {
            inputPage.clickAcceptSmart(5, 1000);
        }
        if (checkForCAE()) {
            Assert.fail("CAE - Connexus Application Error - Input");
        }
        Reporter.log("Input completed");
    }

    public void performInputWithBlankTMCode(String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(patientName);
        rxSearch.openFirstPatientRecord();
        inputPage.isAddressValidationViewPopupDisplayed();
        inputPage.enterNdc(ndc);
        inputPage.clickProductSearch3Dots();
        inputPage.enterPrescribedQty(prescribedQty);
        inputPage.enterSigCode(sigCode);
        inputPage.enterRefillQty(refills);
        inputPage.enterPrescriber(prescriberName);
        inputPage.clickOkOnValidateRxPopUp();
        if (!inputPage.isTMCodeDisplayed()) {
            Assert.fail("TM code Field Not displayed");
        }
        if (inputPage.isDxCodeDisplayed()) {
            inputPage.inputRandomDXCode();
        }
        if (inputPage.isTriplicateDisplayed()) {
            inputPage.inputTriplicateNumber();
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        automationManager.performSleep(3);
        inputPage.clickAccept();
        automationManager.performSleep(5);
        inputPage.clickYesOnValidateRxPopUp();
        inputPage.clickOnOutofStockPopupOk();
        inputPage.clickYesOnValidateRxPopUp();
        if (checkForCAE()) {
            Assert.fail("CAE - Connexus Application Error - Input");
        }
        Reporter.log("Input completed");
    }

    public void performInputWithDAW1(String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            rxSearch.launchOrderSearchScreen();
            rxSearch.performSearch(patientName);
            rxSearch.openFirstPatientRecord();
            inputPage.isAddressValidationViewPopupDisplayed();
            inputPage.enterNdc(ndc);
            inputPage.clickProductSearch3Dots();
            inputPage.enterPrescribedQty(prescribedQty);
            inputPage.enterSigCode(sigCode);
            inputPage.enterRefillQty(refills);
            inputPage.selectDAW(1);
            inputPage.enterPrescriber(prescriberName);
            if (inputPage.isTMCodeDisplayed()) {
                inputPage.selectTmCodeField(2);
            }
            if (inputPage.isDxCodeDisplayed()) {
                inputPage.inputRandomDXCode();
            }
            if (inputPage.isTriplicateDisplayed()) {
                inputPage.inputTriplicateNumber();
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            automationManager.performSleep(3);
            inputPage.clickAccept();
            automationManager.performSleep(5);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Perform Drop off by providing all the mandatory fields.
     *
     * @param patientName
     * @param priority
     * @param originType
     * @param noOfRx
     * @param pickupTime
     * @param orderComment
     */
    public void performDropOffBasedOnRxOriginType(String patientName, Priority priority, RxOriginType originType, int noOfRx, String pickupTime, String orderComment) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        dropOff.enterPatientName(patientName);
        dropOff.clickPatientSearch();
        dropOff.handleAnnualValidatePatInfoPopUp();
        dropOff.clickScanNewRx();
        String barCode = dropOff.generateRxBarCode();
        dropOff.enterBarCode(barCode);
        Reporter.log("New barcode entered " + barCode);
        dropOff.clickBtnAccept();
        dropOff.clickVerifyBarCode();
        if (originType == RxOriginType.OriginalRx) {
            dropOff.selectOriginTypeBasedOnIndex(0);
        }
        if (originType == RxOriginType.Phone) {
            dropOff.selectOriginTypeBasedOnIndex(1);
        }
        if (originType == RxOriginType.Fax) {
            dropOff.selectOriginTypeBasedOnIndex(2);
        }
        if (originType == RxOriginType.Pharmacy) {
            dropOff.selectOriginTypeBasedOnIndex(3);
        }
        if (originType == RxOriginType.Transfer) {
            dropOff.selectOriginTypeBasedOnIndex(4);
        }
        if (originType == RxOriginType.Erx_transfer) {
            dropOff.selectOriginTypeBasedOnIndex(5);
        }
        if (originType == RxOriginType.No_associated_prescription) {
            dropOff.selectOriginTypeBasedOnIndex(6);
        }
        dropOff.clickBtnAccept();
        dropOff.addNoOfRx(barCode, noOfRx);
        dropOff.selectPriority(priority.getPriority());
        if (priority == Priority.InStore) {
            dropOff.getReadyByTime();
        }
        if (priority == Priority.Critical) {
            dropOff.getReadyByTime();
        }
        if (priority == Priority.DRCallIn) {
            dropOff.getReadyByTimeDrCallIn();
        }
        if (priority == Priority.DriveThru) {
            dropOff.getReadyByTimeDriveThru();
        }

        if (priority == Priority.Future) {
            dropOff.selectPickupTime(pickupTime);
        }
        if (priority == Priority.Today) {
            dropOff.selectPickupTime(pickupTime);
        }
        if (!"defaultValue".equals(orderComment)) {
            dropOff.enterOrderComment(orderComment);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        dropOff.clickBtnAccept();
        dropOff.handleStorePickupTimePopup();
        dropOff.checkAndClickDropOffStation();
        Reporter.log("Drop-Off completed");
    }

    public void performInputWithWrittenDateLessThanSixMonths(String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(patientName);
        rxSearch.openFirstPatientRecord();
        inputPage.isAddressValidationViewPopupDisplayed();
        inputPage.enterNdc(ndc);
        inputPage.clickProductSearch3Dots();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Capturing screenshot before changing written date");
        inputPage.selectWrittenDateLessThanSixMonths();
        inputPage.enterPrescribedQty(prescribedQty);
        inputPage.enterSigCode(sigCode);
        inputPage.enterRefillQty(refills);
        inputPage.enterPrescriber(prescriberName);
        if (inputPage.isTMCodeDisplayed()) {
            inputPage.selectTmCodeField(2);
        }
        if (inputPage.isDxCodeDisplayed()) {
            inputPage.inputRandomDXCode();
        }
        if (inputPage.isTriplicateDisplayed()) {
            inputPage.inputTriplicateNumber();
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        automationManager.performSleep(3);
        inputPage.clickAccept();
        automationManager.performSleep(5);
    }

    @Override
    public String performFourPoint(String patNameOrRxNbr) {
        return performFourPoint(patNameOrRxNbr, null, false);
    }


    @Override
    public String performFourPoint(String patNameOrRxNbr, Map<String, String> inputData, boolean counselRequiredCheck) {
        return performFourPoint(patNameOrRxNbr, inputData, counselRequiredCheck, false);
    }

    /**
     * Overload that delegates to 5-param method with checkOnHold=false (default behavior)
     * Maintains backward compatibility for existing callers
     */
    @Override
    public String performFourPoint(String patNameOrRxNbr, Map<String, String> inputData, boolean counselRequiredCheck, boolean paymentCheck) {
        return performFourPoint(patNameOrRxNbr, inputData, counselRequiredCheck, paymentCheck, false, false);
    }

    /**
     * Convenience method to perform 4-point with OnHold checkbox checked
     * Used for RX Transfer test scenarios where OnHold status is required
     *
     * @param patNameOrRxNbr - Patient name or Rx number
     */
    @Override
    public String performFourPointWithOnHold(String patNameOrRxNbr) {
        return performFourPoint(patNameOrRxNbr, null, false, false, true, false);
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - performFourPoint()
     * Description: This method is to perform 4 point on an Rx
     * Inputs : patientName
     * returns: rxNbr
     * Author: Shalini Devaraj
     * *********************************************************************************************************************************************************
     */

    public String performFourPoint(String patNameOrRxNbr, Map<String, String> inputData, boolean counselRequiredCheck, boolean paymentCheck, boolean checkOnHold, boolean triplicatecheck) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        checkRxWorkQue(patNameOrRxNbr, WorkQueue.FOUR_POINT);
        FourPoint fourpoint = new FourPoint();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(patNameOrRxNbr);
        rxNbr = rxSearch.getRxNbr(0);
        if (rxNbr == null || rxNbr.isEmpty()) {
            captureUnExpectedResults(currentStepMethodName, "Rx number not found in search results");
        }
        Reporter.log("Rx number is " + rxNbr);
        rxSearch.openFirstPatientRecord();
        if (!rxSearch.isFourPointPageDisplayed()) {
            captureUnExpectedResults(currentStepMethodName, "FourPoint - page not loaded");
        }
        fourpoint.waitForGrpcReady();
        if (fourpoint.isElementDisplayed(fourpoint.btnValidateReEntry)) {
            fourpoint.enterDrugName(inputData.get("DRUG_STRENGTH"));
            Reporter.logScreenShot(Status.PASS, "Screenshot of Drug Strength validation", fourpoint.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Provided " + inputData.get("DRUG_STRENGTH") + " as drug strength in 4point drug strength validation popup");
            fourpoint.clickBtnValidateReEntry();
        }
        // Handle OnHold checkbox based on checkOnHold flag
        if (checkOnHold) {
            // If checkOnHold=true, ensure OnHold IS checked (for RX Transfer scenarios)
            if (!fourpoint.onHoldButtonSelected()) {
                fourpoint.unCheckOnHold(); // clicks to check the onHold checkbox
            }
        } else {
            // Default behavior: ensure OnHold is NOT checked
            if (fourpoint.onHoldButtonSelected()) {
                fourpoint.unCheckOnHold();
            }
        }
        if (paymentCheck) {

            String paymentType = fourpoint.getPaymentDetails();
            if (paymentType.contains("CASH")) {
                Reporter.log("4point - Payment section appeared on the left side as a grid with Insurance showing as 'Cash'.");
            } else if (paymentType.contains(inputData.get("TP_CARRIER_BIN"))) {
                Reporter.log("4point - Payment section appeared on the left side as a grid with Insurance showing as 'TP Insurance'.");
            } else {
                Assert.fail("Unexpected payment type: " + paymentType);
            }
            Reporter.log("Payment Type is " + paymentType);
            String address = fourpoint.getPatientAddress();
            Assert.assertTrue(address.contains(inputData.get("ADDRESS")), "Address is " + address);
            Reporter.log("4point - Patient address is displayed in the patient section in right plane");
            Reporter.log("Address is :" + address);
        }

        if (inputData != null && inputData.get("SIG") != null && "1Q4H".equals(inputData.get("SIG"))) {
            if (fourpoint.isElementDisplayed(fourpoint.dosage)) {
                Reporter.logScreenShot("dosage popup", fourpoint.takeScreenShot());
                fourpoint.clickOverDoseButton();
            }
        }

        if (fourpoint.isNameChkBoxDisplayed()) {
            if (counselRequiredCheck) {
                String counselReason = fourpoint.getCounselReason();
                Reporter.log("Actual Counsel Reason from Four Point page: " + counselReason);
                Reporter.log("Expected Counsel Reason : " + inputData.get("COUNSEL_REASON"));
                Assert.assertTrue(fourpoint.isCounselRequiredIn4point(), "Counsel required option is not checked");
                Assert.assertTrue(counselReason.contains(inputData.get("COUNSEL_REASON")), "Counsel reason is " + counselReason);
                Reporter.log("Validated counsel required is checked and option is disabled");
                Assert.assertTrue(fourpoint.isCounselRequiredIn4point(), "Counsel required option is not checked");
                Assert.assertTrue(counselReason.contains(inputData.get("COUNSEL_REASON")), "Counsel reason is " + counselReason);
                Reporter.log("4point - Validated that Counsel required checkbox is checked and disabled.");
                Reporter.log("Counsel reason is " + counselReason);
            }
            fourpoint.chkName();
            fourpoint.chkPrescribed();
            if (fourpoint.ischkStrength()) {
                fourpoint.chkStrength();
            }
            fourpoint.chkSIG();
            if (fourpoint.isDeaChkBoxDisplayed()) {
                fourpoint.chkDEA();
            }
            if (fourpoint.isNonAcuteRdbDisplayed()) {
                fourpoint.clickNonAcute();
            }
            if (fourpoint.isAdminDetailsDisplayed()) {
                fourpoint.clickAdminDetails();
            }
            if (fourpoint.isRxCommentPresentIn4Point()) {
                fourpoint.clearRxCommentIn4Point();
            }


            if (triplicatecheck) {
                if (fourpoint.isTriplicateFieldDisplayed()) {
                    String triplicate = fourpoint.readTriplicateCode();
                    Reporter.log("autopopulated Triplicate is " + triplicate);
                    Assert.assertEquals(triplicate, inputData.get("TRIPLICATE"));
                    Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
                } else {
                    Reporter.logScreenShot(Status.FAIL, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
                    Assert.fail("Failed to display Triplicate field");
                }
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
            boolean acceptComplete = fourpoint.clickAccept();
            if (fourpoint.isElementDisplayed(fourpoint.txtSiteIdOnRphPopUp, 5)) {
                fourpoint.performRPHValidation();
            }
            if (!acceptComplete) {
                fourpoint.clickAccept();
            }
            if (checkForCAE()) {
                Assert.fail("CAE - Connexus Application Error - Four Point");
            }
            Reporter.log("4 point completed");
        } else {
            captureUnExpectedResults(currentStepMethodName, "FourPoint - page not loaded");
        }
        return rxNbr;
    }

    @Override
    public void performDoubleFourPoint(String patNameOrRxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        FourPoint fourpoint = new FourPoint();
        int counter = 0;
        rxSearch.performSearch(patNameOrRxNbr, SearchType.PatientRx);
        rxNbr = rxSearch.getRxNbr(0);
        Reporter.log("Rx number is " + rxNbr);
        while (rxSearch.getWorkQueue(0).toLowerCase().equals(WorkQueue.DUR.getWorkQueue())) {
            counter++;
            rxSearch.pressKeys(KeyEvent.VK_F6);
            if (counter >= 4) {
                break;
            }
        }
        if (!rxSearch.getWorkQueue(0).toLowerCase().equals(WorkQueue.FOUR_POINT.getWorkQueue().toLowerCase())) {
            System.out.println(rxSearch.getWorkQueue(0) + "" + WorkQueue.FOUR_POINT.getWorkQueue().toLowerCase());
            Assert.fail("OnHold button selected");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
        }
        rxSearch.selectRowFromSearch(0);
        fourpoint.waitForGrpcReady();
        enterRxComments("rxnotes", "pharmacynotes", "counselingnotes");
        fourpoint.orderComment();
        fourpoint.rxComment();
        if (fourpoint.onHoldButtonSelected()) {
            Assert.fail("OnHold button selected");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
        }
        fourpoint.chkName();
        fourpoint.chkPrescribed();
        if (fourpoint.ischkStrength()) {
            fourpoint.chkStrength();
        }
        fourpoint.chkSIG();
        if (fourpoint.isDeaChkBoxDisplayed()) {
            fourpoint.chkDEA();
        }
        if (fourpoint.isNonAcuteRdbDisplayed()) {
            fourpoint.clickNonAcute();
        }
        if (fourpoint.isAdminDetailsDisplayed()) {
            fourpoint.clickAdminDetails();
        }
        if (fourpoint.isRxCommentPresentIn4Point()) {
            fourpoint.clearRxCommentIn4Point();
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
        boolean acceptComplete = fourpoint.clickAccept();
        if (fourpoint.isElementDisplayed(fourpoint.txtSiteIdOnRphPopUp, 5)) {
            fourpoint.performRPHValidation();
        }
        if (!acceptComplete) {
            fourpoint.clickAccept();
        }
        if (checkForCAE()) {
            Assert.fail("CAE - Connexus Application Error - Four Point");
        }
        Reporter.log("Double 4 point completed");
    }

    @Override
    public void enterRxComments(String rxNotes, String pharmacyNotes, String conselingNotes) {
        ModifyDetails modifyDetails = new ModifyDetails();
        modifyDetails.clickOrderDetails();
        modifyDetails.clickCounsellingNote();
        modifyDetails.rxNotesButton();
        modifyDetails.rxNotesRadioButtonClick();
        modifyDetails.enterRxNotes(rxNotes);
        modifyDetails.acceptAndClose();
        modifyDetails.clickOrderDetails();
        modifyDetails.rxNotesButton();
        modifyDetails.pharmacyNotesRadioButtonClick();
        modifyDetails.enterRxNotes(pharmacyNotes);
        modifyDetails.acceptAndClose();
        modifyDetails.clickCounsellingNote();
        modifyDetails.clickOrderDetails();
        modifyDetails.rxNotesButton();
        modifyDetails.cousellingNotesRadioButtonClick();
        modifyDetails.enterRxNotes(conselingNotes);
        modifyDetails.acceptAndClose();
    }

    @Override
    public String performFourPointForControlledDrug(String patNameOrRxNbr, String productName) {
        return performFourPointForControlledDrug(patNameOrRxNbr, productName, false);
    }

    /**
     * *********************************************************************************************************************************************************
     * Function Name - performFourPointForControlledDrug()
     * Description: This method is to perform 4 point on an Rx
     * Inputs : patientName
     * returns: rxNbr
     * Author: Srinivas(vn50jui)
     * *********************************************************************************************************************************************************
     */

    @Override
    public String performFourPointForControlledDrug(String patNameOrRxNbr, String productName, boolean flagDur) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        checkRxWorkQue(patNameOrRxNbr, WorkQueue.FOUR_POINT);
        FourPoint fourpoint = new FourPoint();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(patNameOrRxNbr);
        rxNbr = rxSearch.getRxNbr(0);
        Reporter.log("Rx number is " + rxNbr);
        rxSearch.openFirstPatientRecord();
        if (!rxSearch.isFourPointPageDisplayed()) {
            captureUnExpectedResults(currentStepMethodName, "FourPoint - page not loaded");
        }
        fourpoint.waitForGrpcReady();
        if (fourpoint.isElementDisplayed(fourpoint.cmbDrugReEntry, 30)) {
            Assert.assertFalse(fourpoint.isElementEnabled(fourpoint.btnValidateReEntry));
            Reporter.log("Index number " + fourpoint.getDrugReleaseType(productName));
            fourpoint.selectValueFromTheListBasedOnIndex(fourpoint.cmbDrugReEntry, fourpoint.getDrugReleaseType(productName));
            fourpoint.click(fourpoint.btnValidateReEntry);
        }
        //method to handle dosage popup that appears when the dosage is more
        if (fourpoint.isElementDisplayed(fourpoint.dosage, ConnexusConstants.WAIT_TIMEOUT_10)) {
            Reporter.logScreenShot("dosage popup", fourpoint.takeScreenShot());
            fourpoint.clickOverDoseButton();
        }
        fourpoint.chkName();
        fourpoint.chkPrescribed();
        if (fourpoint.ischkStrength()) {
            fourpoint.chkStrength();
        }
        fourpoint.chkSIG();
        if (fourpoint.isElementDisplayed(fourpoint.rdbNonAcute, 1)) {
            fourpoint.click(fourpoint.rdbNonAcute);
        }

        if (fourpoint.isElementDisplayed(fourpoint.chkDEA, 1)) {
            fourpoint.click(fourpoint.chkDEA);
        }

        Reporter.logScreenShot(Status.PASS, currentStepMethodName, fourpoint.takeScreenShot(currentStepMethodName).getValue());
        fourpoint.clickAccept();
        if (checkForCAE()) {
            Assert.fail("CAE - Connexus Application Error - Four Point");
        }
        Reporter.log("4 point completed");
        return rxNbr;
    }

    @Override
    public boolean completeFilling(String rxNbr) {
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery("select first 1 order_id,order_seq_nbr,rx_fill_id from rx_order_detail rod " +
                "left join rx rx on rx.rx_id=rod.rx_id " +
                "where rod.next_work_que_code=4 " +
                "and rx.rx_nbr=" + rxNbr + " order by order_seq_nbr");
        if (rxInfo != null && StringUtils.isNotNullOrEmpty(rxInfo.get("order_id").toString()) && StringUtils.isNotNullOrEmpty(rxInfo.get("rx_fill_id").toString())) {
            int toteNbr = connexusAppUtils.getAvailableToteNbr();
            int res = 0;
            res = automationManager.getConnexusDB().executeUpdateQuery("update rx_fill set tech_of_rec_userid = \"SYSTEM\" where rx_fill_id = " + rxInfo.get("rx_fill_id"));
            if (res > 0) {
                res = automationManager.getConnexusDB().executeUpdateQuery("update rx_order_detail set tote_nbr = " + toteNbr + " where rx_fill_id = " + rxInfo.get("rx_fill_id"));
                if (res > 0) {
                    res = automationManager.getConnexusDB().executeInsertQuery("insert into rx_fill_activity values (" + rxInfo.get("rx_fill_id") + ",(select case when max(activity_seq_nbr) is null then 1 else max(activity_seq_nbr)+1 end from rx_fill_activity where rx_fill_id=" + rxInfo.get("rx_fill_id") + "),1119,CURRENT,\"SYSTEM\",\"\")");
                    if (res > 0) {
                        String retVal = automationManager.getConnexusDB().getScalar("call nextworkquerx(" + rxInfo.get("order_id") + "," + rxInfo.get("order_seq_nbr") + ")", String.class);
                        return StringUtils.isNotNullOrEmpty(retVal);
                    }
                }
            }
        }
        return false;
    }

    @Override
    public void completePartialFilling(String rxNbr) {
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery("select first 1 order_id,order_seq_nbr,rx_fill_id from rx_order_detail rod " +
                "left join rx rx on rx.rx_id=rod.rx_id " +
                "where rod.next_work_que_code=4 " +
                "and rx.rx_nbr=" + rxNbr + " order by order_seq_nbr");
        automationManager.getConnexusDB().getScalar("call removefill(" + rxInfo.get("order_id") + "," + rxInfo.get("order_seq_nbr") + "," + rxInfo.get("rx_fill_id") + ",'N0S06RK',4,'TEST5514',20403,0,'Y','Y',7000,'Y',1)", String.class);
        AutomationManager.getInstance().performSleep(5);
        automationManager.getConnexusDB().getScalar("call CreateNewFill(" + rxInfo.get("rx_fill_id") + "," + rxInfo.get("order_id") + "," + rxInfo.get("order_seq_nbr") + ",'N0S06RK',4,'TEST5514',1,'Y','N',798,'Y',NULL,NULL,'I','N',NULL,NULL,1)", String.class);
        AutomationManager.getInstance().performSleep(5);
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - completeResolution()
     * Description: This method is to complete Resolution
     * Inputs : rxNbr
     * returns:
     * Author: Lakshmi Priya(vn510nm)
     * *********************************************************************************************************************************************************
     */
    @Override
    public void completeResolution(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        ResolutionPage resolutionPage = new ResolutionPage();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(rxNbr);
        rxSearch.openFirstPatientRecord();
        if (rxSearch.isResolutionPageDisplayed()) {
            Reporter.log("Resolution page is displayed");
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
        }
        if (isElementDisplayed(resolutionPage.problemResolvedBtn, 5)) {
            resolutionPage.clickProblemResolvedBtn();
        }

        if (isElementDisplayed(resolutionPage.btnProblemResolved, 5)) {
            resolutionPage.clickProblemResolved();
        } else if (isElementDisplayed(resolutionPage.btnApproveEarlyRefill, 5)) {
            resolutionPage.clickApprovalCheckBox();
            resolutionPage.enterReasonForEarlyRefill();
            resolutionPage.clickApproveEarlyRefill();
        } else {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            resolutionPage.clickDownTime();
            if (isElementDisplayed(resolutionPage.txtCoPayAmt, 10)) {
                resolutionPage.enterCoPayAmt("0.0");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
                resolutionPage.clickAccept();
            }
            while (automationManager.getConnexusWorkFlow().checkRxWorkQue(rxNbr, WorkQueue.RESOLVE)) {
                rxSearch.launchOrderSearchScreen();
                rxSearch.performSearch(rxNbr);
                rxSearch.openFirstPatientRecord();
                resolutionPage.clickDownTime();
                resolutionPage.enterCoPayAmt("0.0");
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
                resolutionPage.clickAccept();
                Reporter.log("Resolution completed");
                resolutionPage.clickYesOnConfirmPopUp();
            }
        }
        Reporter.log("Resolution completed");
        resolutionPage.clickYesOnConfirmPopUp();
    }

    @Override
    public void completeResolutionForMultiRx(String rxNbr) throws AWTException {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        ResolutionPage resolutionPage = new ResolutionPage();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(rxNbr);
        rxSearch.openFirstPatientRecord();
        if (isElementDisplayed(resolutionPage.dawDropDown, 5)) {
            resolutionPage.clickDawDropdown();
        } else {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
            resolutionPage.clickProblemResolvedBtn();
        }
        Reporter.log("Resolution " + resolutionPage.takeScreenShot("Resolution").getKey());
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Resolution completed");
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - completeVisualVerify()
     * Description: This method is to complete Visual verify
     * Inputs : rxNbr
     * returns:
     * Author: Lakshmi Priya(vn510nm)
     * *********************************************************************************************************************************************************
     */
    @Override
    public void completeVisualVerify(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        VisVerPage visVerPage = new VisVerPage();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(rxNbr);
        rxSearch.openFirstPatientRecord();
        if (!rxSearch.isVisualVerifyPageDisplayed()) {
            captureUnExpectedResults(currentStepMethodName, "Visual Verify - page not loaded");
        }
        automationManager.performSleep(5);
        visVerPage.handleIHaveOrderPopUp();
        visVerPage.clickCancelButtonOnPopUp();
        automationManager.performSleep(3);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, visVerPage.takeScreenShot(currentStepMethodName).getValue());
        visVerPage.clickAccept();
        visVerPage.clickOk();
        visVerPage.clickOkButton();
        Reporter.log("Visual Verify completed");
    }

    @Override
    public void completeVisualVerify(String rxNbr, Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            FourPoint fourPoint = new FourPoint();
            ChkDur dur = new ChkDur();
            VisVerPage visVerPage = new VisVerPage();
            String counselReason;
            rxSearch.launchOrderSearchScreen();
            rxSearch.performSearch(rxNbr);
            rxSearch.openFirstPatientRecord();
            fourPoint.clickOkInEarlyRefillPopUp();
            if (fourPoint.isElementDisplayed(fourPoint.chkName)) {
                counselReason = fourPoint.getCounselReason();
                Assert.assertTrue(fourPoint.isCounselRequiredIn4point(), "Counsel required option is not checked");
                Assert.assertTrue(counselReason.contains(inputData.get("COUNSEL_REASON")), "Counsel reason is " + counselReason);
                Reporter.log("4point for VV - Validated that Counsel required checkbox is checked and disabled.");
                Reporter.log("Counsel reason is " + counselReason);
                fourPoint.chkName();
                fourPoint.chkPrescribed();
                fourPoint.chkStrength();
                fourPoint.chkSIG();
                fourPoint.chkDEA();
                Reporter.logScreenShot(Status.PASS, "Screenshot of 4 point screen", visVerPage.takeScreenShot(currentStepMethodName).getValue());
                fourPoint.clickAccept();
                if (fourPoint.isElementDisplayed(fourPoint.txtSiteIdOnRphPopUp, 5)) {
                    fourPoint.performRPHValidation();
                }
                Reporter.log("Four point completed from visual verify");
                fourPoint.clickOkInEarlyRefillPopUp();
            }
            // At this point we are checking for counsel required in Visual Verify
            counselReason = fourPoint.getCounselReason();
            Assert.assertEquals(dur.getCounselToggleState(), "1");
            Assert.assertTrue(counselReason.contains(inputData.get("COUNSEL_REASON")), "Counsel reason is " + counselReason);
            Reporter.log("VisualVerify - Validated that Counsel required checkbox is checked and disabled.");
            Reporter.log("Counsel reason is " + counselReason);
            fourPoint.clickOkInEarlyRefillPopUp();
            Reporter.logScreenShot(Status.PASS, "Screenshot of VisualVerify screen", visVerPage.takeScreenShot(currentStepMethodName).getValue());
            fourPoint.clickAccept();
            fourPoint.clickOkInEarlyRefillPopUp();
            fourPoint.clickAccept();
            if (fourPoint.isElementDisplayed(fourPoint.txtSiteIdOnRphPopUp, 5)) {
                fourPoint.performRPHValidation();
            }
            fourPoint.clickAccept();
            fourPoint.clickOkInEarlyRefillPopUp();
            Reporter.log("Visual Verify Completed");
        } catch (Throwable e) {
            Reporter.log("Test failed at Visual Verify queue");
            e.printStackTrace();
            Assert.fail(e.toString());
        }
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - completeBagging()
     * Description: This method is to complete Bagging
     * Inputs : rxNbr
     * returns:
     * Author: Preetha
     * *********************************************************************************************************************************************************
     */
    @Override
    public boolean completeBagging(String rxNbr) {
        Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery("select first 1 order_id,order_seq_nbr,rx_fill_id from rx_order_detail rod " +
                "left join rx rx on rx.rx_id=rod.rx_id " +
                "where rod.next_work_que_code=28 " +
                "and rx.rx_nbr=" + rxNbr + " order by order_seq_nbr");
        if (rxInfo != null && StringUtils.isNotNullOrEmpty(rxInfo.get("order_id").toString()) && StringUtils.isNotNullOrEmpty(rxInfo.get("rx_fill_id").toString())) {
            int res = 0;
            res = automationManager.getConnexusDB().executeUpdateQuery("update rx_fill set bagging_userid = \"AUTOMATION\" where rx_fill_id = " + rxInfo.get("rx_fill_id"));
            if (res > 0) {
                String retVal = automationManager.getConnexusDB().getScalar("call nextworkquerx(" + rxInfo.get("order_id") + "," + rxInfo.get("order_seq_nbr") + ")", String.class);
                return StringUtils.isNotNullOrEmpty(retVal);
            }
        }
        Reporter.log("Bagging Completed");
        return false;
    }

    @Override
    public PatientProfileModel searchAndCreatePatient(boolean isAllFieldRequire, PatientProfileModel patient) {
        //Search If Patient Exist
        patientMaintenancePage = new PatientMaintenancePage();
        if (patientMaintenancePage.isPatientExist(false, patient)) {
            Reporter.log("Patient Exist");
        } else {
            createNewPatient(isAllFieldRequire, patient);
        }
        return patient;
    }

    @Override
    public PatientProfileModel searchAndCreatePatientForNullPhonenumberCheck(boolean isAllFieldRequire, PatientProfileModel patient) {
        //Search If Patient Exist
        patientMaintenancePage = new PatientMaintenancePage();
        if (patientMaintenancePage.isPatientExist(false, patient)) {
            return patient;
        } else {
            createNewPatient(isAllFieldRequire, patient);
        }
        return patient;
    }

    /**
     * Create a new patient, modified to remove the duplicate methods for creating patient.
     * Author: Srinivas(Srinivas) / Johnvinothkumar(vn58my9)
     */
    @Override
    public PatientProfileModel createNewPatient(boolean thirdParty, PatientProfileModel patient) {
        return createNewPatient(thirdParty, patient, false);
    }


    public PatientProfileModel createNewPatient(boolean thirdParty, PatientProfileModel patient,boolean isupdateProfile) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        patientSearchPage = new PatientSearchPage();
        patientMaintenancePage = new PatientMaintenancePage();
        patientSearchPage.launchPatientSearchScreen();
        if (!patientSearchPage.isPatientSearchWindowDisplayed()) {
            captureUnExpectedResults(currentStepMethodName, "Patient search screen not launched");
        }
        Log.info("Patient Name: " + patient.getPatientLastName() + "," + patient.getPatientFirstName());
        patientSearchPage.inputPatientName(patient.getPatientLastName() + "," + patient.getPatientFirstName());
        Log.info("DOB: " + patient.getPatientDob());
        patientSearchPage.inputPatientDob(patient.getPatientDob());
        patientSearchPage.clickSearchNow();
        patientSearchPage.hostSearchPatient();
        patientSearchPage.clickNew();

        if (!patientMaintenancePage.isGeneralInfoTabDisplayed()) {
            captureUnExpectedResults(currentStepMethodName, "Patient Maintenance - General Information Page not Loaded");
        }

        this.selectPatientType(patient);

        patientMaintenancePage.selectGender(patient.getPatientGender());
        patientMaintenancePage.inputAddressLine1(patient.getPatientAddress().getPatientAddressLine1());
        patientMaintenancePage.ZipCode(patient.getPatientAddress().getPatientZipCode());

        if (patientMaintenancePage.isOkDisplayed()) {
            patientMaintenancePage.clickOk();
            Reporter.log("On Selecting Zip code City and State arent auto populated and validation service found to be down");
            patientMaintenancePage.inputCity(patient.getPatientAddress().getPatientCity());
            patientMaintenancePage.selectState(patient.getPatientAddress().getPatientState());
            patientMaintenancePage.clickOk();
        }

        this.checkAndUpdateContactInformation(patient);
        this.checkAndUpdatePatientAllergies(patient);
        if (isupdateProfile) {
            patientMaintenancePage.clickTabProfile();
            patientMaintenancePage.checkFillPrescriptionsAtThisFacilityOnly();
        }
        this.checkAndUpdateSSNDL(patient);

        if ("TRUE".equals(patient.getPatientInsulinInd())) {
            patientMaintenancePage.clickAllergyMedicalTab();
            if (patientMaintenancePage.isChkInsulinDependentDisabledInAllergy()) {
                patientMaintenancePage.checkInsulinDependentInAllergy();
            }
            if (patientMaintenancePage.isChkInsulinPumpDisplayedInAllergy()) {
                patientMaintenancePage.checkInsulinPumpInAllergy();
            }
        }

        if (thirdParty) {
            patientMaintenancePage.inputCarrierBin(patient.getPatientTp().getCarrierBin());
            patientMaintenancePage.inputCardId(patient.getPatientTp().getCardId());
            patientMaintenancePage.checkSameAsPatient();
            patientMaintenancePage.selectPlan(patient.getPatientTp().getPlan(), patient.getPatientTp().getCarrierBin());
        }

        Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        patientMaintenancePage.clickSaveAndClose();

        patientMaintenancePage.isValidationPopup();

        if (!patientMaintenancePage.isPatientCreated(patient.getPetLiveStockInfo() != null, patient.getPatientLastName() + "," + patient.getPatientFirstName())) {
            captureUnExpectedResults(currentStepMethodName, "New Patient Creation Failed");
        }

        if (thirdParty && patient.getPatientTp().getCarrierBin2() != null) {
            patientMaintenancePage.openFirstPatientRecord();
            patientMaintenancePage.addAdditionalTPPlan(patient.getPatientTp().getCarrierBin2(), patient.getPatientTp().getPlan2(), patient.getPatientTp().getCardId2());
            if (patient.getPatientTp().getCarrierBin3() != null) {
                patientMaintenancePage.addAdditionalTPPlan(patient.getPatientTp().getCarrierBin3(), patient.getPatientTp().getPlan3(), patient.getPatientTp().getCardId3());
            }
            patientMaintenancePage.clickSaveAndClose();
        patientMaintenancePage.isValidationPopup();
    }
        if (isGrpcMode()) {
        patientSearchPage.closeSearchAndReturnToMainGrpc();
    } else {
        patientSearchPage.clickClose();
    }
        return patient;
    }

    public void selectPatientType(PatientProfileModel patient) {
        patientMaintenancePage.selectPatientType(patient.getPatientType());
        if (patient.getPatientType().equals(PatientProfileModel.PatientType.PET)) {
            patientSearchPage.inputOwnerFirstName(patient.getPatientFirstName());
            patientMaintenancePage.selectPetLiveStockType(patient.getPetLiveStockInfo());
            patientSearchPage.clickAccept();
        }
    }

    public void checkAndUpdateContactInformation(PatientProfileModel patient) {
        if (connexusAppUtils.isFlagEnabled("26849")) {
            if ((patient.getPatientContact().getPatientPrimaryNumber()) != null) {
                patientMaintenancePage.inputPrimaryPhoneNumber(patient.getPatientContact().getPatientPrimaryNumber());
            }
            if ((patient.getPatientContact().getPatientAlternateNumber()) != null) {
                patientMaintenancePage.inputAlternatePhoneNumber(patient.getPatientContact().getPatientAlternateNumber());
            }
            if (patient.getPatientContact().getPatientMessagingNumber() != null) {
                patientMaintenancePage.inputMessagingPhoneNumber(patient.getPatientContact().getPatientMessagingNumber());
                patientMaintenancePage.clickMessagingTextRdBtn();
            }
            if (patient.getPatientContact().getClinicalServicesNumber() != null) {
                patientMaintenancePage.inputClinicalServicePhoneNumber(patient.getPatientContact().getClinicalServicesNumber());
            }
        } else {
            if ((patient.getPatientContact().getPatientPhoneNumber1()) != null) {
                patientMaintenancePage.inputPhoneNumber1(patient.getPatientContact().getPatientPhoneNumber1());
            }
            if ((patient.getPatientContact().getPatientPhoneNumber2()) != null) {
                patientMaintenancePage.inputPhoneNumber2(patient.getPatientContact().getPatientPhoneNumber2());
            }
            if ((patient.getPatientContact().getPatientPhoneNumber3()) != null) {
                patientMaintenancePage.inputPhoneNumber3(patient.getPatientContact().getPatientPhoneNumber3());
            }
            if (patient.getPatientContact().getPreferredPhoneNumber() != null) {
                patientMaintenancePage.setPreferredPhoneNumber(patient.getPatientContact().getPreferredPhoneNumber());
            }
        }
    }

    public void checkAndUpdatePatientAllergies(PatientProfileModel patient) {
        if (patient.getPatientAllergy() == null || patient.getPatientAllergy().isEmpty()) {
            patientMaintenancePage.setPatientAllergy(patient.getPatientMedicalConditionModel().getAllergies());
            patientMaintenancePage.setMedicalCondition(patient.getPatientMedicalConditionModel().getMedicalCondition());
        } else {
            patientMaintenancePage.setMedicalCondition(patient.getPatientMedicalConditionModel().getMedicalCondition());
            patientMaintenancePage.setPatientAllergy(patient.getPatientMedicalConditionModel().getAllergies());
            patientMaintenancePage.addAllergy(patient.getPatientAllergy());
            patientMaintenancePage.clickReturnToGeneralInformation();
        }
    }

    public void checkAndUpdateSSNDL(PatientProfileModel patient) {
        if (patient.getPatientIdentityModel() != null) {
            if (patient.getPatientIdentityModel().getPatientDrivingLicenseNumber() != null) {
                patientMaintenancePage.inputDrivingLicenseNumber(patient.getPatientIdentityModel().getPatientDrivingLicenseNumber());
                if (patient.getPatientIdentityModel().getPatientDrivingLicenseNumber() != null) {
                    patientMaintenancePage.inputDrivingLicenseState(patient.getPatientIdentityModel().getPatientDrivingLicenseState());
                }
                if (patient.getPatientIdentityModel().getPatientDrivingLicenseNumber() != null) {
                    patientMaintenancePage.inputDrivingLicenseExpiryDate(patient.getPatientIdentityModel().getDrivingLicenseExpiryDate());
                }
            }

            if (patient.getPatientIdentityModel().getPatientSSNNumber() != 0) {
                patientMaintenancePage.inputSSN(String.valueOf(patient.getPatientIdentityModel().getPatientSSNNumber()));
            }
        }
    }

    /*
     * *********************************************************************************************************************************************************
     * Function Name - checkRxWorkQue()
     * Description: This method is to check if an Rx has moved to specific queue or not.
     * Inputs : rxNbr
     * returns: boolean
     * Author: Shalini Devaraj
     * *********************************************************************************************************************************************************
     */

    @Override
    public boolean checkRxWorkQue(String rxNbr, WorkQueue queue) {
        boolean isInQueue = false;
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(rxNbr);
        if (rxSearch.getWorkQueue(0).equalsIgnoreCase(queue.getWorkQueue())) {
            isInQueue = true;

        } else {
            rxSearch.pressKeys(KeyEvent.VK_F6);
        }
        rxSearch.closeSearch();
        if (isInQueue) {
            Reporter.log("Rx is in " + queue.getWorkQueue() + " queue");
        } else {
            Reporter.log("Rx is not in " + queue.getWorkQueue() + " queue");
        }
        return isInQueue;
    }

    public String getFillId(String rxNbr) {
        String fillId = null;
        try {
            String query = "select max(rx_fill_id) as rx_fill_id  from  rx_order_detail where rx_id =(select rx_id from rx where rx_nbr=\"" + rxNbr + "\") and next_work_que_code ='6'";
            Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
            fillId = rxInfo.get("rx_fill_id").toString();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return fillId;
    }

    public boolean isControlledDrug(String rxNbr) {
        try {
            String query = "select drug_control_code from pharmacy_offering:pharmacy_product where product_mds_fam_id = (select product_mds_fam_id from rx where rx_nbr=\"" + rxNbr + "\")";
            Map<String, Object> rxInfo = automationManager.getConnexusDB().executeQuery(query);
            Integer drugControlCode = Integer.parseInt(rxInfo.get("drug_control_code").toString());
            return !drugControlCode.equals(2034);
        } catch (Exception exception) {
            Assert.fail(exception.getMessage());
        }
        return false;
    }

    @Override
    public void completePickup(String firstName, String lastName, String dob, String rxNbr) {
        completePickup(firstName, lastName, dob, rxNbr, false, false);
    }

    @Override
    public void completePickup(String firstName, String lastName, String dob, String rxNbr, boolean counselRequiredCheck) {
        completePickup(firstName, lastName, dob, rxNbr, counselRequiredCheck, false);
    }

    /* *********************************************************************************************************************************************************
     * Function Name - completePickup()
     * Description: This method is complete  Pickup
     * Inputs : firstName,lastName,DOB,fillId
     * returns:void
     * Author: Preetha
     * *********************************************************************************************************************************************************
     */
    @Override
    public void completePickup(String firstName, String lastName, String dob, String rxNbr, boolean counselRequiredCheck, boolean tascoCheck) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        TascoPage tascoPage = new TascoPage();
        PickupPage pickupPage = new PickupPage();
        tascoPage.launchTascoScreen();
        tascoPage.inputPatientLastName(lastName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientFirstName(firstName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientDob(dob);
        tascoPage.pressTabKey();
        tascoPage.pressTabKey();
        tascoPage.clickSearchOnTascoPage();
        tascoPage.clickRow(0);
        tascoPage.medicarevalidationpopup();
        tascoPage.continueCheckout();
        tascoPage.handleOtherOrdersAvailablePopUp();
        if (tascoCheck) {
            String tascoPaymentCheck = tascoPage.getRxPaymentMode();
            if (tascoPaymentCheck.contains("THIRD PARTY")) {
                Reporter.log("Tasco - Payment section appeared as 'THIRD PARTY INSURANCE'.");
            } else if (tascoPaymentCheck.contains("CASH")) {
                Reporter.log("Tasco - Payment section appeared as 'CASH'.");
            } else {
                Assert.fail("Unexpected payment type: " + tascoPaymentCheck);
            }
            Reporter.log("Payment Type is :" + tascoPaymentCheck);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, takeScreenShot(currentStepMethodName).getValue());
        }
        if (!tascoPage.validateCheckoutBkt()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, takeScreenShot(currentStepMethodName).getValue());
            Assert.fail("Checkout button not enabled on tasco screen");
            return;
        }
        tascoPage.clickCheckout();
        tascoPage.handleConnexusCheckoutCashPayPopup();
        if (isControlledDrug(rxNbr)) {
            tascoPage.handleControlIdSubstanceForControlledDrugPopup();
            tascoPage.handleIdAndRelationshipForControlledDrugPopup();
            tascoPage.handleCustomerIdDetailsForControlledDrugPopup();
            tascoPage.handleCustomerIdDetailsscreen();
        }
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        tascoPage.handlePatientCentralDataUpdatePayPopup();
        tascoPage.clickBtnOK();
        String fillId = getFillId(rxNbr);
        String siteId = prop.getProperty("cnx.store");
        Log.info(fillId);
        if (counselRequiredCheck) {
            // Checks for counsel required in pickup
            Assert.assertEquals(pickupPage.getCounselStatus(0), "Y");
            Reporter.log("Pickup - Validated that Counsel value is Y .");
        }
        List<Map<String, Object>> resultSet = connexusAppUtils.verifySubQueTypeCode(rxNbr);
        String subQueTypeCode = "";
        if (resultSet.get(0).get("sub_que_type_code") != null) {
            subQueTypeCode = resultSet.get(0).get("sub_que_type_code").toString();
        }
        if (subQueTypeCode.equalsIgnoreCase(prop.getProperty("cf.subq.code"))) {
            if (tascoPage.isToteNbrDisplayed()) {
                for (String scanCode : scanPickUpCodeForCF) {
                    tascoPage.scanRx(scanCode);
                }
            } else {
                tascoPage.scanRx("4793" + fillId + "0");
            }
        } else {
            if (tascoPage.isToteNbrDisplayed()) {
                if (siteId.length() == 4) {
                    tascoPage.scanRx("0" + siteId + "00" + rxNbr + "0000");
                } else {
                    tascoPage.scanRx(siteId + "00" + rxNbr + "0000");
                }
            } else if (tascoPage.isTxtCounselCommentsDisplayed()) {
                tascoPage.scanRx("4793" + fillId + "0");
            }
        }
        tascoPage.clickBtnNo(); //to handle Do you have any questions on your prescription for the Pharmacist today? popup
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.handleDoYouHaveAnyQuestionsToTheDoctorPopup();
        tascoPage.clickAcceptCheckout();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.clickOk();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        if (tascoPage.clickPatientRefused()) {
            tascoPage.clickOk();
        } else {
            tascoPage.clickCancel();
        }
        tascoPage.handleCheckoutPopUpForTp();
        tascoPage.clickOk();
        tascoPage.clickSignOff();
        Reporter.log("pickup Completed");
    }

    @Override
    public void completeCounsel(String rxNbr) {
        completeCounsel(rxNbr, null, false);
    }

    /* *********************************************************************************************************************************************************
     * Function Name - completeCounsel()
     * Description: This method is complete Counsel
     * Inputs : rxNbr
     * returns:void
     * Author: Preetha
     * *********************************************************************************************************************************************************
     */
    @Override
    public void completeCounsel(String rxNbr, Map<String, String> inputData, boolean counselRequiredCheck) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        CounselPage counselPage = new CounselPage();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(rxNbr);
        rxSearch.openFirstPatientRecord();
        if (rxSearch.isCounselingPageDisplayed()) {
            if (counselPage.isElementDisplayed(counselPage.counselReason, ConnexusConstants.WAIT_TIMEOUT_10)) {
                if (counselRequiredCheck) {
                    String counselReason = counselPage.getCounselReason();
                    Assert.assertTrue(counselReason.contains(inputData.get("COUNSEL_REASON")), "Counsel reason is " + counselReason);
                    Reporter.log("Counselling - Validated that Counsel reason is " + inputData.get("COUNSEL_REASON"));
                }
                counselPage.acceptAll();
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, counselPage.takeScreenShot(currentStepMethodName).getValue());
                counselPage.clickAccept();
                Reporter.log("Counsel Completed");
            } else {
                Assert.fail("Failed to complete counselling");
            }
        } else {
            captureUnExpectedResults(currentStepMethodName, "Counsel - page not loaded");
        }
    }

    /* *********************************************************************************************************************************************************
     * Function Name - completeOfflineSale()
     * Description: This method is complete EOD
     * Inputs : rxNbr
     * returns:void
     * Author: Preetha
     * *********************************************************************************************************************************************************
     */
    @Override
    public void completeOfflineSale(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        F6Search search = new F6Search();
        search.launchOrderSearchScreen();
        search.performSearch(rxNbr);
        //below screenshot line is mandatory for other scenarios to Verify that RX is in POS queue before performing the action.
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, search.takeScreenShot(currentStepMethodName).getValue());
        search.clickOfflineSold();
        search.clickSoldAccept();
        search.clickSoldYes();
        search.clickSoldOk();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, search.takeScreenShot(currentStepMethodName).getValue());
        search.closeSearch();
        Reporter.log("RX moved to EOD");
    }

    /* *********************************************************************************************************************************************************
     * Function Name - createNewPrecriber()
     * Description: creates new prescriber
     * Inputs : inpudata
     * returns:void
     * Author: Narayanaswamy
     * *********************************************************************************************************************************************************
     */
    @Override
    public void createNewPrescriber(Map<String, String> inputData) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            PrescriberSearchPage prescriberSearchPage = new PrescriberSearchPage();
            MenuBar menuBar = new MenuBar();
            connexusAppUtils.addRandomNamesInFileWithFullName();
            String[] name = connexusAppUtils.readPatientNameFromFileWithFullName();
            //menuBar.navigateToMenu(AppMenu.PRESCRIBER);
            prescriberSearchPage.launchPrescriberSearchScreen();
            prescriberSearchPage.inputPrescriberName(name[0] + "," + name[1] + " " + name[2]);
            prescriberSearchPage.clickSearchStore();
            prescriberSearchPage.clickSearchHost();
            prescriberSearchPage.clickNew();
            prescriberSearchPage.enterPrescriberLastNameFromMaintenanceScreen(name[0]);
            prescriberSearchPage.enterPrescriberFirstNameFromMaintenanceScreen(name[1]);
            prescriberSearchPage.enterPrescriberMiddleNameFromMaintenanceScreen(name[2]);
            prescriberSearchPage.selectPrescriberDegree(inputData.get("PRESCRIBER_DEGREE"));
            prescriberSearchPage.selectPrescriberSpeciality(inputData.get("PRESCRIBER_SPECIALITY"));
            prescriberSearchPage.selectResidentYes(inputData.get("RESIDENT_TYPE"));
            prescriberSearchPage.selectLicence(inputData.get("Licence_Type"));
            prescriberSearchPage.enterLicenceNumber(inputData.get("Licence_Number"));
            prescriberSearchPage.enterSuffix(inputData.get("SUFFIX"));
            prescriberSearchPage.selectIssueState(inputData.get("Issue_State"));
            prescriberSearchPage.enterLicenceLicenceExpiryDate(inputData.get("Expiry_Date"));
            prescriberSearchPage.selectLicenceStatus(inputData.get("Licence_Status"));
            prescriberSearchPage.clickAddLocationButton();
            prescriberSearchPage.enterAddress(inputData.get("Precriber_Address"));
            prescriberSearchPage.enterCity(inputData.get("CITY"));
            prescriberSearchPage.selectState(inputData.get("STATE"));
            prescriberSearchPage.enterZipCode(inputData.get("Prescriber_Zipcode"));
            prescriberSearchPage.enterOfficePhoneNumber(inputData.get("Prscriber_PhoneNumber"));
            prescriberSearchPage.clickSaveLocationButton();
            if (prescriberSearchPage.getPrescriberName(0).trim().equalsIgnoreCase(name[0] + "," + name[1] + " " + name[2].substring(0, 1))) {
                Reporter.logScreenShot(currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
            } else {
                Reporter.logScreenShot(currentStepMethodName, prescriberSearchPage.takeScreenShot(currentStepMethodName).getValue());
                prescriberSearchPage.clickClose();
                Assert.fail("Failed to create Prescriber");
            }
            prescriberSearchPage.clickClose();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void completeResolutionForRefills(String rxNbr, String refills, String approvingPrescriber) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        ResolutionPage resolutionPage = new ResolutionPage();
        DropOffPage dropOffPage = new DropOffPage();
        F6Search search = new F6Search();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(rxNbr);
        rxSearch.openFirstPatientRecord();
        resolutionPage.clickRefillAuth();
        resolutionPage.enterRefills(refills);
        dropOffPage.selectListItemfromRxOriginType();
        resolutionPage.enterApprovingPrescriber(approvingPrescriber);
        resolutionPage.clickAccept();
        Reporter.log("Resolution " + resolutionPage.takeScreenShot("Resolution").getKey());
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Resolution completed");
    }

    @Override
    public void completeResolutionForEarlyRefill(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        ResolutionPage resolutionPage = new ResolutionPage();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(rxNbr);
        rxSearch.openFirstPatientRecord();
        resolutionPage.clickApprovalCheckBox();
        resolutionPage.enterReasonForEarlyRefill();
        resolutionPage.clickApproveEarlyRefill();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, resolutionPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Resolution completed");
    }


    @Override
    public void checkAndPerformCheckDURResolved(String rxNumber) {
        ChkDur dur = new ChkDur();
        if (dur.isCheckDUREligible(rxNumber)) {
            rxSearch.launchOrderSearchScreen();
            rxSearch.performSearch(rxNumber);
            rxSearch.openFirstPatientRecord();
            dur.isPopupDisplayed();
            if (dur.clickRedFlagsBtn()) {
                dur.selectResolvedCheckBoxes();
            }
            if (dur.clickDurBtn()) {
                dur.selectDurCheckBoxes();
                dur.clickNarxCareCheckBox();
            }
            Reporter.logScreenShot(Status.INFO, "Screenshot of ChkDUR Page", dur.takeScreenShot("ChkDUR").getValue());
            dur.clickAccept();
            dur.clickConnexusOk();
            if ("Resolve".equalsIgnoreCase(dur.getWorkQueue(0))) {
                dur.selectRowFromSearch(0);
                dur.clickDownTime();
            }
            if (checkForCAE()) {
                Assert.fail("CAE - Connexus Application Error - Check Dur");
            }
            Reporter.log("ChkDUR completed");
        } else {
            Reporter.log("Rx not in ChkDUR Queue");
        }
    }

    @Override
    public void performCheckDurForMultiRx(String rxNumber) {
        ChkDur dur = new ChkDur();
        automationManager.performSleep(5);
        if (dur.isCheckDUREligible(rxNumber)) {
            rxSearch.launchOrderSearchScreen();
            rxSearch.performSearch(rxNumber);
            rxSearch.openFirstPatientRecord();
            if (!dur.clickClearConflictsBtn()) {
                dur.selectCheckBoxes();
            }
            dur.clickNarxCareCheckBox();
            Reporter.logScreenShot(Status.INFO, "Screenshot of ChkDUR Page", dur.takeScreenShot("ChkDUR").getValue());
            automationManager.performSleep(5);
            dur.clickAccept();
            dur.clickConnexusOk();
            if (checkForCAE()) {
                Assert.fail("CAE - Connexus Application Error - Check Dur");
            }
            Reporter.log("ChkDUR completed");
        }
    }

    @Override
    public void completeMultiRxPickup(String firstName, String lastName, String dob, List<String> rxNbr, String siteId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        TascoPage tascoPage = new TascoPage();
        tascoPage.launchTascoScreen();
        automationManager.performSleep(5);
        tascoPage.inputPatientLastName(lastName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientFirstName(firstName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientDob(dob);
        tascoPage.pressTabKey();
        tascoPage.pressTabKey();
        tascoPage.clickSearchOnTascoPage();
        tascoPage.clickRow(0);
        tascoPage.medicarevalidationpopup();
        tascoPage.continueCheckout();
        tascoPage.handleOtherOrdersAvailablePopUp();
        if (!tascoPage.validateCheckoutBkt()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, takeScreenShot(currentStepMethodName).getValue());
            org.junit.Assert.fail("Checkout button not enabled on tasco screen");
            return;
        }
        tascoPage.clickCheckout();
        tascoPage.handleConnexusCheckoutCashPayPopup();
        tascoPage.handleControlIdSubstanceForControlledDrugPopup();
        tascoPage.handleIdAndRelationshipForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsscreen();
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        for (int i = 0; i < rxNbr.size(); i++) {
            String fillId = getFillId(rxNbr.get(i));
            siteId = prop.getProperty("cnx.store");
            Log.info(fillId);
            List<Map<String, Object>> resultSet = connexusAppUtils.verifySubQueTypeCode(rxNbr.get(i));
            String subQueTypeCode = "";
            if (resultSet.get(0).get("sub_que_type_code") != null) {
                subQueTypeCode = resultSet.get(0).get("sub_que_type_code").toString();
            }
            if (subQueTypeCode.equalsIgnoreCase(prop.getProperty("cf.subq.code"))) {
                if (tascoPage.isToteNbrDisplayed()) {
                    for (String scanCode : scanPickUpCodeForCF) {
                        tascoPage.scanRx(scanCode);
                    }
                } else {
                    tascoPage.scanRx("4793" + fillId + "0");
                }
            } else {
                if (tascoPage.isToteNbrDisplayed()) {
                    if (siteId.length() == 4) {
                        tascoPage.scanRx("0" + siteId + "00" + rxNbr.get(i) + "0000");
                    } else {
                        tascoPage.scanRx(siteId + "00" + rxNbr.get(i) + "0000");
                    }
                } else if (tascoPage.isTxtCounselCommentsDisplayed()) {
                    tascoPage.scanRx("4793" + fillId + "0");
                }
            }
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.handleDoYouHaveAnyQuestionsToTheDoctorPopup();
        tascoPage.clickAcceptCheckout();
        tascoPage.clickOk();
        tascoPage.cancelPickUpValidation();
        tascoPage.clickPatientRefused();
        tascoPage.clickOk();
        tascoPage.handleCheckoutPopUpForTp();
        tascoPage.clickSignOff();
        Reporter.log("pickup Completed");
    }

    @Override
    public void completePickupWithSSNValidation(String firstName, String lastName, String dob, String rxNbr, String siteID) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        TascoPage tascoPage = new TascoPage();
        tascoPage.launchTascoScreen();
        System.out.println("in pickup" + lastName + ',' + firstName + ',' + dob);
        tascoPage.inputPatientLastName(lastName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientFirstName(firstName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientDob(dob);
        tascoPage.pressTabKey();
        tascoPage.pressTabKey();
        tascoPage.clickSearchOnTascoPage();
        tascoPage.clickRow(0);
        tascoPage.handleOtherOrdersAvailablePopUp();
        if (!tascoPage.validateCheckoutBkt()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, takeScreenShot(currentStepMethodName).getValue());
            org.junit.Assert.fail("Checkout button not enabled on tasco screen");
            return;
        }
        tascoPage.continueCheckout();
        tascoPage.clickCheckout();
        //tascoPage.continueCheckout();
        //tascoPage.handlePayCashPricePopUp();
        Assert.assertEquals(tascoPage.getTextForSSN(), "Patient does not have SSN", "SSN id capture window is not displayed");
        automationManager.performSleep(3);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.handleSSNCaptureWindow();
        tascoPage.handleConnexusCheckoutCashPayPopup();
        tascoPage.handleControlIdSubstanceForControlledDrugPopup();
        tascoPage.handleIdAndRelationshipForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsscreen();
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        String fillId = getFillId(rxNbr);
        Log.info(fillId);
        String siteId = prop.getProperty("cnx.store");
        if (tascoPage.isToteNbrDisplayed()) {
            if (siteId.length() == 4) {
                tascoPage.scanRx("0" + siteId + "00" + rxNbr + "0000");
            } else {
                tascoPage.scanRx(siteId + "00" + rxNbr + "0000");
            }
        } else if (tascoPage.isTxtCounselCommentsDisplayed()) {
            tascoPage.scanRx("4793" + fillId + "0");
        }
        automationManager.performSleep(5);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.handleDoYouHaveAnyQuestionsToTheDoctorPopup();
        tascoPage.clickAcceptCheckout();
        tascoPage.clickOk();
        tascoPage.clickPatientRefused();
        tascoPage.clickOk();
        tascoPage.handleCheckoutPopUpForTp();
        tascoPage.clickSignOff();
        Reporter.log("pickup Completed");
    }

    @Override
    public void completePickupWithOutSSN(String firstName, String lastName, String dob, String rxNbr, String siteId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        TascoPage tascoPage = new TascoPage();
        tascoPage.launchTascoScreen();
        tascoPage.inputPatientLastName(lastName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientFirstName(firstName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientDob(dob);
        tascoPage.pressTabKey();
        tascoPage.pressTabKey();
        tascoPage.clickSearchOnTascoPage();
        tascoPage.clickRow(0);
        tascoPage.handleOtherOrdersAvailablePopUp();
        if (!tascoPage.validateCheckoutBkt()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, takeScreenShot(currentStepMethodName).getValue());
            org.junit.Assert.fail("Checkout button not enabled on tasco screen");
            return;
        }
        tascoPage.continueCheckout();
        tascoPage.clickCheckout();
        //tascoPage.continueCheckout();
        //tascoPage.handlePayCashPricePopUp();
        tascoPage.handleConnexusCheckoutCashPayPopup();
        tascoPage.handleControlIdSubstanceForControlledDrugPopup();
        tascoPage.handleIdAndRelationshipForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsscreen();
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        String fillId = getFillId(rxNbr);
        Log.info(fillId);
        if (siteId.length() == 4) {
            tascoPage.scanRx("0" + siteId + "00" + rxNbr + "0000");
            tascoPage.pressTabKey();
        } else {
            tascoPage.scanRx(siteId + "00" + rxNbr + "0000");
            tascoPage.pressTabKey();
        }
        automationManager.performSleep(5);
        tascoPage.ClickOkInScannedRxNotBelongingPopUp();
        automationManager.performSleep(5);
        if (!tascoPage.isAcceptButtonEnabled()) {
            tascoPage.scanRx("4793" + fillId + "0");
            tascoPage.pressTabKey();
        }
        automationManager.performSleep(5);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.handleDoYouHaveAnyQuestionsToTheDoctorPopup();
        tascoPage.clickAcceptCheckout();
        tascoPage.clickOk();
        tascoPage.clickPatientRefused();
        tascoPage.clickOk();
        tascoPage.handleCheckoutPopUpForTp();
        tascoPage.clickSignOff();
        Reporter.log("pickup Completed");
    }

    @Override
    public PatientProfileModel searchAndCreatePatientForPetAndLiveStock(boolean isAllFieldRequire, PatientProfileModel patient) {

        String currentStepMethodName = StackUtils.getCurrentMethodName();

        PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();

        //Search If Patient Exist
        if (!patientSearchPage.verifyPatientSearchScreen()) {
            patientSearchPage.launchPatientSearchScreen();
        }
        patientSearchPage.inputPatientName(patient.getPatientLastName() + "," + patient.getPatientFirstName());
        patientSearchPage.inputPatientDob(patient.getPatientDob());

        patientSearchPage.clickSearchNow();
        if (patientSearchPage.isPatientRecordDisplayed(0) &&
                patientSearchPage.getPatientNameFromSearchGrid(0).equalsIgnoreCase(patient.getPatientLastName() + "," + patient.getPatientFirstName())) {
            patientSearchPage.openFirstPatientRecord();
            return patient;
        } else {
            patientSearchPage.hostSearchPatient();
        }
        patientSearchPage.clickNew();

        //Create Patient
        patientMaintenancePage.selectPatientType(patient.getPatientType());
        patientSearchPage.inputOwnerFirstName(patient.getPatientFirstName());
        patientMaintenancePage.selectPetLiveStockType(patient.getPetLiveStockInfo());
        patientMaintenancePage.clickUnknownBirthDateCheckbox();
        patientSearchPage.clickAccept();
        patientMaintenancePage.selectGender(patient.getPatientGender());
        // patientMaintenancePage.inputPrimaryPhoneNumber(patient.getPatientContact().getPatientPrimaryNumber());
        patientMaintenancePage.inputAddressLine1(patient.getPatientAddress().getPatientAddressLine1());
        //patientMaintenancePage.inputCity(patient.getPatientAddress().getPatientCity());
        patientMaintenancePage.ZipCode(patient.getPatientAddress().getPatientZipCode());
        if (patientMaintenancePage.isOkDisplayed()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            patientMaintenancePage.clickOk();
            Reporter.log("On Selecting Zip code City and State arent auto populated and validation service found to be down");
        }

        if ((patient.getPatientContact().getPatientPrimaryNumber()) != null) {
            patientMaintenancePage.inputPrimaryPhoneNumber(patient.getPatientContact().getPatientPrimaryNumber());
        }
        if ((patient.getPatientContact().getPatientAlternateNumber()) != null) {
            patientMaintenancePage.inputAlternatePhoneNumber(patient.getPatientContact().getPatientAlternateNumber());
        }
        if (patient.getPatientContact().getPatientMessagingNumber() != null) {
            patientMaintenancePage.inputMessagingPhoneNumber(patient.getPatientContact().getPatientMessagingNumber());
        }
        if (patient.getPatientContact().getClinicalServicesNumber() != null) {
            patientMaintenancePage.inputClinicalServicePhoneNumber(patient.getPatientContact().getClinicalServicesNumber());
        }

        patientMaintenancePage.clickMessagingTextRdBtn();

        if (isAllFieldRequire) {
            patientMaintenancePage.inputCarrierBin(patient.getPatientTp().getCarrierBin());
            patientMaintenancePage.inputCardId(patient.getPatientTp().getCardId());
            patientMaintenancePage.selectPlan(patient.getPatientTp().getPlan(), patient.getPatientTp().getCarrierBin());
            automationManager.performSleep(3);
            patientMaintenancePage.checkSameAsPatient();
        }
        patientMaintenancePage.setPatientAllergy(patient.getPatientMedicalConditionModel().getAllergies());
        patientMaintenancePage.setMedicalCondition(patient.getPatientMedicalConditionModel().getMedicalCondition());
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        patientMaintenancePage.clickSaveAndClose();

        if (patientMaintenancePage.isSaveAsEnteredDisplayed()) {
            patientMaintenancePage.clickSaveAsEntered();
        }

        patientMaintenancePage.isValidationPopup();
        if (patientMaintenancePage.isSaveAsEnteredDisplayed()) {
            patientMaintenancePage.clickSaveAsEntered();
        }

        if (patientSearchPage.isPatientRecordDisplayed(0)) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
        }

        return patient;
    }

    //This method cleanup taken care along with the IMZ domain
    @Override
    public PatientProfileModel createNewPatientFromResolutionPage(boolean thirdParty, PatientProfileModel patient) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        Boolean multiTP = false;
        PatientSearchPage patientSearchPage = new PatientSearchPage();
        PatientMaintenancePage patientMaintenancePage = new PatientMaintenancePage();

        if (patientSearchPage.isPatientSearchWindowDisplayed()) {
            patientSearchPage.clickSearchNow();
            patientSearchPage.hostSearchPatient();
            patientSearchPage.clickNew();

            //Create Patient
            /*patientMaintenancePage.selectPatientType(patient.getPatientType());
            patientMaintenancePage.selectGender(patient.getPatientGender());
            patientMaintenancePage.inputPrimaryPhoneNumber(patient.getPatientContact().getPatientPrimaryNumber());*/
            //patientMaintenancePage.inputAddressLine1(patient.getPatientAddress().getPatientAddressLine1());
            //patientMaintenancePage.ZipCode(patient.getPatientAddress().getPatientZipCode());

            if (thirdParty) {
                patientMaintenancePage.inputCarrierBin(patient.getPatientTp().getCarrierBin());
                patientMaintenancePage.inputCardId(patient.getPatientTp().getCardId());
                patientMaintenancePage.selectPlan(patient.getPatientTp().getPlan(), patient.getPatientTp().getCarrierBin());
                automationManager.performSleep(3);
                patientMaintenancePage.checkSameAsPatient();
            }
            if (patient.getPatientTp().getCarrierBin2() != null) {
                patientMaintenancePage.setPatientAllergy(patient.getPatientMedicalConditionModel().getAllergies());
                patientMaintenancePage.setMedicalCondition(patient.getPatientMedicalConditionModel().getMedicalCondition());
                patientMaintenancePage.clickSaveAndClose();
                patientSearchPage.openFirstPatientRecord();
                patientMaintenancePage.addAdditionalTPPlan(patient.getPatientTp().getCarrierBin2(), patient.getPatientTp().getPlan2(), patient.getPatientTp().getCardId2());
                multiTP = true;
            }
            if (patient.getPatientTp().getCarrierBin3() != null) {
                System.out.println("checking BIN 3");
                patientMaintenancePage.addAdditionalTPPlan(patient.getPatientTp().getCarrierBin3(), patient.getPatientTp().getPlan3(), patient.getPatientTp().getCardId3());
            }
            automationManager.performSleep(5);
            if (patient.getPatientAllergy() != null && !"".equals(patient.getPatientAllergy())) {
                patientMaintenancePage.setMedicalCondition(patient.getPatientMedicalConditionModel().getMedicalCondition());
                patientMaintenancePage.setPatientAllergy(patient.getPatientMedicalConditionModel().getAllergies());
                patientMaintenancePage.addAllergy(patient.getPatientAllergy());
                patientMaintenancePage.clickReturnToGeneralInformation();
            } else {
                patientMaintenancePage.setPatientAllergy(patient.getPatientMedicalConditionModel().getAllergies());
                patientMaintenancePage.setMedicalCondition(patient.getPatientMedicalConditionModel().getMedicalCondition());
            }
            if ("TRUE".equals(patient.getPatientInsulinInd())) {
                patientMaintenancePage.clickAllergyMedicalTab();
                if (patientMaintenancePage.isChkInsulinDependentDisabledInAllergy()) {
                    patientMaintenancePage.checkInsulinDependentInAllergy();
                }
                if (patientMaintenancePage.isChkInsulinPumpDisplayedInAllergy()) {
                    patientMaintenancePage.checkInsulinPumpInAllergy();
                }
            }

            Reporter.logScreenShot(Status.PASS, currentStepMethodName, patientSearchPage.takeScreenShot(currentStepMethodName).getValue());
            if (multiTP && thirdParty) {
                System.out.println("clicking save and close");
                patientMaintenancePage.clickSaveAndClose();
                patientMaintenancePage.clickSaveAndClose();
                patientMaintenancePage.clickSaveAndClose();
            } else {
                patientMaintenancePage.clickSaveAndClose();
                patientMaintenancePage.phnNumberValidationNO();
                patientMaintenancePage.clickPopUpOkBtn();
                patientSearchPage.clickClose();
            }
        } else {
            captureUnExpectedResults(currentStepMethodName, "Patient search screen not launched");
        }

        return patient;
    }

    @Override
    public void performRphManualResolution(String rxNbrOrName) {
        ResolutionPage resolutionPage = new ResolutionPage();
        F6Search search = new F6Search();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(rxNbrOrName);
        rxSearch.openFirstPatientRecord();

        resolutionPage.clickProblemResolved();
    }

    public void performCovidTestingKitDropRx(String patientName, Priority priority, int noOfRx, String pickupTime, String orderComment, String prescriberName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOff.clickDropOffQueue();
            dropOff.enterPatientName(patientName);
            dropOff.clickPatientSearch();
            dropOff.handleAnnualValidatePatInfoPopUp();
            dropOff.clickorderType();
            dropOff.clickCovidTestingKitInStore();
            dropOff.clickDrugDropDown();
            String drugName = dropOff.getCovidTestKitDrugName();
            dropOff.selectCovidTestDrug();
            // Validate drug was selected
            Assert.assertTrue(dropOff.isDrugSelected(), "Drug " + drugName + " was not selected or not in authorized list");
            if (dropOff.authRPh()) {
                dropOff.clickAuthRPh();
                dropOff.clickNotFound();
                dropOff.setRPh(prescriberName);
                prescriberSearchPage.doubleClickOnSearchGridRow(0);
            }
            dropOff.addToOrder();
            dropOff.selectPriority(priority.getPriority());
            if (priority == Priority.Future) {
                dropOff.selectReadyByTimeFuture();
            }
            if (!"defaultValue".equals(orderComment)) {
                dropOff.enterOrderComment(orderComment);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            dropOff.clickOutOFFStock();
            dropOff.selectdispenseType(DispenseType.CounterPickup.getDispenseType());
            dropOff.clickBtnAccept();
            dropOff.handleStorePickupTimePopup();
            Reporter.log("Drop-Off completed");
        } catch (Exception e) {
            Reporter.log("ERROR: Failed during IMZ Drop-Off for drug. Error: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            throw new RuntimeException("Failed to complete IMZ Drop-Off for drug. " + e.getMessage(), e);
        }
    }

    @Override
    public void navigateToRxNotes(String rxNbr, String textUser, String drugName, String rxNotes) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        int preAuthIdFromUI, servicePreAuthIdFromDB;
        automationManager.performSleep(5);
        //validate Text User and drug name,rxNbr and preAuthId on rx notes on EOD
        menuBar.navigateToRxNotesMenuItem();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Validating required details in Current Rx Notes");
        txtUser = consolidatedNotesPage.getTxtUser().trim();
        Assert.assertEquals(txtUser, textUser, "txtUSer did not match");
        Reporter.log("txtUser: " + txtUser + "\t txtUSer matched in Rx Notes");
        compoundDrugName = consolidatedNotesPage.getDrugName();
        Assert.assertEquals(compoundDrugName, drugName, "compoundDrugName did not match");
        Reporter.log("compoundDrugName: " + compoundDrugName + "\t drugName matched in Rx Notes");
        rxNbrFromRxNotes = consolidatedNotesPage.getRxNbr().trim();
        Assert.assertEquals(rxNbrFromRxNotes, rxNbr, "rxNbr did not match");
        Reporter.log("rxNbrFromRxNotes: " + rxNbrFromRxNotes + "\t rxNbr matched in Rx Notes");
        preAuthId = consolidatedNotesPage.getTxtNotes();
        preAuthIdFromUI = Integer.parseInt(preAuthId.split(": ")[1]);
        servicePreAuthIdFromDB = connexusAppUtils.getServicePreAuthId();
        Assert.assertEquals(preAuthIdFromUI, servicePreAuthIdFromDB, "Rx Notes Pre auth id did not match");
        Reporter.log(preAuthId + "\t  Rx Notes Pre auth id matched");
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
        consolidatedNotesPage.clickButtonExit();
        Reporter.log("Validated Text User and drug name,rxNbr and preAuthId on rx notes on EOD");
    }

    @Override
    public void navigateToRxImage(String rxNbr) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        automationManager.performSleep(10);
        //validate Rx Image on Rx LookUp screen
        menuBar.navigateToRxImageMenuItem();
        rxImage = eod.clickOnRxImage();
        Assert.assertTrue(rxImage, "Rx Image not found");
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
        eod.clickOK();
        eod.clickButtonExit();
        Reporter.log("verified rx image popup on EOD");
    }

    public void performMultiRxInput(String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName, int index) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(patientName);
        patientSearchPage.openPatientRecordFromOrderSearch(index);
        automationManager.performSleep(5);
        inputPage.isInvalidDataPopupDisplayed();
        inputPage.isAddressValidationViewPopupDisplayed();
        System.out.println("ndc:" + ndc);
        inputPage.enterNdc(ndc);
        inputPage.clickProductSearch3Dots();
        inputPage.enterPrescribedQty(prescribedQty);
        automationManager.performSleep(2);
        inputPage.enterSigCode(sigCode);
        inputPage.enterRefillQty(refills);
        inputPage.enterPrescriber(prescriberName);
        if (inputPage.isTMCodeDisplayed()) {
            inputPage.selectTmCodeField(2);
        }
        if (inputPage.isDxCodeDisplayed()) {
            inputPage.inputRandomDXCode();
        }
        if (inputPage.isTriplicateDisplayed()) {
            inputPage.inputTriplicateNumber();
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        automationManager.performSleep(3);
        inputPage.clickAccept();
        inputPage.clickYesOnValidateRxPopUp();
        automationManager.performSleep(3);
        if (checkForCAE()) {
            Assert.fail("CAE - Connexus Application Error - Input");
        }
        Reporter.log("Input completed");
    }
    public void performMultiRxInput(Map<String, String> inputData,String patientName, String ndc, String prescribedQty, String sigCode, String refills, String prescriberName, int index) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(patientName);
        patientSearchPage.openPatientRecordFromOrderSearch(index);
        inputPage.isInvalidDataPopupDisplayed();
        inputPage.isAddressValidationViewPopupDisplayed();
        System.out.println("ndc:" + ndc);
        rxOrigin = inputPage.getRxOriginText();
        if (rxOrigin.contains("DIGITAL")) {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Rx Origin displayed in Input Screen :" + rxOrigin);
            boolean isDisplayed = rxOrigin.toLowerCase().contains(inputData.get("rxOrigin"));
            Assert.assertTrue(isDisplayed, "Rx origin is not DIGITAL COMP XFER");
        } else {
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
            Reporter.log("Rx Origin displayed in Input Screen :" + rxOrigin);
            boolean isDisplayed = rxOrigin.toLowerCase().contains(inputData.get("rxOrigin1"));
            Assert.assertTrue(isDisplayed, "Rx origin is not ORIGINAL RX");
        }
        inputPage.enterNdc(ndc);
        inputPage.clickProductSearch3Dots();
        inputPage.enterPrescribedQty(prescribedQty);
        inputPage.enterSigCode(sigCode);
        inputPage.enterRefillQty(refills);
        inputPage.enterPrescriber(prescriberName);
        if (inputPage.isTMCodeDisplayed()) {
            inputPage.selectTmCodeField(2);
        }
        if (inputPage.isDxCodeDisplayed()) {
            inputPage.inputRandomDXCode();
        }
        if (inputPage.isTriplicateDisplayed()) {
            inputPage.inputTriplicateNumber();
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, inputPage.takeScreenShot(currentStepMethodName).getValue());
        inputPage.clickAccept();
        inputPage.clickYesOnValidateRxPopUp();
        if (checkForCAE()) {
            Assert.fail("CAE - Connexus Application Error - Input");
        }
        Reporter.log("Input completed");
    }

    @Override
    public void completePickupWithPaymentValidation(String firstName, String lastName, String dob, String rxNbr, String siteId, String fillId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        TascoPage tascoPage = new TascoPage();
        tascoPage.launchTascoScreen();
        tascoPage.inputPatientLastName(lastName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientFirstName(firstName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientDob(dob);
        tascoPage.pressTabKey();
        tascoPage.pressTabKey();
        tascoPage.clickSearchOnTascoPage();
        tascoPage.clickRow(0);
        tascoPage.handleOtherOrdersAvailablePopUp();
        if (!tascoPage.validateCheckoutBkt()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, takeScreenShot(currentStepMethodName).getValue());
            org.junit.Assert.fail("Checkout button not enabled on tasco screen");
            return;
        }
        tascoPage.continueCheckout();
        tascoPage.clickCheckout();
        tascoPage.handleConnexusCheckoutCashPayPopup();
        tascoPage.handleIdAndRelationshipForControlledDrugPopup();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.handleCustomerIdDetailsForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsscreen();
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        if (tascoPage.isToteNbrDisplayed()) {
            if (siteId.length() == 4) {
                tascoPage.scanRx("0" + siteId + "00" + rxNbr + "0000");
            } else {
                tascoPage.scanRx(siteId + "00" + rxNbr + "0000");
            }
        } else if (tascoPage.isTxtCounselCommentsDisplayed()) {
            tascoPage.scanRx("4793" + fillId + "0");
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.handleDoYouHaveAnyQuestionsToTheDoctorPopup();
        tascoPage.clickAcceptCheckout();
        tascoPage.clickOk();
        tascoPage.clickPatientRefused();
        tascoPage.clickOk();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Validate popup info");
        Assert.assertEquals(tascoPage.getTextForConnexusCheckOutInfo(), "Payment Processing was unsuccessful for this transaction.");
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Validated Payment Processing info:" + tascoPage.getTextForConnexusCheckOutInfo());
        Assert.assertEquals(tascoPage.getTextForActionNeededInfo(), "Please retry payment. Contact customer to inform an alternate payment is required. If necessary, process POS at a register. \n" +
                "Tip: Discontinue existing credit card and add new credit card.");
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Validated Action Payment info:" + tascoPage.getTextForActionNeededInfo());
        click(tascoPage.btnOk);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.clickSignOff();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("pickup Completed");
    }

    @Override
    public void completeMultiRxPickupWithPaymentValidation(String firstName, String lastName, String dob, List<String> rxNbr, String siteId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        TascoPage tascoPage = new TascoPage();
        tascoPage.launchTascoScreen();
        tascoPage.inputPatientLastName(lastName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientFirstName(firstName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientDob(dob);
        tascoPage.pressTabKey();
        tascoPage.pressTabKey();
        tascoPage.clickSearchOnTascoPage();
        tascoPage.clickRow(0);
        tascoPage.handleOtherOrdersAvailablePopUp();
        if (!tascoPage.validateCheckoutBkt()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, takeScreenShot(currentStepMethodName).getValue());
            org.junit.Assert.fail("Checkout button not enabled on tasco screen");
            return;
        }
        tascoPage.continueCheckout();
        tascoPage.clickCheckout();
        tascoPage.handleConnexusCheckoutCashPayPopup();
        tascoPage.handleControlIdSubstanceForControlledDrugPopup();
        tascoPage.handleIdAndRelationshipForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsscreen();
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        for (int i = 0; i < rxNbr.size(); i++) {
            String fillId = getFillId(rxNbr.get(i));
            Log.info(fillId);
            if (tascoPage.isToteNbrDisplayed()) {
                if (siteId.length() == 4) {
                    tascoPage.scanRx("0" + siteId + "00" + rxNbr.get(i) + "0000");
                } else {
                    tascoPage.scanRx(siteId + "00" + rxNbr.get(i) + "0000");
                }
            } else if (tascoPage.isTxtCounselCommentsDisplayed()) {
                tascoPage.scanRx("4793" + fillId + "0");
            }
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.handleDoYouHaveAnyQuestionsToTheDoctorPopup();
        tascoPage.clickAcceptCheckout();
        tascoPage.clickOk();
        tascoPage.clickPatientRefused();
        tascoPage.clickOk();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Validate popup info");
        Assert.assertEquals(tascoPage.getTextForConnexusCheckOutInfo(), "Payment Processing was unsuccessful for this transaction.");
        Reporter.log("Validated Payment Processing info:" + tascoPage.getTextForConnexusCheckOutInfo());
        Assert.assertEquals(tascoPage.getTextForActionNeededInfo(), "Please retry payment. Contact customer to inform an alternate payment is required. If necessary, process POS at a register. \n" +
                "Tip: Discontinue existing credit card and add new credit card.");
        Reporter.log("Validated Action Payment info:" + tascoPage.getTextForActionNeededInfo());
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        click(tascoPage.btnOk);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.clickSignOff();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("pickup Completed");
    }

    @Override
    public void performRphManualResolutionForAdditionalAction(String rxNbrOrName, String prescriber) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        ResolutionPage resolutionPage = new ResolutionPage();
        Log.info("manual resolution");
        rxSearch.launchOrderSearchScreen();
        rxSearch.performSearch(rxNbrOrName);
        rxSearch.openFirstPatientRecord();
        automationManager.performSleep(5);
        resolutionPage.enterPres(prescriber);
        resolutionPage.clickSearch();
        // prescriberSearchPage.doubleClickOnSearchGridRow(0);
        resolutionPage.clickViewPQCF();
        resolutionPage.clickAccept();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
        resolutionPage.clickProblemResolved();
    }

    @Override
    public void navigateToRxNotesAndPerformValidation(String rxNbr, String vaccineName, String user, String notes) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        String drugName, rxNbrFromRxNotes, txtNote;
        /*patientSearchPage.launchOrderSearchScreen();
        patientSearchPage.performSearch(rxNbr);
        patientSearchPage.openFirstPatientRecord();
        eod.clickBtnNo();*/
        //validate Rx Notes on Rx LookUp screen
        //validate Text User,drug Name,rxNbr and notes on rx notes on EOD
        menuBar.navigateToRxNotesMenuItem();
        Reporter.log("Validating required details in Rx Admin Notes");
        txtUser = consolidatedNotesPage.getTxtUser().trim();
        Reporter.log("logged in User: " + txtUser);
        Assert.assertEquals(txtUser, user, "Logged User Info is not reflecting in RXNotes");
        Reporter.log("Assert: Logged user name is validated from rx Admin Notes");
        drugName = consolidatedNotesPage.getDrugName().trim();
        Reporter.log("Drug Name From Rx Admin Notes: " + drugName);
        Assert.assertEquals(drugName.toUpperCase(), vaccineName.trim().toUpperCase(), "DrugName didnot match");
        Reporter.log("Assert: Drug Name from Rx Admin Notes with Drug Name used in IMZ Administration is matched");
        rxNbrFromRxNotes = consolidatedNotesPage.getRxNbr().trim();
        Reporter.log("RxNbr From Rx Admin Notes: " + rxNbrFromRxNotes);
        Assert.assertEquals(rxNbrFromRxNotes, rxNbr, "rxNbr didnot match");
        Reporter.log("Assert: RxNumber reflected in Rx Admin Notes is validated with required Rx Number");
        txtNote = consolidatedNotesPage.getTxtNote().trim();
        Assert.assertEquals(txtNote, notes, "Notes Entered didnot match");
        Reporter.log("Assert:" + txtNote + " reflected in Rx Admin Notes is validated with required NotesTxt");
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, menuBar.takeScreenShot(currentStepMethodName).getValue());
        consolidatedNotesPage.clickButtonExit();
        //eod.clickButtonExit();
        Reporter.log("Validated User,drug name,RxNbr and Notes details on rx notes");
    }

    public void performNaloxoneDropOffRx(String patientName, Priority priority, String pickupTime, String orderComment, String drugName, String prescriberName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOff.clickDropOffQueue();
            dropOff.enterPatientName(patientName);
            dropOff.clickPatientSearch();
            dropOff.handleAnnualValidatePatInfoPopUp();
            dropOff.clickorderType();
            dropOff.clicknaloxoneInStore();
            dropOff.clickOkButton();
            dropOff.selectImzDrug(drugName);
            // Validate drug was selected
            Assert.assertTrue(dropOff.isDrugSelected(), "Drug " + drugName + " was not selected or not in authorized list");
            if (dropOff.authRPh()) {
                dropOff.clickAuthRPh();
                dropOff.clickNotFound();
                dropOff.setRPh(prescriberName);
                prescriberSearchPage.doubleClickOnSearchGridRow(0);
            }
            dropOff.addToOrder();
            dropOff.selectPriority(priority.getPriority());
            if (priority == Priority.Future) {
                dropOff.selectPickupTime(pickupTime);
            }
            if (!"defaultValue".equals(orderComment)) {
                dropOff.enterOrderComment(orderComment);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            dropOff.clickOutOFFStock();
            dropOff.selectdispenseType(DispenseType.CounterPickup.getDispenseType());
            dropOff.clickBtnAccept();
            dropOff.handleStorePickupTimePopup();
            Reporter.log("Drop-Off completed");
        } catch (Exception e) {
            Reporter.log("ERROR: Failed during IMZ Drop-Off for drug. Error: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            throw new RuntimeException("Failed to complete IMZ Drop-Off for drug. " + e.getMessage(), e);
        }
    }

    public void performIMZDropOffForSingleDrug(String patientName, Priority priority, String pickupTime, String orderComment, String drugName, String prescriberName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOff.clickDropOffQueue();
            dropOff.enterPatientName(patientName);
            dropOff.clickPatientSearch();
            dropOff.handleAnnualValidatePatInfoPopUp();
            dropOff.clickorderType();
            dropOff.clickIMZInStore();
            dropOff.clickOkButton();
            dropOff.selectImzDrug(drugName);
            // Validate drug was selected
            Assert.assertTrue(dropOff.isDrugSelected(), "Drug " + drugName + " was not selected or not in authorized list");
            if (dropOff.authRPh()) {
                dropOff.clickAuthRPh();
                dropOff.clickNotFound();
                dropOff.setRPh(prescriberName);
                prescriberSearchPage.doubleClickOnSearchGridRow(0);
            }
            dropOff.addToOrder();
            dropOff.selectPriority(priority.getPriority());
            if (priority == Priority.Future) {
                dropOff.selectPickupTime(pickupTime);
            }
            if (!"defaultValue".equals(orderComment)) {
                dropOff.enterOrderComment(orderComment);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            dropOff.clickOutOFFStock();
            dropOff.selectdispenseType(DispenseType.CounterPickup.getDispenseType());
            dropOff.clickBtnAccept();
            dropOff.handleStorePickupTimePopup();
            Reporter.log("Drop-Off completed");
        } catch (Exception e) {
            Reporter.log("ERROR: Failed during IMZ Drop-Off for drug. Error: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            throw new RuntimeException("Failed to complete IMZ Drop-Off for drug. " + e.getMessage(), e);
        }
    }

    public void performIMZDropOffForMultiDrug(String patientName, Priority priority, String pickupTime, String orderComment, List<String> drugName, String prescriberName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOff.clickDropOffQueue();
            dropOff.clickorderType();
            dropOff.clickIMZInStore();
            dropOff.clickOkButton();
            dropOff.enterPatientName(patientName);
            dropOff.clickPatientSearch();
            dropOff.handleAnnualValidatePatInfoPopUp();
            for (int i = 0; i < drugName.size(); i++) {
                Reporter.log("Adding drug " + (i + 1) + ": " + drugName.get(i));
                dropOff.selectImzDrug(drugName.get(i));
                // Validate drug was selected
                Assert.assertTrue(dropOff.isDrugSelected(), "Drug " + drugName.get(i) + " was not selected or not in authorized list");
                if (dropOff.authRPh()) {
                    dropOff.clickAuthRPh();
                    dropOff.clickNotFound();
                    dropOff.setRPh(prescriberName);
                    prescriberSearchPage.doubleClickOnSearchGridRow(0);
                }
                dropOff.addToOrder();
                Reporter.log("Drug " + (i + 1) + " added successfully: " + drugName.get(i));
            }
            dropOff.selectPriority(priority.getPriority());
            if (priority == Priority.Future) {
                dropOff.selectPickupTime(pickupTime);
            }
            if (!"defaultValue".equals(orderComment)) {
                dropOff.enterOrderComment(orderComment);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            dropOff.clickOutOFFStock();
            dropOff.selectdispenseType(DispenseType.CounterPickup.getDispenseType());
            dropOff.clickBtnAccept();
            dropOff.handleStorePickupTimePopup();
            Reporter.log("Drop-Off completed");
        } catch (Exception e) {
            Reporter.log("ERROR: Failed during IMZ Drop-Off for multi-drug. Error: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            throw new RuntimeException("Failed to complete IMZ Drop-Off for multi-drug. " + e.getMessage(), e);
        }
    }

    @Override
    public void completeMultiRxPickupWithIndividualRx(String firstName, String lastName, String dob, List<String> rxNbr, String siteId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        TascoPage tascoPage = new TascoPage();
        tascoPage.launchTascoScreen();
        tascoPage.inputPatientLastName(lastName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientFirstName(firstName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientDob(dob);
        tascoPage.pressTabKey();
        tascoPage.pressTabKey();
        tascoPage.clickSearchOnTascoPage();
        tascoPage.clickRow(0);
        tascoPage.handleOtherOrdersAvailablePopUp();
        if (!tascoPage.checkSecondRowSelected()) {
            tascoPage.clickSecondRow();
        }
        if (!tascoPage.validateCheckoutBkt()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, takeScreenShot(currentStepMethodName).getValue());
            org.junit.Assert.fail("Checkout button not enabled on tasco screen");
            return;
        }
        tascoPage.continueCheckout();
        tascoPage.clickCheckout();
        tascoPage.handleConnexusCheckoutCashPayPopup();
        tascoPage.handleControlIdSubstanceForControlledDrugPopup();
        tascoPage.handleIdAndRelationshipForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsscreen();
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        for (int i = 0; i < rxNbr.size(); i++) {
            String fillId = getFillId(rxNbr.get(i));
            Log.info(fillId);
            if (tascoPage.isToteNbrDisplayed()) {
                if (siteId.length() == 4) {
                    tascoPage.scanRx("0" + siteId + "00" + rxNbr.get(i) + "0000");
                } else {
                    tascoPage.scanRx(siteId + "00" + rxNbr.get(i) + "0000");
                }
            } else if (tascoPage.isTxtCounselCommentsDisplayed()) {
                tascoPage.scanRx("4793" + fillId + "0");
            }
        }
        automationManager.performSleep(5);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.handleDoYouHaveAnyQuestionsToTheDoctorPopup();
        tascoPage.clickAcceptCheckout();
        tascoPage.clickOk();
        tascoPage.clickPatientRefused();
        tascoPage.clickOk();
        automationManager.performSleep(20);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Validate popup info");
        Assert.assertEquals(tascoPage.getTextForConnexusCheckOutInfo(), "Payment Processing was unsuccessful for this transaction.");
        Reporter.log("Validated Payment Processing info:" + tascoPage.getTextForConnexusCheckOutInfo());
        Assert.assertEquals(tascoPage.getTextForActionNeededInfo(), "Please retry payment. Contact customer to inform an alternate payment is required. If necessary, process POS at a register. \n" +
                "Tip: Discontinue existing credit card and add new credit card.");
        Reporter.log("Validated Action Payment info:" + tascoPage.getTextForActionNeededInfo());
        click(tascoPage.btnOk);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.clickSignOff();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("pickup Completed");
    }

    private void performDropOffForMultiDrugs(String patientName, String dob, Priority priority, int noOfRx, String pickupTime, String orderComment, List<String> drug) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DropOffPage dropOff = new DropOffPage();
        PrescriberSearchPage prescriberSearchPage = new PrescriberSearchPage();
        dropOff.clickDropOffQueue();
        dropOff.enterPatientName(patientName);
        dropOff.clickPatientSearch();
        dropOff.handleAnnualValidatePatInfoPopUp();
        for (int i = 0; i < drug.size(); i++) {
            dropOff.clickScanNewRx();
            String barCode = dropOff.generateRxBarCode();
            dropOff.enterBarCode(barCode);
            Reporter.log("New barcode entered " + barCode);
            dropOff.clickBtnAccept();
            dropOff.clickVerifyBarCode();
            dropOff.selectListItemfromRxOriginType();
            dropOff.clickBtnAccept();
            // dropOff.addNoOfRx(barCode, noOfRx);
        }
        dropOff.selectPriority(priority.getPriority());
        if (priority == Priority.Future) {
            dropOff.selectPickupTime(pickupTime);
        }
        if (!"defaultValue".equals(orderComment)) {
            dropOff.enterOrderComment(orderComment);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        dropOff.clickOutOFFStock();
        dropOff.clickBtnAccept();
        dropOff.handleStorePickupTimePopup();
        Reporter.log("Drop-Off completed");
    }

    @Override
    public void performAutoFillDropOffForC2Drug(DropRxModel dropRxModel) {
        if (dropRxModel.getOrderComment() == null) {
            performAutoFillDropOffForC2Drug(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", "defaultValue");
        } else {
            performAutoFillDropOffForC2Drug(dropRxModel.getPatientLastName() + "," + dropRxModel.getPatientFirstName(), dropRxModel.getPriority(), dropRxModel.getNoOfRx(), "", dropRxModel.getOrderComment());
        }
    }

    public void performAutoFillDropOffForC2Drug(String patientName, Priority priority, int noOfRx, String pickupTime, String orderComment) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        dropOff.enterPatientName(patientName);
        dropOff.clickPatientSearch();
        dropOff.handleAnnualValidatePatInfoPopUp();
        dropOff.clickScanNewRx();
        String barCode = dropOff.generateRxBarCode();
        dropOff.enterBarCode(barCode);
        Reporter.log("New barcode entered " + barCode);
        dropOff.clickBtnAccept();
        dropOff.clickVerifyBarCode();
        dropOff.selectListItemfromRxOriginType();
        dropOff.clickBtnAccept();
        dropOff.addNoOfRx(barCode, noOfRx);
        dropOff.selectPriority(priority.getPriority());
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        if (priority == Priority.InStore) {
            dropOff.getReadyByTime();
        }
        if (priority == Priority.Critical) {
            dropOff.getReadyByTime();
        }
        if (priority == Priority.DRCallIn) {
            dropOff.getReadyByTimeDrCallIn();
        }
        if (priority == Priority.DriveThru) {
            dropOff.getReadyByTimeDriveThru();
        }

        if (priority == Priority.Future) {
            dropOff.selectPickupTime(pickupTime);
        }
        if (priority == Priority.Today) {
            dropOff.selectPickupTime(pickupTime);
        }
        if (!"defaultValue".equals(orderComment)) {
            dropOff.enterOrderComment(orderComment);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        automationManager.performSleep(3);
        dropOff.clickBtnAccept();
        //if(dropOff.isOrderDetailsDisplayed()){
        dropOff.clickBtnAccept();
    }
    // dropOff.handleStorePickupTimePopup();
    //Reporter.log("Drop-Off completed");

    public void performCovidTestingKitForMultiDrug(String patientName, Priority priority, String pickupTime, String orderComment, List<String> drugName, String prescriberName) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOff.clickDropOffQueue();
            dropOff.clickorderType();
            dropOff.clickCovidTestingKitInStore();
            dropOff.clickOkButton();
            dropOff.enterPatientName(patientName);
            dropOff.clickPatientSearch();
            dropOff.handleAnnualValidatePatInfoPopUp();
            for (int i = 0; i < drugName.size(); i++) {
                Reporter.log("Adding drug " + (i + 1) + ": " + drugName.get(i));
                dropOff.selectImzDrug(drugName.get(i));
                // Validate drug was selected
                Assert.assertTrue(dropOff.isDrugSelected(), "Drug " + drugName.get(i) + " was not selected or not in authorized list");
                if (dropOff.authRPh()) {
                    dropOff.clickAuthRPh();
                    dropOff.clickNotFound();
                    dropOff.setRPh(prescriberName);
                    prescriberSearchPage.doubleClickOnSearchGridRow(0);
                }
                dropOff.addToOrder();
                Reporter.log("Drug " + (i + 1) + " added successfully: " + drugName.get(i));
            }
            dropOff.selectPriority(priority.getPriority());
            if (priority == Priority.Future) {
                dropOff.selectReadyByTimeFuture();
            }
            automationManager.performSleep(2);
            if (!"defaultValue".equals(orderComment)) {
                dropOff.enterOrderComment(orderComment);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            dropOff.clickOutOFFStock();
            dropOff.selectdispenseType(DispenseType.CounterPickup.getDispenseType());
            dropOff.clickBtnAccept();
            dropOff.handleStorePickupTimePopup();
            Reporter.log("Drop-Off completed");
        } catch (Exception e) {
            Reporter.log("ERROR: Failed during IMZ Drop-Off for drug. Error: " + e.getMessage());
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            throw new RuntimeException("Failed to complete IMZ Drop-Off for drug. " + e.getMessage(), e);
        }
    }

    @Override
    public void openCheckDURScreen(String rxNumber) {
        ChkDur dur = new ChkDur();
        if (dur.isCheckDUREligible(rxNumber)) {
            rxSearch.launchOrderSearchScreen();
            rxSearch.performSearch(rxNumber);
            rxSearch.openFirstPatientRecord();
        } else {
            Reporter.log("Rx not in ChkDUR Queue");
        }
    }

    /*this method will handle quantity validation and input for Naloxone State Partnership*/
    private void processQuantityValidation(DropOffPage dropOff, int quantity, int minRange, int maxRange) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOff.txtQuantityField(quantity, minRange, maxRange);
            dropOff.addToOrder();
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        } catch (Exception e) {
            throw new RuntimeException("Failed to process quantity validation. Error: " + e.getMessage());
        }
    }

    /*this method will perform Naloxone State Partnership DropOff and
     * validate quantity txt field is even and not allowed odd numbers */
    public void performNaloxoneStatePartnershipDropOff(String patientName, Priority priority, String pickupTime, String orderComment, String drugName, int qtyEvenNum, int qtyOddNum, int minRangeEvenNum, int maxRangeEvenNum, int minRangeOddNum, int maxRangeOddNum) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        DropOffPage dropOff = new DropOffPage();
        dropOff.clickDropOffQueue();
        dropOff.enterPatientName(patientName);
        dropOff.clickPatientSearch();
        dropOff.handleAnnualValidatePatInfoPopUp();
        dropOff.clickorderType();
        dropOff.clickNaloxoneStatePartnership();
        dropOff.clickOkButton();
        dropOff.selectImzDrug(drugName);
        if (dropOff.authRPh()) {
            dropOff.clickAuthRPh();
            dropOff.clickNotFound();
            dropOff.setRPh("Thomas,walden");
            prescriberSearchPage.doubleClickOnSearchGridRow(0);
        }
        // Verify quantity is even and within the range
        this.processQuantityValidation(dropOff, qtyEvenNum, minRangeEvenNum, maxRangeEvenNum);
        Reporter.log("validated that QTY field is allowing to enter only even numbers");
        // Verify quantity is within the range and is not odd
        this.processQuantityValidation(dropOff, qtyOddNum, minRangeOddNum, maxRangeOddNum);
        Reporter.log("validated that QTY field is not allowing to enter odd numbers");
        dropOff.clickOKBtn();
        dropOff.selectPriority(priority.getPriority());
        if (priority == Priority.Future) {
            dropOff.selectPickupTime(pickupTime);
        }
        if (!"defaultValue".equals(orderComment)) {
            dropOff.enterOrderComment(orderComment);
        }
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
        dropOff.clickOutOFFStock();
        dropOff.selectdispenseType(DispenseType.CounterPickup.getDispenseType());
        dropOff.clickBtnAccept();
        dropOff.handleStorePickupTimePopup();
        Reporter.log("Drop-Off completed");
    }

    void captureUnExpectedResults(String currentStepMethodName, String message) {
        if (checkForCAE()) {
            message = message + " Connexus Application Error occurred either in previous or current page";
        }
        Reporter.log("Test failed at " + currentStepMethodName + " method, '" + message + "'");
        Reporter.logScreenShot(Status.FAIL, currentStepMethodName, takeScreenShot(currentStepMethodName).getValue());
        Assert.fail(message);
    }

    boolean checkForCAE() {
        return isElementDisplayed(AppiumBy.name("An error occurred while processing your request. Please contact system administrator and try again later."), 10);
    }

    // Create a new IMZ Event from File menu
    @Override
    public ImzEventModel createNewIMZEvent(ImzEventModel imzEvent, List<String> drugList, String lotNbr, String expireDate, List<String> ndcList, String prescriberRph, String prescriberSo, String groupName, String invalidNdc) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            imzEventPage.launchImzEventScreen();
            imzEventPage.isImzEventViewWindowDisplayed();
            // Create IMZ Event
            imzEventPage.inputImzEventName(imzEvent.getImzEventName());
            imzEventPage.inputOrganizationName(imzEvent.getImzOrganizationName());
            imzEventPage.inputPhoneNumber(imzEvent.getPhoneNumber());
            // Address details
            imzEventPage.inputAddressLine1(imzEvent.getAddress().getAddressLine1());
            imzEventPage.selectState(imzEvent.getAddress().getState());
            imzEventPage.inputCity(imzEvent.getAddress().getCity());
            imzEventPage.ZipCode(imzEvent.getAddress().getZipCode());
            imzEventPage.selectCountry(imzEvent.getAddress().getCountry());
            imzEventPage.isAddressValidationPopupDisplayed();

            // Handle single or multiple products (drugs)
            boolean isSingleDrug = drugList.size() == 1;
            if (isSingleDrug) {
                // Single drug logic
                String drug1 = drugList.get(0);
                imzEventPage.selectAuthImzDrug(drug1);
                imzEventPage.clickBtnAddImzList();
                for (int i = 0; i < ndcList.size(); i++) {
                    imzEventPage.selectEventImzDrug(drug1);
                    imzEventPage.lotNumber(String.valueOf(Integer.parseInt(lotNbr) + i), i);
                    imzEventPage.expireDate(expireDate, i);

                    if (invalidNdc != null && !invalidNdc.isEmpty()) {
                        imzEventPage.ndcNumber(invalidNdc, i);
                        imzEventPage.selectEventImzDrug(drug1);
                        String ndcPopupText = imzEventPage.getNdcPopupText();
                        Assert.assertEquals(ndcPopupText, "Please enter a valid NDC Number.", "NDC popup text validation failed");
                        Reporter.log("Validated NDC popup text for NDC: " + invalidNdc + "\t\t" + ndcPopupText);
                        imzEventPage.btnOk();
                    }
                    imzEventPage.ndcNumber(ndcList.get(i), i);
                    Reporter.log("Enter text for NDC- " + (i + 1) + ": " + ndcList.get(i));
                    Reporter.logScreenShot(Status.PASS, "singleProductWithMultipleNdcs", takeScreenShot(currentStepMethodName).getValue());
                }
            } else {
                // Multiple drugs logic
                for (String drug : drugList) {
                    imzEventPage.selectAuthImzDrug(drug);
                    imzEventPage.clickBtnAddImzList();
                }
                for (int j = 0; j < drugList.size(); j++) {
                    int ndcCount = ndcList.size() / drugList.size();
                    for (int i = 0; i < ndcCount; i++) {
                        int ndcIndex = i;
                        imzEventPage.selectEventImzDrug(drugList.get(j));
                        int lotNumber = Integer.parseInt(lotNbr);
                        imzEventPage.lotNumber(String.valueOf(lotNumber + ndcIndex), ndcIndex);
                        imzEventPage.expireDate(expireDate, ndcIndex);
                        imzEventPage.ndcNumber(ndcList.get(j * ndcCount + ndcIndex), ndcIndex);
                    }
                    Reporter.log("Enter text for NDC- " + (j + 1) + ": " + ndcList.get(j * ndcCount));
                    Reporter.logScreenShot(Status.PASS, "multipleProductsWithMultipleNdcs", takeScreenShot(currentStepMethodName).getValue());
                }
            }
            // Auth Rph
            imzEventPage.authRPhLookUp(prescriberRph);
            imzEventPage.click3DotsForAuthRPh();
            imzEventPage.clickBtnAddAuthRPh();
            // Administering Pharmacist
            imzEventPage.administeringPharmacistLookup(prescriberSo);
            imzEventPage.click3DotsForAuthRPhForAdminPharmacist();
            imzEventPage.selectAdminUserId();
            imzEventPage.clickBtnAddAdminPharmacist();
            imzEventPage.clickRbdPatientBilling();
            imzEventPage.txtGroupName(groupName);
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, takeScreenShot(currentStepMethodName).getValue());
            imzEventPage.clickAcceptBtn();
        } catch (Throwable e) {
            Reporter.log("IMZ Event info screen not launched or Event not created");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
        return imzEvent;
    }

    public void performImzEventDropOff(String patientName, String orderComment, String dob, String imzEventName, String raceValue, String ethnicityValue, String imzEventDrug) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        try {
            dropOff.clickDropOffQueue();
            dropOff.enterPatientName(patientName);
            dropOff.clickPatientSearch();
            dropOff.handleAnnualValidatePatInfoPopUp();
            dropOff.clickorderType();
            dropOff.clickImzEventOrderType();
            dropOff.performScanImzForm(dob);
            dropOff.clickOkButton();
            dropOff.performRaceAndEthnicityValues(raceValue, ethnicityValue);
            dropOff.selectImzEvent(imzEventName);
            dropOff.selectImzEventDrug(imzEventDrug);
            dropOff.clickAdminSite();
            dropOff.addToOrder();
            if (!"defaultValue".equals(orderComment)) {
                dropOff.enterOrderComment(orderComment);
            }
            Reporter.logScreenShot(Status.PASS, currentStepMethodName, dropOff.takeScreenShot(currentStepMethodName).getValue());
            dropOff.clickBtnAccept();
            Reporter.log("IMZ Event Drop-Off completed");
        } catch (Throwable e) {
            Reporter.log("Test failed at IMZ Event Drop-Off queue");
            e.printStackTrace();
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, this.takeScreenShot(currentStepMethodName).getValue());
            Assert.fail(e.toString());
        }
    }

    @Override
    public void performpickupforWrongScanRX(String firstName, String lastName, String dob, String rxNbr, int fillId) {
        String currentStepMethodName = StackUtils.getCurrentMethodName();
        TascoPage tascoPage = new TascoPage();
        tascoPage.launchTascoScreen();
        automationManager.performSleep(5);
        tascoPage.inputPatientLastName(lastName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientFirstName(firstName);
        tascoPage.pressTabKey();
        tascoPage.inputPatientDob(dob);
        tascoPage.pressTabKey();
        tascoPage.pressTabKey();
        tascoPage.clickSearchOnTascoPage();
        tascoPage.clickRow(0);
        tascoPage.handleOtherOrdersAvailablePopUp();
        if (!tascoPage.validateCheckoutBkt()) {
            Reporter.logScreenShot(Status.FAIL, currentStepMethodName, takeScreenShot(currentStepMethodName).getValue());
            org.junit.Assert.fail("Checkout button not enabled on tasco screen");
            return;
        }
        tascoPage.continueCheckout();
        tascoPage.clickCheckout();
        tascoPage.handleConnexusCheckoutCashPayPopup();
        tascoPage.handleIdAndRelationshipForControlledDrugPopup();
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        tascoPage.handleCustomerIdDetailsForControlledDrugPopup();
        tascoPage.handleCustomerIdDetailsscreen();
        tascoPage.handleConnexusCheckoutEasyPayPopup();
        String siteId = prop.getProperty("cnx.store");
        if (tascoPage.isToteNbrDisplayed()) {
            if (siteId.length() == 5) {
                tascoPage.scanRx("0" + siteId + "00" + rxNbr + "0000");
                automationManager.performSleep(5);
                Reporter.log("Validate popup info");
                Assert.assertTrue(tascoPage.getTextForScanRXpopupmsg().contains("Scanned RX does not belong to any order in checkout basket. Please verify!"));
                Reporter.log("Validated scan RX info:" + tascoPage.getTextForScanRXpopupmsg());
                Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
                click(tascoPage.btnOk);
            }
            tascoPage.scanRx(siteId + "00" + rxNbr + "0000");
        } else if (tascoPage.isTxtCounselCommentsDisplayed()) {
            tascoPage.scanRx("4793" + fillId + "0");
        }
        automationManager.performSleep(5);
        Reporter.logScreenShot(Status.PASS, currentStepMethodName, tascoPage.takeScreenShot(currentStepMethodName).getValue());
        Reporter.log("Validate popup info");
        Assert.assertTrue(tascoPage.getTextForScanRXpopupmsg().contains("Scanned Rx does not belong to any orders"));
        Reporter.log("Validated wrong scan RX info:" + tascoPage.getTextForScanRXpopupmsg());
        click(tascoPage.btnOk);
        Reporter.logScreenShot("RPH Verification", tascoPage.takeScreenShot());
        tascoPage.RPHvalidationpoup("123456788");
        Reporter.logScreenShot("Invalid_User_ID_popup", tascoPage.takeScreenShot());
        Reporter.log("RPH validation popup handled with wrong RPH ID: 123456788");
        click(tascoPage.btnOk);
        tascoPage.RPHvalidationpoup("210296732");
        Reporter.log("RPH validation popup handled with correct RPH ID: 210296732");

    }
}