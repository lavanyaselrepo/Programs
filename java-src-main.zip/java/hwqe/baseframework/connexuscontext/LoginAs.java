package hwqe.baseframework.connexuscontext;

/*
 * this class provide enumerated user type to the restart utility
 *
 * Auther:Ashok(vn50h3h)
 */
@SuppressWarnings("java:S115") // ADFlagOn/Off naming is intentional and consistent across the codebase
public class LoginAs {
    public enum userType {
        HOMEOFFICE_ADFlagOn,
        HOMEOFFICE_ADFlagOff,
        TECHNICIAN_ADFlagOff,   // keep for backward compat — existing tests still use it
        TECHNICIAN_ADFlagOn,    // NEW: use this going forward (flag 28750 is permanently ON)
        PHARMACIST_ADFlagOff,   // keep for backward compat — existing tests still use it
        PHARMACIST_ADFlagOn     // NEW: use this going forward (flag 28750 is permanently ON)
    }
}
