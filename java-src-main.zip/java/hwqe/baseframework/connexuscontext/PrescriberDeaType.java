package hwqe.baseframework.connexuscontext;

public enum PrescriberDeaType {
    ALL_DRUG("BT2413146"),
    NON_CONTROLLED_DRUG("BT2413146");

    private String deaNumber;
    PrescriberDeaType(String deaNumber) {
        this.deaNumber=deaNumber;
    }

    public String getPrescriberDeaType(){
        return deaNumber;
    }

}
