package hwqe.baseframework;

import net.datafaker.Faker;
import hwqe.baseframework.apicontext.RestClient;
import hwqe.baseframework.blobcontext.AzureBlobClient;
import hwqe.baseframework.bosscontext.BossManager;
import hwqe.baseframework.connexuscontext.ConnexusManager;
import hwqe.baseframework.connexuscontext.GrpcConnexusManager;
import hwqe.baseframework.flauicontext.grpc.GrpcConfig;
import hwqe.baseframework.connexuscontext.LoginAs;
import hwqe.baseframework.connexuscontext.WorkFlow;
import hwqe.baseframework.curbsideDispense.CurbsideManager;
import hwqe.baseframework.datacontext.*;
import hwqe.baseframework.dispenseappcontext.DispenseAppManager;
import hwqe.baseframework.imzappcontext.ImzAppManager;
import hwqe.baseframework.interfaces.*;
import hwqe.baseframework.ppicontext.constants.PPIConstants;
import hwqe.baseframework.rxonemobileappcontext.*;
import hwqe.baseframework.shippingappcontext.ShippingAppManager;
import hwqe.baseframework.storingappcontext.StoringAppManager;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.SlackContext;
import hwqe.baseframework.utilities.StringUtils;
import hwqe.baseframework.webcontext.BrowserType;
import hwqe.baseframework.webcontext.WebSiteManager;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;


/*
 * *********************************************************************************************************************************************************
 * Class Name - AutomationManager
 * Description: This class is the container which provides various functionalities from the framework
 * Inputs : none
 * returns: none
 * Author: Krishna Prasad Nandeti
 * *********************************************************************************************************************************************************
 */
@SuppressWarnings({
        "java:S6201",
        "java:S6539",
})
public class AutomationManager {

    private static final Logger logger = LoggerFactory.getLogger(AutomationManager.class);
    private static final Object lock = new Object();
    private static volatile AutomationManager instance;
    private final HashMap<String, RDBContext> storeifxContext = new HashMap<>();
    PropertyReader prop = PropertyReader.getInstance();
    private WorkFlow cnxWorkFlow;
    private CurbsideManager curbsidemobileapp;
    private hwqe.baseframework.bosscontext.WorkFlow bossWorkFlow;
    private RDBContext db2Context;
    private RDBContext cfdbContext;
    private RDBContext cfdboldContext;
    private RestClient restClient;
    private IConnexus cnxManager;
    private BossManager bossManager;
    private ImzAppManager imzApp;
    private StoringAppManager storingApp;
    private ShippingAppManager shippingApp;
    private RxOneMobileAppManager rxonemobileapp;
    private DispenseAppManager dispenseApp;
    private SlackContext slack;
    private IWebSite dpWebsite;
    private IWebSite asuiWebsite;
    private IWebSite rtfWebsite;
    private IWebSite acsiWebsite;
    private IWebSite ortfWebsite;
    private AzureBlobClient blobClient;
    private CosmosContext optEligContext;
    private final java.util.concurrent.ConcurrentMap<String, CosmosContext> bomCosmosContexts =
            new java.util.concurrent.ConcurrentHashMap<>();
    private CosmosContext optEquipContext;
    private CosmosContext fomContext;
    private CosmosContext fomDrugSubContext;
    private CosmosContext fomBaggingContext;
    private CosmosContext fomFillingContext;
    private CosmosContext fomFillingContextQA;
    private CosmosContext CFreceivingcosmos;
    private CosmosContext fomCFContext;
    private CosmosContext fomVVServiceContext;
    private CosmosContext fomVVRackContext;
    private CosmosContext fomRxFillLabelContext;
    private CosmosContext storeConfigCosmosContext;
    private CosmosContext optProviderCosmosContext;
    private CosmosContext optLocationCosmosContext;
    private CosmosContext optPatientCosmosContext;
    private CosmosContext optMarkdownCosmosContext;
    private CosmosContext optItemCosmosContext;
    private CosmosContext optOrderCosmosContext;
    private CosmosContext optInsuranceCosmosContext;
    private CosmosContext optPrescriptionCosmosContext;
    private CosmosContext ppiCosmosContext;
    private RDBContext patientSafetyContext;
    private RDBContext clinicalPackagesContext;
    private RDBContext compoundDrugContext;
    private RDBContext centralPatientContext;
    private RDBContext accountDbContext;
    private RDBContext accountDpDbSchedulerContext;
    private RDBContext carbonPrescriberContext;
    private RDBContext dataDistributionContext;
    private RDBContext masterDrugContext;
    private RDBContext workOrderContext;
    private CosmosContext workCosmosContext;
    private CosmosContext comOrderDb;
    private CosmosContext dpOrderDb;
    private CosmosContext fillCosmosContext;
    private CosmosContext rxCosmosContext;
    private CosmosContext erxCosmosContext;
    private CosmosContext pricingCosmosContext;
    private RDBContext optMakeDb;
    private CosmosContext hwInvAdjmtServiceCosmosContext;
    private RDBContext patientSafetyPrescriberContext;
    private CosmosContext rxItemCosmosContext;
    private CosmosContext rxItemCosmosContextProd;
    private RDBContext picontrolContext;
    private CosmosContext fillInvAdjmtCosmosContext;
    private CosmosContext CustomerPqcfCosmosContext;
    private CosmosContext ByPreAuthCosmosContext;
    private CosmosContext orderInsites;
    private RDBContext orderInsiteMakeDb;
    private RDBContext averageCostProcessContext;
    private RDBContext optDataArchiveDb;
    private CosmosContext enrollmentCosmosContext;
    private CosmosContext hwInvCsosServiceCosmosContext;

    private CosmosContext hwInvCycleCountCosmosContext;
    private CosmosContext hwInvControlledSubstanceAuditCosmosContext;
    private CosmosContext serviceSettingsContext;
    private CosmosContext OrchestratorCosmosContext;
    private CosmosContext customerPQCFContext;
    private CosmosContext rtfCosmosContext;
    private CosmosContext serviceReportingContext;
    private CosmosContext walkInOrchestrator;
    private CosmosContext ortfCosmosContext;
    private CosmosContext cloudToStoreSyncCosmosContext;
    private CosmosContext rxAndFillCosmosContext;
    private CosmosContext orderReturnsCosmosContext;
    private CosmosContext ServiceActivityCosmosContext;
    private RDBContext prmNumberingSqlDbContext;
    private RDBContext routingServiceSqlDbContext;
    private CosmosContext inboundReceivingCosmosContext;
    private CosmosContext hwInvInboundRcvServiceCosmosContext;
    private CosmosContext stsCosmosContext;
    private CosmosContext rxIdSearchCosmosContext;
    private CosmosContext verifyRxCosmosContext;
    private RDBContext testGphDb;
    private CosmosContext dpOrderCosmos;
    private CosmosContext serviceSettingsState;
    private IWebSite smDropOffWebsite;
    private IWebSite sonicUIWebsite;
    private RxOneHCCycleCountsAppManager rxOneHCCycleCountsAppManager;
    private RxOneHCRTSAppManager rxOneHCRTSAppManager;
    private RxOneHCACSIAppManager rxOneHCACSIAppManager;
    private RxOneHCAmberVialAppManager rxOneHCAmberVialAppManager;
    private CosmosContext strandDB;
    private CosmosContext uniqueIdDB;
    private CosmosContext esPatientDB;
    private CosmosContext narxcareDB;

    private CosmosContext optEcomContext;
    private CosmosContext optFulfillContext;
    private CosmosContext ecomDB;
    private CosmosContext rxpdhopsecomDB;
    private RxOneHCRxPDAppManager rxOneHCRxPDAppManager;
    private RDBContext whseDb2Context;
    private CosmosContext fomVVredesignContext;

    private CosmosContext hwinvVendorReturnCosmosContext;
    private CosmosContext cosmosContext;
    private CosmosContext recommendationDB;
    private CosmosContext tdcCosmosContext;
    private CosmosContext drugDiversionCosmosContext;
    private CosmosContext sonicDB;
    private CosmosContext centralPatientCosmosContext;
    private AutomationManager() {
        //Do nothing
    }

    public static AutomationManager getInstance() {
        AutomationManager tempInstance = instance;
        if (tempInstance == null) {
            synchronized (lock) {
                tempInstance = instance;
                if (tempInstance == null) {
                    instance = tempInstance = new AutomationManager();
                }
            }
        }
        return tempInstance;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getConnexus()
     * Description: This method create a new session of connexus or reattaches a connexus session if already exists
     * Inputs : none
     * returns: IConnexus
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IConnexus getConnexus() {
        if (this.cnxManager == null || needsReinitialization()) {
            if (GrpcConfig.getInstance().isGrpcEnabled()) {
                GrpcConnexusManager grpcManager = new GrpcConnexusManager();
                boolean launched = grpcManager.launchConnexus();
                if (!launched) {
                    throw new IllegalStateException(
                            "[AutomationManager] Failed to launch/attach Connexus via gRPC. "
                            + "Ensure the FlaUI gRPC server is running on the target RXPC machine "
                            + "and Connexus has fully loaded its UI (ShellForm) before this call.");
                }
                this.cnxManager = grpcManager;
            } else {
                this.cnxManager = new ConnexusManager();
                this.cnxManager.launchConnexus();
            }
        }
        return this.cnxManager;
    }

    /**
     * Check if the current manager needs re-initialization (Fix #5).
     * WinAppDriver mode: driver is null â†’ needs reinit.
     * gRPC mode: session is not active â†’ needs reinit.
     */
    private boolean needsReinitialization() {
        if (this.cnxManager instanceof GrpcConnexusManager) {
            return !((GrpcConnexusManager) this.cnxManager).isSessionActive();
        }
        return this.cnxManager.getDriver() == null;
    }

    public IConnexus relaunchConnexus() {
        if (GrpcConfig.getInstance().isGrpcEnabled()) {
            // In gRPC mode, Connexus runs on a REMOTE RXPC machine.
            // A local TASKKILL has no effect there. Instead, close the existing
            // gRPC session cleanly so getConnexus() can reconnect after restart.
            if (this.cnxManager != null) {
                try {
                    this.cnxManager.closeConnexus();
                } catch (Exception e) {
                    logger.warn("relaunchConnexus: gRPC session close failed (non-fatal): {}", e.getMessage());
                }
            }
        } else {
            // WinAppDriver mode â€” Connexus runs locally, TASKKILL is appropriate.
            try {
                new ProcessBuilder(
                        resolveWindowsSystemCommand("taskkill"),
                        "/F",
                        "/IM",
                        "connexus.exe"
                ).start();
            } catch (IOException e) {
                logger.warn("relaunchConnexus: TASKKILL failed: {}", e.getMessage());
            }
        }
        this.cnxManager = null;
        return getConnexus();
    }

    private String resolveWindowsSystemCommand(String commandName) {
        String systemRoot = System.getenv("SystemRoot");
        if (systemRoot != null && !systemRoot.trim().isEmpty()) {
            String candidate = Paths.get(systemRoot, "System32", commandName + ".exe").toString();
            java.io.File exe = new java.io.File(candidate);
            if (exe.exists() && exe.isFile()) {
                return exe.getAbsolutePath();
            }
        }
        throw new IllegalStateException(
                "Windows system command '" + commandName + "' not found under SystemRoot/System32. "
                        + "Refusing PATH fallback for security.");
    }

    //Removed this code "new ConnexusAppUtils().switchLoginScreen(userType);"
    // since flag 28750 update is no longer needed.
    // If relaunch with specific user type is needed in future,
    // we can add "new ConnexusAppUtils().switchLoginScreen(userType);" to this.
    public IConnexus relaunchConnexus(LoginAs.userType userType) {
        if (GrpcConfig.getInstance().isGrpcEnabled()
                && this.cnxManager instanceof GrpcConnexusManager) {
            GrpcConnexusManager grpcMgr = (GrpcConnexusManager) this.cnxManager;
            if (grpcMgr.isSessionActive()) {
                LoginAs.userType activeType = grpcMgr.getCurrentLoginType();
                if (activeType == null || activeType == userType) {
                    // activeType == null: login type not yet recorded (first TC) — reuse session.
                    // activeType == userType: same login type — reuse session, no re-login needed.
                    logger.info("[gRPC] relaunchConnexus: login type ({}) matches active session ({}), reusing.",
                            userType, activeType);
                    return this.cnxManager;
                }
                // Only reach here when activeType is known AND differs from requested type.
                // Close current session and re-login with the new type.
                logger.info("[gRPC] relaunchConnexus: login type changed ({} → {}), closing session for re-login.",
                        activeType, userType);
                try {
                    grpcMgr.closeConnexus();
                } catch (Exception e) {
                    logger.warn("[gRPC] relaunchConnexus: session close failed (non-fatal): {}", e.getMessage());
                }
                this.cnxManager = null;
            }
        }
        return relaunchConnexus();
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getBoss()
     * Description: This method create a new session of BOSS or reattaches a BOSS session if already exists
     * Inputs : none
     * returns: IBoss
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IBoss getBoss() {
        if (this.bossManager == null || this.bossManager.getDriver() == null) {
            this.bossManager = new BossManager();
            this.bossManager.launchBoss();
        }
        return this.bossManager;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getImzApp()
     * Description: This method create a new session of IMZ app or reattaches a IMZ app session if already exists
     * Inputs : none
     * returns: IMobileApp
     * Author: Ashok Gurijala
     * *********************************************************************************************************************************************************
     */
    public IMobileApp getImzApp() {
        if (this.imzApp == null || this.imzApp.getDriver() == null) {
            this.imzApp = new ImzAppManager();
            this.imzApp.launchMobileApp();
        }
        return this.imzApp;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getStoringApp()
     * Description: This method create a new session of storing app or reattaches a storing app session if already exists
     * Inputs : none
     * returns: IStoringApp
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IMobileApp getStoringApp() {
        if (this.storingApp == null || this.storingApp.getDriver() == null) {
            this.storingApp = new StoringAppManager();
            this.storingApp.launchMobileApp();
        }
        return this.storingApp;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getShippingApp()
     * Description: This method create a new session of Shipping app or reattaches a Shipping app session if already exists
     * Inputs : none
     * returns: IShippingApp
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IMobileApp getShippingApp() {
        if (this.shippingApp == null || this.shippingApp.getDriver() == null) {
            this.shippingApp = new ShippingAppManager();
            this.shippingApp.launchMobileApp();
        }
        return this.shippingApp;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRxOneMobileApp()
     * Description: This method create a new session of rxone mobile app or reattaches a rxone mobile app session if already exists
     * Inputs : none
     * returns: rxonemobileapp
     * Author: Sireesha Appisetty
     * *********************************************************************************************************************************************************
     */
    public IAndroidApp getRxOneMobileApp() {
        if (this.rxonemobileapp == null || this.rxonemobileapp.getDriver() == null) {
            this.rxonemobileapp = new RxOneMobileAppManager();
            this.rxonemobileapp.launchMobileApp();
        }
        return this.rxonemobileapp;
    }

    //this method accepts name of any rxone specific app and returns an app session
    public IAndroidApp getRxOneApps(String apkName, String testName) {
        if (this.rxonemobileapp == null || this.rxonemobileapp.getDriver() == null) {
            this.rxonemobileapp = new RxOneMobileAppManager();
            this.rxonemobileapp.launchMobileApp(apkName,testName);
        }
        return this.rxonemobileapp;
    }


    /*
     * *********************************************************************************************************************************************************
     * Method Name - getDispenseApp()
     * Description: This method create a new session of dispense app or reattaches a dispense app session if already exists
     * Inputs : none
     * returns: IStoringApp
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IMobileApp getDispenseApp() {
        if (this.dispenseApp == null || this.dispenseApp.getDriver() == null) {
            this.dispenseApp = new DispenseAppManager();
            this.dispenseApp.launchMobileApp();
        }
        return this.dispenseApp;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getDigitalPharmacyApp()
     * Description: This method create a new session of digital pharmacy app or reattaches a DP app session if already exists
     * Inputs : none
     * returns: IMobileApp
     * Author: Saloni Sharma
     * *********************************************************************************************************************************************************
     */
   /* public IMobileApp getDigitalPharmacyApp() {
        if (this.digitalPharmacyMobileApp == null || this.digitalPharmacyMobileApp.getDriver() == null) {
            this.digitalPharmacyMobileApp = new DigitalPharmacyAndroidMobileAppManager();
            this.digitalPharmacyMobileApp.launchMobileApp();
        }
        return this.digitalPharmacyMobileApp;
    }
*/

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getBossWorkFlow()
     * Description: This method will perform workflows for Boss application
     * Inputs : none
     * returns: hwqe.baseframework.bosscontext.WorkFlow
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public hwqe.baseframework.bosscontext.WorkFlow getBossWorkFlow() {
        if (this.bossManager == null && this.bossWorkFlow == null) {
            this.bossManager = new BossManager();
            this.bossManager.launchBoss();
        }
        if (this.bossWorkFlow == null) {
            this.bossWorkFlow = new hwqe.baseframework.bosscontext.WorkFlow(this.bossManager);
        }
        return this.bossWorkFlow;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getConnexusWorkFlow()
     * Description: This method will perform workflows for Connexus application
     * Inputs : none
     * returns: IWorkFlow
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IWorkFlow getConnexusWorkFlow() {
       /* if (this.cnxWorkFlow == null && this.cnxManager == null) {
            this.cnxManager = new ConnexusManager();
            this.cnxManager.launchConnexus();
        }
        if (this.cnxWorkFlow == null) {
            this.cnxWorkFlow = new WorkFlow(this.cnxManager);
        }
        return this.cnxWorkFlow;*/
        return new WorkFlow();
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getConnexusDB()
     * Description: This method will perform database operations on connexus database based on the store set to pclist
     * Inputs : none
     * returns: IDatabaseContext
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getConnexusDB() {
        return this.getConnexusDB(Integer.parseInt(prop.getConnexusStoreNo()));
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getConnexusDB()
     * Description: This method will perform database operations on connexus database based on the store number passed
     * Inputs : storeNo
     * returns: IDatabaseContext
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getConnexusDB(int storeNo) {

        if (storeifxContext.containsKey("cnx" + storeNo)) {
            return storeifxContext.get("cnx" + storeNo);

        } else {
            String storeNumber = Integer.toString(storeNo);
            if (storeNumber.length() == 4) {
                storeNumber = "0" + storeNumber;
            }
            DBCredentials creds = new DBCredentials();
            creds.setDriverName(prop.getProperty("cnx.driver_name"));
            creds.setDbUrl(prop.getProperty("cnx.db_url").replace("XXXXX", storeNumber));
            creds.setDbUsername(prop.getProperty("cnx.db_username"));
            creds.setDbPassword(prop.getProperty("cnx.db_password"));
            RDBContext ctx = new RDBContext(creds);
            storeifxContext.put("cnx" + storeNo, ctx);
            return ctx;
        }
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getDomDB()
     * Description: This method will return database context of Dom DB
     * Inputs : NA
     * returns: IDatabaseContext
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getDomDB() {
        MSICredentials creds = new MSICredentials();
        prop.loadCustomProperties("config/dom/");
        creds.setTenantId(prop.getProperty("dom.db_tenantid"));
        creds.setClientSecret(prop.getProperty("dom.db_secret"));
        creds.setClientId(prop.getProperty("dom.db_clientid"));
        creds.setDbHost(prop.getProperty("dom.db_host"));
        creds.setDbName(prop.getProperty("dom.db_name"));
        RDBContext ctx = new RDBContext(creds);
        return ctx;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getBossDB()
     * Description: This method will perform database operations on optical database based on the store set to pclist
     * Inputs : none
     * returns: IDatabaseContext
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getBossDB() {
        return this.getBossDB(Integer.parseInt(prop.getBossStoreNo()));
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getBossDB()
     * Description: This method will perform database operations on optical database based on the store number passed
     * Inputs : storeNo
     * returns: IDatabaseContext
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getBossDB(int storeNo) {
        if (storeifxContext.containsKey("optical" + storeNo)) {
            return storeifxContext.get("optical" + storeNo);
        } else {
            String storeNumber = Integer.toString(storeNo);
            if (storeNumber.length() == 4) {
                storeNumber = "0" + storeNumber;
            }
            DBCredentials creds = new DBCredentials();
            creds.setDriverName(prop.getProperty("boss.driver_name"));
            creds.setDbUrl(prop.getProperty("boss.db_url").replace("XXXXX", storeNumber));
            creds.setDbUsername(prop.getProperty("boss.db_username"));
            creds.setDbPassword(prop.getProperty("boss.db_password"));
            RDBContext ctx = new RDBContext(creds);
            storeifxContext.put("optical" + storeNo, ctx);
            return ctx;
        }
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getDb2Context()
     * Description: This method will perform database operations on pharmacy DB2 database
     * Inputs : storeNo
     * returns: IDatabaseContext
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getDb2Context() {
        if (this.db2Context == null) {
            DBCredentials creds = new DBCredentials();
            creds.setDriverName(prop.getProperty("db2.driver_name"));
            creds.setDbUrl(prop.getProperty("db2.db_url"));
            creds.setDbUsername(prop.getProperty("db2.db_username"));
            creds.setDbPassword(prop.getProperty("db2.db_password"));
            this.db2Context = new RDBContext(creds);
        }
        return this.db2Context;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRestContext()
     * Description: This method will provide interface for performing REST operations
     * Inputs : none
     * returns: IRestClient
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IRestClient getRestContext() {
        if (this.restClient == null) {
            this.restClient = new RestClient();
        }
        return this.restClient;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getSlack()
     * Description: This method will provide interface for performing slack operation like posting message and uploading files
     * Inputs : none
     * returns: ISlack
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public ISlack getSlack() {
        if (this.slack == null) {
            List<String> channels = Reporter.getSlackChannels();
            if (!channels.isEmpty()) {
                this.slack = new SlackContext(channels);
            } else {
                for (String str : prop.getProperty("app.slack_channel").split(";")) {
                    if (StringUtils.isNotNullOrEmpty(str)) {
                        channels.add(str);
                    }
                }
                this.slack = new SlackContext(channels);
            }
        }
        return this.slack;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getDigitalPharmacy()
     * Description: This method will launch digital pharmacy website and creates or attaches session if exists
     * Inputs : none
     * returns: IWebSite
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IWebSite getDigitalPharmacy() {
        if (this.dpWebsite == null) {
            this.dpWebsite = new WebSiteManager();
            this.dpWebsite.launchWebsite(prop.getProperty("web.dp_base_url"), BrowserType.valueOf(prop.getProperty("web.dp_browser")));
        }
        return this.dpWebsite;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getAsuiLoginPage()
     * Description: This method will launch ASUI website
     * Inputs : none
     * returns: IWebSite
     * Author: Ashok Gurijala
     * *********************************************************************************************************************************************************
     */
    public IWebSite getAsuiLoginPage() {
        if (this.asuiWebsite == null) {
            this.asuiWebsite = new WebSiteManager();
            this.asuiWebsite.launchWebsite(prop.getProperty("web.asui_base_url"), BrowserType.valueOf(prop.getProperty("web.asui_browser")));
        }
        return this.asuiWebsite;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRTFLandingPage()
     * Description: This method will launch Rtf Landing Page
     * Inputs : none
     * returns: IWebSite
     * Author: Tushar Ranjan
     * *********************************************************************************************************************************************************
     */
    public IWebSite getRTFLandingPage() {
        if (this.rtfWebsite == null) {
            this.rtfWebsite = new WebSiteManager();
            this.rtfWebsite.launchWebsite(prop.getProperty("prm.rtfUi.url"), BrowserType.valueOf(prop.getProperty("prm.rtfUi.Browser")));
        }
        return this.rtfWebsite;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getLandingPageForACSIReportingTool
     * Description: This method will launch ACSI Reporting Tool Landing Page
     * Inputs : none
     * returns: IWebSite
     * Author: Mubeen Ahmed Mohammed
     * *********************************************************************************************************************************************************
     */
    public IWebSite getAcsiLandingPage(){
        if(this.acsiWebsite == null){
            this.acsiWebsite = new WebSiteManager();
            this.acsiWebsite.launchWebsite(prop.getProperty("acsistg_landingpage_url"), BrowserType.Chrome);
        }
        return this.acsiWebsite;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getORTFLoginPage()
     * Description: This method will launch Ortf login Page
     * Inputs : none
     * returns: IWebSite
     * Author: Bhargav
     * *********************************************************************************************************************************************************
     */
    public IWebSite getORTFLoginPage() {
        if (this.ortfWebsite == null) {
            this.ortfWebsite = new WebSiteManager();
            this.ortfWebsite.launchWebsite(prop.getProperty("prm.ortfUI.url"), BrowserType.valueOf(prop.getProperty("prm.ortfUI.Browser")));
        }
        return this.ortfWebsite;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getORTFClosedStoreLoginPage()
     * Description: This method will launch Ortf login Page
     * Inputs : none
     * returns: IWebSite
     * Author: Balaji Rajaram
     * *********************************************************************************************************************************************************
     */
    public IWebSite getORTFClosedStoreLoginPage() {
        if (this.ortfWebsite == null) {
            this.ortfWebsite = new WebSiteManager();
            this.ortfWebsite.launchWebsite(prop.getProperty("prm.ortfClosedStoreUI.url"), BrowserType.valueOf(prop.getProperty("prm.ortfUI.Browser")));
        }
        return this.ortfWebsite;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getBlobContext()
     * Description: This method will create an instance of Automation blob client
     * Inputs : none
     * returns: AzureBlobClient
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public AzureBlobClient getBlobContext() {
        if (this.blobClient == null) {
            this.blobClient = new AzureBlobClient(prop.getProperty("app.blob_connectionstring"), prop.getProperty("app.blob_containername"));
            this.blobClient.connect();
        }
        return this.blobClient;
    }

    public IDatabaseContext getCFDBContext() {
        if (this.cfdbContext == null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/ccf/");
            creds.setDriverName(prop.getProperty("cf.driver_name_azure"));
            creds.setDbUrl(prop.getProperty("cf.db_url_azure"));
            creds.setDbUsername(prop.getProperty("cf.azure.sqldb.key"));
            creds.setDbPassword(prop.getProperty("cf.azure.sqldb.pwd"));
            this.cfdbContext = new RDBContext(creds);
        }
        return this.cfdbContext;
    }

    public IDatabaseContext getCFOldDBContext(){
        if(this.cfdboldContext==null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/ccf/");
            creds.setDriverName(prop.getProperty("cf.sql.driver_name"));
            creds.setDbUrl(prop.getProperty("cf.sql.db_url"));
            creds.setDbUsername(prop.getProperty("cf.sql.db_username"));
            creds.setDbPassword(prop.getProperty("cf.sql.db_password"));
            this.cfdboldContext = new RDBContext(creds);
        }
        return this.cfdboldContext;
    }

    public CosmosContext getOptConfigDb() {
        if (this.storeConfigCosmosContext == null) {
            prop.loadCustomProperties("config/optical/siteconfig/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("opt_siteconfig.host_name"));
            c.setKey(prop.getProperty("opt_siteconfig.db_key"));
            c.setDatabase(prop.getProperty("opt_siteconfig.db_name"));
            this.storeConfigCosmosContext = new CosmosContext(c);
        }
        return this.storeConfigCosmosContext;
    }


    public CosmosContext getOptProviderDb() {
        if (this.optProviderCosmosContext == null) {
            prop.loadCustomProperties("config/optical/provider/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("opt_provider.host_name"));
            c.setKey(prop.getProperty("opt_provider.db_key"));
            c.setDatabase(prop.getProperty("opt_provider.db_name"));
            this.optProviderCosmosContext = new CosmosContext(c);
        }
        return this.optProviderCosmosContext;
    }

    public CosmosContext getOptLocationDb() {
        if (this.optLocationCosmosContext == null) {
            prop.loadCustomProperties("config/optical/location/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("opt_location.host_name"));
            c.setKey(prop.getProperty("opt_location.db_key"));
            c.setDatabase(prop.getProperty("opt_location.db_name"));
            this.optLocationCosmosContext = new CosmosContext(c);
        }
        return this.optLocationCosmosContext;
    }

    public CosmosContext getOptPatientDb() {
        if (this.optPatientCosmosContext == null) {
            prop.loadCustomProperties("config/optical/patient/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("opt_patient.host_name"));
            c.setKey(prop.getProperty("opt_patient.db_key"));
            c.setDatabase(prop.getProperty("opt_patient.db_name"));
            this.optPatientCosmosContext = new CosmosContext(c);
        }
        return this.optPatientCosmosContext;
    }

    public CosmosContext getOptMarkdownDb() {
        if (this.optMarkdownCosmosContext == null) {
            prop.loadCustomProperties("config/optical/markdown/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("opt_markdown.host_name"));
            c.setKey(prop.getProperty("opt_markdown.db_key"));
            c.setDatabase(prop.getProperty("opt_markdown.db_name"));
            this.optMarkdownCosmosContext = new CosmosContext(c);
        }
        return this.optMarkdownCosmosContext;
    }

    public CosmosContext getOptItemDb() {
        if (this.optItemCosmosContext == null) {
            prop.loadCustomProperties("config/optical/item/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("opt_item.host_name"));
            c.setKey(prop.getProperty("opt_item.db_key"));
            c.setDatabase(prop.getProperty("opt_item.db_name"));
            this.optItemCosmosContext = new CosmosContext(c);
        }
        return this.optItemCosmosContext;
    }

    public CosmosContext getOptInsuranceDb() {
        if (this.optInsuranceCosmosContext == null) {
            prop.loadCustomProperties("config/optical/insurance/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("opt_insurance.host_name"));
            c.setKey(prop.getProperty("opt_insurance.db_key"));
            c.setDatabase(prop.getProperty("opt_insurance.db_name"));
            this.optInsuranceCosmosContext = new CosmosContext(c);
        }
        return this.optInsuranceCosmosContext;
    }

    public CosmosContext getOptOrderDb() {
        if (this.optOrderCosmosContext == null) {
            prop.loadCustomProperties("config/optical/order/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("opt_order.host_name"));
            c.setKey(prop.getProperty("opt_order.db_key"));
            c.setDatabase(prop.getProperty("opt_order.db_name"));
            this.optOrderCosmosContext = new CosmosContext(c);
        }
        return this.optOrderCosmosContext;
    }

    public CosmosContext getOptPrescriptionDb() {
        if (this.optPrescriptionCosmosContext == null) {
            prop.loadCustomProperties("config/optical/prescription/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("opt_prescription.host_name"));
            c.setKey(prop.getProperty("opt_prescription.db_key"));
            c.setDatabase(prop.getProperty("opt_prescription.db_name"));
            this.optPrescriptionCosmosContext = new CosmosContext(c);
        }
        return this.optPrescriptionCosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getOptEligDb()
     * Description: This method will create an instance of Optical Eligibility Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getOptEligDb() {
        if (this.optEligContext == null) {
            prop.loadCustomProperties("config/optical/eligibility/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("opt.elig.db_host"));
            c.setKey(prop.getProperty("opt.elig.db_key"));
            c.setDatabase(prop.getProperty("opt.elig.db_name"));
            this.optEligContext = new CosmosContext(c);
        }
        return this.optEligContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getOptEquipDb()
     * Description: This method will create an instance of Optical Eligibility Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Sri priya Kodali
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getOptEquipDb() {
        if (this.optEquipContext == null) {
            prop.loadCustomProperties("config/optical/equipment/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("opt_equip.db_host"));
            c.setKey(prop.getProperty("opt_equip.db_key"));
            c.setDatabase(prop.getProperty("opt_equip.db_name"));
            this.optEquipContext = new CosmosContext(c);
        }
        return this.optEquipContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getOptMakeDb()
     * Description: This method will create an instance of Optical Makeability SQL Server context
     * Inputs : none
     * returns: RDBContext
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public RDBContext getOptMakeDb() {
        if (this.optEligContext == null) {
            prop.loadCustomProperties("config/optical/makeability/");
            DBCredentials dbCredentials = new DBCredentials();
            dbCredentials.setDriverName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            dbCredentials.setDbUrl(prop.getProperty("opt_make.db_connectionstring"));
            dbCredentials.setDbUsername(prop.getProperty("opt_make.db_username"));
            dbCredentials.setDbPassword(prop.getProperty("opt_make.db_password"));
            this.optMakeDb = new RDBContext(dbCredentials);
        }
        return this.optMakeDb;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getOptPatientHistNotesDb()
     * Description: This method will create an instance of Optical PatientHistoryNotes SQL Server context
     * Inputs : none
     * returns: RDBContext
     * Author: Tarkeshwar Prasad Rahangdale
     * *********************************************************************************************************************************************************
     */
    public RDBContext getOptDataArchiveDb() {
        prop.loadCustomProperties("config/optical/patienthistory/");
        DBCredentials dbCredentials = new DBCredentials();
        dbCredentials.setDriverName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        dbCredentials.setDbUrl(prop.getProperty("opt_patienthistory.db_connectionstring"));
        dbCredentials.setDbUsername(prop.getProperty("opt_patienthistory.db_username"));
        dbCredentials.setDbPassword(prop.getProperty("opt_patienthistory.db_pwd"));
        this.optDataArchiveDb = new RDBContext(dbCredentials);
        return this.optDataArchiveDb;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getFomEligDb()
     * Description: This method will create an instance of FOM Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Prashanth Reddy Ganta
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getFomDb() {
        if (this.fomContext == null) {
            prop.loadCustomProperties("config/fom/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("fom.elig.db_host"));
            c.setKey(prop.getProperty("fom.elig.db_key"));
            c.setDatabase(prop.getProperty("fom.elig.db_name"));
            this.fomContext = new CosmosContext(c);
        }
        return this.fomContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getFomDrugSubDb()
     * Description: This method will create an instance of FOM Cosmos Drug Sub db context
     * Inputs : none
     * returns: CosmosContext
     * Author: Prashanth Reddy Ganta
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getFomDrugSubDb() {
        if (this.fomDrugSubContext == null) {
            prop.loadCustomProperties("config/fom/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("fom.drugsub.db_host"));
            c.setKey(prop.getProperty("fom.drugsub.db_key"));
            c.setDatabase(prop.getProperty("fom.drugsub.db_name"));
            this.fomDrugSubContext = new CosmosContext(c);
        }
        return this.fomDrugSubContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getFomBaggingDb()
     * Description: This method will create an instance of FOM Cosmos Bagging db context
     * Inputs : none
     * returns: CosmosContext
     * Author: Prashanth Reddy Ganta
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getFomBaggingDb() {
        if (this.fomBaggingContext == null) {
            prop.loadCustomProperties("config/fom/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("fom.bagging.db_host"));
            c.setKey(prop.getProperty("fom.bagging.db_key"));
            c.setDatabase(prop.getProperty("fom.bagging.db_name"));
            this.fomBaggingContext = new CosmosContext(c);
        }
        return this.fomBaggingContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getFomFillingDb()
     * Description: This method will create an instance of FOM Cosmos Filling db context
     * Inputs : none
     * returns: CosmosContext
     * Author: Prashanth Reddy Ganta
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getFomFillingDb() {
        if (this.fomFillingContext == null) {
            prop.loadCustomProperties("config/fom/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("fom.filling.db_host"));
            c.setKey(prop.getProperty("fom.filling.db_key"));
            c.setDatabase(prop.getProperty("fom.filling.db_name"));
            this.fomFillingContext = new CosmosContext(c);
        }
        return this.fomFillingContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getFomCFDb()
     * Description: This method will create an instance of FOM CF db context
     * Inputs : none
     * returns: CosmosContext
     * Author: Prashanth Reddy Ganta
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getFomCFDb() {
        if (this.fomCFContext == null) {
            prop.loadCustomProperties("config/fom/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("fom.cf.db_host"));
            c.setKey(prop.getProperty("fom.cf.db_key"));
            c.setDatabase(prop.getProperty("fom.cf.db_name"));
            this.fomCFContext = new CosmosContext(c);
        }
        return this.fomCFContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getFomRxFillLabelDb()
     * Description: This method will create an instance of FOM Cosmos RxFillLabel db context
     * Inputs : none
     * returns: CosmosContext
     * Author: Prashanth Reddy Ganta
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getFomRxFillLabelDb() {
        if (this.fomRxFillLabelContext == null) {
            prop.loadCustomProperties("config/fom/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("fom.filling.db_host"));
            c.setKey(prop.getProperty("fom.filling.db_key"));
            c.setDatabase(prop.getProperty("fom.RxFillLabel.db_name"));
            this.fomRxFillLabelContext = new CosmosContext(c);
        }
        return this.fomRxFillLabelContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getFomVVRackDb()
     * Description: This method will create an instance of FOM Cosmos VVRack db context
     * Inputs : none
     * returns: CosmosContext
     * Author: Prashanth Reddy Ganta
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getFomVVRackDb() {
        if (this.fomVVRackContext == null) {
            prop.loadCustomProperties("config/fom/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("fom.VV.db_host"));
            c.setKey(prop.getProperty("fom.VV.db_key"));
            c.setDatabase(prop.getProperty("fom.VV.db_name"));
            this.fomVVRackContext = new CosmosContext(c);
        }
        return this.fomVVRackContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getFomVVServiceDb()
     * Description: This method will create an instance of HW_VV_SERVICE container
     * Inputs : none
     * returns: CosmosContext
     * Author: Prashanth Reddy Ganta
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getFomVVServiceDb() {
        if (this.fomVVServiceContext == null) {
            prop.loadCustomProperties("config/fom/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("fom.VV.db_host"));
            c.setKey(prop.getProperty("fom.VV.db_key"));
            c.setDatabase(prop.getProperty("fom.VVService.db_name"));
            this.fomVVServiceContext = new CosmosContext(c);
        }
        return this.fomVVServiceContext;
    }

    public void performSleep(int waitTimeInSec) {
        try {
            Thread.sleep(waitTimeInSec * 1000);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getPatientSafetyDBContext()for dev and QA env
     * Description: This method will create an instance of patient safety db connection
     * Inputs : none
     * returns: patient safety IDatabase context
     * Author: Shyamali Kakati
     * To run in dev environment use creds.setDbPassword(prop.getProperty("rdm.cd.db_password"));
     * *********************************************************************************************************************************************************
     */

    public IDatabaseContext getPatientSafetyDBContext() {
        if (this.patientSafetyContext == null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/rdm/patientsafety/");
            creds.setDriverName(prop.getProperty("rdm.ps.driver_name"));
            creds.setDbUrl(prop.getProperty("rdm.ps.db_url"));
            creds.setDbUsername(prop.getProperty("rdm.ps.db_username"));
            if ("dev".equals(System.getProperty("testEnvironment")) || "dev".equalsIgnoreCase(prop.getEnvironment().toString())) {
                creds.setDbPassword(prop.getProperty("rdm.cd.db_password"));
            } else if ("stg".equals(System.getProperty("testEnvironment")) || "stg".equalsIgnoreCase(prop.getEnvironment().toString())) {
                creds.setDbPassword(prop.getProperty("rdm.ps.db_password"));
            } else {
                creds.setDbPassword(prop.getProperty("rdm.ps.qe.db_password"));
            }
            this.patientSafetyContext = new RDBContext(creds);
        }
        return this.patientSafetyContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getPatientSafetyPrescriberDBContext()for dev and QA env
     * Description: This method will create an instance of prescriber db connection
     * Inputs : none
     * returns: HW_Prescriber IDatabase context
     * Author: Shyamali Kakati
     * *********************************************************************************************************************************************************
     */

    public IDatabaseContext getPatientSafetyPrescriberDBContext() {
        if (this.patientSafetyPrescriberContext == null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/rdm/patientsafety/");
            creds.setDriverName(prop.getProperty("rdm.ps.driver_name"));
            creds.setDbUrl(prop.getProperty("rdm.ps.db_prescriber_url"));
            creds.setDbUsername(prop.getProperty("rdm.ps.db_username"));
            creds.setDbPassword(prop.getProperty("rdm.ps.db_password"));
            this.patientSafetyPrescriberContext = new RDBContext(creds);
        }
        return this.patientSafetyPrescriberContext;
    }


    public CosmosContext getPrmWorkCosmos() {
        if (this.workCosmosContext == null) {
            prop.loadCustomProperties("config/prm/workService/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("prm.workServices.host"));
            c.setKey(prop.getProperty("prm.workServices.key"));
            c.setDatabase(prop.getProperty("prm.workServices.db"));
            this.workCosmosContext = new CosmosContext(c);
        }
        return this.workCosmosContext;
    }

    public CosmosContext getPrmRefusalCosmos() {
        if (this.rtfCosmosContext == null) {
            //prop.loadCustomProperties("config/prm/workService/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("prm.refusalServices.host"));
            c.setKey(prop.getProperty("prm.refusalServices.key"));
            c.setDatabase(prop.getProperty("prm.refusalServices.db"));
            this.rtfCosmosContext = new CosmosContext(c);
        }
        return this.rtfCosmosContext;
    }

    public CosmosContext getComOrderDb() {
        if (this.comOrderDb == null) {
            prop.loadCustomProperties("config/comos/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("comos.db_host"));
            c.setKey(prop.getProperty("comos.db_key"));
            c.setDatabase(prop.getProperty("comos.db_database"));
            this.comOrderDb = new CosmosContext(c);
        }
        return this.comOrderDb;
    }

    public CosmosContext getPrmFillCosmos() {
        if (this.fillCosmosContext == null) {
            prop.loadCustomProperties("config/prm/fill/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("prm.fillServices.host"));
            c.setKey(prop.getProperty("prm.fillServices.key"));
            c.setDatabase(prop.getProperty("prm.fillServices.db"));
            this.fillCosmosContext = new CosmosContext(c);
        }
        return this.fillCosmosContext;
    }

    /**
     * Helper method to create BOM Cosmos context for a specific database and environment.
     * Reduces code duplication across dev/stg methods.
     * @param dbNameProperty Property key for database name (e.g., "bom.patientBenefit.db_name")
     * @param env Environment ("dev" or "stg")
     * @return New CosmosContext instance
     */
    private CosmosContext createBomCosmosContext(String dbNameProperty, String env) {
        prop.loadCustomProperties("config/bom/");
        CosmosCredentials c = new CosmosCredentials();
        String envPrefix = "stg".equalsIgnoreCase(env) ? "bom.stage" : "bom.dev";
        c.setHost(prop.getProperty(envPrefix + ".db_host"));
        c.setKey(prop.getProperty(envPrefix + ".db_key"));
        c.setDatabase(prop.getProperty(dbNameProperty));
        return new CosmosContext(c);
    }

    /**
     * Public method to get BOM Cosmos context for a specific database and environment.
     * @param dbNameProperty Property key for database name (e.g., "bom.patientBenefit.db_name")
     * @param env Environment ("dev" or "stg")
     * @return CosmosContext instance (not cached)
     */
    public CosmosContext getBomCosmosContext(String dbNameProperty, String env) {
        String normalizedEnv = env == null ? "" : env.trim().toLowerCase();
        String cacheKey = normalizedEnv + "|" + dbNameProperty;
        return bomCosmosContexts.computeIfAbsent(cacheKey, k -> createBomCosmosContext(dbNameProperty, env));
    }


    public CosmosContext getPrmRxCosmos() {
        if (this.rxCosmosContext == null) {
            prop.loadCustomProperties("config/prm/rxservices/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("prm.rxservices.host"));
            c.setKey(prop.getProperty("prm.rxservices.key"));
            c.setDatabase(prop.getProperty("prm.rxservices.db"));
            this.rxCosmosContext = new CosmosContext(c);
        }
        return this.rxCosmosContext;
    }

    public CosmosContext getPrmRxFillCosmos() {
        if (this.rxAndFillCosmosContext == null) {
            prop.loadCustomProperties("config/prm/rxandfillservice/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("prm.rxandfillservices.host"));
            c.setKey(prop.getProperty("prm.rxandfillservices.key"));
            c.setDatabase(prop.getProperty("prm.rxandfillservices.db"));
            this.rxAndFillCosmosContext = new CosmosContext(c);
        }
        return this.rxAndFillCosmosContext;
    }

    public CosmosContext getPrmFaxCosmos() {
        if (this.rxCosmosContext == null) {
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("prm.Faxservices.host"));
            c.setKey(prop.getProperty("prm.Faxservices.key"));
            c.setDatabase(prop.getProperty("prm.Faxservices.db"));
            this.rxCosmosContext = new CosmosContext(c);
        }
        return this.rxCosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getCentralPatientSqlServerDBContext()for QA env
     * Description: This method will create an instance of central patient sql server db connection
     * Inputs : none
     * returns: central patient sql server IDatabase context
     * Author: Scott Leung
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getCentralPatientSqlServerDBContext() {
        if (this.centralPatientContext == null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/rdm/centralpatient/");
            creds.setDriverName(prop.getProperty("rdm.cp.SqlServerDriverName"));
            creds.setDbUrl(prop.getProperty("rdm.cp.SqlServerDBUrl"));
            creds.setDbUsername(prop.getProperty("rdm.cp.SqlServerDBUser"));
            creds.setDbPassword(prop.getProperty("rdm.cp.sqlserverdb_password"));
            this.centralPatientContext = new RDBContext(creds);
        }
        return this.centralPatientContext;
    }

    public CosmosContext getErxCosmos() {
        if (this.erxCosmosContext == null) {
            prop.loadCustomProperties("config/prm/erx/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("prm.erx.host"));
            c.setKey(prop.getProperty("prm.erx.key"));
            c.setDatabase(prop.getProperty("prm.erx.db"));
            this.erxCosmosContext = new CosmosContext(c);
        }
        return this.erxCosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getPricingCosmosContext()
     * Description: This method will create an instance of Pricing Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Ayush Seth
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getPricingCosmosContext() {
        if (this.pricingCosmosContext == null) {
            prop.loadCustomProperties("config/pricing/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("pricing.cosmos.host"));
            c.setKey(prop.getProperty("pricing.cosmos.key"));
            c.setDatabase(prop.getProperty("pricing.cosmos.db"));
            this.pricingCosmosContext = new CosmosContext(c);
        }
        return this.pricingCosmosContext;
    }


    /* *********************************************************************************************************************************************************
     * Method Name - getClinicalPackagesDBContext()for dev and QA env
     * Description: This method will create an instance of clinical packages db connection
     * Inputs : none
     * returns: clinical packages IDatabase context
     * Author: Shaista Iqbal
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getClinicalPackagesDBContext() {
        if (this.clinicalPackagesContext == null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/rdm/mo/clinicalpackages/");
            creds.setDriverName(prop.getProperty("rdm.cp.driver_name"));
            creds.setDbUrl(prop.getProperty("rdm.cp.db_url"));
            creds.setDbUsername(prop.getProperty("rdm.cp.db_username"));
            creds.setDbPassword(prop.getProperty("rdm.cp.db_stg_password"));
            this.clinicalPackagesContext = new RDBContext(creds);
        }
        return this.clinicalPackagesContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getCompoundDrugDBContext()for dev and QA env
     * Description: This method will create an instance of compound drug db connection
     * Inputs : none
     * returns: compound drug IDatabase context
     * Author: Muhammad Rizwan
     * *********************************************************************************************************************************************************
     */

    public IDatabaseContext getCompoundDrugDBContext() {
        if (this.compoundDrugContext == null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/rdm/compounddrug/");
            creds.setDriverName(prop.getProperty("rdm.cd.driver_name"));
            creds.setDbUrl(prop.getProperty("rdm.cd.db_url"));
            creds.setDbUsername(prop.getProperty("rdm.cd.db_username"));
            creds.setDbPassword(prop.getProperty("rdm.cp.db_stg_password"));
            this.compoundDrugContext = new RDBContext(creds);
        }
        return this.compoundDrugContext;

    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getCarbonPrescriberDBContext()for dev and QA env
     * Description: This method will create an instance of carbon prescriber db connection
     * Inputs : none
     * returns: carbon prescriber IDatabase context
     * Author: Wasif Mirza
     * *********************************************************************************************************************************************************
     */

    public IDatabaseContext getCarbonPrescriberDBContext() {
        if (this.carbonPrescriberContext == null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/rdm/carbonprescriber/");
            creds.setDriverName(prop.getProperty("rdm.cpb.driver_name"));
            creds.setDbUrl(prop.getProperty("rdm.cpb.db_url"));
            creds.setDbUsername(prop.getProperty("rdm.cpb.db_username"));
            creds.setDbPassword(prop.getProperty("rdm.cpb.db_password"));
            this.carbonPrescriberContext = new RDBContext(creds);
        }
        return this.carbonPrescriberContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getCarbonPrescriberDBContextWithServicePrincipal()
     * Description: This method will create an instance of carbon prescriber db connection using Azure AD Service Principal authentication
     *              This method supports non-interactive authentication for automated tests and CI/CD pipelines
     * Inputs : none
     * returns: carbon prescriber IDatabase context with Azure AD authentication
     * Author: Baha Sadyrov
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getCarbonPrescriberDBContextWithServicePrincipal() {
        if (this.carbonPrescriberContext == null) {
            MSICredentials creds = new MSICredentials();
            prop.loadCustomProperties("config/rdm/carbonprescriberbe/");
            creds.setTenantId(prop.getProperty("azure_tenant_id"));
            creds.setClientSecret(prop.getProperty("azure_secret_id"));
            creds.setClientId(prop.getProperty("azure_client_id"));
            creds.setDbHost(prop.getProperty("rdm.cpb.db_host"));
            creds.setDbName(prop.getProperty("rdm.cpb.db_name"));
            this.carbonPrescriberContext = new RDBContext(creds);
        }
        return this.carbonPrescriberContext;
    }

    /* *********************************************************************************************************************************************************
     * Method Name - getDataDistributionDBContext()for stage env
     * Description: This method will create an instance of data distribution db connection
     * Inputs : none
     * returns: data distribution IDatabase context
     * Author: Irfa Tabassum
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getDataDistributionDBContext() {
        if (this.dataDistributionContext == null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/rdm/datadistribution/");
            creds.setDriverName(prop.getProperty("rdm.cdd.driver_name"));
            creds.setDbUrl(prop.getProperty("rdm.cdd.db_url"));
            creds.setDbUsername(prop.getProperty("rdm.cdd.db_username"));
            creds.setDbPassword(prop.getProperty("rdm.cdd.db_password"));
            this.dataDistributionContext = new RDBContext(creds);
        }
        return this.dataDistributionContext;
    }

    /* *********************************************************************************************************************************************************
     * Method Name - getMasterDrugDBContext()
     * Description: This method will create an instance of db connection
     * Inputs : none
     * returns: Master Drug IDatabase context
     * Author: Irfa Tabassum
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getMasterDrugDBContext() {
        if (this.masterDrugContext == null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/rdm/itemproduct/");
            creds.setDriverName(prop.getProperty("rdm.ip.driver_name"));
            creds.setDbUrl(prop.getProperty("rdm.mddb.db_url"));
            creds.setDbUsername(prop.getProperty("rdm.ip.db_username"));
            creds.setDbPassword(prop.getProperty("rdm.ip.db_password"));
            this.masterDrugContext = new RDBContext(creds);
        }
        return this.masterDrugContext;
    }

    /* *********************************************************************************************************************************************************
     * Method Name - getWorkOrderDBContext()
     * Description: This method will create an instance of db connection
     * Inputs : none
     * returns: Work Order IDatabase context
     * Author: Irfa Tabassum
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getWorkOrderDBContext() {
        if (this.workOrderContext == null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/rdm/workorder/");
            creds.setDriverName(prop.getProperty("rdm.wo.driver_name"));
            creds.setDbUrl(prop.getProperty("rdm.wo.db_url"));
            creds.setDbUsername(prop.getProperty("rdm.wo.db_username"));
            creds.setDbPassword(prop.getProperty("rdm.wo.db_password"));
            this.workOrderContext = new RDBContext(creds);
        }
        return this.workOrderContext;
    }
    /*

     * *********************************************************************************************************************************************************
     * Method Name - getHwInvAdjmtServiceCosmosContext()for QA env
     * Description: This method will create an instance of HW Inv Adjmt Service db Context
     * Inputs : none
     * returns: cosmos context
     * Author: Mubeen Ahmed Mohammed
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getHwInvAdjmtServiceCosmosContext() {
        if (this.hwInvAdjmtServiceCosmosContext == null) {
            prop.loadCustomProperties("config/inv/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("inv.invAdjmtService.db_host"));
            c.setKey(prop.getProperty("inv.invAdjmtService.db_key"));
            c.setDatabase(prop.getProperty("inv.invAdjmtService.db_name"));
            this.hwInvAdjmtServiceCosmosContext = new CosmosContext(c);
        }
        return this.hwInvAdjmtServiceCosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getHwInvAdjmtServiceCosmosContext()for QA env
     * Description: This method will create an instance of HW Inv Adjmt Service db Context
     * Inputs : none
     * returns: cosmos context
     * Author: Mubeen Ahmed Mohammed
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getHwInvInboundRcvServiceCosmosContext() {
        if (this.hwInvInboundRcvServiceCosmosContext == null) {
            prop.loadCustomProperties("config/inv/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("inv.db_host"));
            c.setKey(prop.getProperty("inv.stage.dbkey"));
            c.setDatabase(prop.getProperty("inv.InboundReceivingDBDetails"));
            this.hwInvInboundRcvServiceCosmosContext = new CosmosContext(c);
        }
        return this.hwInvInboundRcvServiceCosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getItemInvLocationCosmosContext()for QA env
     * Description: This method will create an instance of HW_INV_MGMT Service db Context
     * Inputs : none
     * returns: cosmos context
     * Author: Mubeen Ahmed Mohammed
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getItemInvLocationCosmosContext() {
        if (this.hwInvAdjmtServiceCosmosContext == null) {
            prop.loadCustomProperties("config/inv/itemLocation/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("inv.db_host"));
            c.setKey(prop.getProperty("inv.stage.dbkey"));
            c.setDatabase(prop.getProperty("inv.DataBase"));
            this.hwInvAdjmtServiceCosmosContext = new CosmosContext(c);
        }
        return this.hwInvAdjmtServiceCosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getHwInvCsosServiceCosmosContext()for QA env
     * Description: This method will create an instance of HW INV CSOS Service db Context
     * Inputs : none
     * returns: cosmos context
     * Author: Mubeen Ahmed Mohammed
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getHwInvCsosServiceCosmosContext() {
        if (this.hwInvCsosServiceCosmosContext == null) {
            prop.loadCustomProperties("config/inv/csos/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("inv.Csos.DBHOST"));
            c.setKey(prop.getProperty("inv.stage.dbkey"));
            c.setDatabase(prop.getProperty("inv.Csos.DBNAME"));
            this.hwInvCsosServiceCosmosContext = new CosmosContext(c);
        }
        return this.hwInvCsosServiceCosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getHwInvCycleCountCosmosContext()for QA env
     * Description: This method will create an instance of HW INV Cycle Count Context
     * Inputs : none
     * returns: cosmos context
     * Author: Mubeen Ahmed Mohammed
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getHwInvCycleCountCosmosContext() {
        if (this.hwInvCycleCountCosmosContext == null) {
            prop.loadCustomProperties("config/inv/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("inv.cycleCountAccountEndpoint_stg"));
            c.setKey(prop.getProperty("inv.cycleCountAccountKey_stg"));
            c.setDatabase(prop.getProperty("inv.cycleCountDbName"));
            this.hwInvCycleCountCosmosContext = new CosmosContext(c);
        }
        return this.hwInvCycleCountCosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getControlledSubstanceAuditCosmosContext()for QA env
     * Description: This method will create an instance of HW_INV_CONTROLLED_SUBSTANCE_AUDIT Context
     * Inputs : none
     * returns: cosmos context
     * Author: Mubeen Ahmed Mohammed
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getControlledSubstanceAuditCosmosContext() {
        if (this.hwInvControlledSubstanceAuditCosmosContext == null) {
            prop.loadCustomProperties("config/inv/acsi/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("inv.acsi.DBHOST"));
            c.setKey(prop.getProperty("inv.acsi.dbkey"));
            c.setDatabase(prop.getProperty("inv.acsi.DBNAME"));
            this.hwInvControlledSubstanceAuditCosmosContext = new CosmosContext(c);
        }
        return this.hwInvControlledSubstanceAuditCosmosContext;
    }

    public CosmosContext getVendorReturnCosmosContext(){
        if(this.hwinvVendorReturnCosmosContext == null){
            prop.loadCustomProperties("config/inv/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("inv.vendorReturn.DBHOST_DEV"));
            c.setKey(prop.getProperty("inv.vendorReturn.dbkey_DEV"));
            c.setDatabase(prop.getProperty("inv.vendorReturn.DBNAME_DEV"));
            this.hwinvVendorReturnCosmosContext = new CosmosContext(c);
        }
        return this.hwinvVendorReturnCosmosContext;
    }

    /* *********************************************************************************************************************************************************
     * Method Name - getRxItemDetailsDb()
     * Description: This method will create an instance of RxItem Details Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Vetrivel
     * **********************************************************************************************************************************************************/
    public CosmosContext getRxItemDetailsDb() {
        if (this.rxItemCosmosContext == null) {
            prop.loadCustomProperties("config/inv/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("rxItemDetails.cosmos_db_host"));
            c.setKey(prop.getProperty("rxItemDetails.cosmos_db_key"));
            c.setDatabase(prop.getProperty("rxItemDetails.cosmos_db_name"));
            this.rxItemCosmosContext = new CosmosContext(c);
        }
        return this.rxItemCosmosContext;
    }
    /*******************************************************
     * Overload to get RxItem Details Cosmos DB context for a specific environment.
     * If env is "prod" (case-insensitive), connect using readonly cosmos host/key.
     * Otherwise defaults to existing behavior.
     *******************************************************/
    public CosmosContext getRxItemDetailsDb(String env) {
        if (env != null && "prod".equalsIgnoreCase(env.trim())) {
            if (this.rxItemCosmosContextProd == null) {
                prop.loadCustomProperties("config/inv/");
                CosmosCredentials c = new CosmosCredentials();
                c.setHost(prop.getProperty("inv.readonlycosmoshost"));
                c.setKey(prop.getProperty("inv.readonlycosmoskey"));
                c.setDatabase(prop.getProperty("rxItemDetails.cosmos_db_name"));
                this.rxItemCosmosContextProd = new CosmosContext(c);
            }
            return this.rxItemCosmosContextProd;
        }
        return getRxItemDetailsDb();
    }

    /* *********************************************************************************************************************************************************
     * Method Name - getPharmacyInventoryDBContext()
     * Description: This method will create an instance of connecting to RXP pharmacy inventory data base
     * Inputs : none
     * returns: picontrolContext
     * Author: Vetrivel
     * **********************************************************************************************************************************************************/

    public IDatabaseContext getPharmacyInventoryDBContext(String server) {
        if (this.picontrolContext == null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/inv/smartElimination/");
            creds.setDriverName(prop.getProperty("db_SqlServerDriverName"));
            creds.setDbUrl(prop.getProperty("db_url" + server));
            creds.setDbUsername(prop.getProperty("db_userName"));
            creds.setDbPassword(prop.getProperty("cnx.db_password"));
            this.picontrolContext = new RDBContext(creds);
        }
        return this.picontrolContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getDPAccountDBContext()for dev, qa, stg env
     * Description: This method will create an instance of DP account entity connection
     * Inputs : none
     * returns: DPAccountDB IDatabase context
     * Author: Chinmay Joshi
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getDPAccountDBContext() {
        if (this.accountDbContext == null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/sharedconfigproperties/");
            creds.setDriverName(prop.getProperty("dp.account.entity.account.driver_name"));
            creds.setDbUrl(prop.getProperty("dp.account.entity.account.db_url"));
            creds.setDbUsername(prop.getProperty("dp.account.entity.account.db_username"));
            creds.setDbPassword(prop.getProperty("dp.account.entity.account.db_password"));
            this.accountDbContext = new RDBContext(creds);
        }
        return this.accountDbContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getDPAccountSchedulerDBContext()for dev, qa, stg env
     * Description: This method will create an instance of DP account entity connection
     * Inputs : none
     * returns: SchedulerDB IDatabase context
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getDPAccountSchedulerDBContext() {
        if (this.accountDpDbSchedulerContext == null) {
            DBCredentials creds = new DBCredentials();
            prop.loadCustomProperties("config/sharedconfigproperties/");
            creds.setDriverName(prop.getProperty("dp.account.entity.account.driver_name"));
            creds.setDbUrl(prop.getProperty("dp.account.entity.scheduler.db_url"));
            creds.setDbUsername(prop.getProperty("dp.account.entity.account.db_username"));
            creds.setDbPassword(prop.getProperty("dp.account.entity.account.db_password"));
            this.accountDpDbSchedulerContext = new RDBContext(creds);
        }
        return this.accountDpDbSchedulerContext;
    }




    /* *********************************************************************************************************************************************************
     * Method Name - getFillInvAdjmt()
     * Description: This method will create an instance of RxItem Details Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Vetrivel
     * **********************************************************************************************************************************************************/
    public CosmosContext getFillInvAdjmt() {
        if (this.fillInvAdjmtCosmosContext == null) {
            prop.loadCustomProperties("config/inv/smartElimination/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("srxPIPreprocess.cosmos_db_host"));
            c.setKey(prop.getProperty("srxPIPreprocess.cosmos_db_key"));
            c.setDatabase(prop.getProperty("srxPIPreprocess.cosmos_db_name"));
            this.fillInvAdjmtCosmosContext = new CosmosContext(c);
        }
        return this.fillInvAdjmtCosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getCustomerPqcfCosmosContext()
     * Description: This method will create an instance of CustomerPQCF Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Fnu Shobhit
     * *********************************************************************************************************************************************************
     */

    public CosmosContext getCustomerPqcfCosmosContext() {
        if (this.CustomerPqcfCosmosContext == null) {
            prop.loadCustomProperties("config/cs/orchestration/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("cs.CustomerPqcf.cosmos.host"));
            c.setKey(prop.getProperty("cs.CustomerPqcf.cosmos.key"));
            c.setDatabase(prop.getProperty("cs.CustomerPqcf.cosmos.db"));
            this.CustomerPqcfCosmosContext = new CosmosContext(c);
        }

        return this.CustomerPqcfCosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getByPreAuthCosmosContext()
     * Description: This method will create an instance of PreAuth Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Fnu Shobhit
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getByPreAuthCosmosContext() {
        if (this.ByPreAuthCosmosContext == null) {
            prop.loadCustomProperties("config/cs/orchestration/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("cs.ByPreAuth.cosmos.host"));
            c.setKey(prop.getProperty("cs.ByPreAuth.cosmos.key"));
            c.setDatabase(prop.getProperty("cs.ByPreAuth.cosmos.db"));
            this.ByPreAuthCosmosContext = new CosmosContext(c);
        }

        return this.ByPreAuthCosmosContext;
    }


    /*
       MethodName -- getOrchestratorCosmosContext
       Description: This method will create an instance of Orchestrator Cosmosdb context
       Returns: CosmosContext
       Author -- Hariharan RP
    */
    public CosmosContext getOrchestratorCosmosContext() {
        if (this.OrchestratorCosmosContext == null) {
            PropertyReader prop = PropertyReader.getInstance();
            //prop.loadCustomProperties("config/cs/SchedulingOrchestrator/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("cs.stg_cosmos.host"));
            c.setKey(prop.getProperty("cs.stg_cosmos.key"));
            c.setDatabase(prop.getProperty("cs.Resolution.cosmos.db"));
            this.OrchestratorCosmosContext = new CosmosContext(c);
        }

        return this.OrchestratorCosmosContext;
    }


    /*
     * *********************************************************************************************************************************************************
     * Method Name - getEnterpriseAdjustmentDetailsContext() for QA env
     * Inputs : none
     * returns: Request that is being send down to Enterprise Inventory
     * Author: Mubeen Ahmed Mohammed
     * *********************************************************************************************************************************************************
     */

    public RDBContext getEnterpriseAdjustmentDetailsContext() {
        if (this.orderInsiteMakeDb == null) {
            prop.loadCustomProperties("config/inv/pharmacyOrdering/");
            DBCredentials dbCredentials = new DBCredentials();
            dbCredentials.setDriverName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            dbCredentials.setDbUrl(prop.getProperty("orderInsites.db_connectionstring"));
            dbCredentials.setDbUsername(prop.getProperty("hwqesqldb_user"));
            dbCredentials.setDbPassword(prop.getProperty("hwqesqldb_pwd"));
            this.orderInsiteMakeDb = new RDBContext(dbCredentials);
        }
        return this.orderInsiteMakeDb;
    }

    /*
     * Method Name - getGcpDatabaseDetailsContext() for Stg Environment
     * Inputs : none
     * Return: Request that is  being Send down to GCP
     * Author: Mubeen Ahmed Mohammed (@M0M0OJC)
     */
    public RDBContext getGcpDatabaseDetailsContext(){
        if(this.averageCostProcessContext == null){
            prop.loadCustomProperties("config/inv/");
            DBCredentials dbCredentials = new DBCredentials();
            dbCredentials.setDriverName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            dbCredentials.setDbUrl(prop.getProperty("acp.db_connectionstring"));
            dbCredentials.setDbUsername(prop.getProperty("acp.databaseUserName"));
            dbCredentials.setDbPassword(prop.getProperty("acp.db_password"));
            this.averageCostProcessContext = new RDBContext(dbCredentials);
        }
        return this.averageCostProcessContext;
    }


    /**
     * Method Name - getTestGPHDatabaseDetailsContext for Stg Environment
     * @Author: Mubeen Ahmed Mohammed
     */
    public RDBContext getTestGPHDatabaseDetailsContext(){
        if(this.testGphDb == null){
            prop.loadCustomProperties("config/inv/");
            DBCredentials dbCredentials = new DBCredentials();
            dbCredentials.setDriverName("com.informix.jdbc.IfxDriver");
            dbCredentials.setDbUrl(prop.getProperty("testGph.db_connectionstring"));
            dbCredentials.setDbUsername(prop.getProperty("testGph.db_username"));
            dbCredentials.setDbPassword(prop.getProperty("testGph.db_password"));
            this.testGphDb = new RDBContext(dbCredentials);
        }
        return this.testGphDb;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getEnrollmentCosmosContext
     * Inputs : none
     * returns: Returns Enrollment DB Cosmos Context
     * Author: Venkata Dara
     * *********************************************************************************************************************************************************
     */

    public CosmosContext getEnrollmentCosmosContext() {
        return Optional.ofNullable(enrollmentCosmosContext).orElseGet(() -> {
            CosmosCredentials cosmosCredentials = new CosmosCredentials();
            cosmosCredentials.setHost(prop.getProperty("tmm.enrollment.cosmos.host"));
            cosmosCredentials.setKey(prop.getProperty("tmm.enrollment.cosmos.key"));
            cosmosCredentials.setDatabase(prop.getProperty("tmm.enrollment.cosmos.databaseName"));
            enrollmentCosmosContext = new CosmosContext(cosmosCredentials);
            return enrollmentCosmosContext;
        });
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getServiceSettingsCosmosContext
     * Inputs : none
     * returns: Returns Service Settings DB Cosmos Context
     * Author: Nikita Snell
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getServiceSettingsCosmosContext() {
        if (this.serviceSettingsContext == null) {
            prop.loadCustomProperties("config/cs/orchestration/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("cs.servicsSettings.cosmos.host"));
            c.setKey(prop.getProperty("cs.servicsSettings.cosmos.key"));
            c.setDatabase(prop.getProperty("cs.servicsSettings.cosmos.db"));
            this.serviceSettingsContext = new CosmosContext(c);
        }

        return this.serviceSettingsContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getCustomerPQCFCosmosContext
     * Inputs : none
     * returns: Returns Customer-PQCF DB Cosmos Context
     * Author: Nikita Snell
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getCustomerPQCFCosmosContext() {
        if (this.customerPQCFContext == null) {
            prop.loadCustomProperties("config/cs/orchestration/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("cs.customerPQCF.cosmos.host"));
            c.setKey(prop.getProperty("cs.customerPQCF.cosmos.key"));
            c.setDatabase(prop.getProperty("cs.customerPQCF.cosmos.db"));
            this.customerPQCFContext = new CosmosContext(c);
        }
        return this.customerPQCFContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getServiceReportingSTCReportContext
     * Inputs : none
     * returns: Returns Service-Reporting STCReport Context
     * Author: Nikita Snell
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getServiceReportingSTCReportContext() {
        if (this.serviceReportingContext == null) {
            prop.loadCustomProperties("config/cs/orchestration/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("cs.stg_cosmos.host"));
            c.setKey(prop.getProperty("cs.stg_cosmos.key"));
            c.setDatabase(prop.getProperty("cs.serviceReporting.cosmos.db"));
            this.serviceReportingContext = new CosmosContext(c);
        }
        return this.serviceReportingContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - walkInOrchestrator
     * Inputs : none
     * returns: Returns walkInOrchestrator service-details Context
     * Author: Nikita Snell
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getWalkInOrchestrator() {
        if (this.walkInOrchestrator == null) {
            prop.loadCustomProperties("config/cs/orchestration/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("cs.walkInOrchestrator.cosmos.host"));
            c.setKey(prop.getProperty("cs.walkInOrchestrator.cosmos.key"));
            c.setDatabase(prop.getProperty("cs.walkInOrchestrator.cosmos.db"));
            this.walkInOrchestrator = new CosmosContext(c);
        }
        return this.walkInOrchestrator;
    }

    /*
     * *****************************************************************************************************************
     * Method Name - getIMZDropOff()
     * Description: This method initializes the driver & launches IMZ Drop-Off website
     * Inputs : none
     * returns: IWebSite
     * Author: Nikita Snell
     * *****************************************************************************************************************
     */
    public IWebSite getIMZDropOff() {
        if (this.dpWebsite == null) {
            this.dpWebsite = new WebSiteManager();
            this.dpWebsite.launchWebsite(prop.getProperty("web.imzDropOff_url"), BrowserType.valueOf(prop.getProperty("web.cs_browser")));
        }
        return this.dpWebsite;
    }


    /*
     * *****************************************************************************************************************
     * Method Name - getServiceActivityCosmosContext()
     * Inputs : none
     * returns: Returns ServiceActivity DB details
     * Author: Ashok
     * *****************************************************************************************************************
     */
    public CosmosContext getServiceActivityCosmosContext() {
        if (this.ServiceActivityCosmosContext == null) {
            PropertyReader prop = PropertyReader.getInstance();
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("cs.stg_cosmos.host"));
            c.setKey(prop.getProperty("cs.stg_cosmos.key"));
            c.setDatabase(prop.getProperty("cs.ServiceActivity.cosmos.db"));
            this.ServiceActivityCosmosContext = new CosmosContext(c);
        }

        return this.ServiceActivityCosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getOrtfCosmosContext
     * Inputs : none
     * returns: Returns Enrollment DB Cosmos Context
     * Author: Bhargav Anugu
     * *********************************************************************************************************************************************************
     */

    public CosmosContext getOrtfCosmosContext() {
        return Optional.ofNullable(ortfCosmosContext).orElseGet(() -> {
            CosmosCredentials cosmosCredentials = new CosmosCredentials();
            cosmosCredentials.setHost(prop.getProperty("ortf.cosmos.host"));
            cosmosCredentials.setKey(prop.getProperty("ortf.cosmos.key"));
            cosmosCredentials.setDatabase(prop.getProperty("ortf.cosmos.databaseName"));
            ortfCosmosContext = new CosmosContext(cosmosCredentials);
            return ortfCosmosContext;
        });
    }

    public CosmosContext geStoreSyncerCosmosContext() {
        return Optional.ofNullable(cloudToStoreSyncCosmosContext).orElseGet(() -> {
            CosmosCredentials cosmosCredentials = new CosmosCredentials();
            cosmosCredentials.setHost(prop.getProperty("ortf.cosmos.syncer.host"));
            cosmosCredentials.setKey(prop.getProperty("ortf.cosmos.syncer.key"));
            cosmosCredentials.setDatabase(prop.getProperty("ortf.cosmos.syncer.databaseName"));
            cloudToStoreSyncCosmosContext = new CosmosContext(cosmosCredentials);
            return cloudToStoreSyncCosmosContext;
        });
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRxAndFillCosmosContext
     * Inputs : none
     * returns: Returns Enrollment DB Cosmos Context
     * Author: Bhargav Anugu
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getRxAndFillCosmosContext() {
        return Optional.ofNullable(rxAndFillCosmosContext).orElseGet(() -> {
            CosmosCredentials cosmosCredentials = new CosmosCredentials();
            cosmosCredentials.setHost(prop.getProperty("ortf.cosmos.host"));
            cosmosCredentials.setKey(prop.getProperty("ortf.cosmos.key"));
            cosmosCredentials.setDatabase(prop.getProperty("ortf.cosmos.databaseName"));
            rxAndFillCosmosContext = new CosmosContext(cosmosCredentials);
            return rxAndFillCosmosContext;
        });
    }

    /* *********************************************************************************************************************************************************
     * Method Name - getOrderReturnsDb()
     * Description: This method will create an instance of OrderReturns Details Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Srikanth
     * **********************************************************************************************************************************************************/
    public CosmosContext getOrderReturnsDb() {
        if (this.orderReturnsCosmosContext == null) {
            prop.loadCustomProperties("config/inv/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("orderReturns.cosmos_db_host"));
            c.setKey(prop.getProperty("orderReturns.cosmos_db_key"));
            c.setDatabase(prop.getProperty("orderReturns.cosmos_db_name"));
            this.orderReturnsCosmosContext = new CosmosContext(c);
        }
        return this.orderReturnsCosmosContext;
    }

    public RDBContext getPrmNumberingSqlDbContext() {
        if (prmNumberingSqlDbContext == null) {
            SqlAdCredentials credentials = new SqlAdCredentials();
            credentials.setServerName(prop.getProperty("prm.rxNumberingService.sql.serverName"));
            credentials.setDatabaseName(prop.getProperty("prm.rxNumberingService.sql.databaseName"));
            credentials.setUserName(prop.getProperty("prm.rxNumberingService.sql.userName"));
            credentials.setPassword(prop.getProperty("prm.rxNumberingService.sql.key"));
            credentials.setAuthentication(prop.getProperty("prm.rxNumberingService.sql.authentication"));
            credentials.setPort(Integer.parseInt(prop.getProperty("prm.rxNumberingService.sql.portNumber")));
            credentials.setTrustServerCertificate(Boolean.parseBoolean(prop.getProperty("prm.rxNumberingService.sql.trustServerCertificate")));
            credentials.setHostNameInCertificate(prop.getProperty("prm.rxNumberingService.sql.hostNameInCertificate"));
            credentials.setEncrypt(Boolean.parseBoolean(prop.getProperty("prm.rxNumberingService.sql.encrypt")));
            return this.prmNumberingSqlDbContext = new RDBContext(credentials);
        }

        return prmNumberingSqlDbContext;
    }

    public RDBContext getRoutingServiceSqlDbContext() {
        if (routingServiceSqlDbContext == null) {
            SqlAdCredentials credentials = new SqlAdCredentials();
            credentials.setServerName(prop.getProperty("prm.routingService.sql.serverName"));
            credentials.setDatabaseName(prop.getProperty("prm.routingService.sql.databaseName"));
            credentials.setUserName(prop.getProperty("prm.routingService.sql.userName"));
            credentials.setPassword(prop.getProperty("prm.routingService.sql.key"));
            credentials.setAuthentication(prop.getProperty("prm.routingService.sql.authentication"));
            credentials.setPort(Integer.parseInt(prop.getProperty("prm.routingService.sql.portNumber")));
            credentials.setTrustServerCertificate(Boolean.parseBoolean(prop.getProperty("prm.routingService.sql.trustServerCertificate")));
            credentials.setHostNameInCertificate(prop.getProperty("prm.routingService.sql.hostNameInCertificate"));
            credentials.setEncrypt(Boolean.parseBoolean(prop.getProperty("prm.routingService.sql.encrypt")));
            return this.routingServiceSqlDbContext = new RDBContext(credentials);
        }
        return routingServiceSqlDbContext;
    }

    /* *********************************************************************************************************************************************************
     * Method Name - getOrderReturnsDb()
     * Description: This method will create an instance of OrderReturns Details Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Srikanth
     * **********************************************************************************************************************************************************/
    public CosmosContext getInboundReceivingCosmosContext() {
        if (this.inboundReceivingCosmosContext == null) {
            prop.loadCustomProperties("config/inv/smartElimination/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("inboundReceiving.cosmos_db_host"));
            c.setKey(prop.getProperty("inboundReceiving.cosmos_db_key"));
            c.setDatabase(prop.getProperty("inboundReceiving.cosmos_db_name"));
            this.inboundReceivingCosmosContext = new CosmosContext(c);
        }
        return this.inboundReceivingCosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getSTSCosmos()
     * Description: This method will connect to  STS-Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Ramprasad Pola/r0p0a5s
     * *********************************************************************************************************************************************************
     */

    public CosmosContext getSTSCosmos() {
        if (this.stsCosmosContext == null) {
            prop.loadCustomProperties("config/prm/stsTransfer/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("prm.stsTransfer.host"));
            c.setKey(prop.getProperty("prm.stsTransfer.key"));
            c.setDatabase(prop.getProperty("prm.stsTransfer.db"));
            this.stsCosmosContext = new CosmosContext(c);
        }
        return this.stsCosmosContext;
    }
    /* *********************************************************************************************************************************************************
     * Method Name - getrxIddeatilsDb()
     * Description: This method will create an instance of Rxid Details Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Bargavi
     * **********************************************************************************************************************************************************/
    public CosmosContext getrxIddeatilsDb() {
        if (this.rxIdSearchCosmosContext == null) {
            prop.loadCustomProperties("config/prm/prmgrodd");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("prmgrodd.cosmosDB.host"));
            c.setKey(prop.getProperty("prmgrodd.cosmosDB.key"));
            c.setDatabase(prop.getProperty("prmgrodd.cosmosDB.name"));
            this.rxIdSearchCosmosContext = new CosmosContext(c);
        }
        return this.rxIdSearchCosmosContext;
    }

    public CosmosContext getVerifyRxCosmos() {
        if (this.verifyRxCosmosContext == null) {
            prop.loadCustomProperties("config/prm/verifyRx/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("prm.verifyRx.host"));
            c.setKey(prop.getProperty("prm.verifyRx.key"));
            c.setDatabase(prop.getProperty("prm.verifyRx.db"));
            this.verifyRxCosmosContext = new CosmosContext(c);
        }
        return this.verifyRxCosmosContext;
    }


    /**
     * @return Creates DP order cosmos.
     */
    public CosmosContext getDpOrderCosmos() {
        if (this.dpOrderCosmos == null) {
            prop.loadCustomProperties("config/sharedconfigproperties/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("dpOrderCosmos.db_host"));
            c.setKey(prop.getProperty("dpOrderCosmos.db_key"));
            c.setDatabase(prop.getProperty("dpOrderCosmos.db_database"));
            this.dpOrderCosmos = new CosmosContext(c);
        }
        return this.dpOrderCosmos;
    }


    public CosmosContext getServiceSettingsState() {
        if (this.serviceSettingsState == null) {
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("cs.ServiceSettingState.cosmos.host"));
            c.setKey(prop.getProperty("cs.ServiceSettingState.cosmos.key"));
            c.setDatabase(prop.getProperty("cs.ServiceSettingState.cosmos.db"));
            this.serviceSettingsState = new CosmosContext(c);
        }

        return this.serviceSettingsState;
    }
    /*
     * *****************************************************************************************************************
     * Method Name - getCSPLoginPage()
     * Description: This method initializes the driver & launches Super Mario Drop-Off UI website
     * Inputs : none
     * returns: IWebSite
     * Author: Flora Shijirjargal
     * *****************************************************************************************************************
     */
    public IWebSite getCSP() {
        if (this.smDropOffWebsite == null) {
            this.smDropOffWebsite = new WebSiteManager();
            this.smDropOffWebsite.launchWebsite(prop.getProperty("sm.dropOff.baseUrl"), BrowserType.valueOf(prop.getProperty("sm.dropOff.browser")));
        }
        return this.smDropOffWebsite;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getCFCosmosDbSTG()
     * Description: This method will create an instance of CF Cosmos Filling db context for STG env
     * Inputs : none
     * returns: CosmosContext
     * Author: Abdul Shajahan Shaik
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getCFCosmosDbSTG() {
        if (this.fomFillingContext == null) {
            prop.loadCustomProperties("config/ccf/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("cf.cosmos.account.STG.db_host"));
            c.setKey(prop.getProperty("cf.cosmos.subscription.STG.db_key"));
            c.setDatabase(prop.getProperty("cf.centralFill.db_name"));
            this.fomFillingContext = new CosmosContext(c);
        }
        return this.fomFillingContext;
    }
    /*
     * *********************************************************************************************************************************************************
     * Method Name - getCFCosmosDbQA()
     * Description: This method will create an instance of CF Cosmos Filling db context for QA env
     * Inputs : none
     * returns: CosmosContext
     * Author: Oleksandr Shibli
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getCFCosmosDbQA() {
        if (this.fomFillingContextQA == null) {
            prop.loadCustomProperties("config/ccf/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("cf.cosmos.account.QA.db_host"));
            c.setKey(prop.getProperty("cf.cosmos.subscription.QA.db_key"));
            c.setDatabase(prop.getProperty("cf.centralFill.db_name"));
            this.fomFillingContextQA = new CosmosContext(c);
        }
        return this.fomFillingContextQA;
    }

/*
 * *********************************************************************************************************************************************************
 * Method Name - getCFCosmosDbReceivingQa()
 * Description: This method will create an instance of CF Cosmos Filling db context
 * Inputs : none
 * returns: CosmosContext
 * Author: Oleksandr Shibli
 * *********************************************************************************************************************************************************
 */
public CosmosContext getCFCosmosDbCfReceivingQa() {
    if (this.CFreceivingcosmos == null) {
        prop.loadCustomProperties("config/ccf/");
        CosmosCredentials c = new CosmosCredentials();
        c.setHost(prop.getProperty("cf.cosmos.account.QA.db_host"));
        c.setKey(prop.getProperty("cf.cosmos.subscription.QA.db_key"));
        c.setDatabase(prop.getProperty("cf.hw_cf_receiving"));
        this.CFreceivingcosmos = new CosmosContext(c);
    }
    return this.CFreceivingcosmos;
}

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getCFCosmosDbReceivingStg()
     * Description: This method will create an instance of CF Cosmos Filling db context
     * Inputs : none
     * returns: CosmosContext
     * Author: Oleksandr Shibli
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getCFCosmosDbCfReceivingStg() {
        if (this.CFreceivingcosmos == null) {
            prop.loadCustomProperties("config/ccf/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("cf.cosmos.account.STG.db_host"));
            c.setKey(prop.getProperty("cf.cosmos.subscription.STG.db_key"));
            c.setDatabase(prop.getProperty("cf.hw_cf_receiving"));
            this.CFreceivingcosmos = new CosmosContext(c);
        }
        return this.CFreceivingcosmos;
    }

    /*
     * *****************************************************************************************************************
     * Method Name - getGSPUI()
     * Description: This method initializes the driver & launches Sonic UI website
     * Inputs : none
     * returns: IWebSite
     * Author: Flora Shijirjargal
     * *****************************************************************************************************************
     */
    public IWebSite getGSPUI() {
        if (this.sonicUIWebsite == null) {
            this.sonicUIWebsite = new WebSiteManager();
            this.sonicUIWebsite.launchWebsite(prop.getProperty("sonic.ui.baseUrl"), BrowserType.valueOf(prop.getProperty("sonic.ui.browser")));
        }
        return this.sonicUIWebsite;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getCurbsideApp()
     * Description: This method create a new session of Curbside mobile app or reattaches a Curbside mobile app session if already exists
     * Inputs : none
     * returns: IMobileApp
     * Author: Neeharika Verma
     * *********************************************************************************************************************************************************
     */
    public IAndroidApp getCurbsideApp() throws MalformedURLException {
        if (this.curbsidemobileapp == null || this.curbsidemobileapp.getDriver() == null) {
            this.curbsidemobileapp = new CurbsideManager();
            this.curbsidemobileapp.launchMobileApp();
        }
        return this.curbsidemobileapp;
    }
    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRxOneHCCycleCountsAppManager()
     * Description: This method create a new session of rxone cycle counts mobile app or reattaches a rxone mobile app session if already exists
     * Inputs : none
     * returns: rxOneHCCycleCountsAppManager
     * Author: Deepti Gupta
     * *********************************************************************************************************************************************************
     */
    public IAndroidApp getRxOneHCCycleCountsAppManager() {
        if (this.rxOneHCCycleCountsAppManager == null || this.rxOneHCCycleCountsAppManager.getDriver() == null) {
            this.rxOneHCCycleCountsAppManager = new RxOneHCCycleCountsAppManager();
            this.rxOneHCCycleCountsAppManager.launchMobileApp();
        }
        return rxOneHCCycleCountsAppManager;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRxOneHCRTSAppManager()
     * Description: This method create a new session of rxone RTS mobile app or reattaches a rxone mobile app session if already exists
     * Inputs : none
     * returns: rxOneHCRTSAppManager
     * Author: Deepti Gupta
     * *********************************************************************************************************************************************************
     */
    public IAndroidApp getRxOneHCRTSAppManager() {
        if (this.rxOneHCRTSAppManager == null || this.rxOneHCRTSAppManager.getDriver() == null) {
            this.rxOneHCRTSAppManager = new RxOneHCRTSAppManager();
            this.rxOneHCRTSAppManager.launchMobileApp();
        }
        return rxOneHCRTSAppManager;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRxOneHCACSIAppManager()
     * Description: This method create a new session of rxone ACSI mobile app or reattaches a rxone mobile app session if already exists
     * Inputs : none
     * returns: rxOneHCACSIAppManager
     * Author: Deepti Gupta
     * *********************************************************************************************************************************************************
     */
    public IAndroidApp getRxOneHCACSIAppManager() {
        if (this.rxOneHCACSIAppManager == null || this.rxOneHCACSIAppManager.getDriver() == null) {
            this.rxOneHCACSIAppManager = new RxOneHCACSIAppManager();
            this.rxOneHCACSIAppManager.launchMobileApp();
        }
        return rxOneHCACSIAppManager;
    }
    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRxOneHCAmberVialAppManager()
     * Description: This method create a new session of rxone AmberVial mobile app or reattaches a rxone mobile app session if already exists
     * Inputs : none
     * returns: rxOneHCACSIAppManager
     * Author: Deepti Gupta
     * *********************************************************************************************************************************************************
     */
    public IAndroidApp getRxOneHCAmberVialAppManager() {
        if (rxOneHCAmberVialAppManager == null || rxOneHCAmberVialAppManager.getDriver() == null) {
            rxOneHCAmberVialAppManager = new RxOneHCAmberVialAppManager();
            rxOneHCAmberVialAppManager.launchMobileApp();
        }
        return rxOneHCAmberVialAppManager;
    }
    /*
     * *****************************************************************************************************************
     * Method Name - getCSStrandCosmosDb()
     * Description: This method will initialize connection to Expanded Service CosmosDB context
     * Inputs : none
     * returns: CosmosContext
     * Author: Flora Shijirjargal
     * *****************************************************************************************************************
     */
    public CosmosContext getCSStrandCosmosDb() {
        if (this.strandDB == null) {
            CosmosCredentials c = new CosmosCredentials();
            prop.loadCustomProperties("config/cs/SuperMario/");
            c.setHost(prop.getProperty("sm.cosmos.host"));
            c.setKey(prop.getProperty("sm.cosmos.key"));
            c.setDatabase(prop.getProperty("sm.cosmos.db"));
            this.strandDB = new CosmosContext(c);
        }

        return this.strandDB;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getOptFulfillDb()
     * Description: This method will create an instance of Optical Fulfillment Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Renuka Allada
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getOptEcomDb() {
        if (this.optEcomContext == null) {
            prop.loadCustomProperties("config/optical/ecom/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("opt_ecom.db_host_name"));
            c.setKey(prop.getProperty("opt_ecom.db_key"));
            c.setDatabase(prop.getProperty("opt_ecom.db_name"));
            this.optEcomContext = new CosmosContext(c);
        }
        return this.optEcomContext;
    }

    public CosmosContext getOptFulfillDb() {
        if (this.optFulfillContext == null) {
            prop.loadCustomProperties("config/optical/fulfillment/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("opt_fulfill.db_host_name"));
            c.setKey(prop.getProperty("opt_fulfill.db_key"));
            c.setDatabase(prop.getProperty("opt_fulfill.db_name"));
            this.optFulfillContext = new CosmosContext(c);
        }
        return this.optFulfillContext;
    }

    /*
     * *****************************************************************************************************************
     * Method Name - getVisitNumDB()
     * Description: This method will initialize connection to Strand unique-id-generator CosmosDB context
     * Inputs : none
     * returns: CosmosContext
     * Author: Flora Shijirjargal
     * *****************************************************************************************************************
     */
    public CosmosContext getVisitNumDB() {
        if (this.uniqueIdDB == null) {
            prop.loadCustomProperties("config/cs/SuperMario/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("sm.uniqueId.host"));
            c.setKey(prop.getProperty("sm.uniqueId.db.key"));
            c.setDatabase(prop.getProperty("sm.uniqueId.db"));
            this.uniqueIdDB = new CosmosContext(c);
        }

        return this.uniqueIdDB;
    }


    /*
     * *********************************************************************************************************************************************************^M
     * Method Name - uniqueFirstName() ,uniqueLastName^M
     * Description: This method to get unique First Name, Last name^M
     * returns: These Method returns unique First Name, Last name to create patient.^M
     * Author: Manoj Sarode^M
     * *********************************************************************************************************************************************************^M
     */
    public static String uniqueFirstName() {
        Faker objFaker = new Faker();
        String strFirstName = objFaker.name().firstName();
        return strFirstName;
    }

    public static String uniqueLastName() {
        Faker objFaker = new Faker();
        String strLastName = objFaker.name().lastName();
        return strLastName;
    }
    /*
     * *****************************************************************************************************************
     * Method Name - getRxPDCosmosDb()
     * Description: This method will initialize connection to Expanded Service CosmosDB context
     * Inputs : none
     * returns: CosmosContext
     * Author: Narayana swamy
     * *****************************************************************************************************************
     */
    public CosmosContext getRxPDEcomCosmosDb() {
        if (this.ecomDB == null) {
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("rxpd.hops.stg.cosmos.host"));
            c.setKey(prop.getProperty("rxpd.hops.stg.cosmos.key"));
            c.setDatabase(prop.getProperty("rxpd.hops.stg.cosmos.db"));
            this.ecomDB = new CosmosContext(c);
        }

        return this.ecomDB;
    }
    /*
     * *****************************************************************************************************************
     * Method Name - getEsPatientCosmosDb()
     * Description: This method will initialize connection to Expanded Service Es Patient CosmosDB context
     * Inputs : none
     * returns: CosmosContext
     * Author: Flora Shijirjargal
     * *****************************************************************************************************************
     */
    public CosmosContext getEsPatientCosmosDb() {
        if (this.esPatientDB == null) {
            prop.loadCustomProperties("config/cs/SuperMario/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("sm.cosmos.host"));
            c.setKey(prop.getProperty("sm.cosmos.key"));
            c.setDatabase(prop.getProperty("sm.es.cosmos.db"));
            this.esPatientDB = new CosmosContext(c);
        }


        return this.esPatientDB;
    }
    /*
     * *****************************************************************************************************************
     * Method Name - getDotcomTnT()
     * Description: This method initializes the driver & launches Doctom Test and treatment visit scheduling website
     * Inputs : none
     * returns: IWebSite
     * Author: Flora Shijirjargal
     * *****************************************************************************************************************
     */
    public IWebSite getDotcomTnT() {
        if (this.smDropOffWebsite == null) {
            this.smDropOffWebsite = new WebSiteManager();
            this.smDropOffWebsite.launchWebsite(prop.getProperty("sm.dotcomTnT.baseUrl"), BrowserType.valueOf(prop.getProperty("sm.dropOff.browser")));
        }
        return this.smDropOffWebsite;
    }
    /*
     * *****************************************************************************************************************
     * Method Name - getDotcomHC()
     * Description: This method initializes the driver & launches Doctom Hormonal Contraceptive visit scheduling website
     * Inputs : none
     * returns: IWebSite
     * Author: Flora Shijirjargal
     * *****************************************************************************************************************
     */
    public IWebSite getDotcomHC() {
        if (this.smDropOffWebsite == null) {
            this.smDropOffWebsite = new WebSiteManager();
            this.smDropOffWebsite.launchWebsite(prop.getProperty("sm.dotcomHC.baseUrl"), BrowserType.valueOf(prop.getProperty("sm.dropOff.browser")));
        }
        return this.smDropOffWebsite;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRxPDHopsEcomDB()
     * Description: This method will create an instance of RxPD Hops Ecom Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Sanjay Balakrishna
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getRxPDHopsEcomDB() {
        if (this.rxpdhopsecomDB == null) {
            prop.loadCustomProperties("config/rxpdposttransaction/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("rxpd.hops.stg.cosmos.host"));
            c.setKey(prop.getProperty("rxpd.hops.stg.cosmos.key"));
            c.setDatabase(prop.getProperty("rxpd.hops.stg.cosmos.db"));
            this.rxpdhopsecomDB = new CosmosContext(c);
        }
        return this.rxpdhopsecomDB;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRxOneHCRxPDAppManager()
     * Description: This method create a new session of rxone RxPD mobile app or reattaches a rxone mobile app session if already exists
     * Inputs : none
     * returns: rxOneHCRxPDAppManager
     * Author: Deepti Gupta
     * *********************************************************************************************************************************************************
     */
    public IAndroidApp getRxOneHCRxPDAppManager() {
        if (this.rxOneHCRxPDAppManager == null || this.rxOneHCRxPDAppManager.getDriver() == null) {
            this.rxOneHCRxPDAppManager = new RxOneHCRxPDAppManager();
            this.rxOneHCRxPDAppManager.launchMobileApp();
        }
        return rxOneHCRxPDAppManager;
    }


    public CosmosContext getPPIDb() {
        if (this.ppiCosmosContext == null) {
            prop.loadCustomProperties(PPIConstants.PPI_CONFIG_PATH);
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty(PPIConstants.PPI_COSMOS_URL));
            c.setKey(prop.getProperty(PPIConstants.PPI_COSMOS_KEY));
            c.setDatabase(prop.getProperty(PPIConstants.PPI_COSMOS_DATABASE_NAME));
            this.ppiCosmosContext = new CosmosContext(c);
        }
        return this.ppiCosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getWHSEDb2Context()
     * Description: This method will perform database operations on WHSE DB2 database
     * returns: IDatabaseContext
     * Author: Sonu Sangwan
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getWHSEDb2Context() {
        if (this.whseDb2Context == null) {
            DB2Credentials creds = new DB2Credentials();
            creds.setServerName(prop.getProperty("rdm.whse.serverName"));
            creds.setPortNumber(Integer.parseInt(prop.getProperty("rdm.whse.portNumber")));
            creds.setDatabaseName(prop.getProperty("rdm.whse.databaseName"));
            creds.setTrustStore(prop.getProperty("rdm.whse.trustStore"));
            creds.setKeyStore(prop.getProperty("rdm.whse.keyStore"));
            creds.setKeyStorePassword(prop.getProperty("rdm.whse.keyStorePassword"));
            creds.setCurrentSchema(prop.getProperty("rdm.whse.currentSchema"));
            this.whseDb2Context = new RDBContext(creds);
        }
        return this.whseDb2Context;
    }

    public CosmosContext getCosmosContext() {
        if (this.cosmosContext == null) {
            CosmosCredentials c = new CosmosCredentials();
            c.setHost("https://dragon-database-devsl-cosmos.documents.azure.com:443/");
            c.setKey(prop.getProperty("cosmos.db.key"));
            c.setDatabase("hnwqe-automation");
            this.cosmosContext = new CosmosContext(c);
        }
        return this.cosmosContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getFomVVredesignDb()
     * Description: This method will create an instance of FOM VV-redesign db context
     * Inputs : none
     * returns: CosmosContext
     * Author: Shalini Devaraj
     * *********************************************************************************************************************************************************
     */
    public CosmosContext getFomVVredesignDb() {
        if (this.fomVVredesignContext == null) {
            prop.loadCustomProperties("config/fillingredesign/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("fom.vvredesign.db_host"));
            c.setKey(prop.getProperty("fom.vvredesign.db_key"));
            c.setDatabase(prop.getProperty("fom.vvredesign.db_name"));
            this.fomVVredesignContext = new CosmosContext(c);
        }
        return this.fomVVredesignContext;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - signSHA256RSA()
     * Description: This method will generate a SHA256 with RSA signature for the given message using the provided private key
     * Inputs : message - The message to be signed, strPk - The private key
     * returns: signed message as a Base64 encoded string
     * usage: This method is typically used for generating secure signatures for WCNP API requests
     * Author: Shalini Devaraj
     * *********************************************************************************************************************************************************
     */

    public String signSHA256RSA(@NotNull String message, @NotNull String strPk) throws Exception {
        // Remove markers and new line characters in private key
        String realPK = strPk.replaceAll("-----END PRIVATE KEY-----", "")
                .replaceAll("-----BEGIN PRIVATE KEY-----", "")
                .replaceAll("\n", "");

        byte[] b1 = Base64.getDecoder().decode(realPK);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(b1);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        Signature privateSignature = Signature.getInstance("SHA256withRSA");
        privateSignature.initSign(kf.generatePrivate(spec));
        privateSignature.update(message.getBytes("UTF-8"));
        byte[] s = privateSignature.sign();
        return Base64.getEncoder().encodeToString(s);
    }

    public CosmosContext getTdcCosmosContext() {
        if (this.tdcCosmosContext == null) {
            prop.loadCustomProperties("config/tdc/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("tdc.pharmacydb.cosmos.url"));
            c.setKey(prop.getProperty("tdc.pharmacydb.cosmos.key"));
            c.setDatabase(prop.getProperty("tdc.pharmacydb.cosmos.db.name"));
            this.tdcCosmosContext = new CosmosContext(c);
        }
        return this.tdcCosmosContext;
    }
    /*
     * *********************************************************************************************************************************************************
     * Method Name - getTDCDbsConnection(String dbName)
     * Description: This method will return database context of PharmacyDBV2 or Metadb based on the db name passed in parameter
     * Inputs : NA
     * returns: IDatabaseContext
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    public IDatabaseContext getTDCDbsConnection(String dbName) {
        MSICredentials creds = new MSICredentials();
        prop.loadCustomProperties("config/tdc/");
        creds.setTenantId("3cbcc3d3-094d-4006-9849-0d11d61f484d");
        creds.setClientSecret(prop.getProperty("sql.client.secret"));
        creds.setClientId(prop.getProperty("sql.client.id"));
        creds.setDbHost("hw-tdc-qa-01-sql-nonprod-62beb330.database.windows.net");
        creds.setDbName(dbName);
        RDBContext ctx = new RDBContext(creds);
        return ctx;
    }

    public CosmosContext getRecommendationCosmosDb() {
        if (this.recommendationDB == null) {
            CosmosCredentials c = new CosmosCredentials();
            prop.loadCustomProperties("config/cs/ClinicalIntelligence/");
            c.setHost(prop.getProperty("ci.recom.cosmos.host"));
            c.setKey(prop.getProperty("ci.recom.cosmos.key"));
            c.setDatabase(prop.getProperty("ci.recom.cosmos.db"));
            this.recommendationDB = new CosmosContext(c);
        }
        return this.recommendationDB;
    }

    /*
     * *****************************************************************************************************************
     * Method Name - getNarxcareCosmosDb()
     * Description: This method will initialize connection to Narxcare CosmosDB context
     * Inputs : none
     * returns: CosmosContext
     * Author: Nataraj Parimi
     * *****************************************************************************************************************
     */
    public CosmosContext getNarxcareCosmosDb() {
        if (this.narxcareDB == null) {
            CosmosCredentials c = new CosmosCredentials();
            prop.loadCustomProperties("config/cs/Narxcare/");
            c.setHost(prop.getProperty("narxcare.cosmos.host"));
            c.setKey(prop.getProperty("narxcare.cosmos.key"));
            c.setDatabase(prop.getProperty("narxcare.cosmos.db"));
            this.narxcareDB = new CosmosContext(c);
        }
        return this.narxcareDB;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getDrugDiversionCosmosContext()
     * Description: This method will create an instance of Drug Diversion Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Avinash
     * *****************************************************************************************************************
     */
    public CosmosContext getDrugDiversionCosmosContext() {
        if (this.drugDiversionCosmosContext == null) {
            prop.loadCustomProperties("config/inv/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("orderReturns.cosmos_db_host"));
            c.setKey(prop.getProperty("orderReturns.cosmos_db_key"));
            c.setDatabase(prop.getProperty("inv.drugdiversion.cosmos_db_name"));
            this.drugDiversionCosmosContext = new CosmosContext(c);
        }
        return this.drugDiversionCosmosContext;
    }

    /* *********************************************************************************************************************************************************
     * Method Name - getCentralPatientCosmosContext()
     * Description: This method will create an instance of central patient cosmos context
     * Inputs : none
     * returns: CosmosContext
     * Author: Scott Leung
     * **********************************************************************************************************************************************************/
    public CosmosContext getCentralPatientCosmosContext() {
        if (this.centralPatientCosmosContext == null) {
            prop.loadCustomProperties("config/rdm/centralpatient/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("rdm.cp.cosmosDB.host"));
            c.setKey(prop.getProperty("rdm.cp.cosmosDB.key"));
            c.setDatabase(prop.getProperty("rdm.cp.cosmosDB.name"));
            this.centralPatientCosmosContext = new CosmosContext(c);
        }
        return this.centralPatientCosmosContext;
    }

    /* *********************************************************************************************************************************************************
     * Method Name - getPricefileDb()
     * Description: This method will create an instance of Pricefile Details Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Avinash
     * **********************************************************************************************************************************************************/
    public CosmosContext getPricefileDb() {
        if (this.orderReturnsCosmosContext == null) {
            prop.loadCustomProperties("config/inv/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("orderReturns.cosmos_db_host"));
            c.setKey(prop.getProperty("orderReturns.cosmos_db_key"));
            c.setDatabase(prop.getProperty("orderReturns.cosmos_db_name"));
            this.orderReturnsCosmosContext = new CosmosContext(c);
        }
        return this.orderReturnsCosmosContext;
    }

    /* *********************************************************************************************************************************************************
     * Method Name - getSitefileDb()
     * Description: This method will create an instance of Sitefile Details Cosmosdb context
     * Inputs : none
     * returns: CosmosContext
     * Author: Avinash
     * **********************************************************************************************************************************************************/
    public CosmosContext getSitefileDb() {
        if (this.orderReturnsCosmosContext == null) {
            prop.loadCustomProperties("config/inv/");
            CosmosCredentials c = new CosmosCredentials();
            c.setHost(prop.getProperty("orderReturns.cosmos_db_host"));
            c.setKey(prop.getProperty("orderReturns.cosmos_db_key"));
            c.setDatabase(prop.getProperty("orderReturns.cosmos_db_name"));
            this.orderReturnsCosmosContext = new CosmosContext(c);
        }
        return this.orderReturnsCosmosContext;
    }

    /*
     * *****************************************************************************************************************
     * Method Name - getSONICCosmosDb()
     * Description: This method will initialize connection to SONIC (Global Standing Orders) CosmosDB context.
     *              DB       : clinical-service-settings
     *              Host/URI : sonic.cosmos.host  (from config/cs/SonicUI/*.properties)
     *              Key      : sonic.cosmos.key   (from config/cs/SonicUI/*.properties)
     * Inputs : none
     * returns: CosmosContext
     * Author: SHOBHIT
     * *****************************************************************************************************************
     */
    public CosmosContext getSONICCosmosDb() {
        if (this.sonicDB == null) {
            CosmosCredentials c = new CosmosCredentials();
            prop.loadCustomProperties("config/cs/SonicUI/");
            c.setHost(prop.getProperty("sonic.cosmos.host"));
            c.setKey(prop.getProperty("sonic.cosmos.key"));
            c.setDatabase(prop.getProperty("sonic.cosmos.db"));
            this.sonicDB = new CosmosContext(c);
        }

        return this.sonicDB;
    }
}
