package hwqe.baseframework.domShippingServiceContext.config;

import hwqe.baseframework.utilities.PropertyReader;
import lombok.Getter;

/**
 * Configuration class for DOM Shipping Service.
 * Loads service-specific properties from config/dom-shipping-service/ directory.
 */
@Getter
public class DomShippingServiceConfig {

    private final String serviceUrl;
    private final String consumerId;
    private final String serviceName;
    private final String serviceEnv;
    private final String keyVersion;

    private static DomShippingServiceConfig domShippingServiceConfig = null;

    private DomShippingServiceConfig() {
        PropertyReader propertyReader = PropertyReader.getInstance();
        propertyReader.loadCustomProperties("config/dom-shipping-service/");
        
        serviceUrl = propertyReader.getProperty("domshipping.service.url");
        serviceName = propertyReader.getProperty("domshipping.wm.svc.name");
        serviceEnv = propertyReader.getProperty("domshipping.wm.svc.env");
        consumerId = propertyReader.getProperty("domshipping.wm.consumer.id");
        keyVersion = propertyReader.getProperty("domshipping.wm.svc.key.version");
    }

    /**
     * Returns singleton instance of DomShippingServiceConfig.
     * @return DomShippingServiceConfig instance
     */
    public static DomShippingServiceConfig getInstance() {
        if (domShippingServiceConfig == null) {
            domShippingServiceConfig = new DomShippingServiceConfig();
        }
        return domShippingServiceConfig;
    }
}

