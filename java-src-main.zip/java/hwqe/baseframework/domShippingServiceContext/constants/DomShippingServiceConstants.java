package hwqe.baseframework.domShippingServiceContext.constants;

/**
 * Constants for DOM Shipping Service API interactions.
 * Contains header names, header values, and API endpoints.
 */
public class DomShippingServiceConstants {

    // ==================== API Headers ====================
    public static final String CONTENT_TYPE_HEADER = "Content-Type";
    public static final String CONSUMER_ID_HEADER = "WM_CONSUMER.ID";
    public static final String SERVICE_NAME_HEADER = "WM_SVC.NAME";
    public static final String SERVICE_ENV_HEADER = "WM_SVC.ENV";
    public static final String KEY_VERSION_HEADER = "WM_SEC.KEY_VERSION";
    public static final String STORE_ID_HEADER = "x-hnw-rx-store-id";
    public static final String CLIENT_IP_ADDRESS_HEADER = "x-hnw-rx-client-ip-address";
    public static final String INITIATOR_HEADER = "x-hnw-rx-initiator";
    public static final String CLIENT_NAME_HEADER = "x-hnw-rx-client-name";
    public static final String GRAPHQL_VERSION = "x-hnw-graphql-schema-version";
    public static final String RX_CLIENT_HOSTNAME = "x-hnw-rx-client-hostname";
    public static final String RX_CLIENT_IP_ADDRESS = "x-hnw-rx-client-ip-address";
    public static final String RX_CLIENT_NAME = "x-hnw-rx-client-name";
    public static final String RX_CLIENT_WORKSTATION = "x-hnw-rx-client-workstation";
    public static final String RX_REQ_ID = "x-hnw-rx-req-id";
    public static final String RX_REQ_TRACK_ID = "x-hnw-rx-req-track-id";
    public static final String RX_STORE_ID = "x-hnw-rx-store-id";
    public static final String RX_USER_ID = "x-hnw-rx-user-id";


    // ==================== API Header Values ====================
    public static final String CONTENT_TYPE_JSON = "application/json";

    // ==================== API Endpoints ====================
    public static final String HEALTH_CHECK_ENDPOINT = "/v1/health";
    public static final String SHIPMENT_GRAPHQL_ENDPOINT = "/shipment/graphql";

    // Private constructor to prevent instantiation
    private DomShippingServiceConstants() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}

