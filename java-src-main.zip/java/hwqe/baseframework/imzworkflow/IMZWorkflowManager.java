package hwqe.baseframework.imzworkflow;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.imzworkflow.datamodels.SelfHelpResetResult;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.GetOrderInfo;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.utilities.Reporter;
import org.jspecify.annotations.NonNull;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class IMZWorkflowManager {

    // ── Work-Queue Code Constants ─────────────────────────────────────────────
    /** Work queue code 7  — Order is in Resolution (problems to resolve). */
    private static final int WQ_RESOLUTION = 7;

    /** Work queue code 12 — Order is in CHKDUR (drug-utilisation review check). */
    private static final int WQ_CHKDUR = 12;

    /** Work queue code 15 — Order is in SVCADMIN (service administration). */
    private static final int WQ_SVCADMIN = 15;
    // ─────────────────────────────────────────────────────────────────────────

    // ── Log-message fragment constants (avoids SonarQube S1192 duplication) ──
    private static final String LOG_PREFIX_ORDER = "[processIMZOrderToSvcAdmin] Order ";
    private static final String LOG_SUFFIX_SITE_ID = " on siteId: ";
    private static final String LOG_SUFFIX_ORDER_ID = " (order_id: ";
    // ─────────────────────────────────────────────────────────────────────────

    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop;
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;
    DBUtils dbUtils = new DBUtils();
    OrderContext ctx;

    public IMZWorkflowManager() {
        prop = PropertyReader.getInstance();
    }



    /**
     * Validates whether the given product MDS family ID is authorized for IMZ at the specified store.
     *
     * <p>Delegates to {@link #getAuthorizedImzProductMdsFamIds(int)} to retrieve the full
     * authorized product list for the store, then checks for membership.
     *
     * @param productMdsFamId the product MDS family ID to validate
     * @param siteId          the store/site number identifying which Informix DB to query
     * @return {@code true} if the product is in the authorized list; {@code false} otherwise
     */
    public boolean isProductAuthorizedForImz(int productMdsFamId, int siteId) {
        Reporter.log("Validating productMdsFamId: " + productMdsFamId
                + " against authorised IMZ products for siteId: " + siteId);

        List<Integer> authorizedImzProductMdsFamIds = getAuthorizedImzProductMdsFamIds(siteId);
        boolean isAuthorized = authorizedImzProductMdsFamIds.contains(productMdsFamId);

        Reporter.log("productMdsFamId: " + productMdsFamId
                + (isAuthorized ? " IS" : " is NOT")
                + " authorised for IMZ at siteId: " + siteId);
        return isAuthorized;
    }

    /**
     * Safely extracts a trimmed String value from a result-set row map.
     *
     * @param row       the result row from {@link IDatabaseContext#executeQuery(String)}
     * @param columnKey the column name to look up (case-sensitive per Informix driver)
     * @return trimmed string value, or {@code null} if the column is absent or its value is null
     */
    private String getStringValue(Map<String, Object> row, String columnKey) {
        Object value = row.get(columnKey);
        return (value != null) ? value.toString().trim() : null;
    }

    /**
     * Queries the Informix DB for all authorized IMZ product MDS family IDs.
     *
     * <p>Executes the following SQL against the Connexus (Informix) store DB:
     * <pre>
     *   SELECT DISTINCT pp.product_mds_fam_id
     *   FROM pharmacy_offering:pharmacy_product pp
     *   JOIN pre_auth_product pap
     *     ON pp.product_mds_fam_id = pap.product_mds_fam_id
     *   JOIN service_pre_auth spa
     *     ON pap.pre_auth_id = spa.pre_auth_id
     *   JOIN pharmacy_offering:informix.pharmacy_item pitem
     *     ON pitem.product_mds_fam_id = pp.product_mds_fam_id
     *   JOIN pharmacy_offering:route_admin_txt rat
     *     ON pp.route_admin_code = rat.route_admin_code
     *   WHERE pp.status_code = 20806
     *     AND pitem.status_code = 20909
     *     AND pap.pre_auth_id IN (
     *       SELECT pre_auth_id FROM service_pre_auth
     *       WHERE pre_auth_type_cd IN (100, 101)  -- Both SO and RPH Auth
     *         AND (pre_auth_expir_date > CURRENT OR pre_auth_expir_date IS NULL)
     *     )
     * </pre>
     *
     * <p>Filters to active products ({@code status_code = 20806}) with active items
     * ({@code status_code = 20909}) that have a non-expired SO or RPH pre-auth.
     *
     * @param siteId the store/site number identifying which Informix DB to query
     * @return a non-null {@link List} of {@code product_mds_fam_id} integers;
     *         empty list if no authorized products are found
     */
    public List<Integer> getAuthorizedImzProductMdsFamIds(int siteId) {
        String sql = "SELECT DISTINCT pp.product_mds_fam_id "
                + "FROM pharmacy_offering:pharmacy_product pp "
                + "JOIN pre_auth_product pap "
                + "  ON pp.product_mds_fam_id = pap.product_mds_fam_id "
                + "JOIN service_pre_auth spa "
                + "  ON pap.pre_auth_id = spa.pre_auth_id "
                + "JOIN pharmacy_offering:informix.pharmacy_item pitem "
                + "  ON pitem.product_mds_fam_id = pp.product_mds_fam_id "
                + "JOIN pharmacy_offering:route_admin_txt rat "
                + "  ON pp.route_admin_code = rat.route_admin_code "
                + "WHERE pp.status_code = 20806 "
                + "AND pitem.status_code = 20909 "
                + "AND pap.pre_auth_id IN ( "
                + "  SELECT pre_auth_id FROM service_pre_auth "
                + "  WHERE pre_auth_type_cd IN (100, 101) "
                + "  AND (pre_auth_expir_date > CURRENT OR pre_auth_expir_date IS NULL) "
                + ")";

        Reporter.log("Fetching authorized IMZ product_mds_fam_ids from Informix DB for siteId: " + siteId);

        List<Map<String, Object>> resultSet = am.getConnexusDB(siteId).executeQueryForList(sql);
        List<Integer> productMdsFamIds = new ArrayList<>();

        if (resultSet == null || resultSet.isEmpty()) {
            Reporter.log("No authorized IMZ products found in Informix DB for siteId: " + siteId);
            return productMdsFamIds;
        }

        for (Map<String, Object> row : resultSet) {
            Object value = row.get("product_mds_fam_id");
            if (value != null) {
                productMdsFamIds.add(((Number) value).intValue());
            }
        }

        Reporter.log("Found " + productMdsFamIds.size() + " authorized IMZ product_mds_fam_ids for siteId: " + siteId);
        return productMdsFamIds;
    }

    /**
     * Sets the patient status to active (20700) for the given patient.
     *
     * <p>Executes the following SQL against the Connexus (Informix) store DB:
     * <pre>
     *   UPDATE patient
     *   SET    status_code = 20700
     *   WHERE  patient_id  = :patientId
     * </pre>
     *
     * @param patientId the ID of the patient whose status_code should be set to 20700
     * @param siteId    the store/site number identifying which Informix DB to update
     */
    public void updatePatientStatusCode(int patientId, int siteId) {
        String sql = "UPDATE patient "
                + "SET status_code = 20700 "
                + "WHERE patient_id = " + patientId;

        Reporter.log("Updating patient status_code to 20700 for patient_id: " + patientId
                + LOG_SUFFIX_SITE_ID + siteId);

        int rowsAffected = am.getConnexusDB(siteId).executeUpdateQuery(sql);

        Reporter.log("updatePatientStatusCode — rows affected: " + rowsAffected
                + " for patient_id: " + patientId);
    }

    /**
     * Sets the problem status to resolved (6301) for the first sequence item of a given order.
     *
     * <p>Executes the following SQL against the Connexus (Informix) store DB:
     * <pre>
     *   UPDATE rx_ord_dtl_problem
     *   SET    problem_stat_code = 6301
     *   WHERE  order_id      = :orderId
     *     AND  order_seq_nbr = 1
     * </pre>
     *
     * @param orderId the order ID whose first-sequence problem record should be resolved
     * @param siteId  the store/site number identifying which Informix DB to update
     */
    public void updateRxOrdDtlProblemStatCode(int orderId, int siteId) {
        String sql = "UPDATE rx_ord_dtl_problem "
                + "SET problem_stat_code = 6301 "
                + "WHERE order_id = " + orderId
                + " AND order_seq_nbr = 1";

        Reporter.log("Updating rx_ord_dtl_problem.problem_stat_code to 6301 for order_id: " + orderId
                + LOG_SUFFIX_SITE_ID + siteId);

        int rowsAffected = am.getConnexusDB(siteId).executeUpdateQuery(sql);

        Reporter.log("updateRxOrdDtlProblemStatCode — rows affected: " + rowsAffected
                + " for order_id: " + orderId);
    }

    /**
     * Resets the work-queue assignment fields for the first sequence of a given order,
     * returning it to an unassigned/pending state (work_que_stat_code = 20200).
     *
     * <p>Executes the following SQL against the Connexus (Informix) store DB:
     * <pre>
     *   UPDATE rx_order_detail
     *   SET    assigned_userid      = NULL,
     *          wrkstatn_host_name   = NULL,
     *          retry_ts             = NULL,
     *          work_que_stat_code   = 20200
     *   WHERE  order_id      = :orderId
     *     AND  order_seq_nbr = 1
     * </pre>
     *
     * @param orderId the order ID whose first-sequence detail record should be reset
     * @param siteId  the store/site number identifying which Informix DB to update
     */
    public void resetRxOrderDetailAssignment(int orderId, int siteId) {
        String sql = "UPDATE rx_order_detail "
                + "SET assigned_userid = NULL, "
                + "wrkstatn_host_name = NULL, "
                + "retry_ts = NULL, "
                + "work_que_stat_code = 20200 "
                + "WHERE order_id = " + orderId
                + " AND order_seq_nbr = 1";

        Reporter.log("Resetting rx_order_detail assignment fields for order_id: " + orderId
                + LOG_SUFFIX_SITE_ID + siteId);

        int rowsAffected = am.getConnexusDB(siteId).executeUpdateQuery(sql);

        Reporter.log("resetRxOrderDetailAssignment — rows affected: " + rowsAffected
                + " for order_id: " + orderId);
    }



    public void resolveResolutions(int orderId, int siteId) {
        Reporter.log(LOG_PREFIX_ORDER + orderId
                + " is currently in Resolution (work_que_code=" + WQ_RESOLUTION + "). "
                + "Will begin resolving problems.");

        Map<Integer, String> problemCodes = getOrderProblemCodes(orderId, siteId);

        // Step 2a: Check if order is in patient name mismatch resolution (problem code 1034), and then update status code in patient table
        if (problemCodes.containsKey(1034)) {
            Reporter.log(LOG_PREFIX_ORDER + orderId
                    + " has patient name mismatch problem (code 1034: "
                    + problemCodes.get(1034) + "). Resolving now.");
            updatePatientStatusCode(ctx.patientId, siteId);
        }

        updateRxOrdDtlProblemStatCode(orderId, siteId);
        resetRxOrderDetailAssignment(orderId, siteId);
        invokeSelfHelpReset(orderId, 1, "IMZWorkflowManager", "AUTOMATION", siteId);

        Reporter.log("Order status self help reset complete for orderId" + orderId);
    }



    /**
     * Invokes the Informix {@code rx_healer} stored procedure, which is the backend
     * operation triggered when a pharmacist clicks <em>Self Help Reset</em> in the
     * Connexus UI (Order Search view → right-click context menu).
     *
     * <p>This mirrors the DAL call in {@code OrderDAL.PharmacyResetFill()} from the
     * Connexus service stack:
     * <pre>
     *   EXECUTE PROCEDURE rx_healer(orderId, orderSeqNbr, 'userId', 'workStationName')
     * </pre>
     *
     * <p>The procedure resets the order's work-queue lock, clears the assigned user,
     * and moves the order to the appropriate next work queue. It stamps the activity
     * log with activity code {@code 29131} (SelfHelpReset).
     *
     * <p><strong>Return columns from rx_healer:</strong>
     * <ul>
     *   <li>Column 0 ({@code isSuccess})     – "Y" on success, "N" on failure</li>
     *   <li>Column 1 ({@code returnMessage}) – Human-readable message for the pharmacist</li>
     *   <li>Column 2 ({@code nextQueue})     – Work queue the order was moved to</li>
     * </ul>
     *
     * @param orderId         the order ID of the stuck/in-progress order to reset
     * @param orderSeqNbr     the order sequence number (typically {@code 1})
     * @param userId          the user ID of the pharmacist initiating the reset
     *                        (maps to {@code ContextManager.UserId} in the UI)
     * @param workStationName the workstation name initiating the reset
     *                        (maps to {@code Environment.MachineName} in the UI)
     * @param siteId          the store/site number identifying which Informix DB to query
     * @return a {@link SelfHelpResetResult} with the outcome, message, and next queue;
     *         or {@code null} if the stored procedure returned no rows
     */
    public SelfHelpResetResult invokeSelfHelpReset(
            int orderId, int orderSeqNbr, String userId, String workStationName, int siteId) {

        // Informix stored-procedure call — parameters inlined to match the existing
        // executeQuery contract used throughout this class. Single-quote escaping is
        // handled by replacing any embedded single-quotes in the string args.
        String sql = "EXECUTE PROCEDURE rx_healer("
                + orderId + ", "
                + orderSeqNbr + ", "
                + "'" + userId.replace("'", "''") + "', "
                + "'" + workStationName.replace("'", "''") + "'"
                + ")";

        Reporter.log("Invoking rx_healer (SelfHelpReset) — orderId: " + orderId
                + ", orderSeqNbr: " + orderSeqNbr
                + ", userId: " + userId
                + ", workStationName: " + workStationName
                + ", siteId: " + siteId);

        IDatabaseContext db = am.getConnexusDB(siteId);
        Map<String, Object> row = db.executeQuery(sql);

        if (row == null || row.isEmpty()) {
            Reporter.log("rx_healer returned no rows for orderId: " + orderId
                    + LOG_SUFFIX_SITE_ID + siteId);
            return null;
        }

        // rx_healer returns positional columns; Informix JDBC exposes them by
        // ordinal name ("column1", "column2", "column3") when no alias is declared.
        SelfHelpResetResult result = SelfHelpResetResult.builder()
                .isSuccess(getStringValue(row, "column1"))
                .returnMessage(getStringValue(row, "column2"))
                .nextQueue(getStringValue(row, "column3"))
                .build();

        Reporter.log("rx_healer result — isSuccess: " + result.getIsSuccess()
                + ", nextQueue: " + result.getNextQueue()
                + ", returnMessage: " + result.getReturnMessage());

        return result;
    }





    /**
     * Two-step flow to call CHK DUR Complete for an existing order.
     *
     * <p><b>Step 1</b> — POST {@code /getOrderInfo}</p>
     * <pre>
     *   Body:  { "siteId": &lt;storeNbr&gt;, "rxFillId": &lt;rxFillId&gt; }
     *   Returns: full Order JSON
     * </pre>
     *
     * <p><b>Step 2</b> — POST {@code /checkDURComplete}</p>
     * <pre>
     *   Body:  Order JSON from Step 1, with workQueue stamped to "CheckDUR"
     *   Returns: InputResponse (orderId, rxFillId, rxId, rxNbr, etc.)
     * </pre>
     *
     * @param storeNbr the store/site number
     * @param rxFillId the Order ID for the order to move through CHKDUR
     * @return {@link InputResponse} from the checkDURComplete API
     * @throws AssertionError if Step 1 returns a non-200 status, or Step 2 returns a non-302 status,
     *                        or if the Step 2 response contains an error
     */
    public void performChkDurComplete(int rxFillId, int storeNbr) {

        // ── Step 1: GET full order object via getOrderInfo ───────────────────────
        GetOrderInfo getOrderInfoRequest = new GetOrderInfo();
        getOrderInfoRequest.setSiteId(storeNbr);
        getOrderInfoRequest.setRxFillId(rxFillId);

        req.setUrl(prop.getProperty("fom.connexusWrapper.getOrderInfo"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        req.setRequestPayload(getOrderInfoRequest);

        Reporter.log("[performChkDurComplete] Step 1 — getOrderInfo endpoint: " + req.getUrl());
        Reporter.logJSON("[performChkDurComplete] Step 1 — getOrderInfo Request", req.getRequestPayload());

        ServiceResponse getOrderInfoResponse = am.getRestContext().performPost(req);

        Reporter.logJSON("[performChkDurComplete] Step 1 — getOrderInfo Response", getOrderInfoResponse.getDataResponse());

        // ── Stamp workQueue = "CheckDUR" on the order before forwarding ──────────
        getOrderInfoResponse.setJsonElement("workQueue", "CheckDUR");
        Reporter.log("[performChkDurComplete] workQueue stamped to 'CheckDUR'");

        // ── Step 2: POST mutated order JSON to chDURComplete ──────────────────
        req.setUrl(prop.getProperty("fom.connexusWrapper.checkDURCompleteUrl"));
        req.setHeaders(headers);
        req.setRequestPayload(getOrderInfoResponse.getDataResponse());

        Reporter.log("[performChkDurComplete] Step 2 — checkDURComplete endpoint: " + req.getUrl());
        Reporter.logJSON("[performChkDurComplete] Step 2 — checkDURComplete Request", req.getRequestPayload());

        ServiceResponse chkDurCompleteResponse = am.getRestContext().performPost(req, 2);

        Reporter.logJSON("[performChkDurComplete] Step 2 — checkDURComplete Response", chkDurCompleteResponse.getDataResponse());
        //Assert.assertFalse(chkDurCompleteResponse.getDataResponse().contains("error"),
          //      "checkDURComplete response contains an error for storeNbr: " + storeNbr + ", rxFillId: " + rxFillId);

    }



    // ──────────────────────────────────────────────────────────────────────
    // SVC-ADMIN FLOW
    // ──────────────────────────────────────────────────────────────────────

    /**
         * Holds a snapshot of the order-level identifiers retrieved from the DB.
         *
         * <p>All fields are populated in one SQL join so that callers never have
         * to make multiple round-trips for the same order.
         */
        private record OrderContext(int rxNbr, int patientId, int rxFillId, int rxId, int nextWorkQueCode) {

        @Override
            public @NonNull String toString() {
                return "OrderContext{rxNbr=" + rxNbr
                        + ", patientId=" + patientId
                        + ", rxFillId=" + rxFillId
                        + ", rxId=" + rxId
                        + ", nextWorkQueCode=" + nextWorkQueCode + "}";
            }
        }

    /**
     * Fetches the key order identifiers for a given {@code order_id} in a single DB round-trip.
     *
     * <p>Executes the following SQL against the Connexus (Informix) store DB:
     * <pre>
     *   SELECT rod.rx_fill_id,
     *          rod.next_work_que_code,
     *          rod.rx_id,
     *          rx.rx_nbr,
     *          rx.patient_id
     *   FROM rx_order_detail rod
     *   JOIN rx ON rod.rx_id = rx.rx_id
     *   WHERE rod.order_id = :orderId
     * </pre>
     *
     * @param orderId the order ID to look up
     * @param siteId  the store/site number identifying which Informix DB to query
     * @return a populated {@link OrderContext}
     * @throws IllegalStateException if no record is found for the given order ID
     */
    private OrderContext getOrderContext(int orderId, int siteId) {
        String sql = "SELECT rod.rx_fill_id, rod.next_work_que_code, rod.rx_id, "
                + "rx.rx_nbr, rx.patient_id "
                + "FROM rx_order_detail rod "
                + "JOIN rx ON rod.rx_id = rx.rx_id "
                + "WHERE rod.order_id = " + orderId
                + " AND rod.order_seq_nbr = 1";

        Reporter.log("[getOrderContext] Fetching order context for order_id: " + orderId
                + LOG_SUFFIX_SITE_ID + siteId);

        Map<String, Object> row = am.getConnexusDB(siteId).executeQuery(sql);

        if (row == null || row.isEmpty()) {
            throw new IllegalStateException(
                    "No rx_order_detail record found for order_id: " + orderId
                    + LOG_SUFFIX_SITE_ID + siteId);
        }

        OrderContext orderCtx = new OrderContext(
                ((Number) row.get("rx_nbr")).intValue(),
                ((Number) row.get("patient_id")).intValue(),
                ((Number) row.get("rx_fill_id")).intValue(),
                ((Number) row.get("rx_id")).intValue(),
                ((Number) row.get("next_work_que_code")).intValue()
        );

        Reporter.log("[getOrderContext] " + orderCtx);
        return orderCtx;
    }

    /**
     * Drives an IMZ order from its current work queue all the way to
     * <em>SVCADMIN</em> (work-queue code {@value #WQ_SVCADMIN}).
     *
     * <p><b>Algorithm</b>
     * <ol>
     *   <li>Resolve the order context (rxNbr, patientId, rxFillId, rxId,
     *       next_work_que_code) from the DB using {@code orderId}.</li>
     *   <li>If {@code next_work_que_code == }{@value #WQ_RESOLUTION}, log that
     *       the order is currently in <em>Resolution</em>.</li>
     *   <li>Loop until {@code next_work_que_code == }{@value #WQ_SVCADMIN}:
     *     <ol>
     *       <li>Call {@link #resolveResolutions(int, int)} to clear the
     *           current resolution block.</li>
     *       <li>Re-fetch {@code next_work_que_code} from {@code rx_order_detail}
     *           and log the updated value.</li>
     *       <li>If {@code next_work_que_code == }{@value #WQ_CHKDUR}, call
     *           {@link #performChkDurComplete(int, int)} to process CHKDUR,
     *           then re-fetch and log the code before breaking the loop.</li>
     *     </ol>
     *   </li>
     * </ol>
     *
     * @param orderId the order ID of the IMZ order to advance
     * @param siteId  the store/site number identifying which Informix DB to update
     */
    public void processIMZOrderToSvcAdmin(int orderId, int siteId) {
        Reporter.log("[processIMZOrderToSvcAdmin] Starting SVC-ADMIN flow for order_id: "
                + orderId + LOG_SUFFIX_SITE_ID + siteId);

        // Step 1: Fetch all key identifiers in one shot.
        ctx = getOrderContext(orderId, siteId);
        Reporter.log("[processIMZOrderToSvcAdmin] Order context resolved — "
                + "rxNbr=" + ctx.rxNbr
                + ", patientId=" + ctx.patientId
                + ", rxFillId=" + ctx.rxFillId
                + ", rxId=" + ctx.rxId
                + ", next_work_que_code=" + ctx.nextWorkQueCode);

        // Step 2: Surface early if the order is already sitting in Resolution.
        if (ctx.nextWorkQueCode == WQ_RESOLUTION) {

        //Step 2a: Resolving all  problems on the order.
            resolveResolutions(orderId, siteId);

        // Re-fetch work-queue code after resolving all problems and triggering self-help reset
            ctx = getOrderContext(orderId, siteId);
            Reporter.log("[processIMZOrderToSvcAdmin] next_work_que_code after resolving all problem codes: "
                    + ctx.nextWorkQueCode + LOG_SUFFIX_ORDER_ID + orderId + ")");

        // Step 2c: Poll until the order leaves RESOLUTION queue (max 60s, every 10s).
            long startTime = System.currentTimeMillis();
            long maxWaitMs = 60_000;
            long pollIntervalMs = 10_000;

            while (ctx.nextWorkQueCode != WQ_CHKDUR) {
                long elapsed = System.currentTimeMillis() - startTime;
                if (elapsed >= maxWaitMs) {
                    throw new IMZWorkflowException(
                            "Timeout after " + (maxWaitMs / 1000) + "s waiting for order_id: "
                            + orderId + " to leave RESOLUTION queue (work_que_code="
                            + WQ_RESOLUTION + ")" + LOG_SUFFIX_SITE_ID + siteId);
                }
                Reporter.log(LOG_PREFIX_ORDER + orderId
                        + " still in RESOLUTION. Waiting " + (pollIntervalMs / 1000)
                        + "s before re-checking... (elapsed: " + (elapsed / 1000) + "s)");
                try {
                    Thread.sleep(pollIntervalMs);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new IMZWorkflowException("Polling interrupted for order_id: " + orderId, e);
                }
                ctx = getOrderContext(orderId, siteId);
                Reporter.log("[processIMZOrderToSvcAdmin] Re-fetched next_work_que_code: "
                        + ctx.nextWorkQueCode + LOG_SUFFIX_ORDER_ID + orderId + ")");
            }

            Reporter.log(LOG_PREFIX_ORDER + orderId
                    + " has left RESOLUTION queue. Current next_work_que_code: " + ctx.nextWorkQueCode);
        }

        // Step 3: If the order landed in CHKDUR.
            if (ctx.nextWorkQueCode == WQ_CHKDUR) {
                Reporter.log(LOG_PREFIX_ORDER + orderId
                        + " reached CHKDUR (work_que_code=" + WQ_CHKDUR + "). "
                        + "Calling performChkDurComplete.");

                performChkDurComplete(ctx.rxFillId, siteId);

                // Re-fetch and log after CHKDUR processing.
                ctx = getOrderContext(orderId, siteId);
                Reporter.log("[processIMZOrderToSvcAdmin] next_work_que_code after performChkDurComplete: "
                        + ctx.nextWorkQueCode + LOG_SUFFIX_ORDER_ID + orderId + ")");
            }


        Reporter.log("[processIMZOrderToSvcAdmin] Flow complete for order_id: " + orderId
                + ". Final next_work_que_code: " + ctx.nextWorkQueCode
                + (ctx.nextWorkQueCode == WQ_SVCADMIN ? " — order is now in SVCADMIN ✓" : ""));
    }

    /**
     * Identifies all problem codes on the first sequence of a given order.
     *
     * <p>Executes the following SQL against the Connexus (Informix) store DB:
     * <pre>
     *   SELECT phm_problem_code, phm_problem_desc
     *   FROM   phm_problem_txt
     *   WHERE  phm_problem_code IN (
     *     SELECT phm_problem_code
     *     FROM   rx_ord_dtl_problem
     *     WHERE  order_id      = :orderId
     *       AND  order_seq_nbr = 1
     *   )
     * </pre>
     *
     * <p>Every problem code and its description are logged individually to the
     * Reporter. The results are returned as an insertion-ordered map so callers
     * can iterate in the same order the DB returned them.
     *
     * @param orderId the order ID whose seq-1 problem codes should be retrieved
     * @param siteId  the store/site number identifying which Informix DB to query
     * @return a non-null {@link LinkedHashMap} of {@code phm_problem_code} →
     *         {@code phm_problem_desc}; empty map if no problems are found
     */
    public Map<Integer, String> getOrderProblemCodes(int orderId, int siteId) {
        String sql = "SELECT phm_problem_code, phm_problem_desc "
                + "FROM phm_problem_txt "
                + "WHERE phm_problem_code IN ("
                + "  SELECT phm_problem_code "
                + "  FROM rx_ord_dtl_problem "
                + "  WHERE order_id = " + orderId
                + "  AND order_seq_nbr = 1"
                + ")";

        Reporter.log("Fetching problem codes for order_id: " + orderId + LOG_SUFFIX_SITE_ID + siteId);

        List<Map<String, Object>> resultSet = am.getConnexusDB(siteId).executeQueryForList(sql);
        Map<Integer, String> problemCodeMap = new LinkedHashMap<>();

        if (resultSet == null || resultSet.isEmpty()) {
            Reporter.log("No problem codes found for order_id: " + orderId + LOG_SUFFIX_SITE_ID + siteId);
            return problemCodeMap;
        }

        for (Map<String, Object> row : resultSet) {
            String problemCodeStr = getStringValue(row, "phm_problem_code");
            if (problemCodeStr == null) continue;
            int problemCode = Integer.parseInt(problemCodeStr);
            String problemDesc = getStringValue(row, "phm_problem_desc");
            problemCodeMap.put(problemCode, problemDesc);
            Reporter.log("Problem Code: " + problemCode + " | Description: " + problemDesc);
        }

        Reporter.log("Total problem codes found for order_id " + orderId + ": " + problemCodeMap.size());
        return problemCodeMap;
    }



}
