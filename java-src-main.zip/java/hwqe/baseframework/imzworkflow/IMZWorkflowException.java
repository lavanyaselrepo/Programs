package hwqe.baseframework.imzworkflow;

/**
 * Custom exception for IMZ Workflow operations.
 * Provides better error context and handling for IMZ order processing failures
 * such as timeouts, polling interruptions, and unexpected workflow states.
 */
public class IMZWorkflowException extends RuntimeException {

    /**
     * Constructs a new IMZWorkflowException with the specified detail message.
     *
     * @param message the detail message
     */
    public IMZWorkflowException(String message) {
        super(message);
    }

    /**
     * Constructs a new IMZWorkflowException with the specified detail message and cause.
     *
     * @param message the detail message
     * @param cause   the cause of this exception
     */
    public IMZWorkflowException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new IMZWorkflowException with the specified cause.
     *
     * @param cause the cause of this exception
     */
    public IMZWorkflowException(Throwable cause) {
        super(cause);
    }
}
