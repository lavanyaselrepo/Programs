package hwqe.baseframework.imzworkflow.datamodels;

import lombok.Builder;
import lombok.Data;

/**
 * Data model for the result returned by the Informix {@code rx_healer} stored procedure,
 * which is invoked when Self Help Reset is triggered in the Connexus UI.
 *
 * <p>Maps to the three columns returned by:
 * <pre>
 *   EXECUTE PROCEDURE rx_healer(orderId, orderSeqNbr, 'userId', 'workStationName')
 * </pre>
 *
 * <ul>
 *   <li>Column 0 → {@code isSuccess}     – "Y" if the reset succeeded, "N" otherwise</li>
 *   <li>Column 1 → {@code returnMessage} – Human-readable message displayed to the pharmacist</li>
 *   <li>Column 2 → {@code nextQueue}     – Work queue name the order was moved to</li>
 * </ul>
 *
 * @see <a href="Connexus_SP repo">rx_healer stored procedure (Informix rx21c)</a>
 */
@Data
@Builder
public class SelfHelpResetResult {

    /**
     * "Y" if the self-help reset succeeded; "N" otherwise.
     * Maps to column index 0 of the rx_healer result set.
     */
    private String isSuccess;

    /**
     * Human-readable message returned by rx_healer and shown to the pharmacist.
     * Maps to column index 1 of the rx_healer result set.
     */
    private String returnMessage;

    /**
     * Name of the work queue the order was moved into after the reset.
     * Maps to column index 2 of the rx_healer result set.
     */
    private String nextQueue;

    /** Convenience helper: returns {@code true} when {@code isSuccess} equals "Y" (case-insensitive). */
    public boolean succeeded() {
        return "Y".equalsIgnoreCase(isSuccess);
    }
}
