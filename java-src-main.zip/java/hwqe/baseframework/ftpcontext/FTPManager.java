package hwqe.baseframework.ftpcontext;

import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FTPManager {
    private FTPClient ftp;
    private FTPCredentials credentials;

    public FTPManager(FTPCredentials credentials) {
        this.credentials = credentials;
    }

    public boolean open() {
        try {
            ftp = new FTPClient();
            ftp.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out)));
            ftp.connect(credentials.getHost(), credentials.getPort());
            int reply = ftp.getReplyCode();
            if (FTPReply.isPositiveCompletion(reply)) {
                ftp.login(credentials.getUserName(), credentials.getPassword());
                return true;
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return false;
    }

    public boolean close() {
        try {
            ftp.disconnect();
            return true;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return false;
    }

    public List<String> listFiles(String path) {
        try {
            FTPFile[] files = ftp.listFiles(path);
            return Arrays.stream(files)
                    .map(FTPFile::getName)
                    .collect(Collectors.toList());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public boolean downloadFile(String source, String destination) {
        try {
            FileOutputStream out = new FileOutputStream(destination);
            ftp.retrieveFile(source, out);
            return true;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return false;
    }

    public boolean uploadFile(String srcPath, String destPath) {
        try {
            ftp.storeFile(destPath, new FileInputStream(srcPath));
            return true;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return false;
    }
}