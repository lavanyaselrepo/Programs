package hwqe.baseframework.connexusharnessapicontext.apimanager;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.ServiceUrlManager;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;

import java.util.HashMap;

public class BeaconServiceManager {
    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReader.getInstance();
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;

    public BeaconServiceManager() {
        prop.loadCustomProperties("config/connexustestharness/");
    }

    public ServiceResponse GetStationCounts(String siteId, String station, String userId) {
        String serviceEndpoint = StoreIDManager.createEndPointURL(siteId, prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.GetStationCountsEndPoint"));

        req.setUrl(serviceEndpoint + "?siteId=" + siteId + "&station=" + station + "&userId=" + userId);
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        Reporter.log("GetStationCounts Request endpoint: " + req.getUrl());
        Reporter.logJSON("GetStationCounts Request", req.getRequestPayload());

        resp = am.getRestContext().performGet(req);
        Reporter.logJSON("GetStationCounts Response", resp.getDataResponse());

        return resp;
    }

    public ServiceResponse GetStationCounts(String siteId, String station) {
        String serviceEndpoint = StoreIDManager.createEndPointURL(prop.getProperty("cnx.store"), prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.GetStationCountsEndPoint"));

        req.setUrl(serviceEndpoint + "?siteId=" + siteId + "&station=" + station);
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        Reporter.log("GetStationCounts Request endpoint: " + req.getUrl());
        Reporter.logJSON("GetStationCounts Request", req.getRequestPayload());

        resp = am.getRestContext().performGet(req);
        Reporter.logJSON("GetStationCounts Response", resp.getDataResponse());

        return resp;
    }
}
