package hwqe.baseframework.connexusharnessapicontext.apimanager;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexusharnessapicontext.datamodels.patientservice.GetBasicInfo.GetBasicInfoRequest;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;

import java.io.IOException;
import java.rmi.ServerException;
import java.util.HashMap;

import static hwqe.baseframework.utilities.FileUtils.readFileToString;

public class PatientServiceManager {
    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReader.getInstance();
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;

    public PatientServiceManager() {
        prop.loadCustomProperties("config/connexustestharness/");
    }

    public void insertAllergyAPI(String insertAllergyInfoFilePath, int patientId) throws IOException {
        String file = readFileToString(insertAllergyInfoFilePath);
        DocumentContext jsonToParse = JsonPath.parse(file);
        jsonToParse.set("$.AllergyInformation.PatientId", patientId);
        String effectiveTS = jsonToParse.read("$.AllergyInformation.EffectiveTS");
        if (effectiveTS != null && !effectiveTS.isEmpty()) {

            try {
                req.setRequestPayloadWithNulls(jsonToParse.json());
                int storeId = jsonToParse.read("$.SiteID");
                String serviceEndPointURL = StoreIDManager.createEndPointURL(Integer.toString(storeId), prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.addAllergyEndPoint"));
                req.setUrl(serviceEndPointURL);
                headers.put("Content-Type", "application/json");
                headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
                req.setHeaders(headers);
                System.out.println("Patient Allergy API RequestPayload:\n" + req.getRequestPayload() + "\n");
                Reporter.log("Patient Allergy API endpoint:" + req.getUrl());
                resp = am.getRestContext().performPost(req);
                System.out.println("Patient Allergy API ResponsePayload:\n" + resp.getStatusDesc() + "\n" + resp.getStatusCode() + "\n");
                Assert.assertNotNull(resp);
                Assert.assertEquals(resp.getStatusCode(), 200, "Expected status code 200 but found " + resp.getStatusCode());

            } catch (Exception exception) {
                Reporter.log("Error occurred while inserting allergy");
                throw new ServerException("Error occurred while inserting allergy", exception);
            }
        } else {
            System.out.println("Error: EffectiveTS is null or empty");
            throw new ServerException("Error: EffectiveTS is null or empty. Cannot proceed with API call.");
        }
    }

    public void checkPatientAllergyInfo(String checkPatientAllergyInfoFilePath, int patientId) throws IOException {

        String file = readFileToString(checkPatientAllergyInfoFilePath);
        DocumentContext jsonToParse = JsonPath.parse(file);
        jsonToParse.set("$.PatientId", patientId);
        req.setRequestPayloadWithNulls(jsonToParse.json());
        int storeId = jsonToParse.read("$.SiteID");
        String serviceEndPointURL = StoreIDManager.createEndPointURL(Integer.toString(storeId), prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.checkAllergyInfoEndPoint"));
        req.setUrl(serviceEndPointURL);
        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        Reporter.log("CheckAllergyInfo API Endpoint:" + req.getUrl());
        System.out.println("CheckAllergyInfo API RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req);
        System.out.println("CheckAllergyInfo API ResponsePayload:\n" + resp.getDataResponse());
        Assert.assertNotNull(resp);
        Assert.assertEquals(resp.getStatusCode(), 200, "Expected status code 200 but found " + resp.getStatusCode());
        Gson gson = new Gson();
        JsonObject json = gson.fromJson(resp.getDataResponse(), JsonObject.class);
        boolean allergyExists = json.get("AllergyExists").getAsBoolean();
        Assert.assertTrue(allergyExists, "Allergy should exist but it does not");
    }

    public ServiceResponse callGetBasicInfoApi(Integer patientId) throws IOException {
        String serviceEndpoint = StoreIDManager.createEndPointURL(prop.getProperty("connexusharness.storeId"), prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.GetBasicInfo"));
        GetBasicInfoRequest getBasicInfoRequest = new GetBasicInfoRequest();
        getBasicInfoRequest.setPatientID(patientId);
        req.setUrl(serviceEndpoint);
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        req.setRequestPayload(getBasicInfoRequest);
        Reporter.log("BasicInfo Request endpoint: " + req.getUrl());
        Reporter.logJSON("BasicInfo Request", req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("BasicInfo Response", resp.getDataResponse());
        return resp;
    }

    public ServiceResponse callGetBasicInfoApiNullPatient() throws IOException {
        String serviceEndpoint = StoreIDManager.createEndPointURL(prop.getProperty("connexusharness.storeId"), prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.GetBasicInfo"));
        req.setUrl(serviceEndpoint);
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        req.setRequestPayload(prop.getProperty("connexusharness.GetBasicInfoFilePath"));
        Reporter.log("BasicInnfo Request endpoint: " + req.getUrl());
        Reporter.logJSON("BasicInfo Request", req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("BasicInfo Response", resp.getDataResponse());
        return resp;
    }

}
