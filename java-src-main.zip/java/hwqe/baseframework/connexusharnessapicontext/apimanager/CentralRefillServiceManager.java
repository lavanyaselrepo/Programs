package hwqe.baseframework.connexusharnessapicontext.apimanager;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;

import java.io.IOException;
import java.util.HashMap;

import static hwqe.baseframework.utilities.FileUtils.readFileToString;

public class CentralRefillServiceManager {
    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReader.getInstance();
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;

    public CentralRefillServiceManager() {
        prop.loadCustomProperties("config/connexustestharness/");
    }

    public ServiceResponse createRefillAPI(String createRefillFilePath, int rx_nbr, int rx_id, int store_nbr, int patient_id) throws IOException {

        String file = readFileToString(createRefillFilePath);
        DocumentContext jsonToParse = JsonPath.parse(file);
        jsonToParse.set("$.rxRefill[0].rx_nbr", rx_nbr);
        jsonToParse.set("$.rxRefill[0].rx_id", rx_id);
        jsonToParse.set("$.rxRefill[0].store_nbr", store_nbr);
        jsonToParse.set("$.rxRefill[0].patient_id", patient_id);
        req.setRequestPayloadWithNulls(jsonToParse.json());
        String serviceEndPointURL = StoreIDManager.createEndPointURL(Integer.toString(store_nbr), prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.createRefillEndPoint"));
        req.setUrl(serviceEndPointURL);
        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        Log.info(" Create ReFill RequestPayload:\n"+ req.getRequestPayload()+ "\n");
        ServiceResponse resp = am.getRestContext().performPost(req);
        Log.info("Create ReFill ResponsePayload:\n"+ resp.getDataResponse()+ "\n");
        Reporter.log("Response StatusCode: " + resp.getStatusCode());
        Reporter.logJSON("HTTP Response", resp.getDataResponse());
        return resp;
    }

    public ServiceResponse createRefillAPI(String payload){

        ServiceRequest req = new ServiceRequest();
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(payload, JsonObject.class);
        int storeId = jsonObject.getAsJsonArray("rxRefill")
                .get(0).getAsJsonObject()
                .get("store_nbr").getAsInt();
        String serviceEndPointURL = StoreIDManager.createEndPointURL(Integer.toString(storeId), prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.createRefillEndPoint"));
        req.setUrl(serviceEndPointURL);
        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        req.setRequestPayload(payload);
        Log.info(" Create ReFill RequestPayload:\n"+ req.getRequestPayload()+ "\n");
        ServiceResponse resp = am.getRestContext().performPost(req);
        Log.info("Create ReFill ResponsePayload:\n"+ resp.getDataResponse()+ "\n");
        Reporter.log("Response StatusCode: " + resp.getStatusCode());
        Reporter.logJSON("HTTP Response", resp.getDataResponse());
        return resp;
    }

    public ServiceResponse createRefillInvalidStoreID(String payload){

        ServiceRequest req = new ServiceRequest();
        String serviceEndPointURL = prop.getProperty("connexusharness.createRefillUrl");
        req.setUrl(serviceEndPointURL);
        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        req.setRequestPayload(payload);
        Log.info(" Create ReFill RequestPayload:\n"+ req.getRequestPayload()+ "\n");
        ServiceResponse resp = am.getRestContext().performPost(req);
        Log.info("Create ReFill ResponsePayload:\n"+ resp.getDataResponse()+ "\n");
        Reporter.log("Response StatusCode: " + resp.getStatusCode());
        Reporter.logJSON("HTTP Response", resp.getDataResponse());
        return resp;
    }
}
