package hwqe.baseframework.connexusharnessapicontext.apimanager;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.ServiceUrlManager;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexusharnessapicontext.datamodels.PrescriptionService.CalcRxExpDate3.CalcRxExpDate3Request;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;

import java.util.HashMap;

public class PrescriptionServiceManger {


    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReader.getInstance();
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;
    StoreIDManager storeIDManager = new StoreIDManager();


    /**
     * This method will hit the CalcRxExpDate3 api and return the response
     * @param drugCtrlCode
     * @param rxWrittenDate
     * @param nbrOfRefills
     * @param isAccutaneItem
     * @param productId
     * @param gender
     * @param isMidLevelPrescribers
     * @param prescriberState
     * @param earliestFillDate
     * @param isNursePractitioner
     * @return ServiceResponse
     */

    public ServiceResponse calculateRxExpiryDate(String rxWrittenDate,String nbrOfRefills,Integer drugCtrlCode,boolean isAccutaneItem,Integer productId,
                                                 String gender,boolean isMidLevelPrescribers,String prescriberState,String earliestFillDate,boolean isNursePractitioner) {
        String serviceEndpoint = StoreIDManager.createEndPointURL(prop.getProperty("connexusharness.storeId"), prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.calcrxepdateEndPoint"));
        CalcRxExpDate3Request calcRxExpDate3Request = new CalcRxExpDate3Request();
        calcRxExpDate3Request.setRxWrittenDate(rxWrittenDate);
        if(!"null".equalsIgnoreCase(earliestFillDate)) {
            calcRxExpDate3Request.setEarliestFillDate(earliestFillDate);
        }
        calcRxExpDate3Request.setGender(gender);
        calcRxExpDate3Request.setDrugCtrlCode(drugCtrlCode);
        calcRxExpDate3Request.setMidLevelPrescribers(isMidLevelPrescribers);
        calcRxExpDate3Request.setIsAccutaneItem(isAccutaneItem);
        calcRxExpDate3Request.setNursePractitioner(isNursePractitioner);
        calcRxExpDate3Request.setNbrOfRefills(nbrOfRefills);
        calcRxExpDate3Request.setPrescriberState(prescriberState);
        calcRxExpDate3Request.setProductId(productId);
        req.setUrl(serviceEndpoint);
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        req.setRequestPayload(calcRxExpDate3Request);
        Reporter.log("CalcRxExpDate Request endpoint: " + req.getUrl());
        Reporter.logJSON("CalcRxExpDate Request", req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("CalcRxExpDate Response", resp.getDataResponse());

        return resp;
    }

    /**
     * This method will hit the CalcRxExpDate3 api without request body
     * @return ServiceResponse
     */

    public ServiceResponse calculateRxExpiryDateWithoutRequest() {

        String serviceEndpoint = StoreIDManager.createEndPointURL(prop.getProperty("connexusharness.storeId"), prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.calcrxepdateEndPoint"));
        req.setUrl(serviceEndpoint);
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        Reporter.log("CalcRxExpDate Request endpoint: " + req.getUrl());
        Reporter.logJSON("CalcRxExpDate Request", req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("CalcRxExpDate Response", resp.getDataResponse());

        return resp;
    }



}
