package hwqe.baseframework.connexusharnessapicontext.apimanager;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.ServiceUrlManager;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexusharnessapicontext.datamodels.itemservice.PricingApi.CalcPriceRequest;
import hwqe.baseframework.connexusharnessapicontext.datamodels.itemservice.SearchProductPI.SearchProductPIRequest;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;

import java.util.HashMap;

public class ItemServiceManager {

    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReader.getInstance();
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;

    public ItemServiceManager() {
        prop.loadCustomProperties("config/connexustestharness/");
    }

    public ServiceResponse Calcprice(String MdsFamId, double Qty) {
        String serviceEndpoint = StoreIDManager.createEndPointURL(prop.getProperty("connexusharness.storeId"), prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.calcPriceEndPoint"));
        CalcPriceRequest calcPriceRequest = new CalcPriceRequest();
        calcPriceRequest.setMdsFamId(MdsFamId);
        calcPriceRequest.setQty(Qty);

        req.setUrl(serviceEndpoint);
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        req.setRequestPayload(calcPriceRequest);
        Reporter.log("Calcprice Request endpoint: " + req.getUrl());
        Reporter.logJSON("Calcprice Request", req.getRequestPayload());

        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("Calcprice Response", resp.getDataResponse());

        return resp;
    }

    public ServiceResponse CallSearchProductPIAPI(String productName, String form, String strength, String ndcNbr, String genericName, boolean showDiscontinued, boolean showInactivated, boolean isBreakable, String gpi, String upcNumber, Integer itemNumber, Integer maxRows, Integer mdsFamId) {
        String serviceEndpoint = StoreIDManager.createEndPointURL(prop.getProperty("connexusharness.storeId"), prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.searchProductPIEndPoint"));
        SearchProductPIRequest searchProductPIRequest = new SearchProductPIRequest();
        searchProductPIRequest.setProductName(productName);
        searchProductPIRequest.setForm(form);
        searchProductPIRequest.setStrength(strength);
        searchProductPIRequest.setNdcNbr(ndcNbr);
        searchProductPIRequest.setGenericName(genericName);
        searchProductPIRequest.setShowDiscontinued(showDiscontinued);
        searchProductPIRequest.setShowInactivated(showInactivated);
        searchProductPIRequest.setIsBreakable(isBreakable);
        searchProductPIRequest.setGpi(gpi);
        searchProductPIRequest.setUpcNumber(upcNumber);
        searchProductPIRequest.setItemNumber(itemNumber);
        searchProductPIRequest.setMaxRows(maxRows);
        searchProductPIRequest.setMdsFamId(mdsFamId);
        req.setUrl(serviceEndpoint);
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        req.setRequestPayload(searchProductPIRequest);
        Reporter.log("SearchProductPI Request endpoint: " + req.getUrl());
        Reporter.logJSON("SearchProductPI Request", req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("SearchProductPI Response", resp.getDataResponse());
        return resp;
    }
}
