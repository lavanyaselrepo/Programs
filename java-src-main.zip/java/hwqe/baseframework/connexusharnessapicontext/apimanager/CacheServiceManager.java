package hwqe.baseframework.connexusharnessapicontext.apimanager;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.utilities.PropertyReader;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.util.HashMap;

public class CacheServiceManager {
    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReader.getInstance();
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;
    public CacheServiceManager() {
        prop.loadCustomProperties("config/connexustestharness/");
    }
    public void callFlushCacheAPI(String siteID) {
        String serviceEndPointURL = StoreIDManager.createEndPointURL(siteID, prop.getProperty("connexustestharness.cacheService.portNo"), prop.getProperty("connexustestharness.sapsUrl.http"), prop.getProperty("connexustestharness.flushCacheEndPoint"));
        req.setUrl(serviceEndPointURL);
        headers.put("Content-Type", "application/json");
        req.setHeaders(headers);
        resp = am.getRestContext().performPost(req);
        Log.info("Flush Cache Successful");
        Assert.assertEquals(resp.getStatusCode(), 200, "Flush Cache Successful");
    }
}
