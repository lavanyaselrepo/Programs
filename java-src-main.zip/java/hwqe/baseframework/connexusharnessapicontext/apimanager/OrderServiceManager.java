package hwqe.baseframework.connexusharnessapicontext.apimanager;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexusharnessapicontext.datamodels.orderservice.FourPtChkCompleteRequest;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;

import java.io.IOException;
import java.util.HashMap;

public class OrderServiceManager {
    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReader.getInstance();
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;

    public OrderServiceManager() {
        prop.loadCustomProperties("config/connexustestharness/");
    }


    public ServiceResponse validate4ptCompleted(int OrderId, int OrderSeqNbr, boolean ReEntryCheck, int SiteID) throws IOException {


        FourPtChkCompleteRequest fourPtChkCompleteRequest = new FourPtChkCompleteRequest();

        fourPtChkCompleteRequest.setOrderId(OrderId);
        fourPtChkCompleteRequest.setOrderSeqNbr(OrderSeqNbr);
        fourPtChkCompleteRequest.setReEntryCheck(ReEntryCheck);
        fourPtChkCompleteRequest.setSiteID(SiteID);

        req.setRequestPayloadWithNulls(fourPtChkCompleteRequest);
        String serviceEndPointURL = StoreIDManager.createEndPointURL(Integer.toString(SiteID), prop.getProperty("connexustestharness.common.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexusharness.check4PtCompletedEndPoint"));
        req.setUrl(serviceEndPointURL);
        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        Reporter.log("validate4ptCompleted API Endpoint:" + req.getUrl());
        Log.info("validate4ptCompleted RequestPayload:\n"+ req.getRequestPayload()+ "\n");
        resp = am.getRestContext().performPost(req);
        Log.info("validate4ptCompleted ResponsePayload:\n"+ resp.getDataResponse()+ "\n");
        return resp;
    }

}
