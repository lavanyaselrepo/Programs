package hwqe.baseframework.connexusharnessapicontext.apimanager;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexusharnessapicontext.datamodels.localsiteservice.IsStoreOpen.IsStoreOpenRequest;
import hwqe.baseframework.utilities.PropertyReader;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.io.IOException;
import java.util.HashMap;

public class LocalSiteServiceManager {
    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReader.getInstance();
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;
    public LocalSiteServiceManager() {
        prop.loadCustomProperties("config/connexustestharness/");
    }

    public ServiceResponse callIsStoreOpenAPI(int station, String siteID) throws IOException {
        IsStoreOpenRequest isStoreOpenRequest = new IsStoreOpenRequest();
        String serviceEndPointURL = StoreIDManager.createEndPointURL(siteID, prop.getProperty("connexustestharness.localSiteService.portNo"), prop.getProperty("connexustestharness.sapsUrl.https"), prop.getProperty("connexustestharness.isStoreOpenEndPoint"));
        req.setUrl(serviceEndPointURL);
        headers.put("Content-Type", "application/json");
        req.setHeaders(headers);
        isStoreOpenRequest.setStation(station);
        isStoreOpenRequest.setSiteID(siteID);
        req.setRequestPayload(isStoreOpenRequest);
        Log.info("IsStoreOpen API RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req);
        Log.info("IsStoreOpen ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }
}
