
package hwqe.baseframework.connexusharnessapicontext;

import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;

public class ServiceUrlManager {

    static PropertyReader prop = PropertyReader.getInstance();

    public static Object serviceRequest(String storeNo, String serviceEndPoint) {

        String url = prop.getProperty("connexusharness.sapsServiceUrl");
        String storeNumber = storeNo;
        if (storeNumber.length() == 4) {
            storeNumber = "0" + storeNumber;
        }
        if (Integer.parseInt(storeNo) != 0) {
            url = url.replace("XXXXX", storeNumber);
        } else {
            url = url.replace("XXXXX", String.valueOf(32080));
        }
        serviceEndPoint = url + serviceEndPoint;

        Reporter.log(" URLV+++++ : " + serviceEndPoint);
        System.out.println(" URLV+++++ : " + serviceEndPoint);

        return serviceEndPoint;
    }

}