package hwqe.baseframework.connexusharnessapicontext;

import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;

public class StoreIDManager {

    static PropertyReader prop = PropertyReader.getInstance();

    public static Object apiRequest(int storeNo, String serviceEndPoint) {

        String url = prop.getProperty("connexusharness.sapsUrl");
        String storeNumber = Integer.toString(storeNo);
        if (storeNumber.length() == 4) {
            storeNumber = "0" + storeNumber;
        }
        if (storeNo != 0) {
            url = url.replace("XXXXX", storeNumber);
        } else {
            url = url.replace("XXXXX", String.valueOf(32080));
        }
        serviceEndPoint = url + serviceEndPoint;

        Reporter.log(" URLV+++++ : " + serviceEndPoint);
        Log.info(" URLV+++++ : " + serviceEndPoint);
        return serviceEndPoint;
    }

    public static String createEndPointURL(String storeNumber, String portNo, String url, String endPoint) {
        if (storeNumber.length() == 4) {
            storeNumber = "0" + storeNumber;
        }
        if (!storeNumber.isEmpty()) {
            url = url.replace("XXXXX", storeNumber);
        } else {
            url = url.replace("XXXXX", String.valueOf(32080));
        }
        if (!portNo.isEmpty()) {
            url = url.replace("YYYYY", portNo);
        }
        String serviceEndPoint = url + endPoint;
        Reporter.log("Service End Point: " + serviceEndPoint);
        Log.info("Service End Point: " + serviceEndPoint);
        return serviceEndPoint;
    }
}
