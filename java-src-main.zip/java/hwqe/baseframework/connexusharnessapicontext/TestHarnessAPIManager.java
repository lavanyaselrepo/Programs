package hwqe.baseframework.connexusharnessapicontext;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jayway.jsonpath.JsonPath;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.DropOffQueueRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Drug;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import net.minidev.json.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import com.jayway.jsonpath.DocumentContext;
import java.io.IOException;
import java.rmi.ServerException;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import static hwqe.baseframework.utilities.FileUtils.readFileToString;


public class TestHarnessAPIManager {

    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReader.getInstance();
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;

    public TestHarnessAPIManager() {
        prop.loadCustomProperties("config/connexustestharness/");
    }


    public ServiceResponse AddPatient(String Payload) {

        String serviceEndpoint = ServiceUrlManager.serviceRequest(prop.getProperty("connexusharness.storeId"), prop.getProperty("connexusharness.addPatientEndPoint")).toString();

        req.setUrl(serviceEndpoint);
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        req.setRequestPayload(Payload);
        Reporter.log("AddPatient Request endpoint: " + req.getUrl());
        Reporter.logJSON("AddPatient Request", req.getRequestPayload());

        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("AddPatient Response", resp.getDataResponse());
        return resp;

    }


    public ServiceResponse createOrderAndMoveTo4point(int requestTypeCode, int priorityId, int dispenseType, int patientId, int siteId, String inputPickUpDate, String inputRxExpDate, int numRefills, DataRow drugInfo) {

        DropOffQueueRequest dropoffRequest = new DropOffQueueRequest();
        Drug drug = new Drug();

        dropoffRequest.setRequestTypeCode(requestTypeCode);
        dropoffRequest.setPriorityId(priorityId);
        dropoffRequest.setDispenseType(dispenseType);
        dropoffRequest.setPatientId(patientId);
        dropoffRequest.setSiteID(siteId);
        dropoffRequest.setInputPickUpDate(inputPickUpDate);
        dropoffRequest.setInputRxExpDate(inputRxExpDate);
        dropoffRequest.setNumRefills(numRefills);
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr"));
        drug.setItemId(drugInfo.getValue("mds_fam_id"));
        drug.setRxProdId(drugInfo.getValue("product_mds_fam_id"));
        drug.setControlCode(drugInfo.getValue("drug_control_code"));
        drug.setPresMultiSrcCode(drugInfo.getValue("multi_source_code"));
        drug.setOnHandQty(Integer.parseInt(drugInfo.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
        drug.setGpiCode(drugInfo.getValue("gpi_code"));
        drug.setUsualCost("0");
        drug.setActCost("0");
        drug.setOrgUsualCost("0");
        dropoffRequest.setDrug(drug);

        req.setRequestPayloadWithNulls(dropoffRequest);
        req.setUrl(prop.getProperty("connexusharness.newOrderTo4PointCompleteUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("CreateOrderMoveTo4Pt Request endpoint: " + req.getUrl());
        Log.info("CreateOrderMoveTo4Pt RequestPayload:\n"+ req.getUrl()+ "\n");
        Reporter.logJSON("CreateOrderMoveTo4Pt Request", req.getRequestPayload());
        Log.info("CreateOrderMoveTo4Pt RequestPayload:\n"+ req.getRequestPayload()+ "\n");
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("CreateOrderMoveTo4Pt Response", resp.getDataResponse());
        Log.info("CreateOrderMoveTo4Pt ResponsePayload:\n"+ resp.getDataResponse()+ "\n");
        return resp;
    }

    public void rxLookUpAPI(String rxLookupInfoFilePath, int RxFillID) throws IOException {

        String file = readFileToString(rxLookupInfoFilePath);
        DocumentContext jsonToParse = JsonPath.parse(file);
        jsonToParse.set("$.barcode", "4793" + RxFillID);
        int storeId = jsonToParse.read("$.SiteID");
        req.setRequestPayloadWithNulls(jsonToParse.json());
        String serviceEndPointURL = StoreIDManager.apiRequest(storeId, prop.getProperty("connexusharness.rxLookupEndPoint")).toString();
        req.setUrl(serviceEndPointURL);
        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        Reporter.log("RxLookup API Endpoint:" + req.getUrl());
        System.out.println("RxLookup API RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req);
        Log.info("RxLookup ResponsePayload:\n" + resp.getDataResponse() + "\n");
        Assert.assertNotNull(resp);
        Assert.assertEquals(resp.getStatusCode(), 200, "Expected status code 200 but found " + resp.getStatusCode());
    }

    public int addPatient(String addPatientFilePath) throws IOException {

        String file = readFileToString(addPatientFilePath);
        DocumentContext jsonToParse = JsonPath.parse(file);
        req.setRequestPayloadWithNulls(jsonToParse.json());
        req.setUrl(prop.getProperty("connexusharness.addPatientUrl"));
        headers.put("Content-Type", "application/json");
        req.setHeaders(headers);
        Reporter.log("Add Patient Request endpoint: " + req.getUrl());
        Log.info("Add Patient Request Payload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req);
        Log.info("Add Patient Response Payload:\n" + resp.getDataResponse() + "\n");
        Assert.assertNotNull(resp);
        Assert.assertEquals(resp.getStatusCode(), 201, "Expected status code 201 but found " + resp.getStatusCode());
        Gson gson = new Gson();
        JsonObject json = gson.fromJson(resp.getDataResponse(), JsonObject.class);
        return json.get("patientId").getAsInt();
    }

    public DataRow getPatientInfo(IDatabaseContext cnx, String patientId) {
        String getPatientInfo = "select *\n" +
                "from patient as pi \n" +
                "where pi.patient_id =" + patientId + "";
        DataTable dt = cnx.getDataTable(getPatientInfo);
        Assert.assertEquals(dt.getRowCount(), 1);
        DataRow row = dt.getDataRows().get(0);
        return row;
    }

    public DataRow getPatientAddressInfo(IDatabaseContext cnx, String patientId) {
        String getPatientAddressInfo = "select *\n" +
                "from subject_address as sa \n" +
                "where sa.subject_id =" + patientId + "";
        DataTable dt = cnx.getDataTable(getPatientAddressInfo);
        Assert.assertEquals(dt.getRowCount(), 1);
        DataRow row = dt.getDataRows().get(0);
        return row;
    }

    public DataRow getPatientCommunicationInfo(IDatabaseContext cnx, String patientId) {
        String getPatientCommunicationInfo = "select *\n" +
                "from subject_comm as sa \n" +
                "where sa.subject_id =" + patientId + "";
        DataTable dt = cnx.getDataTable(getPatientCommunicationInfo);
        Assert.assertEquals(dt.getRowCount(), 1);
        DataRow row = dt.getDataRows().get(0);
        return row;
    }

    public void validatePatientInfo(String patientId, String payload) throws IOException {
        IDatabaseContext cnx = am.getConnexusDB(Integer.parseInt(prop.getProperty("connexusharness.storeId")));
        DataRow patientInfo = getPatientInfo(cnx, patientId);

        DocumentContext jsonToParse = JsonPath.parse(payload);

        Assert.assertEquals(jsonToParse.read("$.Patient.PatGeneralInfo.PersonalInfo.FirstName").toString().trim(), patientInfo.getValue("first_name").toString().trim());
        Assert.assertEquals(jsonToParse.read("$.Patient.PatGeneralInfo.PersonalInfo.LastName").toString().trim(), patientInfo.getValue("last_name").toString().trim());
        Assert.assertEquals(jsonToParse.read("$.Patient.PatGeneralInfo.PersonalInfo.MiddleName").toString().trim(), patientInfo.getValue("middle_name").toString().trim());
        Assert.assertEquals(jsonToParse.read("$.Patient.PatGeneralInfo.PersonalInfo.Language").toString().trim(), patientInfo.getValue("pref_language_code").toString().trim());
        Assert.assertEquals(jsonToParse.read("$.Patient.PatGeneralInfo.PersonalInfo.Gender").toString().trim(), patientInfo.getValue("gender_code").toString().trim());
        Assert.assertEquals(jsonToParse.read("$.Patient.PatGeneralInfo.PersonalInfo.Status").toString().trim(), patientInfo.getValue("status_code").toString().trim());
        Assert.assertNotNull(patientInfo.getValue("birth_date").toString().trim());
        Assert.assertEquals(jsonToParse.read("$.Patient.PatGeneralInfo.PrimaryPrescriberInformation.PrescriberId").toString().trim(), patientInfo.getValue("pri_prescriber_id").toString().trim());
        Assert.assertEquals(jsonToParse.read("$.Patient.PatGeneralInfo.OtherInformation.ChargeCode").toString().trim(), patientInfo.getValue("charge_freq_code").toString().trim());
        Assert.assertEquals(jsonToParse.read("$.Patient.PatGeneralInfo.OtherInformation.MailOutCode").toString().trim(), patientInfo.getValue("mail_out_freq_code").toString().trim());
        Assert.assertEquals(jsonToParse.read("$.Patient.PatGeneralInfo.HipaaInformation.HipaaStatusCode").toString().trim(), patientInfo.getValue("hipaa_status_code").toString().trim());
        Assert.assertEquals(jsonToParse.read("$.Patient.PatGeneralInfo.PatientTypeCode").toString().trim(), patientInfo.getValue("patient_type_code").toString().trim());

    }

    public void validateAddressInfo(String patientId, String payload) throws IOException, ParseException {
        IDatabaseContext cnx = am.getConnexusDB(Integer.parseInt(prop.getProperty("connexusharness.storeId")));
        DataRow addressInfo = getPatientAddressInfo(cnx, patientId);

        DocumentContext jsonToParse = JsonPath.parse(payload);

        JSONArray jsonArray = jsonToParse.read("$.Patient.PatGeneralInfo.PersonalInfo.AddressInformation");
        JSONObject jo = new JSONObject();
        jo.put("AddressInformation", jsonArray.get(0));
        DocumentContext jsonToParseAddress = JsonPath.parse(jo);

        Assert.assertEquals(jsonToParseAddress.read("$.AddressInformation.AddressTypeCode").toString().trim(), addressInfo.getValue("addr_type_code").toString().trim());
        Assert.assertEquals(jsonToParseAddress.read("$.AddressInformation.AddressLine1").toString().trim(), addressInfo.getValue("address_line_1").toString().trim());
        Assert.assertEquals(jsonToParseAddress.read("$.AddressInformation.AddressLine2").toString().trim(), addressInfo.getValue("address_line_2").toString().trim());
        Assert.assertEquals(jsonToParseAddress.read("$.AddressInformation.City").toString().trim(), addressInfo.getValue("city_name").toString().trim());
        Assert.assertEquals(jsonToParseAddress.read("$.AddressInformation.State").toString().trim(), addressInfo.getValue("state_prov_code").toString().trim());
        Assert.assertEquals(jsonToParseAddress.read("$.AddressInformation.ZipCode").toString().trim(), addressInfo.getValue("postal_code").toString().trim());
        Assert.assertEquals(jsonToParseAddress.read("$.AddressInformation.Country").toString().trim(), addressInfo.getValue("country_code").toString().trim());
        Assert.assertEquals(jsonToParseAddress.read("$.AddressInformation.VerifyFreqCode").toString().trim(), addressInfo.getValue("verify_freq_code").toString().trim());

    }

    public void validateCommunicationInfo(String patientId, String payload) throws IOException, ParseException {
        IDatabaseContext cnx = am.getConnexusDB(Integer.parseInt(prop.getProperty("connexusharness.storeId")));
        DataRow communicationInfo = getPatientCommunicationInfo(cnx, patientId);

        DocumentContext jsonToParse = JsonPath.parse(payload);

        JSONArray jsonArray = jsonToParse.read("$.Patient.PatCommunicationRedesignInfo");
        JSONObject jo = new JSONObject();
        jo.put("CommunicationInformation", jsonArray.get(0));
        DocumentContext jsonToParseComm = JsonPath.parse(jo);

        Assert.assertEquals(jsonToParseComm.read("$.CommunicationInformation.CommMethodCode").toString().trim(), communicationInfo.getValue("comm_method_code").toString().trim());
        Assert.assertEquals(jsonToParseComm.read("$.CommunicationInformation.CommSequenceNbr").toString().trim(), communicationInfo.getValue("comm_seq_nbr").toString().trim());
        Assert.assertEquals(jsonToParseComm.read("$.CommunicationInformation.CommunicationID").toString().trim(), communicationInfo.getValue("communication_id").toString().trim());
    }


}
