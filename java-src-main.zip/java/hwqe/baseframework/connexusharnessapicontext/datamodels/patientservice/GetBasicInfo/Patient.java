package hwqe.baseframework.connexusharnessapicontext.datamodels.patientservice.GetBasicInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Patient {
    @JsonProperty("PrimaryThirdParty")
    private primaryThirdParty PrimaryThirdParty;
    @JsonProperty("PatGeneralInfo")
    private patGeneralInfo PatGeneralInfo;
}
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
class primaryThirdParty {
    @JsonProperty("RelationshipCode")
    private int RelationshipCode;
    @JsonProperty("PlanTypeCode")
    private int PlanTypeCode;
    @JsonProperty("IcpInfo")
    private icpInfo IcpInfo;
}
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
class icpInfo
{
    @JsonProperty("PlanId")
    private int PlanId;
    @JsonProperty("CardHolderId")
    private int CardHolderId;
}
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
class patGeneralInfo {
    @JsonProperty("PersonalInfo")
    private personalInfo PersonalInfo;
    @JsonProperty("OtherInformation")
    private otherInformation OtherInformation;
    @JsonProperty("HipaaInformation")
    private hipaaInformation HipaaInformation;
}
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
class personalInfo {
    @JsonProperty("FirstName")
    private String FirstName;
    @JsonProperty("LastName")
    private String LastName;
    @JsonProperty("Gender")
    private String Gender;
    @JsonProperty("Language")
    private String Language;
    @JsonProperty("Status")
    private String Status;
}
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
class otherInformation {
    @JsonProperty("ChargeCode")
    private int ChargeCode;
    @JsonProperty("MailOutCode")
    private int MailOutCode;
}
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
class hipaaInformation {
    @JsonProperty("HipaaStatusCode")
    private int HipaaStatusCode;
}







