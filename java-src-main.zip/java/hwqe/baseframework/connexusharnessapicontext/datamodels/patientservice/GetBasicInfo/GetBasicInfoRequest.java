package hwqe.baseframework.connexusharnessapicontext.datamodels.patientservice.GetBasicInfo;

import lombok.Data;

@Data
public class GetBasicInfoRequest {

    private int PatientID;
    private int SiteID;
}
