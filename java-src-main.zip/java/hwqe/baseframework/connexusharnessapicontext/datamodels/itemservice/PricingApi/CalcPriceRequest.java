package hwqe.baseframework.connexusharnessapicontext.datamodels.itemservice.PricingApi;

import lombok.Data;

@Data
public class CalcPriceRequest {
	
	 private Object MdsFamId;
	 private double Qty;
	 private boolean PatientResident;
	 private boolean TPTaxable;
	 private boolean CashRx;
	 private Object CalcTaxesInfoBE;
	 private double DaysSupply;
	 private int PatientId;
	 private Object BrandNDCNbr;
	 private boolean AdjustBrandPrice;
	 private double GenericProfit;
	 private boolean NoActiveGenerics;
	 private Object UserId;
	 private int RxFillId;
	 private Object ScreenName;
	 private int SiteID;
}
