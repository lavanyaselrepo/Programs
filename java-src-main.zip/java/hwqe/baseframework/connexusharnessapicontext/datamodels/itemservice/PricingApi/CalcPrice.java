package hwqe.baseframework.connexusharnessapicontext.datamodels.itemservice.PricingApi;

import lombok.Data;

@Data
public class CalcPrice {


	private double AcqCost;
	private double AwpCost;
	private double AwpMacCost;
	private String BrandGenericProfitPricingErrorText;
	private double BrandPrice;
	private double CompetitionPrice;
	private double CorporatePrice;

	private double CostTypeCode;
	private double CustomerCost;
	private double MarkUpAmount;
	private boolean OmsPriceFailureInd;
	private int PriceClassCode;
	private boolean PriceClassMissingInd;
	private boolean PricingFallbackFailureInd;
	private double SmartRetail;
	private double USCustomerCABorderCost;
	private double USCustomerCanadaApsiCost;
	private double USCustomerCanadaDirCost;
	private double USStdCARetailCost;
	private double WHPCInd;
	private double whpc;


}
