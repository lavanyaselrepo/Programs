package hwqe.baseframework.connexusharnessapicontext.datamodels.itemservice.PricingApi;

import lombok.Data;

@Data
public class CalcPriceResponse {

	private CalcPrice CalcPrice;



}
