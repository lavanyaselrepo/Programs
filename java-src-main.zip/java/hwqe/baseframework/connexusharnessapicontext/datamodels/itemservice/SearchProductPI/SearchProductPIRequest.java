package hwqe.baseframework.connexusharnessapicontext.datamodels.itemservice.SearchProductPI;

import lombok.Data;

@Data
public class SearchProductPIRequest {
    private Object ProductName;
    private Object Form;
    private Object Strength;
    private Object NdcNbr;
    private Object GenericName;
    private boolean ShowDiscontinued;
    private boolean ShowInactivated;
    private boolean IsBreakable;
    private Object Gpi;
    private Object UpcNumber;
    private Integer ItemNumber;
    private int MaxRows;
    private Integer MdsFamId;
}
