package hwqe.baseframework.connexusharnessapicontext.datamodels.itemservice.SearchProductPI;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchProductPIDBAndResponse {
    @JsonProperty("MdsFamId")
    private int MdsFamId;
    @JsonProperty("ShortName")
    private String ShortName;
    @JsonProperty("GenericName")
    private String GenericName;
    @JsonProperty("DrugControlCode")
    private short DrugControlCode;
    @JsonProperty("StatusCode")
    private short StatusCode;
    @JsonProperty("MultiSourceCode")
    private short MultiSourceCode;
    @JsonProperty("ProductName")
    private String ProductName;
    @JsonProperty("InnerPackQty")
    private int InnerPackQty;
}
