package hwqe.baseframework.connexusharnessapicontext.datamodels.PrescriptionService.CalcRxExpDate3;


import lombok.Data;

@Data
public class CalcRxExpDate3Request {
    private String RxWrittenDate;
    private String nbrOfRefills;
    private Integer drugCtrlCode;
    private boolean IsAccutaneItem;
    private Integer ProductId;
    private String Gender;
    private boolean isMidLevelPrescribers;
    private String prescriberState;
    private String EarliestFillDate;
    private boolean isNursePractitioner;
    private Integer SiteID;
}
