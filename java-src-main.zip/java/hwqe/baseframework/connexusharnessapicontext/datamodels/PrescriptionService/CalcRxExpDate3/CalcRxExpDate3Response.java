package hwqe.baseframework.connexusharnessapicontext.datamodels.PrescriptionService.CalcRxExpDate3;

import lombok.Data;

@Data
public class CalcRxExpDate3Response {
    private String expDate;
}
