package hwqe.baseframework.connexusharnessapicontext.datamodels.beaconservice.GetStationCounts;

import lombok.Data;

@Data
public class CycleCounts {

    public int completedCount;
    public int pendingCount;
}
