package hwqe.baseframework.connexusharnessapicontext.datamodels.beaconservice.GetStationCounts;
import lombok.Data;

@Data
public class RTS {


    public int completedCount;
    public int pendingCount;
}
