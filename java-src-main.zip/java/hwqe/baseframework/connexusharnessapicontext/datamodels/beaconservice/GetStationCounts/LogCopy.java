package hwqe.baseframework.connexusharnessapicontext.datamodels.beaconservice.GetStationCounts;
import lombok.Data;

@Data
public class LogCopy {

    public int pendingBatches;
    public int pendingCount;
}
