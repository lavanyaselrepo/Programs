package hwqe.baseframework.connexusharnessapicontext.datamodels.beaconservice.GetStationCounts;
import lombok.Data;

@Data
public class Filling {

    public int completedCount;
    public int due2hours;
    public int due30mins;
    public int due48hours;
    public int dueFuture;
    public int pendingCount;

}
