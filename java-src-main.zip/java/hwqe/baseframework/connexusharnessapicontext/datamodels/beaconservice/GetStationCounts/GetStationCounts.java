package hwqe.baseframework.connexusharnessapicontext.datamodels.beaconservice.GetStationCounts;

import lombok.Data;

@Data
public class GetStationCounts {


	public CycleCounts CycleCounts;
	public Filling Filling;
	public LogCopy LogCopy;
	public RTS RTS;

}
