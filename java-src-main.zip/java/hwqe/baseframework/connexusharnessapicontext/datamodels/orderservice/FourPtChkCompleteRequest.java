package hwqe.baseframework.connexusharnessapicontext.datamodels.orderservice;

import lombok.Data;

@Data
public class FourPtChkCompleteRequest {

    int OrderId;
    int OrderSeqNbr;
    boolean ReEntryCheck;
    int SiteID;
}
