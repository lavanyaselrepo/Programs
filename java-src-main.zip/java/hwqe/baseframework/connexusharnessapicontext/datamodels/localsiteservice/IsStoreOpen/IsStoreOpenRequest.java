package hwqe.baseframework.connexusharnessapicontext.datamodels.localsiteservice.IsStoreOpen;

import lombok.Data;

@Data
public class IsStoreOpenRequest {
    private int Station;
    private String SiteID;
}
