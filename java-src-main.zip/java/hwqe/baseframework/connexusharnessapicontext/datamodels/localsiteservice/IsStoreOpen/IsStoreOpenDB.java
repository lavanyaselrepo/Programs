package hwqe.baseframework.connexusharnessapicontext.datamodels.localsiteservice.IsStoreOpen;

@lombok.Getter
@lombok.Setter
public class IsStoreOpenDB {
    private long phm_parm_value;
}
