package hwqe.baseframework.datacontext;

import lombok.Data;

/**
 * @author Tushar Ranjan(t0r07b9)
 * @project AutomationBaseFramework
 * @created 8/11/2022
 */
@Data
public class SqlAdCredentials {
    private String serverName;
    private String databaseName;
    private String userName;
    private String password;
    private String authentication;
    private int port;
    private boolean isTrustServerCertificate;
    private String hostNameInCertificate;
    private boolean isEncrypt;
}
