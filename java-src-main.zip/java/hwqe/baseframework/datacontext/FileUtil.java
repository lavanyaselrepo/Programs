package hwqe.baseframework.datacontext;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Base64;

import org.openjdk.tools.sjavac.Log;

public class FileUtil {
    private FileUtil() {
        throw new IllegalStateException("Utility Class");
    }

    /**
     * Decode certificate file and create a file at temp location to be used for SSL
     *
     * @param trustStoreBase64 base 64 encoded string
     * @param expectedName     file name
     * @return file path
     */
    public static String getJksFileLocation(String trustStoreBase64, String expectedName) {

        byte[] tsFileByteArray = Base64.getDecoder().decode(trustStoreBase64);

        try {
            String tmpdir = Files.createTempDirectory("sslCerts").toFile().getAbsolutePath();
            File tempFile = File.createTempFile(expectedName, ".jks", new File(tmpdir));
            try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                fos.write(tsFileByteArray);
            }
            return tempFile.getAbsolutePath();
        } catch (IOException e) {
            Log.error("An Exception occurred while getting Jks File :" + e.getMessage());
        }
        return null;
    }
}
