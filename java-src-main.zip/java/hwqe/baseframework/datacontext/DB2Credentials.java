package hwqe.baseframework.datacontext;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DB2Credentials {
    private String serverName;
    private int portNumber;
    private String databaseName;
    private String trustStore;
    private String keyStore;
    private String keyStorePassword;
    private String currentSchema;
}
