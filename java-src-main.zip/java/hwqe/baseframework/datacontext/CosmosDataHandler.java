package hwqe.baseframework.datacontext;

import java.util.HashMap;
import java.util.Map;

import hwqe.baseframework.AutomationManager;

public class CosmosDataHandler {

    private final CosmosContext cosmosContext;
    AutomationManager am = AutomationManager.getInstance();

    public CosmosDataHandler(CosmosContext cosmosContext) {
        this.cosmosContext = cosmosContext;
    }

    /**
     * Fetches data from Cosmos DB based on the test case name.
     *
     * @param testCaseName The name of the test case.
     * @return The key-value pairs associated with the test case name.
     */
    public Map<String, Object> fetchData(String testCaseName) {
        if (testCaseName == null || testCaseName.isEmpty()) {
            throw new IllegalArgumentException("Test case name must be provided.");
        }

        return cosmosContext.fetchTestCaseData("regression_test_data", testCaseName);
    }

    /**
     * Generates key-value pairs dynamically and returns the whole set if finished.
     *
     * @param finished Indicates whether the test case execution is finished.
     * @param key The key to add to the map.
     * @param value The value to associate with the key.
     * @return A map containing the generated key-value pairs if finished, otherwise null.
     */
    public Map<String, Object> generateKeyValuePairs(boolean finished, String key, String value) {
        Map<String, Object> keyValuePairs = new HashMap<>();
        keyValuePairs.put(key, value);

        if (finished) {
            Map<String, Object> result = new HashMap<>(keyValuePairs);
            keyValuePairs.clear(); // Clear the map for future use
            return result;
        }

        return null; // Return null if not finished
    }

    /**
     * Fetches specific values from the stored key-value pairs based on the test case name and keys provided.
     *
     * @param testCaseName The name of the test case.
     * @param keys The keys to fetch values for.
     * @return A map containing the requested key-value pairs.
     */
    public Map<String, Object> fetchValuesByKeys(String testCaseName, String... keys) {
        if (testCaseName == null || testCaseName.isEmpty()) {
            throw new IllegalArgumentException("Test case name must be provided.");
        }

        Map<String, Object> existingData = this.fetchData(testCaseName);
        if (existingData == null) {
            return new HashMap<>();
        }

        Map<String, Object> filteredData = new HashMap<>();
        for (String key : keys) {
            if (existingData.containsKey(key)) {
                filteredData.put(key, existingData.get(key));
            }
        }

        return filteredData;
    }

    /**
     * Saves data into Cosmos DB based on the test case name.
     *
     * @param testCaseName The name of the test case.
     * @param data The key-value pairs to save.
     */
    private void saveData(String testCaseName, Map<String, Object> data) {

        if (testCaseName == null || testCaseName.isEmpty()) {
            throw new IllegalArgumentException("Test case name must be provided.");
        }

        cosmosContext.saveTestCaseData("regression_test_data", testCaseName, data);
    }

    /**
     * Initializes a map with mandatory fields for a test case.
     *
     * @param testCaseName The name of the test case.
     * @return A map containing mandatory fields.
     */
    public Map<String, Object> initializeTestCaseMap(String testCaseName) {
        if (testCaseName == null || testCaseName.isEmpty()) {
            throw new IllegalArgumentException("Test case name must be provided.");
        }

        Map<String, Object> testCaseMap = new HashMap<>();
        testCaseMap.put("startTimestamp", System.currentTimeMillis());
        testCaseMap.put("endTimestamp", null); // End timestamp will be set later
        return testCaseMap;
    }

    /**
     * Adds key-value pairs to the test case map during execution.
     *
     * @param testCaseMap The map representing the test case.
     * @param key The key to add.
     * @param value The value to associate with the key.
     */
    public void addValuesToMap(Map<String, Object> testCaseMap, String key, Object value) {
        if (testCaseMap == null) {
            throw new IllegalArgumentException("Test case map must be initialized.");
        }

        testCaseMap.put(key, value);
    }

    public void publishTestCaseDataByName(String testCaseName, Map<String, Object> testCaseMap, boolean keepExisting) {
        if (testCaseName == null || testCaseName.isEmpty()) {
            throw new IllegalArgumentException("Test case name must be provided.");
        }

        if (testCaseMap == null) {
            throw new IllegalArgumentException("Test case map must be initialized.");
        }

        // Set endTimestamp
        testCaseMap.put("endTimestamp", System.currentTimeMillis());

        Map<String, Object> existingTestCaseData = this.fetchData(testCaseName);

        if (existingTestCaseData == null) {
            existingTestCaseData = new HashMap<>();
        }

        if (keepExisting) {
            existingTestCaseData.putAll(testCaseMap);
        } else {
            existingTestCaseData = testCaseMap;
        }

        this.saveData(testCaseName, existingTestCaseData);
    }
}
