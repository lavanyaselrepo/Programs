package hwqe.baseframework.datacontext;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Excel context for reading .xlsx files.
 * POI 5.x requires proper resource management - use try-with-resources.
 */
public class XlsContext implements AutoCloseable {
    private Workbook workbook;
    private Sheet sheet;
    private FormulaEvaluator formulaEvaluator;

    public XlsContext(String filePath, String sheetName) {
        try (FileInputStream inputStream = new FileInputStream(new File(filePath))) {
            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheet(sheetName);
            formulaEvaluator = workbook.getCreationHelper().createFormulaEvaluator();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public XlsContext(InputStream fileStream, String sheetName) {
        try {
            workbook = new XSSFWorkbook(fileStream);
            sheet = workbook.getSheet(sheetName);
            formulaEvaluator = workbook.getCreationHelper().createFormulaEvaluator();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public XlsContext(String filePath, int sheetIndex) {
        try (FileInputStream inputStream = new FileInputStream(new File(filePath))) {
            workbook = new XSSFWorkbook(inputStream);
            sheet = workbook.getSheetAt(sheetIndex);
            formulaEvaluator = workbook.getCreationHelper().createFormulaEvaluator();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public <T> List<T> getColumnValues(int index) {
        try {
            List<T> lst = new ArrayList<>();
            Iterator<Row> iterator = sheet.iterator();
            while (iterator.hasNext()) {
                Row nextRow = iterator.next();
                try {
                    lst.add((T) getCellValue(nextRow.getCell(index)));
                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                }
            }
            return lst;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return new ArrayList<>();
    }

    public <T> List<T> getRowValues(int index) {
        try {
            List<T> lst = new ArrayList<>();
            Row row = sheet.getRow(index);
            Iterator<Cell> cellIterator = row.cellIterator();
            while (cellIterator.hasNext()) {
                try {
                    lst.add((T) getCellValue(cellIterator.next()));
                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                }
            }
            return lst;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return new ArrayList<>();
    }

    public <T> T getCellValues(int rowIndex, int columnIndex) {
        try {
            Row row = sheet.getRow(rowIndex);
            return (T) getCellValue(row.getCell(columnIndex));
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    private Object getCellValue(Cell c) {
        if (c == null) {
            return "";
        }

        DataFormatter fmt = new DataFormatter();

        // For formula cells, evaluate the formula to get the calculated value
        if (c.getCellType() == CellType.FORMULA) {
            try {
                // Use FormulaEvaluator to get the calculated value, not the formula string
                return fmt.formatCellValue(c, formulaEvaluator);
            } catch (Exception e) {
                System.out.println("Error evaluating formula in cell: " + e.getMessage());
                // Fallback to the formula string if evaluation fails
                return c.getCellFormula();
            }
        } else {
            // For non-formula cells, use standard formatting
            return fmt.formatCellValue(c);
        }
    }

    /**
     * Close the workbook to release resources.
     * POI 5.x enforces stricter resource management.
     */
    @Override
    public void close() {
        if (workbook != null) {
            try {
                workbook.close();
            } catch (IOException e) {
                System.out.println("Error closing workbook: " + e.getMessage());
            }
        }
    }
}
