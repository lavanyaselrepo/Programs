package hwqe.baseframework.datacontext;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.*;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import hwqe.baseframework.annotations.DataProviderArguments;
import hwqe.baseframework.utilities.FileUtils;
import hwqe.baseframework.utilities.PropertyReader;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DataProvider {
    private static final Logger logger = LoggerFactory.getLogger(DataProvider.class);

    /**
     * Use all available test data rows.
     */
    private static final int ALL_ROWS = -1;

    /**
     * Use all available test data rows in random order.
     */
    private static final int ALL_ROWS_RANDOMIZED = -2;

    private Object[][] getData(int rowCount, Method method, boolean isByEnv) {
        DataProviderArguments args = method.getAnnotation(DataProviderArguments.class);
        String filePath = args.filePath();
        if (isByEnv) {
            String tempPath = getPathByEnv(filePath);
            if (FileUtils.doesFileExistsInResources(tempPath)) {
                filePath = tempPath;
            } else {
                throw new RuntimeException("DataFile does not exist. path: " + tempPath);
            }
        }
        // Auto-detect format: supports both .xlsx (legacy) and .json (new)
        DataContextFactory.DataContext ctx = DataContextFactory.create(
                filePath, FileUtils.getStreamFromResources(filePath), args.sheetName());
        // Thread-safe: create dataTypes locally for each call
        Map<Integer, String> dataTypes = new HashMap<>();
        List<Integer> testsRows = getTestRows(ctx.getColumnValues(0), getTestName(method));
        List<Integer> testsColumns = getTestColumns(ctx.getRowValues(0), getParameters(method, dataTypes));
        Object[][] retArray;
        if (rowCount == ALL_ROWS) {
            retArray = new Object[testsRows.size()][testsColumns.size()];
        } else {
            if (rowCount == ALL_ROWS_RANDOMIZED || rowCount > testsRows.size()) {
                rowCount = testsRows.size();
            }
            retArray = new Object[rowCount][testsColumns.size()];
            Collections.shuffle(testsRows);
            testsRows = testsRows.subList(0, rowCount);
        }
        for (int i = 1; i <= testsRows.size(); i++) {
            for (int j = 1; j <= testsColumns.size(); j++) {
                retArray[i - 1][j - 1] = convertToValue(
                        j - 1, ctx.getCellValues(testsRows.get(i - 1), testsColumns.get(j - 1)), dataTypes);
            }
        }
        return retArray;
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getDataAsMap()
     * Description: This method will get the xls columns & stores it in a map
     * Inputs : Method
     * returns: Object[][] - array of data
     * Author: Sugenya Sankar
     * *********************************************************************************************************************************************************
     */
    @org.testng.annotations.DataProvider
    public Object[][] getDataAsMap(Method method) {
        return getMap(method, false);
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getDataAsMaps()
     * Description: This method will get the xls columns & stores it in a map, and it will return all list of maps.
     * Inputs : Method
     * returns: Iterator<Object[]> - maps of maps list
     * Author: Ashok Gurijala
     * *********************************************************************************************************************************************************
     */
    @org.testng.annotations.DataProvider
    public Iterator<Object[]> getDataAsMaps(Method method) {
        return getMaps(method, false);
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getDataAsMapByEnv()
     * Description: This method will get the xls columns & stores it in a map based on environment
     * Inputs : Method
     * returns: Object[][] - array of data
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    @org.testng.annotations.DataProvider
    public Object[][] getDataAsMapByEnv(Method method) {
        return getMap(method, true);
    }

    private Object[][] getMap(Method method, boolean isByEnv) {
        DataProviderArguments args = method.getAnnotation(DataProviderArguments.class);
        String filePath = args.filePath();
        if (isByEnv) {
            String tempPath = getPathByEnv(filePath);
            if (FileUtils.doesFileExistsInResources(tempPath)) {
                filePath = tempPath;
            } else {
                throw new RuntimeException("DataFile does not exist. path: " + tempPath);
            }
        }
        // Auto-detect format: supports both .xlsx (legacy) and .json (new)
        DataContextFactory.DataContext ctx = DataContextFactory.create(
                filePath, FileUtils.getStreamFromResources(filePath), args.sheetName());
        List<Integer> testsRows = getTestRows(ctx.getColumnValues(0), getTestName(method));
        List<Integer> testsColumns = getTestColumnsForDataMap(ctx.getRowValues(0));
        Object[][] retArray = new Object[testsRows.size()][1];
        for (int i = 0; i < testsRows.size(); i++) {
            Map<Object, Object> datamap = new HashMap<>();
            for (int j = 0; j < testsColumns.size(); j++) {
                datamap.put(ctx.getRowValues(0).get(j), ctx.getCellValues(testsRows.get(i), testsColumns.get(j)));
            }
            retArray[i][0] = datamap;
        }
        return retArray;
    }

    private Iterator<Object[]> getMaps(Method method, boolean isByEnv) {
        List<Map<Object, Object>> lom = new ArrayList<>();

        DataProviderArguments args = method.getAnnotation(DataProviderArguments.class);
        String filePath = args.filePath();
        if (isByEnv) {
            String tempPath = getPathByEnv(filePath);
            if (FileUtils.doesFileExistsInResources(tempPath)) {
                filePath = tempPath;
            } else {
                throw new RuntimeException("DataFile does not exist. path: " + tempPath);
            }
        }
        // Auto-detect format: supports both .xlsx (legacy) and .json (new)
        DataContextFactory.DataContext ctx = DataContextFactory.create(
                filePath, FileUtils.getStreamFromResources(filePath), args.sheetName());
        List<Integer> testsRows = getAllTestRows(ctx.getColumnValues(0));
        List<Integer> testsColumns = getTestColumnsForDataMap(ctx.getRowValues(0));
        for (int i = 1; i < testsRows.size(); i++) {
            Map<Object, Object> datamap = new HashMap<>();
            for (int j = 0; j < testsColumns.size(); j++) {
                datamap.put(ctx.getRowValues(0).get(j), ctx.getCellValues(testsRows.get(i), testsColumns.get(j)));
            }
            lom.add(datamap);
        }
        Collection<Object[]> dp = new ArrayList<>();
        for (Map<Object, Object> map : lom) {
            dp.add(new Object[] {map});
        }
        return dp.iterator();
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getData()
     * Description: This method will get the TestNG provider data mapping the xls columns to testmethod parameters
     * Inputs : Method
     * returns: Object[][] - array of data
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    @org.testng.annotations.DataProvider
    public Object[][] getData(Method method) {
        return getData(ALL_ROWS, method, false);
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getDataByEnv()
     * Description: This method will get the TestNG provider data mapping the xls columns to testmethod parameters based on your env
     * Inputs : Method
     * returns: Object[][] - array of data
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    @org.testng.annotations.DataProvider
    public Object[][] getDataByEnv(Method method) {
        return getData(ALL_ROWS, method, true);
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getDataInRandom()
     * Description: This method will provide all the test related rows randomly mapping the xls columns to testmethod parameters
     * Inputs : Method
     * returns: Object[][] - array of data
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    @org.testng.annotations.DataProvider
    public Object[][] getDataInRandom(Method method) {
        return getData(ALL_ROWS_RANDOMIZED, method, false);
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRandomOne()
     * Description: This method will provide 1 row randomly mapping the xls columns to testmethod parameters
     * Inputs : Method
     * returns: Object[][] - array of data
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    @org.testng.annotations.DataProvider
    public Object[][] getRandomOne(Method method) {
        return getData(1, method, false);
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRandomThree()
     * Description: This method will provide 3 row randomly mapping the xls columns to testmethod parameters
     * Inputs : Method
     * returns: Object[][] - array of data
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    @org.testng.annotations.DataProvider
    public Object[][] getRandomThree(Method method) {
        return getData(3, method, false);
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRandomFive()
     * Description: This method will provide 5 row randomly mapping the xls columns to testmethod parameters
     * Inputs : Method
     * returns: Object[][] - array of data
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    @org.testng.annotations.DataProvider
    public Object[][] getRandomFive(Method method) {
        return getData(5, method, false);
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getRandomTen()
     * Description: This method will provide 5 row randomly mapping the xls columns to testmethod parameters
     * Inputs : Method
     * returns: Object[][] - array of data
     * Author: Krishna Prasad Nandeti
     * *********************************************************************************************************************************************************
     */
    @org.testng.annotations.DataProvider
    public Object[][] getRandomTen(Method method) {
        return getData(10, method, false);
    }

    /*
     * *********************************************************************************************************************************************************
     * Method Name - getBaseRxData()
     * Description: This method will get the jsonInfo for a key passed/ or will get the entire json in a hashmap
     * Inputs : Method
     * returns: Object[][] - array of data
     * Author: Saloni Sharma
     * *********************************************************************************************************************************************************
     */

    @org.testng.annotations.DataProvider
    public Iterator<Object[]> getBaseRxData(Method method) {
        DataProviderArguments args = method.getAnnotation(DataProviderArguments.class);
        String filePath = args.filePath();
        Map<String, JSONObject> rxTestDataMapping = getDataFromJson(filePath);

        JSONObject data = rxTestDataMapping.get(method.getName());
        if (data == null) {
            return java.util.Collections.<Object[]>emptyList().iterator();
        }
        return java.util.Collections.<Object[]>singletonList(new Object[] {data})
                .iterator();
    }

    /**
     * Converts a value to the appropriate type based on the parameter type mapping.
     *
     * @param index     the parameter index
     * @param value     the raw value to convert
     * @param dataTypes the thread-local type mapping
     * @return the converted value
     */
    private Object convertToValue(int index, Object value, Map<Integer, String> dataTypes) {
        if (value == null) {
            return null;
        }

        String type = dataTypes.get(index);
        String raw = value.toString().trim();

        if (type == null) {
            return raw;
        }

        switch (type.toLowerCase()) {
            case "int":
            case "java.lang.integer": {
                // Handle Excel-style values like "123.0", "123.00", etc.
                java.math.BigDecimal bd = new java.math.BigDecimal(raw).stripTrailingZeros();
                return bd.intValueExact();
            }
            case "long":
            case "java.lang.long": {
                java.math.BigDecimal bd = new java.math.BigDecimal(raw).stripTrailingZeros();
                return bd.longValueExact();
            }
            case "float":
            case "java.lang.float":
                return Float.parseFloat(raw);
            case "double":
            case "java.lang.double":
                return Double.parseDouble(raw);
            case "boolean":
            case "java.lang.boolean":
                return Boolean.parseBoolean(raw);
            case "java.lang.string":
            default:
                return raw;
        }
    }

    /**
     * Extracts parameter names and types from a method.
     *
     * @param method    the method to inspect
     * @param dataTypes the map to populate with parameter index -> type name
     * @return list of parameter names (lowercase)
     */
    private List<String> getParameters(Method method, Map<Integer, String> dataTypes) {
        Parameter[] params = method.getParameters();
        List<String> lstParams = new ArrayList<>();
        for (int i = 0; i < params.length; i++) {
            Parameter p = params[i];
            lstParams.add(p.getName().toLowerCase());
            dataTypes.put(i, p.getType().getName());
        }
        return lstParams;
    }

    private List<Integer> getTestRows(List<String> rows, String testName) {
        List<Integer> indexes = new ArrayList<>();
        for (int i = 0; i < rows.size(); i++) {
            String[] tests = rows.get(i).trim().split(",");
            for (int j = 0; j < tests.length; j++) {
                if (tests[j].trim().equalsIgnoreCase(testName)) {
                    indexes.add(i);
                }
            }
        }
        return indexes;
    }

    private List<Integer> getAllTestRows(List<String> rows) {
        List<Integer> indexes = new ArrayList<>();
        for (int i = 0; i < rows.size(); i++) {
            String[] tests = rows.get(i).trim().split(",");
            for (int j = 0; j < tests.length; j++) {
                indexes.add(i);
            }
        }
        return indexes;
    }

    private List<Integer> getTestColumns(List<String> columns, List<String> params) {
        List<Integer> indexes = new ArrayList<>();
        for (String s : params) {
            for (int i = 0; i < columns.size(); i++) {
                String column = columns.get(i).trim();
                if (s.equalsIgnoreCase(column)) {
                    indexes.add(i);
                }
            }
        }
        return indexes;
    }

    private List<Integer> getTestColumnsForDataMap(List<String> columns) {
        List<Integer> indexes = new ArrayList<>();
        for (int i = 0; i < columns.size(); i++) {
            indexes.add(i);
        }
        return indexes;
    }

    private String getTestName(Method method) {
        String testName = method.getName().toLowerCase();
        Test testAnnotation = method.getAnnotation(Test.class);
        if (testAnnotation != null) {
            String annotatedName = testAnnotation.testName();
            if (annotatedName != null && !annotatedName.isEmpty()) {
                testName = annotatedName.toLowerCase();
            }
        }
        return testName;
    }

    private String getPathByEnv(String path) {
        String fileName = path.substring(path.lastIndexOf("/") + 1);
        String[] file = fileName.split("\\.");
        String newFileName = file[0] + "-"
                + PropertyReader.getInstance().getEnvironment().name().toLowerCase() + "." + file[1];
        path = path.replace(fileName, newFileName);
        return path;
    }

    private Map<String, JSONObject> getDataFromJson(String filePath) {
        CommonUtils commonUtils = new CommonUtils();
        JSONObject jsonObject = new JSONObject(commonUtils.readJsonFile(filePath));
        Map<String, JSONObject> testCasesData = new HashMap<>();
        for (Iterator<String> it = jsonObject.keys(); it.hasNext(); ) {
            String testCaseName = it.next();
            testCasesData.put(testCaseName, jsonObject.getJSONObject(testCaseName));
        }
        return testCasesData;
    }

    /**
     * Data provider to read test data from a JSON file.
     * The JSON file should be structured as an array of objects, each containing a "TEST_NAME" field.
     * The method filters the data based on the test method name.
     *
     * @param method The test method for which data is being provided.
     * @return An array of objects containing the filtered test data.
     * Author: Devi Thummala
     */
    @org.testng.annotations.DataProvider(name = "testCaseData")
    public static Object[][] getDataFromJson(Method method) {
        try {
            // Get the declaring class and its static fileName field
            Class<?> declaringClass = method.getDeclaringClass();
            Field fileNameField = declaringClass.getDeclaredField("fileName");
            fileNameField.setAccessible(true);
            String fileName = (String) fileNameField.get(null);
            File file = fileName == null ? null : new File(fileName);
            if (fileName == null || !file.exists() || file.length() == 0) {
                throw new RuntimeException(
                        "Test data file is invalid: fileName is null, does not exist, or is empty. Path: " + fileName);
            }

            // Read JSON file into a list of maps (supporting arrays and primitives)
            ObjectMapper objectMapper = new ObjectMapper();
            List<Map<String, Object>> data =
                    objectMapper.readValue(new File(fileName), new TypeReference<List<Map<String, Object>>>() {});

            // Filter by test method name
            String testName = method.getName();
            List<Map<String, Object>> filteredData = data.stream()
                    .filter(d -> testName.equals(d.get("TEST_NAME")))
                    .collect(Collectors.toList());

            // Convert to Object[][]
            return filteredData.stream().map(d -> new Object[] {d}).toArray(Object[][]::new);

        } catch (Exception e) {
            logger.error("Failed to load test data from JSON file: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to load test data from JSON file", e);
        }
    }
}
