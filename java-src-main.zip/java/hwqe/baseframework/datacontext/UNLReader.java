package hwqe.baseframework.datacontext;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Stream;

public class UNLReader {

    private String path;

    public UNLReader(String filePath) {
        this.path = filePath;
    }

    public <T> List<T> getList(Function<String[], T> mapper) throws Exception {
        Stream<String> stream = Files.lines(Paths.get(this.path));
        Iterator<String> itr = stream.iterator();
        List<T> lst = new ArrayList<>();
        while (itr.hasNext()) {
            String[] s = itr.next().split("[|]");
            lst.add(mapper.apply(s));
        }
        stream.close();
        return lst;
    }

    public <E, T> Map<E, T> getMap(int keyColumnIndex, Function<String[], T> mapper) {
        Map<E, T> map = new HashMap<>();
        try {
            Stream<String> stream = Files.lines(Paths.get(this.path));
            Iterator<String> itr = stream.iterator();
            while (itr.hasNext()) {
                String[] s = itr.next().split("[|]");
                map.put((E) s[keyColumnIndex], mapper.apply(s));
            }
            stream.close();
        } catch (Exception ex) {
            System.out.println("error in UNLReader getMap");
        }
        return map;
    }
}
