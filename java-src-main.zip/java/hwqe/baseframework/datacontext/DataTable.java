package hwqe.baseframework.datacontext;

import java.util.ArrayList;
import java.util.List;

public class DataTable {
    private List<DataColumn> dataColumns = new ArrayList<>();
    private List<DataRow> rows = new ArrayList<>();

    public DataRow newRow() {
        DataRow row = new DataRow(this.dataColumns);
        if (dataColumns.isEmpty()) {
            throw new NullPointerException("DataColumns are not set");
        }
        return row;
    }

    public void addColumn(DataColumn dataColumn) {
        if (!rows.isEmpty()) {
            throw new RuntimeException("schema cannot be altered when there is data.");
        }
        for (DataColumn col : dataColumns) {
            if (col.getName().equalsIgnoreCase(dataColumn.getName())) {
                throw new IllegalArgumentException("column already exists with this name");
            }
        }
        this.dataColumns.add(dataColumn);
    }

    public void addRow(DataRow row) {
        if (dataColumns.isEmpty()) {
            throw new NullPointerException("DataColumns are not set");
        }
        rows.add(row);
    }

    public int getRowCount() {
        return rows.size();
    }

    public int getColumnCount() {
        return dataColumns.size();
    }

    public List<DataRow> getDataRows() {
        return rows;
    }

    public List<DataColumn> getDataColumns() {
        return dataColumns;
    }

    public DataRow getRow(int index) {
        if (index < 0 || index >= rows.size()) {
            throw new IndexOutOfBoundsException("Index out of range: " + index);
        }
        return rows.get(index);
    }
}
