package hwqe.baseframework.datacontext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import com.aventstack.extentreports.Status;
import com.azure.cosmos.CosmosClient;
import com.azure.cosmos.CosmosClientBuilder;
import com.azure.cosmos.CosmosContainer;
import com.azure.cosmos.CosmosDatabase;
import com.azure.cosmos.models.*;
import com.azure.cosmos.util.CosmosPagedIterable;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import hwqe.baseframework.utilities.Reporter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CosmosContext {
    private static final Logger logger = LoggerFactory.getLogger(CosmosContext.class);

    private CosmosClient client;
    private CosmosDatabase database;

    public CosmosContext(CosmosCredentials credentials) {
        client = new CosmosClientBuilder()
                .endpoint(credentials.getHost())
                .key(credentials.getKey())
                // .preferredRegions(Collections.singletonList("West US"))
                .gatewayMode()
                .buildClient();
        database = client.getDatabase(credentials.getDatabase());
    }

    public <T> List<T> executeQueryForList(String containerName, String sql, Class<T> mappedClass) {
        try {
            List<T> retList = new ArrayList<>();
            CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();
            options.setMaxBufferedItemCount(-1);
            CosmosContainer container = database.getContainer(containerName);
            Iterator<T> result = container.queryItems(sql, options, mappedClass).iterator();
            while (result.hasNext()) {
                retList.add(result.next());
            }
            return retList;
        } catch (Exception ex) {
            logger.error("Error executing query: {}", ex.getMessage(), ex);
        }
        return new ArrayList<>();
    }

    public <T> List<T> executeQueryForList(String containerName, SqlQuerySpec querySpec, Class<T> mappedClass) {
        try {
            List<T> retList = new ArrayList<>();
            CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();
            options.setMaxBufferedItemCount(-1);
            CosmosContainer container = database.getContainer(containerName);
            Iterator<T> result = container.queryItems(querySpec, options, mappedClass).iterator();
            while (result.hasNext()) {
                retList.add(result.next());
            }
            return retList;
        } catch (Exception ex) {
            logger.error("Error executing query: {}", ex.getMessage(), ex);
        }
        return new ArrayList<>();
    }

    public <T> T executeQuery(String containerName, String sql, Class<T> mappedClass) {

        try {
            CosmosContainer container = database.getContainer(containerName);
            Iterator<T> result = container
                    .queryItems(sql, new CosmosQueryRequestOptions(), mappedClass)
                    .iterator();
            while (result.hasNext()) {
                return result.next();
            }
        } catch (Exception ex) {
            logger.error("Cosmos query failed for container '{}': {}", containerName, ex.getMessage(), ex);
        }
        return null;
    }

    public <T> void executeUpdateQuery(
            String containerName,
            String id,
            String partitionKeyValue,
            String sql,
            Class<T> mappedClass,
            Function<T, T> updateLogic) {
        try {
            CosmosContainer container = database.getContainer(containerName);

            Iterator<T> result = container
                    .queryItems(sql, new CosmosQueryRequestOptions(), mappedClass)
                    .iterator();

            while (result.hasNext()) {
                T item = result.next();

                // Apply the update logic
                T updatedItem = updateLogic.apply(item);

                // Replace in container
                container.replaceItem(
                        updatedItem, id, new PartitionKey(partitionKeyValue), new CosmosItemRequestOptions());
            }
            logger.debug("Update completed.");
        } catch (Exception ex) {
            logger.error("Error during executeUpdateQuery: {}", ex.getMessage(), ex);
        }
    }

    public <T> List<T> executeQuery(String containerName, String sql, Class<T> mappedClass, Integer limit) {
        List<T> resultList = new ArrayList<>();
        try {
            CosmosContainer container = database.getContainer(containerName);
            CosmosQueryRequestOptions cosmosQueryRequestOptions = new CosmosQueryRequestOptions();
            cosmosQueryRequestOptions.setMaxBufferedItemCount(limit);
            Iterator<T> result = container
                    .queryItems(sql, cosmosQueryRequestOptions, mappedClass)
                    .iterator();
            while (result.hasNext()) {
                resultList.add(result.next());
            }
        } catch (Exception ex) {
            logger.error(
                    "Cosmos query failed for container '{}' with limit {}: {}",
                    containerName,
                    limit,
                    ex.getMessage(),
                    ex);
        }
        return resultList;
    }

    public <T> boolean createDocument(String containerName, T document, Object partitionKey) {
        try {
            CosmosContainer container = database.getContainer(containerName);
            CosmosItemResponse resp = container.createItem(document, new PartitionKey(partitionKey), null);
            if (resp.getStatusCode() >= 200 && resp.getStatusCode() < 300) {
                return true;
            }
        } catch (Exception ex) {
            logger.error("Failed to create document in container '{}': {}", containerName, ex.getMessage(), ex);
        }
        return false;
    }

    public <T> boolean upsertDocument(String containerName, T document) {
        try {
            CosmosContainer container = database.getContainer(containerName);
            CosmosItemResponse resp = container.upsertItem(document);
            if (resp.getStatusCode() >= 200 && resp.getStatusCode() < 300) {
                return true;
            }
        } catch (Exception ex) {
            logger.error("Failed to upsert document in container '{}': {}", containerName, ex.getMessage(), ex);
        }
        return false;
    }

    public boolean deleteDocument(String containerName, String docId, Object partitionKey) {
        try {
            CosmosContainer container = database.getContainer(containerName);
            CosmosItemResponse resp = container.deleteItem(docId, new PartitionKey(partitionKey), null);
            if (resp.getStatusCode() >= 200 && resp.getStatusCode() < 300) {
                return true;
            }
        } catch (Exception ex) {
            logger.error(
                    "Failed to delete document '{}' in container '{}': {}", docId, containerName, ex.getMessage(), ex);
        }
        return false;
    }

    /**
     * Deletes documents by directly querying partition key values and using them for deletion.
     * Partition key fields are automatically detected from the container definition.
     *
     * @param containerName The name of the container
     * @param whereClause The WHERE clause condition (e.g., "c.p_key='32028'" or "c.p_key='32028' and c.id='xyz'")
     * @return Total number of documents deleted
     *
     * Example:
     * // Container: activity with partition keys auto-detected from container
     * int deleted = cosmosContext.deleteDocumentsByPartitionKeyValues("activity", "c.p_key='32028'");
     * int deleted = cosmosContext.deleteDocumentsByPartitionKeyValues("activity", "c.p_key='32028' and c.id='abc123'");
     */
    public int deleteDocumentsByPartitionKeyValues(String containerName, String whereClause, int batchSizeForDelete) {
        final java.util.concurrent.atomic.AtomicInteger totalDeleted = new java.util.concurrent.atomic.AtomicInteger(0);

        if (containerName == null || whereClause == null || whereClause.trim().isEmpty()) {
            Reporter.log(Status.FAIL, "Container name or WHERE clause is null/empty");
            return 0;
        }

        try {
            CosmosContainer container = database.getContainer(containerName);

            // Get container's actual partition key definition and extract field names
            CosmosContainerProperties containerProps = container.read().getProperties();
            List<String> actualPkPaths =
                    containerProps.getPartitionKeyDefinition().getPaths();

            // Convert paths like "/p_key" to field names like "p_key"
            List<String> partitionKeyFields = new ArrayList<>();
            for (String path : actualPkPaths) {
                String fieldName = path.startsWith("/") ? path.substring(1) : path;
                partitionKeyFields.add(fieldName);
            }

            logger.debug(
                    "Performing deletions for container '{}' with partition key fields: {}",
                    containerName,
                    partitionKeyFields);

            // Build SELECT clause to get id and all partition key fields
            StringBuilder selectClause = new StringBuilder("SELECT c.id");
            for (String pkField : partitionKeyFields) {
                selectClause.append(", c.").append(pkField);
            }

            // Build complete query with the provided WHERE clause
            String query = String.format("%s FROM c WHERE %s", selectClause.toString(), whereClause);

            logger.debug("Cosmos delete query: {}", query);

            CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();
            options.setMaxBufferedItemCount(-1);

            Iterator<JsonNode> result =
                    container.queryItems(query, options, JsonNode.class).iterator();

            // Step 1: Collect all documents and build partition keys
            List<CosmosItemOperation> bulkOperations = new ArrayList<>();
            int docsFound = 0;

            logger.debug("Collecting documents for bulk deletion...");

            while (result.hasNext()) {
                JsonNode doc = result.next();

                if (!doc.has("id")) {
                    Reporter.log(Status.FAIL, "Document missing 'id' field");
                    continue;
                }

                String docId = doc.get("id").asText();
                docsFound++;

                // Extract partition key values in order - preserve types!
                List<Object> pkValues = new ArrayList<>();
                List<String> pkValueStrings = new ArrayList<>(); // For display
                boolean allPresent = true;

                for (String pkField : partitionKeyFields) {
                    if (doc.has(pkField)) {
                        JsonNode fieldNode = doc.get(pkField);

                        // Preserve the actual type (string, number, boolean, etc.)
                        Object fieldValue;
                        if (fieldNode.isTextual()) {
                            fieldValue = fieldNode.asText();
                        } else if (fieldNode.isInt()) {
                            fieldValue = fieldNode.asInt();
                        } else if (fieldNode.isLong()) {
                            fieldValue = fieldNode.asLong();
                        } else if (fieldNode.isDouble()) {
                            fieldValue = fieldNode.asDouble();
                        } else if (fieldNode.isBoolean()) {
                            fieldValue = fieldNode.asBoolean();
                        } else {
                            fieldValue = fieldNode.asText(); // Fallback to string
                        }

                        pkValues.add(fieldValue);
                        pkValueStrings.add(String.valueOf(fieldValue));
                    } else {
                        Reporter.log(
                                Status.FAIL,
                                String.format("Document id=%s missing partition key field: %s", docId, pkField));
                        allPresent = false;
                        break;
                    }
                }

                if (!allPresent) {
                    continue;
                }

                // Build partition key
                try {
                    PartitionKey partitionKey;
                    if (pkValues.size() == 1) {
                        // Single partition key
                        partitionKey = new PartitionKey(pkValues.get(0));
                    } else {
                        // Hierarchical partition key - use PartitionKeyBuilder
                        PartitionKeyBuilder builder = new PartitionKeyBuilder();
                        for (Object pkValue : pkValues) {
                            // PartitionKeyBuilder.add() requires specific types
                            if (pkValue instanceof String) {
                                builder.add((String) pkValue);
                            } else if (pkValue instanceof Integer) {
                                builder.add((Integer) pkValue);
                            } else if (pkValue instanceof Long) {
                                builder.add((Long) pkValue);
                            } else if (pkValue instanceof Double) {
                                builder.add((Double) pkValue);
                            } else if (pkValue instanceof Boolean) {
                                builder.add((Boolean) pkValue);
                            } else {
                                builder.add(String.valueOf(pkValue)); // Fallback
                            }
                        }
                        partitionKey = builder.build();
                    }

                    // Add to bulk operations list
                    bulkOperations.add(CosmosBulkOperations.getDeleteItemOperation(docId, partitionKey));
                    logger.trace("Queued for deletion: id={}, PK={}", docId, pkValueStrings);

                    // Execute batch when reaching batchSizeForDelete
                    if (bulkOperations.size() >= batchSizeForDelete) {
                        logger.debug("Batch limit reached ({} docs), executing batch delete...", bulkOperations.size());
                        executeBulkDelete(container, bulkOperations, totalDeleted);
                        bulkOperations.clear(); // Clear for next batch
                    }

                } catch (Exception e) {
                    Reporter.log(
                            Status.FAIL, String.format("✗ Failed to build PK for id=%s: %s", docId, e.getMessage()));
                }
            }

            logger.debug("Found {} documents to delete", docsFound);

            // Step 2: Execute remaining bulk delete (final batch)
            if (!bulkOperations.isEmpty()) {
                logger.debug("Executing final bulk delete of {} documents...", bulkOperations.size());
                executeBulkDelete(container, bulkOperations, totalDeleted);
            } else if (docsFound == 0) {
                logger.debug("No documents found to delete");
            }

            logger.info("Total deleted from container '{}': {} documents", containerName, totalDeleted.get());

        } catch (Exception ex) {
            Reporter.log(Status.FAIL, ex.getMessage());
            logger.error("Error deleting documents from container {}: {}", containerName, ex.getMessage(), ex);
        }

        return totalDeleted.get();
    }

    /**
     * Helper method to execute bulk delete operations
     */
    private void executeBulkDelete(
            CosmosContainer container,
            List<CosmosItemOperation> operations,
            java.util.concurrent.atomic.AtomicInteger totalDeleted) {
        int batchSize = operations.size();
        java.util.concurrent.atomic.AtomicInteger batchSuccessCount = new java.util.concurrent.atomic.AtomicInteger(0);

        try {
            container.executeBulkOperations(operations).forEach(bulkResponse -> {
                if (bulkResponse.getException() == null) {
                    // Success
                    int statusCode = bulkResponse.getResponse().getStatusCode();
                    if (statusCode >= 200 && statusCode < 300) {
                        totalDeleted.incrementAndGet();
                        batchSuccessCount.incrementAndGet();
                    } else {
                        logger.warn("Unexpected status code during bulk delete: {}", statusCode);
                    }
                } else {
                    // Failed
                    Exception ex = bulkResponse.getException();
                    logger.warn("Failed to delete document: {}", ex.getMessage());
                }
            });

            int succeeded = batchSuccessCount.get();
            int failed = batchSize - succeeded;

            logger.debug("Batch completed: {}/{} succeeded, {} failed", succeeded, batchSize, failed);

        } catch (Exception bulkEx) {
            logger.error("Bulk delete batch failed: {}", bulkEx.getMessage(), bulkEx);
        }
    }

    public int executeCountQuery(String containerName, String sql) {
        try {
            CosmosContainer container = database.getContainer(containerName);
            CosmosPagedIterable<JsonNode> recordCount =
                    container.queryItems(sql, new CosmosQueryRequestOptions(), JsonNode.class);
            Iterator<JsonNode> it = recordCount.iterator();
            if (it.hasNext()) {
                JsonNode node = it.next();
                return node.isNumber() ? node.asInt() : Integer.parseInt(node.asText());
            }
        } catch (Exception ex) {
            logger.error("Count query failed for container '{}': {}", containerName, ex.getMessage(), ex);
        }
        return 0;
    }

    /**
     * Saves data into Cosmos DB based on the test case name.
     *
     * @param testCaseName The name of the test case.
     * @param data The key-value pairs to save.
     */
    public boolean saveData(String containerName, String testCaseName, Map<String, Object> data) {
        try {
            CosmosContainer container = database.getContainer(containerName);
            data.put("testCaseName", testCaseName); // Ensure testCaseName is part of the document
            CosmosItemResponse<?> resp = container.upsertItem(data);
            return resp.getStatusCode() >= 200 && resp.getStatusCode() < 300;
        } catch (Exception ex) {
            logger.error(
                    "Failed to save data for test case '{}' in container '{}': {}",
                    testCaseName,
                    containerName,
                    ex.getMessage(),
                    ex);
        }
        return false;
    }

    /**
     * Fetches data from Cosmos DB based on the test case name.
     *
     * @param containerName The name of the container.
     * @param testCaseName The name of the test case.
     * @return The key-value pairs associated with the test case name.
     */
    public Map<String, Object> fetchData(String containerName, String testCaseName) {
        try {
            CosmosContainer container = database.getContainer(containerName);
            String sql = String.format("SELECT * FROM c WHERE c.testCaseName = '%s'", testCaseName);
            Iterator<JsonNode> result = container
                    .queryItems(sql, new CosmosQueryRequestOptions(), JsonNode.class)
                    .iterator();
            if (result.hasNext()) {
                JsonNode node = result.next();
                return new ObjectMapper().convertValue(node, new TypeReference<Map<String, Object>>() {});
            }
        } catch (Exception ex) {
            logger.error(
                    "Failed to fetch data for test case '{}' from container '{}': {}",
                    testCaseName,
                    containerName,
                    ex.getMessage(),
                    ex);
        }
        return new HashMap<>();
    }

    /**
     * Fetches data from Cosmos DB based on the test case name within the testCases field.
     *
     * @param containerName The name of the container.
     * @param testCaseName The name of the test case.
     * @return The key-value pairs associated with the test case name.
     */
    public Map<String, Object> fetchTestCaseData(String containerName, String testCaseName) {
        try {
            CosmosContainer container = database.getContainer(containerName);
            String sql = String.format(
                    "SELECT c.testCases['%s'] AS testCaseData FROM c WHERE c.testCases['%s'] != null",
                    testCaseName, testCaseName);
            CosmosQueryRequestOptions options = new CosmosQueryRequestOptions();
            options.setMaxBufferedItemCount(-1);
            Iterator<JsonNode> result =
                    container.queryItems(sql, options, JsonNode.class).iterator();

            if (result.hasNext()) {
                JsonNode node = result.next();
                return new ObjectMapper()
                        .convertValue(node.get("testCaseData"), new TypeReference<Map<String, Object>>() {});
            }
        } catch (Exception ex) {
            logger.error(
                    "Failed to fetch test case data for '{}' from container '{}': {}",
                    testCaseName,
                    containerName,
                    ex.getMessage(),
                    ex);
        }
        return new HashMap<>();
    }

    /**
     * Saves data into Cosmos DB for a specific test case name within the testCases field.
     *
     * @param containerName The name of the container.
     * @param testCaseName The name of the test case.
     * @param data The key-value pairs to save.
     */
    public boolean saveTestCaseData(String containerName, String testCaseName, Map<String, Object> data) {
        try {
            CosmosContainer container = database.getContainer(containerName);
            String sql = String.format("SELECT * FROM c WHERE c.testCases['%s'] != null", testCaseName);
            Iterator<JsonNode> result = container
                    .queryItems(sql, new CosmosQueryRequestOptions(), JsonNode.class)
                    .iterator();

            if (result.hasNext()) {
                JsonNode node = result.next();
                Map<String, Object> record =
                        new ObjectMapper().convertValue(node, new TypeReference<Map<String, Object>>() {});
                Map<String, Object> testCases = (Map<String, Object>) record.get("testCases");

                if (testCases == null) {
                    testCases = new HashMap<>();
                }
                testCases.put(testCaseName, data);
                record.put("testCases", testCases);

                // Ensure the partition key is included in the document
                Object suiteName = record.get("suiteName");

                if (suiteName == null) {
                    throw new IllegalArgumentException("Partition key value 'suiteName' is missing in the document.");
                }

                // Use the partition key for the upsert operation
                PartitionKey partitionKey = new PartitionKey(suiteName);
                CosmosItemResponse<?> resp = container.upsertItem(record, partitionKey, null);
                return resp.getStatusCode() >= 200 && resp.getStatusCode() < 300;
            }
        } catch (Exception ex) {
            logger.error(
                    "Failed to save test case data for '{}' in container '{}': {}",
                    testCaseName,
                    containerName,
                    ex.getMessage(),
                    ex);
        }
        return false;
    }
}
