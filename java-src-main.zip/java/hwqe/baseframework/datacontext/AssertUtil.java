package hwqe.baseframework.datacontext;

import com.aventstack.extentreports.Status;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;

public class AssertUtil {

    private static void logAssertion(String message) {
        Reporter.log(message);
        System.out.println(message);
    }

    public static void assertEquals(String actual, String expected) {
        Assert.assertEquals(actual, expected);
        logAssertion("ASSERT PASSED. Expected: " + expected + ", Actual: " + actual);
    }

    public static void assertEquals(int actual, int expected) {
        Assert.assertEquals(actual, expected);
        logAssertion("ASSERT PASSED. Expected: " + expected + ", Actual: " + actual);
    }

    public static void assertEquals(boolean actual, boolean expected) {
        Assert.assertEquals(actual, expected);
        logAssertion("ASSERT PASSED. Expected: " + expected + ", Actual: " + actual);
    }

    public static void assertTrue(boolean expected, String message) {
        Assert.assertTrue(expected, "ASSERT FAILED : " + message);
        logAssertion("ASSERT PASSED. Condition is true. Message : " + message);
    }

    public static void assertFalse(boolean expected, String message) {
        Assert.assertFalse(expected, "ASSERT FAILED : " + message);
        logAssertion("ASSERT PASSED. Condition is false. Message : " + message);
    }

    public static void assertNull(Object expectedValue, String message) {
        Assert.assertNull(expectedValue, "ASSERT FAILED : " + message);
        logAssertion("ASSERT PASSED. Object is null.Message : " + message);
    }

    public static void assertNotNull(Object expectedValue, String message) {
        Assert.assertNotNull(expectedValue, "ASSERT FAILED : Object is null. " + expectedValue);
        logAssertion("ASSERT PASSED. Object is not null. Message : " + message);
    }

    public static void fail(String message) {
        Reporter.log(Status.FAIL, message);
        System.out.println("ASSERT FAILED. Message : " + message);
        Assert.fail("ASSERT FAILED : " + message);
    }
}
