package hwqe.baseframework.datacontext;

import java.io.InputStream;

/**
 * Factory for creating data contexts that can read both Excel and JSON files.
 * <p>
 * This factory automatically selects the appropriate context implementation
 * based on the file extension, enabling seamless migration from Excel to JSON.
 * </p>
 * <p>
 * Usage:
 * <pre>
 * // Works with both .xlsx and .json files
 * DataContext ctx = DataContextFactory.create(filePath, sheetName);
 * List&lt;String&gt; column = ctx.getColumnValues(0);
 * </pre>
 * </p>
 */
public class DataContextFactory {

    /**
     * Interface for data context operations.
     * Both XlsContext and JsonContext implement these methods.
     */
    public interface DataContext {
        <T> java.util.List<T> getColumnValues(int index);
        <T> java.util.List<T> getRowValues(int index);
        <T> T getCellValues(int rowIndex, int columnIndex);
    }

    /**
     * Create a data context from a file path and sheet name.
     * Automatically selects XlsContext or JsonContext based on file extension.
     *
     * @param filePath  Path to the data file (.xlsx or .json)
     * @param sheetName Name of the sheet
     * @return Appropriate DataContext implementation
     */
    public static DataContext create(String filePath, String sheetName) {
        if (filePath.toLowerCase().endsWith(".json")) {
            return wrap(new JsonContext(filePath, sheetName));
        } else if (filePath.toLowerCase().endsWith(".xlsx")) {
            return wrap(new XlsContext(filePath, sheetName));
        } else {
            throw new IllegalArgumentException(
                "Unsupported file format: " + filePath + ". Expected .xlsx or .json"
            );
        }
    }

    /**
     * Create a data context from an input stream and sheet name.
     * Note: For streams, you must specify the format explicitly.
     *
     * @param fileStream InputStream of the data file
     * @param sheetName  Name of the sheet
     * @param isJson     true for JSON format, false for Excel
     * @return Appropriate DataContext implementation
     */
    public static DataContext create(InputStream fileStream, String sheetName, boolean isJson) {
        if (isJson) {
            return wrap(new JsonContext(fileStream, sheetName));
        } else {
            return wrap(new XlsContext(fileStream, sheetName));
        }
    }

    /**
     * Create a data context from file path (for format detection) and input stream.
     * This is the preferred method when loading resources from classpath.
     *
     * @param filePath   Path to the data file (used to detect format: .xlsx or .json)
     * @param fileStream InputStream of the data file
     * @param sheetName  Name of the sheet
     * @return Appropriate DataContext implementation based on file extension
     */
    public static DataContext create(String filePath, InputStream fileStream, String sheetName) {
        boolean isJson = filePath.toLowerCase().endsWith(".json");
        return create(fileStream, sheetName, isJson);
    }

    /**
     * Create a data context from a file path and sheet index.
     *
     * @param filePath   Path to th (.xlsx or .json)
     * @param sheetIndex Index of the sheet (0-based)
     * @return Appropriate DataContext implementation
     */
    public static DataContext create(String filePath, int sheetIndex) {
        if (filePath.toLowerCase().endsWith(".json")) {
            return wrap(new JsonContext(filePath, sheetIndex));
        } else if (filePath.toLowerCase().endsWith(".xlsx")) {
            return wrap(new XlsContext(filePath, sheetIndex));
        } else {
            throw new IllegalArgumentException(
                "Unsupported file format: " + filePath + ". Expected .xlsx or .json"
            );
        }
    }

    /**
     * Try to find and create a context, preferring JSON over Excel.
     * Useful during migration when both files might exist.
     *
     * @param basePath  Path without extension
     * @param sheetName Name of the sheet
     * @return DataContext for JSON if available, otherwise Excel
     */
    public static DataContext createPreferJson(String basePath, String sheetName) {
        String jsonPath = basePath + ".json";
        String xlsxPath = basePath + ".xlsx";

        java.io.File jsonFile = new java.io.File(jsonPath);
        if (jsonFile.exists()) {
            return wrap(new JsonContext(jsonPath, sheetName));
        }

        java.io.File xlsxFile = new java.io.File(xlsxPath);
        if (xlsxFile.exists()) {
            return wrap(new XlsContext(xlsxPath, sheetName));
        }

        throw new IllegalArgumentException(
            "Neither JSON nor Excel file found at: " + basePath
        );
    }

    // Wrapper to adapt XlsContext to DataContext interface
    private static DataContext wrap(XlsContext ctx) {
        return new DataContext() {
            @Override
            public <T> java.util.List<T> getColumnValues(int index) {
                return ctx.getColumnValues(index);
            }

            @Override
            public <T> java.util.List<T> getRowValues(int index) {
                return ctx.getRowValues(index);
            }

            @Override
            public <T> T getCellValues(int rowIndex, int columnIndex) {
                return ctx.getCellValues(rowIndex, columnIndex);
            }
        };
    }

    // Wrapper to adapt JsonContext to DataContext interface
    private static DataContext wrap(JsonContext ctx) {
        return new DataContext() {
            @Override
            public <T> java.util.List<T> getColumnValues(int index) {
                return ctx.getColumnValues(index);
            }

            @Override
            public <T> java.util.List<T> getRowValues(int index) {
                return ctx.getRowValues(index);
            }

            @Override
            public <T> T getCellValues(int rowIndex, int columnIndex) {
                return ctx.getCellValues(rowIndex, columnIndex);
            }
        };
    }
}
