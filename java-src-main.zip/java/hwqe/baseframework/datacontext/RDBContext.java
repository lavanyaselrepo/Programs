package hwqe.baseframework.datacontext;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.ibm.db2.jcc.DB2SimpleDataSource;
import com.microsoft.aad.adal4j.AuthenticationContext;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.microsoft.aad.adal4j.ClientCredential;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import hwqe.baseframework.interfaces.IDatabaseContext;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class RDBContext implements IDatabaseContext {
    private JdbcTemplate template;

    public RDBContext(DBCredentials credentials) {
        try {
            DriverManagerDataSource dataSource = new DriverManagerDataSource();
            dataSource.setDriverClassName(credentials.getDriverName());
            
            // mssql-jdbc 10.x+ changed encrypt default to true - restore old behavior for backward compatibility
            String connectionUrl = credentials.getDbUrl();
            if (connectionUrl != null && connectionUrl.contains("sqlserver") 
                    && !connectionUrl.toLowerCase().contains("encrypt")) {
                connectionUrl += connectionUrl.contains("?") ? "&" : ";";
                connectionUrl += "encrypt=false";
            }
            dataSource.setUrl(connectionUrl);
            
            dataSource.setUsername(credentials.getDbUsername());
            dataSource.setPassword(credentials.getDbPassword());
            dataSource.getConnection().setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);
            dataSource.getConnection().setAutoCommit(true);
            template = new JdbcTemplate(dataSource);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public RDBContext(MSICredentials credentials) {
        try {
            String spn = "https://database.windows.net/";
            String authUrl = "https://login.microsoftonline.com/" + credentials.getTenantId() + "/";
            AuthenticationContext context = new AuthenticationContext(authUrl, false, Executors.newFixedThreadPool(1));
            ClientCredential cred = new ClientCredential(credentials.getClientId(), credentials.getClientSecret());
            Future<AuthenticationResult> future = context.acquireToken(spn, cred, null);
            String accessToken = future.get().getAccessToken();

            SQLServerDataSource ds = new SQLServerDataSource();
            ds.setServerName(credentials.getDbHost());
            ds.setDatabaseName(credentials.getDbName());
            ds.setAccessToken(accessToken);
            // mssql-jdbc 10.x+ changed encrypt default to true - restore old behavior for backward compatibility
            ds.setEncrypt("false");

            template = new JdbcTemplate(ds);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    /*
     * Below constructor can be used to connect to SQL Servers which use AD group for authentication
     * */

    public RDBContext(SqlAdCredentials credentials) {
        try {
            SQLServerDataSource ds = new SQLServerDataSource();
            ds.setServerName(credentials.getServerName());
            ds.setDatabaseName(credentials.getDatabaseName());
            ds.setUser(credentials.getUserName());
            ds.setPassword(credentials.getPassword());
            ds.setAuthentication(credentials.getAuthentication());
            ds.setPortNumber(credentials.getPort());
            ds.setTrustServerCertificate(credentials.isTrustServerCertificate());
            ds.setHostNameInCertificate(credentials.getHostNameInCertificate());
            ds.setEncrypt(String.valueOf(credentials.isEncrypt()));

            template = new JdbcTemplate(ds);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public RDBContext(DB2Credentials credentials) {
        try {
            String ksFile = FileUtil.getJksFileLocation(credentials.getKeyStore(), "db-keystore");
            String tsFile = FileUtil.getJksFileLocation(credentials.getTrustStore(), "db-truststore");

            System.setProperty("javax.net.ssl.keyStorePassword", credentials.getKeyStorePassword());
            System.setProperty("javax.net.ssl.keyStore", ksFile);
            System.setProperty("javax.net.ssl.trustStore", tsFile);

            DB2SimpleDataSource dataSource = new DB2SimpleDataSource();
            dataSource.setServerName(credentials.getServerName());
            dataSource.setPortNumber(credentials.getPortNumber());
            dataSource.setDatabaseName(credentials.getDatabaseName());
            dataSource.setDriverType(4);
            dataSource.setSslConnection(true);
            dataSource.setSecurityMechanism(DB2SimpleDataSource.TLS_CLIENT_CERTIFICATE_SECURITY);
            dataSource.getConnection().setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);
            dataSource.getConnection().setAutoCommit(true);
            dataSource.setCurrentSchema(credentials.getCurrentSchema());
            template = new JdbcTemplate(dataSource);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public <T> List<T> executeQueryForList(String sql, Class<T> mappedClass) {
        BeanPropertyRowMapper<T> mapper = new BeanPropertyRowMapper(mappedClass);
        mapper.setPrimitivesDefaultedForNullValue(true);
        return template.query(sql, mapper);
    }

    @Override
    public <T> T executeQuery(String sql, Class<T> mappedClass) {
        List<T> lst = this.executeQueryForList(sql, mappedClass);
        if (!lst.isEmpty()) {
            return lst.get(0);
        }
        return null;
    }

    @Override
    public DataTable getDataTable(String sql) {
        List<Map<String, Object>> lst = template.queryForList(sql);
        DataTable dt = new DataTable();
        if (lst.isEmpty()) {
            return dt;
        }
        int counter = 1;
        for (Map.Entry<String, Object> entry : lst.get(0).entrySet()) {
            DataColumn column = new DataColumn();
            column.setName(entry.getKey().toLowerCase());
            column.setOrdinalPosition(counter);
            counter++;
            dt.addColumn(column);
        }
        for (Map<String, Object> m : lst) {
            counter = 1;
            DataRow row = dt.newRow();
            for (Map.Entry<String, Object> entry : m.entrySet()) {
                row.setValue(counter, entry.getValue());
                counter++;
            }
            dt.addRow(row);
        }
        return dt;
    }

    @Override
    public <E, T> Map<E, T> executeQuery(String sql, String keyColumn, Class<T> mappedClass) {
        List<T> lst = this.executeQueryForList(sql, mappedClass);
        if (!lst.isEmpty()) {
            HashMap<E, T> map = new HashMap<>();
            for (T obj : lst) {
                map.put((E) new BeanWrapperImpl(obj).getPropertyValue(keyColumn), obj);
            }
            return map;
        }
        return null;
    }

    @Override
    public Map<String, Object> executeQuery(String sql) {
        try {
            return template.queryForMap(sql);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<Map<String, Object>> executeQueryForList(String sql) {
        return template.queryForList(sql);
    }

    @Override
    public <T> T getScalar(String sql, Class<T> mappedClass) {
        try {
            return template.queryForObject(sql, mappedClass);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    @Override
    public int executeUpdateQuery(String sql) {
        try {
            return template.update(sql);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return 0;
    }

    @Override
    public int executeInsertQuery(String sql) {
        try {
            return template.update(sql);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return 0;
    }

    public int executeDeleteQuery(String sql) {
        try {
            return template.update(sql);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return 0;
    }
}
