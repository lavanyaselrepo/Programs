package hwqe.baseframework.datacontext;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * JSON-based data context that mirrors XlsContext API.
 * <p>
 * Reads JSON files that were converted from Excel using the migration scripts.
 * Each JSON file contains sheets as top-level keys, with arrays of row objects.
 * </p>
 * <p>
 * Example JSON structure:
 * <pre>
 * {
 *   "Sheet1": [
 *     {"Column1": "value1", "Column2": "value2"},
 *     {"Column1": "value3", "Column2": "value4"}
 *   ],
 *   "Sheet2": [...]
 * }
 * </pre>
 * </p>
 */
public class JsonContext {

    private final List<Map<String, Object>> sheetData;
    private final List<String> headers;

    /**
     * Create a JsonContext from a file path and sheet name.
     *
     * @param filePath  Path to the JSON file
     * @param sheetName Name of the sheet (top-level key in JSON)
     */
    public JsonContext(String filePath, String sheetName) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<String, List<Map<String, Object>>> data = mapper.readValue(
                    new File(filePath),
                    new TypeReference<Map<String, List<Map<String, Object>>>>() {}
            );
            this.sheetData = data.getOrDefault(sheetName, new ArrayList<>());
            this.headers = extractHeaders();
        } catch (Exception ex) {
            throw new RuntimeException("Failed to load JSON file: " + filePath + ", sheet: " + sheetName, ex);
        }
    }

    /**
     * Create a JsonContext from an input stream and sheet name.
     *
     * @param fileStream InputStream of the JSON file
     * @param sheetName  Name of the sheet (top-level key in JSON)
     */
    public JsonContext(InputStream fileStream, String sheetName) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<String, List<Map<String, Object>>> data = mapper.readValue(
                    fileStream,
                    new TypeReference<Map<String, List<Map<String, Object>>>>() {}
            );
            this.sheetData = data.getOrDefault(sheetName, new ArrayList<>());
            this.headers = extractHeaders();
        } catch (Exception ex) {
            throw new RuntimeException("Failed to load JSON from stream, sheet: " + sheetName, ex);
        }
    }

    /**
     * Create a JsonContext from a file path and sheet index.
     *
     * @param filePath   Path to the JSON file
     * @param sheetIndex Index of the sheet (0-based, based on JSON key order)
     */
    public JsonContext(String filePath, int sheetIndex) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            // Use LinkedHashMap to preserve order
            Map<String, List<Map<String, Object>>> data = mapper.readValue(
                    new File(filePath),
                    new TypeReference<java.util.LinkedHashMap<String, List<Map<String, Object>>>>() {}
            );
            List<String> sheetNames = new ArrayList<>(data.keySet());
            if (sheetIndex >= 0 && sheetIndex < sheetNames.size()) {
                this.sheetData = data.get(sheetNames.get(sheetIndex));
            } else {
                this.sheetData = new ArrayList<>();
            }
            this.headers = extractHeaders();
        } catch (Exception ex) {
            throw new RuntimeException("Failed to load JSON file: " + filePath + ", index: " + sheetIndex, ex);
        }
    }

    /**
     * Extract column headers from the first row of data.
     */
    private List<String> extractHeaders() {
        if (sheetData.isEmpty()) {
            return new ArrayList<>();
        }
        return new ArrayList<>(sheetData.get(0).keySet());
    }

    /**
     * Get all values from a specific column.
     *
     * @param index Column index (0-based)
     * @return List of values in that column
     */
    @SuppressWarnings("unchecked")
    public <T> List<T> getColumnValues(int index) {
        List<T> values = new ArrayList<>();
        if (index < 0 || index >= headers.size()) {
            return values;
        }

        String columnName = headers.get(index);

        // First add the header itself (to match XlsContext behavior)
        values.add((T) columnName);

        // Then add all row values
        for (Map<String, Object> row : sheetData) {
            Object value = row.get(columnName);
            values.add((T) formatValue(value));
        }

        return values;
    }

    /**
     * Get all values from a specific row.
     *
     * @param index Row index (0 = headers, 1+ = data rows)
     * @return List of values in that row
     */
    @SuppressWarnings("unchecked")
    public <T> List<T> getRowValues(int index) {
        List<T> values = new ArrayList<>();

        if (index == 0) {
            // Return headers
            for (String header : headers) {
                values.add((T) header);
            }
        } else if (index > 0 && index <= sheetData.size()) {
            // Return data row (index - 1 because row 0 is headers)
            Map<String, Object> row = sheetData.get(index - 1);
            for (String header : headers) {
                values.add((T) formatValue(row.get(header)));
            }
        }

        return values;
    }

    /**
     * Get a specific cell value.
     *
     * @param rowIndex    Row index (0 = headers, 1+ = data rows)
     * @param columnIndex Column index (0-based)
     * @return Cell value
     */
    @SuppressWarnings("unchecked")
    public <T> T getCellValues(int rowIndex, int columnIndex) {
        if (columnIndex < 0 || columnIndex >= headers.size()) {
            return null;
        }

        String columnName = headers.get(columnIndex);

        if (rowIndex == 0) {
            return (T) columnName;
        } else if (rowIndex > 0 && rowIndex <= sheetData.size()) {
            Map<String, Object> row = sheetData.get(rowIndex - 1);
            return (T) formatValue(row.get(columnName));
        }

        return null;
    }

    /**
     * Format a value to string, handling nulls and special types.
     */
    private String formatValue(Object value) {
        if (value == null) {
            return "";
        }
        if (value instanceof Number) {
            // Handle integer-like doubles (e.g., 123.0 -> "123")
            if (value instanceof Double) {
                Double d = (Double) value;
                if (d == Math.floor(d) && !Double.isInfinite(d)) {
                    return String.valueOf(d.longValue());
                }
            }
        }
        return String.valueOf(value);
    }

    /**
     * Get the number of data rows (excluding header).
     */
    public int getRowCount() {
        return sheetData.size();
    }

    /**
     * Get the number of columns.
     */
    public int getColumnCount() {
        return headers.size();
    }

    /**
     * Get all headers.
     */
    public List<String> getHeaders() {
        return new ArrayList<>(headers);
    }
}
