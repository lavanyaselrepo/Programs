package hwqe.baseframework.datacontext;

import java.util.HashMap;
import java.util.List;
import java.util.NoSuchElementException;

public class DataRow {
    private HashMap<Integer, Object> map = new HashMap<>();
    private List<DataColumn> cols;

    protected DataRow(List<DataColumn> columns) {
        this.cols = columns;
    }

    public <T> void setValue(int position, T value) {
        if (position < 1 || position > this.cols.size()) {
            throw new IndexOutOfBoundsException("Invalid index of data row");
        }
        map.put(position, value);
    }

    public <T> void setValue(String columnName, T value) {
        DataColumn column = this.cols.stream()
                .filter(x -> x.getName().equalsIgnoreCase(columnName))
                .findFirst()
                .get();
        if (column == null) {
            throw new NoSuchElementException("column does not exist in the table.");
        }
        map.put(column.getOrdinalPosition(), value);
    }

    public <T> T getValue(String columnName) {
        DataColumn column = this.cols.stream()
                .filter(x -> x.getName().equalsIgnoreCase(columnName))
                .findFirst()
                .get();
        if (column == null) {
            throw new NoSuchElementException("column does not exist in the table.");
        }
        return (T) map.get(column.getOrdinalPosition());
    }

    /**
     * Checks if a column with the given name exists (case-insensitive).
     * Returns false if columnName is null, cols is null/empty, or names are null.
     *
     * @param columnName column name to check; may be null
     * @return true if a matching column exists; false otherwise
     */
    public boolean hasColumn(final String columnName) {
        if (columnName == null || this.cols == null || this.cols.isEmpty()) {
            return false;
        }
        for (DataColumn col : this.cols) {
            if (col != null) {
                String name = col.getName();
                if (name != null && name.equalsIgnoreCase(columnName)) {
                    return true;
                }
            }
        }
        return false;
    }
}
