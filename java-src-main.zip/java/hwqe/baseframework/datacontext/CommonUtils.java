/**
 * CommonUtils is a utility class that does common functionalities like json parsing, translations handling,etc.
 *
 * @Author: Saloni Sharma
 * <p>
 * Copyright: Walmart Global Tech. Any use of this codebase outside Walmart Global Tech is considered unlawful.
 */
package hwqe.baseframework.datacontext;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import com.aventstack.extentreports.Status;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import hwqe.baseframework.utilities.Reporter;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CommonUtils {
    private static final Logger logger = LoggerFactory.getLogger(CommonUtils.class);

    String translations;

    public CommonUtils(String platform) {
        switch (platform) {
            case "ANDROID":
                translations = parseJsonFile(
                                "src/test/java/digitalPharmacyMobileAppTests/translations/translationsAndroid.json")
                        .toString();
                break;
            case "IOS":
                translations = parseJsonFile(
                                "src/test/java/digitalPharmacyMobileAppTests/translations/translationsIOS.json")
                        .toString();
                break;
            case "WEB":
                translations = parseJsonFile(
                                "src/test/java/digitalPharmacyMobileAppTests/translations/translationsWeb.json")
                        .toString();
                break;
        }
    }

    public CommonUtils() {}

    public JsonObject parseJsonFile(String fileName) {

        Object obj = null;
        try {
            JsonParser parser = new JsonParser();
            obj = parser.parse(new FileReader(fileName));

        } catch (FileNotFoundException e) {
            logger.error("File not found: {}", fileName, e);
        }
        return (JsonObject) obj;
    }

    public String readJsonFile(String fileName) {
        // JSON parser object to parse read file
        JsonParser jsonParser = new JsonParser();
        Object obj = null;
        try (FileReader reader = new FileReader(fileName)) {
            // Read JSON file
            obj = jsonParser.parse(reader);
        } catch (FileNotFoundException e) {
            logger.error("File not found: {}", fileName, e);
        } catch (IOException e) {
            logger.error("Error reading file: {}", fileName, e);
        }
        return obj.toString();
    }

    public Object getKeyInObject(Map objectToParse, String key) {

        Object value = null;

        Iterator<Map.Entry> itr1 = objectToParse.entrySet().iterator();

        while (itr1.hasNext()) {

            Map.Entry pair = itr1.next();

            if (pair.getKey().equals(key)) {
                value = pair.getValue();
                break;
            }
        }

        return value;
    }

    public Object getKeyInObject(String screenName, String key) {

        JsonParser jsonParser = new JsonParser();
        Object value = jsonParser
                .parse(translations)
                .getAsJsonObject()
                .get(screenName)
                .getAsJsonObject()
                .get(key)
                .getAsString();

        return value;
    }

    public Object getKeyInObject(String screenName, String subScreenName, String key) {

        JsonParser jsonParser = new JsonParser();
        Object value = jsonParser
                .parse(translations)
                .getAsJsonObject()
                .get(screenName)
                .getAsJsonObject()
                .getAsJsonObject(subScreenName)
                .get(key)
                .getAsString();

        return value;
    }

    public String nullStringValidation(String inputData) {
        String val = inputData;
        if ("null".equals(inputData)) {
            val = null;
        } else if ("invalid".equals(inputData)) {
            val = "invalid";
        }
        return val;
    }

    public JSONObject getJsonTestData(String jsonPath, String testName) {
        JSONObject jsonObject = new JSONObject(readJsonFile(jsonPath));
        Reporter.log("Test Name :: " + testName);
        JSONObject testInputDetails = null;
        if (jsonObject.keySet().contains(testName)) {
            testInputDetails = jsonObject.getJSONObject(testName);
        } else {
            Reporter.log(Status.FAIL, testName + " is not found in json path : " + jsonPath);
        }
        return testInputDetails;
    }
}
