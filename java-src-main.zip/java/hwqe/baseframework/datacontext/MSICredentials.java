package hwqe.baseframework.datacontext;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MSICredentials {
    String tenantId;
    String clientId;
    String clientSecret;
    String dbHost;
    String dbName;
}
