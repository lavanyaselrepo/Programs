package hwqe.baseframework.IMZFlow.datamodels.requests.orderForm;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SvcDocument{
	private int service_id;
	private int prescriber_id;
	private String svc_image_txt;
}