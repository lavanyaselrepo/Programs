package hwqe.baseframework.IMZFlow.datamodels.requests.orderForm;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RxFill{
	private int rx_fill_id;
}