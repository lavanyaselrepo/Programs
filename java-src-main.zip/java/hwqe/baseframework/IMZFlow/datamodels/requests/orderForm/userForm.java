package hwqe.baseframework.IMZFlow.datamodels.requests.orderForm;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class userForm{
	private String assigned_userid;
	private int siteid;
	private String wrkstatn_host_name;
}