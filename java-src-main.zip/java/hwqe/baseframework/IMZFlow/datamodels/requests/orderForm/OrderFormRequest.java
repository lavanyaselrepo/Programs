package hwqe.baseframework.IMZFlow.datamodels.requests.orderForm;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OrderFormRequest{
	private userForm user;
	private RxFill rx_fill;
	private SvcDocument svc_document;
}