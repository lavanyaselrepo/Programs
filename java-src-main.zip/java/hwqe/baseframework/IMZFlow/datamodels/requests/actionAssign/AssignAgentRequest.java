package hwqe.baseframework.IMZFlow.datamodels.requests.actionAssign;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AssignAgentRequest{
	private User user;
	private AssignOrders assign_orders;
}