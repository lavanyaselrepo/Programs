package hwqe.baseframework.IMZFlow.datamodels.requests.actionAssign;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OrderInfoItem{
	private int order_id;
	private int order_seq_nbr;
}