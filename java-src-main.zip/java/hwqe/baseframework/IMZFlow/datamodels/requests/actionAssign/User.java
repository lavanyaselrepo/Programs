package hwqe.baseframework.IMZFlow.datamodels.requests.actionAssign;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class User{
	private int siteid;
	private String assigned_userid;
	private String wrkstatn_host_name;
}