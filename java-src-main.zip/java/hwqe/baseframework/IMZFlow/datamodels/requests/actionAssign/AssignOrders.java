package hwqe.baseframework.IMZFlow.datamodels.requests.actionAssign;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AssignOrders{
	private List<OrderInfoItem> order_info;
}