package hwqe.baseframework.IMZFlow.datamodels.requests.completeImzOrder;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RxFill1{
	private int rx_fill_id;
	private RxFillItem rx_fill_item;
}