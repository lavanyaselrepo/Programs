package hwqe.baseframework.IMZFlow.datamodels.requests.completeImzOrder;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CompleteImzOrderRequest{
	private User1 user;
	private List<ImzAdministerDetailsItem> imz_administer_details;
}