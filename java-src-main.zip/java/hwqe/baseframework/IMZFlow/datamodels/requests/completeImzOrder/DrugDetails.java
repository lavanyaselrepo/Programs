package hwqe.baseframework.IMZFlow.datamodels.requests.completeImzOrder;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DrugDetails{
	private int service_id;
	private int admin_route_code;
	private int admin_site_code;
	private int prescriber_id;
}