package hwqe.baseframework.IMZFlow.datamodels.requests.completeImzOrder;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RxFillItem{
	private int item_mds_fam_id;
	private RxFillItemLot rx_fill_item_lot;
}