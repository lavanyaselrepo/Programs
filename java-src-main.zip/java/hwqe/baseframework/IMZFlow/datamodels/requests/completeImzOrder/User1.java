package hwqe.baseframework.IMZFlow.datamodels.requests.completeImzOrder;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class User1{
	private int siteid;
	private String assigned_userid;
	private String wrkstatn_host_name;
}