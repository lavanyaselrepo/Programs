package hwqe.baseframework.IMZFlow.datamodels.requests.completeImzOrder;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ImzAdministerDetailsItem{
	private RxFill1 rx_fill;
	private Object guardian_details;
	private DrugDetails drug_details;
	private String notes;
}