package hwqe.baseframework.IMZFlow.datamodels.requests.completeImzOrder;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RxFillItemLot{
	private String lot_nbr;
	private String expiration_date;
}