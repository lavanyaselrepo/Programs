package hwqe.baseframework.IMZFlow;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.IMZFlow.datamodels.requests.actionAssign.AssignAgentRequest;
import hwqe.baseframework.IMZFlow.datamodels.requests.actionAssign.AssignOrders;
import hwqe.baseframework.IMZFlow.datamodels.requests.actionAssign.OrderInfoItem;
import hwqe.baseframework.IMZFlow.datamodels.requests.actionAssign.User;
import hwqe.baseframework.IMZFlow.datamodels.requests.completeImzOrder.*;
import hwqe.baseframework.IMZFlow.datamodels.requests.orderForm.OrderFormRequest;
import hwqe.baseframework.IMZFlow.datamodels.requests.orderForm.RxFill;
import hwqe.baseframework.IMZFlow.datamodels.requests.orderForm.SvcDocument;
import hwqe.baseframework.IMZFlow.datamodels.requests.orderForm.userForm;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class IMZFlowAPIManager {
    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop;
    ServiceRequest req = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;
    public IMZFlowAPIManager (){
        prop = PropertyReader.getInstance();
        prop.loadCustomProperties("config/fom/");
    }


    public ServiceResponse assignToOrders(int siteId,int orderId,int seqNbr,String userIdAssigned,String workStationNbr){
        AssignAgentRequest assignRequest;
        assignRequest = AssignAgentRequest.builder().user(userInfo(siteId,userIdAssigned,workStationNbr)).assign_orders(assignOrderToAgent(orderId,seqNbr)).build();
        req.setRequestPayloadWithNulls(assignRequest);
        String serviceEndPointUrl = StoreIDManager.createEndPointURL(Integer.toString(siteId), prop.getProperty("fom.connexusWrapper.portNo"), prop.getProperty("fom.connexusWrapper.sapsUrl"), prop.getProperty("fom.imz.connexusWrapper.assignOrderEndpoint"));
        req.setUrl(serviceEndPointUrl);
        headers.put("content-type", "application/json");
        headers.put("Authorization", prop.getProperty("imz.authentication"));
        req.setHeaders(headers);
        Reporter.log("Assign Associate Request endpoint: " + req.getUrl());
        Reporter.logJSON("Assign Associate Request", assignRequest);
        Log.info("Assign Associate RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("Assign Associate Response", resp.getDataResponse());
        Log.info("Assign Associate ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }
    public AssignOrders assignOrderToAgent(int orderId,int seqNbr){
        AssignOrders orderAssignment;
        orderAssignment=AssignOrders.builder().order_info(orderInfo(orderId,seqNbr)).build();
        return orderAssignment;
    }
    public List<OrderInfoItem> orderInfo(int orderId,int seqNbr){
        List<OrderInfoItem> infoItemList=new ArrayList<>();
        OrderInfoItem orderInformation;
        orderInformation=OrderInfoItem.builder().order_id(orderId).order_seq_nbr(seqNbr).build();
        infoItemList.add(orderInformation);
        return infoItemList;
    }
    public User userInfo(int siteId,String userIdAssigned,String workStationNbr){
        User userInfor;
        userInfor=User.builder().siteid(siteId).assigned_userid(userIdAssigned).wrkstatn_host_name(workStationNbr).build();
        return userInfor;
    }
    public ServiceResponse orderForm(int fillId,int serviceId,int presId,int siteId,String userIdAssigned,String workStationNbr){
        OrderFormRequest orderFormRequest=OrderFormRequest.builder().user(userInform(siteId,userIdAssigned,workStationNbr)).rx_fill(rxFill(fillId)).svc_document(svcDoc(serviceId,presId)).build();
        req.setRequestPayloadWithNulls(orderFormRequest);
        String serviceEndPointUrl = StoreIDManager.createEndPointURL(String.valueOf(siteId), prop.getProperty("fom.connexusWrapper.portNo"), prop.getProperty("fom.connexusWrapper.sapsUrl"), prop.getProperty("imz.orderForm.endpoint"));
        req.setUrl(serviceEndPointUrl);
        headers.put("content-type", "application/json");
        headers.put("Authorization", prop.getProperty("imz.authentication"));
        req.setHeaders(headers);
        Reporter.log("Order Form Request endpoint: " + req.getUrl());
        Reporter.logJSON("Order Form Request", orderFormRequest);
        Log.info("Order Form RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req);
        return resp;
    }
    public RxFill rxFill(int fillId){
        RxFill rxFillDetails=RxFill.builder().rx_fill_id(fillId).build();
        return rxFillDetails;
    }
    public SvcDocument svcDoc(int serviceId,int presId){
        SvcDocument svcDocDetails=SvcDocument.builder().service_id(serviceId).prescriber_id(presId).svc_image_txt(prop.getProperty("imz.imageTxt")).build();
        return svcDocDetails;
    }
    public userForm userInform(int siteId, String userIdAssigned,String workStationNbr){
        userForm userInformation;
        userInformation= userForm.builder().siteid(siteId).assigned_userid(userIdAssigned)
                .wrkstatn_host_name(workStationNbr).build();
        return userInformation;
    }
    public ServiceResponse completeOrder(int presId,int serviceId,int siteId,String userIdAssigned,int fillId,int item_mds_fam_id,
                                         String workStationNbr,int adminSiteCode,int adminRouteCode,String notes,String lotNbr,String expirationDate){
        CompleteImzOrderRequest completeImzOrderRequest;
        completeImzOrderRequest=CompleteImzOrderRequest.builder()
                .imz_administer_details(imzAdminister(presId,serviceId,fillId,item_mds_fam_id,adminSiteCode,adminRouteCode,notes,lotNbr,expirationDate))
                .user(userdetails(siteId,userIdAssigned,workStationNbr)).build();
        req.setRequestPayloadWithNulls(completeImzOrderRequest);
        String serviceEndPointUrl = StoreIDManager.createEndPointURL(String.valueOf(siteId), prop.getProperty("fom.connexusWrapper.portNo"), prop.getProperty("fom.connexusWrapper.sapsUrl"), prop.getProperty("imz.orderComplete"));
        req.setUrl(serviceEndPointUrl);
        headers.put("content-type", "application/json");
        headers.put("Authorization", prop.getProperty("imz.authentication"));
        req.setHeaders(headers);
        Reporter.log("Order Complete Request endpoint: " + req.getUrl());
        Reporter.logJSON("Order Complete Request", completeImzOrderRequest);
        Log.info("Order Complete RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req);
        return resp;
    }
    public List<ImzAdministerDetailsItem> imzAdminister(int presId,int serviceId,int fillId,int item_mds_fam_id,
                                                        int adminSiteCode,int adminRouteCode,String notes,String lotNbr,String expirationDate){
        List<ImzAdministerDetailsItem> administerDetailsItems=new ArrayList<>();
        ImzAdministerDetailsItem imzAdministerDetailsItem;
        imzAdministerDetailsItem=ImzAdministerDetailsItem.builder().drug_details(drugDetails(presId,serviceId,adminSiteCode,adminRouteCode))
                .notes(notes).guardian_details(null).rx_fill(rxFillDetail(fillId,item_mds_fam_id,lotNbr,expirationDate)).build();
        administerDetailsItems.add(imzAdministerDetailsItem);
        return administerDetailsItems;
    }
    public DrugDetails drugDetails(int presId,int serviceId,int adminSiteCode,int adminRouteCode){
        DrugDetails drugDetails=DrugDetails.builder().admin_site_code(adminSiteCode)
                .admin_route_code(adminRouteCode).prescriber_id(presId).service_id(serviceId).build();
        return drugDetails;
    }
    public RxFill1 rxFillDetail(int fillId,int item_mds_fam_id,String lotNbr,String expirationDate){
        RxFill1 rxFillDetail=
                RxFill1.builder()
                .rx_fill_id(fillId).rx_fill_item(rxFillItem(item_mds_fam_id,lotNbr,expirationDate)).build();
        return rxFillDetail;
    }
    public User1 userdetails(int siteId,String userIdAssigned,String workStationNbr){
        User1 userDetail;
        userDetail= User1.builder().siteid(siteId).assigned_userid(userIdAssigned)
                .wrkstatn_host_name(workStationNbr).build();
        return userDetail;
    }
    public RxFillItem rxFillItem(int item_mds_fam_id,String lotNbr,String expirationDate){
        RxFillItem rxFillItem=RxFillItem.builder().item_mds_fam_id(item_mds_fam_id).rx_fill_item_lot(rxFillItemLot(lotNbr,expirationDate)).build();
        return rxFillItem;
    }
    public RxFillItemLot rxFillItemLot(String lotNbr,String expirationDate){
        RxFillItemLot rxFillItemLot=RxFillItemLot.builder().lot_nbr(lotNbr).expiration_date(expirationDate).build();
        return rxFillItemLot;
    }
}
