package hwqe.baseframework.domServiceContext.constants;

/**
 * Constants for DOM Service API interactions.
 * Contains header names, header values, and API endpoints for both REST V1 and GraphQL V4.
 */
public final class DomServiceConstants {

    // ==================== API Headers (HNW) ====================
    public static final String CONTENT_TYPE_HEADER = "Content-Type";
    public static final String CONTENT_ENCODING_HEADER = "Content-Encoding";
    public static final String ACCEPT_ENCODING_HEADER = "Accept-Encoding";
    public static final String CONSUMER_ID_HEADER = "WM_CONSUMER.ID";
    public static final String SERVICE_NAME_HEADER = "WM_SVC.NAME";
    public static final String SERVICE_ENV_HEADER = "WM_SVC.ENV";
    public static final String STORE_ID_HEADER = "x-hnw-rx-store-id";
    public static final String SESSION_ID_HEADER = "x-hnw-rx-session-id";
    public static final String CLIENT_WORKSTATION_HEADER = "x-hnw-rx-client-workstation";
    public static final String CLIENT_NAME_HEADER = "x-hnw-rx-client-name";
    public static final String CLIENT_HOSTNAME_HEADER = "x-hnw-rx-client-hostname";
    public static final String CLIENT_IP_ADDRESS_HEADER = "x-hnw-rx-client-ip-address";
    public static final String GRAPHQL_SCHEMA_VERSION_HEADER = "x-hnw-graphql-schema-version";
    public static final String REQ_TRACK_ID_HEADER = "x-hnw-rx-req-track-id";
    public static final String REQ_ID_HEADER = "x-hnw-rx-req-id";
    public static final String USER_ID_HEADER = "x-hnw-rx-user-id";
    public static final String TOKEN_TYPE_HEADER = "x-hnw-rx-token-type";

    // ==================== API Header Values ====================
    public static final String CONTENT_TYPE_JSON = "application/json";
    public static final String ENCODING_JSON = "json";
    public static final String DEFAULT_WORKSTATION = "dragon-test-ws";
    public static final String DEFAULT_CLIENT_NAME = "shipping";
    public static final String DEFAULT_USER_ID = "dragon-test-user";
    public static final String DEFAULT_HOSTNAME = "dragon-test-host";
    public static final String DEFAULT_IP_ADDRESS = "127.0.0.1";

    // ==================== REST V1 Endpoints ====================
    public static final String HEALTH_CHECK_ENDPOINT = "/v1/health";
    public static final String DISPENSE_ORDERS_V1_ENDPOINT = "/v1/dispenseorders";
    public static final String ADMIN_DISPENSE_ORDERS_V1_ENDPOINT = "/admin/v1/dispenseorders";
    public static final String SCHEDULER_ENDPOINT = "/v1/dispenseorders/jobs";
    public static final String METADATA_ENDPOINT = "/v1/dispensemetadata";

    // ==================== GraphQL V4 Endpoint ====================
    public static final String GRAPHQL_ENDPOINT = "/dispenseorders/graphql";
    // ==================== REST V1 Action Query Params ====================
    public static final String ACTION_CREATE = "create";
    public static final String ACTION_SEARCH = "search";
    public static final String ACTION_SELECT_FOR_DISPENSE = "selectForDispense";
    public static final String ACTION_DISPENSE = "dispense";
    public static final String ACTION_RETURN_TO_STOCK = "returnToStock";
    public static final String ACTION_STORE_DISPENSED = "storeDispensed";
    public static final String ACTION_DESELECT_FOR_DISPENSE = "deselectForDispense";
    public static final String ACTION_RESEND_PACKET_BY_ID = "resendPacketById";
    public static final String ACTION_RESET_FIELDS = "resetFields";

    // ==================== Azure SQL Table Names ====================
    public static final String TABLE_DISPENSE_STATUS = "domser.DispenseStatus";
    public static final String TABLE_LEDGER = "domser.Ledger";
    public static final String TABLE_LINEAGE = "domser.Lineage";
    public static final String TABLE_DISPENSE_STORE_SYNC = "domser.DispenseStoreSync";
    public static final String TABLE_EGRESS_METADATA = "domser.EgressMetadata";
    public static final String TABLE_ORDER_DETAIL_ACTIVITY = "domser.DispenseOrderDetailActivity";

    private DomServiceConstants() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}
