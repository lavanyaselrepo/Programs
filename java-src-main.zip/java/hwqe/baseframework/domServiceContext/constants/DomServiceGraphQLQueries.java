package hwqe.baseframework.domServiceContext.constants;

/**
 * GraphQL queries and mutations for DOM Service V4 API.
 * Contains the full query/mutation strings used for search, select, deselect, and dispense operations.
 */
public final class DomServiceGraphQLQueries {

    // ==================== Queries ====================

    public static final String SEARCH_BY_PATIENT_ID =
        "query searchByPatientId($patientId: Int, $include: Include, $exclude: Exclude) {\n" +
        "  searchByPatientId(patientId: $patientId, include: $include, exclude: $exclude) {\n" +
        "    didList\n" +
        "    message\n" +
        "    searchResults {\n" +
        "      searchedItemsDetail {\n" +
        "        controlSet { did doGroupId doGroupCode orderId orderSeqNbr rxFillId " +
        "          minorVersionNbr majorVersionNbr dispenseState assignedUserId workQueueCode priority }\n" +
        "        dispenseDetails {\n" +
        "          rxFillInfo { rxFillSeqNbr fillTypeDesc fillDate fillItemQty fillQty }\n" +
        "          rxInfo { rxNbr rxStatus }\n" +
        "          patientInfo { patientId }\n" +
        "        }\n" +
        "        dispenseState { state majorVersion minorVersion }\n" +
        "      }\n" +
        "    }\n" +
        "  }\n" +
        "}";

    public static final String SEARCH_BY_DID =
        "query searchByDid($did: String!, $include: Include, $exclude: Exclude) {\n" +
        "  searchByDid(did: $did, include: $include, exclude: $exclude) {\n" +
        "    didList\n" +
        "    message\n" +
        "    searchResults {\n" +
        "      searchedItemsDetail {\n" +
        "        controlSet { did doGroupId doGroupCode orderId orderSeqNbr rxFillId " +
        "          minorVersionNbr majorVersionNbr dispenseState assignedUserId workQueueCode priority " +
        "          estimatePickupTime rxOriginState rxPrescriberId }\n" +
        "        dispenseDetails {\n" +
        "          rxFillInfo { rxFillSeqNbr fillTypeDesc fillDate fillItemQty fillQty chargeInd " +
        "            isTaxable localThirdPartyAmount patientDueAmt primaryPhmCompanyNameAbbr " +
        "            thirdPartyAmount " +
        "            thirdPartyInfo { carrierId carrierPlanId phmCompanyNameAbbr copayAmt txnTypeCode txnAmount } " +
        "            dispensedItemInfo { productName shortName ndc upcNumber drugControlCode } " +
        "          }\n" +
        "          rxInfo { rxNbr rxContentType compInd compoundId " +
        "            presProdInfo { presProdStrength presProdName prodShortName } " +
        "          }\n" +
        "          patientInfo { patientId }\n" +
        "          storeParms { storeType }\n" +
        "          orderInfo { toteNbr " +
        "            dispenseLocationInfo { dispenseType } " +
        "          }\n" +
        "        }\n" +
        "        shippingDetails { phmPackageId ormdHazMatInd coldStorageInd " +
        "          signatureRequiredInd patientShipChargeInd patientShipFeeAmount " +
        "          deliveryMethodCode shippingType " +
        "          shippingAddress { name addressLine1 addressLine2 addressLine3 cityName " +
        "            stateProvCode postalCode countryCode phoneNbr } " +
        "        }\n" +
        "      }\n" +
        "    }\n" +
        "  }\n" +
        "}";

    // ==================== Mutations ====================

    public static final String SELECT_FOR_DISPENSE =
        "mutation selectfordispense($selectInput: SelectForDispenseInput!, $override: Boolean) {\n" +
        "  selectfordispense(selectInput: $selectInput, override: $override) {\n" +
        "    didList\n" +
        "    message\n" +
        "    selectedItemsDetail {\n" +
        "      controlSet {\n" +
        "        did doGroupId doGroupCode userWorkLocation estimatePickupTime " +
        "        initiatedDateTime lastModifiedDateTime userHomeStoreId doType priority " +
        "        orderId initiatedStore requestSeqNbr rxFillId rxId minorVersionNbr " +
        "        orderSeqNbr majorVersionNbr companyCode currentAction userWorkstation " +
        "        workQueueCode assignedUserId rxOriginState rxPrescriberId dispenseState\n" +
        "      }\n" +
        "      dispenseDetails {\n" +
        "        rxFillInfo { rxFillSeqNbr fillTypeDesc fillDate fillItemQty fillQty chargeInd patientDueAmt }\n" +
        "        rxInfo { rxNbr compInd compoundId }\n" +
        "        patientInfo { patientId }\n" +
        "      }\n" +
        "      shippingDetails { phmPackageId shippingType }\n" +
        "    }\n" +
        "  }\n" +
        "}";

    public static final String DESELECT_FOR_DISPENSE =
        "mutation deselectfordispense($deselectInput: DeselectForDispenseInput!) {\n" +
        "  deselectfordispense(deselectInput: $deselectInput) {\n" +
        "    didList\n" +
        "    message\n" +
        "  }\n" +
        "}";

    public static final String DISPENSE =
        "mutation dispense($dispenseInput: DispenseInput!) {\n" +
        "  dispense(dispenseInput: $dispenseInput) {\n" +
        "    didList\n" +
        "    message\n" +
        "  }\n" +
        "}";

    private DomServiceGraphQLQueries() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}
