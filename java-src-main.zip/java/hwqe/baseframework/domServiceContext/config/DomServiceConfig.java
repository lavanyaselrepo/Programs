package hwqe.baseframework.domServiceContext.config;

import hwqe.baseframework.utilities.PropertyReader;
import lombok.Getter;

/**
 * Configuration class for DOM Service.
 * Loads service-specific properties from config/dom/ directory.
 * Supports both REST V1 and GraphQL V4 endpoints.
 */
@Getter
public class DomServiceConfig {

    private final String serviceUrl;
    private final String consumerId;
    private final String serviceName;
    private final String serviceEnv;
    private final String graphqlSchemaVersion;

    private static DomServiceConfig domServiceConfig = null;

    private DomServiceConfig() {
        PropertyReader propertyReader = PropertyReader.getInstance();
        propertyReader.loadCustomProperties("config/dom/");

        serviceUrl = propertyReader.getProperty("dom.service.url");
        serviceName = propertyReader.getProperty("dom.wm.svc.name");
        serviceEnv = propertyReader.getProperty("dom.wm.svc.env");
        consumerId = propertyReader.getProperty("dom.wm.consumer.id");
        String schemaVersion = propertyReader.getProperty("dom.graphql.schema.version");
        graphqlSchemaVersion = schemaVersion != null ? schemaVersion : "1.0";
    }

    /**
     * Returns singleton instance of DomServiceConfig.
     * @return DomServiceConfig instance
     */
    public static DomServiceConfig getInstance() {
        if (domServiceConfig == null) {
            domServiceConfig = new DomServiceConfig();
        }
        return domServiceConfig;
    }
}
