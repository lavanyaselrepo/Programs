package hwqe.baseframework.apicontext;

import java.time.LocalDate;
import java.util.HashMap;

import com.google.gson.*;
import com.google.gson.GsonBuilder;

public class ServiceRequest {

    private String url;
    private HashMap<String, String> headers;
    private String requestPayload;
    private Proxy proxy;
    // private PropertyReader prop = PropertyReader.getInstance();
    private HashMap<String, String> formPayload;
    private byte[] bytePayload;

    public HashMap<String, String> getFormPayload() {
        return formPayload;
    }

    public void setFormPayload(HashMap<String, String> formPayload) {
        this.formPayload = formPayload;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public HashMap<String, String> getHeaders() {
        return headers;
    }

    public void setHeaders(HashMap<String, String> headers) {
        this.headers = headers;
    }

    public String getRequestPayload() {
        return requestPayload;
    }
    
    public byte[] getBytePayload() {
        return bytePayload;
    }

    public <T> void setRequestPayload(T requestPayload) {
        Gson gson = new GsonBuilder()
                .registerTypeAdapter(LocalDate.class, new GsonLocalDateAdapter())
                .create();
        this.requestPayload = gson.toJson(requestPayload);
    }

    public void setRequestPayload(String requestPayload) {
        this.requestPayload = requestPayload;
    }
    
    public void setBytePayload(byte[] bytePayload) {
        this.bytePayload = bytePayload;
    }

    public <T> void setRequestPayloadWithNulls(T requestPayload) {
        Gson gson = new Gson();
        GsonBuilder builder = new GsonBuilder();
        gson = builder.serializeNulls().create();
        this.requestPayload = gson.toJson(requestPayload);
    }

    //    public Pair<String, String> writeToFile(String fileName) {
    //        if (this.requestPayload == null || this.requestPayload.isEmpty())
    //            return null;
    //        try {
    //            Random r = new Random();
    //            String fName = fileName + "_" + r.nextInt(9999) + ".txt";
    //            Files.write(Paths.get(prop.getProperty("app.workingfolder_path") + fName),
    // this.requestPayload.getBytes());
    //            return new Pair<>(fName, prop.getProperty("app.workingfolder_path") + fName);
    //        } catch (Exception e) {
    //            System.out.println(e.getMessage());
    //        }
    //        return null;
    //    }

    public Proxy getProxy() {
        return this.proxy != null ? this.proxy : Proxy.NONE;
    }

    public void setProxy(Proxy proxy) {
        this.proxy = proxy;
    }

    public void setUrl(String baseURL, HashMap<String, String> queryParams) {
        String encodedParam = queryParams.entrySet().stream()
                .map(p -> p.getKey() + "=" + p.getValue())
                .reduce((p1, p2) -> p1 + "&" + p2)
                .orElseThrow(() -> new IllegalArgumentException(" Query parameters are not valid"));
        this.url = baseURL.concat("?").concat(encodedParam);
    }

    public String setUrlReq(String baseURL, HashMap<String, String> queryParams) {
        String encodedParam = queryParams.entrySet().stream()
                .map(p -> p.getKey() + "=" + p.getValue())
                .reduce((p1, p2) -> p1 + "&" + p2)
                .orElseThrow(() -> new IllegalArgumentException(" Query parameters are not valid"));
        this.url = baseURL.concat("?").concat(encodedParam);

        return url;
    }
}
