package hwqe.baseframework.apicontext;

import java.io.File;
import java.util.HashMap;

import hwqe.baseframework.interfaces.IRestClient;
import hwqe.baseframework.utilities.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.*;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RestClient implements IRestClient {
    private static final Logger logger = LoggerFactory.getLogger(RestClient.class);

    // Timeout values for connection and request - 5 minutes for Connexus Wrapper APIs
    private static final int CONNECTION_TIMEOUT_MS = 300_000;
    private static final int REQUEST_TIMEOUT_MS = 300_000;

    // Proxy configuration
    private static final String INTERNAL_PROXY_HOST = "proxy.wal-mart.com";
    private static final int INTERNAL_PROXY_PORT = 9080;
    private static final String EXTERNAL_PROXY_HOST = "sysproxy.wal-mart.com";
    private static final int EXTERNAL_PROXY_PORT = 8080;

    /**
     * Builds a configured HttpClient with SSL, proxy, and timeout settings.
     *
     * @param request           The service request containing proxy configuration
     * @param connectionTimeout Connection timeout in milliseconds
     * @param requestTimeout    Request/socket timeout in milliseconds
     * @return Configured CloseableHttpClient
     */
    private CloseableHttpClient buildHttpClient(ServiceRequest request, int connectionTimeout, int requestTimeout) {
        try {
            HttpClientBuilder builder = HttpClients.custom()
                    .setSSLContext(new SSLContextBuilder()
                            .loadTrustMaterial(null, TrustAllStrategy.INSTANCE)
                            .build())
                    .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE);
                    // NOTE: useSystemProperties() intentionally omitted — on Looper runners the JVM
                    // picks up https.proxyHost=sysproxy.wal-mart.com:8080 which routes internal
                    // SAPS/Connexus HTTPS traffic (non-443 ports) through the corporate proxy,
                    // causing: SSLException: Unsupported or unrecognized SSL message.
                    // All proxy routing is handled explicitly via the Proxy enum switch below.

            // Configure proxy based on request settings
            Proxy proxy = request.getProxy() != null ? request.getProxy() : Proxy.NONE;
            switch (proxy) {
                case INTERNAL:
                    builder.setProxy(new HttpHost(INTERNAL_PROXY_HOST, INTERNAL_PROXY_PORT));
                    break;
                case EXTERNAL:
                    builder.setProxy(new HttpHost(EXTERNAL_PROXY_HOST, EXTERNAL_PROXY_PORT));
                    break;
                case NONE:
                default:
                    // No proxy
                    break;
            }

            // Configure timeouts
            builder.setDefaultRequestConfig(RequestConfig.custom()
                    .setConnectTimeout(connectionTimeout)
                    .setConnectionRequestTimeout(requestTimeout)
                    .setSocketTimeout(requestTimeout)
                    .build());

            return builder.build();
        } catch (Exception e) {
            logger.error("Failed to build HTTP client: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to build HTTP client", e);
        }
    }

    /**
     * Builds a configured HttpClient using default timeouts.
     *
     * @param request The service request containing proxy configuration
     * @return Configured CloseableHttpClient
     */
    private CloseableHttpClient buildHttpClient(ServiceRequest request) {
        return buildHttpClient(request, CONNECTION_TIMEOUT_MS, REQUEST_TIMEOUT_MS);
    }

    @Override
    public ServiceResponse performPost(ServiceRequest request, int connectionTimeOut, int requestTimeOut) {
        ServiceResponse response = new ServiceResponse();
        try (CloseableHttpClient httpClient = buildHttpClient(request, connectionTimeOut, requestTimeOut)) {
            HttpPost post = new HttpPost(request.getUrl());
            for (HashMap.Entry<String, String> entry : request.getHeaders().entrySet()) {
                post.addHeader(entry.getKey(), entry.getValue());
            }

            if (request.getBytePayload() != null) {
            	ByteArrayEntity byteEntity = new ByteArrayEntity(request.getBytePayload());
            	post.setEntity(byteEntity);
            } else if (StringUtils.isNotNullOrEmpty(request.getRequestPayload())) {
                StringEntity dataEntity = new StringEntity(request.getRequestPayload());
                post.setEntity(dataEntity);
            }

            HttpResponse resp = httpClient.execute(post);
            response.setStatusCode(resp.getStatusLine().getStatusCode());
            response.setStatusDesc(resp.getStatusLine().getReasonPhrase());

            Header[] headers = resp.getAllHeaders();
            HashMap<String, String> responseHeaders = new HashMap<>();
            for (Header header : headers) {
                if (responseHeaders.get(header.getName()) != null) {
                    responseHeaders.put(
                            header.getName(), responseHeaders.get(header.getName()) + " ; " + header.getValue());
                } else {
                    responseHeaders.put(header.getName(), header.getValue());
                }
            }
            response.setHeaders(responseHeaders);
            if (resp.getEntity() != null) {
                response.setDataResponse(EntityUtils.toString(resp.getEntity()));
            }
        } catch (Exception ex) {
            logger.error("Error performing POST request to {}: {}", request.getUrl(), ex.getMessage(), ex);
        }
        return response;
    }

    @Override
    public ServiceResponse performPost(ServiceRequest request) {
        return performPost(request, CONNECTION_TIMEOUT_MS, REQUEST_TIMEOUT_MS);
    }

    @Override
    public ServiceResponse postFormData(ServiceRequest request) {
        ServiceResponse response = new ServiceResponse();
        try (CloseableHttpClient httpClient = buildHttpClient(request)) {
            HttpPost post = new HttpPost(request.getUrl());
            for (HashMap.Entry<String, String> entry : request.getHeaders().entrySet()) {
                post.addHeader(entry.getKey(), entry.getValue());
            }
            MultipartEntityBuilder mpBuilder = MultipartEntityBuilder.create();
            for (HashMap.Entry<String, String> entry : request.getFormPayload().entrySet()) {
                mpBuilder.addPart(entry.getKey(), new StringBody(entry.getValue(), ContentType.create("text/plain")));
            }
            HttpEntity entity = mpBuilder.build();
            post.setEntity(entity);
            HttpResponse resp = httpClient.execute(post);
            response.setStatusCode(resp.getStatusLine().getStatusCode());
            response.setStatusDesc(resp.getStatusLine().getReasonPhrase());
            if (resp.getEntity() != null) {
                response.setDataResponse(EntityUtils.toString(resp.getEntity()));
            }
        } catch (Exception ex) {
            logger.error("Error posting form data to {}: {}", request.getUrl(), ex.getMessage(), ex);
        }
        return response;
    }

    @Override
    public ServiceResponse performPut(ServiceRequest request) {
        ServiceResponse response = new ServiceResponse();
        try (CloseableHttpClient httpClient = buildHttpClient(request)) {
            HttpPut put = new HttpPut(request.getUrl());
            for (HashMap.Entry<String, String> entry : request.getHeaders().entrySet()) {
                put.addHeader(entry.getKey(), entry.getValue());
            }
            StringEntity dataEntity = new StringEntity(request.getRequestPayload());
            put.setEntity(dataEntity);
            HttpResponse resp = httpClient.execute(put);
            response.setStatusCode(resp.getStatusLine().getStatusCode());
            response.setStatusDesc(resp.getStatusLine().getReasonPhrase());
            if (resp.getEntity() != null) {
                response.setDataResponse(EntityUtils.toString(resp.getEntity()));
            }
        } catch (Exception ex) {
            logger.error("Error performing PUT request to {}: {}", request.getUrl(), ex.getMessage(), ex);
        }
        return response;
    }

    @Override
    public ServiceResponse uploadFile(ServiceRequest request) {
        ServiceResponse response = new ServiceResponse();
        try (CloseableHttpClient httpClient = buildHttpClient(request)) {
            HttpPost post = new HttpPost(request.getUrl());
            for (HashMap.Entry<String, String> entry : request.getHeaders().entrySet()) {
                post.addHeader(entry.getKey(), entry.getValue());
            }
            MultipartEntityBuilder mpBuilder = MultipartEntityBuilder.create();
            for (HashMap.Entry<String, String> entry : request.getFormPayload().entrySet()) {
                if (!"file".equalsIgnoreCase(entry.getKey())) {
                    mpBuilder.addPart(
                            entry.getKey(), new StringBody(entry.getValue(), ContentType.create("text/plain")));
                }
            }
            HttpEntity entity = mpBuilder
                    .addPart(
                            "file",
                            new FileBody(new File(request.getFormPayload().get("file"))))
                    .build();
            post.setEntity(entity);
            HttpResponse resp = httpClient.execute(post);
            response.setStatusCode(resp.getStatusLine().getStatusCode());
            response.setStatusDesc(resp.getStatusLine().getReasonPhrase());
            if (resp.getEntity() != null) {
                response.setDataResponse(EntityUtils.toString(resp.getEntity()));
            }
        } catch (Exception ex) {
            logger.error("Error uploading file to {}: {}", request.getUrl(), ex.getMessage(), ex);
        }
        return response;
    }

    @Override
    public ServiceResponse performGet(ServiceRequest request) {
        ServiceResponse response = new ServiceResponse();
        try (CloseableHttpClient httpClient = buildHttpClient(request)) {
            HttpGet get = new HttpGet(request.getUrl());

            for (HashMap.Entry<String, String> entry : request.getHeaders().entrySet()) {
                get.addHeader(entry.getKey(), entry.getValue());
            }
            HttpResponse resp = httpClient.execute(get);
            response.setStatusCode(resp.getStatusLine().getStatusCode());
            response.setStatusDesc(resp.getStatusLine().getReasonPhrase());
            Header[] headers = resp.getAllHeaders();
            HashMap<String, String> responseHeaders = new HashMap<>();
            for (Header header : headers) {
                responseHeaders.put(header.getName(), header.getValue());
            }
            response.setHeaders(responseHeaders);
            if (resp.getEntity() != null) {
                if ("application/octet-stream".equals(responseHeaders.get("content-type"))) {
                    response.setBytePayload(EntityUtils.toByteArray(resp.getEntity()));
                } else {
                    response.setDataResponse(EntityUtils.toString(resp.getEntity()));
                }
            }
        } catch (Exception ex) {
            logger.error("Error performing GET request to {}: {}", request.getUrl(), ex.getMessage(), ex);
        }
        return response;
    }

    @Override
    public ServiceResponse performPatch(ServiceRequest request) {
        ServiceResponse response = new ServiceResponse();
        try (CloseableHttpClient httpClient = buildHttpClient(request)) {
            HttpPatch patch = new HttpPatch(request.getUrl());
            for (HashMap.Entry<String, String> entry : request.getHeaders().entrySet()) {
                patch.addHeader(entry.getKey(), entry.getValue());
            }
            StringEntity dataEntity = new StringEntity(request.getRequestPayload());
            patch.setEntity(dataEntity);
            HttpResponse resp = httpClient.execute(patch);
            response.setStatusCode(resp.getStatusLine().getStatusCode());
            response.setStatusDesc(resp.getStatusLine().getReasonPhrase());
            if (resp.getEntity() != null) {
                response.setDataResponse(EntityUtils.toString(resp.getEntity()));
            }
        } catch (Exception ex) {
            logger.error("Error performing PATCH request to {}: {}", request.getUrl(), ex.getMessage(), ex);
        }
        return response;
    }

    @Override
    public ServiceResponse performDelete(ServiceRequest request) {
        ServiceResponse response = new ServiceResponse();
        try (CloseableHttpClient httpClient = buildHttpClient(request)) {
            HttpResponse resp;
            if (StringUtils.isNotNullOrEmpty(request.getRequestPayload())) {
                HttpDeleteWithBody httpDeleteWithBody = new HttpDeleteWithBody(request.getUrl());
                for (HashMap.Entry<String, String> entry : request.getHeaders().entrySet()) {
                    httpDeleteWithBody.addHeader(entry.getKey(), entry.getValue());
                }
                StringEntity dataEntity = new StringEntity(request.getRequestPayload());
                httpDeleteWithBody.setEntity(dataEntity);
                resp = httpClient.execute(httpDeleteWithBody);
            } else {
                HttpDelete delete = new HttpDelete(request.getUrl());
                for (HashMap.Entry<String, String> entry : request.getHeaders().entrySet()) {
                    delete.addHeader(entry.getKey(), entry.getValue());
                }
                resp = httpClient.execute(delete);
            }
            response.setStatusCode(resp.getStatusLine().getStatusCode());
            response.setStatusDesc(resp.getStatusLine().getReasonPhrase());
            if (resp.getEntity() != null) {
                response.setDataResponse(EntityUtils.toString(resp.getEntity()));
            }
        } catch (Exception ex) {
            logger.error("Error performing DELETE request to {}: {}", request.getUrl(), ex.getMessage(), ex);
        }
        return response;
    }

    @Override
    public ServiceResponse performHead(ServiceRequest request) {
        ServiceResponse response = new ServiceResponse();
        try (CloseableHttpClient httpClient = buildHttpClient(request)) {
            HttpHead get = new HttpHead(request.getUrl());

            for (HashMap.Entry<String, String> entry : request.getHeaders().entrySet()) {
                get.addHeader(entry.getKey(), entry.getValue());
            }
            HttpResponse resp = httpClient.execute(get);
            response.setStatusCode(resp.getStatusLine().getStatusCode());
            response.setStatusDesc(resp.getStatusLine().getReasonPhrase());
            Header[] headers = resp.getAllHeaders();
            HashMap<String, String> responseHeaders = new HashMap<>();
            for (Header header : headers) {
                responseHeaders.put(header.getName(), header.getValue());
            }
            response.setHeaders(responseHeaders);
            if (resp.getEntity() != null) {
                response.setDataResponse(EntityUtils.toString(resp.getEntity()));
            }
        } catch (Exception ex) {
            logger.error("Error performing GET request to {}: {}", request.getUrl(), ex.getMessage(), ex);
        }
        return response;
    }

    @Override
    public ServiceResponse performPost(ServiceRequest request, int retryCount) {
        ServiceResponse response = new ServiceResponse();
        int attempts = 0;
        boolean success = false;

        while (attempts < retryCount && !success) {
            try {
                response = performPost(request, CONNECTION_TIMEOUT_MS, REQUEST_TIMEOUT_MS);
                if (response.getStatusCode() >= 200 && response.getStatusCode() < 400) {
                    success = true;
                } else {
                    logger.info("Attempt {} failed with status code: {}", attempts + 1, response.getStatusCode());
                }
            } catch (Exception e) {
                logger.error("Error during retry attempt {}: {}", attempts + 1, e.getMessage(), e);
            }

            attempts++;
        }

        if (!success) {
            logger.warn("All {} retry attempts failed for {}", retryCount, request.getUrl());
            //            response = new ServiceResponse();
            //            response.setStatusCode(500);
            //            response.setStatusDesc("Failed after " + retryCount + " attempts");
        }

        return response;
    }
}
