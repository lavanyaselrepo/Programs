package hwqe.baseframework.apicontext;

public enum Proxy {
    NONE(0),
    INTERNAL(1),
    EXTERNAL(2);

    private int proxy;

    Proxy(int proxy) {
        this.proxy = proxy;
    }

    public int getProxy() {
        return proxy;
    }
}
