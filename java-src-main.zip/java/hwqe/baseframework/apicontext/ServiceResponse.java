package hwqe.baseframework.apicontext;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import hwqe.baseframework.utilities.StringUtils;
import hwqe.baseframework.utilities.XMLParser;

public class ServiceResponse {

    private int statusCode;
    private String StatusDesc;
    private String dataResponse;
    private HashMap<String, String> headers;
    // private PropertyReader prop = PropertyReader.getInstance();
    private DocumentContext jsonContext;
    private XMLParser xmlContext;
    private byte[] bytePayload;

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusDesc() {
        return StatusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        StatusDesc = statusDesc;
    }

    public String getDataResponse() {
        return dataResponse;
    }

    public HashMap<String, String> getHeaders() {
        return headers;
    }

    public void setHeaders(HashMap<String, String> headers) {
        this.headers = headers;
    }

    public void setDataResponse(String dataResponse) {
        this.dataResponse = dataResponse;
    }

    public <T> T getDataResponse(Class<T> mapToClass) {
        return StringUtils.convertJsonToObject(dataResponse, mapToClass);
    }

    public <T> T getPPIDataResponse(Class<T> mapToClass) {
        return StringUtils.convertPPIJsonToObject(dataResponse, mapToClass);
    }

    public <T> T getDataResponse(Class<T> mapToClass, Type type, Object typeAdapter) {
        Gson gson = new GsonBuilder().registerTypeAdapter(type, typeAdapter).create();
        return gson.fromJson(dataResponse, mapToClass);
    }

    public <T> T getDataResponseXML(Class<T> mapToClass) {
        return StringUtils.convertXmlToObject(dataResponse, mapToClass);
    }

    public <T> List<T> getDataResponseInList(Class<T> mapToClass) {
        return StringUtils.convertJArrayToObject(dataResponse, mapToClass);
    }

    public <T> List<T> getPPIDataResponseInList(Class<T> mapToClass) {
        return StringUtils.convertPPIJArrayToObject(dataResponse, mapToClass);
    }

    public <T> T getJsonElement(String jsonPath) {
        if (jsonContext == null) {
            jsonContext = JsonPath.parse(dataResponse);
        }
        return jsonContext.read(jsonPath);
    }

    public void setJsonElement(String jsonPath, Object value) {
        if (jsonContext == null) {
            jsonContext = JsonPath.parse(dataResponse);
        }
        jsonContext.set(jsonPath, value);
        dataResponse = jsonContext.jsonString(); // Update the dataResponse with the modified JSON
    }

    public <T> T getXMLElement(String xPath) {
        if (xmlContext == null) {
            xmlContext = new XMLParser(dataResponse);
        }
        return xmlContext.getValue(xPath);
    }

    public byte[] getBytePayload() {
        return bytePayload;
    }

    public void setBytePayload(byte[] bytePayload) {
        this.bytePayload = bytePayload;
    }

    //    public Pair<String, String> writeToFile(String fileName) {
    //        if (this.dataResponse == null || this.dataResponse.isEmpty())
    //            return null;
    //        try {
    //            Random r = new Random();
    //            String fName = fileName + "_" + r.nextInt(9999) + ".txt";
    //            Files.write(Paths.get(prop.getProperty("app.workingfolder_path") + fName),
    // this.dataResponse.getBytes());
    //            return new Pair<>(fName, prop.getProperty("app.workingfolder_path") + fName);
    //        } catch (Exception e) {
    //            System.out.println(e.getMessage());
    //        }
    //        return null;
    //    }
}
