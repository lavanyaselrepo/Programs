package hwqe.baseframework.atlassiancontext;

public enum TestStatus {
    TODO("TODO"),
    PASS("PASS"),
    EXECUTING("EXECUTING"),
    FAIL("FAIL"),
    ABORTED("ABORTED");

    private String status;

    TestStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

}
