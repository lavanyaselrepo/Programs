package hwqe.baseframework.atlassiancontext;

import hwqe.baseframework.apicontext.Proxy;
import hwqe.baseframework.apicontext.RestClient;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.utilities.DateUtils;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.StringUtils;
import hwqe.baseframework.utilities.Zip;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;

public class JiraContext {
    private static JiraContext instance = null;
    HashMap<String, String> headers = new HashMap<>();
    private PropertyReader prop = PropertyReader.getInstance();
    public String sAuthTokenJiraLogin = "";
    private static final Logger logger = LoggerFactory.getLogger(JiraContext.class);
    Zip zipfiles = new Zip();


    private JiraContext() {
        // MIGRATED: Basic Auth (username:password) → API Access Token (Bearer)
        // Basic Auth is blocked from April 30 2026 per Atlassian migration program.
        // Property 'jira.api.token' must hold the Personal Access Token for SVCJiraUserHWQE.
        // See: #atlassian-api-auth-token-migration
        sAuthTokenJiraLogin = prop.getProperty("jira.api.token");
        if (sAuthTokenJiraLogin == null || sAuthTokenJiraLogin.isBlank()) {
            throw new IllegalStateException("Missing Jira API token: set 'jira.api.token' in Akeyless vault (path: /Prod/WCNP/homeoffice/wmt_hw_qe/ProjectDragon/env_shared).");
        }
        if (sAuthTokenJiraLogin.contains("\n") || sAuthTokenJiraLogin.contains("\r")) {
            throw new IllegalStateException("Invalid Jira API token: token contains illegal newline characters.");
        }
        headers.put("content-type", "application/json");
        headers.put("Authorization", "Bearer " + sAuthTokenJiraLogin);
    }

    public static JiraContext getInstance() {
        if (instance == null) {
            instance = new JiraContext();
        }
        return instance;
    }

    private int getTestCaseId(String execKey, String testKey) {
        ServiceRequest req = new ServiceRequest();
        req.setUrl(prop.getProperty("jira.base_url") + prop.getProperty("testexecution_url").replace("XXXXXXXX", execKey));
        req.setHeaders(headers);
        req.setProxy(Proxy.INTERNAL);
        RestClient client = new RestClient();
        ServiceResponse resp = client.performGet(req);
        if (resp.getStatusCode() == 200) {
            List<TestCase> lst = resp.getDataResponseInList(TestCase.class);
            for (TestCase tc : lst) {
                if (testKey.equalsIgnoreCase(tc.getKey())) {
                    return tc.getId();
                }
            }
        }
        return 0;
    }

    public boolean updateTestCaseStatus(String execKey, String testKey, TestStatus status) {
        int testCaseId = this.getTestCaseId(execKey, testKey);
        if (testCaseId > 0) {
            ServiceRequest req = new ServiceRequest();
            req.setUrl(prop.getProperty("jira.base_url") + prop.getProperty("jira.testrun_url") + testCaseId);
            req.setHeaders(headers);
            req.setProxy(Proxy.INTERNAL);
            req.setRequestPayload("{ \"status\": \"" + status.getStatus() + "\" }");
            RestClient client = new RestClient();
            ServiceResponse resp = client.performPut(req);
            if (resp.getStatusCode() == 200) {
                return true;
            }
        }
        return false;
    }

    public boolean updateAttachments(String key, String filePath) {
        ServiceRequest req = new ServiceRequest();
        req.setUrl(prop.getProperty("jira.base_url") + prop.getProperty("jira.attachments").replace("XXXXXXXX", key));
        headers.put("X-Atlassian-Token", "no-check");
        headers.remove("content-type");
        req.setHeaders(headers);
        req.setProxy(Proxy.INTERNAL);
        HashMap<String, String> map = new HashMap<>();
        map.put("file", filePath);
        req.setFormPayload(map);
        RestClient client = new RestClient();
        ServiceResponse resp = client.uploadFile(req);
        headers.remove("X-Atlassian-Token");
        headers.put("content-type", "application/json");
        return resp.getStatusCode() == 200;
    }

    public boolean updateJiraTransition(String sRequiredStatus,int itransitionId,String testExecutionKey) {
        String sPayLoad = "";
        String sUserName = prop.getProperty("jira.username");
        if("INPROGRESSQA".equalsIgnoreCase(sRequiredStatus)){
            sPayLoad = "{\"transition\":{\"id\":" +  itransitionId + "},\"fields\":{\"customfield_21240\":[{\"name\":\""+ sUserName+"\"}]}}";
        } else if ("READYFORREVIEW".equalsIgnoreCase(sRequiredStatus)) {
            sPayLoad = "{\"transition\":{\"id\":" + itransitionId + "}}";
        }
        try {
            String transitionUrl = prop.getProperty("jira.base_url")+ "/rest/api/2/issue/" + testExecutionKey + "/transitions";
            URL url = new URL(transitionUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Authorization", "Bearer " + sAuthTokenJiraLogin);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);
            try (OutputStream outputStream = connection.getOutputStream()) {
                outputStream.write(sPayLoad.getBytes());
            }
            int responseCode = connection.getResponseCode();
            if((responseCode == 200) || (responseCode == 204)){
                return true;
            }else{
                return false;
            }
        }catch(Exception e){
            logger.error("Exception occured while Jira transition to Status "+ sRequiredStatus + " With Error " +e.getStackTrace());
            return  false;
        }
    }
    public boolean uploadAttachmentToJira(String suiteName,String testExecutionKey, String sResultFilepath) {

        Path source = Paths.get(sResultFilepath);
        String fileName=suiteName+"_"+testExecutionKey+"_"+ DateUtils.currentDateAndTimeEST("dd_MM_yy_HH_mm_ss")+".zip";
        boolean value =  zipfiles.zipSingleFile(source,fileName);
        if(value){
            RestAssured.baseURI = prop.getProperty("jira.base_url") +"rest/api/2/issue/"+testExecutionKey+"/attachments";
            RequestSpecification restObj=RestAssured.given();
            restObj=restObj.header("Content-Type", "multipart/form-data");
            restObj=restObj.header("X-Atlassian-Token", "nocheck");
            restObj=restObj.multiPart(new File(source.getParent()+"/"+fileName));
            //restObj=restObj.header("Authorization","Basic "+encodeBase64String("ID"+":"+"Password"));
            restObj=restObj.header("Authorization","Bearer "+sAuthTokenJiraLogin);
            Response response=restObj.when().post();
            if (response.getStatusCode()==200){
                return  true;
            }else {
                return false;
            }
        }else{
            logger.info("ZIP file conversion is not Successful");
            return  false;
        }
    }
    public String updateTestExecutionStatus(TestExecution testExec) {
        try {
            if (testExec != null && !testExec.getTests().isEmpty()) {
                ServiceRequest req = new ServiceRequest();
                req.setUrl(prop.getProperty("jira.base_url") + prop.getProperty("jira.testexecution_url"));
                req.setHeaders(headers);
                req.setRequestPayload(StringUtils.convertToJson(testExec));
                RestClient client = new RestClient();
                ServiceResponse resp = client.performPost(req);
                if (resp.getStatusCode() == 200) {
                    String testExecKey = resp.getJsonElement("testExecIssue.key");
                    return testExecKey;
                }
                else {
                    logger.error("Jira update failed with status code "+resp.getStatusCode()+"-"+resp.getDataResponse());
                }
            }
            return null;
        }
        catch(Exception e)
        {
            logger.error("Exception occured trying to upload test results to jira-xray "+e.getStackTrace());
            return null;
        }
    }
}
