package hwqe.baseframework.atlassiancontext;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import jakarta.annotation.Generated;
import java.util.List;


@Generated("jsonschema2pojo")
public class TestExecution {

    @SerializedName("info")
    @Expose
    private Info info;
    @SerializedName("tests")
    @Expose
    private List<Test> tests = null;

    public String getTestExecutionKey() {
        return testExecutionKey;
    }

    public void setTestExecutionKey(String testExecutionKey) {
        this.testExecutionKey = testExecutionKey;
    }

    private String testExecutionKey;

    public Info getInfo() {
        return info;
    }

    public void setInfo(Info info) {
        this.info = info;
    }

    public List<Test> getTests() {
        return tests;
    }

    public void setTests(List<Test> tests) {
        this.tests = tests;
    }

}