package hwqe.baseframework.connexuswrapperapicontext.clients;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.PatientDependents.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.AddPatient;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Client for Dependent Patient operations.
 * 
 * Handles complex workflows for creating patients (minor/major)
 * and moving their orders through to EOD.
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class DependentPatientClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final WrapperUtils wrapperUtils;
    private final PatientClient patientClient;
    private final OrderCreationClient orderCreationClient;
    private final OrderWorkflowClient orderWorkflowClient;
    private final DrugInfoClient drugInfoClient;

    // Reusable dependent tracking
    private final DependentRxInfo dependent = new DependentRxInfo();
    private final DependentPatientIdAndRx dependentPatientIdAndRx = new DependentPatientIdAndRx();

    public DependentPatientClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.wrapperUtils = new WrapperUtils();
        this.patientClient = new PatientClient();
        this.orderCreationClient = new OrderCreationClient();
        this.orderWorkflowClient = new OrderWorkflowClient();
        this.drugInfoClient = new DrugInfoClient();
    }

    // ========== Dependent Patient Operations ==========

    /**
     * Creates patients (based on DOB list) and moves each order to EOD.
     * Categorizes as minor or major based on age (18 years cutoff).
     */
    public DependentPatientIdAndRx createPatientAndMoveToEODForDependent(int siteId, String ndc, 
            int numRefills, List<String> dob, AddPatient addPatientValues) throws JsonProcessingException {

        ArrayList<MinorPatient> minorPatientList = new ArrayList<>();
        ArrayList<MajorPatient> majorPatientList = new ArrayList<>();
        ArrayList<DependentRxInfo> dependentRxInfoList = new ArrayList<>();

        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);
        
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        int requestTypeCode = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrderPriorityId"));
        int dispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));

        for (int i = 0; i < dob.size(); i++) {
            addPatientValues.setDob(dob.get(i));
            int patientId = patientClient.addPatientWithGenericAllParam(addPatientValues);
            Log.info("Add patient response:\n" + patientId);

            // Create order and move through workflow to EOD
            InputResponse inputResp = createOrderAndMoveToEOD(siteId, patientId, drugInfo, 
                    inputPickupDate, inputRxExpDate, numRefills, requestTypeCode, priorityId, dispenseType);

            int rxNbr = inputResp.getRxNbr();
            Reporter.log("patientId = " + patientId + ", rxNbr = " + rxNbr);

            // Categorize by age
            categorizePatientByAge(dob.get(i), patientId, rxNbr, minorPatientList, majorPatientList);
        }

        dependent.setMinor(minorPatientList);
        dependent.setMajor(majorPatientList);
        dependentRxInfoList.add(dependent);
        dependentPatientIdAndRx.setDependentRxInfo(dependentRxInfoList);

        logDependentResult(dependentPatientIdAndRx);
        return dependentPatientIdAndRx;
    }

    /**
     * Creates patients with multiple RXs and moves to EOD for dependent workflow.
     */
    public DependentPatientIdAndRx createPatientwithMultirxAndMoveToEODForDependent(int siteId, 
            List<String> ndcList, int numRefills, List<String> dob, AddPatient addPatientValues, 
            Prescriber prescriberObject) throws JsonProcessingException {

        ArrayList<MinorPatient> minorPatientList = new ArrayList<>();
        ArrayList<MajorPatient> majorPatientList = new ArrayList<>();
        ArrayList<DependentRxInfo> dependentRxInfoList = new ArrayList<>();

        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        for (int i = 0; i < dob.size(); i++) {
            addPatientValues.setDob(dob.get(i));
            int patientId = patientClient.addPatientWithGenericAllParam(addPatientValues);
            Log.info("Add patient response:\n" + patientId);

            // Create multi-rx order and move to EOD
            List<InputResponse> inputResponseList = createMultiRxOrderAndMoveToEOD(siteId, patientId, 
                    ndcList, numRefills, prescriberObject);

            // Get first rx for categorization
            InputResponse firstResp = inputResponseList.get(0);
            int rxNbr = firstResp.getRxNbr();

            Reporter.log("patientId = " + patientId + ", rxNbr = " + rxNbr);
            categorizePatientByAge(dob.get(i), patientId, rxNbr, minorPatientList, majorPatientList);
        }

        dependent.setMinor(minorPatientList);
        dependent.setMajor(majorPatientList);
        dependentRxInfoList.add(dependent);
        dependentPatientIdAndRx.setDependentRxInfo(dependentRxInfoList);

        logDependentResult(dependentPatientIdAndRx);
        return dependentPatientIdAndRx;
    }

    // ========== Helper Methods ==========

    /**
     * Creates an order and moves it through the full workflow to EOD.
     */
    private InputResponse createOrderAndMoveToEOD(int siteId, int patientId, DataRow drugInfo,
            String inputPickupDate, String inputRxExpDate, int numRefills,
            int requestTypeCode, int priorityId, int dispenseType) {

        // Drop-off
        ServiceResponse dropOffResp = orderCreationClient.createOrderAndDropOff(
                requestTypeCode, priorityId, dispenseType, patientId, siteId, 
                inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        // Input Accept
        ServiceResponse inputAcceptResp = orderWorkflowClient.inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains("error"), "Input Accept could not be completed");
        
        InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + 
                ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());

        // Check DUR
        ServiceResponse chkDURCompleteResp = orderWorkflowClient.chkDURComplete(inputAcceptResp.getDataResponse());
        Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
        Assert.assertFalse(chkDURCompleteResp.getDataResponse().contains("error"), "Check DUR could not be completed");
        am.performSleep(30);

        // Fill
        ServiceResponse fillCompleteResp = orderWorkflowClient.fillComplete(chkDURCompleteResp.getDataResponse());
        Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Filling could not be completed");

        // VV
        ServiceResponse vvCompleteResp = orderWorkflowClient.vvComplete(fillCompleteResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "VVCompleteResp API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");

        // Pickup
        ServiceResponse pickupCompleteResp = orderWorkflowClient.pickupComplete(vvCompleteResp.getDataResponse());
        Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "PickupComplete API response status code did not match");
        Assert.assertFalse(pickupCompleteResp.getDataResponse().contains("error"), "Pickup could not be completed");

        // Counsel
        ServiceResponse counselCompleteResp = orderWorkflowClient.counselComplete(pickupCompleteResp.getDataResponse());
        Assert.assertEquals(counselCompleteResp.getStatusCode(), 302, "CounselComplete API response status code did not match");
        Assert.assertFalse(counselCompleteResp.getDataResponse().contains("error"), "Counsel could not be completed");

        // POS
        ServiceResponse posCompleteResp = orderWorkflowClient.posComplete(counselCompleteResp.getDataResponse());
        Assert.assertEquals(posCompleteResp.getStatusCode(), 302, "POSCompleteResp API response status code did not match");
        Assert.assertFalse(posCompleteResp.getDataResponse().contains("error"), "POS could not be completed");

        return posCompleteResp.getDataResponse(InputResponse.class);
    }

    /**
     * Creates multi-rx order and moves to EOD - placeholder for multi-rx implementation.
     */
    private List<InputResponse> createMultiRxOrderAndMoveToEOD(int siteId, int patientId,
            List<String> ndcList, int numRefills, Prescriber prescriberObject) {
        // This would delegate to MultiRxClient for multi-rx workflow
        // For now, return empty list as placeholder
        return new ArrayList<>();
    }

    /**
     * Categorizes patient as minor (<=18) or major (>18) based on DOB.
     */
    private void categorizePatientByAge(String dobStr, int patientId, int rxNbr,
            List<MinorPatient> minorList, List<MajorPatient> majorList) {

        long timeStamp = Long.parseLong(dobStr.replaceAll("[^\\d.]", ""));
        long currentTimeStamp = System.currentTimeMillis();
        long days = wrapperUtils.getDateDiff(timeStamp, currentTimeStamp, TimeUnit.DAYS);
        double age = days / 365.0;

        if (age <= 18) {
            MinorPatient minorPatient = new MinorPatient();
            minorPatient.setPatientId(patientId);
            minorPatient.setRxNbr(rxNbr);
            minorList.add(minorPatient);
        } else {
            MajorPatient majorPatient = new MajorPatient();
            majorPatient.setPatientId(patientId);
            majorPatient.setRxNbr(rxNbr);
            majorList.add(majorPatient);
        }
    }

    /**
     * Logs the dependent patient result.
     */
    private void logDependentResult(DependentPatientIdAndRx result) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(result);
        Reporter.log("DependentPatientIdAndRx:\n" + json + "\n");
        Log.info("DependentPatientIdAndRx:\n" + json + "\n");
    }
}
