package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Drug;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.FetchDrug;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;

import java.util.HashMap;

/**
 * Client for drug/NDC information operations.
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 * Handles all drug lookup, NDC queries, and inventory quantity operations.
 */
public class DrugInfoClient {

    private final AutomationManager am;
    private final PropertyReader prop;

    public DrugInfoClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public DrugInfoClient(AutomationManager am, PropertyReader prop) {
        this.am = am;
        this.prop = prop;
    }

    /**
     * Fetches drug info from the NDC lookup API.
     * 
     * @param drugPayload the fetch drug request payload
     * @return Drug object with fetched info
     */
    public Drug fetchDrugInfo(FetchDrug drugPayload) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        
        req.setRequestPayload(drugPayload);
        req.setUrl(prop.getProperty("fom.connexusWrapper.fetchDrugListFromNDC"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        
        Reporter.log("FetchDrugInfo Request endpoint: " + req.getUrl());
        Reporter.logJSON("FetchDrugInfo Request", drugPayload);
        
        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("FetchDrugInfo Response", resp.getDataResponse());
        
        return resp.getDataResponseInList(Drug.class).get(0);
    }

    /**
     * Gets drug info from the store database by NDC number.
     * 
     * @param cnx database context for the store
     * @param ndc the NDC number to look up
     * @return DataRow containing drug information
     */
    public DataRow getDrugInfo(IDatabaseContext cnx, String ndc) {
        String query = "select pp.short_name, pp.product_mds_fam_id, pp.drug_control_code, " +
                "pi.multi_source_code, pi.ndc_nbr, pi.mds_fam_id, pi.on_hand_qty, pgx.gpi_code \n" +
                "from pharmacy_offering:pharmacy_product as pp, " +
                "pharmacy_offering:pharmacy_item as pi, " +
                "pharmacy_offering:product_gpi_xref as pgx \n" +
                "where pp.product_mds_fam_id = pi.product_mds_fam_id \n" +
                "and pgx.product_mds_fam_id = pi.product_mds_fam_id \n" +
                "and pi.ndc_nbr ='" + ndc + "'";
        
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1, "Expected exactly one drug record for NDC: " + ndc);
        return dt.getDataRows().get(0);
    }

    /**
     * Gets the NDC number for a given GPI code.
     * 
     * @param cnx database context for the store
     * @param gpi the GPI code to look up
     * @return NDC number as string
     */
    public String getNdcInfoFromGpi(IDatabaseContext cnx, String gpi) {
        String query = "SELECT pi.ndc_nbr, pi.product_mds_fam_id, pgx.gpi_code \n" +
                "FROM pharmacy_offering:pharmacy_item pi \n" +
                "INNER JOIN pharmacy_offering:product_gpi_xref pgx \n" +
                "ON pi.product_mds_fam_id = pgx.product_mds_fam_id \n" +
                "WHERE pgx.gpi_code IN ('" + gpi + "')";
        
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1, "Expected exactly one drug record for GPI: " + gpi);
        return dt.getRow(0).getValue("ndc_nbr").toString();
    }

    /**
     * Gets the on-hand quantity for a drug from store Informix database.
     * 
     * @param cnx database context for the store
     * @param ndc the NDC number
     * @return on-hand quantity
     */
    public int getOnHandQty(IDatabaseContext cnx, String ndc) {
        String query = "SELECT on_hand_qty \n" +
                "FROM pharmacy_offering:pharmacy_item \n" +
                "WHERE ndc_nbr = '" + ndc + "'";
        
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1, "Expected exactly one record for NDC: " + ndc);
        
        Object value = dt.getRow(0).getValue("on_hand_qty");
        return Integer.parseInt(value.toString().replaceFirst("\\.0+$", ""));
    }

    /**
     * Updates the on-hand quantity for a drug in store Informix database.
     * 
     * @param cnx database context for the store
     * @param ndc the NDC number
     * @param onHandQty the new on-hand quantity
     */
    public void updateOnHandQty(IDatabaseContext cnx, String ndc, int onHandQty) {
        String query = "UPDATE pharmacy_offering:pharmacy_item \n" +
                "SET last_change_ts = CURRENT, on_hand_qty = " + onHandQty + " \n" +
                "WHERE ndc_nbr = '" + ndc + "'";
        
        int rowsUpdated = cnx.executeUpdateQuery(query);
        Assert.assertEquals(rowsUpdated, 1, "Update query did not affect exactly one row for NDC: " + ndc);
    }
}
