package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash.InsertRxFillActivity;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Client for Switch to Cash payment operations.
 * 
 * Handles:
 * - Switching payment from insurance to cash
 * - Insert RX fill activity for cash switch
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class SwitchToCashClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final DBUtils dbUtils;

    public SwitchToCashClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.dbUtils = new DBUtils();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public SwitchToCashClient(AutomationManager am, PropertyReader prop, DBUtils dbUtils) {
        this.am = am;
        this.prop = prop;
        this.dbUtils = dbUtils;
    }

    // ========== Switch to Cash Operations ==========

    /**
     * Switches payment to cash using input accept response.
     * 
     * @param inputAcceptResponse The response from input accept
     */
    public void switchToCash(String inputAcceptResponse) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");

        req.setUrl(prop.getProperty("fom.connexusWrapper.switchToCash"));
        req.setHeaders(headers);
        req.setRequestPayload(inputAcceptResponse);

        Reporter.log("SwitchToCash Request endpoint: " + req.getUrl());
        Log.info("SwitchToCash Request endpoint\n " + req.getUrl());
        Reporter.logJSON("SwitchToCash Request", req.getRequestPayload());
        Log.info("SwitchToCash RequestPayload:\n" + req.getRequestPayload() + "\n");

        ServiceResponse resp = am.getRestContext().performPost(req, 3);

        Reporter.logJSON("SwitchToCash Response", resp.getDataResponse());
        Log.info("SwitchToCash ResponsePayload:\n" + resp.getDataResponse() + "\n");
    }

    /**
     * Inserts RX fill activity for switch to cash operation.
     * This is the first step in switching a prescription to cash payment.
     * 
     * @param siteId The site ID
     * @param orderId The order ID
     * @return ServiceResponse from the insert operation
     */
    public ServiceResponse insertRxFillActivityForCash(int siteId, int orderId) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        headers.put("Authorization", prop.getProperty("cs.header.authorization"));

        InsertRxFillActivity insertRxFillActivity = new InsertRxFillActivity();
        int rxFillId = dbUtils.getrxFillId(siteId, orderId);
        int activityCode = Integer.parseInt(prop.getProperty("fom.activityCode"));

        insertRxFillActivity.setSiteID(siteId);
        insertRxFillActivity.setRxFillId(rxFillId);
        insertRxFillActivity.setActivityCode(activityCode);
        insertRxFillActivity.setUserId(prop.getProperty("fom.usereId"));

        req.setRequestPayloadWithNulls(insertRxFillActivity);

        String serviceEndPointUrl = StoreIDManager.createEndPointURL(
                String.valueOf(siteId),
                prop.getProperty("fom.connexusWrapper.portNo"),
                prop.getProperty("fom.connexusWrapper.sapsUrl"),
                prop.getProperty("fom.connexusWrapper.InsertRxFillActivityEndpoint"));

        req.setUrl(serviceEndPointUrl);
        req.setHeaders(headers);

        ServiceResponse resp = am.getRestContext().performPost(req);
        Assert.assertEquals(resp.getStatusCode(), 200, "Insert RX Fill Activity API response status code did not match");

        return resp;
    }
}
