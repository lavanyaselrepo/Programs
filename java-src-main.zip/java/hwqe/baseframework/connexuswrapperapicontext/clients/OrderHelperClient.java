package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.WorkQueueCode;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Drug;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.GetOrderInfo;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Order;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;

import java.util.HashMap;

/**
 * Helper client providing utility methods for order processing.
 * 
 * This client provides common utility methods used across order workflows:
 * - Order logging and debugging
 * - Queue state management and waiting
 * - Order object building
 * - Order details retrieval
 * 
 * Thread-safe: Uses method-local variables instead of instance state.
 * 
 * Extracted from OrderOrchestrationClient to reduce complexity.
 */
public class OrderHelperClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final DBUtils dbUtils;
    private final DowntimeClient downtimeClient;

    public OrderHelperClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.dbUtils = new DBUtils();
        this.downtimeClient = new DowntimeClient();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public OrderHelperClient(AutomationManager am, PropertyReader prop,
                              DBUtils dbUtils, DowntimeClient downtimeClient) {
        this.am = am;
        this.prop = prop;
        this.dbUtils = dbUtils;
        this.downtimeClient = downtimeClient;
    }

    /**
     * Logs order details for debugging.
     */
    public void logOrderDetails(InputResponse inputResp) {
        Reporter.log("orderId = " + inputResp.getOrderId() + 
                ", rxNbr = " + inputResp.getRxNbr() + 
                ", rxId = " + inputResp.getRxId() + 
                ", rxFillId = " + inputResp.getRxFillId());
    }

    /**
     * Performs downtime processing for an order.
     */
    public void performDowntime(int siteId, InputResponse inputResp) {
        Reporter.log("Performing downtime for rxFillId: " + inputResp.getRxFillId());
        downtimeClient.downTime(inputResp.getRxFillId(), inputResp.getOrderId(), 
                inputResp.getOrderSeqNbr(), prop.getProperty("fom.userId"), 
                prop.getProperty("fom.setDeviceName"), siteId);
    }

    /**
     * Refreshes and logs the next work queue code.
     */
    public int refreshNextQueue(int siteId, int rxFillId, String phase) {
        int code = dbUtils.getNextWorkQueCode(siteId, rxFillId);
        Reporter.log(phase + " - Next Work Queue Code: " + code);
        return code;
    }

    /**
     * Checks if a queue code matches any of the target codes.
     */
    public boolean isOneOfQueues(int code, WorkQueueCode... targets) {
        for (WorkQueueCode w : targets) {
            if (w.getWorkQueueCode() == code) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if queue code is CASH or TP (third-party).
     */
    public boolean isCashOrTPQueue(int code) {
        return code == WorkQueueCode.CASH.getWorkQueueCode() || 
               code == WorkQueueCode.TP.getWorkQueueCode();
    }

    /**
     * Waits for an order to exit CASH or TP queue state.
     * 
     * @param siteId store/site identifier
     * @param rxFillId Rx fill identifier
     * @param maxAttempts maximum number of retry attempts
     * @param waitSeconds seconds to wait between attempts
     * @param context description for logging
     */
    public void waitOnCashOrTP(int siteId, int rxFillId, int maxAttempts, 
            int waitSeconds, String context) {
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            Reporter.log("[CASH/TP WAIT] " + context + " attempt " + attempt + 
                    " waiting " + waitSeconds + "s");
            am.performSleep(waitSeconds);
            int code = dbUtils.getNextWorkQueCode(siteId, rxFillId);
            if (!isCashOrTPQueue(code)) {
                Reporter.log("[CASH/TP WAIT] Exiting CASH/TP queue after attempt " + 
                        attempt + ": code=" + code);
                break;
            }
        }
    }

    /**
     * Builds a complete Order object with drug and prescriber information.
     * 
     * @param patientId patient identifier
     * @param orderId order identifier
     * @param storeNbr store number
     * @param rxFillId Rx fill identifier
     * @param rxId Rx identifier
     * @param rxNbr Rx number
     * @param numRefills number of refills
     * @param orderSeqNbr order sequence number
     * @param inputPickupDate pickup date
     * @param inputRxExpDate expiration date
     * @param drugInfo drug information row
     * @param prescriber prescriber object
     * @return fully populated Order object
     */
    public Order buildOrderWithDrug(int patientId, int orderId, int storeNbr,
            int rxFillId, int rxId, int rxNbr, int numRefills, int orderSeqNbr,
            String inputPickupDate, String inputRxExpDate, DataRow drugInfo, 
            Prescriber prescriber) {
        
        Order order = new Order();
        Drug drug = new Drug();

        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(prop.getProperty("fom.OrderPriorityId")));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setPatientId(patientId);
        order.setOrderId(orderId);
        order.setSiteID(storeNbr);
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);
        order.setRxFillId(rxFillId);
        order.setNumRefills(numRefills);
        order.setRxId(rxId);
        if (rxNbr > 0) {
            order.setRxNbr(rxNbr);
        }
        order.setOrderSeqNbr(orderSeqNbr);

        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr"));
        drug.setItemId(drugInfo.getValue("mds_fam_id"));
        drug.setRxProdId(drugInfo.getValue("product_mds_fam_id"));
        drug.setControlCode(drugInfo.getValue("drug_control_code"));
        drug.setPresMultiSrcCode(drugInfo.getValue("multi_source_code"));
        drug.setOnHandQty(Integer.parseInt(drugInfo.getValue("on_hand_qty").toString()
                .trim().replaceFirst("\\.0+$", "")));
        drug.setGpiCode(drugInfo.getValue("gpi_code"));
        drug.setUsualCost("0");
        drug.setActCost("0");
        drug.setOrgUsualCost("0");

        order.setPrescriber(prescriber);
        order.setDrug(drug);
        
        return order;
    }

    /**
     * Gets detailed order information for a specific Rx fill.
     * 
     * @param siteId store/site identifier
     * @param rxFillId Rx fill identifier
     * @return service response with order details
     */
    public ServiceResponse getOrderDetailsInfo(int siteId, int rxFillId) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();

        GetOrderInfo getOrderInfo = new GetOrderInfo();
        getOrderInfo.setSiteId(siteId);
        getOrderInfo.setRxFillId(rxFillId);
        
        req.setUrl(prop.getProperty("fom.connexusWrapper.getOrderInfo"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        req.setRequestPayload(getOrderInfo);
        
        Reporter.log("getOrderInfo API endpoint: " + req.getUrl());
        Reporter.logJSON("getOrderInfo API Request", req.getRequestPayload());
        Log.info("getOrderInfo API RequestPayload:\n" + req.getRequestPayload() + "\n");
        
        ServiceResponse resp = am.getRestContext().performPost(req);
        
        Reporter.logJSON("getOrderInfo API Response", resp.getDataResponse());
        Log.info("getOrderInfo API ResponsePayload:\n" + resp.getDataResponse() + "\n");
        
        return resp;
    }
}
