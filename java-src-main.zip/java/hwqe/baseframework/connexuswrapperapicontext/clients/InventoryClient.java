package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Inventory.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Client for Inventory operations including tasks, in-transit, and cycle counts.
 * 
 * Handles:
 * - Open/Close task operations for inventory
 * - In-transit and delivered shipment tracking
 * - Cycle count NDC additions
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class InventoryClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final ConnexusAppUtils connexusAppUtils;

    public InventoryClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.connexusAppUtils = new ConnexusAppUtils();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public InventoryClient(AutomationManager am, PropertyReader prop, ConnexusAppUtils connexusAppUtils) {
        this.am = am;
        this.prop = prop;
        this.connexusAppUtils = connexusAppUtils;
    }

    // ========== Task Operations ==========

    /**
     * Opens or closes a task for inventory operations.
     * 
     * @param requestType The type of request
     * @param activeStatus Status indicating open or close
     * @param siteId The site ID
     * @param eventId The event ID
     */
    public void openAndCloseTaskForInventory(String requestType, String activeStatus, String siteId, String eventId) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildInventoryHeaders();

        String transId = String.valueOf(connexusAppUtils.randomNumber());
        String timeStamp = ConnexusAppUtils.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss");
        String requestUrl = prop.getProperty("fom.RequestUrl_INV");
        String appId = prop.getProperty("fom.AppID_INV");
        String eventType = prop.getProperty("fom.EventType_INV");
        String token = prop.getProperty("fom.Token_INV");

        req.setUrl(prop.getProperty("fom.connexusWrapper.openCloseTask"));
        req.setHeaders(headers);

        // Build event
        Event eventReq = new Event();
        eventReq.setRequest_type(requestType);
        eventReq.setRequest_url(requestUrl);
        eventReq.setSite_id(siteId);
        eventReq.setActive_status(activeStatus);

        ArrayList<Event> eventList = new ArrayList<>();
        eventList.add(eventReq);

        // Build open task request
        OpenTask openTaskReq = new OpenTask();
        openTaskReq.setEvents(eventList);
        openTaskReq.setApp_id(appId);
        openTaskReq.setEvent_id(eventId);
        openTaskReq.setEvent_type(eventType);
        openTaskReq.setTimestamp(timeStamp);
        openTaskReq.setToken(token);
        openTaskReq.setTrans_id(transId);

        req.setRequestPayload(openTaskReq);
        ServiceResponse resp = am.getRestContext().performPost(req, 1);

        // Log based on operation type
        String openStatusProperty = prop.getProperty("fom.Active_Status_Open_Task_INV");
        if (activeStatus.equals(openStatusProperty)) {
            Reporter.log("Open task Request endpoint: " + req.getUrl());
            Reporter.logJSON("Open task Request", req.getRequestPayload());
            Reporter.logJSON("Open task Response", resp.getDataResponse());
        } else {
            Reporter.log("Close task Request endpoint: " + req.getUrl());
            Reporter.logJSON("Close task Request", req.getRequestPayload());
            Reporter.logJSON("Close task Response", resp.getDataResponse());
        }

        Assert.assertEquals(resp.getStatusCode(), 200, "Open task API status code did not match");
    }

    // ========== In-Transit Operations ==========

    /**
     * Handles in-transit and delivered status for inventory shipments.
     * 
     * @param activityType The type of activity (in-transit or delivered)
     * @param sourceSiteId The source site ID
     * @param recvSiteId The receiving site ID
     * @param eventId The event ID
     */
    public void inTransitAndDeliveredForInventory(String activityType, String sourceSiteId, String recvSiteId, String eventId) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildInventoryHeaders();

        String transId = String.valueOf(connexusAppUtils.randomNumber());

        req.setUrl(prop.getProperty("fom.connexusWrapper.openCloseTask"));
        req.setHeaders(headers);

        // Build item list
        InTransitItemList itemList = buildInTransitItem();
        ArrayList<InTransitItemList> items = new ArrayList<>();
        items.add(itemList);

        // Build in-transit event
        InTransitEvents inTransitEventReq = buildInTransitEvent(activityType, sourceSiteId, recvSiteId, items);
        ArrayList<InTransitEvents> inTransitEventList = new ArrayList<>();
        inTransitEventList.add(inTransitEventReq);

        // Build root request
        InTransitRoot inTransitReq = buildInTransitRoot(transId, eventId, sourceSiteId, recvSiteId, inTransitEventList);

        req.setRequestPayloadWithNulls(inTransitReq);
        ServiceResponse resp = am.getRestContext().performPost(req, 2);

        // Log based on activity type
        String inTransitActivityType = prop.getProperty("fom.inv.inTransitActivityType");
        if (activityType.equals(inTransitActivityType)) {
            Reporter.log("InTransit Request endpoint: " + req.getUrl());
            Reporter.logJSON("InTransit Request", req.getRequestPayload());
            Reporter.logJSON("InTransit Response", resp.getDataResponse());
        } else {
            Reporter.log("Delivered Request endpoint: " + req.getUrl());
            Reporter.logJSON("Delivered Request", req.getRequestPayload());
            Reporter.logJSON("Delivered Response", resp.getDataResponse());
        }

        Assert.assertEquals(resp.getStatusCode(), 200, "InTransit And Delivered API status code did not match");
    }

    // ========== Cycle Count Operations ==========

    /**
     * Adds NDC items to the cycle count report page.
     * 
     * @param countList List of NDC items to add
     * @param storeNumber The store number
     */
    public void addNdcInCycleCountReportPage(ArrayList<AddNDCToCycleCountPageCountList> countList, String storeNumber) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", prop.getProperty("fom.Content.type"));

        int storeNum = Integer.parseInt(storeNumber);
        req.setUrl(prop.getProperty("fom.AddNDC").replace("XXXXX", String.valueOf(storeNum)));
        req.setHeaders(headers);

        AddNDCToCycleCountPageRoot addInCycleCount = new AddNDCToCycleCountPageRoot();
        addInCycleCount.setStoreNbr(storeNum);
        addInCycleCount.setCountList(countList);

        req.setRequestPayloadWithNulls(addInCycleCount);
        ServiceResponse resp = am.getRestContext().performPost(req, 1);

        Reporter.log("NDC Numbers Added");
        Reporter.log("End Point: " + req.getUrl());
        Reporter.logJSON("Request", req.getRequestPayload());
        Reporter.logJSON("Response", resp.getDataResponse());

        Assert.assertEquals(resp.getStatusCode(), 200, "API status code did not match");
    }

    // ========== Helper Methods ==========

    /**
     * Builds standard inventory headers.
     */
    private HashMap<String, String> buildInventoryHeaders() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", prop.getProperty("fom.Content.type"));
        headers.put("WM_SVC.NAME", prop.getProperty("fom.WM_SVC.NAME_INV"));
        headers.put("WM_SVC.ENV", prop.getProperty("fom.WM_SVC.ENV_INV"));
        headers.put("WM_CONSUMER.ID", prop.getProperty("fom.WM_CONSUMER.ID_INV"));
        return headers;
    }

    /**
     * Builds an in-transit item from properties.
     */
    private InTransitItemList buildInTransitItem() {
        InTransitItemList itemList = new InTransitItemList();
        itemList.setNdc(prop.getProperty("fom.inv.ndc"));
        itemList.setQty(prop.getProperty("fom.inv.qty"));
        itemList.setAverage_cost(Double.parseDouble(prop.getProperty("fom.inv.average_cost")));
        itemList.setXfer_mode(prop.getProperty("fom.inv.xfer_mode"));
        return itemList;
    }

    /**
     * Builds an in-transit event.
     */
    private InTransitEvents buildInTransitEvent(String activityType, String sourceSiteId, 
            String recvSiteId, ArrayList<InTransitItemList> items) {
        InTransitEvents inTransitEventReq = new InTransitEvents();
        inTransitEventReq.setActivity_type(activityType);
        inTransitEventReq.setRequest_url(prop.getProperty("fom.inv.request_url"));
        inTransitEventReq.setSite_type(prop.getProperty("fom.inv.site_type"));
        inTransitEventReq.setSource_site_id(sourceSiteId);
        inTransitEventReq.setRecv_site_id(recvSiteId);
        inTransitEventReq.setPackage_id(prop.getProperty("fom.inv.package_id"));
        inTransitEventReq.setVendor_name(prop.getProperty("fom.inv.vendor_name"));
        inTransitEventReq.setTracking_id(prop.getProperty("fom.inv.tracking_id"));
        inTransitEventReq.setDelivered_ts(ConnexusAppUtils.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"));
        inTransitEventReq.setItem_list_count(prop.getProperty("fom.inv.item_list_count"));
        inTransitEventReq.setRecv_div_id(prop.getProperty("fom.inv.recv_div_id"));
        inTransitEventReq.setUser_id(prop.getProperty("fom.inv.user_id"));
        inTransitEventReq.setTimestamp(ConnexusAppUtils.getCurrentTimestamp("yyyy-MM-dd HH:mm:ss"));
        inTransitEventReq.setItem_list(items);
        return inTransitEventReq;
    }

    /**
     * Builds the in-transit root request.
     */
    private InTransitRoot buildInTransitRoot(String transId, String eventId, String sourceSiteId, 
            String recvSiteId, ArrayList<InTransitEvents> inTransitEventList) {
        InTransitRoot inTransitReq = new InTransitRoot();
        inTransitReq.setToken(prop.getProperty("fom.Token_INV"));
        inTransitReq.setApp_id(prop.getProperty("fom.AppID_INV"));
        inTransitReq.setTrans_id(transId);
        inTransitReq.setEvent_type(prop.getProperty("fom.inv.event_type"));
        inTransitReq.setEvent_id(eventId);
        inTransitReq.setLineageType(prop.getProperty("fom.inv.lineageType"));
        inTransitReq.setLineageId(sourceSiteId + "-" + recvSiteId + "-" + eventId);
        inTransitReq.setEvents(inTransitEventList);
        return inTransitReq;
    }
}
