package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Drug;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.DropOffQueueRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.MultiRxDropOffQueueRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Order;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.digitalPharmacyapicontext.DigitalPharmacyAPIManager;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.json.JSONArray;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Client for End of Day (EOD) operations.
 * 
 * Handles:
 * - Creating new orders directly to EOD
 * - Moving prescriptions to EOD state
 * - Multi-drug order creation to EOD
 * - Batch EOD job processing
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class EODClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final WrapperUtils wrapperUtils;
    private final DBUtils dbUtils;

    public EODClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.wrapperUtils = new WrapperUtils();
        this.dbUtils = new DBUtils();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public EODClient(AutomationManager am, PropertyReader prop, WrapperUtils wrapperUtils, DBUtils dbUtils) {
        this.am = am;
        this.prop = prop;
        this.wrapperUtils = wrapperUtils;
        this.dbUtils = dbUtils;
    }

    // ========== Simple EOD Creation ==========

    /**
     * Creates a new order and sends it directly to EOD queue.
     */
    public ServiceResponse newOrderToEOD(int requestTypeCode, int priorityId, int dispenseType, 
            int patientId, int storeNbr, String inputPickUpDate, String inputRxExpDate, 
            int numRefills, DataRow drugInfo) {

        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");

        ArrayList<DropOffQueueRequest> dropoffRequestList = new ArrayList<>();
        DropOffQueueRequest dropoffRequest = new DropOffQueueRequest();

        dropoffRequest.setRequestTypeCode(requestTypeCode);
        dropoffRequest.setPriorityId(priorityId);
        dropoffRequest.setDispenseType(dispenseType);
        dropoffRequest.setPatientId(patientId);
        dropoffRequest.setSiteID(storeNbr);
        dropoffRequest.setInputPickUpDate(inputPickUpDate);
        dropoffRequest.setInputRxExpDate(inputRxExpDate);
        dropoffRequest.setNumRefills(numRefills);

        Drug drug = buildDrugFromDataRow(drugInfo);
        dropoffRequest.setDrug(drug);
        dropoffRequestList.add(dropoffRequest);

        req.setRequestPayloadWithNulls(dropoffRequestList);
        req.setUrl(prop.getProperty("fom.connexusWrapper.newOrderToEODUrl"));
        req.setHeaders(headers);

        Reporter.log("NewOrderToEOD Request endpoint: " + req.getUrl());
        Reporter.logJSON("NewOrderToEOD Request", dropoffRequestList);

        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("NewOrderToEOD Response", resp.getDataResponse());

        return resp;
    }

    // ========== Multi-Drug EOD Creation ==========

    /**
     * Creates a new multi-drug order and sends it to EOD.
     */
    public JSONArray createNewMultiDrugOrderToEOD(int patientId, int siteId, int numRefills, 
            List<String> ndcList, Prescriber prescriberObject) {

        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");

        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        // Connect to store DB and get drug info
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        List<DataRow> ndcData = new ArrayList<>();
        for (String ndc : ndcList) {
            List<DataRow> rows = dbUtils.getMultiDrugInfo(cnx, ndc);
            ndcData.addAll(rows);
        }

        // Build order
        Order order = new Order();
        order.setPrescriber(prescriberObject);
        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(prop.getProperty("fom.OrderPriorityId")));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);
        order.setNumRefills(numRefills);
        order.setPatientId(patientId);
        order.setSiteID(siteId);

        // Build drug list
        ArrayList<Drug> drugList = new ArrayList<>();
        for (int i = 0; i < ndcData.size(); i++) {
            Drug drug = buildDrugFromDataRowMinimal(ndcData.get(i));
            drugList.add(drug);
        }

        MultiRxDropOffQueueRequest multiRxRequest = new MultiRxDropOffQueueRequest();
        multiRxRequest.setDrugList(drugList);
        multiRxRequest.setOrder(order);

        req.setRequestPayloadWithNulls(multiRxRequest);
        req.setUrl(prop.getProperty("fom.connexusWrapper.newMultiDrugOrderToEODUrl"));
        req.setHeaders(headers);

        Log.info("MultiOrderTillEOD Request endpoint\n " + req.getUrl());
        Reporter.log("MultiOrderTillPickup Request endpoint: " + req.getUrl());
        Reporter.logJSON("MultiOrderTillEOD Request", multiRxRequest);
        Log.info("MultiOrderTillEOD Request\n " + req.getRequestPayload());

        ServiceResponse resp = am.getRestContext().performPost(req);

        Log.info("MultiOrderTillEOD Response\n " + resp.getDataResponse());
        Reporter.logJSON("MultiOrderTillEOD Response", resp.getDataResponse());
        Assert.assertEquals(resp.getStatusCode(), 201, "createMultiOrderTillEOD API response status code did not match");

        return new JSONArray(resp.getDataResponse());
    }

    // ========== Batch EOD Operations ==========

    /**
     * Moves multiple RXs to EOD via batch job.
     * 
     * @param fillIds List of fill IDs to move
     * @param storeId Store ID
     * @return Count of successfully moved RXs
     */
    public int moveRXsToEODJob(List<Integer> fillIds, int storeId) {
        int count = 0;
        DigitalPharmacyAPIManager dpManager = new DigitalPharmacyAPIManager();

        for (int fillId : fillIds) {
            try {
                ServiceResponse resp = dpManager.moveRxToEODAPI_Astro(fillId, storeId);

                if (resp.getStatusCode() != 200) {
                    Reporter.log("Move RX api failed for fillId :: " + fillId);
                    Reporter.logJSON("Move RX to EOD response is :: ", resp.getDataResponse());
                } else {
                    Reporter.log("RxNumber " + fillId + " Moved to EOD");
                    Reporter.logJSON("Move RX to EOD response is :: ", resp.getDataResponse());
                    count++;
                }
            } catch (Exception e) {
                Reporter.log("Move RX api failed with exception " + e.getMessage());
            }
        }

        return count;
    }

    // ========== Helper Methods ==========

    /**
     * Builds Drug object from DataRow with full attributes.
     */
    private Drug buildDrugFromDataRow(DataRow drugInfo) {
        Drug drug = new Drug();
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr"));
        drug.setItemId(drugInfo.getValue("mds_fam_id"));
        drug.setRxProdId(drugInfo.getValue("product_mds_fam_id"));
        drug.setControlCode(drugInfo.getValue("drug_control_code"));
        drug.setPresMultiSrcCode(drugInfo.getValue("multi_source_code"));
        drug.setOnHandQty(Integer.parseInt(drugInfo.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
        drug.setGpiCode(drugInfo.getValue("gpi_code"));
        drug.setUsualCost("0");
        drug.setActCost("0");
        drug.setOrgUsualCost("0");
        return drug;
    }

    /**
     * Builds Drug object from DataRow with minimal attributes (for multi-drug).
     */
    private Drug buildDrugFromDataRowMinimal(DataRow drugInfo) {
        Drug drug = new Drug();
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr").toString().trim());
        drug.setItemId(Integer.parseInt(drugInfo.getValue("mds_fam_id").toString().trim()));
        drug.setRxProdId(Integer.parseInt(drugInfo.getValue("product_mds_fam_id").toString().trim()));
        drug.setControlCode(Short.parseShort(drugInfo.getValue("drug_control_code").toString().trim()));
        drug.setGpiCode(drugInfo.getValue("gpi_code").toString().trim());
        drug.setUsualCost("0");
        drug.setActCost("0");
        drug.setOrgUsualCost("0");
        return drug;
    }
}
