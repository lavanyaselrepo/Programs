package hwqe.baseframework.connexuswrapperapicontext.clients;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.AllergyInfo;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.CheckAllergyInfo;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.CreateAllergy;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.InsertAllergy;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.AddPatient;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.io.IOException;
import java.util.HashMap;

/**
 * Client for allergy-related operations.
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 * Handles patient allergy creation, checking, and validation.
 */
public class AllergyClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final WrapperUtils wrapperUtils;
    private final PatientClient patientClient;

    public AllergyClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.wrapperUtils = new WrapperUtils();
        this.patientClient = new PatientClient();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public AllergyClient(AutomationManager am, PropertyReader prop, 
                         WrapperUtils wrapperUtils, PatientClient patientClient) {
        this.am = am;
        this.prop = prop;
        this.wrapperUtils = wrapperUtils;
        this.patientClient = patientClient;
    }

    /**
     * Adds allergy information for a patient.
     */
    public void addAllergyInfo(InsertAllergy insertAllergy, int patientId, int siteId) throws IOException {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();

        CreateAllergy createAllergy = new CreateAllergy();
        AllergyInfo allergyInformation = wrapperUtils.buildInputAllergyForAddPatient(insertAllergy);
        allergyInformation.setPatientId(patientId);
        createAllergy.setAllergyInformation(allergyInformation);

        req.setRequestPayloadWithNulls(createAllergy);
        String serviceEndPointUrl = StoreIDManager.createEndPointURL(
                Integer.toString(siteId),
                prop.getProperty("fom.connexusWrapper.portNo"),
                prop.getProperty("fom.connexusWrapper.sapsUrl"),
                prop.getProperty("fom.addInsertAllergyURL"));
        req.setUrl(serviceEndPointUrl);

        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);

        Log.info("Patient Allergy API RequestPayload:\n" + req.getRequestPayload() + "\n");
        Reporter.log("Patient Allergy API endpoint:" + req.getUrl());

        ServiceResponse resp = am.getRestContext().performPost(req);
        Log.info("Patient Allergy API ResponsePayload:\n" + resp.getStatusDesc() + "\n" + resp.getStatusCode() + "\n");

        Assert.assertNotNull(resp);
        Assert.assertEquals(resp.getStatusCode(), 200, "Expected status code 200 but found " + resp.getStatusCode());
    }

    /**
     * Creates a patient with allergy information.
     * Convenience method that combines patient creation with allergy setup.
     */
    public void addPatientWithAllergy(int siteId, InsertAllergy insertAllergy, AddPatient addPatient) throws IOException {
        int patientId = patientClient.addPatientWithGenericAllParam(addPatient);
        addAllergyInfo(insertAllergy, patientId, siteId);
        checkPatientSupportedAllergyInfo(patientId, siteId);
    }

    /**
     * Verifies that allergy information exists for a patient.
     */
    public void checkPatientSupportedAllergyInfo(int patientId, int siteId) throws IOException {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();

        CheckAllergyInfo checkAllergyInfo = new CheckAllergyInfo();
        checkAllergyInfo.setSiteId(siteId);
        checkAllergyInfo.setPatientId(patientId);

        req.setRequestPayloadWithNulls(checkAllergyInfo);
        String serviceEndPointUrl = StoreIDManager.createEndPointURL(
                Integer.toString(siteId),
                prop.getProperty("fom.connexusWrapper.portNo"),
                prop.getProperty("fom.connexusWrapper.sapsUrl"),
                prop.getProperty("fom.checkAllergyInfo"));
        req.setUrl(serviceEndPointUrl);

        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);

        Reporter.log("CheckAllergyInfo API Endpoint:" + req.getUrl());
        Log.info("CheckAllergyInfo API RequestPayload:\n" + req.getRequestPayload() + "\n");

        ServiceResponse resp = am.getRestContext().performPost(req);
        Log.info("CheckAllergyInfo API ResponsePayload:\n" + resp.getDataResponse());

        Assert.assertNotNull(resp);
        Assert.assertEquals(resp.getStatusCode(), 200, "Expected status code 200 but found " + resp.getStatusCode());

        Gson gson = new Gson();
        JsonObject json = gson.fromJson(resp.getDataResponse(), JsonObject.class);
        boolean allergyExists = json.get("AllergyExists").getAsBoolean();
        Assert.assertTrue(allergyExists, "Allergy should exist but it does not");
    }
}
