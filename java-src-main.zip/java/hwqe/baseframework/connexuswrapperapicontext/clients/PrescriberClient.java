package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import org.testng.Assert;

/**
 * Client for prescriber information operations.
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 * Handles all prescriber lookups and data retrieval.
 */
public class PrescriberClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final DBUtils dbUtils;

    public PrescriberClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.dbUtils = new DBUtils();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public PrescriberClient(AutomationManager am, PropertyReader prop, DBUtils dbUtils) {
        this.am = am;
        this.prop = prop;
        this.dbUtils = dbUtils;
    }

    /**
     * Gets prescriber info from the store database by prescriber ID.
     * 
     * @param cnx database context for the store
     * @param prescriberId the prescriber ID to look up
     * @return DataRow containing prescriber information
     */
    public DataRow getPrescriberInfo(IDatabaseContext cnx, int prescriberId) {
        String query = "select * from informix.prescriber p where p.prescriber_id=" + prescriberId;
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1, "Expected exactly one prescriber for ID: " + prescriberId);
        return dt.getDataRows().get(0);
    }

    /**
     * Gets a random active prescriber from the store database.
     * Note: The prescriber_id parameter is ignored (legacy signature).
     * 
     * @param cnx database context for the store
     * @param prescriberId ignored - kept for backward compatibility
     * @return DataRow containing prescriber information
     */
    public DataRow getRandomPrescriberInfo(IDatabaseContext cnx, int prescriberId) {
        String query = "select * from informix.prescriber p where p.status_code=20100 LIMIT 1";
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1, "Expected at least one active prescriber");
        return dt.getDataRows().get(0);
    }

    /**
     * Builds a Prescriber object with default values from properties and DB lookup.
     * Uses the store ID from cnx.store property.
     * 
     * @return Prescriber object populated with clinic and prescriber IDs
     */
    public Prescriber getPrescriberDetails() {
        int siteId = Integer.parseInt(prop.getProperty("cnx.store"));
        return getPrescriberDetails(siteId);
    }

    /**
     * Builds a Prescriber object with default values from properties and DB lookup.
     * 
     * @param siteId the store/site ID
     * @return Prescriber object populated with clinic and prescriber IDs
     */
    public Prescriber getPrescriberDetails(int siteId) {
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow prescriberDetails = dbUtils.getRxClinicIdAndPrescriberId(cnx);
        
        int rxClinicId = prescriberDetails.getValue("clinic_id");
        int prescriberId = prescriberDetails.getValue("prescriber_id");

        Prescriber prescriber = new Prescriber();
        prescriber.setFullname(prop.getProperty("fom.connexusWrapper.prescriberFullName"));
        prescriber.setFirstname(prop.getProperty("fom.connexusWrapper.prescriberFirstName"));
        prescriber.setLastname(prop.getProperty("fom.connexusWrapper.prescriberLastName"));
        prescriber.setPhone(prop.getProperty("fom.connexusWrapper.prescriberPhone"));
        prescriber.setState(prop.getProperty("fom.connexusWrapper.prescriberState"));
        prescriber.setPrescriberId(prescriberId);
        prescriber.setRxClinicId(rxClinicId);
        prescriber.setDea(prop.getProperty("fom.connexusWrapper.prescriberDea"));
        prescriber.setNpi(prop.getProperty("fom.connexusWrapper.prescriberNpi"));
        
        return prescriber;
    }

    /**
     * Builds a Prescriber object with specific values.
     * 
     * @param presName full name
     * @param presFName first name
     * @param presLName last name
     * @param presPhone phone number
     * @param state state code
     * @param prescriberID prescriber ID
     * @param rxClinicId clinic ID
     * @return Prescriber object populated with provided values
     */
    public Prescriber buildPrescriber(String presName, String presFName, String presLName,
            String presPhone, String state, int prescriberID, int rxClinicId) {
        Prescriber prescriber = new Prescriber();
        prescriber.setFullname(presName);
        prescriber.setFirstname(presFName);
        prescriber.setLastname(presLName);
        prescriber.setPhone(presPhone);
        prescriber.setState(state);
        prescriber.setPrescriberId(prescriberID);
        prescriber.setRxClinicId(rxClinicId);
        prescriber.setDea(prop.getProperty("fom.connexusWrapper.prescriberDea"));
        prescriber.setNpi(prop.getProperty("fom.connexusWrapper.prescriberNpi"));
        return prescriber;
    }
}
