package hwqe.baseframework.connexuswrapperapicontext.clients;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Eod.MoveOrderToEODRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import org.assertj.core.util.DateUtil;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;

import java.util.Date;
import java.util.HashMap;
import java.util.TimeZone;

/**
 * Client for pharmacy order workflow state transitions.
 * 
 * Handles the core workflow state machine for prescription processing:
 * DropOff → InputAccept → 4PointCheck/DURCheck → Fill → VV → Pickup → Counsel → POS
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class OrderWorkflowClient {

    private final AutomationManager am;
    private final PropertyReader prop;

    public OrderWorkflowClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public OrderWorkflowClient(AutomationManager am, PropertyReader prop) {
        this.am = am;
        this.prop = prop;
    }

    // ========== Core Workflow State Transitions ==========

    /**
     * Accepts input from drop-off queue and validates prescription.
     * Transition: DropOff → Input
     */
    public ServiceResponse inputAccept(String dropOffResponse) {
        return executeWorkflowStep(
                "fom.connexusWrapper.inputAcceptUrl",
                dropOffResponse,
                "InputAccept",
                3);
    }

    /**
     * Completes Drug Utilization Review check.
     * Transition: Input → DUR Complete
     */
    public ServiceResponse chkDURComplete(String inputAcceptResponse) {
        return executeWorkflowStep(
                "fom.connexusWrapper.checkDURCompleteUrl",
                inputAcceptResponse,
                "CheckDUR",
                2);
    }

    /**
     * Completes 4-point verification check.
     * Transition: Input → 4Point Complete
     */
    public ServiceResponse fourPointCheck(String inputAcceptResponse) {
        return executeWorkflowStep(
                "fom.connexusWrapper.fourPointCheckUrl",
                inputAcceptResponse,
                "FourPointCheck",
                1);
    }

    /**
     * Marks filling as complete.
     * Transition: DUR/4Point → Fill Complete
     */
    public ServiceResponse fillComplete(String chkDURResponse) {
        return executeWorkflowStep(
                "fom.connexusWrapper.fillCompleteUrl",
                chkDURResponse,
                "Fill complete",
                1);
    }

    /**
     * Completes visual verification.
     * Transition: Fill → VV Complete
     */
    public ServiceResponse vvComplete(String fillCompleteResponse) {
        return executeWorkflowStep(
                "fom.connexusWrapper.vvCompleteUrl",
                fillCompleteResponse,
                "VV complete",
                1);
    }

    /**
     * Marks order as ready for pickup.
     * Transition: VV → Pickup
     */
    public ServiceResponse pickupComplete(String vvCompleteResp) {
        return executeWorkflowStep(
                "fom.connexusWrapper.pickupCompleteUrl",
                vvCompleteResp,
                "Pickup complete",
                1);
    }

    /**
     * Completes patient  step.
     * Transition: Pickup → Counsel
     */
    public ServiceResponse counselComplete(String pickupCompleteResp) {
        return executeWorkflowStep(
                "fom.connexusWrapper.counselCompleteUrl",
                pickupCompleteResp,
                "Counsel complete",
                3);
    }

    /**
     * Completes point of sale transaction.
     * Transition: Counsel → POS (Final)
     */
    public ServiceResponse posComplete(String counselCompleteResp) {
        return executeWorkflowStep(
                "fom.connexusWrapper.posCompleteUrl",
                counselCompleteResp,
                "POS complete",
                1);
    }

    // ========== Order Movement Operations ==========

    /**
     * Moves order to pickup queue.
     */
    public ServiceResponse moveOrderToPickUp(String resp) {
        return executeWorkflowStep(
                "fom.connexusWrapper.moveOrderToPickupUrl",
                resp,
                "moveOrderToPickUp",
                2);
    }

    /**
     * Moves order to End of Day queue (string payload version).
     */
    public ServiceResponse moveOrderToEOD(String resp) {
        return executeWorkflowStep(
                "fom.connexusWrapper.moveOrderToEODUrl",
                resp,
                "moveOrderToEOD",
                1);
    }

    /**
     * Moves order to End of Day queue using rxFillId and siteId.
     */
    public ServiceResponse moveToEOD(int rxFillId, int siteId) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();

        MoveOrderToEODRequest moveOrderToEODRequest = new MoveOrderToEODRequest();
        moveOrderToEODRequest.setRxFillId(rxFillId);
        moveOrderToEODRequest.setSiteId(siteId);

        req.setRequestPayloadWithNulls(moveOrderToEODRequest);
        req.setUrl("http://cnx-ui-wrapper-stage.hw-cnx-wrapper.k8s.glb.us.walmart.net/moveToEOD");
        headers.put("content-type", "application/json");
        req.setHeaders(headers);

        ServiceResponse resp = am.getRestContext().performPost(req);

        Reporter.logJSON("Move Order to EOD Request", req.getRequestPayload());
        Reporter.logJSON("Move Order to EOD Response", resp.getDataResponse());

        return resp;
    }

    /**
     * Moves order to End of Day queue with full order context.
     * Fetches order info first, then moves to EOD.
     * 
     * @param orderInfoFetcher Function to fetch order info (injected to avoid circular dependency)
     */
    public ServiceResponse moveOrderToEOD(int patientId, int orderId, int storeNbr,
                                          int rxFillId, int rxId, int numRefills, 
                                          String ndc, Prescriber prescriber,
                                          OrderInfoFetcher orderInfoFetcher) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();

        Date date = DateUtil.tomorrow();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));

        ServiceResponse getOrderInfoResponse = orderInfoFetcher.getOrderInfo(storeNbr, rxFillId, 2);
        JsonObject object = JsonParser.parseString(getOrderInfoResponse.getDataResponse()).getAsJsonObject();
        req.setRequestPayloadWithNulls(object);

        req.setUrl(prop.getProperty("fom.connexusWrapper.moveOrderToEODUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);

        Reporter.log("moveOrderToEOD Request endpoint: " + req.getUrl());
        Reporter.logJSON("moveOrderToEOD Request", req.getRequestPayload());
        Log.info("moveOrderToEOD RequestPayload:\n" + req.getRequestPayload() + "\n");

        ServiceResponse resp = am.getRestContext().performPost(req);

        Reporter.logJSON("moveOrderToEOD Response", resp.getDataResponse());
        Log.info("moveOrderToEOD ResponsePayload:\n" + resp.getDataResponse() + "\n");

        return resp;
    }

    // ========== Helper Methods ==========

    /**
     * Executes a standard workflow step with consistent logging.
     * DRY: All workflow methods follow the same pattern.
     */
    private ServiceResponse executeWorkflowStep(String urlProperty, String payload, 
                                                 String stepName, int retryCount) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();

        req.setUrl(prop.getProperty(urlProperty));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        req.setRequestPayload(payload);

        Reporter.log(stepName + " Request endpoint: " + req.getUrl());
        Reporter.logJSON(stepName + " Request", req.getRequestPayload());
        Log.info(stepName + " RequestPayload:\n" + req.getRequestPayload() + "\n");

        ServiceResponse resp;
        if (retryCount > 1) {
            resp = am.getRestContext().performPost(req, retryCount);
        } else {
            resp = am.getRestContext().performPost(req);
        }

        Reporter.logJSON(stepName + " Response", resp.getDataResponse());
        Log.info(stepName + " ResponsePayload:\n" + resp.getDataResponse() + "\n");

        return resp;
    }

    /**
     * Functional interface to fetch order info.
     * Used to break circular dependency with ConnexusAPIManager.
     */
    @FunctionalInterface
    public interface OrderInfoFetcher {
        ServiceResponse getOrderInfo(int storeNbr, int rxFillId, int retryCount);
    }
}
