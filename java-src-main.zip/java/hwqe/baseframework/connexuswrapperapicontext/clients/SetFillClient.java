package hwqe.baseframework.connexuswrapperapicontext.clients;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash.GetFillDetailsByOrderId;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;

/**
 * Client for SetFill operations (complex JSON transformation).
 * 
 * Handles building setFillInfo requests from getFillDetails responses.
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class SetFillClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final WrapperUtils wrapperUtils;
    private final Gson gson;

    private static final String SET_FILL_TEMPLATE = "src/test/resources/TestData/ConnexusWrapper/RequestModel/setFillDetails.json";

    public SetFillClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.wrapperUtils = new WrapperUtils();
        this.gson = new Gson();
    }

    /**
     * Gets fill details by order ID.
     */
    public ServiceResponse getFillDetailsByOrderId(int siteId, int orderId, int orderSeqNbr) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        headers.put("Authorization", prop.getProperty("cs.header.authorization"));

        GetFillDetailsByOrderId request = new GetFillDetailsByOrderId();
        request.setSiteID(siteId);
        request.setOrderId(orderId);
        request.setOrderSeqNbr(orderSeqNbr);

        String serviceEndPointUrl = StoreIDManager.createEndPointURL(String.valueOf(siteId),
                prop.getProperty("fom.connexusWrapper.portNo"), prop.getProperty("fom.connexusWrapper.sapsUrl"),
                prop.getProperty("fom.connexusWrapper.getFillDetailsByOrderIdEndPoint"));

        req.setRequestPayloadWithNulls(request);
        req.setUrl(serviceEndPointUrl);
        req.setHeaders(headers);

        return am.getRestContext().performPost(req);
    }

    /**
     * Builds and sends setFillInfo request by transforming getFillDetails response.
     */
    public void buildSetFill(int siteId, int orderId, int orderSeqNbr) throws IOException, org.json.simple.parser.ParseException {
        String content = new String(Files.readAllBytes(new File(SET_FILL_TEMPLATE).toPath()));

        Configuration configuration = Configuration.builder()
                .options(Option.ALWAYS_RETURN_LIST)
                .build();

        DocumentContext setFillInfoJsonToParse = JsonPath.parse(content, configuration);

        ServiceResponse getFillDetailsResp = getFillDetailsByOrderId(siteId, orderId, orderSeqNbr);
        JsonObject json = gson.fromJson(getFillDetailsResp.getDataResponse(), JsonObject.class);
        Reporter.log("Get Fill Response is " + getFillDetailsResp.getDataResponse());

        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();
        String inputPickupDate1 = wrapperUtils.ISTToTimestamp(inputPickupDate);
        String inputRxExpDate1 = wrapperUtils.ISTToTimestamp(inputRxExpDate);

        // Extract JSON objects from response
        JsonObject fd = json.get("FillDetailsByOrderId").getAsJsonObject();
        JsonObject drInfo = fd.get("DrInfo").getAsJsonObject();
        JsonObject prescProdInfo = fd.get("PrescProdInfo").getAsJsonObject();
        JsonObject prodItemInfo = fd.get("ProdItemInfo").getAsJsonObject();
        JsonObject custOrder = fd.get("CustomerOrder").getAsJsonObject();
        JsonObject rxOrderDetailInfo = custOrder.get("RxOrderDetailInfo").getAsJsonObject();
        JsonObject rxOrderInfo = rxOrderDetailInfo.get("RxOrderInfo").getAsJsonObject();
        JsonObject rxInfo = rxOrderInfo.get("RxInfo").getAsJsonObject();
        JsonObject patInfo = rxOrderInfo.get("PatientInfo").getAsJsonObject();
        JsonObject addInfo = patInfo.get("SubjectAddressInfo").getAsJsonObject();
        JsonObject rxFillInfo = rxOrderDetailInfo.get("RxFillInfo").getAsJsonObject();
        JsonObject priTPRXDet = fd.get("PrimaryTPRxSaleDetailInfo").getAsJsonObject();
        JsonObject mInfo = fd.get("MiscInfo").getAsJsonObject();

        // Map DrInfo
        mapDrInfo(setFillInfoJsonToParse, drInfo);
        
        // Map PrescProdInfo
        mapPrescProdInfo(setFillInfoJsonToParse, prescProdInfo);
        
        // Map ProdItemInfo
        mapProdItemInfo(setFillInfoJsonToParse, prodItemInfo);
        
        // Map CustomerOrder
        mapCustomerOrder(setFillInfoJsonToParse, rxOrderInfo, rxInfo, patInfo, addInfo, rxFillInfo, inputPickupDate1, inputRxExpDate1);
        
        // Map PrimaryTPRxSaleDetailInfo
        mapPrimaryTP(setFillInfoJsonToParse, priTPRXDet);
        
        // Map MiscInfo
        mapMiscInfo(setFillInfoJsonToParse, mInfo);

        // Send setFillInfo request
        sendSetFillRequest(siteId, setFillInfoJsonToParse.jsonString());
    }

    // ========== Mapping Helpers ==========

    private void mapDrInfo(DocumentContext doc, JsonObject drInfo) {
        doc.set("$.FillDetails.DrInfo.RxPrescriberId", drInfo.get("RxPrescriberId").getAsInt());
        doc.set("$.FillDetails.DrInfo.OriginalPrescriberId", drInfo.get("OriginalPrescriberId").getAsInt());
        doc.set("$.FillDetails.DrInfo.RxClinicId", drInfo.get("RxClinicId").getAsInt());
        doc.set("$.FillDetails.DrInfo.OrgRxClinicId", drInfo.get("OrgRxClinicId").getAsInt());
        doc.set("$.FillDetails.DrInfo.DrName", drInfo.get("DrName").getAsString());
        doc.set("$.FillDetails.DrInfo.OriginalDrName", drInfo.get("OriginalDrName").getAsString());
        doc.set("$.FillDetails.DrInfo.DrAddr", drInfo.get("DrAddr").getAsString());
        doc.set("$.FillDetails.DrInfo.DrCSZ", drInfo.get("DrCSZ").getAsString());
    }

    private void mapPrescProdInfo(DocumentContext doc, JsonObject prescProdInfo) {
        doc.set("$.FillDetails.PrescProdInfo.OriginalProdId", prescProdInfo.get("OriginalProdId").getAsInt());
        doc.set("$.FillDetails.PrescProdInfo.PrescProdId", prescProdInfo.get("PrescProdId").getAsInt());
        doc.set("$.FillDetails.PrescProdInfo.PrescNdcNbr", prescProdInfo.get("PrescNdcNbr").getAsString());
        doc.set("$.FillDetails.PrescProdInfo.PrescDrugName", prescProdInfo.get("PrescDrugName").getAsString());
        doc.set("$.FillDetails.PrescProdInfo.OriginalPrescDrugName", prescProdInfo.get("OriginalPrescDrugName").getAsString());
    }

    private void mapProdItemInfo(DocumentContext doc, JsonObject prodItemInfo) {
        doc.set("$.FillDetails.ProdItemInfo.DispProdId", prodItemInfo.get("DispProdId").getAsInt());
        doc.set("$.FillDetails.ProdItemInfo.DispNdcNbr", prodItemInfo.get("DispNdcNbr").getAsString());
        doc.set("$.FillDetails.ProdItemInfo.DispDrugName", prodItemInfo.get("DispDrugName").getAsString());
        doc.set("$.FillDetails.ProdItemInfo.DispItemId", prodItemInfo.get("DispItemId").getAsInt());
        doc.set("$.FillDetails.ProdItemInfo.DispUnitDoseCost", prodItemInfo.get("DispUnitDoseCost").getAsDouble());
        doc.set("$.FillDetails.ProdItemInfo.DispGpi", prodItemInfo.get("DispGpi").getAsString());
    }

    private void mapCustomerOrder(DocumentContext doc, JsonObject rxOrderInfo, JsonObject rxInfo, 
            JsonObject patInfo, JsonObject addInfo, JsonObject rxFillInfo, 
            String inputPickupDate, String inputRxExpDate) {
        
        doc.set("$.FillDetails.CustomerOrder.RxOrderDetailInfo.RxOrderInfo.RxInfo.OrderId", rxInfo.get("OrderId").getAsInt());
        doc.set("$.FillDetails.CustomerOrder.RxOrderDetailInfo.RxOrderInfo.RxInfo.RxId", rxInfo.get("RxId").getAsInt());
        doc.set("$.FillDetails.CustomerOrder.RxOrderDetailInfo.RxOrderInfo.RxInfo.RxNbr", rxInfo.get("RxNbr").getAsInt());
        doc.set("$.FillDetails.CustomerOrder.RxOrderDetailInfo.RxOrderInfo.RxInfo.WrittenDate", inputPickupDate);
        doc.set("$.FillDetails.CustomerOrder.RxOrderDetailInfo.RxOrderInfo.RxInfo.OriginCode", rxInfo.get("OriginCode").getAsInt());
        doc.set("$.FillDetails.CustomerOrder.RxOrderDetailInfo.RxOrderInfo.RxInfo.ExpirationDate", inputRxExpDate);
        
        doc.set("$.FillDetails.CustomerOrder.RxOrderDetailInfo.RxOrderInfo.PatientInfo.PatientId", patInfo.get("PatientId").getAsInt());
        doc.set("$.FillDetails.CustomerOrder.RxOrderDetailInfo.RxOrderInfo.PatientInfo.Name", patInfo.get("Name").getAsString());
        doc.set("$.FillDetails.CustomerOrder.RxOrderDetailInfo.RxOrderInfo.PatientInfo.Gender", patInfo.get("Gender").getAsInt());
        doc.set("$.FillDetails.CustomerOrder.RxOrderDetailInfo.RxOrderInfo.PatientInfo.DOB", patInfo.get("DOB").getAsString());
        
        doc.set("$.FillDetails.CustomerOrder.RxOrderDetailInfo.RxFillInfo.RxFillId", rxFillInfo.get("RxFillId").getAsInt());
        doc.set("$.FillDetails.CustomerOrder.RxOrderDetailInfo.RxFillInfo.OrderSeqNbr", rxFillInfo.get("OrderSeqNbr").getAsInt());
    }

    private void mapPrimaryTP(DocumentContext doc, JsonObject priTPRXDet) {
        if (priTPRXDet.has("TpId") && !priTPRXDet.get("TpId").isJsonNull()) {
            doc.set("$.FillDetails.PrimaryTPRxSaleDetailInfo.TpId", priTPRXDet.get("TpId").getAsInt());
        }
    }

    private void mapMiscInfo(DocumentContext doc, JsonObject mInfo) {
        doc.set("$.FillDetails.MiscInfo.PreviousFillDate", mInfo.get("PreviousFillDate").getAsString());
        doc.set("$.FillDetails.MiscInfo.RphInitials", mInfo.get("RphInitials").getAsString());
    }

    private void sendSetFillRequest(int siteId, String payload) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));

        req.setRequestPayload(payload);
        req.setUrl(prop.getProperty("fom.connexusWrapper.setFillInfoUrl"));
        req.setHeaders(headers);

        Reporter.log("SetFillInfo Request endpoint: " + req.getUrl());
        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.log("SetFillInfo Response: " + resp.getDataResponse());
    }
}
