package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.Downtime;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.utilities.PropertyReader;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * Client for Downtime (resolve queue) operations.
 * 
 * Handles:
 * - Processing downtime resolution
 * - Updating tax and patient due amounts
 * - RX sale detail insertion with downtime status
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class DowntimeClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final DBUtils dbUtils;

    public DowntimeClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.dbUtils = new DBUtils();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public DowntimeClient(AutomationManager am, PropertyReader prop, DBUtils dbUtils) {
        this.am = am;
        this.prop = prop;
        this.dbUtils = dbUtils;
    }

    // ========== Downtime Processing ==========

    /**
     * Processes downtime resolution for a fill.
     * Updates tax and patient due amounts as needed.
     * 
     * @param rxFillId The fill ID
     * @param orderId The order ID
     * @param orderSeqNbr The order sequence number
     * @param userId The user ID
     * @param machineName The machine name
     * @param siteID The site ID
     * @return HTTP status code (200 for success)
     */
    public int downTime(int rxFillId, int orderId, int orderSeqNbr, String userId, String machineName, int siteID) {
        // Get tax details before downtime
        Map<String, Object> taxDetails = dbUtils.getRxFIllDetails(siteID, rxFillId);
        BigDecimal patientTaxAmt = (BigDecimal) taxDetails.get("tax_amt");
        BigDecimal patientDueAmt = (BigDecimal) taxDetails.get("patient_due_amt");

        // Build and send downtime request
        ServiceResponse resp = sendDowntimeRequest(rxFillId, orderId, orderSeqNbr, userId, machineName, siteID);

        // Update amounts after downtime if needed
        updateAmountsAfterDowntime(siteID, rxFillId, taxDetails, patientTaxAmt, patientDueAmt);

        Assert.assertEquals(resp.getStatusCode(), 200, "Expected status code 200 but found " + resp.getStatusCode());
        Log.info("Status code of downtime:\n" + resp.getStatusCode() + "\n");

        return resp.getStatusCode();
    }

    // ========== RX Sale Detail Operations ==========

    /**
     * Inserts RX sale detail with downtime status.
     */
    public int addRxSaleDetailsWithDowntime(Integer siteId, Integer rxFillId) {
        return dbUtils.insertRxSaleDetailWithDowntimeStatus(siteId, rxFillId);
    }

    /**
     * Inserts RX sale detail with TPS submitted status.
     */
    public int insertRxSaleDetailWithTPSSubmitted(Integer siteId, Integer rxFillId) {
        return dbUtils.insertRxSaleDetailWithTPSSubmitted(siteId, rxFillId);
    }

    // ========== Helper Methods ==========

    /**
     * Sends the downtime request to the API.
     */
    private ServiceResponse sendDowntimeRequest(int rxFillId, int orderId, int orderSeqNbr, 
            String userId, String machineName, int siteID) {

        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        headers.put("content-type", "application/json");

        Downtime downtime = new Downtime();
        downtime.setFillId(rxFillId);
        downtime.setOrderId(orderId);
        downtime.setOrderSeqNbr(orderSeqNbr);
        downtime.setMachineName(machineName);
        downtime.setUserId(userId);
        downtime.setSiteID(siteID);

        String serviceEndpoint = StoreIDManager.createEndPointURL(
                String.valueOf(siteID),
                prop.getProperty("fom.connexusWrapper.portNo"),
                prop.getProperty("fom.connexusWrapper.sapsUrl"),
                prop.getProperty("fom.connexusWrapper.GetBasicInfo"));

        req.setRequestPayloadWithNulls(downtime);
        req.setUrl(serviceEndpoint);
        req.setHeaders(headers);

        return am.getRestContext().performPost(req);
    }

    /**
     * Updates patient due and tax amounts after downtime if needed.
     */
    private void updateAmountsAfterDowntime(int siteID, int rxFillId, Map<String, Object> taxDetails,
            BigDecimal patientTaxAmt, BigDecimal patientDueAmt) {

        BigDecimal dueAmntAfterDowntime = (BigDecimal) taxDetails.get("patient_due_amt");

        if (dueAmntAfterDowntime.compareTo(BigDecimal.ZERO) <= 0) {
            dbUtils.updatePatientDueAmnt(siteID, rxFillId, patientTaxAmt.add(patientDueAmt));
        }

        if (patientTaxAmt.compareTo(BigDecimal.ZERO) > 0) {
            dbUtils.updatePatientTaxAmnt(siteID, rxFillId, patientTaxAmt);
        }
    }
}
