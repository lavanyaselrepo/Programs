package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.CancelFill.CancelFill;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StringUtils;

import java.util.HashMap;

/**
 * Client for Cancel Fill operations.
 * 
 * Handles:
 * - Cancelling fills
 * - Cancelling prescriptions by RX number
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class CancelClient {

    private final AutomationManager am;
    private final PropertyReader prop;

    // Hardcoded endpoint for cancel prescriptions (stage environment)
    private static final String CANCEL_PRESCRIPTIONS_URL = 
            "http://cnx-ui-wrapper-stage.hw-cnx-wrapper.k8s.glb.us.walmart.net/cancelPrescriptions";

    public CancelClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public CancelClient(AutomationManager am, PropertyReader prop) {
        this.am = am;
        this.prop = prop;
    }

    // ========== Cancel Operations ==========

    /**
     * Cancels a fill using the CancelFill object.
     * 
     * @param cancelFill The cancel fill request object
     * @return ServiceResponse from the API call
     */
    public ServiceResponse cancelFill(CancelFill cancelFill) {
        try {
            ServiceRequest req = new ServiceRequest();
            HashMap<String, String> headers = buildAuthHeaders();

            String baseUrl = StringUtils.replaceStoreNumber(
                    prop.getProperty("cw.baseURL"),
                    String.valueOf(cancelFill.getSiteId()));

            req.setRequestPayloadWithNulls(cancelFill);
            req.setUrl(baseUrl + prop.getProperty("cw.cancelFill"));
            req.setHeaders(headers);

            ServiceResponse resp = am.getRestContext().performPost(req);
            Reporter.logJSON("Fill has been cancelled", resp.getDataResponse());

            return resp;
        } catch (Exception e) {
            // Return empty response on error (maintains original behavior)
            return new ServiceResponse();
        }
    }

    /**
     * Cancels a prescription using RX number.
     * Uses the stage environment cancel prescriptions endpoint.
     * 
     * @param cancelFill The cancel fill request object
     */
    public void cancelPrescriptionUsingRxNumber(CancelFill cancelFill) {
        try {
            ServiceRequest req = new ServiceRequest();
            HashMap<String, String> headers = new HashMap<>();
            headers.put("content-type", "application/json");

            req.setRequestPayloadWithNulls(cancelFill);
            req.setUrl(CANCEL_PRESCRIPTIONS_URL);
            req.setHeaders(headers);

            Reporter.logJSON("CancelFill Request is :: ", req.getRequestPayload());

            ServiceResponse resp = am.getRestContext().performPost(req);
            Reporter.logJSON("Fill has been cancelled :: ", resp.getDataResponse());

        } catch (Exception e) {
            Reporter.logJSON("Exception occurred while cancelling fill", e.getMessage());
        }
    }

    // ========== Helper Methods ==========

    /**
     * Builds headers with authentication for cancel requests.
     */
    private HashMap<String, String> buildAuthHeaders() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        return headers;
    }
}
