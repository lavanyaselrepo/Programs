package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.interfaces.IDatabaseContext;
import org.testng.Assert;

/**
 * Client for Database Operations (BuParm, FillTax, etc.).
 * 
 * Handles:
 * - BuParm (business parameter) CRUD
 * - Fill tax info operations
 * - Direct database queries for Connexus
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class DatabaseOpsClient {

    public DatabaseOpsClient() {
        // No dependencies needed - all methods take IDatabaseContext as param
    }

    // ========== BuParm Operations ==========

    /**
     * Gets BuParm (business parameter) from Connexus database.
     * 
     * @param cnx Database context
     * @param phmParmCode Parameter code to lookup
     * @return DataRow containing the parameter
     */
    public DataRow getBuParm(IDatabaseContext cnx, String phmParmCode) {
        String query = "select * from bu_phm_parm where phm_parm_code=" + phmParmCode;
        DataTable dt = cnx.getDataTable(query);
        Assert.assertEquals(dt.getRowCount(), 1, "Expected exactly 1 BuParm record for code: " + phmParmCode);
        return dt.getDataRows().get(0);
    }

    /**
     * Updates BuParm value in Connexus database.
     * 
     * @param cnx Database context
     * @param phmParmValue New parameter value
     * @param phmParmCode Parameter code to update
     * @return Number of rows updated
     */
    public int updateBuParmInfo(IDatabaseContext cnx, String phmParmValue, String phmParmCode) {
        String query = String.format(
                "update bu_phm_parm set phm_parm_value='%s' where phm_parm_code=%s",
                phmParmValue, phmParmCode);
        return cnx.executeUpdateQuery(query);
    }

    // ========== Fill Tax Operations ==========

    /**
     * Gets fill tax info from Connexus database.
     * 
     * @param cnx Database context
     * @param rxFillId Fill ID
     * @param posCalcInd POS calculation indicator
     * @return DataRow containing tax info, or null if not found
     */
    public DataRow getFillTaxInfo(IDatabaseContext cnx, int rxFillId, String posCalcInd) {
        String query = String.format(
                "select * from rx_fill_tax where rx_fill_id= %d and pos_calc_ind = '%s'",
                rxFillId, posCalcInd);
        DataTable dt = cnx.getDataTable(query);
        
        if (dt.getRowCount() == 0) {
            return null;
        }
        return dt.getDataRows().get(0);
    }

    /**
     * Inserts fill tax info into Connexus database.
     * 
     * @param cnx Database context
     * @param rxFillId Fill ID
     * @param posCalcInd POS calculation indicator
     * @return Number of rows inserted
     */
    public int insertFillTax(IDatabaseContext cnx, int rxFillId, String posCalcInd) {
        String query = String.format(
                "INSERT INTO rx_fill_tax (rx_fill_id, basis_price_ind, pos_calc_ind, tax_amt) VALUES (%d,'P','%s','0.34')",
                rxFillId, posCalcInd);
        return cnx.executeInsertQuery(query);
    }
}
