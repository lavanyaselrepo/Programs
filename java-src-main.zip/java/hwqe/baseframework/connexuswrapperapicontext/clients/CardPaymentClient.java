package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DBModels.EasyPay.PatientPaymentInfo;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DBModels.EasyPay.updateEasyPayCard;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.cardAddition.AddCardRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.GetCardDetails;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.cardAddition.PatientPaymentInfoItem;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StringUtils;
import hwqe.baseframework.vaults.AzureKeyVaultConfig;
import hwqe.baseframework.vaults.AzureKeyVaultContext;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Client for card and payment operations.
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 * Handles card addition, retrieval, and EasyPay operations.
 */
public class CardPaymentClient {

    private final AutomationManager am;
    private final PropertyReader prop;

    public CardPaymentClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public CardPaymentClient(AutomationManager am, PropertyReader prop) {
        this.am = am;
        this.prop = prop;
    }

    /**
     * Adds a card to a patient's account.
     */
    public ServiceResponse addCardToPatientAccount(String patientId, String strNbr, String cardRefNbr,
                                                    String cardHolderName, String expirYearNbr, String expirMoNbr,
                                                    String p2peToken, String startDate, String phmPymtMethod) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();

        // Note: AzureKeyVaultConfig/Context instantiated but not used in original - kept for compatibility
        AzureKeyVaultConfig config = new AzureKeyVaultConfig();
        AzureKeyVaultContext auth = new AzureKeyVaultContext(config);

        AddCardRequest cardRequest = AddCardRequest.builder()
                .patientId(patientId)
                .storeNbr(strNbr)
                .patientPaymentInfo(buildPatientPaymentInfo(cardRefNbr, cardHolderName, expirMoNbr, 
                        expirYearNbr, p2peToken, startDate, phmPymtMethod))
                .build();

        req.setRequestPayloadWithNulls(cardRequest);
        req.setUrl(prop.getProperty("fom.addCardToPatientAccount"));
        headers.put("content-type", "application/json");
        headers.put("Authorization", prop.getProperty("card.authentication"));
        headers.put("WM_SVC.NAME", prop.getProperty("fom.WM_SVC.NAME_1"));
        headers.put("WM_SVC.ENV", prop.getProperty("fom.WM_SVC.ENV_1"));
        headers.put("WM_CONSUMER.ID", prop.getProperty("fom.WM_CONSUMER.ID"));
        req.setHeaders(headers);

        Reporter.log("AddCard Request endpoint: " + req.getUrl());
        Reporter.logJSON("AddCard Request", cardRequest);
        Log.info("AddCard RequestPayload:\n" + req.getRequestPayload() + "\n");

        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("AddCard Response", resp.getDataResponse());
        Log.info("AddCard ResponsePayload:\n" + resp.getDataResponse() + "\n");

        return resp;
    }

    /**
     * Gets card details for a patient.
     */
    public ServiceResponse getCardDetails(String patientId, String strNbr) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();

        GetCardDetails getCardDetails = new GetCardDetails();
        getCardDetails.setPatientId(patientId);
        getCardDetails.setSiteID(Integer.parseInt(strNbr));

        req.setRequestPayloadWithNulls(getCardDetails);
        String serviceEndPointUrl = StoreIDManager.createEndPointURL(
                strNbr,
                prop.getProperty("fom.connexusWrapper.portNo"),
                prop.getProperty("fom.connexusWrapper.sapsUrl"),
                prop.getProperty("fom.getCardDetailsEndpoint"));
        req.setUrl(serviceEndPointUrl);

        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);

        Reporter.log("getCard Request endpoint: " + req.getUrl());
        Reporter.logJSON("getCard Request", req.getRequestPayload());
        Log.info("getCard RequestPayload:\n" + req.getRequestPayload() + "\n");

        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("getCard Response", resp.getDataResponse());
        Log.info("getCard ResponsePayload:\n" + resp.getDataResponse() + "\n");

        return resp;
    }

    /**
     * Builds patient payment info list for card operations.
     */
    public List<PatientPaymentInfoItem> buildPatientPaymentInfo(String cardRefNbr, String cardHolderName,
                                                                 String expirYearNbr, String expirMoNbr,
                                                                 String p2peToken, String startDate,
                                                                 String phmPymtMethod) {
        List<PatientPaymentInfoItem> details = new ArrayList<>();

        String address = "Address card" + StringUtils.addressGenerator();
        String cityName = StringUtils.cityNameGenerator();
        String zipCode = StringUtils.zipCodeGenerator();
        String phoneNbr = StringUtils.phoneNumberGenerator();

        PatientPaymentInfoItem patientInfo = PatientPaymentInfoItem.builder()
                .billingAddrTxt(address)
                .cardHolderName(cardHolderName)
                .cityName(cityName)
                .cardSeqNbr(prop.getProperty("fom.cardSeqNbr"))
                .cardSuffixNbr(cardRefNbr.substring(7, 11))
                .cardRefNbr(cardRefNbr)
                .expirMoNbr(expirMoNbr)
                .expirYearNbr(expirYearNbr)
                .lastChangeUserId(prop.getProperty("fom.changeUserId"))
                .postalCode(zipCode)
                .p2peToken(p2peToken)
                .relationshipCode(prop.getProperty("fom.relationshipCode"))
                .phmPymtMthdCode(phmPymtMethod)
                .pymtFreqCode(prop.getProperty("fom.pymtFreqCode"))
                .signatureFrequencyCode(prop.getProperty("fom.signatureFrequencyCode"))
                .startDate(startDate)
                .stateProvCode(prop.getProperty("fom.stateProvCode"))
                .phoneNbr(phoneNbr)
                .routingNbr("")
                .build();

        details.add(patientInfo);
        return details;
    }

    /**
     * Inserts EasyPay card details for a patient.
     */
    public ServiceResponse insertEasyPayCardDetails(String siteId, int patientId) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();

        // Note: AzureKeyVaultConfig/Context instantiated but not used in original - kept for compatibility
        AzureKeyVaultConfig config = new AzureKeyVaultConfig();
        AzureKeyVaultContext auth = new AzureKeyVaultContext(config);

        updateEasyPayCard updateEasyPayCard = new updateEasyPayCard();
        PatientPaymentInfo patientPaymentInfo = new PatientPaymentInfo();

        updateEasyPayCard.setStoreNbr(siteId);
        updateEasyPayCard.setPatientId(String.valueOf(patientId));

        patientPaymentInfo.setPhmPymtAcctId("");
        patientPaymentInfo.setCardSeqNbr(prop.getProperty("fom.cardSeqNbr"));
        patientPaymentInfo.setPymtFreqCode(prop.getProperty("fom.pymtFreqCode"));
        patientPaymentInfo.setRelationshipCode(prop.getProperty("fom.relationshipCode"));
        patientPaymentInfo.setStartDate(prop.getProperty("fom.startDate"));
        patientPaymentInfo.setExpirYearNbr(prop.getProperty("fom.expirYearNbr"));
        patientPaymentInfo.setExpirMoNbr(prop.getProperty("fom.expirMoNbr"));
        patientPaymentInfo.setCardHolderName(prop.getProperty("fom.cardHolderName"));
        patientPaymentInfo.setPhmPymtMthdCode(prop.getProperty("fom.phmPymtMthdCode"));
        patientPaymentInfo.setBillingAddrTxt(prop.getProperty("fom.billingAddrTxt"));
        patientPaymentInfo.setCityName(prop.getProperty("fom.cityName"));
        patientPaymentInfo.setPostalCode(prop.getProperty("fom.postalCode"));
        patientPaymentInfo.setStateProvCode(prop.getProperty("fom.stateProvCode"));
        patientPaymentInfo.setRoutingNbr("");
        patientPaymentInfo.setPhoneNbr("");
        patientPaymentInfo.setCardRefNbr(prop.getProperty("fom.cardRefNbr"));
        patientPaymentInfo.setCardSuffixNbr(prop.getProperty("fom.cardSuffixNbr"));
        patientPaymentInfo.setLastChangeUserId(prop.getProperty("fom.lastChangeUserId"));
        patientPaymentInfo.setSignatureFrequencyCode(prop.getProperty("fom.signatureFrequencyCode"));
        patientPaymentInfo.setP2peToken(prop.getProperty("fom.p2peToken"));

        ArrayList<PatientPaymentInfo> patientPaymentInfos = new ArrayList<>();
        patientPaymentInfos.add(patientPaymentInfo);
        updateEasyPayCard.setPatientPaymentInfo(patientPaymentInfos);

        req.setRequestPayloadWithNulls(updateEasyPayCard);
        req.setUrl(prop.getProperty("fom.addCardToPatientAccount"));
        headers.put("content-type", "application/json");
        headers.put("Authorization", prop.getProperty("card.authentication"));
        headers.put("WM_SVC.NAME", prop.getProperty("fom.WM_SVC.NAME_1"));
        headers.put("WM_SVC.ENV", prop.getProperty("fom.WM_SVC.ENV_1"));
        headers.put("WM_CONSUMER.ID", prop.getProperty("fom.WM_CONSUMER.ID"));
        req.setHeaders(headers);

        Reporter.logJSON("AddCard Request", req.getRequestPayload());
        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("AddCard Response", resp.getDataResponse());

        Assert.assertEquals(resp.getStatusCode(), 202, "Insert EasyPay Card details API response status code did not match");
        return resp;
    }
}
