package hwqe.baseframework.connexuswrapperapicontext.clients;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.models.datamodels.cosmos.TestRecord;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;

import java.util.HashMap;

/**
 * Client for Cosmos DB test record operations.
 * 
 * Handles:
 * - Inserting/updating test suite run records
 * - Retrieving test records by ID
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class CosmosClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final Gson gson;

    public CosmosClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.gson = new Gson();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public CosmosClient(AutomationManager am, PropertyReader prop) {
        this.am = am;
        this.prop = prop;
        this.gson = new Gson();
    }

    // ========== Insert/Update Operations ==========

    /**
     * Inserts or updates a test record in Cosmos DB.
     * Updates the testRecord's _ts field with the Cosmos-assigned timestamp.
     * 
     * @param testRecord The test record to insert/update
     * @throws RuntimeException if the Cosmos call fails
     */
    public void insertUpdateRecordForSuiteRunInDb(TestRecord testRecord) {
        ServiceRequest cosmosReq = buildCosmosRequest();
        cosmosReq.setRequestPayload(testRecord);
        cosmosReq.setUrl(prop.getProperty("insert.update.test.record.url"));

        Reporter.log("Insert/Update Request endpoint: " + cosmosReq.getUrl());
        Reporter.logJSON("Insert/Update Request", testRecord);
        Log.info("Insert/Update Request:\n" + testRecord.toString() + "\n");

        ServiceResponse cosmosResp = am.getRestContext().performPost(cosmosReq);

        Log.info("Insert/Update Response (Status: " + cosmosResp.getStatusCode() + "): " + cosmosResp.getDataResponse() + "\n");
        Reporter.logJSON("Insert/Update Response", cosmosResp.getDataResponse());

        validateResponse(cosmosResp, "insert/update");
        updateTimestampFromResponse(testRecord, cosmosResp);
    }

    // ========== Read Operations ==========

    /**
     * Retrieves a test record by ID from Cosmos DB.
     * 
     * @param id The record ID
     * @return The TestRecord
     * @throws RuntimeException if the Cosmos call fails
     */
    public TestRecord getRecordById(String id) {
        ServiceRequest cosmosReq = buildCosmosRequest();
        cosmosReq.setUrl(prop.getProperty("get.test.record.url") + id);

        Reporter.log("Get Test Record Request endpoint: " + cosmosReq.getUrl());
        Reporter.logJSON("Get Test Record Request", cosmosReq);

        ServiceResponse cosmosResp = am.getRestContext().performGet(cosmosReq);
        Reporter.logJSON("Get Test Record Response", cosmosResp.getDataResponse());

        validateResponse(cosmosResp, "get record");

        String dataResponse = cosmosResp.getDataResponse();
        JsonObject jsonObject = JsonParser.parseString(dataResponse).getAsJsonObject();
        JsonObject testRecordJson = jsonObject.getAsJsonObject("testRecord");

        return gson.fromJson(testRecordJson, TestRecord.class);
    }

    // ========== Helper Methods ==========

    /**
     * Builds a fresh ServiceRequest with Cosmos headers.
     * Uses fresh headers to avoid stale auth headers from other API calls.
     */
    private ServiceRequest buildCosmosRequest() {
        HashMap<String, String> cosmosHeaders = new HashMap<>();
        cosmosHeaders.put("content-type", "application/json");

        ServiceRequest cosmosReq = new ServiceRequest();
        cosmosReq.setHeaders(cosmosHeaders);

        return cosmosReq;
    }

    /**
     * Validates the Cosmos response and throws if it failed.
     */
    private void validateResponse(ServiceResponse response, String operation) {
        int statusCode = response.getStatusCode();
        if (statusCode < 200 || statusCode >= 300) {
            throw new RuntimeException("Cosmos " + operation + " failed with status " + statusCode + ": " + response.getDataResponse());
        }
    }

    /**
     * Updates the testRecord's _ts field from the Cosmos response.
     * This allows callers to read the Cosmos-assigned timestamp.
     */
    private void updateTimestampFromResponse(TestRecord testRecord, ServiceResponse cosmosResp) {
        try {
            String responseJson = cosmosResp.getDataResponse();
            if (responseJson != null && !responseJson.isEmpty()) {
                JsonObject jsonObj = JsonParser.parseString(responseJson).getAsJsonObject();
                // Check if response has testRecord wrapper or is direct
                JsonObject recordObj = jsonObj.has("testRecord")
                        ? jsonObj.getAsJsonObject("testRecord")
                        : jsonObj;
                if (recordObj.has("_ts") && !recordObj.get("_ts").isJsonNull()) {
                    long ts = recordObj.get("_ts").getAsLong();
                    testRecord.set_ts(ts);
                    Log.info("Updated testRecord._ts from Cosmos response: " + ts);
                }
            }
        } catch (Exception e) {
            Log.warn("Could not parse _ts from Cosmos response: " + e.getMessage());
        }
    }
}
