package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests.FillingGetFillInfoRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests.FillingOrderLineInfoContents;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests.FillingProblemContents;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests.FillingSetFillInfoRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests.FillingSetFillItemContents;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Response.FillingGetFillInfoResponse;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuples;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Client for fill operations (SAPS getFillInfo/setFillInfo).
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 * Handles prescription filling workflow API calls.
 */
public class FillInfoClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final DBUtils dbUtils;

    public FillInfoClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.dbUtils = new DBUtils();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public FillInfoClient(AutomationManager am, PropertyReader prop, DBUtils dbUtils) {
        this.am = am;
        this.prop = prop;
        this.dbUtils = dbUtils;
    }

    /**
     * Gets fill information for an order from SAPS.
     */
    public ServiceResponse getFillInfo(String source, String deviceName, int storeId, 
                                        String orderId, int toteNbr, String userId, String assignedOrd) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();

        FillingGetFillInfoRequest getFillInfoRequest = new FillingGetFillInfoRequest();
        getFillInfoRequest.setSource(source);
        getFillInfoRequest.setDeviceName(deviceName);
        getFillInfoRequest.setStoreId(storeId);
        getFillInfoRequest.setOrderId(orderId);
        getFillInfoRequest.setToteNbr(toteNbr);
        getFillInfoRequest.setUserId(userId);
        getFillInfoRequest.setAssignedOrd(assignedOrd);

        req.setRequestPayloadWithNulls(getFillInfoRequest);
        String serviceEndPointUrl = StoreIDManager.createEndPointURL(
                String.valueOf(storeId),
                prop.getProperty("fom.connexusWrapper.portNo"),
                prop.getProperty("fom.connexusWrapper.sapsUrl"),
                prop.getProperty("fom.connexusWrapper.getfill"));
        req.setUrl(serviceEndPointUrl);

        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);

        Reporter.log("getFillInfo endpoint: " + req.getUrl());
        Reporter.logJSON("getFillInfo Request", getFillInfoRequest);
        Log.info("getFillInfo RequestPayload:\n" + req.getRequestPayload());

        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("getFillInfo Response", resp.getDataResponse());
        Log.info("getFillInfo ResponsePayload:\n" + resp.getDataResponse());

        return resp;
    }

    /**
     * Sets fill information for an order in SAPS.
     */
    public ServiceResponse setFillInfo(String orderId, int storeNbr, String deviceId, 
                                        String techUserId, int bagNbr, String labelMac, 
                                        String reprintInd, ArrayList<FillingOrderLineInfoContents> orderLineInfo) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();

        FillingSetFillInfoRequest sapsSetFillInfo = new FillingSetFillInfoRequest();
        sapsSetFillInfo.setOrderId(orderId);
        sapsSetFillInfo.setGroupingId(null);
        sapsSetFillInfo.setStoreNbr(storeNbr);
        sapsSetFillInfo.setDeviceId(deviceId);
        sapsSetFillInfo.setTechUserId(techUserId);
        sapsSetFillInfo.setBagNbr(bagNbr);
        sapsSetFillInfo.setLabelMac(labelMac);
        sapsSetFillInfo.setReprintInd(reprintInd);
        sapsSetFillInfo.setOrderLineInfo(orderLineInfo);

        req.setRequestPayloadWithNulls(sapsSetFillInfo);
        String serviceEndPointUrl = StoreIDManager.createEndPointURL(
                String.valueOf(storeNbr),
                prop.getProperty("fom.connexusWrapper.portNo"),
                prop.getProperty("fom.connexusWrapper.sapsUrl"),
                prop.getProperty("fom.connexusWrapper.setfill"));
        req.setUrl(serviceEndPointUrl);

        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);

        Reporter.log("setFillInfo endpoint: " + req.getUrl());
        Reporter.logJSON("setFillInfo Request", sapsSetFillInfo);
        Log.info("setFillInfo RequestPayload:\n" + req.getRequestPayload());

        ServiceResponse resp = am.getRestContext().performPost(req, 3);
        Reporter.logJSON("setFillInfo Response", resp.getDataResponse());

        return resp;
    }

    /**
     * Validates and processes setFillInfo for cancelled fills.
     * Processes each item in the fill response and validates problem codes.
     */
    public void validateSetFillInfoAPIForCancelled(int storeNbr, FillingGetFillInfoResponse getFillInfoResponse, 
                                                    int problemCodeForCancelFill, boolean isRTSVialUsed) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        String ts = sdf.format(new Timestamp(System.currentTimeMillis()));

        for (int i = 0; i < getFillInfoResponse.getFillWork().getItemDetails().size(); i++) {
            ArrayList<FillingOrderLineInfoContents> orderLineInfoList = new ArrayList<>();
            ArrayList<FillingSetFillItemContents> fillItemList = new ArrayList<>();

            int fill_Id = (int) getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getRxFillId();
            String orderLineItemId = getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getOrderLineItemId();
            int on_hand_qty_BeforeSetFill = getFillInfoResponse.getFillWork().getItemDetails().get(i).getOnHandQty();
            int mds_fam_id = getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getFilItem().get(0).getItemMdsFamId();

            Reporter.log("on_hand_qty for mds_fam_id:" + mds_fam_id + " before setFill for fill_Id:" + fill_Id + " is " + on_hand_qty_BeforeSetFill);

            FillingOrderLineInfoContents orderLineInfo = buildOrderLineInfo(getFillInfoResponse, i, fill_Id, ts);
            FillingSetFillItemContents fillItemContents = buildFillItemContents(getFillInfoResponse, i);
            
            fillItemList.add(fillItemContents);
            orderLineInfo.setFillItem(fillItemList);

            // Set problem info for cancellation
            FillingProblemContents problemContents = new FillingProblemContents();
            problemContents.setProblemCode(problemCodeForCancelFill);
            problemContents.setDispensedNdc(getFillInfoResponse.getFillWork().getItemDetails().get(i).getNdcNbr());
            problemContents.setRequestedNdc(prop.getProperty("fom.setRequestedNdc"));
            orderLineInfo.setProblem(problemContents);
            orderLineInfo.setRtsVialItemsUsed(null);

            orderLineInfoList.add(orderLineInfo);

            // Call setFillInfo
            int bagNbr = getFillInfoResponse.getFillWork().getOrderLineItem().get(0).getBagInfo().getBagNbr();
            ServiceResponse setFillInforesp = setFillInfo(
                    getFillInfoResponse.getOrderId(),
                    getFillInfoResponse.getStoreNbr(),
                    prop.getProperty("fom.setDeviceName"),
                    getFillInfoResponse.getUserId(),
                    bagNbr,
                    prop.getProperty("fom.setlabelMac"),
                    prop.getProperty("fom.reprintInd"),
                    orderLineInfoList);

            Assert.assertEquals(setFillInforesp.getStatusCode(), 200, "SetFillInfo Saps service response did not match");
            am.performSleep(30);

            // Problem code validation
            int prblm_CodeTransactionInDB = dbUtils.getRxOrderDetailTableValue(storeNbr, getFillInfoResponse, problemCodeForCancelFill);
            Assert.assertEquals(prblm_CodeTransactionInDB, i + 1, 
                    "problem code:" + problemCodeForCancelFill + " is not logged in rx_ord_dtl_problem for order_id:" 
                    + Integer.parseInt(getFillInfoResponse.getOrderId()) + " and order_seq_nbr:" 
                    + Integer.parseInt(orderLineItemId) + " after setFill with status:CANCELLED");
            Reporter.log("problem_code:" + problemCodeForCancelFill + " is logged in rx_ord_dtl_problem for order_id:" 
                    + Integer.parseInt(getFillInfoResponse.getOrderId()) + " and order_seq_nbr:" 
                    + Integer.parseInt(orderLineItemId) + " after setFill with status:CANCELLED");
        }
    }

    /**
     * Processes setFillInfo for cancelled fills and returns fill/rx IDs.
     */
    public Tuple2<Integer, Integer> setFillInfoAPIForCancelled(int storeNbr, FillingGetFillInfoResponse getFillInfoResponse, 
                                                                int problemCodeForCancelFill, boolean isRTSVialUsed) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        String ts = sdf.format(new Timestamp(System.currentTimeMillis()));
        Tuple2<Integer, Integer> responseData = null;

        for (int i = 0; i < getFillInfoResponse.getFillWork().getItemDetails().size(); i++) {
            ArrayList<FillingOrderLineInfoContents> orderLineInfoList = new ArrayList<>();
            ArrayList<FillingSetFillItemContents> fillItemList = new ArrayList<>();

            int fill_Id = (int) getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getRxFillId();
            String rx_id = getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getRxId();
            String orderLineItemId = getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getOrderLineItemId();
            int on_hand_qty_BeforeSetFill = getFillInfoResponse.getFillWork().getItemDetails().get(i).getOnHandQty();
            int mds_fam_id = getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getFilItem().get(0).getItemMdsFamId();

            Reporter.log("on_hand_qty for mds_fam_id:" + mds_fam_id + " before setFill for fill_Id:" + fill_Id + " is " + on_hand_qty_BeforeSetFill);

            FillingOrderLineInfoContents orderLineInfo = buildOrderLineInfo(getFillInfoResponse, i, fill_Id, ts);
            FillingSetFillItemContents fillItemContents = buildFillItemContents(getFillInfoResponse, i);
            
            fillItemList.add(fillItemContents);
            orderLineInfo.setFillItem(fillItemList);

            // Set problem info for cancellation
            FillingProblemContents problemContents = new FillingProblemContents();
            problemContents.setProblemCode(problemCodeForCancelFill);
            problemContents.setDispensedNdc(getFillInfoResponse.getFillWork().getItemDetails().get(i).getNdcNbr());
            problemContents.setRequestedNdc(prop.getProperty("fom.setRequestedNdc"));
            orderLineInfo.setProblem(problemContents);
            orderLineInfo.setRtsVialItemsUsed(null);

            orderLineInfoList.add(orderLineInfo);

            // Call setFillInfo
            int bagNbr = getFillInfoResponse.getFillWork().getOrderLineItem().get(0).getBagInfo().getBagNbr();
            ServiceResponse setFillInforesp = setFillInfo(
                    getFillInfoResponse.getOrderId(),
                    getFillInfoResponse.getStoreNbr(),
                    prop.getProperty("fom.setDeviceName"),
                    getFillInfoResponse.getUserId(),
                    bagNbr,
                    prop.getProperty("fom.setlabelMac"),
                    prop.getProperty("fom.reprintInd"),
                    orderLineInfoList);

            Assert.assertEquals(setFillInforesp.getStatusCode(), 200, "SetFillInfo Saps service response did not match");
            am.performSleep(30);

            // Problem code validation
            int prblm_CodeTransactionInDB = dbUtils.getRxOrderDetailTableValue(storeNbr, getFillInfoResponse, problemCodeForCancelFill);
            Assert.assertEquals(prblm_CodeTransactionInDB, i + 1, 
                    "problem code:" + problemCodeForCancelFill + " is not logged in rx_ord_dtl_problem for order_id:" 
                    + Integer.parseInt(getFillInfoResponse.getOrderId()) + " and order_seq_nbr:" 
                    + Integer.parseInt(orderLineItemId) + " after setFill with status:CANCELLED");
            Reporter.log("problem_code:" + problemCodeForCancelFill + " is logged in rx_ord_dtl_problem for order_id:" 
                    + Integer.parseInt(getFillInfoResponse.getOrderId()) + " and order_seq_nbr:" 
                    + Integer.parseInt(orderLineItemId) + " after setFill with status:CANCELLED");

            responseData = Tuples.of(fill_Id, Integer.valueOf(rx_id));
        }

        return responseData;
    }

    /**
     * Validates setFillInfo for multiple delay reasons.
     * Handles both SUBMITTED and CANCELLED scenarios based on problem codes.
     */
    public void validateSetFillInfoForDelayReasons(int storeNbr, FillingGetFillInfoResponse getFillInfoResponse, 
                                                    List<Integer> problemCodeStatusList) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        String ts = sdf.format(new Timestamp(System.currentTimeMillis()));

        Map<Integer, String> nxtWrkQueCodenText = new HashMap<>();
        nxtWrkQueCodenText.put(7, "Resolution");
        nxtWrkQueCodenText.put(4, "Filling");
        nxtWrkQueCodenText.put(10, "VisualVerify");

        int NumOfRx = getFillInfoResponse.getFillWork().getItemDetails().size();
        int problemCodes = problemCodeStatusList.size();
        am.performSleep(60);

        Assert.assertEquals(NumOfRx, problemCodes, "Number of Problem codes Passed is not equal to No of drugs passed");

        for (int i = 0; i < getFillInfoResponse.getFillWork().getItemDetails().size(); i++) {
            ArrayList<FillingOrderLineInfoContents> orderLineInfoList = new ArrayList<>();
            ArrayList<FillingSetFillItemContents> fillItemList = new ArrayList<>();

            int fill_Id = (int) getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getRxFillId();
            String orderLineItemId = getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getOrderLineItemId();
            int on_hand_qty_BeforeSetFill = getFillInfoResponse.getFillWork().getItemDetails().get(i).getOnHandQty();
            int mds_fam_id = getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getFilItem().get(0).getItemMdsFamId();
            int fillItemQty = getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getFilItem().get(0).getFillItemQty();
            int order_id = Integer.parseInt(getFillInfoResponse.getOrderId());

            Reporter.log("on_hand_qty for mds_fam_id:" + mds_fam_id + " before setFill for fill_Id:" + fill_Id + " is " + on_hand_qty_BeforeSetFill);

            FillingOrderLineInfoContents orderLineInfo = new FillingOrderLineInfoContents();
            orderLineInfo.setRxId(getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getRxId());
            orderLineInfo.setRxFillId(String.valueOf(fill_Id));
            orderLineInfo.setFomId(null);
            orderLineInfo.setLabelId(null);
            orderLineInfo.setOrderLineItemId(getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getOrderLineItemId());
            orderLineInfo.setPatientId(getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getPatientId());
            orderLineInfo.setFillSeqNbr(1);
            orderLineInfo.setFillType(getFillInfoResponse.getFillWork().getOrderLineItem().get(i).getFillType());

            FillingSetFillItemContents fillItemContents = buildFillItemContents(getFillInfoResponse, i);
            fillItemList.add(fillItemContents);
            orderLineInfo.setFillItem(fillItemList);
            orderLineInfo.setWorkId(null);
            orderLineInfo.setFillingStartTs(ts);
            orderLineInfo.setFillingCompleteTs(ts);

            int wrkQueExpectedAftrSetFill;
            int on_hand_qty_AftrSetFill;

            // 200 = no problem (SUBMITTED), otherwise = CANCELLED
            if (problemCodeStatusList.get(i) == 200) {
                orderLineInfo.setFillWorkStatus("SUBMITTED");
                orderLineInfo.setProblem(null);
                orderLineInfo.setModifiedFillItem(null);
                orderLineInfo.setRtsVialItemsUsed(null);
                wrkQueExpectedAftrSetFill = 10;
                on_hand_qty_AftrSetFill = on_hand_qty_BeforeSetFill - fillItemQty;
            } else {
                orderLineInfo.setFillWorkStatus("CANCELLED");
                FillingProblemContents problemContents = new FillingProblemContents();
                problemContents.setProblemCode(problemCodeStatusList.get(i));
                problemContents.setDispensedNdc(getFillInfoResponse.getFillWork().getItemDetails().get(i).getNdcNbr());
                problemContents.setRequestedNdc(prop.getProperty("fom.setRequestedNdc"));
                orderLineInfo.setProblem(problemContents);
                orderLineInfo.setRtsVialItemsUsed(null);
                wrkQueExpectedAftrSetFill = 7;
                on_hand_qty_AftrSetFill = on_hand_qty_BeforeSetFill;
            }

            orderLineInfoList.add(orderLineInfo);
            int bagNbr = getFillInfoResponse.getFillWork().getOrderLineItem().get(0).getBagInfo().getBagNbr();

            am.performSleep(30);
            ServiceResponse setFillInforesp = setFillInfo(
                    getFillInfoResponse.getOrderId(),
                    getFillInfoResponse.getStoreNbr(),
                    prop.getProperty("fom.setDeviceName"),
                    getFillInfoResponse.getUserId(),
                    bagNbr,
                    prop.getProperty("fom.setlabelMac"),
                    prop.getProperty("fom.reprintInd"),
                    orderLineInfoList);

            Assert.assertEquals(setFillInforesp.getStatusCode(), 200, "SetFillInfo Saps service response did not match");
            Reporter.log("setFillInfo API is logged with status code: 200");
            am.performSleep(30);

            if (problemCodeStatusList.get(i) == 200) {
                int nxt_wrk_que = dbUtils.getNextWorkQueCode(storeNbr, fill_Id);
                Log.info("Next work queue code code:" + nxt_wrk_que);
                Assert.assertEquals(nxt_wrk_que, wrkQueExpectedAftrSetFill, "Fill:" + fill_Id + " is not in expected work_que after SetFill");
                Reporter.log("Fill:" + fill_Id + " is in " + nxtWrkQueCodenText.get(nxt_wrk_que) + " after setFill with status: SUBMITTED");
            } else {
                int prblm_CodeTransactionInDB = dbUtils.getProblemCode(storeNbr, problemCodeStatusList.get(i), order_id);
                Log.info("problem transaction code:" + prblm_CodeTransactionInDB);
                Assert.assertEquals(prblm_CodeTransactionInDB, i, 
                        "problem code:" + problemCodeStatusList.get(i) + " is not logged in rx_ord_dtl_problem for order_id:" 
                        + order_id + " and order_seq_nbr:" + orderLineItemId + " after setFill with status: CANCELLED");
                Reporter.log("problem_code:" + problemCodeStatusList.get(i) + " is logged in rx_ord_dtl_problem for order_id:" 
                        + order_id + " and order_seq_nbr:" + orderLineItemId + " after setFill with status: CANCELLED");

                int nxt_wrk_que = dbUtils.getNextWorkQueCode(storeNbr, fill_Id);
                Log.info("Next work queue code code:" + nxt_wrk_que);
                Assert.assertEquals(nxt_wrk_que, wrkQueExpectedAftrSetFill, "Fill:" + fill_Id + " is not in expected work_que after SetFill");
                Reporter.log("Fill:" + fill_Id + " is in " + nxtWrkQueCodenText.get(nxt_wrk_que) + " after setFill with status: CANCELLED");
            }
        }
    }

    // ========== Helper Methods ==========

    /**
     * Builds order line info from fill response.
     */
    private FillingOrderLineInfoContents buildOrderLineInfo(FillingGetFillInfoResponse response, int index, int fillId, String ts) {
        FillingOrderLineInfoContents orderLineInfo = new FillingOrderLineInfoContents();
        orderLineInfo.setRxId(response.getFillWork().getOrderLineItem().get(index).getRxId());
        orderLineInfo.setRxFillId(String.valueOf(fillId));
        orderLineInfo.setFomId(null);
        orderLineInfo.setLabelId(null);
        orderLineInfo.setFillWorkStatus(prop.getProperty("fom.setFillStatusInRequest"));
        orderLineInfo.setOrderLineItemId(response.getFillWork().getOrderLineItem().get(index).getOrderLineItemId());
        orderLineInfo.setPatientId(response.getFillWork().getOrderLineItem().get(index).getPatientId());
        orderLineInfo.setFillSeqNbr(response.getFillWork().getOrderLineItem().get(index).getFillSeqNbr());
        orderLineInfo.setFillType(response.getFillWork().getOrderLineItem().get(index).getFillType());
        orderLineInfo.setWorkId(null);
        orderLineInfo.setFillingStartTs(ts);
        orderLineInfo.setFillingCompleteTs(ts);
        orderLineInfo.setProblem(null);
        orderLineInfo.setModifiedFillItem(null);
        orderLineInfo.setRtsVialItemsUsed(null);
        return orderLineInfo;
    }

    /**
     * Builds fill item contents from fill response.
     */
    private FillingSetFillItemContents buildFillItemContents(FillingGetFillInfoResponse response, int index) {
        FillingSetFillItemContents fillItemContents = new FillingSetFillItemContents();
        fillItemContents.setItemMdsFamId(response.getFillWork().getOrderLineItem().get(index).getFilItem().get(0).getItemMdsFamId());
        fillItemContents.setFillItemQty(response.getFillWork().getOrderLineItem().get(index).getFilItem().get(0).getFillItemQty());
        fillItemContents.setItemSeqNbr(response.getFillWork().getOrderLineItem().get(index).getFilItem().get(0).getItemSeqNbr());
        return fillItemContents;
    }
}
