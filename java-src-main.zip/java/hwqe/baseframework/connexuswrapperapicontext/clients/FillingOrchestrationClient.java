package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.WorkQueueCode;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;

/**
 * Client for orchestrating order workflows that stop at Filling queue.
 *
 * Handles workflows from drop-off to the Filling queue state:
 * DropOff → InputAccept → DUR → Filling (STOP)
 *
 * Unlike PickupOrchestrationClient which continues to VV and Pickup,
 * this stops at the Filling queue for testing fill operations.
 *
 * Thread-safe: Uses method-local variables.
 *
 * Extracted from OrderOrchestrationClient for Single Responsibility Principle.
 */
public class FillingOrchestrationClient {

    private static final String ERROR_KEYWORD = "error";
    private static final String DOWNTIME_LOG_SUFFIX = ") — performing downtime";

    private final AutomationManager am;
    private final PropertyReader prop;
    private final WrapperUtils wrapperUtils;
    private final DBUtils dbUtils;
    private final OrderWorkflowClient workflowClient;
    private final OrderCreationClient orderCreationClient;
    private final DowntimeClient downtimeClient;
    private final DrugInfoClient drugInfoClient;

    public FillingOrchestrationClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.wrapperUtils = new WrapperUtils();
        this.dbUtils = new DBUtils();
        this.workflowClient = new OrderWorkflowClient();
        this.orderCreationClient = new OrderCreationClient();
        this.downtimeClient = new DowntimeClient();
        this.drugInfoClient = new DrugInfoClient();
    }

    /**
     * Creates a new order and moves it to Filling queue (without fill quantity).
     */
    public InputResponse createNewOrderAndMoveToFilling(int patientId, int siteId,
                                                        int numRefills, DataRow drugInfo, String ndc) {
        return createNewOrderAndMoveToFilling(0, patientId, siteId, numRefills, drugInfo, ndc);
    }

    /**
     * Creates a new order with specific fill quantity and moves it to Filling queue.
     *
     * Workflow:
     *   DropOff → InputAccept → [4-Point?] → [CHKDUR?] → Filling
     *
     * After InputAccept the queue can land on:
     *   - FOURPOINT (5) → complete 4-point, then re-check for CHKDUR or FILLING
     *   - CHKDUR   (12) → complete DUR directly
     *   - FILLING   (4) → already there, nothing more to do
     *
     * Downtime is applied whenever the queue is not in an expected state between steps.
     */
    public InputResponse createNewOrderAndMoveToFilling(int fillQuantity, int patientId,
                                                        int siteId, int numRefills, DataRow drugInfo, String ndc) {

        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(siteId);
        drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        int requestTypeCode = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrderPriorityId"));
        int dispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));

        // ── Step 1: Drop-Off ────────────────────────────────────────────────────
        ServiceResponse dropOffResp = orderCreationClient.createOrderAndDropOff(
                fillQuantity, requestTypeCode, priorityId, dispenseType, patientId, siteId,
                inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201,
                "createOrderAndDropOff API response status code did not match");

        // ── Step 2: Input Accept  ──
        ServiceResponse inputAcceptResp = workflowClient.inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302,
                "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains(ERROR_KEYWORD),
                "Input Accept could not be completed");
        InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        logOrderDetails(inputResp);

        // ── Step 3: Check queue after InputAccept ────────────────────────────────
        int nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        Reporter.log("Queue after InputAccept: " + nxtWrkQueCode);

        // Track the latest response to chain into the next step
        ServiceResponse latestResp = inputAcceptResp;

        // ── Step 4: 4-Point (if landed on FOURPOINT queue) ───────────────────────
        if (nxtWrkQueCode == WorkQueueCode.FOURPOINT.getWorkQueueCode()) {
            Reporter.log("Order is in 4-Point queue — completing FourPointCheck");
            ServiceResponse fourPointResp = workflowClient.fourPointCheck(latestResp.getDataResponse());
            Assert.assertEquals(fourPointResp.getStatusCode(), 302,
                    "FourPointCheck API response status code did not match");
            Assert.assertFalse(fourPointResp.getDataResponse().contains(ERROR_KEYWORD),
                    "Four Point Check could not be completed");
            latestResp = fourPointResp;

            // Re-check queue — after 4-point can go to CHKDUR or directly to FILLING
            InputResponse fourPointInputResp = fourPointResp.getDataResponse(InputResponse.class);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, fourPointInputResp.getRxFillId());
            Reporter.log("Queue after FourPointCheck: " + nxtWrkQueCode);

            // Downtime if not in CHKDUR or FILLING after 4-point
            if (nxtWrkQueCode != WorkQueueCode.CHKDUR.getWorkQueueCode()
                    && nxtWrkQueCode != WorkQueueCode.FILLING.getWorkQueueCode()) {
                Reporter.log("Unexpected queue after FourPointCheck (" + nxtWrkQueCode + DOWNTIME_LOG_SUFFIX);
                performDowntime(siteId, fourPointInputResp);
                nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, fourPointInputResp.getRxFillId());
                Reporter.log("Queue after downtime (post-FourPoint): " + nxtWrkQueCode);
            }

        } else if (nxtWrkQueCode != WorkQueueCode.CHKDUR.getWorkQueueCode()
                && nxtWrkQueCode != WorkQueueCode.FILLING.getWorkQueueCode()) {
            // Unexpected queue after InputAccept — apply downtime to unblock
            Reporter.log("Unexpected queue after InputAccept (" + nxtWrkQueCode + DOWNTIME_LOG_SUFFIX);
            performDowntime(siteId, inputResp);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
            Reporter.log("Queue after downtime (post-InputAccept): " + nxtWrkQueCode);
        }

        // ── Step 5: CHKDUR (if not already in FILLING) ──────────────────────────
        if (nxtWrkQueCode == WorkQueueCode.CHKDUR.getWorkQueueCode()) {
            Reporter.log("Order is in CHKDUR queue — completing CheckDUR");
            ServiceResponse chkDURCompleteResp = workflowClient.chkDURComplete(latestResp.getDataResponse());
            Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302,
                    "CheckDURComplete API response status code did not match");
            Assert.assertFalse(chkDURCompleteResp.getDataResponse().contains(ERROR_KEYWORD),
                    "Check DUR could not be completed");
            latestResp = chkDURCompleteResp;

            InputResponse checkDURInputResp = chkDURCompleteResp.getDataResponse(InputResponse.class);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, checkDURInputResp.getRxFillId());
            Reporter.log("Queue after CheckDUR: " + nxtWrkQueCode);

            // Downtime if not in FILLING after DUR
            if (nxtWrkQueCode != WorkQueueCode.FILLING.getWorkQueueCode()) {
                Reporter.log("Unexpected queue after CheckDUR (" + nxtWrkQueCode + DOWNTIME_LOG_SUFFIX);
                performDowntime(siteId, checkDURInputResp);
                nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, checkDURInputResp.getRxFillId());
                Reporter.log("Queue after downtime (post-CheckDUR): " + nxtWrkQueCode);
            }
        } else if (nxtWrkQueCode == WorkQueueCode.FILLING.getWorkQueueCode()) {
            Reporter.log("Order moved directly to Filling queue — skipping CHKDUR");
        } else {
            Assert.fail("Order is in unexpected queue (" + nxtWrkQueCode
                    + ") after all steps — cannot proceed to Filling");
        }

        Reporter.log("Order successfully moved to Filling queue");
        return latestResp.getDataResponse(InputResponse.class);
    }

    // ========== Helper Methods ==========

    private void logOrderDetails(InputResponse inputResp) {
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() +
                ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());
    }

    private void performDowntime(int siteId, InputResponse respObj) {
        downtimeClient.downTime(respObj.getRxFillId(), respObj.getOrderId(), respObj.getOrderSeqNbr(),
                prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
    }
}