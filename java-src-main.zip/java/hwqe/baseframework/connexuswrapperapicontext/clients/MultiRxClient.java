package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.MultiOrderInput;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.OrderInput;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.DropOffConstants;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.connexuscontext.WorkQueueCode;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.json.JSONArray;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Client for Multi-Rx (multiple prescription) operations.
 * 
 * Handles:
 * - Creating multi-drug orders to filling queue
 * - Multi-drug order to ready for pickup
 * - Multi-Rx API calls
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class MultiRxClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final WrapperUtils wrapperUtils;
    private final DBUtils dbUtils;
    private final OrderWorkflowClient orderWorkflowClient;
    private final DowntimeClient downtimeClient;

    public MultiRxClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.wrapperUtils = new WrapperUtils();
        this.dbUtils = new DBUtils();
        this.orderWorkflowClient = new OrderWorkflowClient();
        this.downtimeClient = new DowntimeClient();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public MultiRxClient(AutomationManager am, PropertyReader prop) {
        this.am = am;
        this.prop = prop;
        this.wrapperUtils = new WrapperUtils();
        this.dbUtils = new DBUtils();
        this.orderWorkflowClient = new OrderWorkflowClient();
        this.downtimeClient = new DowntimeClient();
    }

    // ========== Multi-Rx to Filling ==========

    /**
     * Creates a new multi-drug order and moves it to filling queue.
     * 
     * @param siteId Store number
     * @param patientID Patient ID
     * @param priorityId Priority ID
     * @param ndcList List of NDC codes
     * @return ServiceResponse from the API call
     */
    public ServiceResponse newMultiRxOrderToFilling(String siteId, String patientID, String priorityId, List<String> ndcList) {
        Order order = buildMultiRxOrder(siteId, patientID, priorityId);
        List<Drug> drugList = fetchDrugList(siteId, ndcList);

        MultiRxDropOffQueueRequest multiRxRequest = new MultiRxDropOffQueueRequest();
        multiRxRequest.setOrder(order);
        multiRxRequest.setDrugList(drugList);

        ServiceResponse moveToFill = multiRxToFillingAPICall(multiRxRequest);
        Assert.assertEquals(moveToFill.getStatusCode(), 201, "newMultiRxOrderToFilling API response status code did not match");

        return moveToFill;
    }

    /**
     * Creates a new multi-drug order with specified fill quantity.
     * 
     * @param siteId Store number
     * @param patientID Patient ID
     * @param priorityId Priority ID
     * @param ndcList List of NDC codes
     * @param fillQty Fill quantity for all drugs
     * @return ServiceResponse from the API call
     */
    public ServiceResponse newMultiRxOrderToFillingWithFillQty(String siteId, String patientID, String priorityId, List<String> ndcList, int fillQty) {
        Order order = buildMultiRxOrder(siteId, patientID, priorityId);
        List<Drug> drugList = fetchDrugListWithQty(siteId, ndcList, fillQty);

        MultiRxDropOffQueueRequest multiRxRequest = new MultiRxDropOffQueueRequest();
        multiRxRequest.setOrder(order);
        multiRxRequest.setDrugList(drugList);

        ServiceResponse moveToFill = multiRxToFillingAPICall(multiRxRequest);
        Assert.assertEquals(moveToFill.getStatusCode(), 201, "newMultiRxOrderToFilling API response status code did not match");

        return moveToFill;
    }

    // ========== Multi-Rx API Calls ==========

    /**
     * Handles the API call to move multi-Rx order to filling queue.
     * 
     * @param requestPayload The multi-rx request payload
     * @return ServiceResponse from the API call
     */
    public ServiceResponse multiRxToFillingAPICall(MultiRxDropOffQueueRequest requestPayload) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");

        req.setRequestPayloadWithNulls(requestPayload);
        req.setUrl(prop.getProperty("fom.connexusWrapper.newMultiDrugOrderToFilling"));
        req.setHeaders(headers);

        Reporter.log("NewMultiDrugOrderToFilling Request endpoint: " + req.getUrl());
        Reporter.logJSON("NewMultiDrugOrderToFilling Request", requestPayload);

        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("NewMultiDrugOrderToFilling Response", resp.getDataResponse());

        return resp;
    }

    // ========== Multi-Drug Order to Ready For Pickup ==========

    /**
     * Creates a multi-drug order to ready for pickup.
     * 
     * @param order Order details
     * @param drugInfo List of drug info DataRows
     * @param prescriber Prescriber info
     * @return JSONArray response
     */
    public JSONArray newMultiDrugOrderToReadyForPickUp(Order order, List<DataRow> drugInfo, Prescriber prescriber) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");

        order.setPrescriber(prescriber);

        ArrayList<Drug> drugList = new ArrayList<>();
        for (int i = 0; i < drugInfo.size(); i++) {
            Drug drug = buildDrugFromDataRowFull(drugInfo.get(i));
            drugList.add(drug);
        }

        MultiRxDropOffQueueRequest multiRxRequest = new MultiRxDropOffQueueRequest();
        multiRxRequest.setDrugList(drugList);
        multiRxRequest.setOrder(order);

        req.setRequestPayloadWithNulls(multiRxRequest);
        req.setUrl(prop.getProperty("fom.connexusWrapper.newMultiDrugOrderToReadyForPickUpUrl"));
        req.setHeaders(headers);

        Log.info("MultiOrderTillPickup Request endpoint\n " + req.getUrl());
        Reporter.log("MultiOrderTillPickup Request endpoint: " + req.getUrl());
        Reporter.logJSON("MultiOrderTillPickup Request", multiRxRequest);
        Log.info("MultiOrderTillPickup Request\n " + req.getRequestPayload());

        ServiceResponse resp = am.getRestContext().performPost(req);

        Reporter.logJSON("MultiOrderTillPickup Response", resp.getDataResponse());
        JSONArray response = new JSONArray(resp.getDataResponse());
        Log.info("MultiOrderTillPickup Response\n " + response);
        Reporter.logJSON("MultiOrderTillPickup Response - JSONArray", response);
        Assert.assertEquals(resp.getStatusCode(), 201, "createMultiOrderTillPickup API response status code did not match");

        return response;
    }

    // ========== Multi-Order Creation ==========

    /**
     * Creates a multi-drug order and performs drop-off.
     * 
     * @param order Order details
     * @param drugInfo List of drug info DataRows
     * @param prescriber Prescriber info (currently unused)
     * @return ServiceResponse from the API call
     */
    public ServiceResponse createMultiOrderAndDropOff(Order order, List<DataRow> drugInfo, Prescriber prescriber) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");

        MultiRxDropOffQueueRequest multiRxRequest = new MultiRxDropOffQueueRequest();
        
        ArrayList<Drug> drugList = new ArrayList<>();
        for (int i = 0; i < drugInfo.size(); i++) {
            Drug drug = buildDrugFromDataRowFull(drugInfo.get(i));
            drugList.add(drug);
        }
        
        multiRxRequest.setDrugList(drugList);
        multiRxRequest.setOrder(order);

        req.setRequestPayloadWithNulls(multiRxRequest);
        req.setUrl(prop.getProperty("fom.connexusWrapper.createMultiRxOrderAndDropOffUrl"));
        req.setHeaders(headers);

        Reporter.log("CreateMultiOrderAndDropOff Request endpoint: " + req.getUrl());
        Reporter.logJSON("CreateMultiOrderAndDropOff Request", multiRxRequest);

        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("CreateMultiOrderAndDropOff Response", resp.getDataResponse());

        return resp;
    }

    // ========== Helper Methods ==========

    /**
     * Builds the base Order object for multi-rx requests.
     */
    private Order buildMultiRxOrder(String siteId, String patientID, String priorityId) {
        Order order = new Order();
        order.setRequestTypeCode(DropOffConstants.REQUEST_TYPE_CODE);
        order.setPriorityId(Integer.parseInt(priorityId));
        order.setDispenseType(DropOffConstants.DISPENSE_TYPE);
        order.setPatientId(Integer.parseInt(patientID));
        order.setSiteID(Integer.parseInt(siteId));
        order.setInputPickUpDate(DropOffConstants.getPickupDate());
        order.setInputRxExpDate(DropOffConstants.getExpiryDate());
        order.setNumRefills(DropOffConstants.NUM_REFILLS);
        return order;
    }

    /**
     * Builds Drug object from DataRow with full attributes.
     */
    private Drug buildDrugFromDataRowFull(DataRow drugInfo) {
        Drug drug = new Drug();
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr").toString().trim());
        drug.setItemId(Integer.parseInt(drugInfo.getValue("mds_fam_id").toString().trim()));
        drug.setRxProdId(Integer.parseInt(drugInfo.getValue("product_mds_fam_id").toString().trim()));
        drug.setControlCode(Short.parseShort(drugInfo.getValue("drug_control_code").toString().trim()));
        drug.setPresMultiSrcCode(Short.parseShort(drugInfo.getValue("multi_source_code").toString().trim()));
        drug.setOnHandQty(Integer.parseInt(drugInfo.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
        drug.setGpiCode(drugInfo.getValue("gpi_code").toString().trim());
        drug.setUsualCost("0");
        drug.setActCost("0");
        drug.setOrgUsualCost("0");
        return drug;
    }

    /**
     * Fetches drug info for a list of NDCs.
     */
    private List<Drug> fetchDrugList(String siteId, List<String> ndcList) {
        List<Drug> drugList = new ArrayList<>();
        for (String ndc : ndcList) {
            FetchDrug drugPayload = new FetchDrug();
            drugPayload.setSiteId(siteId);
            drugPayload.setNdc(ndc);
            drugList.add(fetchDrugInfo(drugPayload));
        }
        return drugList;
    }

    /**
     * Fetches drug info for a list of NDCs with specified fill quantity.
     */
    private List<Drug> fetchDrugListWithQty(String siteId, List<String> ndcList, int fillQty) {
        List<Drug> drugList = new ArrayList<>();
        for (String ndc : ndcList) {
            FetchDrug drugPayload = new FetchDrug();
            drugPayload.setSiteId(siteId);
            drugPayload.setNdc(ndc);
            Drug drugInfo = fetchDrugInfo(drugPayload);
            drugInfo.setFillQty(fillQty);
            drugList.add(drugInfo);
        }
        return drugList;
    }

    /**
     * Fetches drug info from the API.
     */
    private Drug fetchDrugInfo(FetchDrug drugPayload) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");

        req.setUrl(prop.getProperty("fom.connexusWrapper.fetchDrugUrl"));
        req.setHeaders(headers);
        req.setRequestPayloadWithNulls(drugPayload);

        Reporter.log("FetchDrug Request endpoint: " + req.getUrl());
        Reporter.logJSON("FetchDrug Request", drugPayload);

        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("FetchDrug Response", resp.getDataResponse());

        return resp.getDataResponse(Drug.class);
    }

    // ========== Multi-Rx Workflow Methods ==========

    /**
     * Creates multi-Rx and moves to pickup.
     * Full implementation extracted from ConnexusAPIManager.
     */
    public List<InputResponse> createMultiRxAndMoveToPickup(int patientId, int siteId, int numRefills, 
            List<String> ndcList, Prescriber prescriberObject) {
        List<InputResponse> multiRxVVCompleteResp = new ArrayList<>();
        InputResponse fillCompleteInputResp;
        Order order = new Order();
        order.setPrescriber(prescriberObject);

        // Get pickup date as tomorrow's date of the current year
        String inputPickupDate = wrapperUtils.getPickUpDate();
        // Get expiry date based on year
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        // Connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);

        // Get multi drug details
        List<DataRow> NDCData = new ArrayList<>();
        for (String ndc : ndcList) {
            List<DataRow> rows = dbUtils.getMultiDrugInfo(cnx, ndc);
            NDCData.addAll(rows);
        }

        // Setting order object
        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(prop.getProperty("fom.OrderPriorityId")));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);
        order.setNumRefills(numRefills);
        order.setPatientId(patientId);
        order.setSiteID(siteId);

        // Create multiRx and drop-off
        ServiceResponse dropOffResp = createMultiOrderAndDropOff(order, NDCData, prescriberObject);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createMultiRxAndDropOff API response status code did not match");

        MultiOrderInput multiOrderInput = dropOffResp.getDataResponse(MultiOrderInput.class);
        int drugListSize = multiOrderInput.getDrugList().size();
        OrderInput orderInput = new OrderInput();
        
        for (int i = 0; i < drugListSize; i++) {
            orderInput.setOrder(multiOrderInput.getOrder());
            orderInput.setDrug(multiOrderInput.getDrugList().get(i));

            String input = wrapperUtils.buildInputOrder(orderInput, siteId, prescriberObject);

            // Completes input accept and 4point check
            ServiceResponse inputAcceptResp = orderWorkflowClient.inputAccept(input);
            Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
            Assert.assertEquals(inputAcceptResp.getDataResponse().contains("error"), false, "Input Accept could not be completed");
            InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
            Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());
            
            // Induce wait to allow CASH/TP processing
            am.performSleep(30);

            int nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
            ServiceResponse fillCompleteResp;
            
            if (nxtWrkQueCode == WorkQueueCode.CHKDUR.getWorkQueueCode()) {
                // Complete check DUR
                ServiceResponse chkDURCompleteResp = orderWorkflowClient.chkDURComplete(inputAcceptResp.getDataResponse());
                Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
                Assert.assertEquals(chkDURCompleteResp.getDataResponse().contains("error"), false, "Check DUR could not be completed");

                // Induce wait to allow CASH/TP processing
                am.performSleep(30);
                nxtWrkQueCode = WorkQueueCode.FILLING.getWorkQueueCode();

                // Completes fillcomplete
                fillCompleteResp = orderWorkflowClient.fillComplete(chkDURCompleteResp.getDataResponse());
                Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
                Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Filling could not be completed");
                fillCompleteInputResp = fillCompleteResp.getDataResponse(InputResponse.class);
                am.performSleep(5);

                if (nxtWrkQueCode == WorkQueueCode.VISUALVERIFY.getWorkQueueCode()) {
                    downtimeClient.downTime(fillCompleteInputResp.getRxFillId(), fillCompleteInputResp.getOrderId(), fillCompleteInputResp.getOrderSeqNbr(),
                            prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
                    nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, fillCompleteInputResp.getRxFillId());
                }
            } else if (nxtWrkQueCode == WorkQueueCode.FILLING.getWorkQueueCode()) {
                fillCompleteResp = orderWorkflowClient.fillComplete(inputAcceptResp.getDataResponse());
                Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
                Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Filling could not be completed");
                fillCompleteInputResp = fillCompleteResp.getDataResponse(InputResponse.class);

                // Induce wait to allow CASH/TP processing
                am.performSleep(5);

                if (nxtWrkQueCode != WorkQueueCode.RESOLVE.getWorkQueueCode()) {
                    downtimeClient.downTime(fillCompleteInputResp.getRxFillId(), fillCompleteInputResp.getOrderId(), fillCompleteInputResp.getOrderSeqNbr(),
                            prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
                    nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, fillCompleteInputResp.getRxFillId());
                }
                if (nxtWrkQueCode != WorkQueueCode.VISUALVERIFY.getWorkQueueCode()) {
                    downtimeClient.downTime(fillCompleteInputResp.getRxFillId(), fillCompleteInputResp.getOrderId(), fillCompleteInputResp.getOrderSeqNbr(),
                            prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
                    nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, fillCompleteInputResp.getRxFillId());
                }
            } else {
                // Default case - try fill complete with input accept response
                fillCompleteResp = orderWorkflowClient.fillComplete(inputAcceptResp.getDataResponse());
            }
            
            // Completes VVComplete
            ServiceResponse vvCompleteResp = orderWorkflowClient.vvComplete(fillCompleteResp.getDataResponse());
            Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "vvComplete API response status code did not match");
            Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");
            multiRxVVCompleteResp.add(vvCompleteResp.getDataResponse(InputResponse.class));
            Reporter.log("Order successfully moved to Pickup queue");
        }
        return multiRxVVCompleteResp;
    }

    /**
     * Multi-Rx filling to EOD.
     * Full implementation extracted from ConnexusAPIManager.
     */
    public List<InputResponse> multiRxFillingToEOD(int patientId, int orderId, int siteId,
            List<Integer> rxFillId, List<Integer> rxId, int numRefills,
            List<String> ndcList, List<Integer> rxNbr) {
        List<InputResponse> multiRxPaymentCompleteResp = new ArrayList<>();
        Order order = new Order();
        Map<String, Object> rxOrderDetails;
        Drug drug = new Drug();
        
        // Get pickup date as tomorrow's date of the current year
        String inputPickupDate = wrapperUtils.getPickUpDate();
        // Get expiry date based on year
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        // Connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);

        // Get multi drug details
        List<DataRow> NDCData = new ArrayList<>();
        for (String ndc : ndcList) {
            List<DataRow> rows = dbUtils.getMultiDrugInfo(cnx, ndc);
            NDCData.addAll(rows);
        }

        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(prop.getProperty("fom.OrderPriorityId")));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);
        order.setNumRefills(numRefills);
        order.setPatientId(patientId);
        order.setSiteID(siteId);
        order.setOrderId(orderId);
        
        for (int i = 0; i < NDCData.size(); i++) {
            rxOrderDetails = dbUtils.getRxOrderDetailTableInfo(siteId, rxFillId.get(i));
            // Setting order object
            order.setRxFillId(rxFillId.get(i));
            order.setRxId(rxId.get(i));
            order.setRxNbr(rxNbr.get(i));
            order.setOrderSeqNbr(Integer.parseInt(rxOrderDetails.get("order_seq_nbr").toString()));
            drug.setName(NDCData.get(i).getValue("short_name").toString().trim());
            drug.setNdc(NDCData.get(i).getValue("ndc_nbr").toString().trim());
            drug.setItemId(Integer.parseInt(NDCData.get(i).getValue("mds_fam_id").toString().trim()));
            drug.setRxProdId(Integer.parseInt(NDCData.get(i).getValue("product_mds_fam_id").toString().trim()));
            drug.setControlCode(Short.parseShort(NDCData.get(i).getValue("drug_control_code").toString().trim()));
            drug.setPresMultiSrcCode(Short.parseShort(NDCData.get(i).getValue("multi_source_code").toString().trim()));
            drug.setOnHandQty(Integer.parseInt(NDCData.get(i).getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
            drug.setGpiCode(NDCData.get(i).getValue("gpi_code").toString().trim());
            drug.setUsualCost("0");
            drug.setActCost("0");
            drug.setOrgUsualCost("0");
            order.setDrug(drug);

            am.performSleep(30);
            int nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId.get(i));
            if (nxtWrkQueCode == WorkQueueCode.RESOLVE.getWorkQueueCode()) {
                downtimeClient.downTime(rxFillId.get(i), orderId, order.getOrderSeqNbr(), prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
            }

            // Verify nxtWrkQueCode
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId.get(i));
            Assert.assertEquals(nxtWrkQueCode, WorkQueueCode.FILLING.getWorkQueueCode(), "Order is not in Filling queue");

            // FillComplete via direct API call
            ServiceRequest fillReq = new ServiceRequest();
            HashMap<String, String> headers = new HashMap<>();
            fillReq.setRequestPayloadWithNulls(order);
            fillReq.setUrl(prop.getProperty("fom.connexusWrapper.fillCompleteUrl"));
            headers.put("content-type", "application/json");
            fillReq.setHeaders(headers);
            Reporter.logJSON("Filling complete Request", fillReq.getRequestPayload());
            Log.info("FillInfo Request Payload:\n" + fillReq.getRequestPayload());
            ServiceResponse fillCompleteResp = am.getRestContext().performPost(fillReq);
            am.performSleep(10);
            Reporter.logJSON("Filling complete Response", fillCompleteResp.getDataResponse());
            Log.info("fillcomplete Response:" + "\n" + fillCompleteResp.getDataResponse());
            Log.info("fill complete status code:" + fillCompleteResp.getStatusCode());
            Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
            Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Fill Complete could not be completed");
            am.performSleep(5);
            
            // Complete VV
            ServiceResponse vvCompleteResp = orderWorkflowClient.vvComplete(fillCompleteResp.getDataResponse());
            Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "VVComplete API response status code did not match");
            Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");
            am.performSleep(5);
            
            // Completes PickUp
            ServiceResponse pickupCompleteResp = orderWorkflowClient.pickupComplete(vvCompleteResp.getDataResponse());
            Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "pickUpComplete API response status code did not match");
            Assert.assertFalse(pickupCompleteResp.getDataResponse().contains("error"), "pickUp could not be completed");
            am.performSleep(5);

            ServiceResponse posCompleteResp;
            // Verify nxtWrkQueCode and perform Counsel and POS
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId.get(i));
            if (nxtWrkQueCode == WorkQueueCode.COUNSEL.getWorkQueueCode()) {
                // Complete counsel
                ServiceResponse counselCompleteResp = orderWorkflowClient.counselComplete(pickupCompleteResp.getDataResponse());
                Assert.assertEquals(counselCompleteResp.getStatusCode(), 302, "counsel API response status code did not match");
                Assert.assertFalse(counselCompleteResp.getDataResponse().contains("error"), "counsel could not be completed");
                am.performSleep(5);
                // Completes Payment
                nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId.get(i));
                if (nxtWrkQueCode == WorkQueueCode.RESOLVE.getWorkQueueCode()) {
                    downtimeClient.downTime(rxFillId.get(i), orderId, order.getOrderSeqNbr(), prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
                }
                posCompleteResp = orderWorkflowClient.posComplete(counselCompleteResp.getDataResponse());
                Assert.assertEquals(counselCompleteResp.getStatusCode(), 302, "POS API response status code did not match");
                Assert.assertFalse(counselCompleteResp.getDataResponse().contains("error"), "POS could not be completed");
            } else if (nxtWrkQueCode == WorkQueueCode.POS.getWorkQueueCode()) {
                am.performSleep(5);
                // Completes Payment
                nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId.get(i));
                if (nxtWrkQueCode == WorkQueueCode.RESOLVE.getWorkQueueCode()) {
                    downtimeClient.downTime(rxFillId.get(i), orderId, order.getOrderSeqNbr(), prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
                }
                posCompleteResp = orderWorkflowClient.posComplete(pickupCompleteResp.getDataResponse());
                Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "POS API response status code did not match");
                Assert.assertFalse(pickupCompleteResp.getDataResponse().contains("error"), "POS could not be completed");
            } else {
                // Default - try POS from pickup
                posCompleteResp = orderWorkflowClient.posComplete(pickupCompleteResp.getDataResponse());
            }
            multiRxPaymentCompleteResp.add(posCompleteResp.getDataResponse(InputResponse.class));
            am.performSleep(15);
            Log.info("PaymentComplete ResponsePayload:\n" + posCompleteResp.getDataResponse() + "\n");
        }
        return multiRxPaymentCompleteResp;
    }
}
