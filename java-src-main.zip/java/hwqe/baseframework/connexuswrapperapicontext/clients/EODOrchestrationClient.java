package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.WorkQueueCode;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;

import java.util.List;

/**
 * Client for orchestrating complete order workflows that end at End-of-Day (EOD).
 * 
 * Handles the full pharmacy workflow from drop-off through POS completion:
 * DropOff → InputAccept → DUR → Fill → VV → Pickup → Counsel → POS
 * 
 * This is a focused subset extracted from OrderOrchestrationClient.
 * 
 * Thread-safe: Uses method-local variables.
 */
public class EODOrchestrationClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final WrapperUtils wrapperUtils;
    private final DBUtils dbUtils;
    private final OrderWorkflowClient workflowClient;
    private final OrderCreationClient orderCreationClient;
    private final DowntimeClient downtimeClient;
    private final DrugInfoClient drugInfoClient;
    private final MultiRxClient multiRxClient;

    public EODOrchestrationClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.wrapperUtils = new WrapperUtils();
        this.dbUtils = new DBUtils();
        this.workflowClient = new OrderWorkflowClient();
        this.orderCreationClient = new OrderCreationClient();
        this.downtimeClient = new DowntimeClient();
        this.drugInfoClient = new DrugInfoClient();
        this.multiRxClient = new MultiRxClient();
    }

    /**
     * Creates a new single Rx order and processes it through to EOD.
     * Full workflow with all assertions and queue checks.
     */
    public ServiceResponse createNewOrderAndMoveToEOD(int patientId, int siteId, 
            String inputRxExpDate, String inputPickupDate, int numRefills, 
            DataRow drugInfo, String ndc) {
        
        inputPickupDate = wrapperUtils.getPickUpDate();
        inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(siteId);
        drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        ServiceResponse dropOffResp = orderCreationClient.createOrderAndDropOff(
                1600, 21104, 1, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        ServiceResponse inputAcceptResp = workflowClient.inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains("error"), "Input Accept could not be completed");
        InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        logOrderDetails(inputResp);

        int nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        if (nxtWrkQueCode != WorkQueueCode.CHKDUR.getWorkQueueCode()) {
            performDowntime(siteId, inputResp);
        }

        ServiceResponse chkDURCompleteResp = workflowClient.chkDURComplete(inputAcceptResp.getDataResponse());
        Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
        Assert.assertFalse(chkDURCompleteResp.getDataResponse().contains("error"), "Check DUR could not be completed");
        InputResponse checkDURInputResp = chkDURCompleteResp.getDataResponse(InputResponse.class);
        
        am.performSleep(30);

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, checkDURInputResp.getRxFillId());
        if (nxtWrkQueCode != WorkQueueCode.FILLING.getWorkQueueCode()) {
            performDowntime(siteId, checkDURInputResp);
        }

        ServiceResponse fillCompleteResp = workflowClient.fillComplete(chkDURCompleteResp.getDataResponse());
        Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Filling could not be completed");

        ServiceResponse vvCompleteResp = workflowClient.vvComplete(fillCompleteResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");

        ServiceResponse pickupCompleteResp = workflowClient.pickupComplete(vvCompleteResp.getDataResponse());
        Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "PickupComplete API response status code did not match");
        Assert.assertFalse(pickupCompleteResp.getDataResponse().contains("error"), "Pickup could not be completed");

        ServiceResponse counselCompleteResp = workflowClient.counselComplete(pickupCompleteResp.getDataResponse());
        Assert.assertEquals(counselCompleteResp.getStatusCode(), 302, "CounselComplete API response status code did not match");
        Assert.assertFalse(counselCompleteResp.getDataResponse().contains("error"), "Counsel could not be completed");
        InputResponse counselCompleteInputResp = counselCompleteResp.getDataResponse(InputResponse.class);

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, counselCompleteInputResp.getRxFillId());
        if (nxtWrkQueCode != WorkQueueCode.POS.getWorkQueueCode()) {
            performDowntime(siteId, counselCompleteInputResp);
        }

        ServiceResponse posCompleteResp = workflowClient.posComplete(counselCompleteResp.getDataResponse());
        Assert.assertEquals(posCompleteResp.getStatusCode(), 302, "POSComplete API response status code did not match");
        Assert.assertFalse(posCompleteResp.getDataResponse().contains("error"), "POS could not be completed");

        return posCompleteResp;
    }

    /**
     * Creates order to EOD with DUR bypass handling and CASH/TP wait logic.
     */
    public ServiceResponse createNewOrderAndMoveToEOD(int patientId, int siteId, 
            int numRefills, DataRow drugInfo, String ndc) {
        
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(siteId);
        drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        ServiceResponse dropOffResp = orderCreationClient.createOrderAndDropOff(
                1600, 21104, 1, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        ServiceResponse inputAcceptResp = workflowClient.inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains("error"), "Input Accept could not be completed");
        InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        logOrderDetails(inputResp);

        int nxtWrkQueCode = refreshNextQueue(siteId, inputResp.getRxFillId(), "After INPUT");

        if (!isOneOfQueues(nxtWrkQueCode, WorkQueueCode.CHKDUR, WorkQueueCode.FILLING) && !isCashOrTPQueue(nxtWrkQueCode)) {
            performDowntime(siteId, inputResp);
            nxtWrkQueCode = refreshNextQueue(siteId, inputResp.getRxFillId(), "After downtime from INPUT");
        }

        ServiceResponse latestPhaseResp = inputAcceptResp;

        if (isCashOrTPQueue(nxtWrkQueCode)) {
            waitOnCashOrTP(siteId, inputResp.getRxFillId(), 3, 30, "Pre-DUR/FILLING");
            nxtWrkQueCode = refreshNextQueue(siteId, inputResp.getRxFillId(), "After CASH wait");
        }

        if (nxtWrkQueCode == WorkQueueCode.CHKDUR.getWorkQueueCode()) {
            ServiceResponse chkDURCompleteResp = workflowClient.chkDURComplete(latestPhaseResp.getDataResponse());
            Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
            Assert.assertFalse(chkDURCompleteResp.getDataResponse().contains("error"), "Check DUR could not be completed");
            latestPhaseResp = chkDURCompleteResp;
            InputResponse durResp = chkDURCompleteResp.getDataResponse(InputResponse.class);
            am.performSleep(30);
            nxtWrkQueCode = refreshNextQueue(siteId, durResp.getRxFillId(), "After DUR");
        } else {
            Reporter.log("DUR bypassed. Current queue code: " + nxtWrkQueCode);
        }

        if (isCashOrTPQueue(nxtWrkQueCode)) {
            waitOnCashOrTP(siteId, inputResp.getRxFillId(), 3, 30, "Pre-FILLING second pass");
            nxtWrkQueCode = refreshNextQueue(siteId, inputResp.getRxFillId(), "After second CASH wait");
        }

        if (nxtWrkQueCode != WorkQueueCode.FILLING.getWorkQueueCode()) {
            performDowntime(siteId, inputResp);
            nxtWrkQueCode = refreshNextQueue(siteId, inputResp.getRxFillId(), "After downtime to FILLING");
        }

        ServiceResponse fillCompleteResp = workflowClient.fillComplete(latestPhaseResp.getDataResponse());
        Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Filling could not be completed");
        latestPhaseResp = fillCompleteResp;

        ServiceResponse vvCompleteResp = workflowClient.vvComplete(latestPhaseResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");
        latestPhaseResp = vvCompleteResp;

        ServiceResponse pickupCompleteResp = workflowClient.pickupComplete(latestPhaseResp.getDataResponse());
        Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "PickupComplete API response status code did not match");
        Assert.assertFalse(pickupCompleteResp.getDataResponse().contains("error"), "Pickup could not be completed");
        latestPhaseResp = pickupCompleteResp;

        ServiceResponse counselCompleteResp = workflowClient.counselComplete(latestPhaseResp.getDataResponse());
        Assert.assertEquals(counselCompleteResp.getStatusCode(), 302, "CounselComplete API response status code did not match");
        Assert.assertFalse(counselCompleteResp.getDataResponse().contains("error"), "Counsel could not be completed");
        InputResponse counselResp = counselCompleteResp.getDataResponse(InputResponse.class);

        nxtWrkQueCode = refreshNextQueue(siteId, counselResp.getRxFillId(), "After COUNSEL");
        if (nxtWrkQueCode != WorkQueueCode.POS.getWorkQueueCode()) {
            performDowntime(siteId, counselResp);
        }

        ServiceResponse posCompleteResp = workflowClient.posComplete(counselCompleteResp.getDataResponse());
        Assert.assertEquals(posCompleteResp.getStatusCode(), 302, "POSComplete API response status code did not match");
        Assert.assertFalse(posCompleteResp.getDataResponse().contains("error"), "POS could not be completed");
        return posCompleteResp;
    }

    /**
     * Processes a single Rx from Filling queue all the way to EOD.
     */
    public ServiceResponse singleRxFillingToEOD(int storeNbr, int rxFillId) {
        ServiceResponse orderDetailsResponse = getOrderDetailsInfo(storeNbr, rxFillId);

        ServiceResponse fillCompleteResp = workflowClient.fillComplete(orderDetailsResponse.getDataResponse());
        Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Fill Complete could not be completed");

        Assert.assertNotNull(fillCompleteResp.getDataResponse(), "FillComplete returned null response body, cannot proceed to VV/Pickup/Counsel");
        InputResponse inputResp = fillCompleteResp.getDataResponse(InputResponse.class);
        long toteNumber = inputResp.getToteNumber();
        Assert.assertNotEquals(toteNumber, 0, "FillComplete returned toteNumber = 0; cannot proceed to VV/Pickup/Counsel");

        ServiceResponse vvCompleteResp = workflowClient.vvComplete(fillCompleteResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");

        ServiceResponse pickupCompleteResp = workflowClient.pickupComplete(vvCompleteResp.getDataResponse());
        Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "pickUpComplete API response status code did not match");
        Assert.assertFalse(pickupCompleteResp.getDataResponse().contains("error"), "pickUp could not be completed");
        am.performSleep(5);

        ServiceResponse counselCompleteResp = workflowClient.counselComplete(pickupCompleteResp.getDataResponse());
        Assert.assertEquals(counselCompleteResp.getStatusCode(), 302, "counsel API response status code did not match");
        Assert.assertFalse(counselCompleteResp.getDataResponse().contains("error"), "counsel could not be completed");
        am.performSleep(5);

        ServiceResponse posCompleteResp = workflowClient.posComplete(counselCompleteResp.getDataResponse());
        Assert.assertEquals(counselCompleteResp.getStatusCode(), 302, "POS API response status code did not match");
        Assert.assertFalse(counselCompleteResp.getDataResponse().contains("error"), "POS could not be completed");
        return posCompleteResp;
    }

    /**
     * Processes a single Rx from Filling to EOD with full order context.
     * Uses OrderOrchestrationClient for complex multi-step workflows.
     */
    public ServiceResponse singleRxFillingToEOD(int patientId, int orderId, int storeNbr,
                                                int rxFillId, int rxId, int numRefills, String ndc, Prescriber prescriber) {
        // Delegate to OrderOrchestrationClient which has the full context
        OrderOrchestrationClient orchClient = new OrderOrchestrationClient();
        return orchClient.singleRxFillingToEOD(patientId, orderId, storeNbr, rxFillId, rxId, numRefills, ndc, prescriber);
    }

    /**
     * Creates multiple Rx orders and processes them all to EOD.
     */
    public List<InputResponse> createMultiRxDropOffToEod(int patientId, int siteId, int numRefills, 
                                                          List<String> ndcList, Prescriber prescriberObject) {
        // Delegate to OrderOrchestrationClient
        OrderOrchestrationClient orchClient = new OrderOrchestrationClient();
        return orchClient.createMultiRxDropOffToEod(patientId, siteId, numRefills, ndcList, prescriberObject);
    }

    // ========== Helper Methods ==========

    private void logOrderDetails(InputResponse inputResp) {
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + 
                    ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());
    }

    private void performDowntime(int siteId, InputResponse respObj) {
        downtimeClient.downTime(respObj.getRxFillId(), respObj.getOrderId(), respObj.getOrderSeqNbr(),
                prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
    }

    private int refreshNextQueue(int siteId, int rxFillId, String phase) {
        int code = dbUtils.getNextWorkQueCode(siteId, rxFillId);
        Reporter.log(phase + " - Next Work Queue Code: " + code);
        return code;
    }

    private boolean isOneOfQueues(int code, WorkQueueCode... targets) {
        for (WorkQueueCode w : targets) {
            if (w.getWorkQueueCode() == code) {
                return true;
            }
        }
        return false;
    }

    private boolean isCashOrTPQueue(int code) {
        return code == WorkQueueCode.CASH.getWorkQueueCode() || code == WorkQueueCode.TP.getWorkQueueCode();
    }

    private void waitOnCashOrTP(int siteId, int rxFillId, int maxRetries, int sleepSeconds, String context) {
        int attempt = 0;
        int nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId);
        while (isCashOrTPQueue(nxtWrkQueCode) && attempt < maxRetries) {
            Reporter.log(context + " - Still in CASH/TP queue (attempt " + (attempt + 1) + "). Waiting " + sleepSeconds + "s...");
            am.performSleep(sleepSeconds);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId);
            attempt++;
        }
        if (isCashOrTPQueue(nxtWrkQueCode)) {
            Reporter.log(context + " - Still in CASH/TP after " + maxRetries + " retries. Proceeding anyway.");
        }
    }

    private ServiceResponse getOrderDetailsInfo(int storeNbr, int rxFillId) {
        hwqe.baseframework.apicontext.ServiceRequest req = new hwqe.baseframework.apicontext.ServiceRequest();
        java.util.HashMap<String, String> headers = new java.util.HashMap<>();

        hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.GetOrderInfo getOrderInfo = 
                new hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.GetOrderInfo();
        getOrderInfo.setSiteId(storeNbr);
        getOrderInfo.setRxFillId(rxFillId);
        
        req.setUrl(prop.getProperty("fom.connexusWrapper.getOrderInfo"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        req.setRequestPayload(getOrderInfo);
        
        Reporter.log("getOrderInfo API endpoint: " + req.getUrl());
        Reporter.logJSON("getOrderInfo API Request", req.getRequestPayload());
        
        ServiceResponse resp = am.getRestContext().performPost(req);
        
        Reporter.logJSON("getOrderInfo API Response", resp.getDataResponse());
        
        return resp;
    }
}
