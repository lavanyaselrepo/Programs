# Connexus API Client Architecture

## Overview

This directory contains focused client classes extracted from the legacy `ConnexusAPIManager` god class.
Each client has a single, well-defined responsibility following the Single Responsibility Principle.

## Refactoring Summary

| Metric | Before | After | Change |
|--------|--------|-------|--------|
| **ConnexusAPIManager** | 5,268 lines | 2,382 lines | -54.8% |
| **Client Classes** | 0 | 28 | +28 classes |
| **Average Client Size** | N/A | ~245 lines | All <600 |
| **Code Quality** | Unmaintainable | Maintainable | ✅ |
| **Testability** | Difficult | Easy (DI) | ✅ |

## Client Categories

### 📦 Order Management

| Client | Purpose | Key Methods |
|--------|---------|-------------|
| `OrderCreationClient` | Order creation workflows | `createOrder()`, `createDropOff()` |
| `OrderWorkflowClient` | State transition management | `inputAccept()`, `checkDUR()`, `fillComplete()` |
| `OrderOrchestrationClient` | End-to-end order orchestration | `createNewOrderAndMoveToEOD()` |
| `OrderHelperClient` | Utility/helper methods | `buildOrderWithDrug()`, `logOrderDetails()` |

### 🔄 Workflow Orchestration

| Client | Purpose | Key Methods |
|--------|---------|-------------|
| `EODOrchestrationClient` | End-of-day workflows | `singleRxFillingToEOD()`, `createMultiRxDropOffToEod()` |
| `PickupOrchestrationClient` | Pickup workflows | `moveOrderToPickup()`, `performPickup()` |
| `FillingOrchestrationClient` | Filling workflows | `createNewOrderAndMoveToFilling()` |
| `PartialWorkflowClient` | Partial/intermediate flows | `orderToPickup()`, `partialWorkflow()` |

### ⚙️ Specialized Workflows

| Client | Purpose | Key Methods |
|--------|---------|-------------|
| `PickupFlowClient` | Pickup process handling | `pickupComplete()`, `counselComplete()` |
| `DowntimeClient` | Downtime mode operations | `downTime()`, `resolveDowntime()` |
| `CancelClient` | Order cancellation | `cancelOrder()`, `cancelFill()` |
| `RefillClient` | Prescription refills | `refillRx()`, `processRefill()` |
| `MultiRxClient` | Multi-prescription workflows | `createMultiRx()`, `processMultiRx()` |
| `CentralFillClient` | Central fill operations | `sendToCentralFill()` |
| `TransferClient` | Prescription transfers | `transferRx()` |

### 👤 Patient & Prescriber

| Client | Purpose | Key Methods |
|--------|---------|-------------|
| `PatientClient` | Patient info management | `getPatient()`, `updatePatient()` |
| `PatientSearchClient` | Patient search/lookup | `searchPatient()`, `findByName()` |
| `DependentPatientClient` | Dependent management | `addDependent()`, `linkDependent()` |
| `PrescriberClient` | Prescriber information | `getPrescriber()`, `createPrescriber()` |

### 💳 Payment & Billing

| Client | Purpose | Key Methods |
|--------|---------|-------------|
| `SwitchToCashClient` | Cash payment switching | `switchToCash()`, `createCashOrder()` |
| `CardPaymentClient` | Card payment processing | `processCard()`, `addPaymentMethod()` |
| `EligibilityClient` | Insurance eligibility | `checkEligibility()` |

### 💊 Drug & Inventory

| Client | Purpose | Key Methods |
|--------|---------|-------------|
| `DrugInfoClient` | Drug/medication details | `getDrugInfo()`, `searchDrug()` |
| `FillInfoClient` | Fill information | `getFillInfo()`, `getFillDetails()` |
| `SetFillClient` | Fill state management | `setFill()`, `updateFillState()` |
| `InventoryClient` | Inventory operations | `updateInventory()`, `checkStock()` |

### 🔧 Support & Infrastructure

| Client | Purpose | Key Methods |
|--------|---------|-------------|
| `AllergyClient` | Allergy information | `getAllergies()`, `addAllergy()` |
| `ConsentClient` | Patient consent | `getConsent()`, `updateConsent()` |
| `QueueClient` | Work queue operations | `moveToQueue()`, `getQueueStatus()` |
| `EODClient` | End-of-day operations | `performEOD()` |
| `CosmosClient` | Cosmos DB operations | `saveToComos()`, `queryComos()` |
| `DatabaseOpsClient` | Database utilities | `executeQuery()`, `cleanupData()` |
| `ServiceAdminClient` | Service admin ops | `callConnexusService()` |

## Migration Guide

### ❌ Old Pattern (Deprecated)

```java
ConnexusAPIManager manager = new ConnexusAPIManager();
InputResponse response = manager.createNewOrderAndMoveToEOD(
    patientId, siteId, numRefills, drugInfo, ndc
);
```

**Issues:**
- Uses god class with 2,382 lines
- Hidden dependencies on instance state
- Difficult to test and maintain
- No clear separation of concerns

### ✅ New Pattern (Recommended)

```java
// Use focused client directly
EODOrchestrationClient eodClient = new EODOrchestrationClient();
InputResponse response = eodClient.createNewOrderAndMoveToEOD(
    patientId, siteId, numRefills, drugInfo, ndc
);
```

**Benefits:**
- Clear, focused responsibility
- Easy to test (dependency injection)
- No hidden instance state
- Follows SOLID principles

## Common Workflows

### Create Order → EOD

```java
// New approach
OrderCreationClient orderClient = new OrderCreationClient();
EODOrchestrationClient eodClient = new EODOrchestrationClient();

// Create order
InputResponse order = orderClient.createOrder(patientId, siteId, drugInfo, ndc);

// Move through workflow to EOD
InputResponse eodResponse = eodClient.moveToEOD(order.getRxFillId(), siteId);
```

### Multi-Rx Workflow

```java
// New approach
MultiRxClient multiRxClient = new MultiRxClient();

List<InputResponse> responses = multiRxClient.createMultiRx(
    patientId, siteId, numRefills, ndcList, prescriber
);
```

### Pickup Workflow

```java
// New approach
PickupOrchestrationClient pickupClient = new PickupOrchestrationClient();

InputResponse pickupResponse = pickupClient.moveOrderToPickup(
    siteId, patientId, orderId
);
```

## Dependency Injection

All clients support constructor injection for testability:

```java
// Production usage (default constructor)
OrderCreationClient client = new OrderCreationClient();

// Testing usage (inject mocks)
AutomationManager mockAM = mock(AutomationManager.class);
PropertyReader mockProp = mock(PropertyReader.class);
DBUtils mockDB = mock(DBUtils.class);

OrderCreationClient testClient = new OrderCreationClient(
    mockAM, mockProp, mockDB
);
```

## Thread Safety

All clients are **thread-safe** by design:
- No mutable instance state
- All state is method-local
- Stateless operations

You can safely use clients across threads or create new instances as needed.

## Best Practices

### ✅ DO

- Use focused clients for new code
- Inject dependencies for testing
- Keep workflow logic in clients
- Follow the Single Responsibility Principle

### ❌ DON'T

- Use `ConnexusAPIManager` for new code (deprecated)
- Create client subclasses (use composition)
- Add business logic to data models
- Share client instances across test methods

## Testing Examples

### Unit Test with Mocks

```java
@Test
public void testOrderCreation() {
    // Arrange
    AutomationManager mockAM = mock(AutomationManager.class);
    PropertyReader mockProp = mock(PropertyReader.class);
    DBUtils mockDB = mock(DBUtils.class);
    
    when(mockProp.getProperty("fom.OrderRequestTypeCode")).thenReturn("1");
    
    OrderCreationClient client = new OrderCreationClient(mockAM, mockProp, mockDB);
    
    // Act
    InputResponse response = client.createOrder(123, 456, drugInfo, "12345");
    
    // Assert
    assertNotNull(response);
    verify(mockAM, times(1)).getRestContext();
}
```

### Integration Test

```java
@Test
public void testEndToEndWorkflow() {
    // Use real clients (integration test)
    OrderCreationClient orderClient = new OrderCreationClient();
    EODOrchestrationClient eodClient = new EODOrchestrationClient();
    
    // Create and process order
    InputResponse order = orderClient.createOrder(patientId, siteId, drugInfo, ndc);
    InputResponse eod = eodClient.moveToEOD(order.getRxFillId(), siteId);
    
    // Verify workflow completion
    assertEquals(WorkQueueCode.EOD.getWorkQueueCode(), eod.getNextWorkQueue());
}
```

## Future Enhancements (Phase 3)

The following improvements are planned for future work:

1. **Complete State Refactoring**
   - Remove all mutable instance state from `ConnexusAPIManager`
   - Convert remaining 75 methods to pure delegations
   - Reduce `ConnexusAPIManager` to <600 lines

2. **Additional Clients**
   - `ValidationClient` - Input validation logic
   - `AutofillClient` - Autofill workflows
   - `ConsentWorkflowClient` - Complex consent workflows

3. **Enhanced Documentation**
   - Sequence diagrams for common workflows
   - Decision trees for client selection
   - Performance optimization guides

4. **Async Support**
   - Add async/reactive workflow support
   - Parallel processing for multi-rx workflows

## Contributing

When adding new functionality:

1. **Choose the right client** based on responsibility
2. **Add method to existing client** if it fits
3. **Create new client** if it's a new domain
4. **Write tests** with dependency injection
5. **Update this README** with new client info

## Questions?

See the main project documentation or contact the automation framework team.

---

**Last Updated:** 2026-04-22  
**Version:** 2.0 (Post-Refactoring)  
**Status:** Production Ready ✅
