package hwqe.baseframework.connexuswrapperapicontext.clients;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Pickup.CreateOrderReadyForPickupRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.connexuscontext.WorkQueueCode;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.util.*;

/**
 * Client for Pickup Flow orchestration operations.
 * 
 * Handles complex workflows that move orders through queues to pickup:
 * - newOrderToReadyForPickup (with standard and control drugs)
 * - createNewOrderAndMoveToPickup
 * - fillingToPickup (single and multi-rx)
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class PickupFlowClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final DBUtils dbUtils;
    private final WrapperUtils wrapperUtils;
    private final OrderWorkflowClient orderWorkflowClient;
    private final OrderCreationClient orderCreationClient;
    private final DowntimeClient downtimeClient;
    private final DrugInfoClient drugInfoClient;

    // Hardcoded stage endpoint for ready-for-pickup
    private static final String READY_FOR_PICKUP_URL = 
            "http://cnx-ui-wrapper-stage.hw-cnx-wrapper.k8s.glb.us.walmart.net/newOrderToReadyForPickUp";

    public PickupFlowClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.dbUtils = new DBUtils();
        this.wrapperUtils = new WrapperUtils();
        this.orderWorkflowClient = new OrderWorkflowClient();
        this.orderCreationClient = new OrderCreationClient();
        this.downtimeClient = new DowntimeClient();
        this.drugInfoClient = new DrugInfoClient();
    }

    // ========== Ready for Pickup Operations ==========

    /**
     * Creates a new order and moves it to ready-for-pickup status using a standard drug.
     */
    public ServiceResponse newOrderToReadyForPickup(int dispenseType, int priorityId, int patientId, 
            int siteId, String inputPickUpDate, String inputRxExpDate) {
        
        Drug drug = buildStandardDrug();
        return sendReadyForPickupRequest(drug, dispenseType, priorityId, patientId, siteId, inputPickUpDate, inputRxExpDate);
    }

    /**
     * Creates a new order and moves it to ready-for-pickup status using a controlled drug.
     */
    public ServiceResponse newOrderToReadyForPickup_ControlDrug(int dispenseType, int priorityId, 
            int patientId, int siteId, String inputPickUpDate, String inputRxExpDate) {
        
        Drug drug = buildControlDrug();
        return sendReadyForPickupRequest(drug, dispenseType, priorityId, patientId, siteId, inputPickUpDate, inputRxExpDate);
    }

    // ========== Filling to Pickup Operations ==========

    /**
     * Moves an order from filling queue to pickup (VV complete).
     */
    public ServiceResponse fillingToPickup(int patientId, int orderId, int storeNbr,
            int rxFillId, int rxId, int numRefills, String ndc, Prescriber prescriber) {

        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(storeNbr);
        DataRow drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        Order order = buildOrder(patientId, orderId, storeNbr, rxFillId, rxId, numRefills, 
                inputPickupDate, inputRxExpDate, prescriber, drugInfo);

        // Wait for order to reach filling queue
        am.performSleep(60);
        resolveIfNeeded(storeNbr, rxFillId, orderId, order.getOrderSeqNbr());
        am.performSleep(20);

        int nxtWrkQueCode = dbUtils.getNextWorkQueCode(storeNbr, rxFillId);
        Assert.assertEquals(nxtWrkQueCode, WorkQueueCode.FILLING.getWorkQueueCode(), "Order is not in Filling queue");

        // Fill complete
        ServiceResponse fillCompleteResp = sendFillComplete(order, storeNbr);
        Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Fill Complete could not be completed");

        am.performSleep(5);
        resolveIfNeeded(storeNbr, rxFillId, orderId, order.getOrderSeqNbr());

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(storeNbr, rxFillId);
        Assert.assertEquals(nxtWrkQueCode, WorkQueueCode.VISUALVERIFY.getWorkQueueCode(), "Order is not in Visual Verify queue");

        // VV complete
        ServiceResponse vvCompleteResp = orderWorkflowClient.vvComplete(fillCompleteResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");

        return vvCompleteResp;
    }

    // ========== Helper Methods ==========

    /**
     * Builds a standard test drug (DML LOT).
     */
    private Drug buildStandardDrug() {
        Drug drug = new Drug();
        drug.setName("DML LOT");
        drug.setNdc("00096072208");
        drug.setItemId(124627);
        drug.setRxProdId(107812);
        drug.setControlCode((short) 2304);
        drug.setPresMultiSrcCode((short) 2603);
        drug.setOnHandQty(2000);
        drug.setGpiCode("90650000004100");
        drug.setUsualCost("100");
        drug.setActCost("80");
        drug.setOrgUsualCost("0");
        drug.setRxNbr(0);
        drug.setRxFillId(0);
        return drug;
    }

    /**
     * Builds a controlled test drug (OXYCODONE).
     */
    private Drug buildControlDrug() {
        Drug drug = new Drug();
        drug.setName("OXYCODONE ER 10MG   TAB");
        drug.setNdc("49884013601");
        drug.setItemId(266950);
        drug.setRxProdId(168213);
        drug.setControlCode((short) 2300);
        drug.setPresMultiSrcCode((short) 2600);
        drug.setOnHandQty(2000);
        drug.setGpiCode("6510007510A710");
        drug.setUsualCost("100");
        drug.setActCost("80");
        drug.setOrgUsualCost("0");
        drug.setRxNbr(0);
        drug.setRxFillId(0);
        return drug;
    }

    /**
     * Sends the ready-for-pickup request.
     */
    private ServiceResponse sendReadyForPickupRequest(Drug drug, int dispenseType, int priorityId,
            int patientId, int siteId, String inputPickUpDate, String inputRxExpDate) {

        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");

        CreateOrderReadyForPickupRequest request = new CreateOrderReadyForPickupRequest();
        request.setDrug(drug);
        request.setDispenseType(dispenseType);
        request.setPriorityId(priorityId);
        request.setPatientId(patientId);
        request.setSiteID(siteId);
        request.setInputPickUpDate(inputPickUpDate);
        request.setInputRxExpDate(inputRxExpDate);

        req.setRequestPayloadWithNulls(request);
        req.setUrl(READY_FOR_PICKUP_URL);
        req.setHeaders(headers);

        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("Create order to Ready for pickup Response", resp.getDataResponse());

        return resp;
    }

    /**
     * Builds an Order object with drug info.
     */
    private Order buildOrder(int patientId, int orderId, int storeNbr, int rxFillId, int rxId,
            int numRefills, String inputPickupDate, String inputRxExpDate, 
            Prescriber prescriber, DataRow drugInfo) {

        Order order = new Order();
        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(prop.getProperty("fom.OrderPriorityId")));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setPatientId(patientId);
        order.setOrderId(orderId);
        order.setSiteID(storeNbr);
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);
        order.setRxFillId(rxFillId);
        order.setNumRefills(numRefills);
        order.setRxId(rxId);
        order.setOrderSeqNbr(1);
        order.setPrescriber(prescriber);
        order.setDrug(buildDrugFromInfo(drugInfo));

        return order;
    }

    /**
     * Builds a Drug object from database info.
     */
    private Drug buildDrugFromInfo(DataRow drugInfo) {
        Drug drug = new Drug();
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr"));
        drug.setItemId(drugInfo.getValue("mds_fam_id"));
        drug.setRxProdId(drugInfo.getValue("product_mds_fam_id"));
        drug.setControlCode(drugInfo.getValue("drug_control_code"));
        drug.setPresMultiSrcCode(drugInfo.getValue("multi_source_code"));
        drug.setOnHandQty(Integer.parseInt(drugInfo.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
        drug.setGpiCode(drugInfo.getValue("gpi_code"));
        drug.setUsualCost("0");
        drug.setActCost("0");
        drug.setOrgUsualCost("0");
        return drug;
    }

    /**
     * Sends fill complete request.
     */
    private ServiceResponse sendFillComplete(Order order, int storeNbr) {
        ServiceRequest sreq = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");

        sreq.setRequestPayloadWithNulls(order);
        sreq.setUrl(prop.getProperty("fom.connexusWrapper.fillCompleteUrl"));
        sreq.setHeaders(headers);

        Reporter.logJSON("Filling complete Request", sreq.getRequestPayload());
        Log.info("Filling complete RequestPayload:\n" + sreq.getRequestPayload() + "\n");

        ServiceResponse fillCompleteResp = am.getRestContext().performPost(sreq);

        Reporter.logJSON("Filling complete Response", fillCompleteResp.getDataResponse());
        Log.info("Filling complete ResponsePayload:\n" + fillCompleteResp.getDataResponse() + "\n");

        am.performSleep(10);
        return fillCompleteResp;
    }

    /**
     * Resolves order if it's in the resolve queue.
     */
    private void resolveIfNeeded(int storeNbr, int rxFillId, int orderId, int orderSeqNbr) {
        int nxtWrkQueCode = dbUtils.getNextWorkQueCode(storeNbr, rxFillId);
        if (nxtWrkQueCode == WorkQueueCode.RESOLVE.getWorkQueueCode()) {
            downtimeClient.downTime(rxFillId, orderId, orderSeqNbr,
                    prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), storeNbr);
        }
    }
}
