package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.AcceptDropOff;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.OrderInfoItem;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.PatHeaderInfoItem;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.CreateOrderForRefill;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.CreateOrderforRefillResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.DropOffCreateReFill;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.DropOffCreateReFillResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.MakeOrderRefill;
import org.openjdk.tools.sjavac.Log;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StringUtils;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Client for Refill operations.
 * 
 * Handles:
 * - Creating refill orders with drop-off
 * - Making orders ready for refill
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class RefillClient {

    private final AutomationManager am;
    private final PropertyReader prop;

    public RefillClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public RefillClient(AutomationManager am, PropertyReader prop) {
        this.am = am;
        this.prop = prop;
    }

    // ========== Refill Order Operations ==========

    /**
     * Drops a Connexus refill by creating an order, attaching to refill, and accepting drop-off.
     * 
     * @param createOrderForRefill Order creation request
     * @param dropOffCreateReFill Drop-off refill request
     * @param acceptDropOff Accept drop-off request
     * @return ServiceResponse from accept drop-off
     */
    public ServiceResponse dropConnexusRefill(CreateOrderForRefill createOrderForRefill, 
            DropOffCreateReFill dropOffCreateReFill, AcceptDropOff acceptDropOff) {
        
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildRefillHeaders();

        String baseUrl = StringUtils.replaceStoreNumber(
                prop.getProperty("cw.baseURL"), 
                String.valueOf(createOrderForRefill.getSiteID()));

        // Step 1: Create order for the customer
        CreateOrderforRefillResponse createOrderResponse = createOrder(req, headers, baseUrl, createOrderForRefill);
        Reporter.logJSON("Create Order for the Patient", createOrderResponse.toString());

        // Step 2: Attach order to refill
        DropOffCreateReFillResponse dropOffResponse = attachOrderToRefill(
                req, headers, baseUrl, dropOffCreateReFill, createOrderForRefill, createOrderResponse);
        Reporter.logJSON("Drop Off Create Refill Response", dropOffResponse.toString());

        // Step 3: Accept drop-off
        return acceptDropOff(req, headers, baseUrl, acceptDropOff, createOrderForRefill, 
                dropOffCreateReFill, dropOffResponse);
    }

    /**
     * Makes orders ready for refill processing.
     * 
     * @param siteId The site ID
     * @param rxId List of prescription IDs
     * @param rxFillId List of fill IDs
     * @return List of input responses
     */
    public List<InputResponse> makeOrdersReadyForRefill(int siteId, List<Integer> rxId, List<Integer> rxFillId) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");

        ArrayList<MakeOrderRefill> makeOrderRefillList = new ArrayList<>();
        List<InputResponse> refillResponse = new ArrayList<>();

        for (int i = 0; i < rxId.size(); i++) {
            MakeOrderRefill makeOrderRefill = new MakeOrderRefill();
            makeOrderRefill.setSiteId(siteId);
            makeOrderRefill.setRxId(rxId.get(i));
            makeOrderRefill.setRxFillId(rxFillId.get(i));
            makeOrderRefillList.add(makeOrderRefill);

            Reporter.logJSON("MakeorderRefill", makeOrderRefill);
        }

        req.setUrl(prop.getProperty("fom.connexusWrapper.orderRefillUrl"));
        req.setHeaders(headers);
        req.setRequestPayloadWithNulls(makeOrderRefillList);

        Reporter.log("MakeorderRefill Request endpoint: " + req.getUrl());

        ServiceResponse resp = am.getRestContext().performPost(req);
        Assert.assertEquals(resp.getStatusCode(), 201, 
                "Expected status code 201 but found " + resp.getStatusCode());

        Log.info("Orders are ready for refill:\n" + resp.getDataResponse() + "\n");
        refillResponse.add(resp.getDataResponse(InputResponse.class));

        return refillResponse;
    }

    // ========== Helper Methods ==========

    /**
     * Builds standard refill headers.
     */
    private HashMap<String, String> buildRefillHeaders() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        return headers;
    }

    /**
     * Creates an order for refill.
     */
    private CreateOrderforRefillResponse createOrder(ServiceRequest req, HashMap<String, String> headers,
            String baseUrl, CreateOrderForRefill createOrderForRefill) {
        req.setRequestPayloadWithNulls(createOrderForRefill);
        req.setUrl(baseUrl + prop.getProperty("cw.createOrder"));
        req.setRequestPayload(createOrderForRefill);
        req.setHeaders(headers);

        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("Create Order for the Patient", resp.getDataResponse());

        return resp.getDataResponse(CreateOrderforRefillResponse.class);
    }

    /**
     * Attaches order to refill.
     */
    private DropOffCreateReFillResponse attachOrderToRefill(ServiceRequest req, HashMap<String, String> headers,
            String baseUrl, DropOffCreateReFill dropOffCreateReFill, 
            CreateOrderForRefill createOrderForRefill, CreateOrderforRefillResponse createOrderResponse) {

        dropOffCreateReFill.setRxId(dropOffCreateReFill.getRxId());
        dropOffCreateReFill.setOrderId(createOrderResponse.getOrderId());
        dropOffCreateReFill.setPriorityId(dropOffCreateReFill.getPriorityId());

        String pickUpTime = dropOffCreateReFill.getPickupTime(dropOffCreateReFill.getPriorityId());
        dropOffCreateReFill.setPickupTime(pickUpTime);
        dropOffCreateReFill.setUserId(StringUtils.generateRandomUserId());
        dropOffCreateReFill.setPatientId(createOrderForRefill.getPatientId());
        dropOffCreateReFill.setSiteId(createOrderForRefill.getSiteID());

        req.setRequestPayloadWithNulls(dropOffCreateReFill);
        req.setUrl(baseUrl + prop.getProperty("cw.DropOffCreateReFill"));
        req.setHeaders(headers);

        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("Create Order for the Patient", resp.getDataResponse());

        return resp.getDataResponse(DropOffCreateReFillResponse.class);
    }

    /**
     * Accepts drop-off for refill.
     */
    private ServiceResponse acceptDropOff(ServiceRequest req, HashMap<String, String> headers, String baseUrl,
            AcceptDropOff acceptDropOff, CreateOrderForRefill createOrderForRefill,
            DropOffCreateReFill dropOffCreateReFill, DropOffCreateReFillResponse dropOffResponse) {

        acceptDropOff.setOrderId(dropOffCreateReFill.getOrderId());
        acceptDropOff.setPriorityId(acceptDropOff.getPriorityId());

        String pickUpDate = acceptDropOff.getPickupDate(acceptDropOff.getPriorityId());
        acceptDropOff.setPickupDate(pickUpDate);
        acceptDropOff.setUserId(dropOffCreateReFill.getUserId());
        acceptDropOff.setPatientId(createOrderForRefill.getPatientId());

        // Build patient header info
        ArrayList<PatHeaderInfoItem> patHeaderInfoItems = new ArrayList<>();
        PatHeaderInfoItem patHeaderInfoItem = new PatHeaderInfoItem();
        patHeaderInfoItem.setPatientId(createOrderForRefill.getPatientId());
        patHeaderInfoItem.setOrderId(dropOffCreateReFill.getOrderId());
        patHeaderInfoItem.setSiteID(createOrderForRefill.getSiteID());
        patHeaderInfoItems.add(patHeaderInfoItem);
        acceptDropOff.setPatHeaderInfo(patHeaderInfoItems);

        // Build order info
        ArrayList<OrderInfoItem> orderInfos = new ArrayList<>();
        OrderInfoItem orderInfo = new OrderInfoItem();
        orderInfo.setOrderId(dropOffResponse.getDropOffInfo().getOrderId());
        orderInfo.setPriorityId(acceptDropOff.getPriorityId());
        orderInfo.setRxFillId(dropOffResponse.getDropOffInfo().getRxFillId());
        orderInfo.setRxId(dropOffResponse.getDropOffInfo().getRxId());
        orderInfo.setPatientId(createOrderForRefill.getPatientId());
        orderInfo.setSiteID(createOrderForRefill.getSiteID());
        orderInfo.setOrderSeqNbr(orderInfo.getOrderSeqNbr());
        orderInfos.add(orderInfo);
        acceptDropOff.setOrderInfo(orderInfos);

        acceptDropOff.setSiteID(createOrderForRefill.getSiteID());

        req.setRequestPayloadWithNulls(acceptDropOff);
        req.setUrl(baseUrl + prop.getProperty("cw.AcceptDropOff"));
        req.setHeaders(headers);

        return am.getRestContext().performPost(req);
    }
}
