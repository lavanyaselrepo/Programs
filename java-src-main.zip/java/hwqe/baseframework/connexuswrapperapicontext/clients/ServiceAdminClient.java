package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.callConnexusService.ConnexusServiceRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.callConnexusService.ConnexusServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.deleteData.RxDataCleanupRequest;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.util.HashMap;

/**
 * Client for Connexus Service Administration operations.
 * 
 * Handles:
 * - Restarting Connexus services
 * - Flushing cache
 * - Running backend scripts
 * - RX data cleanup
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class ServiceAdminClient {

    private final AutomationManager am;
    private final PropertyReader prop;

    public ServiceAdminClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public ServiceAdminClient(AutomationManager am, PropertyReader prop) {
        this.am = am;
        this.prop = prop;
    }

    // ========== Service Operations ==========

    /**
     * Restarts the Connexus service for a given site.
     * 
     * @param siteId Site ID to restart
     */
    public void restartConnexusService(String siteId) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildHeaders();

        ConnexusServiceRequest restartReq = new ConnexusServiceRequest();
        restartReq.setSiteId(siteId);

        req.setUrl(prop.getProperty("fom.connexusWrapper.restartConnexusServiceUrl"));
        req.setHeaders(headers);
        req.setRequestPayload(restartReq);

        logRequest("restartConnexusService", req);

        ServiceResponse resp = am.getRestContext().performPost(req, 2);

        logResponse("restartConnexusService", resp);

        Assert.assertEquals(resp.getStatusCode(), 200, "restartConnexusService API status code did not match");

        ConnexusServiceResponse restartRes = resp.getDataResponse(ConnexusServiceResponse.class);
        Assert.assertEquals(restartRes.getStatus(), "FINISHED", 
                "Restart Connexus Service Response is not successful");
    }

    /**
     * Flushes the cache for a given site.
     * 
     * @param siteId Site ID
     * @return true if successfultatus 200)
     */
    public boolean flushCache(String siteId) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildHeaders();

        ConnexusServiceRequest flushCacheReq = new ConnexusServiceRequest();
        flushCacheReq.setSiteId(siteId);

        req.setUrl(prop.getProperty("fom.connexusWrapper.flushCache"));
        req.setHeaders(headers);
        req.setRequestPayload(flushCacheReq);

        logRequest("flushCache", req);

        ServiceResponse resp = am.getRestContext().performPost(req, 2);

        Reporter.logJSON("flushCache Response: ", resp.getDataResponse());
        Log.info("flushCache Response: " + resp.getDataResponse() + "\n");

        return resp.getStatusCode() == 200;
    }

    // ========== Script Operations ==========

    /**
     * Runs a Connexus backend script.
     * 
     * @param siteId Store ID (e.g., "5511")
     * @param scriptName Script name (e.g., "checkDUR.sh", "autoRefillSubmit.sh")
     * @param targetBoxType Target box type (e.g., "rxp", "rxu")
     */
    public void runConnexusScriptBE(String siteId, String scriptName, String targetBoxType) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildHeaders();

        ConnexusServiceRequest runScriptReq = new ConnexusServiceRequest();
        runScriptReq.setSiteId(siteId);
        runScriptReq.setScriptName(scriptName);
        runScriptReq.setTargetBoxType(targetBoxType);

        req.setUrl(prop.getProperty("fom.connexusWrapper.runConnexusScriptBE"));
        req.setHeaders(headers);
        req.setRequestPayload(runScriptReq);

        logRequest("runConnexusScriptBE", req);

        ServiceResponse resp = am.getRestContext().performPost(req, 5);

        Reporter.log("Response Status Code: " + resp.getStatusCode());
        logResponse("runConnexusScriptBE", resp);

        Assert.assertEquals(resp.getStatusCode(), 200, "runConnexusScriptBE API status code did not match");

        ConnexusServiceResponse runScriptRes = resp.getDataResponse(ConnexusServiceResponse.class);
        Assert.assertEquals(runScriptRes.getStatus(), "FINISHED",
                "runConnexusScriptBE Response is not successful");
    }

    // ========== Data Cleanup Operations ==========

    /**
     * Performs RX data cleanup for a given site.
     * 
     * @param siteId Site ID
     * @param rxDeletionInDays Number of days for deletion threshold
     * @param conTimeOut Connection timeout
     * @param reqTimeOut Request timeout
     */
    public void rxDataCleanUp(String siteId, String rxDeletionInDays, int conTimeOut, int reqTimeOut) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildHeaders();

        RxDataCleanupRequest rxDataCleanupRequest = new RxDataCleanupRequest();
        rxDataCleanupRequest.setSiteId(Integer.parseInt(siteId.trim()));
        rxDataCleanupRequest.setRxDeletionInDays(Integer.parseInt(rxDeletionInDays));

        req.setUrl(prop.getProperty("fom.connexusWrapper.rxDataCleanUpUrl"));
        req.setHeaders(headers);
        req.setRequestPayload(rxDataCleanupRequest);

        Reporter.log("rxDataCleanUp Request endpoint: " + req.getUrl());
        Log.info("rxDataCleanUp Request endpoint\n " + req.getUrl());
        Log.info("rxDataCleanUp Request \n " + req.getRequestPayload());
        Reporter.logJSON("conTimeOut:\n", conTimeOut + "\n");
        Reporter.logJSON("reqTimeOut:\n", reqTimeOut + "\n");
        Reporter.logJSON("rxDataCleanUp Request:\n", req.getRequestPayload() + "\n");

        ServiceResponse resp = am.getRestContext().performPost(req, conTimeOut, reqTimeOut);

        logResponse("rxDataCleanUp", resp);

        Assert.assertEquals(resp.getStatusCode(), 200, "rxDataCleanUp API status code did not match");
    }

    // ========== Helper Methods ==========

    private HashMap<String, String> buildHeaders() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        return headers;
    }

    private void logRequest(String methodName, ServiceRequest req) {
        Reporter.log(methodName + " Request endpoint: " + req.getUrl());
        Log.info(methodName + " Request endpoint\n " + req.getUrl());
        Reporter.logJSON(methodName + " Request", req.getRequestPayload());
        Log.info(methodName + " RequestPayload:\n" + req.getRequestPayload() + "\n");
    }

    private void logResponse(String methodName, ServiceResponse resp) {
        Reporter.logJSON(methodName + " Response", resp.getDataResponse());
        Log.info(methodName + " ResponsePayload:\n" + resp.getDataResponse() + "\n");
    }
}
