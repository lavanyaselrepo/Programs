package hwqe.baseframework.connexuswrapperapicontext.clients;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.DropOffQueueRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Drug;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Order;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;

import java.util.*;

/**
 * Client for Central Fill (CF) operations including ESPN updates, ASN processing, and bag info.
 * 
 * Central Fill is the automated pharmacy fulfillment system that handles:
 * - ESPN (Electronic Shipment Processing Notification) updates
 * - ASN (Advanced Shipment Notification) processing
 * - Bag/tote tracking and finalization
 * - RTS (Return to Stock) operations
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class CentralFillClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final ConnexusAppUtils connexusAppUtils;

    // Shared state for CF operations (maintained for backward compatibility)
    private long asnNumber;
    private long toteNumber;
    private long shipmentId;
    private final List<String> scanPickUpCodeForCF = new ArrayList<>();
    private final List<ESPNASNDetail> asnList = new ArrayList<>();
    private final List<ESPNFill> fillList = new ArrayList<>();
    private final List<ESPNBag> bagList = new ArrayList<>();

    public CentralFillClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.connexusAppUtils = new ConnexusAppUtils();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public CentralFillClient(AutomationManager am, PropertyReader prop, ConnexusAppUtils connexusAppUtils) {
        this.am = am;
        this.prop = prop;
        this.connexusAppUtils = connexusAppUtils;
    }

    // ========== Getters for shared state (for backward compatibility) ==========
    
    public long getAsnNumber() { return asnNumber; }
    public long getToteNumber() { return toteNumber; }
    public long getShipmentId() { return shipmentId; }
    public List<String> getScanPickUpCodeForCF() { return scanPickUpCodeForCF; }

    // ========== Order Creation ==========

    /**
     * Creates a Central Fill order and drops it off for processing.
     */
    public ServiceResponse createCFOrderAndDropOff(Order order, List<DataRow> drugInfo, Prescriber prescriber) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();

        DropOffQueueRequest dropoffRequest = new DropOffQueueRequest();
        dropoffRequest.setRequestTypeCode(order.getRequestTypeCode());
        dropoffRequest.setPriorityId(order.getPriorityId());
        dropoffRequest.setDispenseType(order.getDispenseType());
        dropoffRequest.setPatientId(order.getPatientId());
        dropoffRequest.setSiteID(order.getSiteID());
        dropoffRequest.setInputPickUpDate(order.getInputPickUpDate());
        dropoffRequest.setInputRxExpDate(order.getInputRxExpDate());
        dropoffRequest.setNumRefills(order.getNumRefills());

        Drug drug = buildDrugFromDataRow(drugInfo.get(0));
        dropoffRequest.setDrug(drug);

        req.setRequestPayloadWithNulls(dropoffRequest);
        req.setUrl(prop.getProperty("fom.connexusWrapper.createOrderAndDropOffUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);

        Reporter.log("CreateOrderAndDropOff Request endpoint: " + req.getUrl());
        Reporter.logJSON("CreateMultiOrderAndDropOff Request", dropoffRequest);

        ServiceResponse resp = am.getRestContext().performPost(req);
        Reporter.logJSON("CreateOrderAndDropOff Response", resp.getDataResponse());

        return resp;
    }

    // ========== ESPN Operations ==========

    /**
     * Updates ESPN (Electronic Shipment Processing Notification) with fill details.
     */
    public void centralFillEspnUpdate(Map<String, String> inputData, List<Map<String, Integer>> fillIdAndTranIds) {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildCFAuthHeaders();

        asnNumber = connexusAppUtils.randomNumber(12);
        shipmentId = connexusAppUtils.randomNumber();

        req.setHeaders(headers);
        req.setUrl(buildCFUrl("cf.espn.url"));
        Reporter.log("ESPN UPDATE Endpoint: " + req.getUrl());

        // Build fill list
        for (Map<String, Integer> fillIdAndTranId : fillIdAndTranIds) {
            ESPNFill fill = ESPNFill.builder()
                    .store_tran_id(fillIdAndTranId.get("tranId"))
                    .fill_id(fillIdAndTranId.get("fillId"))
                    .ndc_nbr(inputData.get("DRUG_NAME"))
                    .fill_date(ConnexusAppUtils.getCurrentTimestamp("YYYY-MM-dd"))
                    .fill_qty(Integer.parseInt(prop.getProperty("cf.fill.qty")))
                    .tech_of_rec_desc(prop.getProperty("cf.tech.desc"))
                    .tech_of_rec_id(prop.getProperty("cf.tech.id"))
                    .rph_of_rec_id(prop.getProperty("cf.rph.id"))
                    .rph_of_rec_desc(prop.getProperty("cf.rph.desc"))
                    .rph_of_rec_end_ts(prop.getProperty("cf.fill.ts"))
                    .packer_of_rec_desc(prop.getProperty("cf.pack.desc"))
                    .packer_of_rec_id(prop.getProperty("cf.tech.id"))
                    .packer_of_rec_end_ts(prop.getProperty("cf.fill.ts"))
                    .tech_of_rec_st_ts(prop.getProperty("cf.fill.ts"))
                    .build();
            fillList.add(fill);
        }

        ESPNBag bag = ESPNBag.builder()
                .bag_nbr(connexusAppUtils.randomNumber(6))
                .fills(fillList)
                .build();
        bagList.add(bag);

        ESPNASNDetail asnDetail = ESPNASNDetail.builder()
                .asn_nbr(String.valueOf(asnNumber))
                .asn_final_ts(ConnexusAppUtils.getCurrentTimestamp("YYYY-MM-dd HH:mm:ss"))
                .cf_shipment_id(shipmentId)
                .est_arrival(ConnexusAppUtils.getCurrentTimestamp("YYYY-MM-dd HH:mm:ss"))
                .drug_tracking_txt("")
                .fill_cnt(fillList.size() % 14)
                .bags(bagList)
                .build();
        asnList.add(asnDetail);

        ESPNShipmentDetails shipmentDetails = ESPNShipmentDetails.builder()
                .ASN_details(asnList)
                .build();

        ESPNData data = ESPNData.builder()
                .azure_tran_id(connexusAppUtils.randomAlphaNumeric())
                .cf_facility_nbr(connexusAppUtils.randomNumber(4))
                .cf_facility_tran_id(connexusAppUtils.randomAlphaNumeric())
                .shipment_details(shipmentDetails)
                .build();

        ESPNHeader header = ESPNHeader.builder()
                .request_tracking_id(connexusAppUtils.randomAlphaNumeric())
                .request_id(connexusAppUtils.randomAlphaNumeric())
                .store_nbr(Integer.parseInt(prop.getProperty("cnx.store")))
                .msg_type(prop.getProperty("cf.msg.type"))
                .request_type_code(4)
                .request_type_desc(prop.getProperty("cf.req.desc"))
                .request_ts(ConnexusAppUtils.getCurrentTimestamp("YYYY-MM-dd HH:mm:ss"))
                .version(prop.getProperty("cf.version"))
                .build();

        ESPNRoot root = ESPNRoot.builder().data(data).header(header).build();

        req.setRequestPayloadWithNulls(root);
        ServiceResponse resp = am.getRestContext().performPost(req, 1);

        Reporter.logJSON("ESPN Request", req.getRequestPayload());
        Reporter.logJSON("ESPN Response", resp.getDataResponse());

        // Clear for next use
        fillList.clear();
        bagList.clear();
        asnList.clear();
    }

    // ========== ASN Operations ==========

    /**
     * Retrieves Central Fill ASN information and returns rx tokens.
     */
    public List<Integer> centralFillASNInfo() {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildCFFullHeaders();

        req.setHeaders(headers);
        req.setUrl(buildCFUrl("cf.asn.url"));
        Reporter.log("ASN Info Endpoint: " + req.getUrl());

        ASNRoot root = ASNRoot.builder()
                .asnNbr(String.valueOf(asnNumber))
                .override(true)
                .build();

        req.setRequestPayloadWithNulls(root);
        ServiceResponse resp = am.getRestContext().performPost(req, 1);

        Reporter.logJSON("ASN Request", req.getRequestPayload());
        Reporter.logJSON("ASN Response", resp.getDataResponse());

        // Parse rx tokens from response
        List<Integer> rxToken = new ArrayList<>();
        String response = resp.getDataResponse();
        JsonObject json = JsonParser.parseString(response).getAsJsonObject();
        JsonArray orders = json.getAsJsonArray("orders");
        JsonObject firstOrder = orders.get(0).getAsJsonObject();
        JsonArray fills = firstOrder.getAsJsonArray("fills");

        for (int i = 0; i < fills.size(); i++) {
            JsonObject fill = fills.get(i).getAsJsonObject();
            rxToken.add(fill.get("rxToken").getAsInt());
        }

        return rxToken;
    }

    /**
     * Finalizes an ASN (Advanced Shipment Notification).
     */
    public void centralFillFinalizeASN() {
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildCFFullHeaders();

        req.setHeaders(headers);
        req.setUrl(buildCFUrl("cf.finalizeASN.url"));

        ASNFinalizeDetails asnFinalize = ASNFinalizeDetails.builder()
                .description("FINALIZE")
                .code(1)
                .build();

        CFASNFinalize root = CFASNFinalize.builder()
                .asnNbr(String.valueOf(asnNumber))
                .action(asnFinalize)
                .build();

        req.setRequestPayloadWithNulls(root);
        ServiceResponse resp = am.getRestContext().performPost(req, 1);

        Reporter.logJSON("Request", req.getRequestPayload());
        Reporter.logJSON("Response", resp.getDataResponse());
    }

    // ========== Bag Info Operations ==========

    /**
     * Processes CF bag info for given rx tokens.
     */
    public void centralFillCfBagInfo(List<Integer> rxToken) {
        centralFillCfBagInfo(rxToken, "");
    }

    /**
     * Processes CF bag info for given rx tokens with rx number.
     */
    public void centralFillCfBagInfo(List<Integer> rxToken, String rxNbr) {
        centralFillCfBagInfo(rxToken, rxNbr, false);
    }

    /**
     * Processes CF bag info for a single rx token.
     */
    public void centralFillCfBagInfo(int rxToken, String rxNbr) {
        List<Integer> rxTokenList = new ArrayList<>();
        rxTokenList.add(rxToken);
        centralFillCfBagInfo(rxTokenList, rxNbr);
    }

    /**
     * Processes CF bag info with full options.
     */
    public void centralFillCfBagInfo(List<Integer> rxToken, String rxNbr, boolean pickupCode) {
        toteNumber = connexusAppUtils.randomNumber(4);
        scanPickUpCodeForCF.clear();

        for (int i = 0; i < rxToken.size(); i++) {
            String scanPickUpCodeF = buildScanPickUpCode(rxToken.get(i), pickupCode);
            scanPickUpCodeForCF.add(scanPickUpCodeF);

            if (!rxNbr.isEmpty()) {
                String scanPickUpCode2 = buildAlternateScanCode(rxNbr, rxToken.get(i));
                scanPickUpCodeForCF.add(scanPickUpCode2);
            }

            Reporter.log("CentralFill scan codes are " + scanPickUpCodeForCF);

            ServiceRequest req = new ServiceRequest();
            HashMap<String, String> headers = buildCFFullHeaders();
            req.setHeaders(headers);
            req.setUrl(buildCFUrl("cf.cfbag.url"));

            CFBagInfoRoot root = CFBagInfoRoot.builder()
                    .asnNbr(String.valueOf(asnNumber))
                    .toteNbr(toteNumber)
                    .rxToken(scanPickUpCodeForCF.get(i))
                    .build();

            req.setRequestPayloadWithNulls(root);
            ServiceResponse resp = am.getRestContext().performPost(req, 1);

            Reporter.logJSON("Request", req.getRequestPayload());
            Reporter.logJSON("Response", resp.getDataResponse());
        }
    }

    // ========== Set Fill Missing ==========

    /**
     * Sets fill as missing in CF system.
     */
    public void centralFillCfSetFillMissing(int rxToken, boolean isNewToken) {
        toteNumber = connexusAppUtils.randomNumber(4);
        scanPickUpCodeForCF.clear();

        String scanPickUpCodeF = buildScanPickUpCode(rxToken, isNewToken);
        scanPickUpCodeForCF.add(scanPickUpCodeF);

        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildCFFullHeaders();
        req.setHeaders(headers);
        req.setUrl(buildCFUrl("cf.setasnmissing.url"));

        CFAsnInfoRoot root = CFAsnInfoRoot.builder()
                .asnNbr(String.valueOf(asnNumber))
                .rxTokens(scanPickUpCodeForCF)
                .build();

        req.setRequestPayloadWithNulls(root);
        ServiceResponse resp = am.getRestContext().performPost(req, 1);

        Reporter.logJSON("CFSetMissingInfoRequest", req.getRequestPayload());
        Reporter.logJSON("CFSetMissingInfoResponse", resp.getDataResponse());
    }

    // ========== RTS (Return to Stock) ==========

    /**
     * Sets CF RTS (Return to Stock) information.
     */
    public void setCFRTSInfo(int rxToken, boolean isNewToken) {
        toteNumber = connexusAppUtils.randomNumber(4);
        scanPickUpCodeForCF.clear();

        String scanPickUpCodeF = buildScanPickUpCode(rxToken, isNewToken);
        scanPickUpCodeForCF.add(scanPickUpCodeF);

        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildCFFullHeaders();
        req.setHeaders(headers);
        req.setUrl(buildCFUrl("cf.RTSInfo.url"));

        RTSInfoRoot root = RTSInfoRoot.builder()
                .asnNbr(String.valueOf(asnNumber))
                .rxToken(scanPickUpCodeForCF.get(0))
                .printLabel(true)
                .reprint(false)
                .build();

        req.setRequestPayloadWithNulls(root);
        ServiceResponse resp = am.getRestContext().performPost(req, 1);

        Reporter.logJSON("SetCFRTSInfo Request", req.getRequestPayload());
        Reporter.logJSON("SetCFRTSInfo Response", resp.getDataResponse());
    }

    // ========== Helper Methods ==========

    /**
     * Builds basic CF auth headers.
     */
    private HashMap<String, String> buildCFAuthHeaders() {
        HashMap<String, String> headers = new HashMap<>();
        String auth = prop.getProperty("cf.basic.auth");
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());
        headers.put("content-type", prop.getProperty("fom.Content.type"));
        headers.put("Authorization", "Basic " + encodedAuth);
        return headers;
    }

    /**
     * Builds full CF headers including all required fields.
     */
    private HashMap<String, String> buildCFFullHeaders() {
        HashMap<String, String> headers = buildCFAuthHeaders();
        headers.put("header_p_value", prop.getProperty("cf.header.p.value"));
        headers.put("TimeStamp", "");
        headers.put("auth_pass", prop.getProperty("cf.auth.pass"));
        headers.put("AuthSHA", "");
        headers.put("userId", prop.getProperty("cnx.rph.userName"));
        headers.put("macAddress", prop.getProperty("cf.mac.address"));
        return headers;
    }

    /**
     * Builds CF URL with store number replacement.
     */
    private String buildCFUrl(String urlProperty) {
        return prop.getProperty(urlProperty)
                .replace("XXXXX", String.format("%05d", Integer.parseInt(prop.getProperty("cnx.store"))));
    }

    /**
     * Builds scan pickup code for CF operations.
     */
    private String buildScanPickUpCode(int rxToken, boolean isNewToken) {
        if (isNewToken) {
            return "4793" + String.format("%05d", Integer.parseInt(prop.getProperty("cnx.store"))) 
                    + "-" + String.format("%010d", rxToken) + "0";
        } else {
            return "4793" + String.format("%010d", rxToken) + "0";
        }
    }

    /**
     * Builds alternate scan code format.
     */
    private String buildAlternateScanCode(String rxNbr, int rxToken) {
        String siteId = prop.getProperty("cnx.store");
        if (siteId.length() > 4) {
            return siteId + "00" + rxNbr + String.format("%010d", rxToken);
        } else {
            return "0" + siteId + "00" + rxNbr + String.format("%010d", rxToken);
        }
    }

    /**
     * Builds Drug object from DataRow.
     */
    private Drug buildDrugFromDataRow(DataRow drugInfo) {
        Drug drug = new Drug();
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr").toString().trim());
        drug.setItemId(Integer.parseInt(drugInfo.getValue("mds_fam_id").toString().trim()));
        drug.setRxProdId(Integer.parseInt(drugInfo.getValue("product_mds_fam_id").toString().trim()));
        drug.setControlCode(Short.parseShort(drugInfo.getValue("drug_control_code").toString().trim()));
        drug.setPresMultiSrcCode(Short.parseShort(drugInfo.getValue("multi_source_code").toString().trim()));
        drug.setOnHandQty(Integer.parseInt(drugInfo.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
        drug.setGpiCode(drugInfo.getValue("gpi_code").toString().trim());
        drug.setUsualCost("0");
        drug.setActCost("0");
        drug.setOrgUsualCost("0");
        return drug;
    }
}
