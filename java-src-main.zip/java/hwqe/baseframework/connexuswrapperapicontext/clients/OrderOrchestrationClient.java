package hwqe.baseframework.connexuswrapperapicontext.clients;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.WorkQueueCode;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Drug;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Order;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.MultiOrderInput;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.OrderInput;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.GetOrderInfo;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.DropOffQueueRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.TillPickupRequest;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.utilities.StringUtils;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.assertj.core.util.DateUtil;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

/**
 * Client for orchestrating complete order workflows through multiple queue states.
 * 
 * This client handles end-to-end order processing that spans multiple workflow steps:
 * DropOff → InputAccept → DUR → Fill → VV → Pickup → Counsel → POS → EOD
 * 
 * Unlike {@link OrderWorkflowClient} which handles individual state transitions,
 * this client orchestrates complete journeys through the pharmacy workflow.
 * 
 * Thread-safe: Uses method-local variables instead of instance state.
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class OrderOrchestrationClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final WrapperUtils wrapperUtils;
    private final DBUtils dbUtils;
    private final OrderWorkflowClient workflowClient;
    private final OrderCreationClient orderCreationClient;
    private final DowntimeClient downtimeClient;
    private final DrugInfoClient drugInfoClient;
    private final PrescriberClient prescriberClient;
    private final PickupFlowClient pickupFlowClient;
    private final MultiRxClient multiRxClient;
    private final OrderHelperClient helperClient;

    public OrderOrchestrationClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.wrapperUtils = new WrapperUtils();
        this.dbUtils = new DBUtils();
        this.workflowClient = new OrderWorkflowClient();
        this.orderCreationClient = new OrderCreationClient();
        this.downtimeClient = new DowntimeClient();
        this.drugInfoClient = new DrugInfoClient();
        this.prescriberClient = new PrescriberClient();
        this.pickupFlowClient = new PickupFlowClient();
        this.multiRxClient = new MultiRxClient();
        this.helperClient = new OrderHelperClient();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public OrderOrchestrationClient(AutomationManager am, PropertyReader prop,
                                     WrapperUtils wrapperUtils, DBUtils dbUtils,
                                     OrderWorkflowClient workflowClient,
                                     OrderCreationClient orderCreationClient,
                                     DowntimeClient downtimeClient,
                                     DrugInfoClient drugInfoClient,
                                     PrescriberClient prescriberClient,
                                     PickupFlowClient pickupFlowClient,
                                     MultiRxClient multiRxClient,
                                     OrderHelperClient helperClient) {
        this.am = am;
        this.prop = prop;
        this.wrapperUtils = wrapperUtils;
        this.dbUtils = dbUtils;
        this.workflowClient = workflowClient;
        this.orderCreationClient = orderCreationClient;
        this.downtimeClient = downtimeClient;
        this.drugInfoClient = drugInfoClient;
        this.prescriberClient = prescriberClient;
        this.pickupFlowClient = pickupFlowClient;
        this.multiRxClient = multiRxClient;
        this.helperClient = helperClient;
    }

    // ========== Complete Order Workflows to EOD ==========

    /**
     * Creates a new order and moves it through all queues to End of Day.
     * Full workflow: DropOff → Input → DUR → Fill → VV → Pickup → Counsel → POS
     */
    public ServiceResponse createNewOrderAndMoveToEOD(int patientId, int siteId, 
            String inputRxExpDate, String inputPickupDate, int numRefills, 
            DataRow drugInfo, String ndc) {
        
        // Initialize dates
        inputPickupDate = wrapperUtils.getPickUpDate();
        inputRxExpDate = wrapperUtils.getExpiryDate();

        // Fetch drug info
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        // Drop-Off
        ServiceResponse dropOffResp = orderCreationClient.createOrderAndDropOff(
                1600, 21104, 1, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        // Input Accept
        ServiceResponse inputAcceptResp = workflowClient.inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains("error"), "Input Accept could not be completed");
        InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        helperClient.logOrderDetails(inputResp);

        // Handle queue transitions with downtime if needed
        int nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        if (nxtWrkQueCode != WorkQueueCode.CHKDUR.getWorkQueueCode()) {
            helperClient.performDowntime(siteId, inputResp);
        }

        // DUR Complete
        ServiceResponse chkDURCompleteResp = workflowClient.chkDURComplete(inputAcceptResp.getDataResponse());
        Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
        Assert.assertFalse(chkDURCompleteResp.getDataResponse().contains("error"), "Check DUR could not be completed");
        InputResponse checkDURInputResp = chkDURCompleteResp.getDataResponse(InputResponse.class);
        
        // Wait for CASH/TP processing
        am.performSleep(30);

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, checkDURInputResp.getRxFillId());
        if (nxtWrkQueCode != WorkQueueCode.FILLING.getWorkQueueCode()) {
            helperClient.performDowntime(siteId, checkDURInputResp);
        }

        // Fill Complete
        ServiceResponse fillCompleteResp = workflowClient.fillComplete(chkDURCompleteResp.getDataResponse());
        Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Filling could not be completed");

        // VV Complete
        ServiceResponse vvCompleteResp = workflowClient.vvComplete(fillCompleteResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");

        // Pickup Complete
        ServiceResponse pickupCompleteResp = workflowClient.pickupComplete(vvCompleteResp.getDataResponse());
        Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "PickupComplete API response status code did not match");
        Assert.assertFalse(pickupCompleteResp.getDataResponse().contains("error"), "Pickup could not be completed");

        // Counsel Complete
        ServiceResponse counselCompleteResp = workflowClient.counselComplete(pickupCompleteResp.getDataResponse());
        Assert.assertEquals(counselCompleteResp.getStatusCode(), 302, "CounselComplete API response status code did not match");
        Assert.assertFalse(counselCompleteResp.getDataResponse().contains("error"), "Counsel could not be completed");
        InputResponse counselCompleteInputResp = counselCompleteResp.getDataResponse(InputResponse.class);

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, counselCompleteInputResp.getRxFillId());
        if (nxtWrkQueCode != WorkQueueCode.POS.getWorkQueueCode()) {
            helperClient.performDowntime(siteId, counselCompleteInputResp);
        }

        // POS Complete
        ServiceResponse posCompleteResp = workflowClient.posComplete(counselCompleteResp.getDataResponse());
        Assert.assertEquals(posCompleteResp.getStatusCode(), 302, "POSComplete API response status code did not match");
        Assert.assertFalse(posCompleteResp.getDataResponse().contains("error"), "POS could not be completed");

        return posCompleteResp;
    }

    /**
     * Creates a new order and moves it to EOD with DUR bypass handling.
     */
    public ServiceResponse createNewOrderAndMoveToEOD(int patientId, int siteId, 
            int numRefills, DataRow drugInfo, String ndc) {
        // Initialize dates
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        // Fetch drug info
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        // Drop-Off
        ServiceResponse dropOffResp = orderCreationClient.createOrderAndDropOff(
                1600, 21104, 1, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        // Input Accept
        ServiceResponse inputAcceptResp = workflowClient.inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains("error"), "Input Accept could not be completed");
        InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        helperClient.logOrderDetails(inputResp);

        // Determine next queue after INPUT; DUR may be bypassed
        int nxtWrkQueCode = helperClient.refreshNextQueue(siteId, inputResp.getRxFillId(), "After INPUT");

        // If we are not at DUR, FILLING or CASH, attempt a downtime
        if (!helperClient.isOneOfQueues(nxtWrkQueCode, WorkQueueCode.CHKDUR, WorkQueueCode.FILLING) && !helperClient.isCashOrTPQueue(nxtWrkQueCode)) {
            helperClient.performDowntime(siteId, inputResp);
            nxtWrkQueCode = helperClient.refreshNextQueue(siteId, inputResp.getRxFillId(), "After downtime from INPUT");
        }

        ServiceResponse latestPhaseResp = inputAcceptResp;

        // Handle CASH or TP WQ waits pre-DUR/FILLING
        if (helperClient.isCashOrTPQueue(nxtWrkQueCode)) {
            helperClient.waitOnCashOrTP(siteId, inputResp.getRxFillId(), 3, 30, "Pre-DUR/FILLING");
            nxtWrkQueCode = helperClient.refreshNextQueue(siteId, inputResp.getRxFillId(), "After CASH wait");
        }

        // Perform DUR only if currently in DUR WQ
        if (nxtWrkQueCode == WorkQueueCode.CHKDUR.getWorkQueueCode()) {
            ServiceResponse chkDURCompleteResp = workflowClient.chkDURComplete(latestPhaseResp.getDataResponse());
            Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
            Assert.assertFalse(chkDURCompleteResp.getDataResponse().contains("error"), "Check DUR could not be completed");
            latestPhaseResp = chkDURCompleteResp;
            InputResponse durResp = chkDURCompleteResp.getDataResponse(InputResponse.class);
            am.performSleep(30);
            nxtWrkQueCode = helperClient.refreshNextQueue(siteId, durResp.getRxFillId(), "After DUR");
        } else {
            Reporter.log("DUR bypassed. Current queue code: " + nxtWrkQueCode);
        }

        // If still CASH before FILLING, wait again
        if (helperClient.isCashOrTPQueue(nxtWrkQueCode)) {
            helperClient.waitOnCashOrTP(siteId, inputResp.getRxFillId(), 3, 30, "Pre-FILLING second pass");
            nxtWrkQueCode = helperClient.refreshNextQueue(siteId, inputResp.getRxFillId(), "After second CASH wait");
        }

        // Assist movement to FILLING if not already there
        if (nxtWrkQueCode != WorkQueueCode.FILLING.getWorkQueueCode()) {
            helperClient.performDowntime(siteId, inputResp);
            nxtWrkQueCode = helperClient.refreshNextQueue(siteId, inputResp.getRxFillId(), "After downtime to FILLING");
        }

        // Filling
        ServiceResponse fillCompleteResp = workflowClient.fillComplete(latestPhaseResp.getDataResponse());
        Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Filling could not be completed");
        latestPhaseResp = fillCompleteResp;

        // Visual Verify
        ServiceResponse vvCompleteResp = workflowClient.vvComplete(latestPhaseResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");
        latestPhaseResp = vvCompleteResp;

        // Pickup
        ServiceResponse pickupCompleteResp = workflowClient.pickupComplete(latestPhaseResp.getDataResponse());
        Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "PickupComplete API response status code did not match");
        Assert.assertFalse(pickupCompleteResp.getDataResponse().contains("error"), "Pickup could not be completed");
        latestPhaseResp = pickupCompleteResp;

        // Counsel
        ServiceResponse counselCompleteResp = workflowClient.counselComplete(latestPhaseResp.getDataResponse());
        Assert.assertEquals(counselCompleteResp.getStatusCode(), 302, "CounselComplete API response status code did not match");
        Assert.assertFalse(counselCompleteResp.getDataResponse().contains("error"), "Counsel could not be completed");
        InputResponse counselResp = counselCompleteResp.getDataResponse(InputResponse.class);

        // Move to POS if needed
        nxtWrkQueCode = helperClient.refreshNextQueue(siteId, counselResp.getRxFillId(), "After COUNSEL");
        if (nxtWrkQueCode != WorkQueueCode.POS.getWorkQueueCode()) {
            helperClient.performDowntime(siteId, counselResp);
        }

        // POS
        ServiceResponse posCompleteResp = workflowClient.posComplete(counselCompleteResp.getDataResponse());
        Assert.assertEquals(posCompleteResp.getStatusCode(), 302, "POSComplete API response status code did not match");
        Assert.assertFalse(posCompleteResp.getDataResponse().contains("error"), "POS could not be completed");
        return posCompleteResp;
    }

    // ========== Order Workflows to Pickup ==========
    /**
     * Performs Visual Verify and Pickup steps on an existing order.
     */
    public InputResponse performVisualVerifyAndPickup(int patientId, int orderId, int storeNbr,
            int rxFillId, int rxId, int rxNbr, int numRefills, int orderSeqNum, 
            String ndc, Prescriber prescriber) {
        
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(storeNbr);
        DataRow drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        Order order = helperClient.buildOrderWithDrug(patientId, orderId, storeNbr, rxFillId, rxId, rxNbr, 
                numRefills, orderSeqNum, inputPickupDate, inputRxExpDate, drugInfo, prescriber);

        req.setRequestPayloadWithNulls(order);
        req.setUrl(prop.getProperty("fom.connexusWrapper.vvCompleteUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("VV complete Request endpoint: " + req.getUrl());
        Reporter.logJSON("VV complete Request", req.getRequestPayload());
        Log.info("VV complete RequestPayload:\n" + req.getRequestPayload() + "\n");
        
        ServiceResponse vvCompleteResp = am.getRestContext().performPost(req);
        Reporter.logJSON("VV complete Response", vvCompleteResp.getDataResponse());
        Log.info("VV complete ResponsePayload:\n" + vvCompleteResp.getDataResponse() + "\n");
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");

        ServiceResponse pickupCompleteResp = workflowClient.pickupComplete(vvCompleteResp.getDataResponse());
        Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "PickupComplete API response status code did not match");
        Assert.assertFalse(pickupCompleteResp.getDataResponse().contains("error"), "Pickup could not be completed");
        
        return pickupCompleteResp.getDataResponse(InputResponse.class);
    }

    // ========== Single Rx Workflows ==========

    /**
     * Moves a single Rx from Filling to EOD.
     */
    public ServiceResponse singleRxFillingToEOD(int storeNbr, int rxFillId) {
        ServiceResponse orderDetailsResponse = helperClient.getOrderDetailsInfo(storeNbr, rxFillId);

        ServiceResponse fillCompleteResp = workflowClient.fillComplete(orderDetailsResponse.getDataResponse());
        Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Fill Complete could not be completed");

        InputResponse inputResp = fillCompleteResp.getDataResponse(InputResponse.class);
        long toteNumber = inputResp.getToteNumber();
        Assert.assertNotEquals(toteNumber, 0, "FillComplete returned toteNumber = 0; cannot proceed to VV/Pickup/Counsel");

        ServiceResponse vvCompleteResp = workflowClient.vvComplete(fillCompleteResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");

        ServiceResponse pickupCompleteResp = workflowClient.pickupComplete(vvCompleteResp.getDataResponse());
        Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "pickUpComplete API response status code did not match");
        Assert.assertFalse(pickupCompleteResp.getDataResponse().contains("error"), "pickUp could not be completed");
        am.performSleep(5);

        ServiceResponse counselCompleteResp = workflowClient.counselComplete(pickupCompleteResp.getDataResponse());
        Assert.assertEquals(counselCompleteResp.getStatusCode(), 302, "counsel API response status code did not match");
        Assert.assertFalse(counselCompleteResp.getDataResponse().contains("error"), "counsel could not be completed");
        am.performSleep(5);

        ServiceResponse posCompleteResp = workflowClient.posComplete(counselCompleteResp.getDataResponse());
        Assert.assertEquals(posCompleteResp.getStatusCode(), 302, "POS API response status code did not match");
        Assert.assertFalse(posCompleteResp.getDataResponse().contains("error"), "POS could not be completed");
        
        return posCompleteResp;
    }

    /**
     * Moves a single Rx from Filling to EOD with full order context.
     */
    public ServiceResponse singleRxFillingToEOD(int patientId, int orderId, int storeNbr,
            int rxFillId, int rxId, int numRefills, String ndc, Prescriber prescriber) {
        
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(storeNbr);
        DataRow drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        Order order = helperClient.buildOrderWithDrug(patientId, orderId, storeNbr, rxFillId, rxId, 0, 
                numRefills, 1, inputPickupDate, inputRxExpDate, drugInfo, prescriber);

        req.setRequestPayloadWithNulls(order);
        req.setUrl(prop.getProperty("fom.connexusWrapper.fillCompleteUrl"));
        Reporter.logJSON("Filling complete Request", req.getRequestPayload());
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        
        ServiceResponse fillCompleteResp = am.getRestContext().performPost(req);
        Reporter.logJSON("Filling complete Response", fillCompleteResp.getDataResponse());
        Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Fill Complete could not be completed");

        ServiceResponse vvCompleteResp = workflowClient.vvComplete(fillCompleteResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");

        ServiceResponse pickupCompleteResp = workflowClient.pickupComplete(vvCompleteResp.getDataResponse());
        Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "pickUpComplete API response status code did not match");
        Assert.assertFalse(pickupCompleteResp.getDataResponse().contains("error"), "pickUp could not be completed");
        am.performSleep(5);

        ServiceResponse counselCompleteResp = workflowClient.counselComplete(pickupCompleteResp.getDataResponse());
        Assert.assertEquals(counselCompleteResp.getStatusCode(), 302, "counsel API response status code did not match");
        Assert.assertFalse(counselCompleteResp.getDataResponse().contains("error"), "counsel could not be completed");
        am.performSleep(5);

        ServiceResponse posCompleteResp = workflowClient.posComplete(counselCompleteResp.getDataResponse());
        Assert.assertEquals(posCompleteResp.getStatusCode(), 302, "POS API response status code did not match");
        Assert.assertFalse(posCompleteResp.getDataResponse().contains("error"), "POS could not be completed");
        
        return posCompleteResp;
    }

    // ========== Multi-Rx Workflows ==========

    /**
     * Creates multi-Rx drop-off and moves all to EOD.
     */
    public List<InputResponse> createMultiRxDropOffToEod(int patientId, int siteId, 
            int numRefills, List<String> ndcList, Prescriber prescriberObject) {
        
        List<InputResponse> multiRxPaymentCompleteResp = new ArrayList<>();
        
        Order order = new Order();
        order.setPrescriber(prescriberObject);

        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(siteId);
        List<DataRow> NDCData = new ArrayList<>();
        for (String ndc : ndcList) {
            List<DataRow> rows = dbUtils.getMultiDrugInfo(cnx, ndc);
            NDCData.addAll(rows);
        }

        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(prop.getProperty("fom.OrderPriorityId")));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);
        order.setNumRefills(numRefills);
        order.setPatientId(patientId);
        order.setSiteID(siteId);

        ServiceResponse dropOffResp = multiRxClient.createMultiOrderAndDropOff(order, NDCData, prescriberObject);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createMultiRxAndDropOff API response status code did not match");

        MultiOrderInput multiOrderInput = dropOffResp.getDataResponse(MultiOrderInput.class);
        int drugListSize = multiOrderInput.getDrugList().size();
        OrderInput orderInput = new OrderInput();
        
        for (int i = 0; i < drugListSize; i++) {
            orderInput.setOrder(multiOrderInput.getOrder());
            orderInput.setDrug(multiOrderInput.getDrugList().get(i));

            String input = wrapperUtils.buildInputOrder(orderInput, siteId, prescriberObject);

            ServiceResponse inputAcceptResp = workflowClient.inputAccept(input);
            Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
            Assert.assertFalse(inputAcceptResp.getDataResponse().contains("error"), "Input Accept could not be completed");
            InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
            helperClient.logOrderDetails(inputResp);
            am.performSleep(10);

            int nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
            if (nxtWrkQueCode != WorkQueueCode.CHKDUR.getWorkQueueCode()) {
                helperClient.performDowntime(siteId, inputResp);
            }

            ServiceResponse chkDURCompleteResp = workflowClient.chkDURComplete(inputAcceptResp.getDataResponse());
            Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
            Assert.assertFalse(chkDURCompleteResp.getDataResponse().contains("error"), "Check DUR could not be completed");
            InputResponse chkDURCompleteInputResp = inputAcceptResp.getDataResponse(InputResponse.class);
            am.performSleep(30);

            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, chkDURCompleteInputResp.getRxFillId());
            if (nxtWrkQueCode != WorkQueueCode.CHKDUR.getWorkQueueCode()) {
                helperClient.performDowntime(siteId, chkDURCompleteInputResp);
            }

            ServiceResponse fillCompleteResp = workflowClient.fillComplete(chkDURCompleteResp.getDataResponse());
            Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
            Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Filling could not be completed");
            am.performSleep(5);

            ServiceResponse vvCompleteResp = workflowClient.vvComplete(fillCompleteResp.getDataResponse());
            Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "vvComplete API response status code did not match");
            Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");
            Reporter.log("Order successfully moved to Pickup queue");
            am.performSleep(5);

            ServiceResponse pickupCompleteResp = workflowClient.pickupComplete(vvCompleteResp.getDataResponse());
            Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "pickUpComplete API response status code did not match");
            Assert.assertFalse(pickupCompleteResp.getDataResponse().contains("error"), "pickUp could not be completed");
            am.performSleep(5);

            ServiceResponse counselCompleteResp = workflowClient.counselComplete(pickupCompleteResp.getDataResponse());
            Assert.assertEquals(counselCompleteResp.getStatusCode(), 302, "counsel API response status code did not match");
            Assert.assertFalse(counselCompleteResp.getDataResponse().contains("error"), "counsel could not be completed");
            am.performSleep(5);
            InputResponse counselCompleteInputResp = counselCompleteResp.getDataResponse(InputResponse.class);

            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, counselCompleteInputResp.getRxFillId());
            if (nxtWrkQueCode != WorkQueueCode.POS.getWorkQueueCode()) {
                helperClient.performDowntime(siteId, counselCompleteInputResp);
            }

            ServiceResponse posCompleteResp = workflowClient.posComplete(counselCompleteResp.getDataResponse());
            Assert.assertEquals(posCompleteResp.getStatusCode(), 302, "POS API response status code did not match");
            Assert.assertFalse(posCompleteResp.getDataResponse().contains("error"), "POS could not be completed");
            multiRxPaymentCompleteResp.add(posCompleteResp.getDataResponse(InputResponse.class));
        }
        
        return multiRxPaymentCompleteResp;
    }

    /**
     * Creates order and moves to pickup queue (with prescriber info).
     * Package-visible for use by PartialWorkflowClient.
     */
    public ServiceResponse orderToPickup(int siteId, int patientId, int priorityId, 
            int requestTypeCode, int dispenseType, int numRefills, String inputPickupDate, 
            int clinicId, String inputRxExpDate, DataRow drugInfo, DataRow prescriber) {
        
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = new HashMap<>();
        
        TillPickupRequest orderPickupRequest = new TillPickupRequest();
        String phoneNbr = StringUtils.phoneNumberGenerator();
        
        hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Drug drug = 
                new hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Drug();
        
        orderPickupRequest.setRequestTypeCode(requestTypeCode);
        orderPickupRequest.setPriorityId(priorityId);
        orderPickupRequest.setDispenseType(dispenseType);
        orderPickupRequest.setPatientId(patientId);
        orderPickupRequest.setSiteID(siteId);
        orderPickupRequest.setInputPickUpDate(inputPickupDate);
        orderPickupRequest.setInputRxExpDate(inputRxExpDate);
        orderPickupRequest.setNumRefills(numRefills);
        
        drug.setGpiCode(drugInfo.getValue("gpi_code"));
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr"));
        drug.setItemId(drugInfo.getValue("mds_fam_id"));
        drug.setRxProdId(Integer.parseInt(drugInfo.getValue("product_mds_fam_id").toString().trim()));
        drug.setControlCode(Integer.parseInt(drugInfo.getValue("drug_control_code").toString()));
        drug.setOnHandQty(Integer.parseInt(prop.getProperty("fom.OnHandQty")));
        drug.setUsualCost(prop.getProperty("fom.usualCost"));
        drug.setActCost(prop.getProperty("fom.actCost"));
        drug.setOrgUsualCost(prop.getProperty("fom.orgUsualCost"));
        orderPickupRequest.setDrug(drug);
        
        req.setRequestPayloadWithNulls(orderPickupRequest);
        req.setUrl(prop.getProperty("fom.connexusWrapper.createOrderTillPickupUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        
        Reporter.log("OrderTillPickup Request endpoint: " + req.getUrl());
        Reporter.logJSON("OrderTillPickup Request", orderPickupRequest);
        Log.info("OrderTillPickup RequestPayload:\n" + req.getRequestPayload() + "\n");
        
        ServiceResponse resp = am.getRestContext().performPost(req, 3);
        
        Reporter.logJSON("OrderTillPickup Response", resp.getDataResponse());
        Log.info("OrderTillPickup ResponsePayload:\n" + resp.getDataResponse() + "\n");
        
        return resp;
    }

    /**
     * Creates order and drop-off with prescriber and rxOriginCode.
     */
}
