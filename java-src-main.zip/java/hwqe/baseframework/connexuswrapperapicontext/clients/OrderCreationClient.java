package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Drug;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.DropOffQueueRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.openjdk.tools.sjavac.Log;

import java.util.HashMap;

/**
 * Client for Order Creation and Drop-off operations.
 * 
 * Handles:
 * - Creating orders with drop-off
 * - Order drop-off API calls
 * 
 * Extracted from ConnexusAPIManager to follow Single Responsibility Principle.
 */
public class OrderCreationClient {

    private final AutomationManager am;
    private final PropertyReader prop;

    public OrderCreationClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
    }

    /**
     * Constructor for dependency injection (testability).
     */
    public OrderCreationClient(AutomationManager am, PropertyReader prop) {
        this.am = am;
        this.prop = prop;
    }

    // ========== Order Creation ==========

    /**
     * Creates an order and performs drop-off (without fill quantity).
     */
    public ServiceResponse createOrderAndDropOff(int requestTypeCode, int priorityId, int dispenseType,
            int patientId, int storeNbr, String inputPickUpDate, String inputRxExpDate, 
            int numRefills, DataRow drugInfo) {
        return createOrderAndDropOff(0, requestTypeCode, priorityId, dispenseType, patientId, storeNbr,
                inputPickUpDate, inputRxExpDate, numRefills, drugInfo);
    }

    /**
     * Creates an order and performs drop-off with specified fill quantity.
     */
    public ServiceResponse createOrderAndDropOff(int fillQuantity, int requestTypeCode, int priorityId, 
            int dispenseType, int patientId, int storeNbr, String inputPickUpDate, String inputRxExpDate, 
            int numRefills, DataRow drugInfo) {

        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildHeaders();

        DropOffQueueRequest dropoffRequest = buildDropOffRequest(requestTypeCode, priorityId, dispenseType,
                patientId, storeNbr, inputPickUpDate, inputRxExpDate, numRefills);
        
        Drug drug = buildDrugFromDataRow(drugInfo, fillQuantity);
        dropoffRequest.setDrug(drug);

        req.setRequestPayloadWithNulls(dropoffRequest);
        req.setUrl(prop.getProperty("fom.connexusWrapper.createOrderAndDropOffUrl"));
        req.setHeaders(headers);

        Reporter.log("CreateOrderAndDropOff Request endpoint: " + req.getUrl());
        Reporter.logJSON("CreateOrderAndDropOff Request", dropoffRequest);
        Log.info("CreateOrderAndDropOff RequestPayload:\n" + req.getRequestPayload() + "\n");

        ServiceResponse resp = am.getRestContext().performPost(req);

        Reporter.logJSON("CreateOrderAndDropOff Response", resp.getDataResponse());
        Log.info("CreateOrderAndDropOff ResponsePayload:\n" + resp.getDataResponse() + "\n");

        return resp;
    }

    /**
     * Creates an order and performs drop-off with prescriber information.
     */
    public ServiceResponse createOrderAndDropOffWithPrescriber(int requestTypeCode, int priorityId, 
            int dispenseType, int patientId, int storeNbr, String inputPickUpDate, String inputRxExpDate, 
            int numRefills, DataRow drugInfo, Prescriber prescriber, int rxOriginCode) {
        
        ServiceRequest req = new ServiceRequest();
        HashMap<String, String> headers = buildHeaders();
        
        DropOffQueueRequest dropoffRequest = buildDropOffRequest(requestTypeCode, priorityId, dispenseType,
                patientId, storeNbr, inputPickUpDate, inputRxExpDate, numRefills);
        dropoffRequest.setRxOriginCode(rxOriginCode);
        
        Drug drug = buildDrugFromDataRow(drugInfo, 0);
        dropoffRequest.setDrug(drug);
        dropoffRequest.setPrescriber(prescriber);

        req.setRequestPayloadWithNulls(dropoffRequest);
        req.setUrl(prop.getProperty("fom.connexusWrapper.createOrderAndDropOffUrl"));
        req.setHeaders(headers);
        
        Reporter.log("CreateOrderAndDropOff Request endpoint: " + req.getUrl());
        Reporter.logJSON("CreateOrderAndDropOff Request", dropoffRequest);
        Log.info("CreateOrderAndDropOff RequestPayload:\n" + req.getRequestPayload() + "\n");
        
        ServiceResponse resp = am.getRestContext().performPost(req);
        
        Reporter.logJSON("CreateOrderAndDropOff Response", resp.getDataResponse());
        Log.info("CreateOrderAndDropOff ResponsePayload:\n" + resp.getDataResponse() + "\n");
        
        return resp;
    }

    // ========== Helper Methods ==========

    /**
     * Builds standard headers for API requests.
     */
    private HashMap<String, String> buildHeaders() {
        HashMap<String, String> headers = new HashMap<>();
        headers.put("content-type", "application/json");
        return headers;
    }

    /**
     * Builds the base DropOffQueueRequest without drug info.
     */
    private DropOffQueueRequest buildDropOffRequest(int requestTypeCode, int priorityId, int dispenseType,
            int patientId, int storeNbr, String inputPickUpDate, String inputRxExpDate, int numRefills) {

        DropOffQueueRequest dropoffRequest = new DropOffQueueRequest();
        dropoffRequest.setRequestTypeCode(requestTypeCode);
        dropoffRequest.setPriorityId(priorityId);
        dropoffRequest.setDispenseType(dispenseType);
        dropoffRequest.setPatientId(patientId);
        dropoffRequest.setSiteID(storeNbr);
        dropoffRequest.setInputPickUpDate(inputPickUpDate);
        dropoffRequest.setInputRxExpDate(inputRxExpDate);
        dropoffRequest.setNumRefills(numRefills);
        dropoffRequest.setAllowExpiredOrder(true);

        return dropoffRequest;
    }

    /**
     * Builds Drug object from DataRow with optional fill quantity.
     */
    private Drug buildDrugFromDataRow(DataRow drugInfo, int fillQuantity) {
        Drug drug = new Drug();
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr").toString().trim());
        drug.setItemId(drugInfo.getValue("mds_fam_id"));
        drug.setRxProdId(drugInfo.getValue("product_mds_fam_id"));
        drug.setControlCode(drugInfo.getValue("drug_control_code"));
        drug.setPresMultiSrcCode(drugInfo.getValue("multi_source_code"));
        drug.setOnHandQty(Integer.parseInt(drugInfo.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
        drug.setGpiCode(drugInfo.getValue("gpi_code"));
        drug.setUsualCost("0");
        drug.setActCost("0");
        drug.setOrgUsualCost("0");

        if (fillQuantity > 0) {
            drug.setFillQty(fillQuantity);
        }

        return drug;
    }
}
