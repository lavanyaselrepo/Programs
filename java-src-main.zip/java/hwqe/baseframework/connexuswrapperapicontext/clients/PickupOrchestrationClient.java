package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.WorkQueueCode;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;

import java.util.ArrayList;

/**
 * Client for orchestrating order workflows that end at Pickup queue.
 * 
 * Handles complete workflows from drop-off through to Pickup (ready for customer):
 * DropOff → InputAccept → DUR → Fill → VV → Pickup
 * 
 * Unlike EODOrchestrationClient which goes all the way to POS completion,
 * this stops at the Pickup queue state.
 * 
 * Thread-safe: Uses method-local variables.
 * 
 * Extracted from OrderOrchestrationClient for Single Responsibility Principle.
 */
public class PickupOrchestrationClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final WrapperUtils wrapperUtils;
    private final DBUtils dbUtils;
    private final OrderWorkflowClient workflowClient;
    private final OrderCreationClient orderCreationClient;
    private final DowntimeClient downtimeClient;
    private final DrugInfoClient drugInfoClient;

    public PickupOrchestrationClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.wrapperUtils = new WrapperUtils();
        this.dbUtils = new DBUtils();
        this.workflowClient = new OrderWorkflowClient();
        this.orderCreationClient = new OrderCreationClient();
        this.downtimeClient = new DowntimeClient();
        this.drugInfoClient = new DrugInfoClient();
    }

    /**
     * Creates a new order and moves it to Pickup queue.
     * Returns [rxNbr, rxFillId, drugName, ndc].
     */
    public ArrayList<String> createNewOrderAndMoveToPickup(int patientId, int siteId, 
            String inputRxExpDate, String inputPickupDate, int numRefills, 
            DataRow drugInfo, String ndc) {
        
        inputPickupDate = wrapperUtils.getPickUpDate();
        inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(siteId);
        drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        ServiceResponse dropOffResp = orderCreationClient.createOrderAndDropOff(
                1600, 21104, 1, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        ServiceResponse inputAcceptResp = workflowClient.inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains("error"), "Input Accept could not be completed");
        InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        logOrderDetails(inputResp);

        int nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        if (nxtWrkQueCode != WorkQueueCode.CHKDUR.getWorkQueueCode()) {
            performDowntime(siteId, inputResp);
        }

        ServiceResponse chkDURCompleteResp = workflowClient.chkDURComplete(inputAcceptResp.getDataResponse());
        Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
        Assert.assertFalse(chkDURCompleteResp.getDataResponse().contains("error"), "Check DUR could not be completed");
        InputResponse checkDURInputResp = chkDURCompleteResp.getDataResponse(InputResponse.class);
        am.performSleep(30);

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, checkDURInputResp.getRxFillId());
        if (nxtWrkQueCode != WorkQueueCode.FILLING.getWorkQueueCode()) {
            performDowntime(siteId, checkDURInputResp);
        }

        ServiceResponse fillCompleteResp = workflowClient.fillComplete(chkDURCompleteResp.getDataResponse());
        Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Filling could not be completed");

        ServiceResponse vvCompleteResp = workflowClient.vvComplete(fillCompleteResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "VVComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");

        ArrayList<String> rxDetails = new ArrayList<>();
        rxDetails.add(String.valueOf(inputResp.getRxNbr()));
        rxDetails.add(String.valueOf(inputResp.getRxFillId()));
        rxDetails.add(drugInfo.getValue("short_name").toString().trim());
        rxDetails.add(drugInfo.getValue("ndc_nbr"));

        return rxDetails;
    }

    /**
     * Creates a new order and moves it to Pickup queue.
     * Simplified version with DUR bypass handling.
     */
    public InputResponse createNewOrderAndMoveToPickup(int patientId, int siteId, 
            int numRefills, String ndc) {
        
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        int requestTypeCode = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrderPriorityId"));
        int dispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));

        ServiceResponse dropOffResp = orderCreationClient.createOrderAndDropOff(
                requestTypeCode, priorityId, dispenseType, patientId, siteId, 
                inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");
        am.performSleep(30);

        ServiceResponse inputAcceptResp = workflowClient.inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains("error"), "Input Accept could not be completed");
        InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        logOrderDetails(inputResp);
        am.performSleep(80);

        int nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        ServiceResponse fillCompleteResp;
        InputResponse fillCompleteInputResp;

        if (nxtWrkQueCode == WorkQueueCode.CHKDUR.getWorkQueueCode()) {
            ServiceResponse chkDURCompleteResp = workflowClient.chkDURComplete(inputAcceptResp.getDataResponse());
            Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
            Assert.assertFalse(chkDURCompleteResp.getDataResponse().contains("error"), "Check DUR could not be completed");
            am.performSleep(30);

            fillCompleteResp = workflowClient.fillComplete(chkDURCompleteResp.getDataResponse());
            Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
            Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Filling could not be completed");
            fillCompleteInputResp = fillCompleteResp.getDataResponse(InputResponse.class);
            am.performSleep(5);

            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, fillCompleteInputResp.getRxFillId());
            if (nxtWrkQueCode != WorkQueueCode.VISUALVERIFY.getWorkQueueCode()) {
                performDowntime(siteId, fillCompleteInputResp);
            }
        } else if (nxtWrkQueCode == WorkQueueCode.FILLING.getWorkQueueCode()) {
            fillCompleteResp = workflowClient.fillComplete(inputAcceptResp.getDataResponse());
            Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
            Assert.assertFalse(fillCompleteResp.getDataResponse().contains("error"), "Filling could not be completed");
            fillCompleteInputResp = fillCompleteResp.getDataResponse(InputResponse.class);
            am.performSleep(5);

            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, fillCompleteInputResp.getRxFillId());
            if (nxtWrkQueCode == WorkQueueCode.RESOLVE.getWorkQueueCode()) {
                performDowntime(siteId, fillCompleteInputResp);
            }
            if (nxtWrkQueCode != WorkQueueCode.VISUALVERIFY.getWorkQueueCode()) {
                performDowntime(siteId, fillCompleteInputResp);
            }
        } else {
            // Default case - try to complete fill
            fillCompleteResp = workflowClient.fillComplete(inputAcceptResp.getDataResponse());
            Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        }

        ServiceResponse vvCompleteResp = workflowClient.vvComplete(fillCompleteResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "vvComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains("error"), "Visual Verify could not be completed");
        InputResponse inputVVResp = vvCompleteResp.getDataResponse(InputResponse.class);
        am.performSleep(5);
        Reporter.log("Order successfully moved to Pickup queue");
        
        return inputVVResp;
    }

    // ========== Helper Methods ==========

    private void logOrderDetails(InputResponse inputResp) {
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + 
                    ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());
    }

    private void performDowntime(int siteId, InputResponse respObj) {
        downtimeClient.downTime(respObj.getRxFillId(), respObj.getOrderId(), respObj.getOrderSeqNbr(),
                prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
    }
}
