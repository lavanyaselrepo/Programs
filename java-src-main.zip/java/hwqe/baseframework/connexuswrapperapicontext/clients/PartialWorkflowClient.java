package hwqe.baseframework.connexuswrapperapicontext.clients;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.WorkQueueCode;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Order;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.InputResponse;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Client for creating orders and moving them to intermediate workflow states.
 * 
 * Handles partial order workflows that stop at specific queue states:
 * - To 4-Point Check (INPUT)
 * - To Input Accept
 * - To DUR
 * - To Visual Verify
 * - To Counsel
 * 
 * Unlike full orchestration clients, these methods create orders but don't
 * complete the entire workflow to EOD or Pickup.
 * 
 * Thread-safe: Uses method-local variables.
 * 
 * Extracted from OrderOrchestrationClient for Single Responsibility Principle.
 */
public class PartialWorkflowClient {

    private final AutomationManager am;
    private final PropertyReader prop;
    private final WrapperUtils wrapperUtils;
    private final DBUtils dbUtils;
    private final OrderWorkflowClient workflowClient;
    private final OrderCreationClient orderCreationClient;
    private final DowntimeClient downtimeClient;
    private final DrugInfoClient drugInfoClient;
    private final PrescriberClient prescriberClient;

    public PartialWorkflowClient() {
        this.am = AutomationManager.getInstance();
        this.prop = PropertyReader.getInstance();
        this.wrapperUtils = new WrapperUtils();
        this.dbUtils = new DBUtils();
        this.workflowClient = new OrderWorkflowClient();
        this.orderCreationClient = new OrderCreationClient();
        this.downtimeClient = new DowntimeClient();
        this.drugInfoClient = new DrugInfoClient();
        this.prescriberClient = new PrescriberClient();
    }

    // ========== Workflows to 4-Point Check ==========

    /**
     * Creates order and moves to 4-point check queue (INPUT state).
     * Returns [rxNbr, rxFillId].
     */
    public ArrayList<String> createOrderAndMoveTo4Pt(int patientId, int siteId, 
            int numRefills, String ndc) {
        
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        int orderReqType = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrdPriorityId"));
        int orderDispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));

        ServiceResponse dropOffResp = orderCreationClient.createOrderAndDropOff(
                orderReqType, priorityId, orderDispenseType, patientId, siteId, 
                inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        ServiceResponse inputAcceptResp = workflowClient.inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains("error"), "Input Accept could not be completed");
        InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        logOrderDetails(inputResp);

        ArrayList<String> rxDetails = new ArrayList<>();
        rxDetails.add(String.valueOf(inputResp.getRxNbr()));
        rxDetails.add(String.valueOf(inputResp.getRxFillId()));
        return rxDetails;
    }

    /**
     * Creates order and moves to 4-point check queue, returning full response.
     */
    public ServiceResponse createOrderAndMoveTo4PtAsResponse(int patientId, int siteId, 
            int numRefills, String ndc) {
        
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        int orderReqType = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrderPriorityId"));
        int orderDispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));

        ServiceResponse dropOffResp = orderCreationClient.createOrderAndDropOff(
                orderReqType, priorityId, orderDispenseType, patientId, siteId, 
                inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        ServiceResponse inputAcceptResp = workflowClient.inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains("error"), "Input Accept could not be completed");
        InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        dropOffResp.setJsonElement("rxNbr", inputResp.getRxNbr());
        logOrderDetails(inputResp);
        
        return dropOffResp;
    }

    // ========== Workflows to Input Accept ==========

    /**
     * Creates a new order and moves it to Input Accept queue.
     */
    public InputResponse createNewOrderAndMoveToInputAccept(int patientId, int siteId, 
            int numRefills, DataRow drugInfo, String ndc) {
        
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(siteId);
        drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        ServiceResponse dropOffResp = orderCreationClient.createOrderAndDropOff(
                1600, 21104, 1, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        ServiceResponse inputAcceptResp = workflowClient.inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains("error"), "Input Accept could not be completed");
        InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        logOrderDetails(inputResp);
        
        return inputResp;
    }

    // ========== Workflows to Counsel ==========

    /**
     * Creates a new order and moves it to Counsel queue.
     */
    public InputResponse createNewOrderToCounsel(int patientId, int siteId, int numRefills, 
            String ndc, String presName, String presFName, String presLName, String presPhone, 
            String state, int prescriberID, int rxClinicId, int rxOriginCode) {
        
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        Prescriber prescriber = prescriberClient.buildPrescriber(presName, presFName, presLName, presPhone, 
                state, prescriberID, rxClinicId);

        DataRow prescriberRow = prescriberClient.getPrescriberInfo(cnx, prescriberID);
        
        // Delegate to OrderOrchestrationClient for orderToPickup (complex private method)
        OrderOrchestrationClient orchClient = new OrderOrchestrationClient();
        ServiceResponse resp = orchClient.orderToPickup(siteId, patientId, 21104, 1600, 1, 
                numRefills, inputPickupDate, rxClinicId, inputRxExpDate, drugInfo, prescriberRow);
        Assert.assertEquals(resp.getStatusCode(), 201, "The order cannot be created and drop till pickup" + resp.getDataResponse());

        ServiceResponse pickupCompleteResp = workflowClient.pickupComplete(resp.getDataResponse());
        Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "PickupComplete API response status code did not match");
        Assert.assertFalse(pickupCompleteResp.getDataResponse().contains("error"), "Pickup could not be completed");
        InputResponse inputResp = pickupCompleteResp.getDataResponse(InputResponse.class);
        logOrderDetails(inputResp);
        
        return inputResp;
    }

    // ========== Workflows to DUR ==========

    /**
     * Creates a new order and moves it to DUR queue.
     */
    public InputResponse createNewOrderToDur(int patientId, int siteId, int numRefills, 
            String ndc, String presName, String presFName, String presLName, String presPhone, 
            String state, int prescriberID, int rxClinicId, String rxOriginCode) {
        
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        Prescriber prescriber = prescriberClient.buildPrescriber(presName, presFName, presLName, presPhone, 
                state, prescriberID, rxClinicId);

        ServiceResponse createNewOrderToPickupResp = orderCreationClient.createOrderAndDropOffWithPrescriber(
                1600, 21104, 1, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, 
                drugInfo, prescriber, Integer.parseInt(rxOriginCode));
        Assert.assertEquals(createNewOrderToPickupResp.getStatusCode(), 201, "createOrderToPickup API response status code did not match");

        ServiceResponse inputAcceptResp = workflowClient.inputAccept(createNewOrderToPickupResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains("error"), "Input Accept could not be completed");
        InputResponse inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        logOrderDetails(inputResp);

        int nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        if (nxtWrkQueCode == WorkQueueCode.RESOLVE.getWorkQueueCode()) {
            performDowntime(siteId, inputResp);
        }
        am.performSleep(30);

        ServiceResponse chkDURCompleteResp = workflowClient.chkDURComplete(inputAcceptResp.getDataResponse());
        Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
        Assert.assertFalse(chkDURCompleteResp.getDataResponse().contains("error"), "Check DUR could not be completed");
        inputResp = chkDURCompleteResp.getDataResponse(InputResponse.class);
        am.performSleep(60);
        
        return inputResp;
    }

    // ========== Workflows to VV ==========

    /**
     * Creates a new order and moves it to Visual Verify queue.
     */
    public InputResponse createNewOrderToVV(int patientId, int siteId, int numRefills, 
            String ndc, String presName, String presFName, String presLName, String presPhone, 
            String state, int prescriberID, int rxClinicId, int rxOriginCode) {
        
        String inputPickupDate = wrapperUtils.getPickUpDate();
        String inputRxExpDate = wrapperUtils.getExpiryDate();

        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow drugInfo = drugInfoClient.getDrugInfo(cnx, ndc);

        Prescriber prescriber = prescriberClient.buildPrescriber(presName, presFName, presLName, presPhone, 
                state, prescriberID, rxClinicId);

        DataRow prescriberRow = prescriberClient.getPrescriberInfo(cnx, prescriberID);
        
        // Delegate to OrderOrchestrationClient
        OrderOrchestrationClient orchClient = new OrderOrchestrationClient();
        ServiceResponse resp = orchClient.orderToPickup(siteId, patientId, 21104, 1600, 1, 
                numRefills, inputPickupDate, rxClinicId, inputRxExpDate, drugInfo, prescriberRow);
        Assert.assertEquals(resp.getStatusCode(), 201, "The order cannot be created and drop till pickup" + resp.getDataResponse());

        InputResponse inputResp = resp.getDataResponse(InputResponse.class);
        logOrderDetails(inputResp);
        
        return inputResp;
    }

    // ========== Helper Methods ==========

    private void logOrderDetails(InputResponse inputResp) {
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + 
                    ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());
    }

    private void performDowntime(int siteId, InputResponse respObj) {
        downtimeClient.downTime(respObj.getRxFillId(), respObj.getOrderId(), respObj.getOrderSeqNbr(),
                prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
    }
}
