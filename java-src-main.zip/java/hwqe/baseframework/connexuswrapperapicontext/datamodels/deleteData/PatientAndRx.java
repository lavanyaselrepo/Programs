package hwqe.baseframework.connexuswrapperapicontext.datamodels.deleteData;

import java.util.List;

@lombok.Getter
@lombok.Setter
public class PatientAndRx {

    private int siteID;
    private List<Integer> patientID;
    private List<Integer> orderID;
}
