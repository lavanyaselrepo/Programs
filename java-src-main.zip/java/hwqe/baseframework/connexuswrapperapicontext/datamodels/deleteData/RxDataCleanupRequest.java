package hwqe.baseframework.connexuswrapperapicontext.datamodels.deleteData;
@lombok.Getter
@lombok.Setter
public class RxDataCleanupRequest {

    private int siteId;
    private int rxDeletionInDays;
}
