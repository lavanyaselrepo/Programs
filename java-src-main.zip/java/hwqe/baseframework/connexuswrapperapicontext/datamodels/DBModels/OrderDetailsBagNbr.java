package hwqe.baseframework.connexuswrapperapicontext.datamodels.DBModels;

@lombok.Getter
@lombok.Setter
public class OrderDetailsBagNbr {
    public int order_bag_id;
    public int rx_fill_id;
    public int tote_nbr;
    public int order_id;
    public int next_work_que_code;
    public int ho_espn_stat_code;
    public int store_tran_id;
    public String vndr_shpmt_id;
    public int order_seq_nbr;
}
