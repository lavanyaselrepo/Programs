package hwqe.baseframework.connexuswrapperapicontext.datamodels.DBModels.EasyPay;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;

@Getter
@Setter
public class updateEasyPayCard {

    public String patientId;
    public String storeNbr;
    public ArrayList<PatientPaymentInfo> patientPaymentInfo;
}
