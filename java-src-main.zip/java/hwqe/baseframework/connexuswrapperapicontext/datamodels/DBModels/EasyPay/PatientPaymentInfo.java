package hwqe.baseframework.connexuswrapperapicontext.datamodels.DBModels.EasyPay;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PatientPaymentInfo {
    public String phmPymtAcctId;
    public String cardSeqNbr;
    public String pymtFreqCode;
    public String relationshipCode;
    public String startDate;
    public String expirYearNbr;
    public String expirMoNbr;
    public String cardHolderName;
    public String phmPymtMthdCode;
    public String billingAddrTxt;
    public String cityName;
    public String postalCode;
    public String stateProvCode;
    public String routingNbr;
    public String phoneNbr;
    public String cardRefNbr;
    public String cardSuffixNbr;
    public String lastChangeUserId;
    public String signatureFrequencyCode;
    public String p2peToken;
}
