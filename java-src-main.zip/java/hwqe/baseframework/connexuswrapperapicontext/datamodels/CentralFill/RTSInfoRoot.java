package hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill;

@lombok.Data
@lombok.Builder

public class RTSInfoRoot {
    public String asnNbr;
    public String rxToken;
    public boolean printLabel;
    public boolean reprint;
}