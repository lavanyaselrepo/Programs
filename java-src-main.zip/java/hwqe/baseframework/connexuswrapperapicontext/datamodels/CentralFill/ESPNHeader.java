package hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill;

@lombok.Data
@lombok.Builder
public class ESPNHeader {
    public String request_tracking_id;
    public String request_id;
    public int store_nbr;
    public Object store_tran_id;
    public String msg_type;
    public int request_type_code;
    public String request_type_desc;
    public String request_ts;
    public String version;
}
