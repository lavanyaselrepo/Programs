package hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill;

@lombok.Data
@lombok.Builder
public class ESPNData {
    public String azure_tran_id;
    public long cf_facility_nbr;
    public String cf_facility_tran_id;
    public ESPNShipmentDetails shipment_details;
}
