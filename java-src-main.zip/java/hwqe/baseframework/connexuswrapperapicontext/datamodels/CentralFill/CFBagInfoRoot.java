package hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill;

@lombok.Data
@lombok.Builder
public class CFBagInfoRoot {
    public String asnNbr;
    public String rxToken;
    public long toteNbr;
}
