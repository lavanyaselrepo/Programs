package hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

@lombok.Data
@lombok.Builder
public class ESPNShipmentDetails {
    @JsonProperty("ASN_details")
    public List<ESPNASNDetail> ASN_details;
}
