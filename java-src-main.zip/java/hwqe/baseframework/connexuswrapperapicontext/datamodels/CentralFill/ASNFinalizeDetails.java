package hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill;

@lombok.Builder
public class ASNFinalizeDetails {
    public String description;
    public int code;
}
