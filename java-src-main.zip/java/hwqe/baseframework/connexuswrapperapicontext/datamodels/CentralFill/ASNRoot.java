package hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill;

@lombok.Data
@lombok.Builder
public class ASNRoot {
    public String asnNbr;
    public boolean override;
}
