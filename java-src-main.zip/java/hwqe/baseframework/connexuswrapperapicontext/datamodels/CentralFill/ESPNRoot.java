package hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill;

@lombok.Data
@lombok.Builder
public class ESPNRoot {
    public ESPNHeader header;
    public ESPNData data;
}
