package hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill;

import java.util.List;

@lombok.Data
@lombok.Builder
public class ESPNASNDetail {
    public String asn_nbr;
    public String asn_final_ts;
    public long cf_shipment_id;
    public String est_arrival;
    public String drug_tracking_txt;
    public int fill_cnt;
    public List<ESPNBag> bags;
}
