package hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill;

@lombok.Data
@lombok.Builder
public class ESPNFill {
    public int store_tran_id;
    public int fill_id;
    public String ndc_nbr;
    public String fill_date;
    public int fill_qty;
    public String tech_of_rec_id;
    public String rph_of_rec_id;
    public String packer_of_rec_id;
    public String tech_of_rec_desc;
    public String rph_of_rec_desc;
    public String packer_of_rec_desc;
    public String tech_of_rec_st_ts;
    public String rph_of_rec_end_ts;
    public String packer_of_rec_end_ts;
}
