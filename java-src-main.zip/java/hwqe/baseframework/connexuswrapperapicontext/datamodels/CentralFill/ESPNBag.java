package hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill;

import java.util.List;

@lombok.Data
@lombok.Builder
public class ESPNBag {
    public long bag_nbr;
    public List<ESPNFill> fills;
}
