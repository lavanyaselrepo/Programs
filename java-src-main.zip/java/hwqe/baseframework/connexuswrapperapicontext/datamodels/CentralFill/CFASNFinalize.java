package hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill;

@lombok.Data
@lombok.Builder
public class CFASNFinalize {
    public String asnNbr;
    public ASNFinalizeDetails action;
}
