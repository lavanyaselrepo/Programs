package hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill;

import java.util.List;

@lombok.Data
@lombok.Builder
public class CFAsnInfoRoot {
    public String asnNbr;
    public List<String> rxTokens;
}

