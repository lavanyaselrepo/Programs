package hwqe.baseframework.connexuswrapperapicontext.datamodels.tillFilling;

import hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Drug;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Prescriber;
import lombok.Data;

@Data
@lombok.Getter
@lombok.Setter
public class TillFillingRequest {

    private Prescriber prescriber;
    private boolean allowExpiredOrder;
    private int patientId;
    private int siteID;
    private String inputRxExpDate;
    private int numRefills;
    private int dispenseType;
    private String inputPickUpDate;
    private int requestTypeCode;
    private int priorityId;
    private Drug drug;
}
