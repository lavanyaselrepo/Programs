package hwqe.baseframework.connexuswrapperapicontext.datamodels.tillFilling;

import java.util.ArrayList;

@lombok.Getter
@lombok.Setter
public class MultiRxOrderToFillingResponse extends ArrayList<MultiRxWrapperItem> {}
