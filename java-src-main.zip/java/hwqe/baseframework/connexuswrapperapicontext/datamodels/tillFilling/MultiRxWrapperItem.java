package hwqe.baseframework.connexuswrapperapicontext.datamodels.tillFilling;

import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Order;

import java.util.List;

@lombok.Getter
@lombok.Setter
public class MultiRxWrapperItem {
    private List<Order> order;
}
