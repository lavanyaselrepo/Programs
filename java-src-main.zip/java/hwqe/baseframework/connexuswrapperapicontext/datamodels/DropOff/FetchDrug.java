package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

@lombok.Getter
@lombok.Setter
public class FetchDrug {
    private String siteId;
    private String ndc;
}
