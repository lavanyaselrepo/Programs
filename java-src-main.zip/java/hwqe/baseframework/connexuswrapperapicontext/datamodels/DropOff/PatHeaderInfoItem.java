package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class PatHeaderInfoItem{
	private int SiteID;
	private int patientId;
	private int OrderId;
}
