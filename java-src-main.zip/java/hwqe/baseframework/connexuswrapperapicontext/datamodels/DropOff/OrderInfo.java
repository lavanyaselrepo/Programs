package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;
@lombok.Getter
@lombok.Setter
public class OrderInfo {

    private int siteId;
    private int rxFillId;
}
