package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

import lombok.Getter;
import lombok.Setter;
import java.util.List;

@Getter
@Setter
public class CreateOrderforRefillResponse {

    public int orderId;
    public int packId;
    public List<Object> patList;
}