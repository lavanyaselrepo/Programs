package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

@lombok.Getter
@lombok.Setter
public class Drug {
	
	 private String name;
	 private String ndc;
	 private int itemId;
	 private int rxProdId;
	 private short controlCode;
	 private short presMultiSrcCode;
	 private int onHandQty;
	 private String gpiCode;
	 private String usualCost;
	 private String actCost;
	 private String orgUsualCost;
	 private int rxNbr;
	 private int rxFillId;
	 private int fillQty;
}
