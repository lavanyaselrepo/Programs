package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

import lombok.Getter;
import org.assertj.core.util.DateUtil;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

@Getter
public class DropOffConstants {
    public static final int REQUEST_TYPE_CODE = 1600;
    public static final int DISPENSE_TYPE = 1;
    public static final int NUM_REFILLS = 0;

    public static String getPickupDate(){
        Date date = DateUtil.tomorrow();
        Calendar cal =Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE,1);
        date = cal.getTime();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        String rxPickupDate=date.toString().substring(4, 10)+" "+date.toString().substring(24,28)+" 18:00:00.000 UTC";
        return rxPickupDate;
    }

    public static String getExpiryDate(){
        Date date = DateUtil.tomorrow();
        Calendar cal =Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.YEAR,1);
        date = cal.getTime();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        String rxExpDate=date.toString().substring(4, 10)+" "+date.toString().substring(24,28)+" 18:00:00.000 UTC";
        return  rxExpDate;
    }
}
