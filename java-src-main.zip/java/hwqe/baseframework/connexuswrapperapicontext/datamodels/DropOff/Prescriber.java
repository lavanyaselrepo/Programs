package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

@lombok.Getter
@lombok.Setter
public class Prescriber {
    private String fullname;
    private String firstname;
    private String lastname;
    private String phone;
    private String state;
    private int prescriberId;
    private int rxClinicId;
    private String dea;
    private String npi;
}
