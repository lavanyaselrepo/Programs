package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;
@lombok.Getter
@lombok.Setter
public class GetOrderInfo {

    private int siteId;
    private int rxFillId;
}
