package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

import hwqe.baseframework.utilities.DateUtils;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class AcceptDropOff{
    private Object BeeperId;
    private Object Comment;
    private int SiteID;
    private int PatientId;
    private List<OrderInfoItem> OrderInfo;
    private Object DBSiteId;
    private boolean IsPatientVisit;
    private boolean ForceUpdateEPT;
    private int OrderId;
    private String PickupDate;
    private Object UTCOffSet;
    private List<PatHeaderInfoItem> PatHeaderInfo;
    private Object OrderUUID;
    private String PromiseTime;
    private int DispenseType;
    private Object IgnoreUserDescription;
    private String UserId;
    private boolean IsTestingCovid;
    private boolean IsDiagnosticTest;
    private Object PackageId;
    private Object RxNotesText;
    private int PriorityId;

    public int getPriorityId() {
        if (PriorityId == 0) {

            return 21104;
        }
        return PriorityId;
    }
    public void setPriorityId(int priorityId) {
        this.PriorityId = priorityId;
    }

    public String getPickupDate(int priorityId){
        return DateUtils.returnDateBasedOnPriorityId(priorityId);
    }

    public void setPickupDate(String pickupDate){
        this.PickupDate = pickupDate;
    }
}