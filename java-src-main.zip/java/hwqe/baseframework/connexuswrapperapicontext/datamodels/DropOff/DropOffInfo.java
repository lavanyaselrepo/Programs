package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class DropOffInfo{
	private boolean aRPayment;
	private boolean itemStatus;
	private boolean multipleSourceCode;
	private int carrierCoId;
	private boolean isCompound;
	private int rxId;
	private String cardholderId;
	private boolean restrictedSplitBill;
	private int cardExpIndex;
	private int statusCode;
	private boolean tPChanged;
	private Object priceClassMissingNDC;
	private String accutaneReFill;
	private String dispensedProdName;
	private Object rxUUID;
	private int daysSupply;
	private boolean isAccutaneItem;
	private int drugStatusCode;
	private int requestTypeCode;
	private boolean isAutoRefillInd;
	private boolean splitBill;
	private int orderSeqNbr;
	private int orderId;
	private String beforeIntervalFill;
	private int billingError;
	private String productsWithOutItems;
	private Object orderUUID;
	private String eRxIndicator;
	private int insCarrierPlanId;
	private String ndcNbr;
	private boolean cardExpIndicator;
	private int packageId;
	private int txnAmt;
	private Object pricingErrorText;
	private int rxFillId;
	private Object orderLineItemID;
}
