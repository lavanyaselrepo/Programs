package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

import hwqe.baseframework.utilities.DateUtils;
import lombok.Getter;
import lombok.Setter;

import java.util.Calendar;
import java.util.Date;

@Getter
@Setter
public class DropOffCreateReFill {
    public int RxId;
    public int OrderId;
    public int PriorityId;
    public String PickupTime;
    public String UserId;
    public String WorkStationHostName;
    public Object LastFillCarrierId;
    public Object OverWriteTP;
    public Object FutureChargeIndicator;
    public Object FutureMailIndicator;
    public int PhmProblemCode;
    public int ResponseId;
    public int RequestTypeCode;
    public boolean FillQtyExceedsPrescribed;
    public Object NewCarrierId;
    public boolean RefillFromDropOff;
    public boolean CPRSync;
    public Object PaymentInfoList;
    public int PatientId;
    public Object FillLastPaymentInfo;
    public int PhmResolutionMode;
    public Object OrderUUID;
    public Object RxUUID;
    public int SiteId;


    public int getPriorityId() {
        if (PriorityId == 0) {

            return 21104;
        }
        return PriorityId;
    }

    public void setPriorityId(int priorityId) {
        this.PriorityId = priorityId;
    }

    public String getPickupTime(int priorityId) {
        return DateUtils.returnDateBasedOnPriorityId(priorityId);
    }

    public void setPickupTime(String pickupTime) {
        this.PickupTime = pickupTime;
    }
}