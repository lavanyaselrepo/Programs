package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DropOffCreateReFillResponse {
    private DropOffInfo dropOffInfo;
}