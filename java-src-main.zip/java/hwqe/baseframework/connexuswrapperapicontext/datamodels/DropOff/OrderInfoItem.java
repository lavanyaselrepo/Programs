package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class OrderInfoItem{
	private int SiteID;
	private int rxId;
	private int orderId;
	private int patientId;
	private int rxFillId;
	private int OrderSeqNbr;
	private int PriorityId;
	private String WorkStationName;
}
