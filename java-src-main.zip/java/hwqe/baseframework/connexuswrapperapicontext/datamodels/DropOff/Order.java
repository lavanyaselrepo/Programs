package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

@lombok.Getter
@lombok.Setter
public class Order {
    public int requestTypeCode ; // request_type_code -> rx21c: rx_order_detail where rx_fill_id
    public int priorityId ; // priority_id -> rx21c: rx_order_detail where rx_fill_id
    private boolean changeMode;
    private int patientId; // patient_id -> rx21c: rx where rx_nbr
    private int orderId; // order_id -> rx21c: rx_order_detail where rx_fill_id
    private int packId;
    private int packageId; // phm_package_id -> rx21c: ord_sfs_trans where order_id
    private boolean visible;
    private int selectedIndex;
    private int selectedValue;
    private int tempPriority; // = priorityId
    private String controlDate;
    private int siteID;
    private String pickUpDate;
    private int rxFillId;
    private int rxId; // rx_id -> rx21c: rx_fill where rx_fill_id
    private int orderSeqNbr; // order_seq_nbr -> rx21c: rx_order_detail where rx_fill_id
    private int inputId; // input_id -> rx21c: rx where rx_id
    private int rxNbr;
    private int orgPriorityId; // = priorityId
    private String fillDate; // fill_date -> rx21c: rx_fill where rx_fill_id
    private String rxWrittenDate; // rx_written_date -> rx21c: rx where rx_id/rx_nbr
    private int requestSeqNbr; // rx_version_seq_nbr -> rx21c: rx_fill where rx_fill_id [CHECK]
    private String rxExpDate; // rx_exp_date -> rx21c: rx where rx_id/rx_nbr
    //private String NDCNumber;
    private String inputPickUpDate; // actual_pickup_ts -> rx21c: rx_order_detail where rx_fill_id [CHECK]
    private String inputRxExpDate; // rx_exp_date -> rx21c: rx where rx_id/rx_nbr
    private int requestId; // rx21c: rx_request where rx_id
    private int dispenseType;
    private boolean updateFillViaDB=false;
    private int toteNumber; // select tote_nbr from rx21c: rx_order_detail where rx_fill_id
    private int numRefills;
    private Drug drug;
    public Prescriber prescriber;
    private boolean allowExpiredOrder;
    private int productMdsFamId;
    private String omsOfferId;
    private String omsWtxCode;
    //private String rxInfo;
    private RxInfo rxInfo;
    //@Enumerated(EnumType.STRING)
    //private WorkQueueSettings workQueue;
    private String workQueue;
    private String exceptionDetails;
    //private boolean isShippingSuccessful;
    //private String shippingResponseData;
    //private boolean isPatientHasInsurance;
    //private boolean orderTypeERx=false;
}
