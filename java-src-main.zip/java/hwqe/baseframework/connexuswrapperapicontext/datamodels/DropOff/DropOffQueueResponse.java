package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

@lombok.Getter
@lombok.Setter
public class DropOffQueueResponse {

	private int requestTypeCode;
	private int orderId;
	private int siteID;
	private String pickUpDate;
	private int rxFillId;
	private int rxId;
	private int orderSeqNbr;
	private int inputId;
	private String fillDate;
	private String rxWrittenDate;
	private String rxExpDate;
	private String inputPickUpDate;
	private String inputRxExpDate;
}
