package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;
@lombok.Getter
@lombok.Setter
public class RxInfo {

    private String expSigTxt;
    private String originalExpSigTxt;
    private String orgPresSigTxt;
    private String presSigTxt;
    private int onHand;
    private double prescQty;
    private int labelerId;
    private double orgPrescQty;
    private int fillQty;
    private int fillDaysQty;
    private int orgFillDaysQty;
    private int remainingQty;
    private String addressLine1;
    private String homePhone;
    private String patCSZ;
    private String originalPatientName;
    private String requestTypeDescription;
    private int dawCode;
    private int orgDawCode;
    private int fillTypeCode;
    private int orgFillTypeCode;
    private double expectedSaleAmt;
    private int priceClassCode;
    private double taxAmt;
    private double markupAmt;
    private double usualPriceAmt;
    private String dawDesc;
    private int inputSourceCode;
    private int eRxRespTypeCode;
    private int eRxResponseId;
    private double innerPack;
    private String petRxParams;
}
