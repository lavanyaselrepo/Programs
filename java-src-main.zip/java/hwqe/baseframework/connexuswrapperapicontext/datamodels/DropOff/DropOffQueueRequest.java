package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

@lombok.Getter
@lombok.Setter
public class DropOffQueueRequest {
	
	 private int requestTypeCode;
	 private int priorityId;
	 private int dispenseType;
	 private int patientId;
	 private int siteID;
	 private String inputPickUpDate;
	 private String inputRxExpDate;
	 private int numRefills;	 
	 Drug drug;
	 Prescriber prescriber;
	 private int rxOriginCode;
	 private boolean allowExpiredOrder;
}
