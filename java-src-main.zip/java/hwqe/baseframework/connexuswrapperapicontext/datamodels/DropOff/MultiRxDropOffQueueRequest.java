package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

import java.util.List;

@lombok.Getter
@lombok.Setter
public class MultiRxDropOffQueueRequest {
    public Order order;
    public List<Drug> drugList;
}
