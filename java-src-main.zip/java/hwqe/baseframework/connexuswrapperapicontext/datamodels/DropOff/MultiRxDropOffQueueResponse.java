package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

import java.util.List;

@lombok.Getter
@lombok.Setter
public class MultiRxDropOffQueueResponse {
    public Order order;
    private List<Drug> drugList;
}
