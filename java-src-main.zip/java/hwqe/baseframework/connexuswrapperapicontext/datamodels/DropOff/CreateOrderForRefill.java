package hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff;

import hwqe.baseframework.utilities.DateUtils;
import lombok.Getter;
import lombok.Setter;

import java.util.*;

@Setter
@Getter
public class CreateOrderForRefill {
    public boolean ChangeMode;
    public int PatientId;
    public int OrderId;
    public int PackId;
    public List<Object> PatList;
    public boolean IsBatchingEnabled;
    public boolean Visible;
    public int SelectedIndex;
    public int SelectedValue;
    public int TempPriority;
    public String ControlDate;
    public int SiteID;

    public CreateOrderForRefill() {
        this.PatList = new ArrayList<>();
    }

    public void setPatList(List<Object> patList) {
        this.PatList = patList;
    }

    public int getPriorityId() {
        if (TempPriority == 0) {

            return 21104;
        }
        return TempPriority;
    }

    public void setPriorityId(int priorityId) {
        this.TempPriority = priorityId;
    }

    public String getControlDate(int priorityId) {
        return DateUtils.returnDateBasedOnPriorityId(priorityId);
    }

    public void setControlDate(String controlDate) {
        this.ControlDate = controlDate;
    }

}