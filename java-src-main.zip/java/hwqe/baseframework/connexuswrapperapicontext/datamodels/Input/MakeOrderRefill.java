package hwqe.baseframework.connexuswrapperapicontext.datamodels.Input;

import java.util.ArrayList;

@lombok.Getter
@lombok.Setter
public class MakeOrderRefill {
    private int siteId;
    private int rxId;
    private int rxFillId;
}