package hwqe.baseframework.connexuswrapperapicontext.datamodels.Input;

import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Drug;

@lombok.Getter
@lombok.Setter
public class OrderInput {
    public Order order;
    public Drug drug;
}
