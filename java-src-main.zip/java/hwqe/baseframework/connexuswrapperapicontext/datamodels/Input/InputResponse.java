package hwqe.baseframework.connexuswrapperapicontext.datamodels.Input;

@lombok.Getter
@lombok.Setter
public class InputResponse {
	
	 private int orderId;
	 private int rxFillId;
	 private int rxId;
	 private int rxNbr;
	 private int patientId;
	 private int orderSeqNbr;
     private String workQueue;
	 private int toteNumber;

}
