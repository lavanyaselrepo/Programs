package hwqe.baseframework.connexuswrapperapicontext.datamodels.Input;

import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Drug;

import java.util.List;

@lombok.Getter
@lombok.Setter
public class MultiOrderInput {
    public Order order;
    public List<Drug> drugList;
}
