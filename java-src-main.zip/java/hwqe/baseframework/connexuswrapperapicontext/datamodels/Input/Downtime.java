package hwqe.baseframework.connexuswrapperapicontext.datamodels.Input;

@lombok.Getter
@lombok.Setter
public class Downtime {
    private int FillId;
    private int OrderSeqNbr;
    private double txnAmt;
    private int OrderId;
    private int SiteID;
    public String UserId;
    public String MachineName;
}