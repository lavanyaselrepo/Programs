package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;
import com.google.api.client.util.DateTime;
import hwqe.baseframework.utilities.DateUtils;

import java.util.Date;

@lombok.Getter
@lombok.Setter
public class AddressInformation{
	private int AddressTypeCode;
	private int AddressSequenceNo;
	private String AddressLine1;
	private String AddressLine2;
	private String City;
	private String State;
	private String Country;
	private String ZipCode;
	private String HomePhone;
	private String WorkPhone;
	private boolean AddressChange;
	private boolean CommunicationChange;
	private String CellPhone;
	private String CMSPartDSelected;
	private int SubjectTypeCode;
	private int VerifyFreqCode;
	private int Freq_Days;
	private boolean IsAddressDeleted;
	private Object AddressLine3;
	private Object AddressLine4;
	private Object FullAddress;
	private Object EmailAddress;
	private Object CommunicationText;
	private String FacilityName;
	private String FacilityID;
	private Object PatientResidenceCode;
	private Object CountyName;
	private Object AltHomePhone;
	private Object AltWorkPhone;
	private Object PreferredPhone;
}
