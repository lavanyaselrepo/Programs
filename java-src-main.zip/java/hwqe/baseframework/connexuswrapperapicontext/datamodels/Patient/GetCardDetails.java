package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class GetCardDetails {

	private int SiteID;
	private String PatientId;

}
