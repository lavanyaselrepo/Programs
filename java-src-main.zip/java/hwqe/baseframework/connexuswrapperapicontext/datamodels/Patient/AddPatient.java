package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class AddPatient {

	private int SiteID;
	private String CommunicationID;
	private String FirstName;
	private String LastName;
	private String MiddleName;
	private String PatientName;
	private String Dob;
	private String Gender;
	private String Language;
	private int Status;
    private Boolean IsPatientMinor;
	private int AddressTypeCode;
	private int VerifyFreCode;
	private int PatientTypeCode;
	private String UserId;
	private String AddressLine1;
	private String AddressLine2;
	private String CellPhone;
	private String City;
	private String Country;
	private String HomePhone;
	private String State;
	private String WorkPhone;
	private String ZipCode;
	private int HipaaStatusCode;

}
