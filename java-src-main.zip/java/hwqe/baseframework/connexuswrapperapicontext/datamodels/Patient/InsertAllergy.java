package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class InsertAllergy {

    private String AllergyClassDescription;
    private int AllergyClassCode;
    private String EffectiveTS;
    private String ExpiryDate;
    private int PatientId;
    private String LastChangeUserId;
    private int PrescriberId;
    private String PrescriberReferenceNbr;
    private int CommentId;
    private String NdcNbr;
    private String SourceCode;
    private String ReportDate;
    private String FirstName;
    private String LastName;
    private Object MiddleName;
    private Object LabelName;
    private String ShortName;
    private Object CommentText;
    private String ProductMdsFamilyId;
    private int Checked;
    private int UpdateIndicator;
    private String TypeOfReaction;
    private int AllergyClassTypeCode;
    private String ReasonDeactivated;
}
