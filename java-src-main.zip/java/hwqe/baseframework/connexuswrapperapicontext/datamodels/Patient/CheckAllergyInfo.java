package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;
@lombok.Getter
@lombok.Setter
public class CheckAllergyInfo {
    private int PatientId;
    private int SiteId;
}
