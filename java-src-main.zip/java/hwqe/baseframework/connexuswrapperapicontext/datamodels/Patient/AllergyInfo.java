package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class AllergyInfo{
	private int AllergyClassCode;
	private int PatientId;
	private String LastChangeUserId;
	private int PrescriberId;
	private int CommentId;
	private String NdcNbr;
	private String FirstName;
	private String LastName;
	private String ProductMdsFamilyId;
	private int Checked;
	private int UpdateIndicator;
	private String TypeOfReaction;
	private int AllergyClassTypeCode;
	private String AllergyClassDescription;
	private String PrescriberReferenceNbr;
	private String SourceCode;
	private Object MiddleName;
	private Object LabelName;
	private Object CommentText;
	private String ShortName;
	private String ReasonDeactivated;
}