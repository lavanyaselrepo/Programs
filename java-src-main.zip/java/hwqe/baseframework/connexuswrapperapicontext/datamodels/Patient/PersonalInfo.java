package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;
import com.google.api.client.util.DateTime;
import hwqe.baseframework.utilities.DateUtils;


import java.util.Date;
import java.util.List;

@lombok.Getter
@lombok.Setter
public class PersonalInfo{
	private String LastName;
	private String FirstName;
	private String MiddleName;
	private Object PatientName;
	private List<ContactInformation> ContactInformation;
	private Object AltContactInformation;
	private String Dob;
	private String Gender;
	private String Language;
	private int Status;
	private Object Weight;
	private Object PetOwnerDetails;
	private Object PatientTypeCode;
	private Object AutoPaySignupCode;
	private int ChargeFrequencyCode;
	private Object LastChangeUserId;
	private int PatientStatusCode;
	private boolean IsPatientMinor;
	private int RaceTypeCode;
	private int EthnicityTypeCode;
	public List<AddressInformation> AddressInformation;
	private Object MailContactInformation;
	private Object PatCommunicationRedesignInfo;
	private Object PatientPhoneNumberRemoveList;
	private int PatientId;
	private int HipaaStatusCode;
}