package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;


@lombok.Getter
@lombok.Setter
public class UpdatePatientInfoCentralData {

	private int PatientId;
	private int SiteId;
	private String UserId;
}
