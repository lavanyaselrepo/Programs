package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter


public class PhmPaymentAcctInfo {
	private String AccountNbr;
	private String AddressLine1;
	private int CardRefNbr;
	private String CardSuffixNbr;
	private String CardValidityComment;
	private String CardholderName;
	private String City;
	private String CreditCardName;
	private int ExpireMonthNbr;
	private int ExpireYearNbr;
	private String LastValidatedTS;
	private String P2PEToken;
	private int PhmPaymentAcctId;
	private String PostalCode;
	private String State;
	private int ValidateStatCode;

	// Getters and setters
	// ... (include all fields)

	public String getCreditCardName() {
		return CreditCardName;
	}

	public void setCreditCardName(String creditCardName) {
		CreditCardName = creditCardName;
	}

	public String getCardholderName() {
		return CardholderName;
	}

	public void setCardholderName(String cardholderName) {
		CardholderName = cardholderName;
	}

	public int getExpireMonthNbr() {
		return ExpireMonthNbr;
	}

	public void setExpireMonthNbr(int expireMonthNbr) {
		ExpireMonthNbr = expireMonthNbr;
	}

	public int getExpireYearNbr() {
		return ExpireYearNbr;
	}

	public void setExpireYearNbr(int expireYearNbr) {
		ExpireYearNbr = expireYearNbr;
	}

	public String getP2PEToken() {
		return P2PEToken;
	}

	public void setP2PEToken(String p2PEToken) {
		P2PEToken = p2PEToken;
	}

	// Add other fields similarly...
}
