package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class GetPatientInformation {
    private int SiteID;
    private int PatientId;
    private String ScreenName;
}
