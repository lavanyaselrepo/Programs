package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

import java.util.List;

@lombok.Getter
@lombok.Setter
public class Patient {


	public AllergyInfo AllergyInfo;
	public PrimaryThirdParty PrimaryThirdParty;
	public List<PatCommunicationRedesignInfo> PatCommunicationRedesignInfo;
	private String ScreenName;
	private Object MedicalConditionInformation;
	private String Notes;
	private Object ImageSignature;
	private Object ReferenceNbr;
	private String RestrictValue;
	public PatGeneralInfo PatGeneralInfo;
}