package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class CreatePatientResponse {

	private int patientId;
	private String firstName;
	private String lastName;
	private String inputDob;
	private int siteId;
	private long homePhone;
	private long workPhone;
	private long cellPhone;
}
