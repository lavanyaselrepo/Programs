package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class CreatePatientRequest {

    private String firstName;
    private String lastName;
    private String dob;
    private String inputDob;
    private int siteId;
    private String gender;
    private String homePhone;
    private String workPhone;
    private String cellPhone;
    private boolean patientHasInsurance;
    private InsuranceDetails insurance;
    private Address address;
	
}
