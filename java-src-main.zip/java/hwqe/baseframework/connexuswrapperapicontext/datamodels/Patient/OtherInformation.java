package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class OtherInformation{
	private int ResponsibleParty;
	private boolean PackingOption;
	private int MailOutCode;
	private int ChargeCode;
	private boolean UpdateChargeCode;
	private boolean UpdateMailOut;
	private boolean CommentChangeInd;
	private int Lnka;
	private String UserId;
	private String CommentText;
	private String CodeAbbreviation;

}