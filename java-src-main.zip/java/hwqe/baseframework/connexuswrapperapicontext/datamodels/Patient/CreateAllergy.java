package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class CreateAllergy {
    public AllergyInfo AllergyInformation;
}
