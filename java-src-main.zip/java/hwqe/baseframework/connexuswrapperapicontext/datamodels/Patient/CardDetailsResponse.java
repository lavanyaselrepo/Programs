package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

import java.util.List;

@lombok.Getter
@lombok.Setter


public class CardDetailsResponse {
	private List<PatientPaymentInfo> PatientPaymentInfo;

	public List<PatientPaymentInfo> getPatientPaymentInfo() {
		return PatientPaymentInfo;
	}

	public void setPatientPaymentInfo(List<PatientPaymentInfo> patientPaymentInfo) {
		this.PatientPaymentInfo = patientPaymentInfo;
	}
}
