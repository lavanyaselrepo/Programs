package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

import java.util.List;

@lombok.Getter
@lombok.Setter
public class PatGeneralInfo{
	public PersonalInfo PersonalInfo;
	public MiscPersonalInformation MiscPersonalInformation;
	private int PatientTypeCode;
	public OtherInformation OtherInformation;
	public HipaaInformation HipaaInformation;
	public PrimaryPrescriberInformation PrimaryPrescriberInformation;
	private Object RemovePayLoadFeilds;
	private Object PatientPhoneNumberRemoveList;
	private boolean PatientNotPresent;
	private Object PatientDemogList;
	private List<Object> PatientRelationshipInfo;
	private boolean NeedToCallResndchckSP;
	private int HipaaStatusCode;
}