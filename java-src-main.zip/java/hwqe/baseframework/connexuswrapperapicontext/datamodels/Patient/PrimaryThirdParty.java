package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;


@lombok.Getter
@lombok.Setter
public class PrimaryThirdParty{
	private int RelationshipCode;
	private Object DependentCode;
	private String CardHolderFirstName;
	private String CardHolderLastName;
	private boolean EligibilityIndicator;
	private String CoverageIndicator;
	private String PlanName;
	private int CoverageOptionId;
	private String UserId;
	private int PatientId;
	private int ParticipantNbr;
	private int PlanTypeCode;
	public IcpInfo IcpInfo;
	private int OldCarrierId;

	private Object RelationshipDescription;
	private Object RestrictValue;
	private Object PrimaryCoverageIndicator;
	private int BillingSequenceNbr;
	private int BillGroupSequenceNbr;
	private String BillingGroupNbr;
	private String OldCardHolderId;
	private String BillingGroupName;
	private String CardHolderName;
	private Object CoverageAbbreviation;
	private int CoverageCode;

	private int PhmCompanyId;
	private Object PhmCompanyName;
	private Object PhmCompanyNameAbbreviation;
	private int OldPlanId;
	private Object PlanReferenceCode;
	private String CarrierCode;

	private Object SplitBillIndicator;
	private int EligibleOverrideValue;
	private int EligibleLocationValue;
	private int EligibleInsuranceValue;
	private int EligibleSeriesValue;
	private int EligibleAdcValue;
	private int EligibleNbrsValue;
	private String InsBirthDateComment;
	private Object HomePlanCode;
	private Object MedicaidId;
	private Object MediGapId;
	private Object HomeState;

	private String CommentText;
	private Object CommentId;
	private Object BIN;
	private Object PCN;
	private Object InsurancePlan;
	private Object ContactNumber;
}