package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class PatCommunicationRedesignInfo{
	private int CommMethodCode;
	private int CommSequenceNbr;
	private String CommunicationID;
	private boolean PreferredAddress;
	private boolean HasCommunicationChanged;
	private boolean isText;
	private boolean isCall;
	private boolean isPreferredContactNbr;
}