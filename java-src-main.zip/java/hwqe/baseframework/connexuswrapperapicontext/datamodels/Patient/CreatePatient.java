package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class CreatePatient {
	private int SiteID;
	public Patient Patient;
}