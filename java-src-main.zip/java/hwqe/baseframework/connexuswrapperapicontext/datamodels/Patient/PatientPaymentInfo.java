package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter


public class PatientPaymentInfo {
	private String AssocDiscCardNbr;
	private int CardSeqNbr;
	private String EstPickupTs;
	private String LastChangeUserId;
	private int PatientId;
	private int PaymentFreqCode;
	private int PhmPaymentAcctId;
	private PhmPaymentAcctInfo PhmPaymentAcctInfo;
	private int PhmSignatureId;
	private int PriorityId;
	private int RelationshipCode;
	private String RevokeDate;
	private int SignatureFreqCd;
	private String SplitInd;
	private String StartDate;

	// Getters and setters
	// ... (include all fields)

	public String getAssocDiscCardNbr() {
		return AssocDiscCardNbr;
	}

	public void setAssocDiscCardNbr(String assocDiscCardNbr) {
		AssocDiscCardNbr = assocDiscCardNbr;
	}

	public int getCardSeqNbr() {
		return CardSeqNbr;
	}

	public void setCardSeqNbr(int cardSeqNbr) {
		CardSeqNbr = cardSeqNbr;
	}

	public String getEstPickupTs() {
		return EstPickupTs;
	}

	public void setEstPickupTs(String estPickupTs) {
		EstPickupTs = estPickupTs;
	}

	public String getLastChangeUserId() {
		return LastChangeUserId;
	}

	public void setLastChangeUserId(String lastChangeUserId) {
		LastChangeUserId = lastChangeUserId;
	}

	public int getPatientId() {
		return PatientId;
	}

	public void setPatientId(int patientId) {
		PatientId = patientId;
	}

	public int getPaymentFreqCode() {
		return PaymentFreqCode;
	}

	public void setPaymentFreqCode(int paymentFreqCode) {
		PaymentFreqCode = paymentFreqCode;
	}

	public int getPhmPaymentAcctId() {
		return PhmPaymentAcctId;
	}

	public void setPhmPaymentAcctId(int phmPaymentAcctId) {
		PhmPaymentAcctId = phmPaymentAcctId;
	}

	public PhmPaymentAcctInfo getPhmPaymentAcctInfo() {
		return PhmPaymentAcctInfo;
	}

	public void setPhmPaymentAcctInfo(PhmPaymentAcctInfo phmPaymentAcctInfo) {
		PhmPaymentAcctInfo = phmPaymentAcctInfo;
	}

	public int getPhmSignatureId() {
		return PhmSignatureId;
	}

	public void setPhmSignatureId(int phmSignatureId) {
		PhmSignatureId = phmSignatureId;
	}

	public int getPriorityId() {
		return PriorityId;
	}

	public void setPriorityId(int priorityId) {
		PriorityId = priorityId;
	}

	public int getRelationshipCode() {
		return RelationshipCode;
	}

	public void setRelationshipCode(int relationshipCode) {
		RelationshipCode = relationshipCode;
	}

	public String getRevokeDate() {
		return RevokeDate;
	}

	public void setRevokeDate(String revokeDate) {
		RevokeDate = revokeDate;
	}

	public int getSignatureFreqCd() {
		return SignatureFreqCd;
	}

	public void setSignatureFreqCd(int signatureFreqCd) {
		SignatureFreqCd = signatureFreqCd;
	}

	public String getSplitInd() {
		return SplitInd;
	}

	public void setSplitInd(String splitInd) {
		SplitInd = splitInd;
	}

	public String getStartDate() {
		return StartDate;
	}

	public void setStartDate(String startDate) {
		StartDate = startDate;
	}
}

