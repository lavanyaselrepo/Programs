package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

import java.util.List;

@lombok.Getter
@lombok.Setter
public class PatientInfo {

	String patientId;
	String storeNbr;
	PatientDetails patientDetails;
}