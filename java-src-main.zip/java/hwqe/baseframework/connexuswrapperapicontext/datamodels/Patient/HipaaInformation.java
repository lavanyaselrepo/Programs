package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class HipaaInformation{
	private boolean Acknowledged;
	private int HipaaStatusCode;
	private boolean NewSignCaptured;
	private int PatientId;
	private boolean PatientRefused;
	private int RelationshipCode;
	private int StoreNumber;
	private String SignedBy;
	private String AssociateId;
	private String RequestorUserId;
}