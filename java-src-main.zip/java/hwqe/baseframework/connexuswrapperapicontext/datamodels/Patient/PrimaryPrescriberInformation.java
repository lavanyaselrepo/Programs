package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class PrimaryPrescriberInformation{
	private boolean LocalPrescriber;
	private boolean IsPrescriberMismatch;
	private Object PrescriberId;
	private String FirstName;
	private String LastName;
	private String MiddleName;
	private String Address;
	private Object ClinicId;
	private Object ProblemMessage;
}