package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;


@lombok.Getter
@lombok.Setter
public class InsuranceDetails {
	private int insuranceCarrierPlanId;
	private int insuranceCarrierCompanyId;
	private int billingSeqNbr;
	private String cardholderId;
	private String cardholderFirstName;
	private String cardholderLastName;
	private int relationshipCode;
	private String coverageInd;
	private String coverageExpDate;
	private String splitBillInd;
	private int insPlanTypeCode;
}