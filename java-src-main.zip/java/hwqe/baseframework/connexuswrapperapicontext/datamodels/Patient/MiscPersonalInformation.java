package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class MiscPersonalInformation{
	private int DriversLicenseState;
	private int NotificationStatusCode;
	private int IdentificationType;
	private boolean ImmunizationReporting;
	private boolean ServiceRecommendation;
	private int PseudoephedrinePatientIdTypeCode;
	private int PseudoephedrineIssueAgencyCode;
	private String TwindicatorStatus;
	private String PetValidation;
	private String Ssn;
	private String DriversLicense;
	private String Comments;

	private boolean HealthyLeavingIndicator;
	private boolean BrailleInd;
	private boolean BrandDrugs;
	private Object IsSnapCapPreferred;

	private Object EasyPayStatusCode;
	private Object VisuallyImpaired;
	private boolean ScripTalk;

	private String MothersMaidenName;
	private boolean MothersMaidenNameNotDisclosed;
	private boolean PrimaryCarePhysicianNone;
	private String PrintDigitalDoc;
	private Object ReducePaperInfo;
	private Object PseudoephedrinePatientIdType;
	private Object PseudoephedrinePatientIdNumber;
	private Object PseudoephedrinePatientIdState;
	private boolean isPSEPatient;
	private Object InsulinDependentIndicatorInfo;
	private Object InsulinPumpIndicatorInfo;
	private Object InsulinStatus;
	private Object TimeMyMedsRestrictionInfo;
}