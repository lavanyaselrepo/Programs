package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

@lombok.Getter
@lombok.Setter
public class IcpInfo{
	private int CarrierCompanyId;
	private int PlanId;
	private String CardHolderId;
	private Object LastChangeDate;
}