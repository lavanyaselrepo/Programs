package hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient;

import java.util.List;

@lombok.Getter
@lombok.Setter
public class PatientDetails {

	String lastName;
	String firstName;
	String middleName;
	String languageCode;
	String gender;
	String birthDate;
	String patientStatusCode;
	String hipaaStatusCode;
	String patientTypeCode;
	String autoPaySignupCode;
	String chargeFreqCode;
	String ethnicityTypeCode;
	String raceTypeCode;
	String createTs;
	String lastChangeUserId;
	String storeChangeTs;
}