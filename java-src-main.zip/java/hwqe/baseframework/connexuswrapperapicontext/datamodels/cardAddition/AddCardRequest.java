package hwqe.baseframework.connexuswrapperapicontext.datamodels.cardAddition;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AddCardRequest{
    private String storeNbr;
    private String patientId;
    private List<PatientPaymentInfoItem> patientPaymentInfo;
}