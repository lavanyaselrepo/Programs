package hwqe.baseframework.connexuswrapperapicontext.datamodels.cardAddition;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PatientPaymentInfoItem{
    private String cardSeqNbr;
    private String phoneNbr;
    private String lastChangeUserId;
    private String cardHolderName;
    private String billingAddrTxt;
    private String postalCode;
    private String expirYearNbr;
    private String signatureFrequencyCode;
    private String relationshipCode;
    private String cardRefNbr;
    private String expirMoNbr;
    private String p2peToken;
    private String stateProvCode;
    private String cityName;
    private String pymtFreqCode;
    private String cardSuffixNbr;
    private String phmPymtMthdCode;
    private String phmPymtAcctId;
    private String startDate;
    private String routingNbr;
}