package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PrimaryTPRxSaleDetailInfo {
        public int RxSeqNbr;
        public int PartyType;
        public int RxType;
        public int TaxAmt;
        public Object Status;
        public int OrgStatus;
        public int CarrId;
        public Object CarrAbbr;
        public int PlanId;
        public Object PlanAbbr;
        public Object Card;
        public String Phone;
        public Object GroupSeqNbr;
        public Object GroupAbbr;
        public Object Rltn;
        public Object DependCode;
        public int BillingSeqNbr;
        public String CoverageInd;
        public String CardholderName;
        public String CoverageExpDate;
        public int CoverageCode;
        public String OrgCard;
        public int OrgPlanId;
        public int OrgCarrId;
        public Object OrgGroupAbbr;
        public String OrgRltn;
        public Object OrgDependCode;
        public int OrgTaxAmt;
        public String UpdatedCarrierAbbreviation;
        public String UpdatedPlanAbbreviation;
}