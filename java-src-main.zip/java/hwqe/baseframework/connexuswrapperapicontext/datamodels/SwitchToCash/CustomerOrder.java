package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerOrder {
        public Object CommentInd;
        public Object CustomerNotifyNbr;
        public Object OrderEntryTs;
        public Object BeeperId;
        public int StatusCode;
        public int PriorityId;
        public Object EstPickupTs;
        public Object PromiseTime;
        public int OrderId;
        public Object PharmacyCodeTextInfo;
        public RxOrderDetailInfo RxOrderDetailInfo;
        public boolean OnholdRequestActivityPresent;
        public boolean PatientNotifyEnrollCheck;
        public boolean OrderSold;
}