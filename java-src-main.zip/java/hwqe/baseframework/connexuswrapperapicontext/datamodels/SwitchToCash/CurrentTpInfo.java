package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CurrentTpInfo {
        public Object PriorAuthRefID;
        public int OrderId;
        public int OrderSequenceNumber;
        public int RxFillId;
        public int CarrierId;
        public Object CarrierName;
        public int PlanID;
        public Object PlanName;
        public Object CardHolderID;
        public int StatusCode;
        public double TxnAmount;
        public int CoPayAmt;
        public int TxnSequenceNumber;
        public Object InsCarrPlanName;
}
