package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DrInfo {
        public int RxPrescriberId;
        public int OriginalPrescriberId;
        public int RxClinicId;
        public int OrgRxClinicId;
        public int CentralPrescriberID;
        public String DrName;
        public Object PrescriberDPS;
        public String OriginalDrName;
        private String DrAddr;
        public String DrCSZ;
        public String DrPhone;
        public String DrDEA;
        public Object AuthDEA;
        public Object DrXDEA;
        public String OrgDrDEA;
        public Object OrgDrXDEA;
        public int LicenseSeqNbr;
        public Object DPSNbr;
        public int DPSLicenseSeqNbr;
        public Object DrNPI;
        public int DrDegree;
        public int DrStatusCode;
        public Object DrFax;
        public Object DrLabelName;
        public Object PhysicianNPI;
        public Object OrgPhysicianId;
        public Object PhysicianId;
        public Object PhysicianName;
        public Object OrgPhysicianName;
        public int PhysicianClinicId;
        public int OrgPhysicianClinicId;
        public Object PhysicianAddress;
        public Object PhysicianCSZ;
        public Object PhysicianPhone;
        public Object PrescriberAddresses;
        public Object PhysicianAddresses;
        public Object PhysicianDEA;
        public Object OrgPhysicianDEA;
        public int PhyLicenseSeqNbr;
        public Object PhysicianFax;
        public Object PrsbrLicenseAuthority;
        public int PhysicianStatus;
        public Object PhyLabelName;
        public int PhyDegree;
        public Object TotalRTFCount;
        public Object TotalBRTFCount;
        public Object AllRtfWinSubmissions;
        public Object AllBrtfWinSubmissions;
}