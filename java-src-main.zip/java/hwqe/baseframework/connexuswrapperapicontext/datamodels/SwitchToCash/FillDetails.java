package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FillDetails {
        public DrInfo DrInfo;
        public boolean IsCounselNeeded;
        public boolean IsCounselQueNeeded;
        public int OfferToCounselSetting;
        public boolean CounselOptOutAvailable;
        public boolean CounselDosageVarianceExceeded;
        public boolean IsNewCounselPatient;
        public int CounselOptInReasonCode;
        public int CounselOptOutReasonCode;
        public Object CounselOptInReasonText;
        public Object CounselOptOutReasonText;
        public Object CounselTriggerReasonText;
        public boolean IsRxCounseled;
        public Object CounselDate;
        public Object CounselUserId;
        public PrescProdInfo PrescProdInfo;
        public ProdItemInfo ProdItemInfo;
        public CustomerOrder CustomerOrder;
        public PosActivity PosActivity;
        public PrimaryTPRxSaleDetailInfo PrimaryTPRxSaleDetailInfo;
        public SecondaryTPRxSaleDetailInfo SecondaryTPRxSaleDetailInfo;
        public ActiveRxFillsInfo ActiveRxFillsInfo;
        public MiscInfo MiscInfo;
        public Object GetItemInfoBE;
        public PrimSecTPCopyInfo PrimSecTPCopyInfo;
        public OtherInfo OtherInfo;
        public Object MedicareBStatus;
        public Object ItemLocation;
        public int ProblemSecurityId;
        public int OrderSeqNbr;
        public Object ClaimResponseData;
        public Object TPDURInfo;
        public int OrderId;
        public Object ServiceInfo;
        public Object ServiceOrderDetailInfo;
        public boolean SendToWorkesCompResolution;
        public Object LastfillDetailsInfo;
        public Object CashPrice;
        public int RxWithSameGpi;
        public Object NarxPatientInfo;
        public boolean IsStateRequiredViewReport;
        public boolean LogOrderDetailForWFO;
        public Object RxActivityDetails;
        public boolean EarlyRefillRejectIndicator;
        public boolean IsLockerEligible;
        public boolean CloudCentralFill;
        public Object LabelerShortName;
        public Object ImageId;
        public Object ImageData;
        public boolean IsImmunization;
        public Object DiagnosisCode;
        public boolean IsPriorAuthorized;
        public SwitchReasonBE SwitchReasonBE;
        public int OriginalBarCode;
        public Object PetRxParams;
        public boolean IsAutoRefill;
        public boolean IsEmergency;
        public Object ShipToState;
        public boolean IsReturnToStockFill;
}
