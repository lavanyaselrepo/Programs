package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ItemInfo {
        public int DispensedDaysSupply;
        public int DispensedFillQty;
        public int DispensedItemId;
        public int ItemMdsFamId;
        public String NdcNumber;
}
