package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TamperResistant {
        public int OrderId;
        public int RxId;
        public int OrderSeqNbr;
        public int ProblemSeqNbr;
        public int ProblemCode;
        public int TrblsMethodCode;
        public String UserId;
        public String Tamper;
        public int RxOriginCode;
        public int WorkQueueCode;
        public int SiteID;
}