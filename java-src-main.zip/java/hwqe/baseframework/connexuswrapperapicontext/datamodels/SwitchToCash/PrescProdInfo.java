package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PrescProdInfo {
        public int OriginalProdId;
        public int RxProdId;
        public int GenericDrugId;
        public int PrescribedProductSmallestPack;
        public String PresProdName;
        public Object ProdShortName;
        public String OriginalPresProdName;
        public Object PresProdStrength;
        public int DrugControlCode;
        public int PresMultiSrcCode;
        public Object GenericProdName;
        public String GpiCode;
        public Object RouteAdminDescription;
        public Object DrugRestrictTypeCodes;
}