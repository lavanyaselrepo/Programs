package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PosActivity {
        public String PosTs;
        public int PosPatientAmt;
        public Object PosTaxAmt;
}
