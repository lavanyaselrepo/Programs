package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProdItemInfo {
        public int DispItemId;
        public int OriginalDispItemId;
        public int DispProdId;
        public int OrgDispProdId;
        public String DispProdName;
        public String OrgCompoundInd;
        public String CompoundInd;
        public Object OriginalCompoundId;
        public Object CompoundId;
        public int LabelerId;
        public String InnerPack;
        public String NDC;
        public double UsualCost;
        public double OrgUsualCost;
        public double ActCost;
        public double OrgActualCost;
        public float OnHand;
        public int ItemSeqNbr;
        public int DispMultiSrcCode;
        public boolean IsSuboxone;
        public int DispensedItemSmallestPack;
        public int DeptNumber;
        public Object CompoundInfoList;
        public Object GenericDispensedProdName;
        public boolean IsDrugOpiod;
}
