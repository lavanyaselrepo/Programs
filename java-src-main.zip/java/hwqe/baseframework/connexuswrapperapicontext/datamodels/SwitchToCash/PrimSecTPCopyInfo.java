package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PrimSecTPCopyInfo {
        public int PrimaryTPCopyAmt;
        public int SecTPCopyAmt;
}