package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OtherInfo {
        public int PhmSignatureId;
        public int PrimaryTPReturn;
        public Object SecondaryTPReturn;
        public int InputSourceCode;
        public int ERxRespTypeCode;
        public int ERxResponseId;
        public Object PrescriberPatientId;
        public String NeedERxInd;
        public String OriginalFillDate;
        public String InitialFillDate;
        public String FinalFillDate;
        public String DrugEquivCode;
        public int EnrollmentFee;
        public int TransactionFee;
        public int BalanceRemain;
        public int BrandGenericDiff;
        public String MedicareActInd;
        public int MarkupAmt;
        public Object IntervalDays;
        public Object OrgIntervalDays;
        public int RxOriginCode;
        public int OrgRxOriginCode;
        public String AutoRefillInd;
        public String OriginalAutoRefillInd;
        public int RxTransferId;
        public String RetryTs;
        public int TPCount;
        public String FutureFill;
        public Object PrefillStatCode;
        public String MOCancelInd;
        public int RemoteStoreNbrTSProblem;
        public Object Dps;
        public String DpsReq;
        public Object OrgDps;
        public String OrgFutureFill;
        public Object RxStoreExpSig;
        public Object OrgRxStoreExpSig;
        public Object EarlyFillDate;
        public boolean IsEarlyFillDateInInput;
        public Object OrgEarlyFillDate;
        public Object RxOriginType;
        public int RxAutoFillStatus;
        public String IsRxAutoFillEligible;
        public int OriginalRxAutoFillStatus;
        public int AutoRefillIneligibleReason;
}
