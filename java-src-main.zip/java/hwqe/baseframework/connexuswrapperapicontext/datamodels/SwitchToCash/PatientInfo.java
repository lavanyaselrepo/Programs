package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PatientInfo {
        public Object LastName;
        public Object FirstName;
        public Object MiddleName;
        public Object ShortName;
        public String PatientName;
        public int PatientId;
        public int OriginalPatientId;
        public String PrefLanguageCode;
        public String BirthDate;
        public int AutoPaySignupCD;
        public SubjectAddressInfo SubjectAddressInfo;
        public Object PatientPaymentInfo;
        public String GenderCode;
        public String CommentInd;
        public Object CommentTxt;
        public String PatCSZ;
        public String OriginalPatientName;
        public Object PatientWeight;
        public int PatientTypeCode;
        public int PatientStatusCode;
        public boolean NoKnownAllergies;
        public boolean HasAllergies;
        public Object PetOwnerLastName;
        public Object PetOwnerFirstName;
        public Object PetOwnerMiddleName;
        public int PetOwnerPatID;
        public boolean CounselNotesIndicator;
        public Object PatientPrimaryPhone;
        public int RxNumber;
        public Object Product;
        public int InsurancePaymentAmt;
        public int PatientDue;
        public boolean Ispymtmthdonfile;
        public boolean Ispricevalidated;
        public boolean TMMSyncRx;
        public boolean InsulinPumpRestrictionExists;
        public boolean InsulinDependentRestrictionExits;
        public boolean IsOrderFromWellnessApp;
        public boolean StagingPriceChanged;
        public Object EstimatedPrice;
        public Object TmmEnrollmentInfo;
        public Object ShipToState;
        public boolean IsTimeMyMedsTargetedPatient;
        public Object MaintenanceDrugList;
        public Object TimeMyMedsEnrollmentStatus;
        public Object PatientTypeDesc;
        public String TimeMyMedsEnrollmentDataLoadTimeSpan;
        public boolean IsPediatricPatient;
}
