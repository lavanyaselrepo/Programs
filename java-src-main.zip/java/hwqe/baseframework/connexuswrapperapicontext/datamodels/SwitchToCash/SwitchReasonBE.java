package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SwitchReasonBE {
        public Object reasonCode;
        public Object alternateTherapyText;
        public Object appealDeniedDate;
        public Object appealRequestedDate;
        public Object comment;
        public Object priorAuthorizationDeniedDate;
        public Object priorAuthorizationRequestedDate;
}