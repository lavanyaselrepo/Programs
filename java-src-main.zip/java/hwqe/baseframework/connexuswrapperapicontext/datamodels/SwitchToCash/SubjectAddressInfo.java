package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SubjectAddressInfo {
        public String AddressLine1;
        public Object AddressLine2;
        public Object CityName;
        public Object StateProvCode;
        public Object PostalCode;
        public Object CountryCode;
        public int AddrTypeCode;
        public Object CommunicationId;
        public String HomePhone;
        public int AddressSequenceNo;
        public Object AddressLine3;
        public Object AddressLine4;
        public Object CountryName;
        public Object CMSQlfdFcltyInd;
        public Object PatientResidenceCode;
        public String LastChangeTimeStamp;
        public int SubjectTypeCode;
        public int SubjectId;
        public Object AddressType;
}
