package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GetFillDetailsByOrderId {
        public int OrderId;
        public int OrderSeqNbr;
        public int SiteID;
}
