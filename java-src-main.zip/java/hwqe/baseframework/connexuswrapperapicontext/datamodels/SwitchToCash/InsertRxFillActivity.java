package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

@lombok.Getter
@lombok.Setter
public class InsertRxFillActivity {

	public int siteID;
	public int rxFillId;
	public int activityCode;
	public String userId;
	public int storeNbr;
}