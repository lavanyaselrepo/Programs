package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FillRsd {
        public int BillSeqNbr;
        public int CardHolderId;
        public String ClientTpDeleteIndicator;
        public int CoPayAmt;
        public int RxFillId;
        public CurrentTpInfo CurrentTpInfo;
        public String DeleteTpIndicator;
        public String DownTimeIndicator;
        public int InCarrPlanId;
        public Object InternalIndicator;
        public String NewTPIndicator;
        public int OriginalCoPayAmt;
        public OriginalTPInfo OriginalTPInfo;
        public int OriginalTxnSeqNbr;
        public String PaperBillIndicator;
        public int RefillId;
        public String RevAndSubmitIndicator;
        public int StatusCode;
        public Object StatusDescription;
        public String TPSameIndicator;
        public String TPSubmitIndicator;
        public int TxnAmt;
}
