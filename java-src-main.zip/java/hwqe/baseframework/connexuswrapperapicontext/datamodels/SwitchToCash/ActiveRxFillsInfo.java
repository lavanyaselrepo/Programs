package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ActiveRxFillsInfo {
        public int NbrOfFills;
        public int ActFillQty;
        public String FutureChargeInd;
        public String FutureMailInd;
        public String OrgFutureChargeInd;
        public String OrgFutureMailInd;
        public String MailInd;
        public String OrgMailInd;
        public int Sequence;
}