package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SecondaryTPRxSaleDetailInfo {
        public int RxSeqNbr;
        public int PartyType;
        public int RxType;
        public Object Status;
        public Object OrgStatus;
        public int CarrId;
        public Object CarrAbbr;
        public int PlanId;
        public Object PlanAbbr;
        public Object Card;
        public Object Phone;
        public int GroupSeqNbr;
        public Object GroupAbbr;
        public Object Rltn;
        public Object DependCode;
        public int BillingSeqNbr;
        public Object CoverageInd;
        public Object CardholderName;
        public Object CoverageExpDate;
        public int CoverageCode;
        public int TaxAmt;
        public int OrgTaxAmt;
        public Object OrgCard;
        public int OrgPlanId;
        public int OrgCarrId;
}