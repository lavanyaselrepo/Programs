package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class SetFillDetailsByOrderId {
    public FillDetails FillDetails;
    public String UserId;
    public Object CompoundInfo;
    public Object PrimaryExtraInfo;
    public Object SecondaryExtraInfoBE;
    public int SourceWorkCode;
    public boolean HoldWork;
    public List<TaxInfo> TaxInfo;
    public boolean CopyOverride;
    public List<FillRsd> FillRsd;
    public Object FillTPExtraInfo;
    public boolean IsPaperBill;
    public boolean ForceSubQueToLocal;
    public boolean InputErrorOn;
    public boolean IsAttendingPhysicianReq;
    public boolean MultipleDEAInd;
    public boolean MultipleLocationInd;
    public Object PricingErrorText;
    public int PricingErrorActivity;
    public Object BrandGenericProfitPricingErrorDetails;
    public boolean PriceClassMissingInd;
    public boolean IsOffHold;
    public boolean isModifyDetailsOffHold;
    public boolean IsFutureFill;
    public CalcTaxes CalcTaxes;
    public boolean IsDropOffDateExpired;
    public Object MachineName;
    public int OrderId;
    public Object MaxDailyDose;
    public boolean IsHardCopyDAW1;
    public boolean UpdEncryptFillId;
    public boolean isResendFill;
    public boolean SwitchToInsulinMedicareThirdParty;
    public int ResolutionAction;
    public Object WorkInfo;
    public Object ProfileId;
    public boolean IsCloudOrder;
    public boolean PricingFailureInd;
    public boolean OmsPricingFailureInd;
    public Object TPExtraInfoInMemory;
    public int SiteID;
}
