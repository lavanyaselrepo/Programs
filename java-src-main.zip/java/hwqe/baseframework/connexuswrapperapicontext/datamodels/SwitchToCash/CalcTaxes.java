package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
public class CalcTaxes {
        public int CompoundId;
        public int CarrierCoId;
        public int InsCarrierPlanId;
        public Object InsCardId;
        public int PatientId;
        public String RxFillDate;
        public int OverRideAmt;
        public int RxFillId;
        public Object RxFillTaxInfo;
        public List<ItemInfo> ItemInfo;
        public boolean AdjustBrandPrice;
        public String UserId;
        public Object ScreenName;
        public boolean IsCloudOrder;
        public Object PetRxParams;
        public int SiteID;
}
