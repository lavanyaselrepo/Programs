package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OriginalTPInfo {
        public Object PriorAuthRefID;
        public int OrderId;
        public int OrderSequenceNumber;
        public int RxFillId;
        public int CarrierId;
        public String CarrierName;
        public int PlanID;
        public String PlanName;
        public String CardHolderID;
        public int StatusCode;
        public double TxnAmount;
        public int CoPayAmt;
        public int TxnSequenceNumber;
        public Object InsCarrPlanName;
}
