package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TaxInfo {
        public double AmountTaxed;
        public String Basis;
        public String PosInd;
        public double TaxAmount;
        // Constructors
        public TaxInfo() {}

        public TaxInfo(double amountTaxed, String basis, String posInd, double taxAmount) {
                this.AmountTaxed = amountTaxed;
                this.Basis = basis;
                this.PosInd = posInd;
                this.TaxAmount = taxAmount;
}}
