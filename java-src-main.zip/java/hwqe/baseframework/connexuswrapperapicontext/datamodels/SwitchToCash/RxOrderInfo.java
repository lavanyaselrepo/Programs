package hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RxOrderInfo {
        public int RxNbr;
        public int RxID;
        public int RxUUID;
        public RxInfo RxInfo;
        public int RxFillID;
        public String RxDAW;
        public String OriginalRxDAW;
        public String AltBillMethodInd;
        public int RefillAuthCode;
        public Object RefillAuthAbbr;
        public int TrailQty;
        public int OrgTrailQty;
        public Object RxFillInfo;
        public PatientInfo PatientInfo;
        public Object DrInfo;
        public int ItemMdsFamId;
        public int LastPatientDueAmt;
        public int PatientAmount;
        public int TaxAmount;
        public String PosTS;
        public int PhmSignatureId;
        public Object LicenseNbr;
        public Object DrugName;
        public String TamperResistantInd;
}