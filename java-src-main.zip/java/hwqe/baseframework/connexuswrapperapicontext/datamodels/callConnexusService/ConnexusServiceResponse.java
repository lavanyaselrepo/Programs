package hwqe.baseframework.connexuswrapperapicontext.datamodels.callConnexusService;

@lombok.Getter
@lombok.Setter
public class ConnexusServiceResponse {
  public String instanceID;
  public String status;
}
