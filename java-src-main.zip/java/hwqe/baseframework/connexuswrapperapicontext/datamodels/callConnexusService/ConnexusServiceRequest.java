package hwqe.baseframework.connexuswrapperapicontext.datamodels.callConnexusService;

@lombok.Getter
@lombok.Setter
public class ConnexusServiceRequest {
  public String siteId;
  public String scriptName;
  public String targetBoxType;
}
