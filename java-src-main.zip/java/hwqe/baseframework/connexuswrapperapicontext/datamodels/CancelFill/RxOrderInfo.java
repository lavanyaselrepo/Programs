package hwqe.baseframework.connexuswrapperapicontext.datamodels.CancelFill;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RxOrderInfo {
    public int rxNbr;
    public int rxID;
}
