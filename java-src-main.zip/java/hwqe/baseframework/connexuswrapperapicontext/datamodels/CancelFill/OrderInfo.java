package hwqe.baseframework.connexuswrapperapicontext.datamodels.CancelFill;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderInfo {
    public int rxId;
    public int rxFillId;
    public int statusCode;
    public int patientid;
    public int nextWorkQueueCode;
    public int orderId;
    public int orderSeqNbr;
    public int cancelAction;
    public boolean isPartialFill;
    public boolean isInventoryFlag;
    public boolean isCancelFill;
    public RxFillInfo rxFillInfo;
    public RxOrderInfo rxOrderInfo;
}
