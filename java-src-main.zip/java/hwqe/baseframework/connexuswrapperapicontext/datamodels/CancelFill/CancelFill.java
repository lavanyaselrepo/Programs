package hwqe.baseframework.connexuswrapperapicontext.datamodels.CancelFill;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;

@Getter
@Setter
public class CancelFill {

        public int siteId;
        ArrayList<Integer> rxNumbers;
}
