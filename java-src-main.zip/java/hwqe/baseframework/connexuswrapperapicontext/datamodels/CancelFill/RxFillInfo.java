package hwqe.baseframework.connexuswrapperapicontext.datamodels.CancelFill;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RxFillInfo {

    public int rxId;
    public int rxFillId;
    public int fillTypeCode;
}
