package hwqe.baseframework.connexuswrapperapicontext.datamodels.Eod;

import lombok.Data;

@Data
public class MoveOrderToEODRequest {

    int rxFillId;
    int siteId;
}
