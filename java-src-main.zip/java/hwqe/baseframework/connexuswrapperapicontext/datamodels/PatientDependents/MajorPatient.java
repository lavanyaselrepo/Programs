package hwqe.baseframework.connexuswrapperapicontext.datamodels.PatientDependents;

@lombok.Getter
@lombok.Setter

public class MajorPatient {
    private int patientId;
    private int rxNbr;
}
