package hwqe.baseframework.connexuswrapperapicontext.datamodels.PatientDependents;

import java.util.ArrayList;

@lombok.Getter
@lombok.Setter
public class DependentPatientIdAndRx {
    private ArrayList<DependentRxInfo> dependentRxInfo;
}
