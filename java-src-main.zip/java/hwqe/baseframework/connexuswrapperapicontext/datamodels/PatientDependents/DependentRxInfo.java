package hwqe.baseframework.connexuswrapperapicontext.datamodels.PatientDependents;

import java.util.ArrayList;

@lombok.Getter
@lombok.Setter
public class DependentRxInfo {
    private ArrayList<MinorPatient> minor;
    private ArrayList<MajorPatient> major;
}
