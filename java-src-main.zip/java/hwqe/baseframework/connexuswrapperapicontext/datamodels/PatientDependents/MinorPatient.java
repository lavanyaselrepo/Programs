package hwqe.baseframework.connexuswrapperapicontext.datamodels.PatientDependents;

@lombok.Getter
@lombok.Setter
public class MinorPatient {
    private int patientId;
    private int rxNbr;
}
