package hwqe.baseframework.connexuswrapperapicontext.datamodels.Pickup;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Drug;
import lombok.*;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MultiDrugOrderToReadyForPickUpResponse {
    public List<OrderResponse> order;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class OrderResponse {

        public Integer requestTypeCode;
        public Integer priorityId;
        public Boolean changeMode;
        public Integer patientId;
        public Integer orderId;
        public Integer packId;
        public Integer packageId;
        public Boolean visible;
        public Integer selectedIndex;
        public Integer selectedValue;
        public Integer tempPriority;
        public Object controlDate;
        public Integer siteID;
        public String pickUpDate;
        public Integer rxFillId;
        public Integer rxId;
        public Integer orderSeqNbr;
        public Integer inputId;
        public Integer rxNbr;
        public Integer orgPriorityId;
        public String fillDate;
        public String rxWrittenDate;
        public Integer requestSeqNbr;
        public String rxExpDate;
        public String inputPickUpDate;
        public String inputRxExpDate;
        public Integer requestId;
        public Integer dispenseType;
        public Boolean updateFillViaDB;
        public Integer toteNumber;
        public Integer numRefills;
        public Integer rxOriginCode;
        public Drug drug;
        public Object prescriber;
        public Boolean allowExpiredOrder;
        public Integer productMdsFamId;
        public Object omsOfferId;
        public Object omsWtxCode;
        public Object omsOrderId;
        public Object rxInfo;
        public String workQueue;
        public Object exceptionDetails;
        public Object shippingResponseData;
        public Boolean orderTypeERx;
        public Integer rxResponseCode;
        public Object poId;
        public Object futureFillDate;
        public Boolean shippingSuccessful;
        public String ndcnumber;
        public Boolean patientHasInsurance;

    }
}