package hwqe.baseframework.connexuswrapperapicontext.datamodels.Pickup;

import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Drug;
import lombok.Data;

@Data
public class CreateOrderReadyForPickupRequest {

    int priorityId;
    int dispenseType;
    int patientId;
    int siteID;
    String inputPickUpDate;
    String inputRxExpDate;
    Drug drug;
}
