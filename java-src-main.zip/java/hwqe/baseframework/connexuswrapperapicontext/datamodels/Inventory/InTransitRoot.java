package hwqe.baseframework.connexuswrapperapicontext.datamodels.Inventory;

import java.util.ArrayList;
@lombok.Getter
@lombok.Setter
public class InTransitRoot {
    public String token;
    public String app_id;
    public String trans_id;
    public String event_type;
    public String event_id;
    public Object ecommOrderId;
    public String lineageType;
    public String lineageId;
    public ArrayList<InTransitEvents> events;
}
