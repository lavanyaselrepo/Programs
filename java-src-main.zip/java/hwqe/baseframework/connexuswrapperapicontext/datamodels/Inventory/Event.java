package hwqe.baseframework.connexuswrapperapicontext.datamodels.Inventory;

@lombok.Getter
@lombok.Setter
public class Event{
    public String site_id;
    public String request_type;
    public String request_url;
    public String active_status;
}
