package hwqe.baseframework.connexuswrapperapicontext.datamodels.Inventory;


@lombok.Getter
@lombok.Setter
public class AddNDCToCycleCountPageCountList {
    public String ndc;
    public int countReasonCode;
    public int priority;
}
