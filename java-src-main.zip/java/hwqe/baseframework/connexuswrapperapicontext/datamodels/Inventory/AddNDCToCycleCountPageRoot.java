package hwqe.baseframework.connexuswrapperapicontext.datamodels.Inventory;


import java.util.ArrayList;
@lombok.Getter
@lombok.Setter
public class AddNDCToCycleCountPageRoot {
    public int storeNbr;
    public ArrayList<AddNDCToCycleCountPageCountList> countList;
}
