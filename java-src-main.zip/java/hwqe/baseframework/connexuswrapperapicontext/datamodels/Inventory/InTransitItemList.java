package hwqe.baseframework.connexuswrapperapicontext.datamodels.Inventory;
@lombok.Getter
@lombok.Setter
public class InTransitItemList {
    public String ndc;
    public String qty;
    public String xfer_mode;
    public double average_cost;
}
