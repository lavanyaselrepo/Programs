package hwqe.baseframework.connexuswrapperapicontext.datamodels.Inventory;

import java.util.ArrayList;
@lombok.Getter
@lombok.Setter
public class InTransitEvents {
    public String activity_type;
    public String request_url;
    public String site_type;
    public String source_site_id;
    public String recv_site_id;
    public String package_id;
    public String vendor_name;
    public String tracking_id;
    public String delivered_ts;
    public String item_list_count;
    public String recv_div_id;
    public String user_id;
    public String timestamp;
    public ArrayList<InTransitItemList> item_list;
}
