package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Response;

@lombok.Getter
@lombok.Setter
public class FillingItemDetailsContents {
    int deptNbr;
    int drugControlCode;
    String drugStrength;
    int mdsFamId;
    String ndcNbr;
    int onHandQty;
    int productMdsFamId;
    long upcNbr;
    String singleDispInd;
}
