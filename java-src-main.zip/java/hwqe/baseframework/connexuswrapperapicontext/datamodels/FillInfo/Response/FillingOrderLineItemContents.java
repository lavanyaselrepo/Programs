package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Response;

import java.util.ArrayList;

@lombok.Getter
@lombok.Setter
public class FillingOrderLineItemContents {
    String compoundInd;
    FillingBagInfoContents bagInfo;
    ArrayList<FillingFilItemContents> filItem;
    String emergencyFillInd;
    int fillDaysSplyQty;
    int fillQty;
    int fillType;
    int fillSeqNbr;
    String fillingStatus;
    String isOutOfStock;
    String orderLineItemId;
    String orderReqType;
    int patientId;
    String rxExpDate;
    long rxFillId;
    String rxId;
}
