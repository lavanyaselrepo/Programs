package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Response;

@lombok.Getter
@lombok.Setter
public class FillingPatientInfoContents {
    String firstName;
    String lastName;
    String optforPatAltPkg;
    int patientId;
}

