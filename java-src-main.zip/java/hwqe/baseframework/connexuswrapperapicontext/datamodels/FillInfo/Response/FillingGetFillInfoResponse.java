package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Response;

@lombok.Getter
@lombok.Setter
public class FillingGetFillInfoResponse {
    FillingFillWorkContents fillWork;
    String groupingId;
    String orderId;
    String rackNo;
    int storeNbr;
    String userId;
}
