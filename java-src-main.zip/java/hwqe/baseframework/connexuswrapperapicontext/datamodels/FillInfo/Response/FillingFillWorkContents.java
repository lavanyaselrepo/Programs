package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Response;

import hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests.FillingRtsVialItemContents;

import java.util.ArrayList;

@lombok.Getter
@lombok.Setter
public class FillingFillWorkContents {
    String estimatedPickupTime;
    String orderCommentEntry;
    String priorityId;
    ArrayList<FillingItemDetailsContents> itemDetails;
    ArrayList<FillingOrderLineItemContents> orderLineItem;
    ArrayList<FillingPatientInfoContents> patientInfo;
    ArrayList<FillingRtsVialItemContents> rtsVialItems;
}
