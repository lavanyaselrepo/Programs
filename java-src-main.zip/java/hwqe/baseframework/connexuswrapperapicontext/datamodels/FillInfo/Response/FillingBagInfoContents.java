package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Response;

@lombok.Getter
@lombok.Setter
public class FillingBagInfoContents {
    int bagNbr;
    String colorAbbr;
    String colorCode;
}
