package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Response;

@lombok.Getter
@lombok.Setter
public class FillingModifiedFillItemContents {
    int prescribedProductMdsFamId;
    int productMdsFamId;
    int itemMdsFamId;
    int fillItemQty;
    int itemSeqNbr;
}