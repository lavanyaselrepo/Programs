package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Response;

@lombok.Getter
@lombok.Setter
public class FillingFilItemContents {
    int dawCode;
    int fillItemQty;
    int itemMdsFamId;
    int itemSeqNbr;
    int prescribedProductMdsFamId;
}
