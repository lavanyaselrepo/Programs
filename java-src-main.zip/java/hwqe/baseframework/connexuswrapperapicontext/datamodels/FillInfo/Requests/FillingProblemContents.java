package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests;

@lombok.Getter
@lombok.Setter
public class FillingProblemContents {
    int problemCode;
    String dispensedNdc;
    String requestedNdc;
}

