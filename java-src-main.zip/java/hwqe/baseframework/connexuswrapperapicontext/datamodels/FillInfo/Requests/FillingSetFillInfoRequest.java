package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests;

import java.util.ArrayList;

@lombok.Getter
@lombok.Setter
public class FillingSetFillInfoRequest {
    String orderId;
    String groupingId;
    int storeNbr;
    String deviceId;
    String techUserId;
    int bagNbr;
    String labelMac;
    String reprintInd;
    ArrayList<FillingOrderLineInfoContents> orderLineInfo;
}
