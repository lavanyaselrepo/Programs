package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests;

import hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Response.FillingModifiedFillItemContents;

import java.util.ArrayList;

@lombok.Getter
@lombok.Setter
public class FillingOrderLineInfoContents {
    String rxId;
    String rxFillId;
    String fomId;
    String labelId;
    String fillWorkStatus;
    FillingProblemContents problem;
    String orderLineItemId;
    int patientId;
    int fillSeqNbr;
    int fillType;
    ArrayList<FillingSetFillItemContents> fillItem;
    String fillingStartTs;
    String fillingCompleteTs;
    String workId;
    ArrayList<FillingRtsVialItemContents> rtsVialItemsUsed;
    ArrayList<FillingModifiedFillItemContents> modifiedFillItem;
}
