package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests;

@lombok.Getter
@lombok.Setter
public class FillingGetFillInfoRequest {
    String source;
    String deviceName;
    int storeId;
    String orderId;
    int toteNbr;
    String userId;
    String assignedOrd;
}
