package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests;

@lombok.Getter
@lombok.Setter
public class FillingSetFillItemContents {
    int itemMdsFamId;
    int fillItemQty;
    int itemSeqNbr;
}
