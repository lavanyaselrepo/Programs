package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests;

@lombok.Getter
@lombok.Setter
public class FillingRtsVialItemContents {
    int itemQty;
    int mdsFamId;
    int rtsVialId;
    String vialExpDate;
    boolean vialConsumed;
    Integer rtuCode;
    String rtuCodeDesc;
    int itemQtyConsumed;
}