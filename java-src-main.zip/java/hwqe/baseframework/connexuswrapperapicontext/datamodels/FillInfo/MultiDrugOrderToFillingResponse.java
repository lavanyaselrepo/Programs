package hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MultiDrugOrderToFillingResponse {
    public List<Order> order;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Order {
        private Integer requestTypeCode;
        private Integer priorityId;
        private Boolean changeMode;
        private Integer patientId;
        private Integer orderId;
        private Integer packId;
        private Integer packageId;
        private Boolean visible;
        private Integer selectedIndex;
        private Integer selectedValue;
        private Integer tempPriority;
        private Object controlDate;
        private Integer siteID;
        private String pickUpDate;
        private Integer rxFillId;
        private Integer rxId;
        private Integer orderSeqNbr;
        private Integer inputId;
        private Integer rxNbr;
        private Integer orgPriorityId;
        private String fillDate;
        private String rxWrittenDate;
        private Integer requestSeqNbr;
        private String rxExpDate;
        private String inputPickUpDate;
        private String inputRxExpDate;
        private Integer requestId;
        private Integer dispenseType;
        private Boolean updateFillViaDB;
        private Integer toteNumber;
        private Integer numRefills;
        private Integer rxOriginCode;
        private Drug drug;
        private Object prescriber;
        private Boolean allowExpiredOrder;
        private Integer productMdsFamId;
        private Object omsOfferId;
        private Object omsWtxCode;
        private Object omsOrderId;
        private Object rxInfo;
        private String workQueue;
        private Object exceptionDetails;
        private Object shippingResponseData;
        private Boolean orderTypeERx;
        private Integer rxResponseCode;
        private Object poId;
        private Object futureFillDate;
        private Object cancellationReason;
        private Boolean fixResolutionQueue;
        private Boolean shippingSuccessful;
        private Boolean patientHasInsurance;
        private String ndcnumber;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Drug {
        private String name;
        private String ndc;
        private Integer itemId;
        private Integer rxProdId;
        private Integer controlCode;
        private Integer presMultiSrcCode;
        private Integer onHandQty;
        private String gpiCode;
        private String usualCost;
        private String actCost;
        private String orgUsualCost;
        private Integer rxNbr;
        private Integer rxFillId;
        private Integer fillQty;
        private Integer daysSupply;
    }
}