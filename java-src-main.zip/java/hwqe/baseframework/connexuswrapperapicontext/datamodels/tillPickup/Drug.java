package hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup;

import lombok.Data;

@Data
@lombok.Getter
@lombok.Setter
public class Drug{
	private String gpiCode;
	private int rxNbr;
	private String ndc;
	private String usualCost;
	private String actCost;
	private int itemId;
	private int controlCode;
	private int rxProdId;
	private String orgUsualCost;
	private String name;
	private int onHandQty;
	private int presMultiSrcCode;
	private int rxFillId;
}