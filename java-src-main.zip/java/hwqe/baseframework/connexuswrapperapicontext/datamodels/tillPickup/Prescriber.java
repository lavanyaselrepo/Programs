package hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup;

import lombok.Data;

@Data
@lombok.Getter
@lombok.Setter
public class Prescriber{
	private String dea;
	private String firstname;
	private int prescriberId;
	private String phone;
	private String npi;
	private String fullname;
	private String state;
	private int rxClinicId;
	private String lastname;
}