package hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup;

import lombok.Data;

@Data
@lombok.Getter
@lombok.Setter
public class TillPickupRequest {
	private Prescriber prescriber;
	private boolean allowExpiredOrder;
	private int patientId;
	private int siteID;
	private int orderId;
	private int toteNumber;
	private String inputRxExpDate;
	private int numRefills;
	private int dispenseType;
	private String inputPickUpDate;
	private int requestTypeCode;
	private int priorityId;
	private Drug drug;
}