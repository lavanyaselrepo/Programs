package hwqe.baseframework.connexuswrapperapicontext.utils;

import com.google.gson.Gson;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Prescriber;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.Order;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.OrderInput;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.*;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import org.assertj.core.util.DateUtil;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class WrapperUtils {

    PropertyReader prop = PropertyReader.getInstance();

    public Prescriber PrescriberDetails() {
        prop.loadCustomProperties("config/fom/");
        Prescriber prescriber = new Prescriber();
        prescriber.setFullname(prop.getProperty("fom.connexusWrapper.prescriberFullName"));
        prescriber.setFirstname(prop.getProperty("fom.connexusWrapper.prescriberFirstName"));
        prescriber.setLastname(prop.getProperty("fom.connexusWrapper.prescriberLastName"));
        prescriber.setPhone(prop.getProperty("fom.connexusWrapper.prescriberPhone"));
        prescriber.setState(prop.getProperty("fom.connexusWrapper.prescriberState"));
        prescriber.setPrescriberId(Integer.parseInt(prop.getProperty("fom.connexusWrapper.prescriberId")));
        prescriber.setRxClinicId(Integer.parseInt(prop.getProperty("fom.connexusWrapper.prescriberRxClinicId")));
        prescriber.setDea(prop.getProperty("fom.connexusWrapper.prescriberDea"));
        prescriber.setNpi(prop.getProperty("fom.connexusWrapper.prescriberNpi"));
        return prescriber;
    }

    public String buildInputOrder(OrderInput orderInput, int storeNbr, Prescriber prescriberObject) {
        DBUtils dbUtils = new DBUtils();
        Map<String, Object> rxOrderDetails;
        int rxFillId = orderInput.getDrug().getRxFillId();
        rxOrderDetails = dbUtils.getRxOrderDetailTableInfo(storeNbr, rxFillId);
        Order order = new Order();
        order.setDrug(orderInput.getDrug());
        order.setRequestTypeCode(orderInput.getOrder().getRequestTypeCode());
        order.setPriorityId(orderInput.getOrder().getPriorityId());
        order.setChangeMode(orderInput.getOrder().isChangeMode());
        order.setPatientId(orderInput.getOrder().getPatientId());
        order.setOrderId(orderInput.getOrder().getOrderId());
        order.setPackId(orderInput.getOrder().getPackId());
        order.setPackageId(orderInput.getOrder().getPackageId());
        order.setVisible(orderInput.getOrder().isVisible());
        order.setSelectedIndex(orderInput.getOrder().getSelectedIndex());
        order.setSelectedValue(orderInput.getOrder().getSelectedValue());
        order.setTempPriority(orderInput.getOrder().getTempPriority());
        order.setControlDate(orderInput.getOrder().getControlDate());
        order.setSiteID(orderInput.getOrder().getSiteID());
        order.setPickUpDate(orderInput.getOrder().getPickUpDate());
        order.setRxFillId(rxFillId);
        order.setRxId(Integer.parseInt(rxOrderDetails.get("rx_id").toString()));
        order.setOrderSeqNbr(Integer.parseInt(rxOrderDetails.get("order_seq_nbr").toString()));
        order.setInputId(orderInput.getOrder().getInputId());
        order.setRxNbr(orderInput.getOrder().getRxNbr());
        order.setOrgPriorityId(orderInput.getOrder().getOrgPriorityId());
        order.setFillDate(orderInput.getOrder().getFillDate());
        order.setRxWrittenDate(orderInput.getOrder().getRxWrittenDate());
        order.setRequestSeqNbr(orderInput.getOrder().getRequestSeqNbr());
        order.setRxExpDate(orderInput.getOrder().getRxExpDate());
        order.setInputPickUpDate(orderInput.getOrder().getInputPickUpDate());
        order.setInputRxExpDate(orderInput.getOrder().getInputRxExpDate());
        order.setInputPickUpDate(orderInput.getOrder().getInputPickUpDate());
        order.setInputRxExpDate(orderInput.getOrder().getInputRxExpDate());
        order.setRequestId(orderInput.getOrder().getRequestId());
        order.setDispenseType(orderInput.getOrder().getDispenseType());
        order.setUpdateFillViaDB(orderInput.getOrder().isUpdateFillViaDB());
        order.setToteNumber(orderInput.getOrder().getToteNumber());
        order.setNumRefills(orderInput.getOrder().getNumRefills());
        order.setDrug(orderInput.getDrug());
        order.setPrescriber(orderInput.getOrder().getPrescriber());
        order.setAllowExpiredOrder(orderInput.getOrder().isAllowExpiredOrder());
        order.setProductMdsFamId(orderInput.getOrder().getProductMdsFamId());
        order.setOmsOfferId(orderInput.getOrder().getOmsOfferId());
        order.setOmsWtxCode(orderInput.getOrder().getOmsWtxCode());
        order.setRxInfo(orderInput.getOrder().getRxInfo());
        order.setWorkQueue(orderInput.getOrder().getWorkQueue());
        order.setShippingResponseData(orderInput.getOrder().getShippingResponseData());
        order.setOrderTypeERx(orderInput.getOrder().isOrderTypeERx());
        order.setNDCNumber(orderInput.getOrder().getNDCNumber());
        return new Gson().toJson(order);
    }

   /* public Patient buildInputAddPatientDetails(String communicationID, String firstName, String lastName, String middleName, String patientName, String dob, String gender, String language, int status, boolean patientMinor, int addressTypeCode, int verifyFreCode, int patientTypeCode, String userId) {
        Patient patient = new Patient();
        AllergyInfo allergyInfo = new AllergyInfo();
        HipaaInformation hipaaInformation = new HipaaInformation();
        IcpInfo icpInfo = new IcpInfo();
        MiscPersonalInformation miscPersonalInformation = new MiscPersonalInformation();
        OtherInformation otherInformation = new OtherInformation();
        PatGeneralInfo patGeneralInfo = new PatGeneralInfo();
        PersonalInfo personalInfo = new PersonalInfo();
        PrimaryPrescriberInformation primaryPrescriberInformation = new PrimaryPrescriberInformation();
        PrimaryThirdParty primaryThirdParty = new PrimaryThirdParty();
        patient.setAllergyInfo(allergyInfo);
        primaryThirdParty.setIcpInfo(icpInfo);
        patient.setPrimaryThirdParty(primaryThirdParty);
        PatCommunicationRedesignInfo patCommunicationRedesignInfo;
        ArrayList<PatCommunicationRedesignInfo> communicationInfo = new ArrayList();
        patCommunicationRedesignInfo = new PatCommunicationRedesignInfo();
        patCommunicationRedesignInfo.setCommunicationID(communicationID);
        communicationInfo.add(patCommunicationRedesignInfo);

        patient.setPatCommunicationRedesignInfo(communicationInfo);
        personalInfo.setFirstName(firstName);
        personalInfo.setLastName(lastName);
        personalInfo.setMiddleName(middleName);
        personalInfo.setPatientName(patientName);
        personalInfo.setDob(dob);
        personalInfo.setGender(gender);
        personalInfo.setLanguage(language);
        personalInfo.setStatus(status);
        personalInfo.setIsPatientMinor(patientMinor);
        ContactInformation contactInformation;
        ArrayList<ContactInformation> conInfo = new ArrayList();
        contactInformation = new ContactInformation();
        contactInformation.setAddressTypeCode(addressTypeCode);
        conInfo.add(contactInformation);
        personalInfo.setContactInformation(conInfo);
        AddressInformation addressInformation;
        ArrayList<AddressInformation> addInfo = new ArrayList();
        addressInformation = new AddressInformation();
        addressInformation.setAddressTypeCode(addressTypeCode);
        addressInformation.setVerifyFreqCode(verifyFreCode);
        addInfo.add(addressInformation);
        personalInfo.setAddressInformation(addInfo);
        patGeneralInfo.setPersonalInfo(personalInfo);
        patGeneralInfo.setMiscPersonalInformation(miscPersonalInformation);
        patGeneralInfo.setPatientTypeCode(patientTypeCode);
        otherInformation.setUserId(userId);
        patGeneralInfo.setOtherInformation(otherInformation);
        patGeneralInfo.setHipaaInformation(hipaaInformation);
        patGeneralInfo.setPrimaryPrescriberInformation(primaryPrescriberInformation);
        patient.setPatGeneralInfo(patGeneralInfo);
        return patient;
    }*/

    public Patient buildInputAddPatient(AddPatient addPatient) {

        Patient patient = new Patient();
        AllergyInfo allergyInfo = new AllergyInfo();
        HipaaInformation hipaaInformation = new HipaaInformation();
        IcpInfo icpInfo = new IcpInfo();
        MiscPersonalInformation miscPersonalInformation = new MiscPersonalInformation();
        OtherInformation otherInformation = new OtherInformation();
        PatGeneralInfo patGeneralInfo = new PatGeneralInfo();

        hipaaInformation.setHipaaStatusCode(addPatient.getHipaaStatusCode());
        patGeneralInfo.setHipaaInformation(hipaaInformation);

        PersonalInfo personalInfo = new PersonalInfo();
        PrimaryPrescriberInformation primaryPrescriberInformation = new PrimaryPrescriberInformation();
        PrimaryThirdParty primaryThirdParty = new PrimaryThirdParty();
        patient.setAllergyInfo(allergyInfo);
        primaryThirdParty.setIcpInfo(icpInfo);
        patient.setPrimaryThirdParty(primaryThirdParty);
        PatCommunicationRedesignInfo patCommunicationRedesignInfo;
        ArrayList<PatCommunicationRedesignInfo> communicationInfo = new ArrayList();
        patCommunicationRedesignInfo = new PatCommunicationRedesignInfo();
        patCommunicationRedesignInfo.setCommunicationID(addPatient.getCommunicationID());
        communicationInfo.add(patCommunicationRedesignInfo);
        patient.setPatCommunicationRedesignInfo(communicationInfo);

        personalInfo.setFirstName(addPatient.getFirstName());
        personalInfo.setLastName(addPatient.getLastName());
        personalInfo.setMiddleName(addPatient.getMiddleName());
        personalInfo.setPatientName(addPatient.getPatientName());
        personalInfo.setDob(addPatient.getDob());
        personalInfo.setGender(addPatient.getGender());
        personalInfo.setLanguage(addPatient.getLanguage());
        personalInfo.setStatus(addPatient.getStatus());
        personalInfo.setIsPatientMinor(addPatient.getIsPatientMinor());
        personalInfo.setHipaaStatusCode(addPatient.getHipaaStatusCode());
ContactInformation contactInformation;
        ArrayList<ContactInformation> conInfo = new ArrayList();
        contactInformation = new ContactInformation();
        contactInformation.setAddressTypeCode(addPatient.getAddressTypeCode());
        contactInformation.setAddressLine1(addPatient.getAddressLine1());
        contactInformation.setAddressLine2(addPatient.getAddressLine2());
        contactInformation.setCellPhone(addPatient.getCellPhone());
        contactInformation.setCity(addPatient.getCity());
        contactInformation.setCountry(addPatient.getCountry());
        contactInformation.setHomePhone(addPatient.getHomePhone());
        contactInformation.setState(addPatient.getState());
        contactInformation.setWorkPhone(addPatient.getWorkPhone());
        contactInformation.setZipCode(addPatient.getZipCode());
        conInfo.add(contactInformation);
        personalInfo.setContactInformation(conInfo);

        AddressInformation addressInformation;
        ArrayList<AddressInformation> addInfo = new ArrayList();
        addressInformation = new AddressInformation();
        addressInformation.setAddressTypeCode(addPatient.getAddressTypeCode());
        addressInformation.setVerifyFreqCode(addPatient.getVerifyFreCode());
        addressInformation.setAddressLine1(addPatient.getAddressLine1());
        addressInformation.setAddressLine2(addPatient.getAddressLine2());
        addressInformation.setCellPhone(addPatient.getCellPhone());
        addressInformation.setCity(addPatient.getCity());
        addressInformation.setCountry(addPatient.getCountry());
        addressInformation.setHomePhone(addPatient.getHomePhone());
        addressInformation.setState(addPatient.getState());
        addressInformation.setWorkPhone(addPatient.getWorkPhone());
        addressInformation.setZipCode(addPatient.getZipCode());

        addInfo.add(addressInformation);
        personalInfo.setAddressInformation(addInfo);
        patGeneralInfo.setPersonalInfo(personalInfo);
        patGeneralInfo.setMiscPersonalInformation(miscPersonalInformation);
        patGeneralInfo.setPatientTypeCode(addPatient.getPatientTypeCode());
        otherInformation.setUserId(addPatient.getUserId());

        patGeneralInfo.setOtherInformation(otherInformation);
        patGeneralInfo.setHipaaInformation(hipaaInformation);
        patGeneralInfo.setPrimaryPrescriberInformation(primaryPrescriberInformation);
        patGeneralInfo.setHipaaStatusCode(addPatient.getHipaaStatusCode());
        patient.setPatGeneralInfo(patGeneralInfo);
        return patient;
    }

    public static long getDateDiff(long timeUpdate, long timeNow, TimeUnit timeUnit) {
        long diffInMillies = Math.abs(timeNow - timeUpdate);
        return timeUnit.convert(diffInMillies, TimeUnit.MILLISECONDS);
    }

    public AllergyInfo buildInputAllergyForAddPatient(InsertAllergy insertAllergy) {

        AllergyInfo allergyInformation = new AllergyInfo();
        allergyInformation.setAllergyClassCode(insertAllergy.getAllergyClassCode());
        allergyInformation.setAllergyClassDescription(insertAllergy.getAllergyClassDescription());
        allergyInformation.setAllergyClassCode(insertAllergy.getAllergyClassCode());
        allergyInformation.setLastChangeUserId(insertAllergy.getLastChangeUserId());
        allergyInformation.setPrescriberId(insertAllergy.getPrescriberId());
        allergyInformation.setPrescriberReferenceNbr(insertAllergy.getPrescriberReferenceNbr());
        allergyInformation.setCommentId(insertAllergy.getCommentId());
        allergyInformation.setNdcNbr(insertAllergy.getNdcNbr());
        allergyInformation.setSourceCode(insertAllergy.getSourceCode());
        allergyInformation.setFirstName(insertAllergy.getFirstName());
        allergyInformation.setLastName(insertAllergy.getLastName());
        allergyInformation.setMiddleName(insertAllergy.getMiddleName());
        allergyInformation.setLabelName(insertAllergy.getLabelName());
        allergyInformation.setCommentText(insertAllergy.getCommentText());
        allergyInformation.setShortName(insertAllergy.getShortName());
        allergyInformation.setProductMdsFamilyId(insertAllergy.getProductMdsFamilyId());
        allergyInformation.setChecked(insertAllergy.getChecked());
        allergyInformation.setUpdateIndicator(insertAllergy.getUpdateIndicator());
        allergyInformation.setTypeOfReaction(insertAllergy.getTypeOfReaction());
        allergyInformation.setReasonDeactivated(insertAllergy.getReasonDeactivated());
        allergyInformation.setAllergyClassTypeCode(insertAllergy.getAllergyClassTypeCode());

        return allergyInformation;
    }
    //to get pickupdate as tomorrows date of the current year
    public String getPickUpDate(){
        Date date = DateUtil.tomorrow();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        String todayDate = date.toString();
        return todayDate.substring(4, 10) + " " + todayDate.substring(24, 28) + " 20:00:00.000 UTC";
    }

    //to get expiry date based on year--pass the specified year needed
    public String getExpiryDate(){
        Date date = DateUtil.now();

        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        String todayDate = date.toString();
        int futureYear=Integer.parseInt(todayDate.substring(24, 28))+1;
        return  todayDate.substring(4, 10)+ " " +futureYear+ " "+ "20:00:00.000 UTC";
    }
    public String ISTToTimestamp(String utcDateString) {
        // Define the UTC date format
        SimpleDateFormat sdfUTC = new SimpleDateFormat("MMM dd yyyy HH:mm:ss.SSS 'UTC'");
        sdfUTC.setTimeZone(TimeZone.getTimeZone("UTC"));

        try {
            // Parse the UTC date string
            Date dateInUTC = sdfUTC.parse(utcDateString);

            // Get timestamp in milliseconds
            long timestamp = dateInUTC.getTime();

            // Format the timestamp in /Date(xxx)/ format
            return "/Date(" + timestamp + ")/";
        } catch (ParseException e) {
            e.printStackTrace();
            return "Exception encountered while converting DateTime";
        }
    }

    public Prescriber getErxPrescriberInfo(int storeID){
        Prescriber prescriber = new Prescriber();
        try {
            AutomationManager am = AutomationManager.getInstance();
            // Central Prescriber 20665718 is the desired prescriber for ERX with full name as 'Kraus, Adannaya MD'
            String queryToGetPrescriberDetails = "select * from prescriber where central_prescriber_id=20665718 limit 1;";
            Map<String, Object> prescriber_details = am.getConnexusDB(storeID).executeQuery(queryToGetPrescriberDetails);
            int prescriberId = Integer.parseInt(prescriber_details.get("prescriber_id").toString());
            int rxClinicId = Integer.parseInt(am.getConnexusDB(storeID).executeQuery("select * from prescriber_clinic where prescriber_id = "+prescriberId).get("clinic_id").toString());
            String prescriberState = am.getConnexusDB(storeID).executeQuery("select * from subject_address where subject_id = "+rxClinicId +" limit 1").get("state_prov_code").toString().trim();
            String phoneNumber = am.getConnexusDB(storeID).executeQuery("select * from subject_comm where subject_id = "+rxClinicId+" limit 1").get("communication_id").toString().trim();
            String prescriberDea = am.getConnexusDB(storeID).executeQuery("select * from prescriber_license where prescriber_id="+prescriberId+" and license_type_code=800 limit 1").get("license_nbr").toString().trim();
            String prescriberNpi = am.getConnexusDB(storeID).executeQuery("select * from prescriber_license where prescriber_id="+prescriberId+" and license_type_code=827 limit 1").get("license_nbr").toString();

            prescriber.setFullname(prescriber_details.get("prescbr_label_name").toString().trim());
            prescriber.setFirstname(prescriber_details.get("first_name").toString().trim());
            prescriber.setLastname(prescriber_details.get("last_name").toString().trim());
            prescriber.setPhone(phoneNumber);
            prescriber.setState(prescriberState);
            prescriber.setPrescriberId(prescriberId);
            prescriber.setRxClinicId(rxClinicId);
            prescriber.setDea(prescriberDea);
            prescriber.setNpi(prescriberNpi);

            /* Reference Values:
             prescriber.setFullname("Kraus, Adannaya MD");
             prescriber.setFirstname("ADANNAYA");prescriber.setLastname("KRAUS");prescriber.setPhone("7271272712");prescriber.setState("TX");
             prescriber.setPrescriberId(1572);prescriber.setRxClinicId(9676);prescriber.setDea("AK1236783");prescriber.setNpi("2665632446");*/

            return prescriber;
        } catch (Exception e){
            Reporter.log("The desired Prescriber was not found in store, please do a host pull, selecting a temporary prescriber");
            return this.PrescriberDetails();
        }
    }


    public String getEpochWithTimezone(LocalDate localDate) {
        // Use system default timezone
        ZoneId zoneId = ZoneId.systemDefault();

        // Convert LocalDate to ZonedDateTime at midnight in the system's default timezone
        ZonedDateTime zonedDateTime = localDate.atStartOfDay(zoneId);

        // Get the epoch time in milliseconds for the specified time zone
        long epochMilli = zonedDateTime.toInstant().toEpochMilli();

        // Get the timezone offset in seconds (e.g., -18000 for UTC-5)
        int offsetInSeconds = zonedDateTime.getOffset().getTotalSeconds();
        int hoursOffset = offsetInSeconds / 3600;
        int minutesOffset = (offsetInSeconds % 3600) / 60;

        // Format the timezone offset in `+hhmm` or `-hhmm` format
        String timezoneOffset = String.format("%+03d%02d", hoursOffset, minutesOffset);

        // Return the result in the JavaScript-like format: `/Date(epochTimeOffset)/`
        return String.format("/Date(%d%s)/", epochMilli, timezoneOffset);
    }

    //to get date which is 5 months back from tomorrow's date, formatted as 'MMM dd yyyy 18:00:00.000 UTC'
    public String getDateFiveMonthsBack(){
        Date date = DateUtil.tomorrow();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        java.util.Calendar cal = java.util.Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        cal.setTime(date);
        cal.add(java.util.Calendar.MONTH, -5);
        Date fiveMonthsBack = cal.getTime();
        String dateStr = fiveMonthsBack.toString();
        // Format: 'MMM dd yyyy 18:00:00.000 UTC'
        return dateStr.substring(4, 10) + " " + dateStr.substring(24, 28) + " 18:00:00.000 UTC";
    }
}
