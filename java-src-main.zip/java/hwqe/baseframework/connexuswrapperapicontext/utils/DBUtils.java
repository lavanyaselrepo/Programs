package hwqe.baseframework.connexuswrapperapicontext.utils;

import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DBModels.OrderDetailsBagNbr;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Response.FillingGetFillInfoResponse;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.utilities.Reporter;
import org.testng.Assert;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import hwqe.baseframework.utilities.Reporter;

public class DBUtils {

    AutomationManager am = AutomationManager.getInstance();
    Random randomGenerator = new Random();
    int toteNumber, loopCount;
    public List<DataRow> getMultiDrugInfo(IDatabaseContext cnx, String ndc) {
        String getDrugInfo = "select pp.short_name, pp.product_mds_fam_id, pp.drug_control_code, pi.multi_source_code, pi.ndc_nbr, pi.mds_fam_id, pi.on_hand_qty, pgx.gpi_code \n" +
                "from pharmacy_offering:pharmacy_product as pp,    pharmacy_offering:pharmacy_item as pi,     pharmacy_offering:product_gpi_xref as pgx \n" +
                "where pp.product_mds_fam_id = pi.product_mds_fam_id \n" +
                "and pgx.product_mds_fam_id = pi.product_mds_fam_id \n" +
                "and pi.ndc_nbr ='" + ndc + "'";
        DataTable dt = cnx.getDataTable(getDrugInfo);
        Assert.assertEquals(dt.getRowCount(), 1);
        List<DataRow> rows = dt.getDataRows();
        return rows;
    }

    public Map<String, Object> getRxOrderDetailTableInfo(int storeNumber, int rxFillId){
        return am.getConnexusDB(storeNumber).executeQuery(
                "select * from rx_order_detail where rx_fill_id = " + rxFillId + ";");
    }

    public int getToteBagNum(int storeNumber) {
        OrderDetailsBagNbr orderDetailsBagNbr;
        toteNumber = randomGenerator.nextInt(2997) + 1;
        orderDetailsBagNbr = am.getConnexusDB(storeNumber)
                .executeQuery("select tote_nbr from informix.rx_order_detail where tote_nbr = " + toteNumber + ";",
                        OrderDetailsBagNbr.class);

        while (orderDetailsBagNbr != null && loopCount < 7) {
            toteNumber = randomGenerator.nextInt(2997) + 1;
            orderDetailsBagNbr = am.getConnexusDB(storeNumber)
                    .executeQuery("select tote_nbr from informix.rx_order_detail where tote_nbr = " + toteNumber + ";",
                            OrderDetailsBagNbr.class);
            loopCount++;
        }
        return toteNumber;
    }

    // updating assigned_userid, tote_nbr, wrkstatn_host_name in rx_order_detail table to pull the records in get fill info
    public void updateProvideDataInBD(int storeNumber, int rxFillId, String userId, int toteNbr) {
        am.getConnexusDB(storeNumber).executeUpdateQuery("update rx_order_detail set assigned_userid= '" + userId + "', " +
                "tote_nbr= " + toteNbr + ", wrkstatn_host_name= 'MACADDRESS' " + ", sub_que_type_code = '1' " +
                "where rx_fill_id = " + rxFillId + ";");
    }


    public int getRxOrderDetailTableValue(int storeNbr, FillingGetFillInfoResponse getFillInfoResponse,int problemCodeForCancelFill) {
        return am.getConnexusDB(storeNbr).executeQueryForList("select * from rx21c:informix.rx_ord_dtl_problem where order_id=" + Integer.parseInt(getFillInfoResponse.getOrderId()) + " and " +
                "phm_problem_code=" + problemCodeForCancelFill).size();
    }
    public void updateUserAndToteInDB(int storeNumber, int rxFillId, String userId, int toteNbr) {
        String hostName = "MACADDRESS";
        /*am.getConnexusDB(storeNumber).executeUpdateQuery(("update rx_order_detail set assigned_userid= '" + userId + "', " +
                "tote_nbr= " + toteNbr + ", wrkstatn_host_name= 'MACADDRESS' " +
                ", sub_que_type_code = '1' " +
                "where rx_fill_id = " + rxFillId + ";"));*/
        am.getConnexusDB(storeNumber).executeUpdateQuery("update rx_order_detail set tote_Nbr="+toteNbr+" where rx_fill_id="+rxFillId);
        am.getConnexusDB(storeNumber).executeUpdateQuery("update rx_order_detail set assigned_userid='"+userId+"' where rx_fill_id="+rxFillId);
        am.getConnexusDB(storeNumber).executeUpdateQuery("update rx_order_detail set wrkstatn_host_name='MACADDRESS' where rx_fill_id="+rxFillId);
        am.getConnexusDB(storeNumber).executeUpdateQuery("update rx_order_detail set sub_que_type_code = '1' where rx_fill_id="+rxFillId);

    }
    public int getAvailableToteNbr(int storeNo) {
        Random r = new Random();
        int toteNumber = 0;
        while (true) {
            toteNumber = r.nextInt(2999);
            int retVal = am.getConnexusDB(storeNo).getScalar("select count(order_id) from rx_order_detail where tote_nbr=" + toteNumber, Integer.class);
            if (retVal == 0) {
                break;
            }
        }
        return toteNumber;
    }

    public int getNextWorkQueCode(int storeNbr, int fill_Id) {
        int NextQueCode = am.getConnexusDB(storeNbr).getScalar("select next_work_que_code from rx_order_detail where rx_fill_id=" + fill_Id, Integer.class);
        return NextQueCode;
    }

    /**
     * Retrieves the next_work_que_code from rx_order_detail for a given order_id.
     *
     * @param storeNbr the store/site number — routes to the correct Informix DB
     * @param orderId  the order ID to look up
     * @return the next_work_que_code value for that order
     */
    public int getNextWorkQueCodeByOrderId(int storeNbr, int orderId) {
        return am.getConnexusDB(storeNbr).getScalar(
                "select next_work_que_code from rx_order_detail where order_id=" + orderId,
                Integer.class
        );
    }

    public int getProblemCode(int storeNbr, int problemCode,int orderId) {
        int NoOfTransaction = am.getConnexusDB(storeNbr).executeQueryForList("select * from rx21c:informix.rx_ord_dtl_problem where order_id=" + orderId + " and " +
                " phm_problem_code=" + problemCode).size();
        return NoOfTransaction;
    }

    public void deleteRxFromDB(int siteId, int orderId, int patientId){

        //delete rx_fill_txn
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_fill_txn where rx_fill_id= " +
                        "(select rx_fill_id from rx_order_detail where order_id= " + orderId + ");" );

        //delete express_chkout_ord_resp
        am.getConnexusDB(siteId).executeUpdateQuery("delete from express_chkout_ord_resp where order_id= " + orderId + ";");

        //delete rx_ord_rbt_rqst_vial
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_ord_rbt_rqst_vial where order_id= " + orderId + ";");

        //delete rx_fill
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_fill where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");" );

        //delete rx_fill_activity
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_fill_activity where rx_fill_id = " +
                "(select rx_fill_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_ord_dtl_activty
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_ord_dtl_activty where order_id = " + orderId + ";");

        //delete rx_activity
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_activity where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_conflict
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_conflict where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_end_of_day_image
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_end_of_day_image where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_fill_item
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_fill_item where rx_fill_id = " +
                "(select rx_fill_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_linerusher_card
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_linerusher_card where rx_fill_id = " +
                "(select rx_fill_id from rx_order_detail where order_id= " + orderId + ");");

        //delete phm_mb_message
        am.getConnexusDB(siteId).executeUpdateQuery("delete from phm_mb_message where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_prsbr_license
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_prsbr_license where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_order_detail
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_order_detail where order_id= " + orderId + ";");

        //delete active_patient_rx
        am.getConnexusDB(siteId).executeUpdateQuery("delete from active_patient_rx where patient_id= " + patientId + ";");

        //delete patient
//        am.getConnexusDB(siteId).executeUpdateQuery("delete from patient where patient_id= " + patientId + ";");

    }
    public void deletePatientFromDB(int siteId, int patientId){

        //delete charge_payment
        am.getConnexusDB(siteId).executeUpdateQuery("delete from charge_payment where patient_id= " + patientId + ";");

        //delete active_patient_rx
        am.getConnexusDB(siteId).executeUpdateQuery("delete from active_patient_rx where patient_id= " + patientId + ";");

        //delete apm_user
        am.getConnexusDB(siteId).executeUpdateQuery("delete from apm_user where patient_id= " + patientId + ";");

        //delete claim_bill_fclty_ptnt
        am.getConnexusDB(siteId).executeUpdateQuery("delete from claim_bill_fclty_ptnt where patient_id= " + patientId + ";");

        //delete hipaa_rqst_patient
        am.getConnexusDB(siteId).executeUpdateQuery("delete from hipaa_rqst_patient where patient_id= " + patientId + ";");

        //delete narx_patient_request
        am.getConnexusDB(siteId).executeUpdateQuery("delete from narx_patient_request where patient_id= " + patientId + ";");

        //delete patient_care_fclty
        am.getConnexusDB(siteId).executeUpdateQuery("delete from patient_care_fclty where patient_id= " + patientId + ";");

        //delete patient_demog
        am.getConnexusDB(siteId).executeUpdateQuery("delete from patient_demog where patient_id= " + patientId + ";");

        //delete patient_verif_rqst
        am.getConnexusDB(siteId).executeUpdateQuery("delete from patient_verif_rqst where patient_id= " + patientId + ";");

        //delete phm_mb_message
        am.getConnexusDB(siteId).executeUpdateQuery("delete from phm_mb_message where patient_id= " + patientId + ";");

        //delete patient_linking
        am.getConnexusDB(siteId).executeUpdateQuery("delete from patient_linking where patient_id= " + patientId + ";");

        //delete patient_medication
        am.getConnexusDB(siteId).executeUpdateQuery("delete from patient_medication where patient_id= " + patientId + ";");

        //delete patient_notif_pref
        am.getConnexusDB(siteId).executeUpdateQuery("delete from patient_notif_pref where patient_id= " + patientId + ";");

        //delete patient_payment
        am.getConnexusDB(siteId).executeUpdateQuery("delete from patient_payment where patient_id= " + patientId + ";");

        //delete patient_signature
        am.getConnexusDB(siteId).executeUpdateQuery("delete from patient_signature where patient_id= " + patientId + ";");

        //delete phm_service
        am.getConnexusDB(siteId).executeUpdateQuery("delete from phm_service where patient_id= " + patientId + ";");

        //delete print_request
        am.getConnexusDB(siteId).executeUpdateQuery("delete from print_request where patient_id= " + patientId + ";");

        //delete ptnt_hipaa_refusal
        am.getConnexusDB(siteId).executeUpdateQuery("delete from ptnt_hipaa_refusal where patient_id= " + patientId + ";");

        //delete related_person_link
        am.getConnexusDB(siteId).executeUpdateQuery("delete from related_person_link where patient_id= " + patientId + ";");

        //delete rstr_txn
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rstr_txn where patient_id= " + patientId + ";");

        //delete rstr_txn_request
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rstr_txn_request where patient_id= " + patientId + ";");

        //delete rx_fill_pickup
        //am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_fill_pickup where patient_id= " + patientId + ";");

        //delete rx_wcb_checkin
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_wcb_checkin where patient_id= " + patientId + ";");

        //delete patient
        am.getConnexusDB(siteId).executeUpdateQuery("delete from patient where patient_id= " + patientId + ";");

    }
    //get patient due and tax amount details from rx_fill table
    public Map<String, Object> getRxFIllDetails(int siteId, int fillId){
        return am.getConnexusDB(siteId).executeQuery("select *  from rx_fill where rx_fill_id=" + fillId +";");
    }
    //update patient due in rx_fill table
    public void updatePatientDueAmnt(int siteId,int fillId,BigDecimal dueAmount){
        am.getConnexusDB(siteId).executeUpdateQuery("update rx_fill set patient_due_amt=" +dueAmount +" where rx_fill_id="+fillId + ";");
    }
    //update patient Tax in rx_fill table
    public void updatePatientTaxAmnt(int siteId, int fillId, BigDecimal taxAmount){
        am.getConnexusDB(siteId).executeUpdateQuery("update rx_fill set tax_amt=" +taxAmount +" where rx_fill_id="+fillId + ";");
    }
    public int getRxId(int siteId, int orderId){
        return
                am.getConnexusDB(siteId).getScalar("select rx_id from rx_order_detail where order_id =" + orderId, Integer.class);

    }
    public int getRxOriginCode(int siteId, int rxId){
        return
                am.getConnexusDB(siteId).getScalar("select rx_origin_code from rx where rx_id= " + rxId, Integer.class);

    }public int getrxFillId(int siteId, int orderId){
        return
                am.getConnexusDB(siteId).getScalar("select rx_fill_id from rx_order_detail where order_id =" + orderId, Integer.class);

    }

    public void updateExSaleAmtToPatientDue(int siteId,int fillId,BigDecimal expectedSaleAmt){
        am.getConnexusDB(siteId).executeUpdateQuery("update rx_fill set patient_due_amt=" +expectedSaleAmt +" where rx_fill_id="+fillId + ";");
    }

    //public static final String UPDATE_ADDRESS_TYPE_IN_PATIENT_TABLE="update patient set dflt_addr_type_cd = 3 where patient_id = {}";

    public void updatePatientAddressType(int siteId,int patientId){
        am.getConnexusDB(siteId).executeUpdateQuery("update patient set dflt_addr_type_cd = 3 where patient_id = {}"+patientId + ";");
    }
    public Map<String, Object> getRxOrderDetails(int siteId, String rxNbr){
        return am.getConnexusDB(siteId).executeQuery("select  * from rx_order_detail where rx_id in (select rx_id from rx where rx_nbr =" + rxNbr +");");
    }
    //to get order id through patient id
    public String getRxOrder(int siteId, String patientId){
        String orderId=am.getConnexusDB(siteId).getScalar("select a.order_id from rx_order_detail as a, rx as b\n" +
                "where a.rx_id = b.rx_id and b.patient_id =" + patientId, String.class);
        return orderId;
    }
    //to get rx order details through order id
    public Map<String, Object> rxOrderDetails(int siteId, String orderId){
        return am.getConnexusDB(siteId).executeQuery("select  * from rx_order_detail where order_id" + orderId +");");
    }

    public Map<String, Object> getRxOrderDetailsFromPatientId(int siteId, String patientId,int nextWorkQueCode){
        return am.getConnexusDB(siteId).executeQuery("select * from informix.rx_order_detail where next_work_que_code=" +nextWorkQueCode+ " and rx_id in (select rx_id from rx where patient_id=" + patientId +");");
    }

    public void deleteRx(int siteId, int orderId, int patientId){

        //delete rx_fill_txn
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_fill_txn where rx_fill_id= " +
                "(select rx_fill_id from rx_order_detail where order_id= " + orderId + ");" );

        //delete express_chkout_ord_resp
        am.getConnexusDB(siteId).executeUpdateQuery("delete from express_chkout_ord_resp where order_id= " + orderId + ";");

        //delete rx_ord_rbt_rqst_vial
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_ord_rbt_rqst_vial where order_id= " + orderId + ";");

        //delete rx_fill
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_fill where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");" );

        //delete rx_fill_activity
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_fill_activity where rx_fill_id = " +
                "(select rx_fill_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_ord_dtl_activty
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_ord_dtl_activty where order_id = " + orderId + ";");

        //delete rx_activity
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_activity where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_conflict
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_conflict where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_end_of_day_image
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_end_of_day_image where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_fill_item
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_fill_item where rx_fill_id = " +
                "(select rx_fill_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_linerusher_card
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_linerusher_card where rx_fill_id = " +
                "(select rx_fill_id from rx_order_detail where order_id= " + orderId + ");");

        //delete phm_mb_message
        am.getConnexusDB(siteId).executeUpdateQuery("delete from phm_mb_message where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_prsbr_license
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_prsbr_license where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx where rx_id = " +
                "(select rx_id from rx_order_detail where order_id= " + orderId + ");");

        //delete rx_order_detail
        am.getConnexusDB(siteId).executeUpdateQuery("delete from rx_order_detail where order_id= " + orderId + ";");

        //delete active_patient_rx
        am.getConnexusDB(siteId).executeUpdateQuery("delete from active_patient_rx where patient_id= " + patientId + ";");
    }

    public Map<String, Object>  getRxTableInfo(int storeNumber, String rxNbr){
        return am.getConnexusDB(storeNumber).executeQuery("select * from rx where rx_nbr =\"" + rxNbr + "\"");
    }

    public Map<String, Object> getOrderDetailsFromRxId(int storeNumber, int rx_id){
        return am.getConnexusDB(storeNumber).executeQuery("select * from rx_order_detail where rx_id =" + rx_id + " limit 1");
    }
    public DataRow getRxClinicIdAndPrescriberId(IDatabaseContext cnx){
        String prescriberDetails ="select clinic_id,prescriber_id from prescriber_clinic where clinic_id in (select subject_id from subject_comm where subject_type_code=303 and subject_id in \n" +
                "(select clinic_id from prescriber_clinic where  active_ind='Y' and primary_clinic_ind='Y' and prescriber_id in\n" +
                "(select prescriber_id from prescriber where status_code=20100))) limit 1;";
        DataTable dt = cnx.getDataTable(prescriberDetails);
        Assert.assertEquals(dt.getRowCount(), 1);
        DataRow row = dt.getDataRows().get(0);
        return row;
    }

    public DataRow getPatientInfo(IDatabaseContext cnx, int patientId) {
        String getPatientInfo = "select last_name, first_name, gender_code, birth_date from rx21c:informix.patient \n" +
                "where patient_id = " + patientId + ";";
        DataTable dt = cnx.getDataTable(getPatientInfo);
        Assert.assertEquals(dt.getRowCount(), 1);
        DataRow row = dt.getDataRows().get(0);
        return row;
    }

    public String getPharmacyState(int siteId){
        Map<String, Object> siteDetails = am.getConnexusDB(siteId).executeQuery("select state from bus_unit_addr where bu_nbr=" + siteId + " limit 1");
        return siteDetails.get("state").toString();
    }

    public int insertRxSaleDetailWithDowntimeStatus(int siteId, int rx_fill_id){

        am.getConnexusDB(siteId).executeUpdateQuery("update rx_order_detail set next_work_que_code = 10 "  +
                " where rx_fill_id = " + rx_fill_id + ";");
        
        am.getConnexusDB(siteId).executeInsertQuery("INSERT INTO rx_sale_detail values ( " +  rx_fill_id + " ,1,1201,121312,\"1234234\",1,21400, \"2024-12-03 19:48:17\" , \"test\",22.3,2200, 107,21010, 0,12.2)");

        return am.getConnexusDB(siteId).executeUpdateQuery("update rx_order_detail set next_work_que_code = 6 "  +
                " where rx_fill_id = " + rx_fill_id + ";");
    }

    public int insertRxSaleDetailWithTPSSubmitted(int siteId, int rx_fill_id){

        am.getConnexusDB(siteId).executeUpdateQuery("update rx_order_detail set next_work_que_code = 10 "  +
                " where rx_fill_id = " + rx_fill_id + ";");

        am.getConnexusDB(siteId).executeInsertQuery("update  rx_sale_detail set status_code = 21005 where rx_fill_id ="+rx_fill_id);

        return am.getConnexusDB(siteId).executeUpdateQuery("update rx_order_detail set next_work_que_code = 6 "  +
                " where rx_fill_id = " + rx_fill_id + ";");
    }

    public Map<String, Object> getDispenseTrackingDetails(int storeNumber, String omsOrderId) {
        return am.getConnexusDB(storeNumber).executeQuery("select * from dispense_po_tracking where oms_order_id=\"" + omsOrderId + "\"");
    }

    public int generateUniqueStagingBagNumber(int storeNumber){
        Random rnd = new Random();
        int bagNumber = 1000 + rnd.nextInt(7999);
        if(am.getConnexusDB(storeNumber).executeQuery("select * from rx_order_detail where tote_nbr=\"" + bagNumber + "\"") != null){
            return generateUniqueStagingBagNumber(storeNumber);
        } else {
            return bagNumber;
        }
    }

    public  Map<String, Object> getRawElectronicTransactionDetails(int siteId, String responseMessageId) {
        return am.getConnexusDB(siteId).executeQuery("select * from raw_eltnc_rx_resp where resp_message_id =\"" + responseMessageId + "\"");
    }

    public Map<String, Object> getLastRxFillId(int siteId, String rxNbr){
        return am.getConnexusDB(siteId).executeQuery("select  * from rx_order_detail where rx_id in (select rx_id from rx where rx_nbr =" + rxNbr +") order by 1 desc limit 1;");
    }

    public Map<String, Object> getOrderDetailsFromFillId(int storeNumber, String fill_id){
        return am.getConnexusDB(storeNumber).executeQuery("select * from rx_order_detail where rx_fill_id =" + fill_id + " limit 1");
    }
    public List<Map<String, Object>> getRxOrderDetailsForList(int siteId, String rxNbr){
        return am.getConnexusDB(siteId).executeQueryForList("select  * from rx_order_detail where rx_id in (select rx_id from rx where rx_nbr =" + rxNbr +");");
    }
    public Map<String, Object> getShippingDetails(int storeNumber, String phmPackageId) {
        return am.getConnexusDB(storeNumber).executeQuery("select * from phm_pk_shipping where phm_package_id=\"" + phmPackageId + "\"");
    }
    public Map<String, Object> getDispenseOrderTrackingDetails(int storeNumber, String omsOrderId) {
        String query = "select * from dispense_order_tracking where oms_order_id=\"" + omsOrderId + "\";";
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery( query);
    }
    public Map<String, Object> getDispenseToteTrackingDetails(int storeNumber, String purchaseOrderId) {
        String query = "select * from dispense_tote_tracking where purchase_order_id=\"" + purchaseOrderId + "\";";
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery(query);
    }

    public Map<String, Object> getFillTrackingDetails(int storeNumber, int rx_fill_id) {
        String query = "select * from dispense_fill_tracking where rx_fill_id=\"" + rx_fill_id + "\";";
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery(query);
    }

    public Map<String, Object> getRxRequestDetails(int storeNumber, String requestId) {
        String query = "select * from phm_rx_request where phm_request_id=\"" + requestId + "\";";
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery(query);
    }
    public Map<String, Object> getRequestDetails(int storeNumber, String oms_order_id) {
        Map<String,Object> rxDetails = am.getConnexusDB(storeNumber).executeQuery("select * from raw_eltnc_rx_resp where oms_order_id=\"" + oms_order_id + "\";");
        if (rxDetails == null || rxDetails.isEmpty()) {
            return null;
        }
        
        // Sanitize rx_response_id to prevent SQL injection
        Object rxResponseIdObj = rxDetails.get("rx_response_id");
        if (rxResponseIdObj == null) {
            Reporter.log("rx_response_id is null for oms_order_id: " + oms_order_id);
            return null;
        }
        
        String rxResponseIdValue;
        if (rxResponseIdObj instanceof Number) {
            rxResponseIdValue = String.valueOf(((Number) rxResponseIdObj).longValue());
        } else {
            try {
                rxResponseIdValue = String.valueOf(Long.parseLong(rxResponseIdObj.toString().trim()));
            } catch (NumberFormatException e) {
                Reporter.log("Invalid rx_response_id value: " + rxResponseIdObj);
                return null;
            }
        }
        
        String query = "select * from phm_rx_req_detail where rx_response_id =\"" + rxResponseIdValue + "\";";
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery(query);
    }

    public Map<String,Object> getToteActivity(int storeNumber, String packageToteId) {
        String query = "select * from dispense_tote_activity where package_tote_id = '" + packageToteId + "'";
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery( query);
    }
    public void updateFillDate(int storeNumber, int rxFillId, String fillDate){
        String updateQuery="update rx_fill set fill_date = '"+fillDate + "' where rx_fill_id = " +rxFillId;
        am.getConnexusDB(storeNumber).executeUpdateQuery(updateQuery);
    }
    public String FillQuery(String rxNumbr){
        String rxFillIdQuery = "select rx_fill_id from rx_fill where rx_id in (SELECT rx_id FROM RX where rx_nbr in (" + rxNumbr + "))";
        Reporter.log(rxFillIdQuery);
        return rxFillIdQuery;
    }

    public void updateExpDate(int storeNumber, String rxNbr, String ExpDate){
        String query = "update rx set rx_exp_date = '"+ExpDate + "' where rx_nbr ="+rxNbr+";";
        Reporter.log("Updated Expiration date: "+query);
        am.getConnexusDB(storeNumber).executeUpdateQuery(query);
    }

    public String getExpDate(int storeNumber, String rxNbr){
        String query = "select rx_exp_date from rx where rx_nbr = "+rxNbr+";";
        return am.getConnexusDB(storeNumber).executeQuery(query).get("rx_exp_date").toString();
    }


    public Map<String, Object> getRxTableByPatientIdandrxId(int storeId, int patientId, int rxId) {
        String query = "select * from rx where patient_id = " + patientId + " and rx_id = " + rxId + ";";
        Reporter.log("Fetching RX table data: " + query);
        return am.getConnexusDB(storeId).executeQuery(query);
    }

    public Map<String, Object> getEtncRxRequest(int storeNumber, int rxId) {
        String query = "select rx_rqst_type_code, request_stat_code, request_message_id from eltnc_rx_request where rx_request_id=" + rxId + " order by create_ts desc limit 1";
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery(query);
    }

    public Map<String, Object> getEtrxXferRequest(int storeNumber, int rxId) {
        String query = "select rx_id, xfer_request_seq_nbr, erx_xfer_msg_type, status_code from erx_xfer_request where rx_request_id=" + rxId + " order by create_ts desc limit 1";
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery(query);
    }

    public Map<String, Object> getRxOrderDetailForRxId(int storeNumber, int rxId) {
        String query = "select order_id, next_work_que_code, request_type_code, status_code from rx_order_detail where rx_id=" + rxId + ";";
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery(query);
    }

    public Map<String, Object> getRxOrderDetailForRxNbr(int storeNumber, String rxNbr) {
        String rxIdQuery = "select rx_id from rx where rx_nbr=\"" + rxNbr + "\"";
        Reporter.log(rxIdQuery);
        Map<String, Object> rxResult = am.getConnexusDB(storeNumber).executeQuery(rxIdQuery);
        if (rxResult == null || rxResult.get("rx_id") == null) {
            return null;
        }
        int rxId = Integer.parseInt(rxResult.get("rx_id").toString());
        Reporter.log("Found rx_id=" + rxId + " for rxNbr=" + rxNbr);
        
        String query = "select next_work_que_code, request_type_code from rx_order_detail where rx_id=" + rxId;
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery(query);
    }

    public Map<String, Object> pharmcay_message_dur_audit(int storeNumber, int rxId) {
        String query = "select * from pharmacy_message:dur_audit where rx_id=" + rxId;
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery(query);
    }

    public String getDurResponseDesc(int storeNumber, int rxId) {
        String query = "select dur_response_desc from pharmacy_message:dur_audit where rx_id=" + rxId;
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).getScalar(query, String.class);
    }

    public String getDurResponseDescByRxFillId(int storeNumber, int rxFillId) {
        String query = "select dur_response_desc from pharmacy_message:dur_audit where rx_fill_id=" + rxFillId;
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).getScalar(query, String.class);
    }

    public List<Map<String, Object>> pharmcay_message_dur_audit_list(int storeNumber, int rxId) {
        String query = "select * from pharmacy_message:dur_audit where rx_id=" + rxId;
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQueryForList(query);
    }

    public Map<String, Object> getPharmacyproductInfoDur(int storeNumber, int product_mds_fam_id) {
        String query = "select * from pharmacy_offering:pharmacy_product where product_mds_fam_id=" +  product_mds_fam_id;
    Reporter.log(query);
    return am.getConnexusDB(storeNumber).executeQuery(query);
    }

    public Map<String, Object> getPatientTableInfo(int storeNumber, int patient_id) {
        String query = "select * from patient where patient_id=" +  patient_id;
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery(query);
    }

    public Map<String, Object> getPatientTypeTextTableInfo(int storeNumber, int patient_type_code) {
        String query = "select * from patient_type_txt where patient_type_code =" +  patient_type_code;
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery(query);
    }

    public Map<String, Object> getWorkQueueSkipTableInfo(int storeNumber, int rx_id) {
        String query = "select * from work_queue_skip_info where  rx_id=" +  rx_id;
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery(query);
    }

    public List<Map<String, Object>> getrxConflictTableInfo(int storeNumber, int rx_id) {
        String query = "select * from rx_conflict where rx_id =" +  rx_id;
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQueryForList(query);
    }

    public int updaterxConflictTableforAlertResolution(int storeNumber, String user_id, String resolution_ts, int rx_id) {
        String query = "update rx_conflict set resolution_userid = '"+user_id+"', resolution_ts = '"+resolution_ts+"' where rx_id = " +  rx_id;
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeUpdateQuery(query);
    }

    public Map<String, Object> getRxOrderDetailExternalContentTableInfo(int storeNumber, int orderId){
        String query = "select * from rx_ord_dtl_external_content where order_id = " + orderId;
        Reporter.log(query);
        return am.getConnexusDB(storeNumber).executeQuery(query);
    }
 }
