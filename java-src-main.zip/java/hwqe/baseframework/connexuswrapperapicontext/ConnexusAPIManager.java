package hwqe.baseframework.connexuswrapperapicontext;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import hwqe.baseframework.AutomationManager;
import hwqe.baseframework.apicontext.ServiceRequest;
import hwqe.baseframework.apicontext.ServiceResponse;
import hwqe.baseframework.connexuscontext.ConnexusAppUtils;
import hwqe.baseframework.connexuscontext.WorkQueueCode;
import hwqe.baseframework.connexusharnessapicontext.StoreIDManager;
import hwqe.baseframework.connexuswrapperapicontext.clients.AllergyClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.CancelClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.CardPaymentClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.CentralFillClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.CosmosClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.DatabaseOpsClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.DependentPatientClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.DowntimeClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.EODClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.EODOrchestrationClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.InventoryClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.MultiRxClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.OrderCreationClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.RefillClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.ServiceAdminClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.SetFillClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.SwitchToCashClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.DrugInfoClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.FillingOrchestrationClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.FillInfoClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.InventoryClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.OrderCreationClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.OrderOrchestrationClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.OrderWorkflowClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.PartialWorkflowClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.PatientClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.PickupFlowClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.PickupOrchestrationClient;
import hwqe.baseframework.connexuswrapperapicontext.clients.PrescriberClient;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.CancelFill.CancelFill;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.CentralFill.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DBModels.EasyPay.PatientPaymentInfo;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DBModels.EasyPay.updateEasyPayCard;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.Order;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.DropOff.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Eod.MoveOrderToEODRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Requests.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.FillInfo.Response.FillingGetFillInfoResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Input.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Inventory.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.*;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.PatientDependents.DependentPatientIdAndRx;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.PatientDependents.DependentRxInfo;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.PatientDependents.MajorPatient;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.PatientDependents.MinorPatient;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Pickup.CreateOrderReadyForPickupRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Pickup.MultiDrugOrderToReadyForPickUpResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash.GetFillDetailsByOrderId;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash.InsertRxFillActivity;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.SwitchToCash.TamperResistant;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.cardAddition.AddCardRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.cardAddition.PatientPaymentInfoItem;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.deleteData.PatientAndRx;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.callConnexusService.ConnexusServiceRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.callConnexusService.ConnexusServiceResponse;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.deleteData.RxDataCleanupRequest;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.TillPickupRequest;
import hwqe.baseframework.connexuswrapperapicontext.utils.DBUtils;
import hwqe.baseframework.connexuswrapperapicontext.utils.WrapperUtils;
import hwqe.baseframework.datacontext.DataRow;
import hwqe.baseframework.datacontext.DataTable;
import hwqe.baseframework.digitalPharmacyapicontext.DigitalPharmacyAPIManager;
import hwqe.baseframework.interfaces.IDatabaseContext;
import hwqe.baseframework.models.datamodels.cosmos.TestRecord;
import hwqe.baseframework.utilities.Poller;
import hwqe.baseframework.utilities.PropertyReader;
import hwqe.baseframework.utilities.Reporter;
import hwqe.baseframework.utilities.StringUtils;
import hwqe.baseframework.vaults.AzureKeyVaultConfig;
import hwqe.baseframework.vaults.AzureKeyVaultContext;
import org.assertj.core.util.DateUtil;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openjdk.tools.sjavac.Log;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import reactor.util.function.Tuple2;
import reactor.util.function.Tuples;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static hwqe.baseframework.utilities.FileUtils.readFileToString;
import static org.junit.platform.commons.util.StringUtils.isNotBlank;

/**
 * Legacy Connexus API Manager - Compatibility Facade
 * 
 * <p><b>⚠️ DEPRECATED:</b> This class is maintained for backward compatibility only.
 * New code should use focused client classes directly.</p>
 * 
 * <h2>Refactoring Status (as of 2026-04-22)</h2>
 * <ul>
 *   <li><b>Original:</b> 5,268 lines (unmaintainable god class)</li>
 *   <li><b>Current:</b> 2,382 lines (-54.8% reduction)</li>
 *   <li><b>Extracted:</b> 28 focused client classes (all under 600 lines)</li>
 *   <li><b>Status:</b> Legacy compatibility facade with instance state issues</li>
 * </ul>
 * 
 * <h2>Architectural Issues</h2>
 * This class still contains:
 * <ul>
 *   <li>Mutable shared instance state (headers, resp, todayDate, etc.)</li>
 *   <li>Methods with hidden dependencies on instance variables</li>
 *   <li>75+ methods with implementation (not pure delegations)</li>
 * </ul>
 * 
 * <p><b>Getting to &lt;600 lines would require:</b> Converting all instance state to
 * method-local variables and refactoring all methods to pure functions. This is
 * Phase 3 work requiring 40-80 hours of effort and risk of breaking changes.</p>
 * 
 * <h2>Migration Guide</h2>
 * 
 * <table border="1">
 *   <tr><th>Use Case</th><th>Legacy (Deprecated)</th><th>New Approach (Recommended)</th></tr>
 *   <tr>
 *     <td>Order Creation</td>
 *     <td><code>connexusAPIManager.createNewOrderAndMoveToEOD(...)</code></td>
 *     <td><code>new OrderCreationClient().createOrder(...)</code></td>
 *   </tr>
 *   <tr>
 *     <td>Pickup Workflows</td>
 *     <td><code>connexusAPIManager.performVisualVerifyAndPickup(...)</code></td>
 *     <td><code>new PickupOrchestrationClient().moveToPickup(...)</code></td>
 *   </tr>
 *   <tr>
 *     <td>Multi-Rx Workflows</td>
 *     <td><code>connexusAPIManager.createMultiRxDropOffToEod(...)</code></td>
 *     <td><code>new MultiRxClient().createMultiRx(...)</code></td>
 *   </tr>
 *   <tr>
 *     <td>Payment Processing</td>
 *     <td><code>connexusAPIManager.switchToCash(...)</code></td>
 *     <td><code>new SwitchToCashClient().switchToCash(...)</code></td>
 *   </tr>
 * </table>
 * 
 * <h2>Available Client Classes</h2>
 * 
 * <h3>Order Management</h3>
 * <ul>
 *   <li>{@link OrderCreationClient} - Order creation workflows</li>
 *   <li>{@link OrderWorkflowClient} - Individual workflow state transitions</li>
 *   <li>{@link OrderOrchestrationClient} - End-to-end order orchestration</li>
 * </ul>
 * 
 * <h3>Workflow Orchestration</h3>
 * <ul>
 *   <li>{@link EODOrchestrationClient} - End-of-day workflow orchestration</li>
 *   <li>{@link PickupOrchestrationClient} - Pickup workflow orchestration</li>
 *   <li>{@link FillingOrchestrationClient} - Filling workflow orchestration</li>
 *   <li>{@link PartialWorkflowClient} - Partial/intermediate workflows</li>
 * </ul>
 * 
 * <h3>Specialized Workflows</h3>
 * <ul>
 *   <li>{@link PickupFlowClient} - Pickup process handling</li>
 *   <li>{@link DowntimeClient} - Downtime mode operations</li>
 *   <li>{@link CancelClient} - Order cancellation</li>
 *   <li>{@link RefillClient} - Prescription refills</li>
 *   <li>{@link MultiRxClient} - Multi-prescription handling</li>
 *   <li>{@link CentralFillClient} - Central fill operations</li>
 * </ul>
 * 
 * <h3>Patient & Prescriber</h3>
 * <ul>
 *   <li>{@link PatientClient} - Patient information management</li>
 *   <li>{@link DependentPatientClient} - Dependent patient management</li>
 *   <li>{@link PrescriberClient} - Prescriber information</li>
 * </ul>
 * 
 * <h3>Payment & Billing</h3>
 * <ul>
 *   <li>{@link SwitchToCashClient} - Cash payment switching</li>
 *   <li>{@link CardPaymentClient} - Credit/debit card payments</li>
 * </ul>
 * 
 * <h3>Drug & Inventory</h3>
 * <ul>
 *   <li>{@link DrugInfoClient} - Drug/medication information</li>
 *   <li>{@link FillInfoClient} - Fill information details</li>
 *   <li>{@link SetFillClient} - Fill state management</li>
 *   <li>{@link InventoryClient} - Inventory operations</li>
 * </ul>
 * 
 * <h2>Future Work (Phase 3)</h2>
 * <ul>
 *   <li>Convert all instance variables to method-local</li>
 *   <li>Refactor remaining 75 methods to pure delegations</li>
 *   <li>Extract final workflows to specialized clients</li>
 *   <li>Reduce to pure facade (&lt;600 lines)</li>
 *   <li>Estimated effort: 40-80 hours</li>
 * </ul>
 * 
 * @deprecated Use focused client classes instead. This class is maintained
 *             for backward compatibility only. See migration guide above.
 * @see OrderCreationClient
 * @see EODOrchestrationClient
 * @see PickupOrchestrationClient
 * @since 1.0 (original god class)
 * @version 2.0 (refactored to facade pattern, 2026-04-22)
 */
@Deprecated
public class ConnexusAPIManager {

    private static final String ERROR_LITERAL = "error";
    private static final String FOUR_POINT_CHECK_STATUS_MSG = "FourPointCheck API response status code did not match";
    private static final String FOUR_POINT_CHECK_ERROR_MSG = "FourPointCheck could not be completed";
    private static final String INPUT_ACCEPT_ERROR_MSG = "Input Accept could not be completed";
    private static final String CHK_DUR_ERROR_MSG = "Check DUR could not be completed";
    private static final String FILLING_ERROR_MSG = "Filling could not be completed";
    private static final String VV_ERROR_MSG = "Visual Verify could not be completed";

    AutomationManager am = AutomationManager.getInstance();
    PropertyReader prop = PropertyReader.getInstance();
    ServiceRequest req = new ServiceRequest();
    
    // Delegated clients (refactored from god class)
    private final AllergyClient allergyClient = new AllergyClient();
    private final CancelClient cancelClient = new CancelClient();
    private final CardPaymentClient cardPaymentClient = new CardPaymentClient();
    private final CentralFillClient centralFillClient = new CentralFillClient();
    private final CosmosClient cosmosClient = new CosmosClient();
    private final DatabaseOpsClient databaseOpsClient = new DatabaseOpsClient();
    private final DependentPatientClient dependentPatientClient = new DependentPatientClient();
    private final DowntimeClient downtimeClient = new DowntimeClient();
    private final EODClient eodClient = new EODClient();
    private final EODOrchestrationClient eodOrchestrationClient = new EODOrchestrationClient();
    private final InventoryClient inventoryClient = new InventoryClient();
    private final MultiRxClient multiRxClient = new MultiRxClient();
    private final OrderCreationClient orderCreationClient = new OrderCreationClient();
    private final RefillClient refillClient = new RefillClient();
    private final ServiceAdminClient serviceAdminClient = new ServiceAdminClient();
    private final SetFillClient setFillClient = new SetFillClient();
    private final SwitchToCashClient switchToCashClient = new SwitchToCashClient();
    private final DrugInfoClient drugInfoClient = new DrugInfoClient();
    private final FillInfoClient fillInfoClient = new FillInfoClient();
    private final OrderWorkflowClient orderWorkflowClient = new OrderWorkflowClient();
    private final PartialWorkflowClient partialWorkflowClient = new PartialWorkflowClient();
    private final PickupOrchestrationClient pickupOrchestrationClient = new PickupOrchestrationClient();
    private final FillingOrchestrationClient fillingOrchestrationClient = new FillingOrchestrationClient();
    private final PatientClient patientClient = new PatientClient();
    private final PickupFlowClient pickupFlowClient = new PickupFlowClient();
    private final PrescriberClient prescriberClient = new PrescriberClient();
    private final OrderOrchestrationClient orderOrchestrationClient = new OrderOrchestrationClient();
    ConnexusAppUtils connexusAppUtils = new ConnexusAppUtils();
    ServiceRequest fillReq = new ServiceRequest();
    HashMap<String, String> headers = new HashMap<>();
    ServiceResponse resp;
    String todayDate, inputPickupDate, inputRxExpDate, orderLineItemId, rx_id;
    InputResponse inputResp = new InputResponse();
    ServiceResponse dropOffResp, inputAcceptResp,fourPointCheckResp, chkDURCompleteResp, fillCompleteResp, vvCompleteResp, pickupCompleteResp, counselCompleteResp, posCompleteResp,getFillInforesponse,
            setFillInforesp,createNewOrderToPickupResp;
    List<InputResponse> multiRxVVCompleteResp = new ArrayList<>();
    List<InputResponse> multiRxPaymentCompleteResp = new ArrayList<>();
    List<InputResponse> multiRxChkDURCompleteResp = new ArrayList<>();
    WrapperUtils wrapperUtils = new WrapperUtils();
    AddCardRequest cardRequest;
    PatientPaymentInfoItem patientInfo;
    AddPatient addPatient = new AddPatient();
    Map<Integer, String> nxtWrkQueCodenText = new HashMap<>();
    DBUtils dbUtils = new DBUtils();
    InputResponse orderFillingResponse;
    int rxFillId, orderId, toteNbr, nxtWrkQueCode;
    private StringUtils strUtils;
    FillingGetFillInfoResponse getFillInfoResponse;
    ArrayList<FillingOrderLineInfoContents> orderLineInfoList = new ArrayList<>();
    int product_mds_fam_id, fill_Id, fillItemQty, mds_fam_id, on_hand_qty_BeforeSetFill, prblm_CodeTransactionInDB, nxt_wrk_que, wrkQueExpectedAftrSetFill, on_hand_qty_AftrSetFill, on_hand_qty;
    ArrayList<FillingSetFillItemContents> fillItemList = new ArrayList<>();
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
    Timestamp timestamp = new Timestamp(System.currentTimeMillis());
    String ts = sdf.format(timestamp);
    DependentPatientIdAndRx dependentPatientIdAndRx = new DependentPatientIdAndRx();
    DependentRxInfo dependent = new DependentRxInfo();
    List<InputResponse> multiRx4PointCompleteResp = new ArrayList<>();
    InputResponse inputVVResp = new InputResponse();
    List<String> multirxNbrList = new ArrayList<>();
    List<String> multirxFillNbrList = new ArrayList<>();
    JSONArray response = new JSONArray();
    JSONArray multiOrderTillPickupResp = new JSONArray();

    OpenTask openTaskReq = new OpenTask();
    Event eventReq=new Event();
    ArrayList<Event> eventList=new ArrayList<>();
    InTransitRoot inTransitReq = new InTransitRoot();
    InTransitItemList itemList = new InTransitItemList();
    InTransitEvents inTransitEventReq=new InTransitEvents();
    ArrayList<InTransitEvents> inTransitEventList=new ArrayList<>();
    ArrayList<InTransitItemList> items = new ArrayList<>();
    AddNDCToCycleCountPageRoot addInCycleCount = new AddNDCToCycleCountPageRoot();
    List<ESPNASNDetail> asnList = new ArrayList<>();
    List<ESPNFill> fillList= new ArrayList<>();
    List<ESPNBag> bagList = new ArrayList<>();
    public static long asnNumber ;
    public static long toteNumber;
    public static long shipmentId;
    public static List<String> scanPickUpCodeForCF=new ArrayList<>();

    public ConnexusAPIManager() {
        prop.loadCustomProperties("config/fom/");
    }

    /**
     * @deprecated Use {@link OrderCreationClient#createOrderAndDropOff} directly.
     */
    @Deprecated
    public ServiceResponse createOrderAndDropOff(int requestTypeCode, int priorityId, int dispenseType, int patientId, int storeNbr, String inputPickUpDate,
                                                 String inputRxExpDate, int numRefills, DataRow drugInfo) {
        return orderCreationClient.createOrderAndDropOff(requestTypeCode, priorityId, dispenseType, patientId, storeNbr, inputPickUpDate, inputRxExpDate, numRefills, drugInfo);
    }

    /**
     * @deprecated Use {@link OrderCreationClient#createOrderAndDropOff} directly.
     */
    @Deprecated
    public ServiceResponse createOrderAndDropOff(int fillQuantity, int requestTypeCode, int priorityId, int dispenseType, int patientId, int storeNbr, String inputPickUpDate,
                                                 String inputRxExpDate, int numRefills, DataRow drugInfo) {
        return orderCreationClient.createOrderAndDropOff(fillQuantity, requestTypeCode, priorityId, dispenseType, patientId, storeNbr, inputPickUpDate, inputRxExpDate, numRefills, drugInfo);
    }

    //this method creates a multi Rx order and moves it to Filling Queue
    /**
     * @deprecated Use {@link MultiRxClient#newMultiRxOrderToFilling} directly.
     */
    @Deprecated
    public ServiceResponse newMultiRxOrderToFilling(String siteId, String patientID, String priorityId, List<String> ndcList) {
        return multiRxClient.newMultiRxOrderToFilling(siteId, patientID, priorityId, ndcList);
    }

    /**
     * @deprecated Use {@link MultiRxClient#newMultiRxOrderToFillingWithFillQty} directly.
     */
    @Deprecated
    public ServiceResponse newMultiRxOrderToFillingWithFillQty(String siteId, String patientID, String priorityId, List<String> ndcList, int fillQty) {
        return multiRxClient.newMultiRxOrderToFillingWithFillQty(siteId, patientID, priorityId, ndcList, fillQty);
    }

    /**
     * @deprecated Use {@link MultiRxClient#multiRxToFillingAPICall} directly.
     */
    @Deprecated
    public ServiceResponse multiRxToFillingAPICall(MultiRxDropOffQueueRequest requestPayload) {
        return multiRxClient.multiRxToFillingAPICall(requestPayload);
    }

    /**
     * @deprecated Use {@link DrugInfoClient#fetchDrugInfo(FetchDrug)} directly.
     */
    @Deprecated
    public Drug fetchDrugInfo(FetchDrug drugPayload) {
        return drugInfoClient.fetchDrugInfo(drugPayload);
    }

    // This method will complete both INPUT and 4 Point
    /**
     * @deprecated Use {@link OrderWorkflowClient#inputAccept} directly.
     */
    @Deprecated
    public ServiceResponse inputAccept(String dropOffResponse) {
        return orderWorkflowClient.inputAccept(dropOffResponse);
    }

    /**
     * @deprecated Use {@link OrderWorkflowClient#chkDURComplete} directly.
     */
    @Deprecated
    public ServiceResponse chkDURComplete(String InputAcceptResponse) {
        return orderWorkflowClient.chkDURComplete(InputAcceptResponse);
    }

    /**
     * @deprecated Use {@link OrderWorkflowClient#fillComplete} directly.
     */
    @Deprecated
    public ServiceResponse fillComplete(String chkDURResponse) {
        return orderWorkflowClient.fillComplete(chkDURResponse);
    }

    /**
     * @deprecated Use {@link OrderWorkflowClient#vvComplete} directly.
     */
    @Deprecated
    public ServiceResponse vvComplete(String fillCompleteResponse) {
        return orderWorkflowClient.vvComplete(fillCompleteResponse);
    }

    /**
     * This method will complete only 4 Point.
     * @deprecated Use {@link OrderWorkflowClient#fourPointCheck} directly.
     */
    @Deprecated
    public ServiceResponse fourPointCheck(String InputAcceptResponse) {
        return orderWorkflowClient.fourPointCheck(InputAcceptResponse);
    }

    /**
     * @deprecated Use {@link EODClient#newOrderToEOD} directly.
     */
    @Deprecated
    public ServiceResponse newOrderToEOD(int requestTypeCode, int priorityId, int dispenseType, int patientId, int storeNbr, String inputPickUpDate,
                                         String inputRxExpDate, int numRefills, DataRow drugInfo) {
        return eodClient.newOrderToEOD(requestTypeCode, priorityId, dispenseType, patientId, storeNbr, inputPickUpDate, inputRxExpDate, numRefills, drugInfo);
    }

    /**
     * @deprecated Use {@link PatientClient#createPatient} directly.
     */
    @Deprecated
    public ServiceResponse createPatient(String firstName, String lastName, String inputDob, int storeNbr, long homePhone, long workPhone, long cellPhone) {
        return patientClient.createPatient(firstName, lastName, inputDob, storeNbr, homePhone, workPhone, cellPhone);
    }

    /**
     * @deprecated Use {@link PatientClient#createPatientWithOrWithoutTP} directly.
     */
    @Deprecated
    public int createPaientWithOrWithoutTP(CreatePatientRequest createPatientRequest) {
        return patientClient.createPatientWithOrWithoutTP(createPatientRequest);
    }

    /**
     * @deprecated Use {@link MultiRxClient#createMultiOrderAndDropOff} directly.
     */
    @Deprecated
    public ServiceResponse createMultiOrderAndDropOff(Order order, List<DataRow> drugInfo, Prescriber prescriber) {
        return multiRxClient.createMultiOrderAndDropOff(order, drugInfo, prescriber);
    }




    /**
     * @deprecated Use {@link PatientClient#addPatientWithTP} directly.
     */
    @Deprecated
    public int addPatientWithTP(String patientInfoFilePath) throws IOException {
        return patientClient.addPatientWithTP(patientInfoFilePath);
    }

    /**
     * @deprecated Use {@link OrderWorkflowClient#pickupComplete} directly.
     */
    @Deprecated
    public ServiceResponse pickupComplete(String vvCompleteResp) {
        return orderWorkflowClient.pickupComplete(vvCompleteResp);
    }

    /**
     * @deprecated Use {@link OrderWorkflowClient#counselComplete} directly.
     */
    @Deprecated
    public ServiceResponse counselComplete(String pickupCompleteResp) {
        return orderWorkflowClient.counselComplete(pickupCompleteResp);
    }

    /**
     * @deprecated Use {@link OrderWorkflowClient#posComplete} directly.
     */
    @Deprecated
    public ServiceResponse posComplete(String counselCompleteResp) {
        return orderWorkflowClient.posComplete(counselCompleteResp);
    }


    /**
     * @deprecated Use {@link DrugInfoClient#getDrugInfo(IDatabaseContext, String)} directly.
     */
    @Deprecated
    public DataRow getDrugInfo(IDatabaseContext cnx, String ndc) {
        return drugInfoClient.getDrugInfo(cnx, ndc);
    }

    /**
     * @deprecated Use {@link PrescriberClient#getPrescriberInfo(IDatabaseContext, int)} directly.
     */
    @Deprecated
    public DataRow getPrescriberInfo(IDatabaseContext cnx, int prescriber_id) {
        return prescriberClient.getPrescriberInfo(cnx, prescriber_id);
    }

    /**
     * @deprecated Use {@link PrescriberClient#getRandomPrescriberInfo(IDatabaseContext, int)} directly.
     */
    @Deprecated
    public DataRow getRandomPrescriberInfo(IDatabaseContext cnx, int prescriber_id) {
        return prescriberClient.getRandomPrescriberInfo(cnx, prescriber_id);
    }

    /**
     * Gets buParm detail from connexus for the given phmParmCode
     * */
    /**
     * @deprecated Use {@link DatabaseOpsClient#getBuParm} directly.
     */
    @Deprecated
    public DataRow getBuParm(IDatabaseContext cnx, String phmParmCode) {
        return databaseOpsClient.getBuParm(cnx, phmParmCode);
    }

    /**
     * @deprecated Use {@link DatabaseOpsClient#updateBuParmInfo} directly.
     */
    @Deprecated
    public int updateBuParmInfo(IDatabaseContext cnx, String phmParmValue, String phmParmCode) {
        return databaseOpsClient.updateBuParmInfo(cnx, phmParmValue, phmParmCode);
    }

    /**
     * @deprecated Use {@link DatabaseOpsClient#getFillTaxInfo} directly.
     */
    @Deprecated
    public DataRow getFillTaxInfo(IDatabaseContext cnx, int rxfillId, String posCalcInd) {
        return databaseOpsClient.getFillTaxInfo(cnx, rxfillId, posCalcInd);
    }

    /**
     * @deprecated Use {@link DatabaseOpsClient#insertFillTax} directly.
     */
    @Deprecated
    public int insertFillTax(IDatabaseContext cnx, int rxFillId, String posCalcInd) {
        return databaseOpsClient.insertFillTax(cnx, rxFillId, posCalcInd);
    }

    public ServiceResponse createNewOrderAndMoveToEOD(int patientId, int siteId, String inputRxExpDate, String inputPickupDate, int numRefills, DataRow drugInfo, String ndc) {
        return eodOrchestrationClient.createNewOrderAndMoveToEOD(patientId, siteId, inputRxExpDate, inputPickupDate, numRefills, drugInfo, ndc);
    }

    public ArrayList<String> createNewOrderAndMoveToPickup(int patientId, int siteId, String inputRxExpDate, String inputPickupDate, int numRefills, DataRow drugInfo, String ndc) {
        return pickupOrchestrationClient.createNewOrderAndMoveToPickup(patientId, siteId, inputRxExpDate, inputPickupDate, numRefills, drugInfo, ndc);
    }


    public ServiceResponse createNewOrderAndMoveToPickUp_SwitchToCash(int patientId, int siteId, String inputRxExpDate, String inputPickupDate, int numRefills, DataRow drugInfo, String ndc) {

        //to get pickupdate as tomorrows date of the current year
        inputPickupDate = wrapperUtils.getPickUpDate();
        //to get expiry date based on year--pass the specified year needed
        inputRxExpDate = wrapperUtils.getExpiryDate();

        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        drugInfo = getDrugInfo(cnx, ndc);

        //complete drop-off
        dropOffResp = createOrderAndDropOff(1600, 21104, 1, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        //complete Input and 4 point
        inputAcceptResp = inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains(ERROR_LITERAL), INPUT_ACCEPT_ERROR_MSG);
        inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());

        if (nxtWrkQueCode != WorkQueueCode.CHKDUR.getWorkQueueCode()) {

            downTime(inputResp.getRxFillId(), inputResp.getOrderId(), inputResp.getOrderSeqNbr(),
                    prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        }
        //complete check DUR
        chkDURCompleteResp = chkDURComplete(inputAcceptResp.getDataResponse());
        Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
        Assert.assertFalse(chkDURCompleteResp.getDataResponse().contains(ERROR_LITERAL), CHK_DUR_ERROR_MSG);
        InputResponse checkDURInputResp = chkDURCompleteResp.getDataResponse(InputResponse.class);
        //Induce wait to allow CASH/TP processing
        am.performSleep(30);

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, checkDURInputResp.getRxFillId());

        if (nxtWrkQueCode != WorkQueueCode.FILLING.getWorkQueueCode()) {

            downTime(checkDURInputResp.getRxFillId(), checkDURInputResp.getOrderId(), checkDURInputResp.getOrderSeqNbr(),
                    prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, checkDURInputResp.getRxFillId());
        }
        //complete Filling
        fillCompleteResp = fillComplete(chkDURCompleteResp.getDataResponse());
        Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillCompleteResp.getDataResponse().contains(ERROR_LITERAL), FILLING_ERROR_MSG);


        //complete VV
        vvCompleteResp = vvComplete(fillCompleteResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains(ERROR_LITERAL), VV_ERROR_MSG);

        //complete PickUp
        pickupCompleteResp = pickupComplete(vvCompleteResp.getDataResponse());
        Assert.assertEquals(pickupCompleteResp.getStatusCode(), 302, "PickupComplete API response status code did not match");
        Assert.assertFalse(pickupCompleteResp.getDataResponse().contains(ERROR_LITERAL), "Pickup could not be completed");

        //complete Counsel
        counselCompleteResp = counselComplete(pickupCompleteResp.getDataResponse());
        Assert.assertEquals(counselCompleteResp.getStatusCode(), 302, "CounselComplete API response status code did not match");
        Assert.assertFalse(counselCompleteResp.getDataResponse().contains(ERROR_LITERAL), "Counsel could not be completed");
        InputResponse counselCompleteInputResp = counselCompleteResp.getDataResponse(InputResponse.class);

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, counselCompleteInputResp.getRxFillId());

        if (nxtWrkQueCode != WorkQueueCode.POS.getWorkQueueCode()) {

            downTime(counselCompleteInputResp.getRxFillId(), counselCompleteInputResp.getOrderId(), counselCompleteInputResp.getOrderSeqNbr(),
                    prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, counselCompleteInputResp.getRxFillId());
        }

        //complete POS
        posCompleteResp = posComplete(counselCompleteResp.getDataResponse());
        Assert.assertEquals(posCompleteResp.getStatusCode(), 302, "CounselComplete API response status code did not match");
        Assert.assertFalse(posCompleteResp.getDataResponse().contains(ERROR_LITERAL), "Counsel could not be completed");
        Gson gson = new Gson();
        JsonObject json = gson.fromJson(posCompleteResp.getDataResponse(), JsonObject.class);
        return posCompleteResp;

    }

    public void insertThirdPartyInfo(String thirdPartyInfoFilePath, int patientId) throws IOException {

        String file = readFileToString(thirdPartyInfoFilePath);
        DocumentContext jsonToParse = JsonPath.parse(file);
        jsonToParse.set("$.PatientId", patientId);
        req.setRequestPayloadWithNulls(jsonToParse.json());
        req.setUrl(prop.getProperty("fom.insertThirdPartyInfoUrl"));
        headers.put("Content-Type", "application/json");
        headers.put(prop.getProperty("app.authprop"), prop.getProperty("cw.saps"));
        req.setHeaders(headers);
        Reporter.log("insertThirdParty Request Payload:\n" + req.getRequestPayload() + "\n");
        Reporter.log("insertThirdParty Request endpoint: " + req.getUrl());
        resp = am.getRestContext().performPost(req);
        Assert.assertNotNull(resp);
        Assert.assertEquals(resp.getStatusCode(), 200, "Expected status code 200 but found " + resp.getStatusCode());

    }



    public void createNewOrderAndDropOff(String createOrderFilePath, int patientId) throws IOException {

        String file = readFileToString(createOrderFilePath);
        DocumentContext jsonToParse = JsonPath.parse(file);
        jsonToParse.set("$.patientId", patientId);
        req.setRequestPayloadWithNulls(jsonToParse.json());
        req.setUrl(prop.getProperty("fom.connexusWrapper.createOrderAndDropOffUrl"));
        req.setHeaders(headers);
        Reporter.log("CreateOrderAndDropOff Request endpoint: " + req.getUrl());
        resp = am.getRestContext().performPost(req);
        Assert.assertNotNull(resp);
        Assert.assertEquals(resp.getStatusCode(), 201, "Expected status code 201 but found " + resp.getStatusCode());
    }

    /**
     * @deprecated Use {@link PickupFlowClient#newOrderToReadyForPickup} directly.
     */
    @Deprecated
    public ServiceResponse newOrderToReadyForPickup(int dispenseType, int priorityId, int patientId, int siteId, String inputPickUpDate, String inputRxExpDate) {
        return pickupFlowClient.newOrderToReadyForPickup(dispenseType, priorityId, patientId, siteId, inputPickUpDate, inputRxExpDate);
    }

    /**
     * @deprecated Use {@link PickupFlowClient#newOrderToReadyForPickup_ControlDrug} directly.
     */
    @Deprecated
    public ServiceResponse newOrderToReadyForPickup_ControlDrug(int dispenseType, int priorityId, int patientId, int siteId, String inputPickUpDate, String inputRxExpDate) {
        return pickupFlowClient.newOrderToReadyForPickup_ControlDrug(dispenseType, priorityId, patientId, siteId, inputPickUpDate, inputRxExpDate);
    }

    /**
     * @deprecated Use {@link OrderWorkflowClient#moveToEOD} directly.
     */
    @Deprecated
    public ServiceResponse moveToEOD(int rxFillId, int siteId) {
        return orderWorkflowClient.moveToEOD(rxFillId, siteId);
    }

    /**
     * @deprecated Use {@link CancelClient#cancelFill} directly.
     */
    @Deprecated
    public ServiceResponse cancelFill(CancelFill cancelFill) {
        return cancelClient.cancelFill(cancelFill);
    }

    /**
     * @deprecated Use {@link CancelClient#cancelPrescriptionUsingRxNumber} directly.
     */
    @Deprecated
    public void CancelPrescriptionUsingRxNumber(CancelFill cancelFill) {
        cancelClient.cancelPrescriptionUsingRxNumber(cancelFill);
    }

    /**
     * @deprecated Use {@link RefillClient#dropConnexusRefill} directly.
     */
    @Deprecated
    public ServiceResponse dropConnexusRefill(CreateOrderForRefill createOrderForRefill, DropOffCreateReFill dropOffCreateReFill,
                                              AcceptDropOff acceptDropOff) {
        return refillClient.dropConnexusRefill(createOrderForRefill, dropOffCreateReFill, acceptDropOff);
    }

    /**
     * @deprecated Use {@link MultiRxClient#createMultiRxAndMoveToPickup} directly.
     */
    @Deprecated
    public List<InputResponse> createMultiRxAndMoveToPickup(int patientId, int siteId, int numRefills, List<String> ndcList, Prescriber prescriberObject) {
        return multiRxClient.createMultiRxAndMoveToPickup(patientId, siteId, numRefills, ndcList, prescriberObject);
    }

    /**
     * @deprecated Use {@link PickupFlowClient#fillingToPickup} directly.
     */
    @Deprecated
    public ServiceResponse fillingToPickup(int patientId, int orderId, int storeNbr,
                                           int rxFillId, int rxId, int numRefills, String ndc, Prescriber prescriber) {
        return pickupFlowClient.fillingToPickup(patientId, orderId, storeNbr, rxFillId, rxId, numRefills, ndc, prescriber);
    }

    public List<InputResponse> multiRxFillingToPickup(int patientId, int orderId, int siteId,
                                                      List<Integer> rxFillId, List<Integer> rxId, int numRefills,
                                                      List<String> ndcList, List<Integer> orderSeqNbr) {

        ServiceRequest sreq = new ServiceRequest();
        Order order = new Order();
        Drug drug = new Drug();
        Date date = DateUtil.tomorrow();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        todayDate = date.toString();
        inputPickupDate = date.toString().substring(4, 10) + " " + date.toString().substring(24, 28) + " 18:00:00.000 UTC";
        inputRxExpDate = date.toString().substring(4, 10) + " 2025 " + "18:00:00.000 UTC";

        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);

        //get multi drug details
        List<DataRow> NDCData = new ArrayList<>();
        for (String ndc : ndcList) {
            List<DataRow> rows = dbUtils.getMultiDrugInfo(cnx, ndc);
            NDCData.addAll(rows);
        }
        Log.info("NDCList" + NDCData.size());

        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(prop.getProperty("fom.OrderPriorityId")));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);
        order.setNumRefills(numRefills);
        order.setPatientId(patientId);
        order.setSiteID(siteId);
        order.setOrderId(orderId);

        for (int i = 0; i < NDCData.size(); i++) {

            //setting order object
            order.setOrderSeqNbr(orderSeqNbr.get(i));
            order.setRxFillId(rxFillId.get(i));
            order.setRxId(rxId.get(i));
            drug.setName(NDCData.get(i).getValue("short_name").toString().trim());
            drug.setNdc(NDCData.get(i).getValue("ndc_nbr").toString().trim());
            drug.setItemId(Integer.parseInt(NDCData.get(i).getValue("mds_fam_id").toString().trim()));
            drug.setRxProdId(Integer.parseInt(NDCData.get(i).getValue("product_mds_fam_id").toString().trim()));
            drug.setControlCode(Short.parseShort(NDCData.get(i).getValue("drug_control_code").toString().trim()));
            drug.setPresMultiSrcCode(Short.parseShort(NDCData.get(i).getValue("multi_source_code").toString().trim()));
            drug.setOnHandQty(Integer.parseInt(NDCData.get(i).getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
            drug.setGpiCode(NDCData.get(i).getValue("gpi_code").toString().trim());
            drug.setUsualCost("0");
            drug.setActCost("0");
            drug.setOrgUsualCost("0");
            order.setDrug(drug);
            sreq.setRequestPayloadWithNulls(order);

            am.performSleep(60);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId.get(i));
            if (nxtWrkQueCode == WorkQueueCode.RESOLVE.getWorkQueueCode()) {
                downTime(rxFillId.get(i), orderId, order.getOrderSeqNbr(), prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
            }

            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId.get(i));
            Assert.assertEquals(nxtWrkQueCode, WorkQueueCode.FILLING.getWorkQueueCode(), "Order is not in Filling queue" );
            //fillComplete
            sreq.setUrl(prop.getProperty("fom.connexusWrapper.fillCompleteUrl"));
            headers.put("content-type", "application/json");
            sreq.setHeaders(headers);
            Reporter.logJSON("Filling complete Request", sreq.getRequestPayload());
            Log.info("Filling complete RequestPayload:\n" + sreq.getRequestPayload() + "\n");
            fillCompleteResp = am.getRestContext().performPost(sreq);
            Reporter.logJSON("Filling complete Response", fillCompleteResp.getDataResponse());
            Log.info("Filling complete ResponsePayload:\n" + fillCompleteResp.getDataResponse() + "\n");
            am.performSleep(10);
            Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
            Assert.assertFalse(fillCompleteResp.getDataResponse().contains(ERROR_LITERAL), "Fill Complete could not be completed");
            //Induce wait to allow CASH/TP processing
            am.performSleep(5);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId.get(i));
            if (nxtWrkQueCode == WorkQueueCode.RESOLVE.getWorkQueueCode()) {
                downTime(rxFillId.get(i), orderId, order.getOrderSeqNbr(), prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
            }
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, rxFillId.get(i));
            Assert.assertEquals(nxtWrkQueCode, WorkQueueCode.VISUALVERIFY.getWorkQueueCode(), "Order is not in Visual Verify queue" );
            //complete VV
            vvCompleteResp = vvComplete(fillCompleteResp.getDataResponse());
            Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "VVComplete API response status code did not match");
            Assert.assertFalse(vvCompleteResp.getDataResponse().contains(ERROR_LITERAL), VV_ERROR_MSG);
            multiRxVVCompleteResp.add(vvCompleteResp.getDataResponse(InputResponse.class));
            am.performSleep(15);
            Log.info("multiRxVVComplete ResponsePayload:\n" + vvCompleteResp.getDataResponse() + "\n");
        }
        return multiRxVVCompleteResp;
    }

    public InputResponse createNewOrderAndMoveToFilling(int patientId, int siteId, int numRefills, DataRow drugInfo, String ndc) {
        return fillingOrchestrationClient.createNewOrderAndMoveToFilling(patientId, siteId, numRefills, drugInfo, ndc);
    }

    public InputResponse createNewOrderAndMoveToFilling(int fillQuantity, int patientId, int siteId, int numRefills, DataRow drugInfo, String ndc) {
        return fillingOrchestrationClient.createNewOrderAndMoveToFilling(fillQuantity, patientId, siteId, numRefills, drugInfo, ndc);
    }


    /**
     * @deprecated Use {@link FillInfoClient#getFillInfo} directly.
     */
    @Deprecated
    public ServiceResponse getFillInfo(String source, String deviceName, int storeId, String orderId, int toteNbr, String userId, String assignedOrd) {
        return fillInfoClient.getFillInfo(source, deviceName, storeId, orderId, toteNbr, userId, assignedOrd);
    }

    /**
     * @deprecated Use {@link FillInfoClient#setFillInfo} directly.
     */
    @Deprecated
    public ServiceResponse setFillInfo(String orderId, int storeNbr, String deviceId, String techUserId, int bagNbr, String labelMac, String reprintInd,
                                       ArrayList<FillingOrderLineInfoContents> orderLineInfo) {
        return fillInfoClient.setFillInfo(orderId, storeNbr, deviceId, techUserId, bagNbr, labelMac, reprintInd, orderLineInfo);
    }

    /**
     * @deprecated Use {@link FillInfoClient#validateSetFillInfoAPIForCancelled} directly.
     */
    @Deprecated
    public void validateSetFillInfoAPIForCancelled(int storeNbr, FillingGetFillInfoResponse getFillInfoResponse, int problemCodeForCancelFill, boolean isRTSVialUsed) {
        fillInfoClient.validateSetFillInfoAPIForCancelled(storeNbr, getFillInfoResponse, problemCodeForCancelFill, isRTSVialUsed);
    }

    /**
     * @deprecated Use {@link FillInfoClient#setFillInfoAPIForCancelled} directly.
     */
    @Deprecated
    public Tuple2<Integer, Integer> setFillInfoAPIForCancelled(int storeNbr, FillingGetFillInfoResponse getFillInfoResponse, int problemCodeForCancelFill, boolean isRTSVialUsed) {
        return fillInfoClient.setFillInfoAPIForCancelled(storeNbr, getFillInfoResponse, problemCodeForCancelFill, isRTSVialUsed);
    }

    public void multiDelayReasonsForSingleRx(int patientId, int siteId, int numRefills, String ndc, int problemCodeForCancelFill, boolean isRTSVialUsed) {
        DataRow drugInfo = null;
        orderFillingResponse = createNewOrderAndMoveToFilling(patientId, siteId, numRefills, drugInfo, ndc);
        orderId = orderFillingResponse.getOrderId();
        rxFillId = orderFillingResponse.getRxFillId();
        am.performSleep(5);
        toteNbr = dbUtils.getToteBagNum(siteId);
        String userId = strUtils.generateRandomUserId();
        dbUtils.updateProvideDataInBD(siteId, rxFillId, userId, toteNbr);
        String source = prop.getProperty("fom.setSource");
        String deviceName = prop.getProperty("fom.setDeviceName");
        String assignedOrd = prop.getProperty("fom.assignedOrd");
        //getFillInfo
        getFillInforesponse = getFillInfo(source, deviceName, siteId, String.valueOf(orderId), toteNbr, userId, assignedOrd);
        Assert.assertEquals(getFillInforesponse.getStatusCode(), 200, "GetFillInfo Saps service response did not match");
        getFillInfoResponse = getFillInforesponse.getDataResponse(FillingGetFillInfoResponse.class);
        Reporter.log("getFillInfo API is logged with status code: 200");
        am.performSleep(5);
        //validate setFillInfo cancel
        validateSetFillInfoAPIForCancelled(siteId, getFillInfoResponse, problemCodeForCancelFill, isRTSVialUsed);
    }

    public HashMap<Tuple2<Integer, Integer>, Integer> createNewOrderAndMoveToCancelled(int siteId, int patientId, int priorityId, int requestTypeCode, int dispenseType, int numRefills
            , String inputPickupDate, String inputRxExpDate, DataRow drugInfo, int problemCodeForCancelFill, boolean isRTSVialUsed) {

        HashMap<Tuple2<Integer, Integer>, Integer> cancelledRxs = new HashMap<>();
        orderFillingResponse = orderTillFilling(siteId, patientId, priorityId, requestTypeCode, dispenseType, numRefills, inputPickupDate, inputRxExpDate, drugInfo).getDataResponse(InputResponse.class);
        orderId = orderFillingResponse.getOrderId();
        rxFillId = orderFillingResponse.getRxFillId();
        am.performSleep(5);
        toteNbr = dbUtils.getToteBagNum(siteId);
        String userId = strUtils.generateRandomUserId();
        dbUtils.updateProvideDataInBD(siteId, rxFillId, userId, toteNbr);
        String source = prop.getProperty("fom.setSource");
        String deviceName = prop.getProperty("fom.setDeviceName");
        String assignedOrd = prop.getProperty("fom.assignedOrd");
        //getFillInfo
        getFillInforesponse = getFillInfo(source, deviceName, siteId, String.valueOf(orderId), toteNbr, userId, assignedOrd);
        Assert.assertEquals(getFillInforesponse.getStatusCode(), 200, "GetFillInfo Saps service response did not match");
        getFillInfoResponse = getFillInforesponse.getDataResponse(FillingGetFillInfoResponse.class);
        Reporter.log("getFillInfo API is logged with status code: 200");
        am.performSleep(5);

        //Tuple2<fill_Id, rx_Id>
        Tuple2<Integer, Integer> response = setFillInfoAPIForCancelled(siteId, getFillInfoResponse, problemCodeForCancelFill, isRTSVialUsed);

        cancelledRxs.put(response, orderId);
        return cancelledRxs;
    }

    public ServiceResponse getOrderInfo(int siteId, int rxFillId, int dispenseType) {

        OrderInfo orderInfo = new OrderInfo();
        orderInfo.setSiteId(siteId);
        orderInfo.setRxFillId(rxFillId);
        req.setUrl(prop.getProperty("fom.connexusWrapper.getOrderInfo"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        req.setRequestPayload(orderInfo);
        Reporter.log("getOrderInfo API endpoint: " + req.getUrl());
        Reporter.logJSON("getOrderInfo API Request", req.getRequestPayload());
        Log.info("getOrderInfo API RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("getOrderInfo API Response", resp.getDataResponse());
        Log.info("getOrderInfo API ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }

    /**
     * @deprecated Use {@link DowntimeClient#downTime} directly.
     */
    @Deprecated
    public int downTime(int rxFillId, int orderId, int orderSeqNbr, String userId, String machineName, int siteID) {
        return downtimeClient.downTime(rxFillId, orderId, orderSeqNbr, userId, machineName, siteID);
    }


    // This method adds patient for Human and Pet with PatientTypeCode
    /**
     * @deprecated Use {@link PatientClient#addPatientWithGenericAllParam} directly.
     */
    @Deprecated
    public int addPatientWithGenericAllParam(AddPatient addPatient) {
        return patientClient.addPatientWithGenericAllParam(addPatient);
    }

    /**
     * Add patient via cnx-ui-wrapper (for cnxmodularization tests).
     * 
     * Uses wrapper endpoint instead of direct SAPS PatientService call.
     * Recommended for new code in cnxmodularization package.
     * 
     * @param addPatient Patient data
     * @return Patient ID
     * @see PatientClient#addPatientViaWrapper
     */
    public int addPatientViaWrapper(AddPatient addPatient) {
        return patientClient.addPatientViaWrapper(addPatient);
    }

    /**
     * @deprecated Use {@link PatientClient#updatePatientInfoCentralData} directly.
     */
    @Deprecated
    public void updatePatientInfoCentralData(int patientId, int siteId, String userId) {
        patientClient.updatePatientInfoCentralData(patientId, siteId, userId);
    }

    public List<InputResponse> createMultiRxDropOffToEod(int patientId, int siteId, int numRefills, List<String> ndcList, Prescriber prescriberObject) {
        return eodOrchestrationClient.createMultiRxDropOffToEod(patientId, siteId, numRefills, ndcList, prescriberObject);
    }

    /**
     * @deprecated Use {@link FillInfoClient#validateSetFillInfoForDelayReasons} directly.
     */
    @Deprecated
    public void validateSetFillInfoForDelayReasons(int storeNbr, FillingGetFillInfoResponse getFillInfoResponse, List<Integer> problemCodeStatusList) {
        fillInfoClient.validateSetFillInfoForDelayReasons(storeNbr, getFillInfoResponse, problemCodeStatusList);
    }

    public void validationOfMultiDelayReasonsForMultiRx(int patientId, int siteId, int numRefills, List<String> ndcList, Prescriber prescriberObject, List<Integer> problemCodeStatus) {
        Order order = new Order();
        order.setPrescriber(prescriberObject);

        Date date = DateUtil.tomorrow();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        todayDate = date.toString();
        inputPickupDate = date.toString().substring(4, 10) + " " + date.toString().substring(24, 28) + " 18:00:00.000 UTC";
        inputRxExpDate = date.toString().substring(4, 10) + " 2025 " + "18:00:00.000 UTC";

        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);

        //get multi drug details
        List<DataRow> NDCData = new ArrayList<>();
        for (String ndc : ndcList) {
            List<DataRow> rows = dbUtils.getMultiDrugInfo(cnx, ndc);
            NDCData.addAll(rows);
        }
        //setting order object
        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(prop.getProperty("fom.OrderPriorityId")));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);
        order.setNumRefills(numRefills);
        order.setPatientId(patientId);
        order.setSiteID(siteId);
        //create multiRx and drop-off
        dropOffResp = createMultiOrderAndDropOff(order, NDCData, prescriberObject);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createMultiRxAndDropOff API response status code did not match");
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createMultiRxAndDropOff API response status code did not match");

        MultiOrderInput multiOrderInput = dropOffResp.getDataResponse(MultiOrderInput.class);
        int drugListSize = multiOrderInput.getDrugList().size();
        OrderInput orderInput = new OrderInput();
        for (int i = 0; i < drugListSize; i++) {
            orderInput.setOrder(multiOrderInput.getOrder());
            orderInput.setDrug(multiOrderInput.getDrugList().get(i));
            String input = wrapperUtils.buildInputOrder(orderInput, siteId, prescriberObject);
            //completes input accept and 4point check
            inputAcceptResp = inputAccept(input);
            Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
            Assert.assertEquals(inputAcceptResp.getDataResponse().contains(ERROR_LITERAL), false, INPUT_ACCEPT_ERROR_MSG);
            inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
            Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());
            am.performSleep(15);
            //complete check DUR
            chkDURCompleteResp = chkDURComplete(inputAcceptResp.getDataResponse());
            Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
            Assert.assertEquals(chkDURCompleteResp.getDataResponse().contains(ERROR_LITERAL), false, CHK_DUR_ERROR_MSG);
            Reporter.log("Order successfully moved to Filling queue");
            multiRxChkDURCompleteResp.add(chkDURCompleteResp.getDataResponse(InputResponse.class));
            //Induce wait to allow CASH/TP processing
            am.performSleep(40);
        }
        //generating and getting toteNbr and updating in db
        int bagNbr;
        String userId = StringUtils.generateRandomUserId();
        int orderId = multiRxChkDURCompleteResp.get(1).getOrderId();
        bagNbr = dbUtils.getAvailableToteNbr(order.getSiteID());
        for (int j = 0; j < multiRxChkDURCompleteResp.size(); j++) {
            int rxFillId = multiRxChkDURCompleteResp.get(j).getRxFillId();
            Log.info("rxfillid:" + rxFillId);
            am.performSleep(5);
            dbUtils.updateUserAndToteInDB(siteId, rxFillId, userId, bagNbr);
        }
        //getFill
        String source = prop.getProperty("fom.setSource");
        String deviceName = prop.getProperty("fom.setDeviceName");
        String assignedOrd = prop.getProperty("fom.assignedOrd");
        //getFillInfo
        getFillInforesponse = getFillInfo(source, deviceName, siteId, String.valueOf(orderId), bagNbr, userId, assignedOrd);
        getFillInfoResponse = getFillInforesponse.getDataResponse(FillingGetFillInfoResponse.class);
        Reporter.log("getFillInfo API is logged with status code: 200");
        validateSetFillInfoForDelayReasons(siteId, getFillInfoResponse, problemCodeStatus);
    }

    /**
     * @deprecated Use {@link PatientClient#deleteRxAndPatient} directly.
     */
    @Deprecated
    public void deleteRxAndPatient(int siteId, int orderId, int patientId) {
        patientClient.deleteRxAndPatient(siteId, orderId, patientId);
    }

    public ServiceResponse singleRxFillingToEOD(int storeNbr, int rxFillId) {
        return eodOrchestrationClient.singleRxFillingToEOD(storeNbr, rxFillId);
    }

    public ServiceResponse singleRxFillingToEOD(int patientId, int orderId, int storeNbr,
                                                int rxFillId, int rxId, int numRefills, String ndc, Prescriber prescriber) {
        return eodOrchestrationClient.singleRxFillingToEOD(patientId, orderId, storeNbr, rxFillId, rxId, numRefills, ndc, prescriber);
    }

    /**
     * @deprecated Use {@link DependentPatientClient#createPatientAndMoveToEODForDependent} directly.
     */
    @Deprecated
    public DependentPatientIdAndRx createPatientAndMoveToEODForDependent(int siteId, String ndc, int numRefills, List<String> dob, AddPatient addPatientValues) throws JsonProcessingException {
        return dependentPatientClient.createPatientAndMoveToEODForDependent(siteId, ndc, numRefills, dob, addPatientValues);
    }

    /**
     * @deprecated Use {@link PatientClient#deletePatient} directly.
     */
    @Deprecated
    public void deletePatient(int siteId, int patientId) {
        patientClient.deletePatient(siteId, patientId);
    }



    /**
     * @deprecated Use {@link RefillClient#makeOrdersReadyForRefill} directly.
     */
    @Deprecated
    public List<InputResponse> makeOrdersReadyForRefill(int siteId, List<Integer> rxId, List<Integer> rxFillId) {
        return refillClient.makeOrdersReadyForRefill(siteId, rxId, rxFillId);
    }

    /**
     * @deprecated Use {@link PatientClient#getPatientInformation} directly.
     */
    @Deprecated
    public ServiceResponse getPatientInformation(int SiteID, int PatientId, String ScreenName) {
        return patientClient.getPatientInformation(SiteID, PatientId, ScreenName);
    }

    public ServiceResponse  orderToPickup(int SiteId,int patientId,int priorityId,int requestTypeCode,int dispenseType,int numRefills
            ,String inputPickupDate,int clinicId,String inputRxExpDate,DataRow drugInfo, DataRow prescriber){
        TillPickupRequest orderPickupRequest=new TillPickupRequest();
        String phoneNbr=StringUtils.phoneNumberGenerator();
        hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Drug drug = new hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Drug();
        orderPickupRequest.setRequestTypeCode(requestTypeCode);
        orderPickupRequest.setPriorityId(priorityId);
        orderPickupRequest.setDispenseType(dispenseType);
        orderPickupRequest.setPatientId(patientId);
        orderPickupRequest.setSiteID(SiteId);
        orderPickupRequest.setInputPickUpDate(inputPickupDate);
        orderPickupRequest.setInputRxExpDate(inputRxExpDate);
        orderPickupRequest.setNumRefills(numRefills);
        drug.setGpiCode(drugInfo.getValue("gpi_code"));
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr"));
        drug.setItemId(drugInfo.getValue("mds_fam_id"));
        drug.setRxProdId(Integer.parseInt(drugInfo.getValue("product_mds_fam_id").toString().trim()));
        drug.setControlCode(Integer.parseInt(drugInfo.getValue("drug_control_code").toString()));
        // drug.setPresMultiSrcCode(Integer.parseInt(drugInfo.getValue("multi_source_code").toString()));
        //drug.setOnHandQty(Integer.parseInt(drugInfo.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
        drug.setOnHandQty(Integer.parseInt(prop.getProperty("fom.OnHandQty")));
        drug.setUsualCost(prop.getProperty("fom.usualCost"));
        drug.setActCost(prop.getProperty("fom.actCost"));
        drug.setOrgUsualCost(prop.getProperty("fom.orgUsualCost"));
        hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Prescriber pres=new hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Prescriber();
        pres.setPrescriberId(prescriber.getValue("prescriber_id"));
        pres.setNpi(prop.getProperty("fom.npi"));
        pres.setDea(prop.getProperty("fom.dea"));
        pres.setPhone(phoneNbr);
        String middle_name=prescriber.getValue("middle_name");
        String first_name=prescriber.getValue("first_name");
        String last_name=prescriber.getValue("last_name");
        pres.setFullname(first_name.trim()+" "+middle_name.trim()+" "+last_name.trim());
        pres.setState(prop.getProperty("fom.state"));
        pres.setRxClinicId(clinicId);
        pres.setLastname(last_name.trim());
        pres.setFirstname(first_name.trim());
        orderPickupRequest.setDrug(drug);
        // orderPickupRequest.setPrescriber(pres);
        req.setRequestPayloadWithNulls(orderPickupRequest);
        req.setUrl(prop.getProperty("fom.connexusWrapper.createOrderTillPickupUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("OrderTillPickup Request endpoint: " + req.getUrl());
        Reporter.logJSON("OrderTillPickup Request", orderPickupRequest);
        Log.info("OrderTillPickup RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req, 3);
        Reporter.logJSON("OrderTillPickup Response", resp.getDataResponse());
        Log.info("OrderTillPickup ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }

    public ServiceResponse  orderTillFilling(int siteId,int patientId,int priorityId,int requestTypeCode,int dispenseType,int numRefills
            ,String inputPickupDate,String inputRxExpDate,DataRow drugInfo){

        //complete drop-off
        dropOffResp = createOrderAndDropOff(1600, 21104, 1, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        //move order to filling
        req.setRequestPayload(dropOffResp.getDataResponse());
        req.setUrl(prop.getProperty("fom.connexusWrapper.createOrderTillFillingUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("OrderTillFilling Request endpoint: " + req.getUrl());
        Reporter.logJSON("OrderTillFilling Request", dropOffResp.getDataResponse(InputResponse.class));
        Log.info("OrderTillFilling RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req, 3);
        Reporter.logJSON("OrderTillFilling Response", resp.getDataResponse());
        Log.info("OrderTillFilling ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }

    /**
     * @deprecated Use {@link PatientClient#deletePatientAndRx} directly.
     */
    @Deprecated
    public ServiceResponse deletePatientAndRx(PatientAndRx patientAndRx) {
        return patientClient.deletePatientAndRx(patientAndRx);
    }

    //Method to create new orderToPickup without prescriber details in input
    public ServiceResponse  orderToPickup(int SiteId,int patientId,int priorityId,int requestTypeCode,int dispenseType,int numRefills
            ,String inputPickupDate,String inputRxExpDate,DataRow drugInfo){
        TillPickupRequest orderPickupRequest=new TillPickupRequest();
        String phoneNbr=StringUtils.phoneNumberGenerator();
        hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Drug drug = new hwqe.baseframework.connexuswrapperapicontext.datamodels.tillPickup.Drug();
        orderPickupRequest.setRequestTypeCode(requestTypeCode);
        orderPickupRequest.setPriorityId(priorityId);
        orderPickupRequest.setDispenseType(dispenseType);
        orderPickupRequest.setPatientId(patientId);
        orderPickupRequest.setSiteID(SiteId);
        orderPickupRequest.setInputPickUpDate(inputPickupDate);
        orderPickupRequest.setInputRxExpDate(inputRxExpDate);
        orderPickupRequest.setNumRefills(numRefills);
        drug.setGpiCode(drugInfo.getValue("gpi_code"));
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr"));
        drug.setItemId(drugInfo.getValue("mds_fam_id"));
        drug.setRxProdId(Integer.parseInt(drugInfo.getValue("product_mds_fam_id").toString().trim()));
        drug.setControlCode(Integer.parseInt(drugInfo.getValue("drug_control_code").toString()));
        drug.setPresMultiSrcCode(Integer.parseInt(drugInfo.getValue("multi_source_code").toString()));
        drug.setOnHandQty(Integer.parseInt(prop.getProperty("fom.OnHandQty")));
        drug.setUsualCost(prop.getProperty("fom.usualCost"));
        drug.setActCost(prop.getProperty("fom.actCost"));
        drug.setOrgUsualCost(prop.getProperty("fom.orgUsualCost"));
        orderPickupRequest.setDrug(drug);
        req.setRequestPayloadWithNulls(orderPickupRequest);
        req.setUrl(prop.getProperty("fom.connexusWrapper.createOrderTillPickupUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("OrderTillPickup Request endpoint: " + req.getUrl());
        Reporter.logJSON("OrderTillPickup Request", orderPickupRequest);
        Log.info("OrderTillPickup RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req, 3);
        Reporter.logJSON("OrderTillPickup Response", resp.getDataResponse());
        Log.info("OrderTillPickup ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }

    /**
     * @deprecated Use {@link CardPaymentClient#addCardToPatientAccount} directly.
     */
    @Deprecated
    public ServiceResponse addCardToPatientAccount(String patientId,String strNbr,String cardRefNbr,String cardHolderName,String expirYearNbr,String expirMoNbr,String p2peToken,String startDate,String phmPymtMethod){
        return cardPaymentClient.addCardToPatientAccount(patientId, strNbr, cardRefNbr, cardHolderName, expirYearNbr, expirMoNbr, p2peToken, startDate, phmPymtMethod);
    }


    /**
     * @deprecated Use {@link CardPaymentClient#getCardDetails} directly.
     */
    @Deprecated
    public ServiceResponse getCardDetails(String patientId,String strNbr){
        return cardPaymentClient.getCardDetails(patientId, strNbr);
    }

    /**
     * @deprecated Use {@link CardPaymentClient#buildPatientPaymentInfo} directly.
     */
    @Deprecated
    public List<PatientPaymentInfoItem> patientPaymentInfo(String cardRefNbr, String cardHolderName, String expirYearNbr, String expirMoNbr, String p2peToken, String startDate,String phmPymtMethod){
        return cardPaymentClient.buildPatientPaymentInfo(cardRefNbr, cardHolderName, expirYearNbr, expirMoNbr, p2peToken, startDate, phmPymtMethod);
    }

    /**
     * @deprecated Use {@link AllergyClient#addAllergyInfo} directly.
     */
    @Deprecated
    public void getAddAllergyInfo(InsertAllergy insertAllergy, int patientId, int siteId) throws IOException {
        allergyClient.addAllergyInfo(insertAllergy, patientId, siteId);
    }

    /**
     * @deprecated Use {@link AllergyClient#addPatientWithAllergy} directly.
     */
    @Deprecated
    public void addPatientWithAllergy(int siteId, InsertAllergy insertAllergy, AddPatient addPatient) throws IOException {
        allergyClient.addPatientWithAllergy(siteId, insertAllergy, addPatient);
    }

    /**
     * @deprecated Use {@link AllergyClient#checkPatientSupportedAllergyInfo} directly.
     */
    @Deprecated
    public void checkPatientSupportedAllergyInfo(int patientId, int siteId) throws IOException {
        allergyClient.checkPatientSupportedAllergyInfo(patientId, siteId);
    }

    /**
     * @deprecated Use {@link PatientClient#deletePetPatient} directly.
     */
    @Deprecated
    public void deletePetPatient(int siteId, int patientId) {
        patientClient.deletePetPatient(siteId, patientId);
    }

    /**
     * @deprecated Use {@link PatientClient#getUpdatePatientReq} directly.
     */
    @Deprecated
    public ServiceRequest getUpdatePatientReq(int siteId, int patientId) {
        return patientClient.getUpdatePatientReq(siteId, patientId);
    }

    /**
     * @deprecated Use {@link MultiRxClient#multiRxFillingToEOD} directly.
     */
    @Deprecated
    public List<InputResponse> multiRxFillingToEOD(int patientId, int orderId, int siteId,
            List<Integer> rxFillId, List<Integer> rxId, int numRefills,
            List<String> ndcList, List<Integer> rxNbr) {
        return multiRxClient.multiRxFillingToEOD(patientId, orderId, siteId, rxFillId, rxId, numRefills, ndcList, rxNbr);
    }

    /**
     * @deprecated Use {@link DependentPatientClient#createPatientwithMultirxAndMoveToEODForDependent} directly.
     */
    @Deprecated
    public DependentPatientIdAndRx createPatientwithMultirxAndMoveToEODForDependent(int siteId, List<String> ndcList, int numRefills, List<String> dob, AddPatient addPatientValues, Prescriber prescriberObject) throws JsonProcessingException {
        return dependentPatientClient.createPatientwithMultirxAndMoveToEODForDependent(siteId, ndcList, numRefills, dob, addPatientValues, prescriberObject);
    }

    /**
     * @deprecated Use {@link CentralFillClient#createCFOrderAndDropOff} directly.
     */
    @Deprecated
    public ServiceResponse createCFOrderAndDropOff(Order order, List<DataRow> drugInfo, Prescriber prescriber) {
        return centralFillClient.createCFOrderAndDropOff(order, drugInfo, prescriber);
    }

    public ServiceResponse getFillDetailsByOrderId(int siteId, int orderId, int orderSeqNbr) {
        GetFillDetailsByOrderId getFillDetailsByOrderId = new GetFillDetailsByOrderId();
        getFillDetailsByOrderId.setSiteID(siteId);
        getFillDetailsByOrderId.setOrderId(orderId);
        getFillDetailsByOrderId.setOrderSeqNbr(orderSeqNbr);
        req.setRequestPayloadWithNulls(getFillDetailsByOrderId);
        String serviceEndPointUrl = StoreIDManager.createEndPointURL(String.valueOf(siteId),
                prop.getProperty("fom.connexusWrapper.portNo"), prop.getProperty("fom.connexusWrapper.sapsUrl"),
                prop.getProperty("fom.connexusWrapper.getFillDetailsByOrderIdEndPoint"));
        req.setUrl(serviceEndPointUrl);
        headers.put("content-type", "application/json");
        headers.put("Authorization", prop.getProperty("cs.header.authorization"));
        req.setHeaders(headers);

        ServiceResponse getFillresp = am.getRestContext().performPost(req);
        Assert.assertEquals(getFillresp.getStatusCode(), 200, "Get Fill Details API response status code did not match");
        return getFillresp;
    }

    /**
     * @deprecated Use {@link SetFillClient#buildSetFill} directly.
     */
    @Deprecated
    public void buildSetFill(int siteId, int orderId, int orderSeqNbr) throws IOException, org.json.simple.parser.ParseException {
        setFillClient.buildSetFill(siteId, orderId, orderSeqNbr);
    }

    public void switchToCash(int siteId, int orderId, int orderSeqNbr) throws IOException, org.json.simple.parser.ParseException {
        InsertRxFillActivity insertRxFillActivity= new InsertRxFillActivity();
        int rxFillId= dbUtils.getrxFillId(siteId,orderId);
        int activityCode= Integer.parseInt(prop.getProperty("fom.activityCode"));
        insertRxFillActivity.setSiteID(siteId);
        insertRxFillActivity.setRxFillId(rxFillId);
        insertRxFillActivity.setActivityCode(activityCode);
        insertRxFillActivity.setUserId(prop.getProperty("fom.usereId"));
        req.setRequestPayloadWithNulls(insertRxFillActivity);
        String serviceEndPointUrl = StoreIDManager.createEndPointURL(String.valueOf(siteId),
                prop.getProperty("fom.connexusWrapper.portNo"), prop.getProperty("fom.connexusWrapper.sapsUrl"),
                prop.getProperty("fom.connexusWrapper.InsertRxFillActivityEndpoint"));
        req.setUrl(serviceEndPointUrl);
        headers.put("content-type", "application/json");
        headers.put("Authorization", prop.getProperty("cs.header.authorization"));
        req.setHeaders(headers);
        ServiceResponse insertRxFillresp = am.getRestContext().performPost(req);
        Assert.assertEquals(insertRxFillresp.getStatusCode(), 200, "Insert RX Fill Activity API response status code did not match");
        inputResp = insertRxFillresp.getDataResponse(InputResponse.class);
        buildSetFill(siteId, orderId, orderSeqNbr);

    }

    /**
     * @deprecated Use {@link SwitchToCashClient#switchToCash} directly.
     */
    @Deprecated
    public void switchToCash(String inputAcceptResponse) {
        switchToCashClient.switchToCash(inputAcceptResponse);
    }

    public void resolvedTSProblemForTamperResistant(int siteId, int orderId, int rxId, int rxOriginCode, int ordSeqNbr) {
        TamperResistant tamperResistant = new TamperResistant();
        tamperResistant.setOrderId(orderId);
        tamperResistant.setRxId(rxId);
        tamperResistant.setOrderSeqNbr(ordSeqNbr);
        tamperResistant.setProblemSeqNbr(Integer.parseInt(prop.getProperty("fom.problemSeqNbr")));
        tamperResistant.setProblemCode(Integer.parseInt(prop.getProperty("fom.problemCode")));
        tamperResistant.setTrblsMethodCode(Integer.parseInt(prop.getProperty("fom.trblsMethodCode")));
        tamperResistant.setUserId(prop.getProperty("fom.usereId"));
        tamperResistant.setTamper(prop.getProperty("fom.tamper"));
        tamperResistant.setRxOriginCode(rxOriginCode);
        tamperResistant.setWorkQueueCode(Integer.parseInt(prop.getProperty("fom.workQueueCode")));
        tamperResistant.setSiteID(siteId);

        req.setRequestPayloadWithNulls(tamperResistant);
        String serviceEndPointUrl = StoreIDManager.createEndPointURL(String.valueOf(siteId),
                prop.getProperty("fom.connexusWrapper.portNo"), prop.getProperty("fom.connexusWrapper.sapsUrlTamperResis"),
                prop.getProperty("fom.connexusWrapper.ResolvedTSProblemForTamperResistantEP"));
        req.setUrl(serviceEndPointUrl);
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        ServiceResponse tampResistanceResp = am.getRestContext().performPost(req);
        Assert.assertEquals(tampResistanceResp.getStatusCode(), 200, "Tamper Resistant API response status code did not match");
    }

    public void createOrderAndMoveTo4Pt_SwitchToCash(int patientId, int siteId, int numRefills, String ndc) throws IOException, org.json.simple.parser.ParseException {

        //to get pickupdate as tomorrows date of the current year
        inputPickupDate = wrapperUtils.getPickUpDate();
        //to get expiry date based on year--pass the specified year needed
        inputRxExpDate = wrapperUtils.getExpiryDate();
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow drugInfo = getDrugInfo(cnx, ndc);

        //complete drop-off
        int orderReqType = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrdPriorityId"));
        int orderDispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));
        dropOffResp = createOrderAndDropOff(orderReqType, priorityId, orderDispenseType, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        //complete Input and 4 point
        inputAcceptResp = inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains(ERROR_LITERAL), INPUT_ACCEPT_ERROR_MSG);
        inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());

        int orderId = inputResp.getOrderId();
        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        int orderSeqNbr = inputResp.getOrderSeqNbr();
        if (nxtWrkQueCode == WorkQueueCode.RESOLVE.getWorkQueueCode()) {
            switchToCash(inputAcceptResp.getDataResponse());
        }
    }


    public ArrayList<String> createOrderAndMoveTo4Pt(int patientId, int siteId, int numRefills, String ndc) throws IOException, org.json.simple.parser.ParseException {
        return partialWorkflowClient.createOrderAndMoveTo4Pt(patientId, siteId, numRefills, ndc);
    }

    public ServiceResponse createOrderAndMoveTo4PtasResponse(int patientId, int siteId, int numRefills, String ndc) throws IOException, org.json.simple.parser.ParseException {
        return partialWorkflowClient.createOrderAndMoveTo4PtAsResponse(patientId, siteId, numRefills, ndc);
    }

    public ArrayList<String> createOrderAndMoveToPickUp_SwitchToCash_Consent(int patientId, int siteId, int numRefills, String ndc) throws IOException, org.json.simple.parser.ParseException {

        //to get pickupdate as tomorrows date of the current year
        inputPickupDate = wrapperUtils.getPickUpDate();
        //to get expiry date based on year--pass the specified year needed
        inputRxExpDate = wrapperUtils.getExpiryDate();
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow drugInfo = getDrugInfo(cnx, ndc);

        //complete drop-off
        int orderReqType = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrdPriorityId"));
        int orderDispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));
        dropOffResp = createOrderAndDropOff(orderReqType, priorityId, orderDispenseType, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        //complete Input and 4 point
        inputAcceptResp = inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains(ERROR_LITERAL), INPUT_ACCEPT_ERROR_MSG);
        inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());

        int orderId = inputResp.getOrderId();
        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        int orderSeqNbr = inputResp.getOrderSeqNbr();
        if (nxtWrkQueCode == WorkQueueCode.RESOLVE.getWorkQueueCode()) {
            switchToCash(inputAcceptResp.getDataResponse());
        }
        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());

        ArrayList<String> rxDetails = new ArrayList<>();
        if(nxtWrkQueCode==WorkQueueCode.FOURPOINT.getWorkQueueCode()) {
            fourPointCheckResp = fourPointCheck(inputAcceptResp.getDataResponse());
            Assert.assertEquals(fourPointCheckResp.getStatusCode(), 302, FOUR_POINT_CHECK_STATUS_MSG);
            Assert.assertFalse(fourPointCheckResp.getDataResponse().contains(ERROR_LITERAL), FOUR_POINT_CHECK_ERROR_MSG);
            inputResp = fourPointCheckResp.getDataResponse(InputResponse.class);
        }

        int rxFillId = inputResp.getRxFillId();
        Map<String, Object> taxDetails;
        taxDetails = dbUtils.getRxFIllDetails(siteId, rxFillId);
        BigDecimal expectedSaleAmt = (BigDecimal) taxDetails.get("expected_sale_amt");
        BigDecimal dueAmntAfterDowntime = (BigDecimal) taxDetails.get("patient_due_amt");
        if (dueAmntAfterDowntime.compareTo(BigDecimal.ZERO) <= 0) {
            dbUtils.updateExSaleAmtToPatientDue(siteId, rxFillId, expectedSaleAmt);
        }

        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());

        inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());
        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        if (nxtWrkQueCode != WorkQueueCode.CHKDUR.getWorkQueueCode()) {
            downTime(inputResp.getRxFillId(), inputResp.getOrderId(), inputResp.getOrderSeqNbr(),
                    prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        }
        //complete check DUR
        chkDURCompleteResp = chkDURComplete(inputAcceptResp.getDataResponse());
        Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
        Assert.assertFalse(chkDURCompleteResp.getDataResponse().contains(ERROR_LITERAL), CHK_DUR_ERROR_MSG);
        InputResponse checkDURInputResp = chkDURCompleteResp.getDataResponse(InputResponse.class);
        //Induce wait to allow CASH/TP processing
        am.performSleep(30);

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, checkDURInputResp.getRxFillId());

        if (nxtWrkQueCode != WorkQueueCode.FILLING.getWorkQueueCode()) {
            downTime(checkDURInputResp.getRxFillId(), checkDURInputResp.getOrderId(), checkDURInputResp.getOrderSeqNbr(),
                    prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, checkDURInputResp.getRxFillId());
        }
        //complete Filling
        fillCompleteResp = fillComplete(chkDURCompleteResp.getDataResponse());
        Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
        Assert.assertFalse(fillCompleteResp.getDataResponse().contains(ERROR_LITERAL), FILLING_ERROR_MSG);

        //complete VV
        vvCompleteResp = vvComplete(fillCompleteResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains(ERROR_LITERAL), VV_ERROR_MSG);

        rxDetails.add(String.valueOf(inputResp.getRxNbr()));
        rxDetails.add(String.valueOf(inputResp.getRxFillId()));
        rxDetails.add(String.valueOf(inputResp.getRxId()));
        return rxDetails;
    }

    public ArrayList<String> createOrderAndMoveToFilling_SwitchToCash_Consent(int patientId, int siteId, int numRefills, String ndc) throws IOException, org.json.simple.parser.ParseException {

        //to get pickupdate as tomorrows date of the current year
        inputPickupDate = wrapperUtils.getPickUpDate();
        //to get expiry date based on year--pass the specified year needed
        inputRxExpDate = wrapperUtils.getExpiryDate();
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow drugInfo = getDrugInfo(cnx, ndc);

        //complete drop-off
        int orderReqType = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrdPriorityId"));
        int orderDispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));
        dropOffResp = createOrderAndDropOff(orderReqType, priorityId, orderDispenseType, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        //complete Input and 4 point
        inputAcceptResp = inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains(ERROR_LITERAL), INPUT_ACCEPT_ERROR_MSG);
        inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());

        int orderId = inputResp.getOrderId();
        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        int orderSeqNbr = inputResp.getOrderSeqNbr();
        if (nxtWrkQueCode == WorkQueueCode.RESOLVE.getWorkQueueCode()) {

            switchToCash(inputAcceptResp.getDataResponse());
        }

        ArrayList<String> rxDetails = new ArrayList<>();

        if(nxtWrkQueCode!=WorkQueueCode.CHKDUR.getWorkQueueCode()) {
            fourPointCheckResp = fourPointCheck(inputAcceptResp.getDataResponse());

            Assert.assertEquals(fourPointCheckResp.getStatusCode(), 302, FOUR_POINT_CHECK_STATUS_MSG);
            Assert.assertFalse(fourPointCheckResp.getDataResponse().contains(ERROR_LITERAL), FOUR_POINT_CHECK_ERROR_MSG);
            inputResp = fourPointCheckResp.getDataResponse(InputResponse.class);
        }
        int rxFillId = inputResp.getRxFillId();
        Map<String, Object> taxDetails;
        taxDetails = dbUtils.getRxFIllDetails(siteId, rxFillId);
        BigDecimal expectedSaleAmt = (BigDecimal) taxDetails.get("expected_sale_amt");
        BigDecimal dueAmntAfterDowntime = (BigDecimal) taxDetails.get("patient_due_amt");
        if (dueAmntAfterDowntime.compareTo(BigDecimal.ZERO) <= 0) {
            dbUtils.updateExSaleAmtToPatientDue(siteId, rxFillId, expectedSaleAmt);
        }


        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());

        inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());
        // int rxFillId = inputResp.getRxFillId();
        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        if (nxtWrkQueCode != WorkQueueCode.CHKDUR.getWorkQueueCode()) {

            downTime(inputResp.getRxFillId(), inputResp.getOrderId(), inputResp.getOrderSeqNbr(),
                    prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        }
        //complete check DUR
        chkDURCompleteResp = chkDURComplete(inputAcceptResp.getDataResponse());
        Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
        Assert.assertFalse(chkDURCompleteResp.getDataResponse().contains(ERROR_LITERAL), CHK_DUR_ERROR_MSG);
        InputResponse checkDURInputResp = chkDURCompleteResp.getDataResponse(InputResponse.class);
        //Induce wait to allow CASH/TP processing
        am.performSleep(30);

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, checkDURInputResp.getRxFillId());

        if (nxtWrkQueCode != WorkQueueCode.FILLING.getWorkQueueCode()) {

            downTime(checkDURInputResp.getRxFillId(), checkDURInputResp.getOrderId(), checkDURInputResp.getOrderSeqNbr(),
                    prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, checkDURInputResp.getRxFillId());
        }

        rxDetails.add(String.valueOf(inputResp.getRxNbr()));
        rxDetails.add(String.valueOf(inputResp.getRxFillId()));
        rxDetails.add(String.valueOf(inputResp.getRxId()));
        return rxDetails;
    }

    /**
     * @deprecated Use {@link OrderWorkflowClient#moveOrderToPickUp} directly.
     */
    @Deprecated
    public ServiceResponse moveOrderToPickUp(String Resp) {
        return orderWorkflowClient.moveOrderToPickUp(Resp);
    }

    /**
     * @deprecated Use {@link OrderWorkflowClient#moveOrderToEOD} directly.
     */
    @Deprecated
    public ServiceResponse moveOrderToEOD(String Resp) {
        return orderWorkflowClient.moveOrderToEOD(Resp);
    }

    public ServiceResponse getOrderDetailsInfo(int siteId, int rxFillId) {

        GetOrderInfo getOrderInfo = new GetOrderInfo();
        getOrderInfo.setSiteId(siteId);
        getOrderInfo.setRxFillId(rxFillId);
        req.setUrl(prop.getProperty("fom.connexusWrapper.getOrderInfo"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        req.setRequestPayload(getOrderInfo);
        Reporter.log("getOrderInfo API endpoint: " + req.getUrl());
        Reporter.logJSON("getOrderInfo API Request", req.getRequestPayload());
        Log.info("getOrderInfo API RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("getOrderInfo API Response", resp.getDataResponse());
        Log.info("getOrderInfo API ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }

    public InputResponse createNewOrderToCounsel(int patientId, int siteId, int numRefills, String ndc, String presName,String presFName,String presLName,String presPhone,String state,int prescriberID,int rxClinicId,int rxOriginCode) {
        return partialWorkflowClient.createNewOrderToCounsel(patientId, siteId, numRefills, ndc, presName, presFName, presLName, presPhone, state, prescriberID, rxClinicId, rxOriginCode);
    }

    public ServiceResponse createOrderAndDropOff(int requestTypeCode, int priorityId, int dispenseType, int patientId, int storeNbr, String inputPickUpDate,
                                                 String inputRxExpDate, int numRefills, DataRow drugInfo, Prescriber prescriber) {

        DropOffQueueRequest dropoffRequest = new DropOffQueueRequest();
        Drug drug = new Drug();

        dropoffRequest.setRequestTypeCode(requestTypeCode);
        dropoffRequest.setPriorityId(priorityId);
        dropoffRequest.setDispenseType(dispenseType);
        dropoffRequest.setPatientId(patientId);
        dropoffRequest.setSiteID(storeNbr);
        dropoffRequest.setInputPickUpDate(inputPickUpDate);
        dropoffRequest.setInputRxExpDate(inputRxExpDate);
        dropoffRequest.setNumRefills(numRefills);
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr"));
        drug.setItemId(drugInfo.getValue("mds_fam_id"));
        drug.setRxProdId(drugInfo.getValue("product_mds_fam_id"));
        drug.setControlCode(drugInfo.getValue("drug_control_code"));
        drug.setPresMultiSrcCode(drugInfo.getValue("multi_source_code"));
        drug.setOnHandQty(Integer.parseInt(drugInfo.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
        //drug.setOnHandQty(1000);
        drug.setGpiCode(drugInfo.getValue("gpi_code"));
        drug.setUsualCost("0");
        drug.setActCost("0");
        drug.setOrgUsualCost("0");
        dropoffRequest.setDrug(drug);
        dropoffRequest.setPrescriber(prescriber);

        req.setRequestPayloadWithNulls(dropoffRequest);
        req.setUrl(prop.getProperty("fom.connexusWrapper.createOrderAndDropOffUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("CreateOrderAndDropOff Request endpoint: " + req.getUrl());
        Reporter.logJSON("CreateOrderAndDropOff Request", dropoffRequest);
        Log.info("CreateOrderAndDropOff RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("CreateOrderAndDropOff Response", resp.getDataResponse());
        Log.info("CreateOrderAndDropOff ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }

    public List<InputResponse> createMultiRxDropOffAndMoveTocheckDUR(int patientId, int siteId, int numRefills, List<String> ndcList, String priorityId,Prescriber prescriberObject) {
        Order order = new Order();
        order.setPrescriber(prescriberObject);

        inputPickupDate = wrapperUtils.getPickUpDate();
        inputRxExpDate = wrapperUtils.getExpiryDate();
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);

        //get multi drug details
        List<DataRow> NDCData = new ArrayList<>();
        for (String ndc : ndcList) {
            List<DataRow> rows = dbUtils.getMultiDrugInfo(cnx, ndc);
            NDCData.addAll(rows);
        }
        //setting order object
        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(priorityId));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);
        order.setNumRefills(numRefills);
        order.setPatientId(patientId);
        order.setSiteID(siteId);

        //create multiRx and drop-off
        dropOffResp = createMultiOrderAndDropOff(order, NDCData, prescriberObject);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createMultiRxAndDropOff API response status code did not match");

        MultiOrderInput multiOrderInput = dropOffResp.getDataResponse(MultiOrderInput.class);
        int drugListSize = multiOrderInput.getDrugList().size();
        OrderInput orderInput = new OrderInput();
        for (int i = 0; i < drugListSize; i++) {
            orderInput.setOrder(multiOrderInput.getOrder());
            orderInput.setDrug(multiOrderInput.getDrugList().get(i));

            String input = wrapperUtils.buildInputOrder(orderInput, siteId, prescriberObject);

            //completes input accept and 4point check
            inputAcceptResp = inputAccept(input);
            Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
            Assert.assertEquals(inputAcceptResp.getDataResponse().contains(ERROR_LITERAL), false, INPUT_ACCEPT_ERROR_MSG);
            inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
            am.performSleep(10);
            multiRx4PointCompleteResp.add(inputAcceptResp.getDataResponse(InputResponse.class));
        }
        return multiRx4PointCompleteResp;
    }

    public InputResponse createOrderAndMoveTocheckDUR(int patientId, int siteId, int numRefills, String ndc,Prescriber prescriberObject) {
        Date date = DateUtil.tomorrow();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        todayDate = date.toString();
        inputPickupDate = date.toString().substring(4, 10) + " " + date.toString().substring(24, 28) + " 18:00:00.000 UTC";
        inputRxExpDate = date.toString().substring(4, 10) + " 2026 " + "18:00:00.000 UTC";

        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        //get drug details
        DataRow drugInfo = getDrugInfo(cnx, ndc);

        //setting properties
        int requestTypeCode = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrderPriorityId"));
        int dispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));

        dropOffResp = createOrderAndDropOff(requestTypeCode, priorityId, dispenseType, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo, prescriberObject);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        //complete Input and 4 point
        inputAcceptResp = inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertEquals(inputAcceptResp.getDataResponse().contains(ERROR_LITERAL), false, INPUT_ACCEPT_ERROR_MSG);
        inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());

        fourPointCheckResp = fourPointCheck(inputAcceptResp.getDataResponse());
        Assert.assertEquals(fourPointCheckResp.getStatusCode(), 302, FOUR_POINT_CHECK_STATUS_MSG);
        Assert.assertFalse(fourPointCheckResp.getDataResponse().contains(ERROR_LITERAL), FOUR_POINT_CHECK_ERROR_MSG);
        inputResp = fourPointCheckResp.getDataResponse(InputResponse.class);

        Reporter.log("Order successfully moved to checkDUR queue");
        return inputResp;
    }

    public ServiceResponse createOrderAndDropOff(int requestTypeCode, int priorityId, int dispenseType, int patientId, int storeNbr, String inputPickUpDate,
                                                 String inputRxExpDate, int numRefills, DataRow drugInfo, Prescriber prescriber,int rxOriginCode) {

        DropOffQueueRequest dropoffRequest = new DropOffQueueRequest();
        Drug drug = new Drug();

        dropoffRequest.setRequestTypeCode(requestTypeCode);
        dropoffRequest.setPriorityId(priorityId);
        dropoffRequest.setDispenseType(dispenseType);
        dropoffRequest.setPatientId(patientId);
        dropoffRequest.setSiteID(storeNbr);
        dropoffRequest.setInputPickUpDate(inputPickUpDate);
        dropoffRequest.setInputRxExpDate(inputRxExpDate);
        dropoffRequest.setNumRefills(numRefills);
        dropoffRequest.setRxOriginCode(rxOriginCode);
        drug.setName(drugInfo.getValue("short_name").toString().trim());
        drug.setNdc(drugInfo.getValue("ndc_nbr"));
        drug.setItemId(drugInfo.getValue("mds_fam_id"));
        drug.setRxProdId(drugInfo.getValue("product_mds_fam_id"));
        drug.setControlCode(drugInfo.getValue("drug_control_code"));
        drug.setPresMultiSrcCode(drugInfo.getValue("multi_source_code"));
        drug.setOnHandQty(Integer.parseInt(drugInfo.getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
        //drug.setOnHandQty(1000);
        drug.setGpiCode(drugInfo.getValue("gpi_code"));
        drug.setUsualCost("0");
        drug.setActCost("0");
        drug.setOrgUsualCost("0");
        dropoffRequest.setDrug(drug);
        dropoffRequest.setPrescriber(prescriber);

        req.setRequestPayloadWithNulls(dropoffRequest);
        req.setUrl(prop.getProperty("fom.connexusWrapper.createOrderAndDropOffUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("CreateOrderAndDropOff Request endpoint: " + req.getUrl());
        Reporter.logJSON("CreateOrderAndDropOff Request", dropoffRequest);
        Log.info("CreateOrderAndDropOff RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("CreateOrderAndDropOff Response", resp.getDataResponse());
        Log.info("CreateOrderAndDropOff ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }

    public void deleteRx(int siteId, int orderId, int patientId){

        dbUtils.deleteRx(siteId, orderId, patientId);
    }

    public InputResponse createNewOrderToVV(int patientId, int siteId, int numRefills, String ndc, String presName, String presFName, String presLName, String presPhone, String state, int prescriberID, int rxClinicId, int rxOriginCode) {
        return partialWorkflowClient.createNewOrderToVV(patientId, siteId, numRefills, ndc, presName, presFName, presLName, presPhone, state, prescriberID, rxClinicId, rxOriginCode);
    }

    public InputResponse createNewOrderToDur(int patientId, int siteId, int numRefills, String ndc, String presName,String presFName,String presLName,String presPhone,String state,int prescriberID,int rxClinicId,String rxOriginCode) {
        return partialWorkflowClient.createNewOrderToDur(patientId, siteId, numRefills, ndc, presName, presFName, presLName, presPhone, state, prescriberID, rxClinicId, rxOriginCode);
    }

    public InputResponse performVisualVerifyAndPickup(int patientId, int orderId, int storeNbr,
                                                      int rxFillId, int rxId, int rxNbr,int numRefills,int orderSeqNum, String ndc, Prescriber prescriber) {
        return orderOrchestrationClient.performVisualVerifyAndPickup(patientId, orderId, storeNbr, rxFillId, rxId, rxNbr, numRefills, orderSeqNum, ndc, prescriber);
    }

    public InputResponse createNewOrderAndMoveToPickup(int patientId, int siteId, int numRefills, String ndc) {

        InputResponse fillCompleteInputResp;
        Date date = DateUtil.tomorrow();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        todayDate = date.toString();
        inputPickupDate = date.toString().substring(4, 10) + " " + date.toString().substring(24, 28) + " 18:00:00.000 UTC";
        inputRxExpDate = date.toString().substring(4, 10) + " 2025 " + "18:00:00.000 UTC";

        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        //get drug details
        DataRow drugInfo = getDrugInfo(cnx, ndc);

        //setting properties
        int requestTypeCode = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrderPriorityId"));
        int dispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));

        dropOffResp = createOrderAndDropOff(requestTypeCode, priorityId, dispenseType, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");
        am.performSleep(30);

        //complete Input and 4 point
        inputAcceptResp = inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertEquals(inputAcceptResp.getDataResponse().contains(ERROR_LITERAL), false, INPUT_ACCEPT_ERROR_MSG);
        inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());
        am.performSleep(80);

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        if (nxtWrkQueCode == WorkQueueCode.CHKDUR.getWorkQueueCode()) {

            //complete check DUR
            chkDURCompleteResp = chkDURComplete(inputAcceptResp.getDataResponse());
            Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
            Assert.assertEquals(chkDURCompleteResp.getDataResponse().contains(ERROR_LITERAL), false, CHK_DUR_ERROR_MSG);

            //Induce wait to allow CASH/TP processing
            am.performSleep(30);
            nxtWrkQueCode = WorkQueueCode.FILLING.getWorkQueueCode();

            //completes fillcomplete
            fillCompleteResp = fillComplete(chkDURCompleteResp.getDataResponse());
            Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
            Assert.assertFalse(fillCompleteResp.getDataResponse().contains(ERROR_LITERAL), FILLING_ERROR_MSG);
            fillCompleteInputResp = fillCompleteResp.getDataResponse(InputResponse.class);
            am.performSleep(5);

            if (nxtWrkQueCode == WorkQueueCode.VISUALVERIFY.getWorkQueueCode()) {
                downTime(fillCompleteInputResp.getRxFillId(), fillCompleteInputResp.getOrderId(), fillCompleteInputResp.getOrderSeqNbr(),
                        prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
                nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, fillCompleteInputResp.getRxFillId());
            }
        } else if (nxtWrkQueCode == WorkQueueCode.FILLING.getWorkQueueCode()) {

            fillCompleteResp = fillComplete(inputAcceptResp.getDataResponse());
            Assert.assertEquals(fillCompleteResp.getStatusCode(), 302, "FillComplete API response status code did not match");
            Assert.assertFalse(fillCompleteResp.getDataResponse().contains(ERROR_LITERAL), FILLING_ERROR_MSG);
            fillCompleteInputResp = fillCompleteResp.getDataResponse(InputResponse.class);

            //Induce wait to allow CASH/TP processing
            am.performSleep(5);

            if (nxtWrkQueCode != WorkQueueCode.RESOLVE.getWorkQueueCode()) {
                downTime(fillCompleteInputResp.getRxFillId(), fillCompleteInputResp.getOrderId(), fillCompleteInputResp.getOrderSeqNbr(),
                        prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
                nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, fillCompleteInputResp.getRxFillId());
            }
            if (nxtWrkQueCode != WorkQueueCode.VISUALVERIFY.getWorkQueueCode()) {
                downTime(fillCompleteInputResp.getRxFillId(), fillCompleteInputResp.getOrderId(), fillCompleteInputResp.getOrderSeqNbr(),
                        prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
                nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, fillCompleteInputResp.getRxFillId());
            }
        }
        //completes VVComplete
        vvCompleteResp = vvComplete(fillCompleteResp.getDataResponse());
        Assert.assertEquals(vvCompleteResp.getStatusCode(), 302, "vvComplete API response status code did not match");
        Assert.assertFalse(vvCompleteResp.getDataResponse().contains(ERROR_LITERAL), VV_ERROR_MSG);
        inputVVResp = vvCompleteResp.getDataResponse(InputResponse.class);
        am.performSleep(5);
        Reporter.log("Order successfully moved to Pickup queue");
        return inputVVResp;
    }

    /**
     * @deprecated Use {@link CardPaymentClient#insertEasyPayCardDetails} directly.
     */
    @Deprecated
    public ServiceResponse insertEasyPayCardDetails(String siteId, int patientId){
        return cardPaymentClient.insertEasyPayCardDetails(siteId, patientId);
    }

    public ArrayList<String> createOrderAndMoveTo4Pt_Autofill(int patientId, int siteId, int numRefills, String ndc) throws IOException, org.json.simple.parser.ParseException {

        //to get pickupdate as tomorrows date of the current year
        inputPickupDate = wrapperUtils.getPickUpDate();
        //to get expiry date based on year--pass the specified year needed
        inputRxExpDate = wrapperUtils.getExpiryDate();
        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);
        DataRow drugInfo = getDrugInfo(cnx, ndc);

        //complete drop-off
        int orderReqType = Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode"));
        int priorityId = Integer.parseInt(prop.getProperty("fom.OrdPriorityId"));
        int orderDispenseType = Integer.parseInt(prop.getProperty("fom.OrderDispenseType"));
        dropOffResp = createOrderAndDropOff(orderReqType, priorityId, orderDispenseType, patientId, siteId, inputPickupDate, inputRxExpDate, numRefills, drugInfo);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createOrderAndDropOff API response status code did not match");

        //complete Input and 4 point
        inputAcceptResp = inputAccept(dropOffResp.getDataResponse());
        Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
        Assert.assertFalse(inputAcceptResp.getDataResponse().contains(ERROR_LITERAL), INPUT_ACCEPT_ERROR_MSG);
        inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
        Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());

        int orderId = inputResp.getOrderId();
        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        int orderSeqNbr = inputResp.getOrderSeqNbr();
        if (nxtWrkQueCode == WorkQueueCode.RESOLVE.getWorkQueueCode()) {
            switchToCash(inputAcceptResp.getDataResponse());

        }

        ArrayList<String> rxDetails = new ArrayList<>();

        nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        if (nxtWrkQueCode != WorkQueueCode.CHKDUR.getWorkQueueCode()) {

            downTime(inputResp.getRxFillId(), inputResp.getOrderId(), inputResp.getOrderSeqNbr(),
                    prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
            nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId, inputResp.getRxFillId());
        }

        rxDetails.add(String.valueOf(inputResp.getRxNbr()));
        rxDetails.add(String.valueOf(inputResp.getRxFillId()));
        rxDetails.add(String.valueOf(inputResp.getRxId()));
        return rxDetails;
    }

    public List<InputResponse> createMultiRxAndMoveToFilling(int patientId, int siteId, int numRefills, List<String> ndcList, Prescriber prescriberObject) throws JsonProcessingException {
        Order order = new Order();
        //order.setPrescriber(prescriberObject);
        Date date = DateUtil.tomorrow();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        todayDate = date.toString();
        inputPickupDate = wrapperUtils.getPickUpDate();
        //to get expiry date based on year--pass the specified year needed
        inputRxExpDate = wrapperUtils.getExpiryDate();

        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);

        //get multi drug details
        List<DataRow> NDCData = new ArrayList<>();
        for (String ndc : ndcList) {
            List<DataRow> rows = dbUtils.getMultiDrugInfo(cnx, ndc);
            NDCData.addAll(rows);
        }

        //setting order object
        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(prop.getProperty("fom.OrderPriorityId")));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);
        order.setNumRefills(numRefills);
        order.setPatientId(patientId);
        order.setSiteID(siteId);

        //create multiRx and drop-off
        dropOffResp = createMultiOrderAndDropOff(order, NDCData, prescriberObject);
        Assert.assertEquals(dropOffResp.getStatusCode(), 201, "createMultiRxAndDropOff API response status code did not match");

        MultiOrderInput multiOrderInput = dropOffResp.getDataResponse(MultiOrderInput.class);
        int drugListSize = multiOrderInput.getDrugList().size();
        OrderInput orderInput = new OrderInput();
        for (int i = 0; i < drugListSize; i++) {
            orderInput.setOrder(multiOrderInput.getOrder());
            orderInput.setDrug(multiOrderInput.getDrugList().get(i));

            String input = wrapperUtils.buildInputOrder(orderInput, siteId, prescriberObject);

            //completes input accept and 4point check
            inputAcceptResp = inputAccept(input);
            Assert.assertEquals(inputAcceptResp.getStatusCode(), 302, "InputAccept API response status code did not match");
            Assert.assertEquals(inputAcceptResp.getDataResponse().contains(ERROR_LITERAL), false, INPUT_ACCEPT_ERROR_MSG);
            inputResp = inputAcceptResp.getDataResponse(InputResponse.class);
            Reporter.log("orderId = " + inputResp.getOrderId() + ", rxNbr = " + inputResp.getRxNbr() + ", rxId = " + inputResp.getRxId() + ", rxFillId = " + inputResp.getRxFillId());
            //Induce wait to allow CASH/TP processing
            Poller poller = new Poller();
            boolean isCashTPProcessed =  poller.pollForSuccess(() -> {
                nxtWrkQueCode = dbUtils.getNextWorkQueCode(siteId,inputResp.getRxFillId());
                return nxtWrkQueCode == WorkQueueCode.CHKDUR.getWorkQueueCode();
            });
            //complete check DUR
            if(isCashTPProcessed){
                chkDURCompleteResp = chkDURComplete(inputAcceptResp.getDataResponse());
                Assert.assertEquals(chkDURCompleteResp.getStatusCode(), 302, "CheckDURComplete API response status code did not match");
                Assert.assertEquals(chkDURCompleteResp.getDataResponse().contains(ERROR_LITERAL), false, CHK_DUR_ERROR_MSG);
                multiRxPaymentCompleteResp.add(chkDURCompleteResp.getDataResponse(InputResponse.class));
            }
            else { multiRxPaymentCompleteResp.add(inputAcceptResp.getDataResponse(InputResponse.class));
            }
        }
        return multiRxPaymentCompleteResp;
    }


    public JSONArray newMultiDrugOrderToReadyForPickUp(Order order, List<DataRow> drugInfo, Prescriber prescriber) {
        MultiRxDropOffQueueRequest multiRxDropOffQueueRequest = new MultiRxDropOffQueueRequest();
        order.setPrescriber(prescriber);
        Drug drug;
        ArrayList<Drug> drugList1 = new ArrayList();
        for (int i = 0; i < drugInfo.size(); i++) {
            drug = new Drug();
            drug.setName(drugInfo.get(i).getValue("short_name").toString().trim());
            drug.setNdc(drugInfo.get(i).getValue("ndc_nbr").toString().trim());
            drug.setItemId(Integer.parseInt(drugInfo.get(i).getValue("mds_fam_id").toString().trim()));
            drug.setRxProdId(Integer.parseInt(drugInfo.get(i).getValue("product_mds_fam_id").toString().trim()));
            drug.setControlCode(Short.parseShort(drugInfo.get(i).getValue("drug_control_code").toString().trim()));
            drug.setPresMultiSrcCode(Short.parseShort(drugInfo.get(i).getValue("multi_source_code").toString().trim()));
            drug.setOnHandQty(Integer.parseInt(drugInfo.get(i).getValue("on_hand_qty").toString().trim().replaceFirst("\\.0+$", "")));
            drug.setGpiCode(drugInfo.get(i).getValue("gpi_code").toString().trim());
            drug.setUsualCost("0");
            drug.setActCost("0");
            drug.setOrgUsualCost("0");
            drugList1.add(drug);
        }
        multiRxDropOffQueueRequest.setDrugList(drugList1);
        multiRxDropOffQueueRequest.setOrder(order);

        req.setRequestPayloadWithNulls(multiRxDropOffQueueRequest);
        req.setUrl(prop.getProperty("fom.connexusWrapper.newMultiDrugOrderToReadyForPickUpUrl"));
        Log.info("MultiOrderTillPickup Request endpoint\n " + req.getUrl());
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("MultiOrderTillPickup Request endpoint: " + req.getUrl());
        Reporter.logJSON("MultiOrderTillPickup Request", multiRxDropOffQueueRequest);
        Log.info("MultiOrderTillPickup Request\n " + req.getRequestPayload());
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("MultiOrderTillPickup Response", resp.getDataResponse());
        JSONArray response = new JSONArray(resp.getDataResponse());
        Log.info("MultiOrderTillPickup Response\n " + response);
        Reporter.logJSON("MultiOrderTillPickup Response - JSONArray", response);
        Assert.assertEquals(resp.getStatusCode(), 201, "createMultiOrderTillPickup API response status code did not match");

        return response;
    }

    public List<String> createNewMultiDrugOrderToReadyForPickUp(int patientId, int siteId, int numRefills, List<String> ndcList, Prescriber prescriberObject) {
        Order order = new Order();
        order.setPrescriber(prescriberObject);
        String rxNbr;

        //to get pickupdate as tomorrows date of the current year
        inputPickupDate= wrapperUtils.getPickUpDate();
        //to get expiry date based on year--pass the specified year needed
        inputRxExpDate= wrapperUtils.getExpiryDate();

        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(siteId);

        //get multi drug details
        List<DataRow> NDCData = new ArrayList<>();
        for (String ndc : ndcList) {
            List<DataRow> rows = dbUtils.getMultiDrugInfo(cnx, ndc);
            NDCData.addAll(rows);
        }
        //setting order object
        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(prop.getProperty("fom.OrderPriorityId")));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);
        order.setNumRefills(numRefills);
        order.setPatientId(patientId);
        order.setSiteID(siteId);

        //create multiOrderTillPickup
        multiOrderTillPickupResp  = newMultiDrugOrderToReadyForPickUp(order, NDCData, prescriberObject);

        for (int i = 0; i < multiOrderTillPickupResp.length(); i++) {
            JSONObject object;
            object = multiOrderTillPickupResp.getJSONObject(i);
            Gson gson = new Gson();
            JsonObject json = gson.fromJson(String.valueOf(object), JsonObject.class);
            JsonArray orders = json.get("order").getAsJsonArray();
            JsonObject orderlist = orders.get(0).getAsJsonObject();
            rxNbr = orderlist.get("rxNbr").getAsString();
            String rxFillId = orderlist.get("rxFillId").getAsString();
            String workQueue = orderlist.get("workQueue").getAsString();
            Log.info("RxNbr:" + rxNbr);
            Reporter.log("RxNbr:" + rxNbr);
            multirxNbrList.add(rxNbr);
            multirxNbrList.add(workQueue);
            multirxNbrList.add(rxFillId);
        }
        return  multirxNbrList;
    }

    /**
     * Create a new multi-drug order and move it to the ready-for-pickup status.
     *
     * @param order The order details including patientId, siteId, numRefills, ndcList, and prescriberObject.
     * @return A list of Orders.
     */
    @Deprecated
    public List<MultiDrugOrderToReadyForPickUpResponse> createNewMultiDrugOrderToReadyForPickUp(Order order, List<String> ndcList) {
        //to get pickupdate as tomorrows date of the current year
        inputPickupDate= wrapperUtils.getPickUpDate();
        //to get expiry date based on year--pass the specified year needed
        inputRxExpDate= wrapperUtils.getExpiryDate();

        //connect to store DB
        IDatabaseContext cnx = am.getConnexusDB(order.getSiteID());

        //get multi drug details
        List<DataRow> NDCData = new ArrayList<>();
        for (String ndc : ndcList) {
            List<DataRow> rows = dbUtils.getMultiDrugInfo(cnx, ndc);
            NDCData.addAll(rows);
        }
        //setting order object
        order.setRequestTypeCode(Integer.parseInt(prop.getProperty("fom.OrderRequestTypeCode")));
        order.setPriorityId(Integer.parseInt(prop.getProperty("fom.OrderPriorityId")));
        order.setDispenseType(Integer.parseInt(prop.getProperty("fom.OrderDispenseType")));
        order.setInputPickUpDate(inputPickupDate);
        order.setInputRxExpDate(inputRxExpDate);

        //create multiOrderTillPickup
        multiOrderTillPickupResp  = newMultiDrugOrderToReadyForPickUp(order, NDCData, order.getPrescriber());
        Gson gson = new Gson();
        return gson.fromJson(String.valueOf(multiOrderTillPickupResp), new TypeToken<List<MultiDrugOrderToReadyForPickUpResponse>>() {
        }.getType());
    }

    /**
     * @deprecated Use {@link OrderWorkflowClient#moveOrderToEOD} directly.
     */
    @Deprecated
    public ServiceResponse moveOrderToEOD(int patientId, int orderId, int storeNbr,
                                          int rxFillId, int rxId, int numRefills, String ndc, Prescriber prescriber) {
        return orderWorkflowClient.moveOrderToEOD(patientId, orderId, storeNbr, rxFillId, rxId, 
                numRefills, ndc, prescriber, this::getOrderInfo);
    }

    /**
     * @deprecated Use {@link ServiceAdminClient#restartConnexusService} directly.
     */
    @Deprecated
    public void restartConnexusService(String siteId) {
        serviceAdminClient.restartConnexusService(siteId);
    }

    /**
     * @deprecated Use {@link ServiceAdminClient#flushCache} directly.
     */
    @Deprecated
    public boolean flushCache(String siteId) {
        return serviceAdminClient.flushCache(siteId);
    }

    /**
     * This method will trigger open task API request.
     * @param activeStatus
     * @param siteId
     * @param eventId
     */
    /**
     * @deprecated Use {@link InventoryClient#openAndCloseTaskForInventory} directly.
     */
    @Deprecated
    public void openAndCloseTaskForInventory(String requestType, String activeStatus, String siteId, String eventId) {
        inventoryClient.openAndCloseTaskForInventory(requestType, activeStatus, siteId, eventId);
    }

    /**
     * @deprecated Use {@link InventoryClient#inTransitAndDeliveredForInventory} directly.
     */
    @Deprecated
    public void inTransitAndDeliveredForInventory(String activityType, String sourceSiteId, String recvSiteId, String eventId) {
        inventoryClient.inTransitAndDeliveredForInventory(activityType, sourceSiteId, recvSiteId, eventId);
    }
    
    /**
     * @deprecated Use {@link ServiceAdminClient#runConnexusScriptBE} directly.
     */
    @Deprecated
    public void runConnexusScriptBE(String siteId, String scriptName, String targetBoxType) {
        serviceAdminClient.runConnexusScriptBE(siteId, scriptName, targetBoxType);
    }

    public ServiceResponse moveOrderToPickup(int patientId, int orderId, int storeNbr,
                                          int rxFillId, int rxId, int numRefills, String ndc, Prescriber prescriber, boolean... isPrescriberResetNeeded) {
        Date date = DateUtil.tomorrow();
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        todayDate = date.toString();
        inputPickupDate = date.toString().substring(4, 10) + " " + date.toString().substring(24, 28) + " 18:00:00.000 UTC";
        inputRxExpDate = date.toString().substring(4, 10) + " 2025 " + "18:00:00.000 UTC";

        ServiceResponse getOrderInfoResponse = getOrderInfo(storeNbr, rxFillId, 2);
        // Commenting this because this is needed exactly once and the preference is saved
        boolean isPrescriberResetNeededForMoveOrder = isPrescriberResetNeeded.length >= 1 ? isPrescriberResetNeeded[0] : false;

        if (isPrescriberResetNeededForMoveOrder) {
            getOrderInfoResponse.setJsonElement("prescriber", null);
        }

        JsonObject object = JsonParser.parseString(getOrderInfoResponse.getDataResponse()).getAsJsonObject();
        req.setRequestPayloadWithNulls(object);

        req.setUrl(prop.getProperty("fom.connexusWrapper.moverOrderToPickupUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("moverOrderToPickup  Request endpoint: " + req.getUrl());
        Reporter.logJSON("moverOrderToPickup  Request", req.getRequestPayload());
        Log.info("moverOrderToPickup  RequestPayload:\n" + req.getRequestPayload() + "\n");
        resp = am.getRestContext().performPost(req);
        Reporter.logJSON("moverOrderToPickup  Response", resp.getDataResponse());
        Log.info("moverOrderToPickup  ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }

    /**
     * @deprecated Use {@link DowntimeClient#addRxSaleDetailsWithDowntime} directly.
     */
    @Deprecated
    public int addRxSaleDetailsWithDowntime(Integer siteId, Integer rxFillId) {
        return downtimeClient.addRxSaleDetailsWithDowntime(siteId, rxFillId);
    }

    /**
     * @deprecated Use {@link DowntimeClient#insertRxSaleDetailWithTPSSubmitted} directly.
     */
    @Deprecated
    public int insertRxSaleDetailWithTPSSubmitted(Integer siteId, Integer rxFillId) {
        return downtimeClient.insertRxSaleDetailWithTPSSubmitted(siteId, rxFillId);
    }
  
    /**
     * @deprecated Use {@link EODClient#createNewMultiDrugOrderToEOD} directly.
     */
    @Deprecated
    public JSONArray createNewMultiDrugOrderToEOD(int patientId, int siteId, int numRefills, List<String> ndcList, Prescriber prescriberObject) {
        return eodClient.createNewMultiDrugOrderToEOD(patientId, siteId, numRefills, ndcList, prescriberObject);
    }

    /**
     * @deprecated Use {@link PrescriberClient#getPrescriberDetails()} directly.
     */
    @Deprecated
    public Prescriber PrescriberDetails() {
        return prescriberClient.getPrescriberDetails();
    }

    public List<Integer> getAllFillsInPickupQueue(int storeId) {
        String rxFillIdQuery = "select rx_fill_id from informix.rx_order_detail where next_work_que_code= 6 and tote_nbr is not null and need_pickup_ind = \"Y\" and status_code = 20501 and est_pickup_ts < Date(Today - 20) order by rx_fill_id limit 500;";
        List<Map<String, Object>> resultSet = am.getConnexusDB(storeId).executeQueryForList(rxFillIdQuery);
        List<Integer> fillIds = new ArrayList<>();
        for (Map<String, Object> fill : resultSet) {
            fillIds.add(Integer.parseInt(fill.get("rx_fill_id").toString()));
        }
        return fillIds;
    }


    /**
     * @deprecated Use {@link EODClient#moveRXsToEODJob} directly.
     */
    @Deprecated
    public int moveRXsToEODJob(List<Integer> fillIds, int storeId) {
        return eodClient.moveRXsToEODJob(fillIds, storeId);
    }

    /**
     * This method will trigger open task API request.
     * @param countList
     * @param storeNumber
     */
    /**
     * @deprecated Use {@link InventoryClient#addNdcInCycleCountReportPage} directly.
     */
    @Deprecated
    public void addNdcInCycleCountReportPage(ArrayList<AddNDCToCycleCountPageCountList> countList, String storeNumber) {
        inventoryClient.addNdcInCycleCountReportPage(countList, storeNumber);
    }

    /**
     * @deprecated Use {@link CosmosClient#insertUpdateRecordForSuiteRunInDb} directly.
     */
    @Deprecated
    public void insertUpdateRecordForSuiteRunInDb(TestRecord testRecord) {
        cosmosClient.insertUpdateRecordForSuiteRunInDb(testRecord);
    }

    /**
     * @deprecated Use {@link CosmosClient#getRecordById} directly.
     */
    @Deprecated
    public TestRecord getRecordById(String id) {
        return cosmosClient.getRecordById(id);
    }

    /**
     * Central Fill ESPN Facility update API
     * @param inputData
     */
    /**
     * @deprecated Use {@link CentralFillClient#centralFillEspnUpdate} directly.
     */
    @Deprecated
    public void centralFillEspnUpdate(Map<String, String> inputData, List<Map<String, Integer>> fillIdAndTranIds) {
        centralFillClient.centralFillEspnUpdate(inputData, fillIdAndTranIds);
        // Update static fields for backward compatibility
        asnNumber = centralFillClient.getAsnNumber();
        shipmentId = centralFillClient.getShipmentId();
    }

    /**
     * @deprecated Use {@link CentralFillClient#centralFillASNInfo} directly.
     */
    @Deprecated
    public List<Integer> centralFillASNInfo() {
        return centralFillClient.centralFillASNInfo();
    }

    /**
     * @deprecated Use {@link CentralFillClient#centralFillCfBagInfo} directly.
     */
    @Deprecated
    public void centralFIllCfBagInfo(List<Integer> rxToken) {
        centralFillClient.centralFillCfBagInfo(rxToken);
        toteNumber = centralFillClient.getToteNumber();
        scanPickUpCodeForCF.clear();
        scanPickUpCodeForCF.addAll(centralFillClient.getScanPickUpCodeForCF());
    }

    /**
     * @deprecated Use {@link CentralFillClient#centralFillCfBagInfo} directly.
     */
    @Deprecated
    public void centralFIllCfBagInfo(List<Integer> rxToken, String rxNbr) {
        centralFillClient.centralFillCfBagInfo(rxToken, rxNbr);
        toteNumber = centralFillClient.getToteNumber();
        scanPickUpCodeForCF.clear();
        scanPickUpCodeForCF.addAll(centralFillClient.getScanPickUpCodeForCF());
    }

    /**
     * @deprecated Use {@link CentralFillClient#centralFillCfBagInfo} directly.
     */
    @Deprecated
    public void centralFIllCfBagInfo(int rxToken, String rxNbr) {
        centralFillClient.centralFillCfBagInfo(rxToken, rxNbr);
        toteNumber = centralFillClient.getToteNumber();
        scanPickUpCodeForCF.clear();
        scanPickUpCodeForCF.addAll(centralFillClient.getScanPickUpCodeForCF());
    }

    /**
     * @deprecated Use {@link CentralFillClient#centralFillCfBagInfo} directly.
     */
    @Deprecated
    public void centralFIllCfBagInfo(List<Integer> rxToken, String rxNbr, boolean pickupCode) {
        centralFillClient.centralFillCfBagInfo(rxToken, rxNbr, pickupCode);
        toteNumber = centralFillClient.getToteNumber();
        scanPickUpCodeForCF.clear();
        scanPickUpCodeForCF.addAll(centralFillClient.getScanPickUpCodeForCF());
    }
    /**
     * @deprecated Use {@link ServiceAdminClient#rxDataCleanUp} directly.
     */
    @Deprecated
    public void rxDataCleanUp(String siteId, String rxDeletionInDays, int conTimeOut, int reqTimeOut) {
        serviceAdminClient.rxDataCleanUp(siteId, rxDeletionInDays, conTimeOut, reqTimeOut);
    }

    /**
     * @deprecated Use {@link CentralFillClient#centralFillCfSetFillMissing} directly.
     */
    @Deprecated
    public void centralFIllCfSetFillMissing(int rxToken, boolean isNewToken) {
        centralFillClient.centralFillCfSetFillMissing(rxToken, isNewToken);
        toteNumber = centralFillClient.getToteNumber();
        scanPickUpCodeForCF.clear();
        scanPickUpCodeForCF.addAll(centralFillClient.getScanPickUpCodeForCF());
    }

    /**
     * @deprecated Use {@link CentralFillClient#centralFillFinalizeASN} directly.
     */
    @Deprecated
    public void centralFillFinalizeASN() {
        centralFillClient.centralFillFinalizeASN();
    }

    /**
     * @deprecated Use {@link CentralFillClient#setCFRTSInfo} directly.
     */
    @Deprecated
    public void setCFRTSInfo(int rxToken, boolean isNewToken) {
        centralFillClient.setCFRTSInfo(rxToken, isNewToken);
        toteNumber = centralFillClient.getToteNumber();
        scanPickUpCodeForCF.clear();
        scanPickUpCodeForCF.addAll(centralFillClient.getScanPickUpCodeForCF());
    }
    /**
     * This method will create new RX and Move it To EOD and accounts for DUR bypass
     * */

    @Deprecated

    public ServiceResponse createNewOrderAndMoveToEOD(int patientId, int siteId, int numRefills, DataRow drugInfo, String ndc) {
        return eodOrchestrationClient.createNewOrderAndMoveToEOD(patientId, siteId, numRefills, drugInfo, ndc);
    }

    public InputResponse createNewOrderAndMoveToInputAccept(int patientId, int siteId, int numRefills, DataRow drugInfo, String ndc) {
        return partialWorkflowClient.createNewOrderAndMoveToInputAccept(patientId, siteId, numRefills, drugInfo, ndc);
    }

    // refresh next queue with logging
    private int refreshNextQueue(int siteId, int rxFillId, String phase) {
        int code = dbUtils.getNextWorkQueCode(siteId, rxFillId);
        Reporter.log(phase + " - Next Work Queue Code: " + code);
        return code;
    }

    //check if WQ is in a set of enums
    private boolean isOneOfQueues(int code, WorkQueueCode... targets) {
        for (WorkQueueCode w : targets) {
            if (w.getWorkQueueCode() == code) {
                return true;
            }
        }
        return false;
    }

    // identify CASH Or TP WQ
    private boolean isCashOrTPQueue(int code) {
        return code == WorkQueueCode.CASH.getWorkQueueCode() || code == WorkQueueCode.TP.getWorkQueueCode();
    }

    //perform downtime and log
    private void performDownTime(int siteId, InputResponse respObj, String context) {
        Reporter.log("Performing downtime: " + context);
        downTime(respObj.getRxFillId(), respObj.getOrderId(), respObj.getOrderSeqNbr(),
                prop.getProperty("fom.userId"), prop.getProperty("fom.setDeviceName"), siteId);
    }

    // wait for CASH or TP queue transitions
    private void waitOnCashOrTP(int siteId, int rxFillId, int maxAttempts, int waitSeconds, String context) {
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            Reporter.log("[CASH/TP WAIT] " + context + " attempt " + attempt + " waiting " + waitSeconds + "s");
            am.performSleep(waitSeconds);
            int code = dbUtils.getNextWorkQueCode(siteId, rxFillId);
            if (!isCashOrTPQueue(code)) {
                Reporter.log("[CASH/TP WAIT] Exiting CASH/TP queue after attempt " + attempt + ": code=" + code);
                break;
            }
        }
    }
    // Gets the NDC value in String based on passed GPI
    /**
     * @deprecated Use {@link DrugInfoClient#getNdcInfoFromGpi(IDatabaseContext, String)} directly.
     */
    @Deprecated
    public String getNdcInfoFromGpi(IDatabaseContext cnx, String gpi) {
        return drugInfoClient.getNdcInfoFromGpi(cnx, gpi);
    }

    /**
     * @deprecated Use {@link DrugInfoClient#getOnHandQty(IDatabaseContext, String)} directly.
     */
    @Deprecated
    public int getOnHandQty(IDatabaseContext cnx, String ndc) {
        return drugInfoClient.getOnHandQty(cnx, ndc);
    }
    /**
     * @deprecated Use {@link DrugInfoClient#updateOnHandQty(IDatabaseContext, String, int)} directly.
     */
    @Deprecated
    public void updateOnHandQty(IDatabaseContext cnx, String ndc, int onHandQty) {
        drugInfoClient.updateOnHandQty(cnx, ndc, onHandQty);
    }

    /**
     * Calls the outcomes-filling-workflow API to create an order and move it to filling amd finally to Visual Verify
     * Retries once if the first attempt fails
     * @param patientId - Patient ID (from createPatient method)
     * @param siteID - Store number
     * @param inputData - Map containing all request fields named exactly as in curl
     * @return ServiceResponse containing the API response
     */
    @Deprecated
    public ServiceResponse outcomesFillingWorkflow(int patientId, int siteID, Map<String, String> inputData) {
        DropOffQueueRequest request = new DropOffQueueRequest();
        Drug drug = new Drug();

        request.setRequestTypeCode(Integer.parseInt(inputData.get("RequestTypeCode")));
        request.setPriorityId(Integer.parseInt(inputData.get("PriorityId")));
        request.setDispenseType(Integer.parseInt(inputData.get("DispenseType")));
        request.setPatientId(patientId);
        request.setSiteID(siteID);
        request.setInputPickUpDate(inputData.get("inputPickUpDate"));
        request.setInputRxExpDate(inputData.get("inputRxExpDate"));
        request.setNumRefills(Integer.parseInt(inputData.get("numRefills")));
        request.setAllowExpiredOrder(Boolean.parseBoolean(inputData.get("allowExpiredOrder")));

        drug.setName(inputData.get("DRUG_NAME"));
        drug.setNdc(inputData.get("NDC_NUMBER"));
        drug.setItemId(Integer.parseInt(inputData.get("itemId")));
        drug.setRxProdId(Integer.parseInt(inputData.get("rxProdId")));
        drug.setControlCode(Short.parseShort(inputData.get("controlCode")));
        drug.setPresMultiSrcCode(Short.parseShort(inputData.get("presMultiSrcCode")));
        drug.setOnHandQty(Integer.parseInt(inputData.get("onHandQty")));
        drug.setGpiCode(inputData.get("gpiCode"));
        drug.setUsualCost(inputData.get("usualCost"));
        drug.setActCost(inputData.get("actCost"));
        drug.setOrgUsualCost(inputData.get("orgUsualCost"));
        drug.setRxNbr(Integer.parseInt(inputData.get("rxNbr")));
        drug.setRxFillId(Integer.parseInt(inputData.get("rxFillId")));
        request.setDrug(drug);

        req.setRequestPayloadWithNulls(request);
        req.setUrl(prop.getProperty("fom.connexusWrapper.outcomesFillingWorkflowUrl"));
        headers.put("content-type", "application/json");
        req.setHeaders(headers);
        Reporter.log("OutcomesFillingWorkflow Request endpoint: " + req.getUrl());
        Reporter.logJSON("OutcomesFillingWorkflow Request", request);
        Log.info("OutcomesFillingWorkflow RequestPayload:\n" + req.getRequestPayload() + "\n");

        // First attempt
        resp = am.getRestContext().performPost(req);

        // Retry if first attempt fails (status code not 200 or 201)
        if (resp != null && (resp.getStatusCode() != 200 && resp.getStatusCode() != 201)) {
            Reporter.log("OutcomesFillingWorkflow first attempt failed with status: " + resp.getStatusCode() + ". Retrying...");
            Log.info("OutcomesFillingWorkflow first attempt failed. Retrying...");
            resp = am.getRestContext().performPost(req);
        }

        Reporter.logJSON("OutcomesFillingWorkflow Response", resp.getDataResponse());
        Log.info("OutcomesFillingWorkflow ResponsePayload:\n" + resp.getDataResponse() + "\n");
        return resp;
    }
}
