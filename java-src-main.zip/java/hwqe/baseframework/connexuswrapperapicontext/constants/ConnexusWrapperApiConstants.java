package hwqe.baseframework.connexuswrapperapicontext.constants;

/**
 * Constants for Connexus Wrapper API context.
 * 
 * Contains HTTP headers, media types, and common values used across client classes.
 * Follows the same pattern as PPIConstants, DomServiceConstants, etc.
 * 
 * Consolidates duplicate string literals to improve maintainability and reduce code smells.
 * 
 * @author Code Puppy (Egon)
 * @since May 2026
 */
public class ConnexusWrapperApiConstants {
    
    // ========== HTTP Headers ==========
    
    /**
     * HTTP Content-Type header name (lowercase convention).
     * Used by most client classes in this package.
     */
    public static final String HEADER_CONTENT_TYPE = "content-type";
    
    /**
     * HTTP Content-Type header name (Pascal case convention).
     * Used by some legacy methods for consistency with external APIs.
     */
    public static final String HEADER_CONTENT_TYPE_PASCAL = "Content-Type";
    
    // ========== Media Types ==========
    
    /**
     * JSON media type value.
     * Standard content type for REST API requests/responses.
     */
    public static final String MEDIA_TYPE_JSON = "application/json";
    
    // ========== Private Constructor (Utility Class Pattern) ==========
    
    /**
     * Private constructor to prevent instantiation of this utility class.
     * 
     * @throws AssertionError if instantiation is attempted
     */
    private ConnexusWrapperApiConstants() {
        throw new AssertionError("Utility class - do not instantiate");
    }
}
