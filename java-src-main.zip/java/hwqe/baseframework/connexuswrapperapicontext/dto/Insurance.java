package hwqe.baseframework.connexuswrapperapicontext.dto;

import lombok.Data;

/**
 * Simplified Insurance DTO for cnx-ui-wrapper /addPatient endpoint.
 * 
 * Used only by WrapperPatient for insurance-related data.
 * Currently not used in cnxmodularization tests (set to null).
 * 
 * @author Code Puppy (Egon)
 * @since May 2026
 */
@Data
public class Insurance {
    
    /** Insurance plan name */
    private String planName;
    
    /** Insurance carrier */
    private String carrier;
    
    /** Policy/member ID */
    private String memberId;
    
    /** Group number */
    private String groupNumber;
    
    /** Is this primary insurance? */
    private Boolean isPrimary;
}
