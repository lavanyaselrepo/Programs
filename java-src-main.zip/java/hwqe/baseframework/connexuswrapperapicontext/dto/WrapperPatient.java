package hwqe.baseframework.connexuswrapperapicontext.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import hwqe.baseframework.connexuswrapperapicontext.datamodels.Patient.Address;
import lombok.Data;
import java.util.List;

/**
 * Simplified Patient DTO for cnx-ui-wrapper /addPatient endpoint.
 * 
 * This matches the wrapper's flat Patient model (not the complex SAPS nested model).
 * Used ONLY by cnxmodularization package for Manual/CIVR/ERx tests.
 * Legacy code continues using CreatePatient for direct SAPS calls.
 * 
 * Wrapper endpoint: http://cnx-ui-wrapper-stage.hw-cnx-wrapper.k8s.glb.us.walmart.net/addPatient
 * 
 * @author Code Puppy (Egon)
 * @since May 2026
 */
@Data
public class WrapperPatient {
    
    /** Site/store ID where the patient is registered */
    private int siteId;
    
    /** Patient first name */
    private String firstName;
    
    /** Patient last name */
    private String lastName;
    
    /** Date of birth (C# format /Date(epochMillis)/ or ISO format) */
    private String dob;
    
    /** Input date of birth (raw string from UI) */
    private String inputDob;
    
    /** Gender (M/F/Other) */
    private String gender;
    
    /** Home phone number */
    private String homePhone;
    
    /** Work phone number */
    private String workPhone;
    
    /** Cell phone number */
    private String cellPhone;
    
    /** Connexus user ID (for audit) */
    private String cnxUser;
    
    /** Does the patient have insurance? */
    @JsonProperty("patientHasInsurance")
    private boolean patientHasInsurance;
    
    /** Is the patient a minor? */
    private Boolean isPatientMinor;
    
    /** List of insurance details (multiple insurances supported) */
    private List<Insurance> insurances;
    
    /** Address details (optional) */
    private Address address;
    
    /** Notification type */
    private String notificationType;
    
    /** Notification additional details */
    private String notificationAdditionDetail;
    
    /** Zip code */
    private String zipCode;
}
