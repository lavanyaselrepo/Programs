///<reference types="cypress" />
describe("alertSuite",function()
{
    it('handleAlert',function()
    {
        cy.visit("https://the-kitchen-applitools.netlify.app/ingredients/alert")
//      cy.get(".chakra-button css-huwc4k").click()
        cy.get("#alert-button").click()
        cy.on('window:alert',(str1)=>
        {
            expect(str1).to.equal('Airfryers can make anything!')
        })
    })
    it('Handle confirm',function()
    {
        cy.visit("https://the-kitchen-applitools.netlify.app/ingredients/alert")
//      cy.get(".chakra-button css-huwc4k").click()
        cy.get("#confirm-button").click()
        cy.on('window:confirm',(str2)=>
        {
            expect(str2).to.equal('Proceed with adding garlic?')
        })
    })
    /*it('confirmationAlert',function()
    {
        cy.visit("http://testautomationpractice.blogspot.com/")
        cy.get("#HTML9 > div.widget-content > button").click()
        cy.on('window:confirm',(msg)=>
        {
            expect(msg).to.equal('Press a button!')
        })

    })*/

        it('Handle Prompt', () => {
            cy.visit('https://the-kitchen-applitools.netlify.app/ingredients/alert')
            cy.window().then(win => {
                cy.stub(win, 'prompt').returns('Biriyani')
                cy.get('#prompt-button').click()
                cy.get('#prompt-answer').contains('Answer: Biriyani')
              })
    })
    })