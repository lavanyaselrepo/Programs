///<reference types="cypress" />
// this can be resued for data driven testing with different set of customers both valid and invalid
describe("custSuite",function()
{
    it("customTestcase",function()
    {
        cy.login('admin@yourstore.com','admin')
        cy.title().should('eq','Dashboard / nopCommerce administration')

    })
    //custom command with Data Driven Testing
    it("Add customer",function()                //invalid password
    {
        cy.login('admin@yourstore.com','admin1')
        cy.title().should('eq','Your store. Login')
        cy.log('Invalid login')

    })
    it("Edit customer",function()       //invalid username
    {
        cy.login('admin1@yourstore.com','admin')
        cy.title().should('eq','Your store. Login')
        cy.log('Invalid Login')

    })
})