///<reference types="cypress" />

describe('Table',function()
{
    it('Test Table',function()
    {
        cy.visit('testautomationpractice.blogspot.com')
        //check value anywhere in table
        cy.get('table[name="BookTable"]').contains('td','Learn Selenium').should('be.visible')  // validating  the table data
        //Check value present in specific row and column
//  #HTML1 > div.widget-content > table > tbody > tr:nth-child(2) > td:nth-child(3)---> 2 is the row no and 3 is the col   
        cy.get('table[name="BookTable"] > tbody > tr:nth-child(2) > td:nth-child(3)').contains('Selenium').should('be.visible')

        //Check value based on condition by iterating rows
        //verify the book name "Master in Java" whose author is Amod
        
        cy.get('table[name="BookTable"]>tbody>tr td:nth-child(2)').each(($e,index,$list) => {
            var text=$e.text()
            if(text.includes("Amod"))
            {
                cy.get('table[name="BookTable"]>tbody>tr td:nth-child(1)').eq(index).then(function(bName)
                {
                    var bookName=bName.text()
                    expect(bookName).to.equal("Master In Java")
                })
            }
        })
    })
})
