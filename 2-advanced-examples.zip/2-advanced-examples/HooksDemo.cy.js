///<reference types="cypress"/>
describe("hookSuite",function()
{
    before(() => {
        cy.log('This is a setUp Block')
      })
      beforeEach(() => {
          cy.log('This is the login block')
      })
      afterEach(() => {
        cy.log('This is Logout block')
    })
    after(() => {
        cy.log('This block contains exit criteria')
    })
  it("Search",function()
  {
      cy.log('Inside Search Test')
  })
  it("Advanced Search",function()
  {
      cy.log('Inside advanced Search')
  })
  it("ListingProduct",function()
  {
      cy.log('Inisde Listing Product Test')
  })
})