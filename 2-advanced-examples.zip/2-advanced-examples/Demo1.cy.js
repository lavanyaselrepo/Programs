///<reference types="cypress" />
describe('demo1Suite',function()
{
    it('OpenURL',function()
    {
        cy.log('This is the first test for June7 batch')
        cy.visit('https://demo.nopcommerce.com/')
        cy.log('Application URL is opened !!')
        cy.get('.ico-login').click()
       // cy.wait(5000)
        cy.get('#Email').type('lavanya123@yahoo.com')
        cy.get('.password').type('lavanya123')
        cy.get('.login-button').click()
        cy.title().should('eq','nopCommerce demo store')
        cy.log('Logged in successfully!!')
    })
})