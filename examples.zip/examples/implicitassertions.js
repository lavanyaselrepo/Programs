///<reference types= "cypress"/>

describe('Interacting with web elements',function()
{
    it('firstTest',function()
    {
        cy.visit('https://juliemr.github.io/protractor-demo/');
        cy.title().should('eq','Super Calculator');
        cy.get('input[ng-model="first"]').type('10');
        cy.get('select').select('+');
        cy.get('input[ng-model="second"]').type('20');
        cy.get('#gobutton').click();
        cy.wait(2000);
        cy.get('input[ng-model="first"]').type('10');
        cy.get('select').select('/');
        cy.get('input[ng-model="second"]').type('10');
        cy.get('#gobutton').click();
        cy.wait(2000);
        cy.get('body>div.container.ng-scope>table>tbody')
        .should('contain','1')
        .and('contain','30')
        cy.log('successfully validated')


    })
})