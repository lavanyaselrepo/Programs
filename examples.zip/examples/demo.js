///<reference types= "cypress"/>

describe('Testsuite',function()
{
  it('DemoTest',function()
    {
		cy.visit("https://demo.nopcommerce.com/")
		cy.log('Application url is opened')

	})
})