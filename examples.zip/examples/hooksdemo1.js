///<reference types="cypress"/>

describe("hook demo",function(){

    before(function() {
        cy.log('This is a setUp Block')   
    })

    beforeEach(function() {
          cy.visit('https://juliemr.github.io/protractor-demo/');
          cy.log('This is the login block')
          cy.get('input[ng-model="first"]').type('10');
          cy.get('input[ng-model="second"]').type('5');
    })
    afterEach(() => {
        cy.log('This is Logout block') 
        cy.get('.btn').click();
        cy.wait(2000);
        cy.get('h2[class=ng-binding]').invoke('text').then(total =>{
            cy.log(total)
        })     
    })

    after(() => {
        cy.log('This block contains exit block')
        cy.get('table>tbody>tr>td:nth-child(3)').each(($e1) => {
            const text=$e1.text()
            cy.log(text)
            cy.wait(2000)
        })
    })
    
  it("Addition",function()
  {
    cy.get('select[ng-model=operator]').select('+').should('have.value', 'ADDITION')
  })
  it("Subtraction",function()
  {
    cy.get('select[ng-model=operator]').select('-').should('have.value', 'SUBTRACTION')
  })
  it("Divison",function()
  {
    cy.get('select[ng-model=operator]').select('/').should('have.value', 'DIVISION')
  })

})