///<reference types= "cypress"/>

describe('Interacting with web elements',function()
{
    it('firstTest',function()
    {
        cy.visit('https://demo.nopcommerce.com/');
        cy.get('.ico-register').click();
        cy.get('input[value="F"]').should('be.visible').should('not.be.checked').click(); //click radio btn
        cy.get('#Newsletter').uncheck().should('not.be.checked'); //uncheck checkbox
        cy.get('[name="DateOfBirthDay"]').select(8).should('have.value','8'); //select dropdown day
        cy.get('[name="DateOfBirthMonth"]').select('January').should('have.value','1');//select dropdown month
        cy.get('[name="DateOfBirthYear"]').select('1914').should('have.value','1914');//select dropdown year

    })
})