///<reference types= "cypress"/>

describe('Interacting with web elements',function()
{
    it('firstTest',function()
    {
        cy.visit('https://demo.nopcommerce.com/');
        cy.get('.ico-register').click();
        cy.get('input[value="F"]').should('be.visible').should('not.be.checked').click();
    })
})