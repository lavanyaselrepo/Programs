///<reference types="cypress" />

describe('Web Table',function()
{
    it('Test Table',function()
    {
        cy.visit('https://testautomationpractice.blogspot.com/')
        cy.xpath('//h2[text()="HTML Table"]').scrollIntoView().should('be.visible');

         //check value anywhere in table
         cy.get('table[name="BookTable"]').contains('td','Amit').should('be.visible') 

         //Check value present in specific row and column
         cy.get('table[name="BookTable"] > tbody > tr:nth-child(2) > td:nth-child(3)').contains('Selenium').should('be.visible')
 
    })
})
