///<reference types= "cypress"/>

describe('Interacting with web elements',function()
{
    it('firstTest',function()
    {
        cy.visit('https://testautomationpractice.blogspot.com/');
        cy.get('#field1').should('have.value','Hello World!');
        cy.get('#field2').type("textfield");
        cy.xpath('//button[text()="Copy Text"]').click();

    })
})