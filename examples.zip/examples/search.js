///<reference types= "cypress"/>

describe('SearchSuite',function()
{
    it('firstTest',function()
    {
        cy.log('This is the first Test case executed in Cypress')
        cy.visit('https://demo.nopcommerce.com/')
        cy.get('.ui-autocomplete-input').type("Lenovo Thinkpad X1 Carbon Laptop")
        cy.get('.search-box-button').click()
        cy.get('.actual-price').should('contain','$1,360.00')
        cy.get('.product-box-add-to-cart-button').click() 
       // cy.get('input[value="F"]').click()//validating radio button
      //  cy.get("#Newsletter").check() //CheckBox
       //let popmsg = cy.get('.bar-notification')
       //popmsg.should('eq', 'The product has been added to your ')
        
    })
})