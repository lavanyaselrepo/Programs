///<reference types= "cypress"/>

describe('Test Suite',function()
{
    it('Explicit Assertion',function()
    {
        cy.visit('https://juliemr.github.io/protractor-demo/');
        cy.get('h3').invoke('text').then(text1 =>{
            expect(text1).to.eq('Super Calculator')
        })
        //perform addition and validate result
        cy.get('input[ng-model="first"]').type('10');
        cy.get('select').select('+');
        cy.get('input[ng-model="second"]').type('20');
        cy.get('#gobutton').click();
        cy.wait(2000);
        cy.get('table>tbody>tr>td:nth-child(3)').invoke('text').then(add =>{
            assert.equal(add,30);
        })
    })
})