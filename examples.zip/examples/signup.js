///<reference types="cypress" />

describe('Signup',function()
{
    it('OpenURL',function()
    {        
        cy.visit("https://demo.nopcommerce.com/")
        cy.get(".ico-register").click()
        cy.get('input[value="F"]').click()  //validating radio button
        cy.get('input[name="FirstName"]').type("Lavanya")
        cy.get("#LastName").type("T")
        cy.get('input[name="Email"]').type("lavanya129@yahoo.com")
        cy.get("#Newsletter").uncheck()     //uncheck the checkbox
        cy.get('input[name="Password"]').type("lavanya123")
        cy.get('input[name="ConfirmPassword"]').type("lavanya123")
        cy.get(".register-next-step-button").click()
        cy.get(".result").contains("Your registration completed")
        cy.log("Your registration completed successfully")
        
    })

})