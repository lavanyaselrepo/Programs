///<reference types= "cypress"/>

describe('Flipkart automation',function()
{
  it('Test1',function()
    {
	cy.visit('https://www.flipkart.com/')
    cy.xpath('//img[@alt="Mobiles"]').click()
	cy.xpath('//span[text()="Electronics"]').trigger('mouseover')
	cy.xpath('//a[@title="Vivo"]').click()
	
	cy.xpath('//div[text()="Price -- High to Low"]').click()
	
	cy.xpath('//span[text()="Price"]/following::select').first().select("₹10000")
	//cy.xpath('//span[text()="Price"]/following::select)').last().select("₹30000")
	
	cy.title().should('contains','Flipkart')
	})
})