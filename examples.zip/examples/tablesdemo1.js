///<reference types="cypress" />

describe('Web Table',function()
{
    it('interact with table',function()
    {
        cy.visit('https://testautomationpractice.blogspot.com/')
        cy.xpath('//h2[text()="HTML Table"]').scrollIntoView().should('be.visible')

         //check value anywhere in table
         cy.get('table[name="BookTable"]').contains('td','Amit').should('be.visible') 

         //Check value present in specific row and column
         cy.get('table[name="BookTable"] > tbody > tr:nth-child(2) > td:nth-child(3)').contains('Selenium').should('be.visible')

        //Check value based on condition by iterating rows
        //verify the book name "Master in Java" whose author is Amod
        
        cy.get('table[name="BookTable"]>tbody>tr td:nth-child(2)').each(($e,index) => {
            var text=$e.text()
            if(text.includes("Amod"))
            {
                cy.get('table[name="BookTable"]>tbody>tr td:nth-child(1)').eq(index).then(function(bName)
                {
                    var bookName=bName.text()
                    cy.log(bookName)
                    expect(bookName).to.equal("Master In Java");
                })
            }
        })
    })
})
