///<reference types="cypress"/>

describe('parameteriseSuite',function()
{
    before(function()
    {
        cy.fixture('Login').then(function(data)
        {
            this.data=data
        })
    })
    it('fixtureTest',function()
    {
        cy.visit('https://demo.nopcommerce.com/')
        cy.get(".ico-login").click()
        cy.get("#Email").type(this.data.username)
        cy.get(".password").type(this.data.password)
        cy.get(".login-button").click()

    })
})